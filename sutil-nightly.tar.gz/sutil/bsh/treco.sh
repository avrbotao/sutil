
#_______________________________________________________________________________
#
#	#####  #####   ######   ####    ####
#	  #    #    #  #       #    #  #    #
#	  #    #    #  #####   #       #    #
#	  #    #####   #       #       #    #
#	  #    #   #   #       #    #  #    #
#	  #    #    #  ######   ####    ####
#_______________________________________________________________________________
#
#	treco : Testa RElacao de COnfianca			botao 2013-2019
#_______________________________________________________________________________
#

BAN="	treco	1.0.15	2019-12-19	bud"

LOG=/tmp/.treco.log
ERR=/tmp/.treco.err
TMP=/tmp/.treco.tmp

padit () {
	echo "..."
}

logit () {
	PRT=$1
	shift
	if test "$1" = "-v"
	then
		shift
		echo "### `date +%Y/%m/%d_%H:%M:%S`" "$*"
	fi
	echo "`date +%Y/%m/%d_%H:%M:%S`" "$*" >> $PRT
}

trecout () {
	logit $LOG $*
}

trecerr () {
	logit $ERR $*
	cat -n $LOG
	cat -n $ERR
	exit 1
}

xping () {
	h=$1
	case $tos in
		AIX) ping -c 1 -w 1 $h ;;
		Linux) ping -c 1 $h ;;
		HP-UX) ping $h -n 1 -m 1 ;;
		SunOS) ping -s $h 64 1 ;;
		*) erro 9 $tos ;;
	esac
}

#_______________________________________________________________
#
#	main
#_______________________________________________________________
#

> $LOG
> $ERR
> $TMP

echo
trecout -v begin treco

# clear

cat <<EOC

	#####  #####   ######   ####    ####
	  #    #    #  #       #    #  #    #
	  #    #    #  #####   #       #    #
	  #    #####   #       #       #    #
	  #    #   #   #       #    #  #    #
	  #    #    #  ######   ####    ####

EOC
echo "$BAN\n"

orig=$1
dest=$2

if [ "$orig" = "" -o "$dest" = "" ]
then
	echo "use: $0 [origuser@]orighost [destuser@]desthost \n"
	exit 1
fi

localuser=`whoami`
localhost=`hostname`

DLY=5
SOP="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=$DLY -o PasswordAuthentication=no"

case $orig in
	*@*)
		origuser=`echo $orig | cut -d '@' -f 1`
		orighost=`echo $orig | cut -d '@' -f 2`
	;;
	*)
		origuser=$localuser
		orighost=$orig
	;;
esac

case $dest in
	*@*)
		destuser=`echo $dest | cut -d '@' -f 1`
		desthost=`echo $dest | cut -d '@' -f 2`
	;;
	*)
		destuser=$localuser
		desthost=$dest
	;;
esac

#________________________________________________________________________
#

trecout -v check infos

trecout -v "localuser=($localuser) localhost=($localhost) origuser=($origuser) orighost=($orighost) destuser=($destuser) desthost=($desthost)"

#________________________________________________________________________
#

trecout -v orig host

nslookup $orighost >> $LOG 2>&1

	if xping $orighost >> $LOG 2>&1
	then
		origping=1
	else
		erro 4 $origaddr
	fi

	if xping $destaddr > /dev/null 2>&1
	then
		destping=1
	else
		erro 4 $destaddr
	fi

### ping $orighost -c 1 -w 1 >> $LOG 2>&1
ping $orighost -n 1 -m 1 >> $LOG 2>&1
ssh $SOP $orighost "uname -a" >> $LOG 2>&1
test $? -ne 0 && trecerr orig host ssh fail 

trecout -v "looks good"

#________________________________________________________________________
#

trecout -v dest host

nslookup $desthost >> $LOG 2>&1
### ping $desthost -c 1 -w 1 >> $LOG 2>&1
ping $desthost -n 1 -m 1 >> $LOG 2>&1
ssh $SOP $desthost "uname -a" >> $LOG 2>&1
test $? -ne 0 && trecerr dest host ssh fail 

trecout -v "looks good"

#________________________________________________________________________
#

trecout -v orig user

ssh $SOP $orighost "id $origuser" >> $LOG 2>&1
test $? -ne 0 && trecerr missing orig user

trecout -v "looks good"

### FIXME: check ownership and mode

#________________________________________________________________________
#

trecout -v orig key

ssh $SOP $orighost "ls -l ~$origuser/.ssh/id*.pub" >> $LOG 2>&1
test $? -ne 0 && trecerr missing orig key

trecout -v "looks good"

### FIXME: check ownership and mode

#________________________________________________________________________
#

trecout -v dest user

ssh $SOP $desthost "id $destuser" >> $LOG 2>&1
test $? -ne 0 && trecerr missing dest user

trecout -v "looks good"

#________________________________________________________________________
#

trecout -v dest HOME

ssh $SOP $desthost "ls -ld ~$destuser ~$destuser/.ssh" >> $LOG 2>&1
test $? -ne 0 && trecerr missing dest HOME

trecout -v "looks good"

### FIXME: check ownership and mode

#________________________________________________________________________
#

trecout -v dest key

ssh $SOP $desthost "ls -l ~$destuser/.ssh/authorized_keys" >> $LOG 2>&1
test $? -ne 0 && trecerr missing dest key

trecout -v "looks good"

### FIXME: check ownership and mode

#________________________________________________________________________
#

trecout -v final check

ssh -t $SOP $orighost "su - $origuser -c \"ssh -t $SOP -l $destuser $desthost 'id;uname -a'\" " >> $LOG 2>&1
test $? -ne 0 && trecerr final check failed

trecout -v "passed"

#________________________________________________________________________
#

exit 0

#________________________________________________________________________
# vi:nu ts=8
