
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

SWNAME="rep-sudo-root-all.sh"
SWVERS="1.0.2"
SWDATE="2021/09/01"
SWDESC="report sudo all root"
SWTAGS="script,foss,report,sudo,root,all,sudoers"
SWCOPY="GPLv3"
SWAUTH="alexandre at botao dot org"

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code is part of "fixish" by <alexandre at botao dot org>        |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

THISPATH=$0

THISFILE=`basename $0`
THISNAME=`basename $THISFILE .sh`

#THISUSER=username

### 
### 
###         /\          _____________________________________________________
###        /  \        |                                                     |
###       / OO \       |   "rep-sudo-root-all.sh"         point priv sudos   |
###       \ \/ /       |   (c) [2020-]2021           alexandre v. r. botao   |
###        \  /        |_____________________________________________________|
###         \/
### 
### 

CTO=3
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=$CTO -o PasswordAuthentication=no"

###    _______________________________________________________________________
###   |                                                                       |
###   |   all at once                                       search and show   |
###   |_______________________________________________________________________|
###

### FIXME: argize custom infos
cd $HOME/invinfo
T=/tmp/.psra.
L=hosts.list
test -n "$1" && L=$1
for i in `cat $L`
do
	ddd=${i}.info.dir
	if test -d "${ddd}"
	then
		find $ddd -type f | grep sudoers | while read lin
		do
			fil=`basename $lin`
			pfx="${i};${fil}"
			### grep ALL $lin | tr "\t" " " | egrep -v -e "^#|^root |^Defaults |LC_ALL" > $T
			grep "NOPASSWD: *ALL" $lin | tr "\t" " " | egrep -v -e "^#|^root |^Defaults |LC_ALL" > $T
			test -s $T && cat $T | sed "s/^/${pfx};/"
		done
	fi
done
rm -f $T

#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#        1         2         3         4         5         6         7         8
# vi:nu ts=4
