#	sbase	get	single
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=5 -o PasswordAuthentication=no"
X=sget
test -s ${X}.in || exit 1
H=$1
SF=`cat ${X}.in`
DS=`basename $SF`
if test -z "$H"
then
	echo "noargs;nothing" > noargs.${X}
else
	if grep -i "^${H}$" newest-ssh.list >/dev/null
	then
		ULBS=/usr/local/bin/
	else
		ULBS=/usr/bin/
	fi
	### -v -i /root/.ssh/id_rsa156 
	${ULBS}scp -q -p ${SSHOPT} ${H}:${SF} ${H}.${DS} > ${H}.${X} 2> ${H}.${X}_err
	if test $? -eq 0
	then
		echo "${H};good" >> ${X}.log
	else
		echo "${H};fail" >> ${X}.log
	fi
fi
# vi:nu
