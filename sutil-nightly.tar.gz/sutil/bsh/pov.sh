# pov : processor-os-version
os=`uname -s`
test -z "$os" && os=`uname`
case $os in
	CYGWIN*)
		osn=`uname -o`
		cpu=`uname -m`
		osv=`uname -r | cut -d '(' -f 1`
def="CYGWIN"
	;;
	Linux)
		osn=$os
		cpu=`uname -m`
		osv=`uname -r | cut -d '-' -f 1`
def="LINUX"
	;;
	FreeBSD)
		def="FREEBSD" ; osn=$os ; cpu=`uname -m` ; ost="BSD"
		osv=`echo $ur | cut -d '-' -f 1`
	;;
	NetBSD)
		def="NETBSD" ; osn=$os ; cpu=`uname -m` ; ost="BSD"
		osv=`echo $ur | cut -d '-' -f 1`
	;;
	OpenBSD)
		def="OPENBSD" ; osn=$os ; cpu=`uname -m` ; ost="BSD"
		osv=`echo $ur | cut -d '-' -f 1`
	;;

	HP-UX)
		osn=$os
		cpu=`uname -m`
		[ "$cpu" = "9000/800" ] && cpu=parisc
		osv=`uname -r`
def="HPUX"
	;;
	SunOS)
		osn=$os
		cpu=`uname -p`
		osv=`uname -r`
def="SOLARIS"
	;;
	AIX)
		osn=$os
		cpu=`uname -p`
		osv=`uname -v`.`uname -r`
def="AIX"
	;;
	*)
		def=$os
osn=$os
cpu=`uname -p`
osv=`uname -v`.`uname -r`
	;;

esac
echo "${cpu}_${osn}_${osv}"
