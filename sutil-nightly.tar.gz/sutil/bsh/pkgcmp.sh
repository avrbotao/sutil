#
#	pkgcmp : cmp pkgs
#

usage () {
	echo "use : $0 [ host1 host2 ] [-v]"
	exit 1
}

hosta=$1
hostb=$2
exopt=$3
tene="=========="
nota="          "
nono="          "
notb="          "

test -z "$hosta" && usage
test -z "$hostb" && usage

SSHDLY=3
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=$SSHDLY -o PasswordAuthentication=no"

echo "# chk"

osta=`ssh $SSHOPT $hosta "uname"`
ostb=`ssh $SSHOPT $hostb "uname"`

test -z "$osta" && usage
test -z "$ostb" && usage

if [ "${osta}" = "${ostb}" ]
then
	hdr1=$hosta hdr2="(X)" hdr3=$hostb
else
	usage
fi

tmp=/tmp
aboth=${tmp}/.hon.ab
baoth=${tmp}/.hon.ba
aonly=${tmp}/.hon.ao
bonly=${tmp}/.hon.bo
bskip=${tmp}/.hon.sk
afull=${tmp}/.hon.af
bfull=${tmp}/.hon.bf
allab=${tmp}/.hon.al

rm -f ${tmp}/.hon.??

echo "# get"

case $osta in
	Linux)
		ssh $SSHOPT $hosta "rpm -qa --qf \"%{NAME}\n\" | sort" > $afull
		ssh $SSHOPT $hostb "rpm -qa --qf \"%{NAME}\n\" | sort" > $bfull
	;;
	*) usage ;;
esac

cat $afull $bfull | sort -u > $allab

wid=`cat $allab | awk '{print length($0)}' | sort -n | tail -1`

fmt="%-${wid}s | %-${wid}s | %-${wid}s\n"

echo "# cmp"

if test "${exopt}" = "-v"
then
	printf "${fmt}" ${hdr1} ${hdr2} ${hdr3}
	printf "${fmt}" "$tene" "$tene" "$tene"
fi

cat $allab | while read nam
do
	if grep -q "^${nam}$" ${afull} && grep -q "^${nam}$" ${bfull}
	then
		echo ${nam} >> $aboth
		test "${exopt}" = "-v" && printf "${fmt}" "$nota" "${nam}" "$notb"
	elif grep -q "^${nam}$" ${afull}
	then
		echo ${nam} >> $aonly
		test "${exopt}" = "-v" && printf "${fmt}" "${nam}" "$nono" "$notb"
	else
		echo ${nam} >> $bonly
		test "${exopt}" = "-v" && printf "${fmt}" "$nota" "$nono" "${nam}"
	fi
done

if test "${exopt}" != "-v"
then
	if test -s $aonly
	then
		echo "=== only on ($hosta)"
		cat -n $aonly
	fi
	if test -s $bonly
	then
		echo "=== only on ($hostb)"
		cat -n $bonly
	fi
	if test -s $aboth
	then
		echo "=== common to ($hosta) and ($hostb)"
		cat -n $aboth
	fi
fi

exit 0

# vi:nu ts=4
