#
#	increment version string
#
#	2.1.35		2019/06/17	doc
#	2.1.34		2018/12/05
#

test -s $HOME/.bud && . $HOME/.bud && BASE=`mybase`

test -z "$BASE" && BASE=$HOME

THIS=`hostname`

HISTPATH=${BASE}:${BASE}/lab:${BASE}/lab/l8st

vc=version.c
vh=version.h
hd=hist
hn=ivs.hist
ie=info.env
fe=foss.env

ps=program_string
ys=library_string
vs=version_string

rs=release_string
ts=relogio_string

ss=summary_string
gs=taglist_string
li=license_string
cs=creator_string
ms=contact_string

bs=builder_string
cc=compile_string

PROGRAM=
LIBRARY=
VERSION=
RELEASE=
RELOGIO=
SUMMARY=
TAGLIST=
LICENSE=
CREATOR=
CONTACT=
BUILDER=
COMPILE=

if [ "$1" = "-l" ]
then
	shift
	HST=1
fi

if [ "$1" = "-d" ]
then
	shift
	dir=$1
	if test -z "${dir}"
	then
		echo ">>> missing dir <<<" 1>&2
		exit 1
	fi
	if test -d "${dir}"
	then
		cd $dir
		shift
	else
		echo ">>> NO dir ($dir) <<<" 1>&2
		exit 1
	fi
fi

if [ -s $ie ]
then
	cat -n $ie
elif [ -s $fe ]
then
	ie=$fe
	cat -n $ie
else
	echo ">>> NO $ie or $fe <<<" 1>&2
	exit 1
fi

for i in `echo $HISTPATH | tr ":" " "`
do
	if test -s ${i}/${hd}/${hn}
	then
		hf=${i}/${hd}/${hn}
		break
	fi
done

if [ -z "${hf}" ]
then
	echo ">>> NO history <<<"
	exit 1
else
	echo "=== history ($hf) ==="
	if test "$HST" = 1
	then
		cat $hf
		exit 0
	fi
fi

nvi="$1"
if [ -z "${nvi}" ]
then
	echo "use : $0 [-l] [-d dir] [\"description\"]" 1>&2
	exit 1
else
	echo "=== description ($nvi) ==="
fi

echo "=== load ($ie)"
. ./${ie}
echo "=== loaded ($ie)"

if test -n "${PROGRAM}"
then
	lps=${PROGRAM}
elif test -n "${LIBRARY}"
then
	lps=${LIBRARY}
	PROGRAM=${LIBRARY}
else
	echo ">>> NO name <<<"
	exit 1
fi

cvi=`grep " $lps " $hf | tail -1 | cut -d '"' -f 2`

if [ -n "$cvi" ]
then
	if [ "$nvi" = "$cvi" ]
	then
		echo "ivs warn : duplicate version info ($cvi)"
	fi
fi

tst=`date "+%Y-%m-%d %T"`		# time stamp
ymd=`echo $tst | cut -d ' ' -f 1`	# year month day
tod=`echo $tst | cut -d ' ' -f 2`	# time of day

cvs=${VERSION}
crs=${RELEASE}
cts=${RELOGIO}

cvn=`echo $cvs | cut -d '.' -f 1`
crn=`echo $cvs | cut -d '.' -f 2`
cbn=`echo $cvs | cut -d '.' -f 3`

nvn=$cvn
nrn=$crn

nbn=`expr $cbn + 1`
if [ $nbn -gt 99 ]
then
	nbn=0
	nrn=`expr $nrn + 1`
	if [ $nrn -gt 9 ]
	then
		nrn=0
		nvn=`expr $nvn + 1`
	fi
fi

nvs=$nvn.$nrn.$nbn

VERSION=${nvs}
RELEASE=${ymd}
RELOGIO=${tod}

comp=`gcc -v 2>&1 | grep "gcc version" | sed "s/ *$//"`
user=$USER
host=`hostname`

if test -z "$comp"
then
	COMPILE=genericc
else
	COMPILE="$comp"
fi

if test -z "$user"
then
	user=mockuser
fi

if test -z "$host"
then
	host=mockhost
fi

BUILDER="${user}@${host}"

cat > $ie <<EOX
PROGRAM="${PROGRAM}"
VERSION="${VERSION}"
RELEASE="${RELEASE}"
RELOGIO="${RELOGIO}"
SUMMARY="${SUMMARY}"
TAGLIST="${TAGLIST}"
LICENSE="${LICENSE}"
CREATOR="${CREATOR}"
CONTACT="${CONTACT}"
BUILDER="${BUILDER}"
COMPILE="${COMPILE}"
EOX

cat > $vc <<EOE
const char * ${PROGRAM}_${ps} = "${PROGRAM}" ;
const char * ${PROGRAM}_${vs} = "${VERSION}" ;
const char * ${PROGRAM}_${rs} = "${RELEASE}" ;
const char * ${PROGRAM}_${ts} = "${RELOGIO}" ;
const char * ${PROGRAM}_${ss} = "${SUMMARY}" ;
const char * ${PROGRAM}_${gs} = "${TAGLIST}" ;
const char * ${PROGRAM}_${li} = "${LICENSE}" ;
const char * ${PROGRAM}_${cs} = "${CREATOR}" ;
const char * ${PROGRAM}_${ms} = "${CONTACT}" ;
const char * ${PROGRAM}_${bs} = "${BUILDER}" ;
const char * ${PROGRAM}_${cc} = "${COMPILE}" ;
EOE

echo "$tst $lps current $cvs upgrade $nvs \"$nvi\"" >> $hf
tail -1 $hf

cat > $vh <<EOH
/*
 *	version.h
 */

# ifndef _VERSION_H_

# define _VERSION_H_

extern const char * ${PROGRAM}_${ps} ;
extern const char * ${PROGRAM}_${vs} ;
extern const char * ${PROGRAM}_${rs} ;
extern const char * ${PROGRAM}_${ts} ;
extern const char * ${PROGRAM}_${ss} ;
extern const char * ${PROGRAM}_${gs} ;
extern const char * ${PROGRAM}_${li} ;
extern const char * ${PROGRAM}_${cs} ;
extern const char * ${PROGRAM}_${ms} ;
extern const char * ${PROGRAM}_${bs} ;
extern const char * ${PROGRAM}_${cc} ;

	/*  legacy  */

# define	SWNAME		${PROGRAM}_program_string
# define	SWVERS		${PROGRAM}_version_string
# define	SWDATE		${PROGRAM}_release_string
# define	SWTIME		${PROGRAM}_relogio_string
# define	SWDESC		${PROGRAM}_summary_string
# define	SWTAGS		${PROGRAM}_taglist_string
# define	SWCOPY		${PROGRAM}_license_string
# define	SWAUTH		${PROGRAM}_creator_string
# define	SWMAIL		${PROGRAM}_contact_string
# define	SWBLDR		${PROGRAM}_builder_string
# define	SWCOMP		${PROGRAM}_compile_string

# define	SWFORG		" " /* deprecated */

# endif /* _VERSION_H_ */

/*
 * vi:nu ts=8
 */
EOH

mkdir -p ./src
if test -d ./src
then
	mv $vc ./src
fi

mkdir -p ./include
if test -d ./include
then
	mv $vh ./include
fi

exit 0

# vi:nu ts=8
