test -f $HOME/bsh/lili.sh && . $HOME/bsh/lili.sh
mybase () {
	if test -s $HOME/.myhosts
	then
		hn=`hostname`
		if grep "^${hn}$" $HOME/.myhosts >/dev/null 2>&1
		then
			echo $HOME
		fi
	fi
}
duskn () {
	if [ -z "$1" ]
	then
		dusk * | sort -n
	else
		dusk $@ | sort -n
	fi
}
stp () {
	unset p
	for i in `echo $1 | tr "/" " "`
	do
		p=$p"/"$i
		echo $p
	done
}
lsp () {
	stp $1 | xargs -l ls -ld
}
### if [ -f $HOME/bsh/.lsp ]; then
###	. $HOME/bsh/.lsp
### fi
