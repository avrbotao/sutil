
### 
###           |          _                    |~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                  |    Alexandre Botao    |
###           | \_    /_    \_                |     www.botao.org     |
###           \   \__/  \__   \               |   +55-11-98244-UNIX   |
###            \_    \__/  \_  \              |   +55-11-9933-LINUX   |
###              \_   _/     \ |              |     botao@unix.net    |
###                \_/        \|              |  alexandre@botao.org  |
###                            |              |_______________________|
### 

SWNAME="oxe.sh"
SWVERS="5.2.4"
SWDATE="2020/07/06"
SWDESC="operating system cross-platform health evaluator"
SWTAGS="operating system,status,health,evaluator,analyzer,cross-platform"
SWCOPY="GPLv3"
SWAUTH="alexandre@botao.org"

### 
### 
###          /\           _____________________________________________________
###         /  \         |                                                     |
###        / OO \        |   oxe.sh                operational exam evidence   |
###        \ \/ /        |   (c) 2012-2020             alexandre v. r. botao   |
###         \  /         |_____________________________________________________|
###          \/
### 
### 

MESH=`basename $0`
ME=`basename $MESH .sh`

CTO=3
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=$CTO -o PasswordAuthentication=no"

OXEUSER=username

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code is part of 'oxe.sh' by <botao.org>                        |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

oxe () {
	cat <<EOXE
uptime
S=\`uname\`
DF=df
case \$S in
	AIX) K=-k ;;
	HP-UX) B=b ;;
	Linux) free ;;
	SunOS) K=-k ;;
esac
\${B}df \$K / /tmp /var
uname -a
who -b
date
EOXE
### ps -fe | grep pmon | grep -v grep
}

###    _______________________________________________________________________
###   |                                                                       |
###   |_______________________________________________________________________|
###

test $# -lt 1 && set -- "--help"

while test $# -gt 0
do
	i=$1
	shift
	case $i in
		### --) echo got -- ; break ;;

		--help)
			cat <<EOH
use: $ME [ [options] {listfile[.loa]|host [...]} ]
options:
	--help	show this
EOH
			exit 1
		;;

		--*)
			echo "??? lopt ($i)"
			argv="$argv ${i}"
		;;

		-?)
			echo "??? sopt ($i)"
			argv="$argv ${i}"
		;;

		-*)
			### set -- $(echo "${i}" | cut -c 2- | sed 's/./-& /g') "$@"
			set -- `echo "$i" | cut -c 2- | sed 's/./-& /g'` "$@"
			continue
		;;

		*)
			### echo "=== argc ($#)"
			if [ -f ${i}.loa ]
			then
				if [ -s ${i}.loa ]
				then
					echo "... list (${i}.loa)"
					set -- `cat ${i}.loa` "$@"
				else
					echo ">>> empty (${i}.loa)"
				fi
			elif [ -d $i ]
			then
				echo "=== dir ($i)"
				argv="$argv ${i}/"
			else
				echo
				echo "=== ($i)" ### $ME
				echo
				argv="$argv ${i}"
				if grep -i "^${i}$" newest-ssh.list >/dev/null
				then
					ULBS=/usr/local/bin/
				else
					ULBS=/usr/bin/
				fi
				oxe | ${ULBS}ssh $SSHOPT $i sh
			fi
		;;
	esac
done

### echo "... args ($@)"
### echo "... argv ($argv)"

echo

# vi:nu ts=8
