
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 


SWNAME="oxe.sh"
SWVERS="5.2.6"
SWDATE="2022/02/05"
SWTIME="00:00:00"
SWDESC="operating system cross-platform health exam"
SWTAGS="operating system,status,health,evaluate,check,analyze,unix,linux,cross-platform"
SWCOPY="BSD2Clause"
SWAUTH="alexandre botao"
SWMAIL="alexandre at botao dot org"


##  __________________________________________________________________________
## |                                                                          |
## |  The source code in this file is part of the "sutil" software project    |
## |  as developed and released by alexandre botao <from botao dot org> ,     |
## |  available for download from the following public repositories:          |
## |  https://sourceforge.net/u/avrbotao/                                     |
## |  https://bitbucket.org/alexandrebotao/                                   |
## |  https://gitlab.com/alexandre.botao/                                     |
## |  https://github.com/avrbotao/                                            |
## |__________________________________________________________________________|
## |                                                                          |
## |  This software is free and open-source: you can use it under the terms   |
## |  of the "2-Clause BSD License" or as stated in the file "sutil-LICENSE"  |
## |  provided with this distribution.                                        |
## |  This software is distributed in hopes of being useful, but WITHOUT ANY  |
## |  EXPRESS OR IMPLIED WARRANTIES as detailed in the aforementioned files.  |
## |__________________________________________________________________________|
##


MESH=`basename $0`
ME=`basename $MESH .sh`

#______________________________________________________________________________
#

fecho () {
	flg=$1
	shift
	$flg && echo $*
}

decho () {
	fecho $debugflag $*
}

techo () {
	fecho $traceflag $*
}

#______________________________________________________________________________
#

SWPATH=$0
SWPROJ="sutil"
SWBASE=`dirname $0`
SWFILE=`basename $0`
SWNICK=`basename $SWFILE .sh`

debugflag=false
verboseflag=false
traceflag=false

suffixflag=false

#______________________________________________________________________________
#

showhelp () {
			cat <<EOHELP
use: $SWPATH [ [options] {arg [...]} ]
options:
	-b				basic (-fum) 
	-f				filesystems
	-l				run locally
	-m				memory
	-u				uptime
	--help			show this and exit
-L	--license		show [verbose] license and exit
	--suffix=ext	'.extension' for list files
-v	--verbose		verbose output
-V	--version		show version and exit
EOHELP
	exit 1
}

#______________________________________________________________________________
#

showlicense () {
		cat <<EOCOP

Copyright (c) 2022 Alexandre Botao. All rights reserved.

EOCOP
	if $verboseflag
	then
		LICFIL=${SWBASE}/${SWPROJ}-LICENSE
		if test -s $LICFIL
		then
			cat $LICFIL
		else
			echo ">>> license file ($LICFIL) not found."
		fi
	else
		cat <<EOLIC
(Simplified BSD License; see the file ${LICFIL} for details)

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, 
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED "AS IS", AND ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIMS OR DAMAGES ARISING FROM, OUT OF OR
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE OR OTHER DEALINGS IN THIS SOFTWARE.
EOLIC
	fi
	# echo setlicense bsd2clause
	exit 0
}

#______________________________________________________________________________
#

showversion () {
	echo "$SWNAME $SWVERS $SWDATE"
	exit 1
}

#______________________________________________________________________________
#


### 
### 
###          __/\         _____________________________________________________
###         /   /        |                                                     |
###        / OO \        |   oxe.sh                operational exam evidence   |
###        \ \/ /        |   (c) 2012-2022             alexandre v. r. botao   |
###         \  /         |_____________________________________________________|
###          \/
### 
### 

basicflag=false
fsflag=false
localflag=false
memflag=false
uptimeflag=false

#______________________________________________________________________________
#

oxe_init () {
	if test -z "$TMP"
	then
		TMP=/tmp/.oxe.${LOGNAME}.$$.${RANDOM}
		> $TMP
				ULBS=/usr/bin/
				if test -n "$LATESTLIST" -a -f "$LATESTLIST" -a -s "$LATESTLIST"
				then
					if grep -i "^${i}$" $LATESTLIST >/dev/null
					then
						ULBS=/usr/local/bin/
					fi
				fi
	fi
}

oxe_uptime () {
	if test -z "$fupt"
	then
		echo "echo ; uptime" >> $TMP
		fupt=1
	fi
}

oxe_uname () {
	if test -z "$funa"
	then
		cat >> $TMP <<EOX10
S=\`uname\`
EOX10
		funa=1
	fi
}

oxe_fs () {
	if test -z "$fqdf"
	then
		oxe_uname
		cat >> $TMP <<EOX11A
DF=df
case \$S in
	AIX) K=-k ;;
	HP-UX) B=b ;;
	Linux) K=-k ;;
	SunOS) K=-k ;;
esac
EOX11A
	if $basicflag
	then
		cat >> $TMP <<EOX11B
echo
\${B}df \$K / /tmp /var
EOX11B
	else
		cat >> $TMP <<EOX11C
echo
\${B}df \$K 
EOX11C
	fi
		fqdf=1
	fi
}

oxe_mem () {
	if test -z "$fmem"
	then
		oxe_uname
		cat >> $TMP <<EOXM
echo
case \$S in
	AIX) lsattr -El mem0 ; lsps -a ;;
	HP-UX) swapinfo ;;
	Linux) free ;;
	SunOS) prtconf | grep "^Memory size:" ; swap -l ;;
esac
EOXM
		fmem=1
	fi
}

oxe_basic () {
	uptimeflag=true
	memflag=true
	fsflag=true
	if test -z "$fbas"
	then
		cat >> $TMP <<EOXE
echo ; uname -a 
echo ; who -b 
echo ; date 
EOXE
		fbas=1
	fi
}

oxe_default () {
	uptimeflag=true
}

oxe () {
	oxe_init
	oxe_default
	$basicflag && oxe_basic
	$uptimeflag && oxe_uptime
	$memflag && oxe_mem
	$fsflag && oxe_fs
### ps -fe | grep pmon | grep -v grep
}

oxe_local () {
	echo
	echo "=== (`hostname`)" ### $ME
	oxe ; sh < $TMP
}

###    _______________________________________________________________________
###   |                                                                       |
###   |   prologue                                                            |
###   |_______________________________________________________________________|
###

dlm=";"

CTO=3
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=$CTO -o PasswordAuthentication=no"

OXEUSER=username

techo "... SWBASE $SWBASE SWFILE $SWFILE SWNICK $SWNICK"

###    _______________________________________________________________________
###   |                                                                       |
###   |   parsing                                                             |
###   |_______________________________________________________________________|
###

test $# -lt 1 && set -- "--help"

argt=$#
argk=0
argv=" "
args=" "

while test $# -gt 0
do
	i=$1
	shift
	case $i in
		### --) echo got -- ; break ;;

		--help) showhelp ;;

		--license) showlicense ;;

		--debug) debugflag=true ;;

		--trace) traceflag=true ;;

		--verbose) verboseflag=true ;;

		--version) showversion ;;

		--parm)		### longopt parm
			parm=$1
			shift
			argv="${argv}parm=${parm} "
		;;

		--suffix=*)
			suffixflag=true
			ext="`echo ${i} | cut -d '=' -f 2`"
			argv="${argv}`echo ${i} | tr -d '-'` "
		;;

		--*=*)
			echo "??? longoption=value ($i)"
			argv="${argv}`echo ${i} | tr -d '-'` "
		;;

		--*)
			echo "??? long option ($i) invalid"
			argv="${argv}${i} "
		;;

		-p)		### shortopt parm model
			parm=$1
			shift
			argv="${argv}parm=${parm} "
		;;
#______________________________________________________________________________
#
		-b) basicflag=true ;;

		-f) fsflag=true ;;

		-l) localflag=true ;;

		-m) memflag=true ;;

		-u) uptimeflag=true ;;
#______________________________________________________________________________
#
		-L) showlicense ;;

		-v) verboseflag=true ;;

		-V) showversion ;;

		-?)
			## showhelp $SWNICK
			echo "??? short option ($i) invalid"
			argv="${argv}${i} "
		;;

		-*)
			### set -- $(echo "${i}" | cut -c 2- | sed 's/./-& /g') "$@"
			set -- `echo "$i" | cut -c 2- | sed 's/./-& /g'` "$@"
			continue
		;;

		*)
			argn=`expr $argt - $#`
			techo "=== argt ($argt) argn ($argn) argc ($#)"
			if $suffixflag
			then
				if [ -f ${i}.${ext} ]
				then
					if [ -s ${i}.${ext} ]
					then
						if echo ${listlist} | grep "|${i}|" >/dev/null 2>&1
						then
							echo ">>> list recursion detected ($i)"
						else
							echo "... list (${i}.${ext})"
							listlist="|${i}|${listlist}|"
							set -- `cat ${i}.${ext}` "$@"
						fi
					else
						echo ">>> empty (${i}.${ext})"
					fi
				fi
			fi
			if [ -f $i ]
			then
				techo "=== fil ($i)"
				argv="${argv}${i} "
				args="$args${i} "
				oxe ; ${ULBS}ssh $SSHOPT $i sh < $TMP
			elif [ -d $i ]
			then
				techo "=== dir ($i)"
				argv="${argv}${i}/ "
				args="$args${i} "
				oxe ; ${ULBS}ssh $SSHOPT $i sh < $TMP
			else
				techo "=== arg ($i)"
				argv="${argv}${i} "
				args="$args${i} "
				echo
				echo "=== ($i)"
				oxe ; ${ULBS}ssh $SSHOPT $i sh < $TMP
				argk=`expr $argk + 1`
			fi
		;;
	esac
done


###    _______________________________________________________________________
###   |                                                                       |
###   |   drudgery                                                            |
###   |_______________________________________________________________________|
###

techo "... argc ($#)"
techo "... argt ($argt)"
techo "... argn ($argn)"
techo "... argk ($argk)"
techo "... argv ($argv)"
techo "... args ($args)"
techo "... rest ($@)"

test "$argk" -eq 0 && localflag=true

if $localflag
then
	oxe_local
fi

test \( "$argk" -gt 0 -o $localflag \) && echo

###    _______________________________________________________________________
###   |                                                                       |
###   |   epilogue                                                            |
###   |_______________________________________________________________________|
###

test -n "$TMP" -a -f "$TMP" && rm -f $TMP

#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#        1         2         3         4         5         6         7         8

# vi:nu ts=4
