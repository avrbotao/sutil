RMLIST="*.log *.o ./autom4te.cache ./config.h "
set -x
autoclean.sh
autoprep.sh
./configure
if test $? -eq 0
then
	rm -frv ${RMLIST}
	make dist
fi
