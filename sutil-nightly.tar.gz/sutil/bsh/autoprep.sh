#
#	autoprep : fill autostuff
#

INEN=info.env
FOEN=foss.env
CFSC=configure.scan
CFAC=configure.ac
PMAM=Makefile.am

GPLDIRS="src lib doc man scripts tests examples"

# mkdir -p $GPLDIRS

if test -s $INEN
then
	echo found $INEN
	. ./$INEN
elif test -s $FOEN
then
	echo found $FOEN
	. ./$FOEN
else
	echo missing $INEN
	exit 1
fi

# autoclean
sh `dirname $0`/autoclean.sh

#_______________________________________________________________
#

for t in  AUTHORS  ChangeLog  COPYING  DISCLAIMER  INSTALL  LICENSE  NEWS  README  THANKS  TODO
do
	if test -s $t
	then
		echo "=== found ($t)"
	else
		if test -s ../templ8/$t
		then
			echo "... templ8 ($t)"
			echo cp -p ../templ8/$t .
		else
			echo "___ create ($t)"
			echo touch $t
		fi
	fi
done

#_______________________________________________________________
#

echo "# automake"
test -e $PMAM || cat > $PMAM <<EOP

AUTOMAKE_OPTIONS = subdir-objects
bin_PROGRAMS = bin/${PROGRAM}
bin_${PROGRAM}_SOURCES = src/${PROGRAM}.c src/version.c
bin_${PROGRAM}_CFLAGS = -I ./include -std=c99 -Wall -Wextra -Wundef -Wunused -Wshadow -Wcast-align -Wstrict-prototypes
TESTS = tests/basic.sh
EXTRA_DIST = tests 
noinst_HEADERS = include/${PROGRAM}.h include/version.h
dist_man_MANS = man/${PROGRAM}.1

EOP

echo "# autoscan"
autoscan

if test -s $CFSC
then
	cp $CFSC $CFAC
else
	echo missing $CFSC
	exit 1
fi

echo "# autoinfo"
ed $CFAC <<EOE
/^AC_INIT(/c
AC_INIT(${PROGRAM}, ${VERSION}, ${CONTACT})
AC_MSG_NOTICE([${PROGRAM} ${VERSION} ${CONTACT}])
AM_INIT_AUTOMAKE([subdir-objects])
AC_CANONICAL_HOST
OE_CFLAGS=""
AS_CASE([\$build_os],
        [aix*],
        [
           OE_CFLAGS="\$OE_CFLAGS -DAIX"
        ],
        [hpux*],
        [
           OE_CFLAGS="\$OE_CFLAGS -DHPUX"
        ],
        [linux*],
        [
           OE_CFLAGS="\$OE_CFLAGS -DLINUX"
        ],
        [cygwin*],
        [
           OE_CFLAGS="\$OE_CFLAGS -DCYGWIN"
	],
        [darwin*],
        [
           OE_CFLAGS="\$OE_CFLAGS -DOSX"
	],
        [mingw*],
        [
           OE_CFLAGS="\$OE_CFLAGS -DMINGW"
	],
        [solaris*],
        [
           OE_CFLAGS="\$OE_CFLAGS -DSOLARIS"
        ],
	[*],
	[
		AC_MSG_ERROR(["OS \$build_os not supported"])
        ])
AS_CASE([\$build_cpu],
	[hppa*],
	[
		OE_CFLAGS="\$OE_CFLAGS -DHPPA"
	],
	[ia64],
	[
		OE_CFLAGS="\$OE_CFLAGS -DIA64"
	],
	[i?86],
	[
		OE_CFLAGS="\$OE_CFLAGS -DIX86"
	],
	[powerpc],
	[
		OE_CFLAGS="\$OE_CFLAGS -DPOWERPC"
	],
	[sparc],
	[
		OE_CFLAGS="\$OE_CFLAGS -DSPARC"
	],
	[x86_64],
	[
		OE_CFLAGS="\$OE_CFLAGS -DAMD64"
	],
	[*],
	[
		AC_MSG_ERROR(["CPU \$build_cpu not supported"])
	])
AC_SUBST([OE_CFLAGS])
.
/^# Checks for libraries/a
AC_CHECK_LIB(crypt,crypt,[LIBS="\$LIBS -lcrypt"])
.
/^# Checks for programs/a
AC_PROG_RANLIB
.
w
q
EOE

###	AC_CHECK_LIB ( LIBRARY, FUNCTION [, ACTION-IF-FOUND [, ACTION-IF-NOT-FOUND [, OTHER-LIBRARIES ] ] ] )

###    TEST_AND_SET_CFLAG(-Wall)
###    TEST_AND_SET_CFLAG(-Wextra)
###    TEST_AND_SET_CFLAG(-Wunused)
###    TEST_AND_SET_CFLAG(-Wpedantic)

ls -l $CFSC $CFAC
diff $CFSC $CFAC

# libtoolize --force
# aclocal
# autoheader
# autoconf
# automake --force-missing --add-missing
# ./configure
# make distcheck

echo "# autoreconf"
autoreconf -vfi

# vi:nu ts=8
