
#	quick	jail

techo () {
	if $traceflag
	then
		echo $*
	fi
}

if test $# -eq 0
then
	cat <<EOH
use: $0 hostname jailtype jailgroup jailroot username [privuser]
EOH
	exit 1
fi

jhost=$1
jtype=$2
jgrup=$3
jroot=$4
juser=$5
jpriv=$6

test `echo $jhost $jtype $jgrup $jroot $juser | wc -w` -ne 5 && echo ">>> missing parm(s)" && exit 1

if test -n "$jpriv"
then
	jcred="$jpriv@$jhost"
else
	jcred=$jhost
fi

traceflag=true

# techo jhost jtype jgrup jroot juser jcred

ssh -o connecttimeout=2 $jcred sudo sh <<EOS
$traceflag && echo $jhost $jtype $jgrup $jroot $juser $jcred
test "uid=0(root)" != \`id | cut -d ' ' -f 1\` && echo ">>> no priv" && exit 1
$traceflag && uname -a
type ed && ED=ed
type ex && ED=ex
if test $jtype = sftp
then
	$traceflag && echo $jtype jail
	if grep "^${jgrup}:" /etc/group >/dev/null 2>&1
	then
		$traceflag && echo found $jgrup
	else
		$traceflag && echo create $jgrup
		groupadd $jgrup
	fi
	if grep "^${juser}:" /etc/passwd >/dev/null 2>&1
	then
		$traceflag && echo enjail $juser
		usermod -a -G $jgrup $juser
	else
		$traceflag && echo create $juser
		useradd -g $jgrup -s /sbin/nologin $juser
		echo "$juser:abcd1234" | chpasswd
	fi
	$traceflag && echo backup cfg
	mkdir -p /root/backup
	cp -p /etc/ssh/sshd_config /root/backup/\`date +%s\`.sshd_config
	$traceflag && echo edit cfg
	\$ED /etc/ssh/sshd_config <<EOE
g/^Subsystem.*sftp/s/^/### /
a
Subsystem sftp internal-sftp
.
w
EOE
	cat >> /etc/ssh/sshd_config <<EOC

Match Group $jgrup
	ChrootDirectory $jroot
	ForceCommand internal-sftp
	X11Forwarding no
	AllowTcpForwarding no
EOC
	$traceflag && echo restart
	service sshd restart
elif test $jtype = ssh
then
	$traceflag && echo $jtype jail
else
	$traceflag && echo wrong type
fi
EOS

# vi:nu ts=4
