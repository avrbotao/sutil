#	gret.sh		tree	grep		#
#_______________________________________________#
s="$1"
shift
find $* -type f -exec grep -il "$s" {} \;
# vi:nu ts=8
