ps -eo nlwp | tail -n +2 | awk '{ num_threads += $1 } END { print num_threads }'
