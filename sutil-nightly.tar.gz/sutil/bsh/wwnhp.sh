# Joel Mizerkowski - 08/08/12
# lista hbas do servidor HP
ls /dev/td* > /tmp/lst.hba
ls /dev/fc* >> /tmp/lst.hba
echo "Drv          WWN                   Speed    State      HWPath"
echo "-------------------------------------------------------------------"
for i in $(cat /tmp/lst.hba)
do
wwn=`fcmsutil $i |grep "N_Port Port World Wide Name" |cut -f 2 -d =`
spe=`fcmsutil $i |grep "Link Speed" |cut -f 2 -d =`
sta=`fcmsutil $i |grep "Driver state" |cut -f 2 -d =`
hwp=`fcmsutil $i |grep "Hardware Path is" |cut -f 2 -d =`
hba=`echo $i`
echo "$hba;$wwn;$spe;$sta;$hwp" | tr -d " "
done
echo "-------------------------------------------------------------------"
echo "\n\n"
