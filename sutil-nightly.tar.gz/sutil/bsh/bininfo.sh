
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as released by alexandre botao <alexandre at botao dot org>         |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

binz () {
	HN=$1
	cat <<EOI
		case \`uname\` in
			Linux)
				find $BL -type f -ls > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			AIX)
				find $BL -type f -ls > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			SunOS)
				find $BL -type f -ls > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			HP-UX)
				if test `uname -r` = B.11.31
				then
					find $BL -type f -ls > /tmp/.x.o 2> /tmp/.x.e
				else
					find $BL -type f -exec ls -lis {} \; > /tmp/.x.o 2> /tmp/.x.e
				fi
				zero=\$?
			;;
			*) echo "${HN};O.S. (\`uname\`) unprepared" ; exit 1 ;;
		esac
		if test "\$zero" -eq 0
		then
			cat /tmp/.x.o | sed "s/^/${HN};/"
			rm -f /tmp/.x.o /tmp/.x.e
		else
			if test -s /tmp/.x.o
			then
				cat /tmp/.x.o | sed "s/^/${HN};/"
				rm -f /tmp/.x.o /tmp/.x.e
			else
				echo "${HN};n/a" ; exit 1
			fi
		fi
EOI
}
BL="/*bin /usr/*bin /usr/*/*bin /etc /*lib* /usr/*lib*"
if test $# -eq 0
then
	HN=`hostname | cut -d '.' -f 1`
	binz $HN | sh
else
	for HN in $*
	do
		binz $HN | ssh $SSHOPT $HN "sh"
	done
fi
# vi:nu ts=4
