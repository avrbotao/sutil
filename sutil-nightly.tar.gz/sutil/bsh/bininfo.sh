### find /bin /sbin /lib* /usr/bin /usr/sbin /usr/lib* /usr/local/bin /usr/local/sbin /usr/local/lib* -exec ls -ld {} \;
find /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin -exec ls -ld {} \;
