
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

SWNAME="fixresolv.sh"
SWVERS="1.0.3"
SWDATE="2021/07/01"
SWDESC="renew nameservers on resolv.conf"
SWTAGS="script,foss,resolv,conf,dns,nameserver"
SWCOPY="GPLv3"
SWAUTH="alexandre at botao dot org"

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code is part of "fixish" by <alexandre at botao dot org>        |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

THISPATH=$0

THISFILE=`basename $0`
THISNAME=`basename $THISFILE .sh`

#THISUSER=username

### 
### 
###         /\          _____________________________________________________
###        /  \        |                                                     |
###       / OO \       |   fixresolv.sh                 update resolv.conf   |
###       \ \/ /       |   (c) [2020-]2021           alexandre v. r. botao   |
###        \  /        |_____________________________________________________|
###         \/
### 
### 

CTO=3
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=$CTO -o PasswordAuthentication=no"

###    _______________________________________________________________________
###   |                                                                       |
###   |   all at once                                       try-edit-valid8   |
###   |_______________________________________________________________________|
###

if test "$1" = "--force"
then
	shift
	FORCE=1
fi
HL=$1
test -z "$HL" && echo ">>> use: $0 <hostlistfile>" && exit 1
test -s $HL || exit 1

RC=/etc/resolv.conf
ML=fixresolv.log
TH=any.domain
TA=1.2.3.4
### S1=9.8.7.6
### S2=9.8.7.6
S1=9.8.7.6
S2=-
### X1=9.8.7.6
### X2=9.8.7.6
X1=9.8.7.6
X2=9.8.7.6
L1=/tmp/namsrv1
L2=/tmp/namsrv2
TMP=/tmp/.fixresolv.tmp.
TMQ=/tmp/.fixresolv.tmq.

> $ML

TT=`cat $HL | wc -l | tr -d " "`
NN=1

for i in `cat $HL`
do
	echo "=== begin `date` ($i) $NN / $TT"
	echo "=== begin `date` ($i) $NN / $TT" >> $ML
TD=/root/${i}-fixresolv.d
RP=$TD/${i}.rep
GL=$TD/${i}.good
BU=$TD/bkp-resolv-conf-orig
NC=$TD/bkp-resolv-conf-novo
	ssh $i sh <<EON
h=\`uname -n | cut -d '.' -f 1\`
echo "=== \$h base"
mkdir -p $TD
test -d $TD || exit 1
> $RP
ls -ld $TD >> $RP
echo "=== \$h backup"
cp -p $RC $BU
cmp $RC $BU || exit 1
cp -p $RC $NC
cmp $RC $NC || exit 1
ls -ld ${TD}/* >> $RP
if test "$FORCE" = "1"
then
	echo "found " > $RP
else
	echo "=== \$h inspect"
	grep "^nameserver" $RC | head -1 > $TMP
	if grep $X1 $TMP
	then
		echo "found $X1 pri" >> $RP
		grep -v "\`cat $TMP\`" $RC | grep "^nameserver" | head -1 > $TMQ
		if grep $X2 $TMQ
		then
			echo "found $X2 sec" >> $RP
		fi
	elif grep $X2 $TMP
	then
		echo "found $X2 pri" >> $RP
		grep -v "\`cat $TMP\`" $RC | grep "^nameserver" | head -1 > $TMQ
		if grep $X1 $TMQ
		then
			echo "found $X1 sec" >> $RP
		fi
	else
		echo "=== \$h skip \`cat $TMP\`" >> $RP
	fi
fi
if grep "^found " $RP
then
	echo "=== \$h select"
	echo "=== \$h select" >> $RP
else
	echo "=== \$h skip"
	exit 0
fi
> $GL
if test "$S2" != "-"
then
	echo "=== \$h try $S2"
	if nslookup $TH $S2 > $TMP 2>&1
	then
		echo "... nslookup"
	else
		echo "--- prep"
		echo "nameserver $S2" > $TMP
		cat $RC >> $TMP
		cat $TMP > $RC
		echo "--- ping"
		ping -c 1 $TH > $TMP 2>&1
		cat $TMP >> $RP
		echo "--- tidy"
		/bin/cp -fp $BU $RC
	fi
	if grep $TA $TMP >> $RP
	then
		echo "good $S2" >> $RP
		echo $S2 >> $GL
		echo "=== \$h set $S2"
		j=0
		while read lin
		do
			case \$lin in
				nameserver*)
					if test \$j -eq 0
					then
						j=1
						echo "nameserver $S2"
						echo "\$lin"
					else
						echo "\$lin"
					fi
				;;
				*) echo "\$lin" ;;
			esac
		done < $NC > $TMP
		cat $TMP > $NC
	fi
fi
echo "=== \$h try $S1"
if nslookup $TH $S1 > $TMP 2>&1
then
	echo "... nslookup"
else
	echo "--- prep"
	echo "nameserver $S1" > $TMP
	cat $RC >> $TMP
	cat $TMP > $RC
	echo "--- ping"
	ping -c 1 $TH > $TMP 2>&1
	cat $TMP >> $RP
	echo "--- tidy"
	/bin/cp -fp $BU $RC
fi
if grep $TA $TMP >> $RP
then
	echo "good $S1" >> $RP
	echo $S1 >> $GL
	echo "=== \$h set $S1"
	j=0
	while read lin
	do
		case \$lin in
			nameserver*)
				if test \$j -eq 0
				then
					j=1
					echo "nameserver $S1"
					echo "\$lin"
				else
					echo "\$lin"
				fi
			;;
			*) echo "\$lin" ;;
		esac
	done < $NC > $TMP
	cat $TMP > $NC
fi
if test -s $GL
then
	echo "=== \$h chk $X2"
	if grep "$X2" $NC
	then
		echo "=== \$h off $X2"
		cat $NC | sed "/$X2/s/^/###/" > $TMP
		cat $TMP > $NC
	fi
	echo "=== \$h chk $X1"
	if grep "$X1" $NC
	then
		echo "=== \$h off $X1"
		cat $NC | sed "/$X1/s/^/###/" > $TMP
		cat $TMP > $NC
	fi
	echo "=== \$h apply"
	cat $NC > $RC
	echo "=== \$h check"
	echo "=== \$h check" >> $RP
	bad=0
	while read lin
	do
		if nslookup $TH \$lin > $TMP 2>&1
		then
			echo "... nslookup"
		else
			echo "--- ping"
			ping -c 1 $TH > $TMP 2>&1
			cat $TMP >> $RP
		fi
		if grep $TA $TMP >> $RP
		then
			echo "=== \$h valid \$lin"
		else
			echo ">>> \$h error \$lin"
			echo ">>> \$h error \$lin" >> $RP
			bad=1
		fi
	done < $GL
	if test \$bad -ne 0
	then
		echo "=== \$h abort"
		/bin/cp -fp $BU $RC
	fi
else
	echo ">>> \$h fail" >> $RP
	exit 1
fi
EON
	echo "=== bring `date` ($i)"
	scp -qrp $i:${TD} .
	echo "=== e_n_d `date` ($i)"
	NN=`expr $NN + 1`
done

#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#        1         2         3         4         5         6         7         8
# vi:nu
