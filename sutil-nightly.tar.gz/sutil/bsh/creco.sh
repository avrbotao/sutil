#_______________________________________________________________________________
#
#	  ####   #####   ######   ####    ####
#	 #    #  #    #  #       #    #  #    #
#	 #       #    #  #####   #       #    #
#	 #       #####   #       #       #    #
#	 #    #  #   #   #       #    #  #    #
#	  ####   #    #  ######   ####    ####
#_______________________________________________________________________________
#
# creco : Cria RElacao de COnfianca				botao 2013-2019
#_______________________________________________________________________________
#

VER=1.0.28
REL=2020-03-31

BAN="	creco	${VER}	${REL}	bud"

tmpdat=.creco.dat
tmperr=.creco.err
tmptmp=.creco.tmp
tmplog=.creco.log
sshopt="-o PreferredAuthentications=publickey -o connecttimeout=5 -o PasswordAuthentication=no"

tos=`uname`

#_______________________________________________________________________________
#

crecoff () {
	while true
	do
		echo "view log ?"
		read resp
		case $resp in
			[sSyY]*)	cat -n $tmplog ;	break	;;
			[nN]*)		echo okay ;		break	;;
			*)		echo wrong answer		;;
		esac
	done
	exit
}

#_______________________________________________________________________________
#

erro () {
	case $1 in
		 0) mess="$0 : no data file"		;;
		 1) mess="$0 : empty data file"		;;
		 2) mess="$0 : missing data"		;;
		 3) mess="$0 : host ($2) unknown"	;;
		 4) mess="$0 : ping ($2) failed"	;;
		 5) mess="$0 : ssh ($2) failed"		;;
		 6) mess="$0 : user ($2) unknown"	;;
		 7) mess="$0 : home ($2) mismatch"	;;
		 8) mess="$0 : missing ($2) key"	;;
		 9) mess="$0 : o.s. ($2) unknown"	;;
		10) mess="$0 : progress forestalled"	;;
		 *) mess="$0 : weird"			;;
	esac
	echo $mess 
	echo $mess >> $tmplog
	### crecoff
	### test -s $tmplog && cat -n $tmplog
}

#_______________________________________________________________________________
#

xping () {
	h=$1
	case $tos in
		AIX) ping -c 1 -w 1 $h ;;
		Linux) ping -c 1 $h ;;
		HP-UX) ping $h -n 1 -m 1 ;;
		SunOS) ping -s $h 64 1 ;;
		*) erro 9 $tos ;;
	esac
}

#_______________________________________________________________________________
#

creco () {

	orighalf=$1
	desthalf=$2

	if test "$fixflag" = "yes"
	then
		echo "+ opts (fix)=($fixflag)"
	fi

	#_______________________________________________________________________
	# parse data "alice@wonder,bob@geldof"

	origuser=`echo $orighalf | cut -d '@' -f 1`
	orighost=`echo $orighalf | cut -d '@' -f 2`
	destuser=`echo $desthalf | cut -d '@' -f 1`
	desthost=`echo $desthalf | cut -d '@' -f 2`

	echo "+ orig ($origuser)@($orighost)"
	echo "+ dest ($destuser)@($desthost)"

	#_______________________________________________________________________
	# check data

	if [ "$origuser" = "" -o "$orighost" = "" -o "$destuser" = "" -o "$desthost" = "" ]
	then
		erro 2
	fi

	#_______________________________________________________________________
	# check hosts

	if host $orighost > $tmptmp 2>&1
	then
		origaddr=`cut -d ' ' -f 4 < $tmptmp`
	else
		origaddr=`getent hosts $orighost | awk '{print $1}'`
		test $? -eq 0 || erro 3 $orighost
	fi

	if host $desthost > $tmptmp 2>&1
	then
		destaddr=`cut -d ' ' -f 4 < $tmptmp`
	else
		destaddr=`getent hosts $desthost | awk '{print $1}'`
		test $? -eq 0 || erro 3 $desthost
	fi

	echo "+ orig addr=($origaddr)"
	echo "+ dest addr=($destaddr)"

	#_______________________________________________________________________
	# check connectivity

	if xping $origaddr > /dev/null 2>&1
	then
		origping=1
	else
		erro 4 $origaddr
	fi

	if xping $destaddr > /dev/null 2>&1
	then
		destping=1
	else
		erro 4 $destaddr
	fi

	#_______________________________________________________________________
	# check control

	ssh $sshopt $orighost uname > $tmptmp 2> $tmperr

	if [ -s $tmptmp ]
	then
		origos=`cat $tmptmp`
	else
		erro 5 $orighost
	fi

	ssh $sshopt $desthost uname > $tmptmp 2> $tmperr

	if [ -s $tmptmp ]
	then
		destos=`cat $tmptmp`
	else
		erro 5 $desthost
	fi

	echo "+ orig os=($origos)"
	echo "+ dest os=($destos)"

	#_______________________________________________________________________
	# check users

	ssh $sshopt $orighost "id $origuser" > $tmptmp 2> $tmperr

	origgid=`tr " " "\n" < $tmptmp | grep "gid=" | cut -d '(' -f 2 | cut -d ')' -f 1`

	if [ "$origgid" = "" ]
	then
		erro 6 $origuser
	fi

	echo "+ orig id=($origuser/$origgid)"

	ssh $sshopt $desthost "id $destuser" > $tmptmp 2> $tmperr

	destgid=`tr " " "\n" < $tmptmp | grep "gid=" | cut -d '(' -f 2 | cut -d ')' -f 1`

	if [ "$destgid" = "" ]
	then
		erro 6 $destuser
	fi

	echo "+ dest id=($destuser/$destgid)"

	#_______________________________________________________________________
	# check locks 

		# FIXME: is user locked ?

	#_______________________________________________________________________
	# check homes

	ssh $sshopt $orighost "ls -ld ~$origuser" > $tmptmp 2> $tmperr

	origperms=`awk '{print $1}' < $tmptmp`
	origowner=`awk '{print $3}' < $tmptmp`
	origgroup=`awk '{print $4}' < $tmptmp`

	if [ "$origowner" = "$origuser" -a "$origgroup" = "$origgid" ]
	then
		echo "+ orig home=($origowner/$origgroup)"
	else
		erro 7 "orig $origuser/$origgid # $origowner/$origgroup"
		erro 7 "orig $origuser/$origgid # $origowner/$origgroup"
		if test "$fixflag" = "yes"
		then
			echo "+ fix orig home ownership ($origowner/$origgroup to $origuser/$origgid)"
			ssh $sshopt $orighost "chown $origuser:$origgid ~$origuser ; chown -R $origuser:$origgid ~$origuser/.ssh"
		else
			erro 10 ; exit 1
		fi
	fi

	ssh $sshopt $desthost "ls -ld ~$destuser" > $tmptmp 2> $tmperr

	destperms=`awk '{print $1}' < $tmptmp`
	destowner=`awk '{print $3}' < $tmptmp`
	destgroup=`awk '{print $4}' < $tmptmp`

	if [ "$destowner" = "$destuser" -a "$destgroup" = "$destgid" ]
	then
		echo "+ dest home=($destowner/$destgroup)"
	else
		erro 7 "dest $destuser/$destgid # $destowner/$destgroup"
		if test "$fixflag" = "yes"
		then
			echo "+ fix dest home ownership ($destowner/$destgroup to $destuser/$destgid)"
			ssh $sshopt $desthost "chown $destuser:$destgid ~$destuser ; chown -R $destuser:$destgid ~$destuser/.ssh"
		else
			erro 10 ; exit 1
		fi
	fi

	#_______________________________________________________________________
	# fix modes

	if test "$fixflag" = "yes"
	then
		echo "+ fix orig home mode=($origperms)"
		ssh $sshopt $orighost "chmod go-w ~$origuser"
		echo "+ fix dest home mode=($destperms)"
		ssh $sshopt $desthost "chmod go-w ~$destuser"
	fi

	#_______________________________________________________________________
	# check / create .ssh

	echo "+ check orig .ssh"

	ssh $sshopt $orighost "ls -ld ~$origuser/.ssh" > $tmptmp 2> $tmperr

	if [ -s $tmperr ]
	then
		echo "+ create orig .ssh"
		ssh $sshopt $orighost "mkdir -p ~$origuser/.ssh && chmod 700 ~$origuser/.ssh && chown $origowner:$origgroup ~$origuser/.ssh" > $tmptmp 2> $tmperr
	else
		echo "+ found orig (`cat $tmptmp`)"
		ssh $sshopt $orighost "chown -R $origuser:$origgid ~$origuser/.ssh"
		echo "+ fixed orig (`cat $tmptmp`)"
	fi

	echo "+ check dest .ssh"

	ssh $sshopt $desthost "ls -ld ~$destuser/.ssh" > $tmptmp 2> $tmperr

	if [ -s $tmperr ]
	then
		echo "+ create dest .ssh"
		ssh $sshopt $desthost "mkdir -p ~$destuser/.ssh && chmod 700 ~$destuser/.ssh && chown $destowner:$destgroup ~$destuser/.ssh" > $tmptmp 2> $tmperr
	else
		echo "+ found dest (`cat $tmptmp`)"
		ssh $sshopt $desthost "chown -R $destuser:$destgid ~$destuser/.ssh"
		echo "+ fixed dest (`cat $tmptmp`)"
	fi

	#_______________________________________________________________________
	# check / create .ssh/authorized_keys

	echo "+ check dest keys"

	ssh $sshopt $desthost "ls -l ~$destuser/.ssh/authorized_keys" > $tmptmp 2> $tmperr

	if [ -s $tmperr ]
	then
		echo "+ fix (create) dest (.ssh/authorized_keys)"
		ssh $sshopt $desthost "touch ~$destuser/.ssh/authorized_keys && chmod 600 ~$destuser/.ssh/authorized_keys && chown $destowner:$destgroup ~$destuser/.ssh/authorized_keys" > $tmptmp 2> $tmperr
	else
		echo "+ found dest keys (`cat $tmptmp`)"
	fi

	#_______________________________________________________________________
	# check existent orig key on dest

	#_______________________________________________________________________
	# check / make key

	echo "+ check orig keys"

	ssh $sshopt $orighost "ls -l ~$origuser/.ssh/id_rsa.pub" > $tmptmp 2> $tmperr

	if [ -s $tmperr ]
	then
		if test "$fixflag" = "yes"
		then
			echo "+ fix (create) orig (.ssh/id_rsa)"
			ssh $sshopt $orighost "su - $origuser -c \"ssh-keygen -t rsa -N '' -f .ssh/id_rsa\"" > $tmptmp 2> $tmperr
		else
			erro 8 $origuser
		fi
	else
		echo "+ found orig keys (`cat $tmptmp`)"
	fi

	#_______________________________________________________________________
	# copy / add key

	echo "+ copy/add orig keys"

	ssh $sshopt $orighost "cat ~$origuser/.ssh/id_rsa.pub" > $tmptmp 2> $tmperr

	if [ -s $tmperr ]
	then
		cat -n $tmperr
	else
		echo "+ read good"
	fi

	scp -q $sshopt $tmptmp $desthost:/tmp/$tmptmp

	if [ -s $tmperr ]
	then
		cat -n $tmperr
	else
		echo "+ send good"
	fi

	ssh $sshopt $desthost "cat /tmp/$tmptmp >> ~$destuser/.ssh/authorized_keys ; rm -f /tmp/$tmptmp" > $tmptmp 2> $tmperr

	if [ -s $tmperr ]
	then
		cat -n $tmperr
	else
		echo "+ write good"
	fi

	#_______________________________________________________________________
	# bye

	echo "+ bye"
}

#_______________________________________________________________________________
#
#	main
#_______________________________________________________________________________
#

> $tmpdat
> $tmperr
> $tmptmp
> $tmplog

echo
echo $BAN
echo

if [ "$3" = "--fix" ]
then
	fixflag=yes
fi

if [ "$1" = "" -o "$2" = "" ]
then
	cat <<EOH
  ####   #####   ######   ####    ####
 #    #  #    #  #       #    #  #    #
 #       #    #  #####   #       #    #
 #       #####   #       #       #    #
 #    #  #   #   #       #    #  #    #
  ####   #    #  ######   ####    ####

	use : $0 origuser@orighost destuser@desthost [--fix]

EOH
	exit 1
else
	creco $1 $2
fi

### crecoff
test -s $tmplog && cat -n $tmplog

#_______________________________________________________________________________
#

#
# vi:nu ts=8
#
