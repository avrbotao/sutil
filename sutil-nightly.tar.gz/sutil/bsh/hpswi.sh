[ -z "$1" ] && exit
set -x
/usr/sbin/swinstall -x autoselect_dependencies=false -x mount_all_filesystems=false -x autoreboot=false -s `pwd`/"$1" \*
# /usr/sbin/swinstall -x autoselect_dependencies=false -x mount_all_filesystems=false -x autoreboot=false -x reinstall=true -s `pwd`/"$1" \*
