T="$1"
test -z "$T" && echo ">>> use: $0 [re] [ month [year] ]" && exit 1
M="$2"
Y="$3"
a=-a
test "`uname`" = HP-UX && a=""
test -d $HOME/hist && L=$HOME/hist
test -d /historico && L=/historico
test -z "$Y" && Y=`date +%Y`
test -n "$L" && grep $a -i "$T" ${L}/*${Y}${M}*
grep $a -i "$T" $HOME/.*tory
# vi: nu
