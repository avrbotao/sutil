cat /proc/sys/kernel/threads-max
