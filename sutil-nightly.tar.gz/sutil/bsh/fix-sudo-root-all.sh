
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

SWNAME="fix-sudo-root-all.sh"
SWVERS="1.0.1"
SWDATE="2021/09/27"
SWDESC="fix sudo all root"
SWTAGS="script,foss,report,sudo,root,all,sudoers,fix,edit,save,undo"
SWCOPY="GPLv3"
SWAUTH="alexandre at botao dot org"

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code is part of "fixish" by <alexandre at botao dot org>        |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

THISPATH=$0

THISFILE=`basename $0`
THISNAME=`basename $THISFILE .sh`

#THISUSER=username

### 
### 
###         /\          _____________________________________________________
###        /  \        |                                                     |
###       / OO \       |   "fix-sudo-root-all.sh"         block priv sudos   |
###       \ \/ /       |   (c) [2020-]2021           alexandre v. r. botao   |
###        \  /        |_____________________________________________________|
###         \/
### 
### 

CTO=3
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=$CTO -o PasswordAuthentication=no"

###    _______________________________________________________________________
###   |                                                                       |
###   |   blah                                                        stuff   |
###   |_______________________________________________________________________|
###

tist () {
	date +%Y.%m.%d.%H.%M.%S
}

logmsg () {
	if test $# -eq 0
	then
		echo >> $LOG
	else
		echo "`tist` $*" >> $LOG
	fi
	test "$VERB" = "1" && echo "$*"
}

logfil () {
	test -z "$1" && return
	if test "$1" = "--"
	then
		cat > $J
		test "$VERB" = "1" && cat $J
		cat $J >> $LOG
	else
		if test -f $1
		then
			if test -s $1
			then
				test "$VERB" = "1" && cat $1
				cat $1 >> $LOG
			else
				logmsg ">>> empty file"
			fi
		else
			logmsg ">>> file ($1) not found"
		fi
	fi
}

thistart () {
	logmsg ${THISNAME} initi8
}

thisquit () {
	test -n "$2" && logmsg $2
	logmsg ${THISNAME} finish
	exit $1
}

###    _______________________________________________________________________
###   |                                                                       |
###   |   main                                               scan and oper8   |
###   |_______________________________________________________________________|
###

thistart

if test $# -eq 0
then
	cat <<EOC
use: $0 [-v] [--peek] [opt] [basedir] [hostlist] [user]
opt:
	-v      verbose
	--scan	search only
	--show	backup files
	--edit	comment entries
	--diff	compare files
	--peek	ascertain changes
	--push	commit changes
	--undo	revert changes
	--wipe	clear backup 
EOC
	thisquit 1 usage
fi
W=help
if test "$1" = "-v"
then
	shift
	VERB=1
	export VERB
fi
if test "$1" = "--scan"
then
	W=$1
	shift
	SCAN=1
fi
if test "$1" = "--show"
then
	W=$1
	shift
	SHOW=1
fi
if test "$1" = "--edit"
then
	W=$1
	shift
	EDIT=1
fi
if test "$1" = "--diff"
then
	W=$1
	shift
	DIFF=1
fi
if test "$1" = "--peek"
then
	shift
	PEEK=1
fi
if test "$1" = "--push"
then
	W=$1
	shift
	PUSH=1
fi
if test "$1" = "--undo"
then
	W=$1
	shift
	UNDO=1
fi
if test "$1" = "--wipe"
then
	W=$1
	shift
	WIPE=1
fi
D=$1
L=$2
U=$3
T=/tmp/.psra.
M=/tmp/.fsra.
N=/tmp/.nsra.
Q=/tmp/.qsra.
J=/tmp/.jsra.
B=${D}/undo.d
Z=${D}/logs.d
W=`echo $W | tr -d "-"`
NOLB="##_NO_##"
POUT=/tmp/.osra.
LOG=${Z}/${THISNAME}.${W}.`tist`.log
export LOG

thistart

test "$W" = "help" && thisquit 1 ">>> missing action"
test -z "$D" && thisquit 1 ">>> missing basedir"
test -d "$D" || thisquit 1 ">>> not a dir ($D)"
test -z "$L" && thisquit 1 ">>> missing hostlist"
test -s "$L" || thisquit 1 ">>> empty hostlist ($L)"
cat $L > $M
cd $D
test -d $B || mkdir $B
test -d $Z || mkdir $Z
logmsg "what($W) base($D) list($L) user($U)"
logmsg
if test "${SHOW}" = "1"
then
	logmsg show
	if test -f ${B}/*
	then
		ls -l ${B} | logfil --
	else
		logmsg ">>> nothing saved"
	fi
	thisquit
fi
if test -z "$OPTDIRSUFFIX"
then
	logmsg ">>> \$OPTDIRSUFFIX not exported (to disregard, export OPTDIRSUFFIX=n)"
	thisquit 1 "warn: must export \$OPTDIRSUFFIX" 
fi
for i in `cat $M`
do
	ddd=${i}
	test "${OPTDIRSUFFIX}" != "n" && ddd=${i}${OPTDIRSUFFIX}
	if test -d "${ddd}"
	then
		find $ddd -type f | grep sudoers | while read lin
		do
			fil=`basename $lin`
			pfx="${i};${lin}"
			grep "NOPASSWD:[ 	]*ALL" $lin | tr "\t" " " | egrep -v -e "^#|^root |^Defaults |LC_ALL" > $T
			bkp=`echo $lin | tr "/" "_"`
			ckp=${B}/${bkp}
				if test "${UNDO}" = "1"
				then
					if test -s $ckp
					then
						logmsg "=== undo ($lin)"
						/bin/cp -p $ckp $lin
						/bin/ls -l $lin $ckp | logfil --
						logmsg "=== diff ($lin)"
						diff $lin $ckp | logfil --
						logmsg 
						continue
					fi
				elif test "${DIFF}" = "1"
				then
					if test -s $ckp
					then
						logmsg "=== diff ($lin)"
						diff $lin $ckp | logfil --
						/bin/ls -l $lin $ckp | logfil --
						logmsg 
						continue
					fi
				elif test "${PUSH}" = "1"
				then
					if test -s $ckp
					then
						logmsg "=== push ($lin)"
						logmsg "=== back ($ckp)"
						SUDOPATH=" opt/iexpress/sudo/etc/sudoers.d opt/iexpress/sudo/etc etc/local/etc/sudoers.d etc/local/etc usr/local/etc etc/sudoers.d etc "
						for sp in `echo $SUDOPATH`
						do
							try=${sp}/${fil}
							find $ddd -type f -ls | grep "${try}$" > $Q
							if test -s $Q
							then
								logfil $Q
								if test "${PEEK}" = "1"
								then
									logmsg "=== peek ($try)"
									test -n "$U" && grep "$U[ 	]" $lin | logfil --
									ssh $SSHOPT $i "uname -a ; ls -ld /${try} && egrep -e \"^$U[ 	]|^#.*$U[ 	]\" /${try}" > $POUT 2>&1
								else
									logmsg "=== fire ($try)"
									scp $SSHOPT $lin ${i}:/${try} > $POUT 2>&1
								fi
								if test $? -eq 0
								then
									logmsg peek worked
								else
									logmsg peek failed
								fi
								logfil $POUT
								break
							fi
						done
						logmsg 
						continue
					fi
				elif test "${WIPE}" = "1"
				then
					if test -s $ckp
					then
						logmsg "=== wipe ($ckp)"
						/bin/rm -f $ckp
						continue
					fi
				fi
			if test -s $T
			then
				if test -n "${U}"
				then
					grep "^${U} " $T > $N
					if test -s $N
					then
						cat $N > $T
					else
						continue
					fi
				fi
				if test "${SCAN}" = "1"
				then
					cat $T | sed "s,^,${pfx};," | logfil --
				elif test "${EDIT}" = "1"
				then
					logmsg "=== save ($lin)"
					/bin/cp -p $lin $ckp
					/bin/ls -l $lin $ckp | logfil --
					logmsg "=== edit ($lin)"
					if test -w $lin
					then
						WOK=1
					else
						WOK=0
						chmod +w $lin
					fi
					/bin/ls -l $lin $ckp | logfil --
					ed $lin <<EOE
g/^${U}[ 	]/s/^/${NOLB}/
w
q
EOE
					if test "$WOK" = "0"
					then
						chmod -w $lin
					fi
					/bin/ls -l $lin $ckp | logfil --
					logmsg "=== diff ($lin)"
					diff $lin $ckp | logfil --
					logmsg 
				elif test "${PUSH}" = "1"
				then
					logmsg "=== push ($lin)"
				elif test "${UNDO}" = "1"
				then
					if test -s $ckp
					then
						logmsg "=== undo ($lin)"
						/bin/cp -p $ckp $lin
						/bin/ls -l $lin $ckp | logfil --
						logmsg "=== diff ($lin)"
						diff $lin $ckp | logfil --
						logmsg 
					fi
				fi
			fi
		done
	fi
done
logmsg cleanup
/bin/rm -f $T $M $N $Q $J $POUT
thisquit

#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#        1         2         3         4         5         6         7         8
# vi:nu ts=4
