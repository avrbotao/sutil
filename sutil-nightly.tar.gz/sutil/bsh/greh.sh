test -n "$1" && grep -i "$1" ~/hist/*
