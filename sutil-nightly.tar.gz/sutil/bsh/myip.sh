nslookup myip.opendns.com resolver1.opendns.com
echo
curl https://ifconfig.me/ip
echo
dig TXT +short o-o.myaddr.l.google.com @ns1.google.com
echo
curl ifconfig.me.
echo
curl -4 icanhazip.com.
echo
curl -6 icanhazip.com.
echo
curl ipinfo.io/ip
echo
curl api.ipify.org.
echo
curl checkip.dyndns.org.
echo
host myip.opendns.com resolver1.opendns.com.
echo
curl ident.me.
echo
dig +short myip.opendns.com @resolver1.opendns.com.
echo
dig +short myip.opendns.com @resolver1.opendns.com
echo
