if test $# -eq 0
then
	echo "use: $0 [<searchtext> <replacetext> [-g] [-d <delim>] <file>[...]]"
	exit 1
fi
L=$1
[ "$L" = "" ] && exit 1
shift
N=$1
[ "$N" = "" ] && exit 1
shift
if test "$1" = "-g"
then
	shift
	G=g
fi
D=/
if test "$1" = "-d"
then
	shift
	D=$1
	[ "$D" = "" ] && exit 1
	[ "${#D}" -eq 1 ] || exit 1
	shift
fi
for F in $*
do
	[ -f "$F" ] && echo "=== ($F)" && ed $F <<EOE
g${D}${L}${D}s${D}${D}${N}${D}$G
w
EOE
done
# vi:nu
