#!/bin/sh
count() {
    printf %s\\n "$#"
}
count /proc/[0-9]*/task/[0-9]*
