sudo ls -d /proc/[0-9]*/fd/* | wc
