if test $# -eq 0
then
	echo "use: $0 [<regex> <file>[...]]"
	exit 1
fi
L=$1
[ "$L" = "" ] && exit 1
shift
W=d
for F in $*
do
	[ -f "$F" ] && echo "=== ($F)" && ed $F <<EOE
${L}${W}
w
EOE
done
