
INEN=info.env

LIST=$HOME/bsh/ignore.list

if test -s $INEN
then
	. ./$INEN
else
	echo missing $INEN
	exit 1
fi

echo "# sanitize"

if test -s Makefile
then
	make clean
	make distclean
fi

rm -fr *.in* configure* *.log aclocal* compile missing install-sh depcomp */*.in ${PROGRAM}-[0-9]*/ *.gz *.cache *.o */*.o config.h config.guess* config.sub* config.status stamp-h1 Makefile */Makefile *.exe */*.exe *.stackdump *.a */*.a proto-makefile-am */.dirstamp */.deps ./.deps test-driver

exit $?
