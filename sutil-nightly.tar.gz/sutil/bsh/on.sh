
###	lili							2006	bud

lili () {	###	lista limpa vertical
	tr ",;" "  " | sed "s/ e / /g" | sed "s/ ou / /g" | tr "/ \t" "\n\n\n\n\n" | tr -s "\n"
}
lilid () {	###	lista (dir/path) limpa vertical
	tr ",;" "  " | sed "s/ e / /g" | sed "s/ ou / /g" | tr "\t " "\n\n\n\n" | tr -s "\n"
}
lilil () {	###	lili lower
	dd conv=lcase 2>/dev/null | lili
}
alili () {	###	args lili
	echo $* | lili
}
elili () {	###	lili rex
	lili | ( tr "\n" "|" ; echo ) | sed "s,|$,,"
}
greli () {	###	egrep elili files
	o="${3:- }"
set -x
	egrep $o -e "`cat $1 | elili`" $2
}
grili () {	###	grel -i
	grel "$1" "$2" -i
}

###	on	list	what					2010	bud

usage () {
echo "use : $0 [ [--noerr] [-o <ext>] <listfile> \"command\" ]"
exit 1
}

if test "$1" = "--noerr"
then
	shift
	NOERR=true
else
	NOERR=false
fi

if test "$1" = "-o"
then
	shift
	EXT=$1
	shift
fi

lst=$1
[ -z "$lst" ] && usage
cmd="$2"
[ -z "$cmd" ] && usage
opt=$3
xso=$4
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=6 -o PasswordAuthentication=no"
if test -f $lst
then
	if test -s $lst
	then
		args="`cat $lst | grep -v \"^#\"`"
	else
		usage
	fi
else
	args="`echo $lst`"
fi
for i in `echo $args | lili`
do
        if grep -i "^${i}$" newest-ssh.list >/dev/null
        then
                ULBS=/usr/local/bin/
        else
                ULBS=""
        fi
	echo
	if echo $cmd | grep '%' > /dev/null 2>&1
	then
		run="`echo $cmd | sed \"s/%/$i/\"`"
		[ "${opt}" = "-v" ] && echo "+ on <$i> : ($run) @ [`date`]"
		if test -z "${EXT}"
		then
			if $NOERR
			then
				${ULBS}ssh ${xso} $SSHOPT $i "$run" 2> ${i}.err
			else
				${ULBS}ssh ${xso} $SSHOPT $i "$run"
			fi
		else
			${ULBS}ssh ${xso} $SSHOPT $i "$run" > ${i}.${EXT} 2> ${i}.${EXT}_err
		fi
	else
		[ "${opt}" = "-v" ] && echo "+ on <$i> : ($cmd) @ [`date`]"
		if test -z "${EXT}"
		then
			if $NOERR
			then
				${ULBS}ssh ${xso} $SSHOPT $i "$cmd" 2> ${i}.err
			else
				${ULBS}ssh ${xso} $SSHOPT $i "$cmd"
			fi
		else
			${ULBS}ssh ${xso} $SSHOPT $i "$cmd" > ${i}.${EXT} 2> ${i}.${EXT}_err
		fi
	fi
done
echo
# vi:nu ts=8
