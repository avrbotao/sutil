# fix rh ip
# use : fixrhip hosname ipv4 mask dfgw [tnic]
usage () {
	echo "use : fixrhip hostname ipv4 mask {dfgw|NO} [tnic]"
}
hn=$1
ip=$2
nm=$3
dg=$4
tn=$5
if [ -z "${hn}" ]
then
	usage
	exit 1
fi
if [ "${ip}" != "" -a "${nm}" != "" -a "${dg}" != "" ]
then
	what=fix
else
	what=chk
fi
SO="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=5 -o PasswordAuthentication=no"
TT=/tmp/.fip.tmp
NN=/tmp/.fip.nic
II=/tmp/.fip.ifc
ns=/etc/sysconfig/network-scripts
ts=`date +%Y%m%d%H%M%S`
un=`ssh ${SO} $hn uname`
if [ "${un}" != "Linux" ]
then
	echo "* not Linux"
	exit 1
fi
ssh ${SO} $hn "ip a" > ${TT}
knic=0
tlog=/root/fixrhip.${ts}.log
> ${NN}
cat ${TT} | while read lin
do
	case ${lin} in
		[0-9]*)
			xnic=`echo $lin | cut -d ':' -f 2 | tr -d " \t"`
			echo "<nic=($xnic)>"
			if [ "${xnic}" != "lo" ]
			then
				knic=`expr $knic + 1`
				echo $xnic >> ${NN}
			fi
		;;
		*)
			xipa=`echo $lin | grep "inet " | awk '{print $2}'`
			if test -z "${xipa}"
			then
				continue
			else
				echo "<ip4=($xipa)>"
			fi
		;;
	esac
done
#________________________________________________________________________________
#
if [ "${what}" = "fix" ]
then
	if [ $knic -gt 1 ]
	then
		if [ -z "${tn}" ]
		then
			echo "* missing target nic"
			usage
			exit 1
		else
			tnic=${tn}
		fi
	else
		tnic=`cat ${NN}`
	fi
	scp ${SO} -p ${hn}:${ns}/ifcfg-${tnic} backup.${hn}.ifcfg-${tnic}
	ls -l  backup.${hn}.ifcfg-${tnic}
	cat -n backup.${hn}.ifcfg-${tnic}
	cat > ${II} <<EOI
TYPE="Ethernet"
BOOTPROTO="static"
IPV4_FAILURE_FATAL="no"
IPV6INIT="no"
NAME="${tnic}"
DEVICE="${tnic}"
ONBOOT="yes"
IPADDR="${ip}"
PREFIX="${nm}"
### DNS1="9.8.7.6"
### DNS2="9.8.7.6"
DNS1="9.8.7.6"
DNS2="9.8.7.6"
DOMAIN="any.com"
EOI
if [ "${dg}" = "NO" ]
then
	cat >> ${II} <<EON
DEFROUTE="no"
EON
else
	cat >> ${II} <<EOG
DEFROUTE="yes"
GATEWAY="${dg}"
EOG
fi
	cp ${II} new.${hn}.ifcfg-${tnic}
	ls -l new.${hn}.ifcfg-${tnic}
	cat -n new.${hn}.ifcfg-${tnic}
	echo "=== and ... \c"
	read rsvp 
	if test "${rsvp}" = "go"
	then
		scp ${SO} new.${hn}.ifcfg-${tnic} ${hn}:${ns}/ifcfg-${tnic}
#		ssh ${SO} ${hn} "ip a; netstat -rn; ifdown ${tnic}; ip a; netstat -rn; ifup ${tnic}; ip a; netstat -rn"
		ssh ${SO} ${hn} "nohup sh -c \"(ip a; netstat -rn; ifdown ${tnic}; ip a; netstat -rn; ifup ${tnic}; ip a; netstat -rn)\" > ${tlog} 2>&1 &"
	else
		echo "* chicken !"
	fi
fi
#________________________________________________________________________________
#
# rm -f ${TT} ${NN}
exit 0
# vi:nu ts=8
