L=$1
test -z "$L" && echo "use: $0 <hostlistfile>" && exit 1
for i in `cat $L`
do
	ssh $i sh <<EOS
		if test -s /etc/ssh/sshd_config
		then
			if grep -i ^banner /etc/ssh/sshd_config
			then
				mkdir -p /root/backup
				cp -p /etc/ssh/sshd_config /root/backup/saved-sshd_config-orig
				ex /etc/ssh/sshd_config <<EOE
g/^.anner/s//### &/p
w
q
EOE
ps -fe | grep /sshd | grep -v grep
				service sshd restart
ps -fe | grep /sshd | grep -v grep
			else
				echo ">>> good (sshd_config) on ($i)"
			fi
		else
			echo ">>> no (sshd_config) on ($i)"
		fi
EOS
done
# vi:nu ts=4
