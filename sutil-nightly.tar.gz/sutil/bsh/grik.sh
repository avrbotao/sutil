cd
for i in "$@"
do
	echo "=== ($i)"
	7z x -so -p`cat .detai` $HOME/lab/l8st/doc/kpn.7z | egrep -a -i -e "$i"
done
