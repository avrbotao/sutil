
##  __________________________________________________________________________
## |                                                                          |
## |  The source code in this file is part of the "sutil" software project    |
## |  as developed and released by alexandre botao <from botao dot org> ,     |
## |  available for download from the following public repositories:          |
## |                                                                          |
## |  https://sourceforge.net/u/avrbotao/                                     |
## |  https://bitbucket.org/alexandrebotao/                                   |
## |  https://gitlab.com/alexandre.botao/                                     |
## |  https://github.com/avrbotao/                                            |
## |__________________________________________________________________________|
## |                                                                          |
## |  This software is free and open-source: you can use it under the terms   |
## |  of the "2-Clause BSD License" as stated in the file "sutil-LICENSE"     |
## |  provided with this distribution.                                        |
## |  This software is distributed in hopes of being useful, but WITHOUT ANY  |
## |  EXPRESS OR IMPLIED WARRANTIES as detailed in the file "sutil-LICENSE".  |
## |__________________________________________________________________________|
##

###	2do	pad	cmp	upd
ME=2dock
vcomp () {
	CMD=$1
	PAD=$2
	FIL=$3
	UPD=$4
	echo
	if $CMD $PAD $FIL
	then
		fg=7
		bg=4
		echo $e "\033[${b}3${fg};4${bg}m" "=== ($PAD) okay ($FIL) ===" "\033[m"
		echo
		test "$VFLG" = "1" && ls -lLdrt $PAD $FIL
	else
		echo
		fg=7
		bg=1
		NEW=`ls -dt $PAD $FIL | head -1`
		OLD=`ls -dt $PAD $FIL | tail -1`
		echo $e "\033[${b}3${fg};4${bg}m" ">>> new ($NEW) old ($OLD) <<<" "\033[m"
		echo
		ls -lLdrt $NEW $OLD
		if test "$UPD" = 1
		then
			fg=7
			bg=2
			echo $e "\033[${b}3${fg};4${bg}m" ">>> ($NEW) upd8 ($OLD) <<<" "\033[m"
			rsvp=y
			if test "$IFLG" = 1
			then
				echo confirm
				read rsvp
			fi
			if test "$rsvp" = y
			then
				cp -p $NEW $OLD
				echo
				ls -lLdrt $PAD $FIL
				echo
			fi
		fi
	fi
}
cd
b="1;"
e=""
export b e
[ "`basename $SHELL`" = "bash" ] && e="-e"
HN=`hostname`
CF=${HOME}/.${ME}.${HN}.conf
VCMD=diff
if test "$1" = "-c"
then
	shift
	VCMD=cmp
fi
if test "$1" = "-i"
then
	shift
	IFLG=1
fi
test "$1" = "-u" && UFLG=1
if test -s $CF
then
	echo
	echo "=== conf ($CF)"
	echo
	. ${CF}
	export TASKXPAD TASKFILE UFLG VCMD WORKXPAD WORKFILE
	vcomp $VCMD $TASKXPAD $TASKFILE $UFLG
	vcomp $VCMD $WORKXPAD $WORKFILE $UFLG
	vcomp $VCMD task2do ${HOME}/lab/misc/task2do $UFLG
	vcomp $VCMD work2do ${HOME}/lab/misc/work2do $UFLG
	vcomp $VCMD task2do ${HOME}/lab/l8st/doc/task2do $UFLG
	vcomp $VCMD work2do ${HOME}/lab/l8st/doc/work2do $UFLG
	exit 0
else
	echo ">>> conf ($CF) missing"
	exit 1
fi
echo
if test `hostname` = bud18lus
then
	TN=.config/xpad/content-66YOL0
	WN=.config/xpad/content-CEI540
	ls -lLdrt $TN task2do
	vdiff $TN  task2do
	ls -lLdrt $WN  work2do
	vdiff $WN  work2do
elif test `hostname` = bud18sls
then
	TN=.local/share/notes/Notes/task
	WN=.local/share/notes/Notes/work
	ls -lLdrt $TN  task2do
	vdiff $TN  task2do
	ls -lLdrt $WN  work2do
	vdiff $WN  work2do
elif test `hostname` = bud21osl
then
	TN=.config/xpad/content-88NPA1
	WN=.config/xpad/content-48NPA1
	ls -lLdrt $TN  task2do
	vdiff $TN  task2do
	ls -lLdrt $WN  work2do
	vdiff $WN  work2do
elif test `hostname` = bud21kub
then
	TN=.config/xpad/content-VSWK70
	WN=.config/xpad/content-PGCK70
	ls -lLdrt $TN  task2do
	vdiff $TN  task2do
	ls -lLdrt $WN  work2do
	vdiff $WN  work2do
elif test `hostname` = mab21par
then
	TN=.config/xpad/content-UBC320
	WN=.config/xpad/content-YIS140
	ls -lLdrt $TN  task2do
	vdiff $TN  task2do
	ls -lLdrt $WN  work2do
	vdiff $WN  work2do
fi
ls -lLdrt task2do misc/task2do
ls -lLdrt work2do misc/work2do
vdiff task2do misc/task2do
vdiff work2do misc/work2do
# vi:nu
