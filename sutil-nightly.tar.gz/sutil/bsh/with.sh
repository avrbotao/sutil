lst="$1"
cmd="$2"
[ -z "$lst" -o -z "$cmd" ] && echo "use: $0 [{hostlistfile}|\"host[...]\"} \"<command>\"" && exit
opt=$3
vbz=no
test "${opt}" = "-v" && vbz=-v
test "${vbz}" = "-v" && opt=$4
mark=%
test -z "${opt}" || mark=$opt
test -s ${HOME}/.alias && . ${HOME}/.alias
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=3 -o PasswordAuthentication=no"
if [ -s "${lst}" ]
then
	for i in `cat $lst`
	do
		if echo $cmd | grep "${mark}" > /dev/null 2>&1
		then
			run="`echo $cmd | sed \"s/${mark}/$i/g\"`"
			[ "${vbz}" = "-v" ] && echo "+ ($run) @ [`date`] <$i>"
			$run
		else
			[ "${vbz}" = "-v" ] && echo "+ ($cmd) @ [`date`] <$i>"
			$cmd $i
		fi
	done
else
	for i in `echo $lst`
	do
		if echo $cmd | grep "${mark}" > /dev/null 2>&1
		then
			run="`echo $cmd | sed \"s/${mark}/$i/g\"`"
			[ "${vbz}" = "-v" ] && echo "+ ($run) @ [`date`] <$i>"
			$run
		else
			[ "${vbz}" = "-v" ] && echo "+ ($cmd) @ [`date`] <$i>"
			$cmd $i
		fi
	done
fi
# vi:nu ts=4
