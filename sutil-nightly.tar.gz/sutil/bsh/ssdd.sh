#
#	ssdd		blah dedup
#
#	version		1.2.35
#

bac=ssdd

# hasher prog

# B=md5sum
B=pha

# hasher args

A="-w 128 -B"

# sanity

P=$1
test -z "$P" && echo "use: $0 [dir]" && exit 1
test -d "$P" || exit 1

# init

M=${P}_${bac}.sig
F=${P}_${bac}.fnd
L=${P}_${bac}.siz
K=${P}_${bac}.cnt
R=${P}_${bac}.rep
T=${P}_${bac}.tmp
S=${P}_${bac}.sav
D=${P}_${bac}.dup
Z=${P}_${bac}.zap

X1=${P}_${bac}.one
X2=${P}_${bac}.two
X3=${P}_${bac}.sel

echo "# clean"

rm -fv ${P}_${bac}.???

echo "# siz"

find $P -type f -exec stat -c "%s %n" {} \; > $L

echo "# sort"

cat $L | cut -d ' ' -f 1 | sort | uniq -c | sort -n > $T

echo "# split"

cat $T | grep "^ *1 " > $X1
cat $T | grep -v "^ *1 " > $X2

echo "# filter"

cat $X2 | awk '{print $NF}' > $X3

echo "# select"

> $F
while read s
do
	grep "^${s} " $L | cut -d ' ' -f 2- >> $F
done < $X3

echo "# map(${B})"

> $M
while read n
do
	$B $A "${n}" >> $M
done < $F

echo "# reduce"

cat $M | cut -d ' ' -f 1 | sort | uniq -c | sort -n > $T
cat $T | grep "^ *1 " > $S
cat $T | grep -v "^ *1 " > $K

echo "# report"

echo > ${R}
> ${T}

cat $K | while read c w
do
	echo $c $w
	echo
	grep $w $M | cat -n
	grep $w $M | cat -n | tr "\t" " " >> ${T}
	echo
done >> ${R}

if test -s ${T}
then
	echo "# prune"
	grep "^ *1 " ${T} > ${S}
	grep -v "^ *1 " ${T} > ${D}
	cat ${D} | sed "s,^.* ${P}/,${P}/," > ${Z}
fi

exit 0

# vi:nu ts=8
