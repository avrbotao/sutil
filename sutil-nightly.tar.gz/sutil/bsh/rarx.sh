test -x /usr/bin/xargs && XA=/usr/bin/xargs
test -x /usr/local/bin/xargs && XA=/usr/local/bin/xargs
if test "$1" = "-d"
then
	shift
	DIR=$1
	shift
else
	DIR=`dirname $0`
fi
test -z "$DIR" && exit 1
test -d "$DIR" || exit 1
cd $DIR
test -z "$1" -o -z "$2" && echo "use: $0 [-d dir] list script [burst]" && exit 1
P=10
test -n "$3" && P=$3
ME=`basename $0`
MES=${ME}.start
MEC=${ME}.close
### TRC=-t
/bin/rm -f ${MES} ${MEC}
echo "+++ start (`basename $0`) for (`basename $2`) on ($1/$P) at (`date`)" > ${MES}
cat ${MES} 
echo "... going ..."
cat $1 | $XA $TRC -l -P $P $2 ; date
echo "+++ close (`basename $0`) for (`basename $2`) on ($1/$P) at (`date`)" > ${MEC}
cat ${MEC}
