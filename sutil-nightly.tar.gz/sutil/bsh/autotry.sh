test $# -lt 2 && echo "use : $0 <pkg> \"host [...]\" [user] [cmd;]" && exit
pkg=$1
dir=`basename $pkg .tar.gz`
lst=$2
usr=$3
echo "=== pkg($pkg) dir($dir) usr($usr)"
shift
for host in `echo $lst`
do
	if test -n "${usr}"
	then
		dest="${usr}@${host}"
	else
		dest="${host}"
	fi
	echo === $dest
	scp $pkg ${dest}:.
	ssh $dest "gzip -dc $pkg | tar xf - ; cd $dir ; ./configure && make && make check; cd .. ; rm -fr $pkg $dir"
done
# vi:nu ts=8
