# L=$1
# [ "$L" = "" ] && exit
SO="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=5 -o PasswordAuthentication=no"
### SO="-o PreferredAuthentications=publickey -o connecttimeout=5 -o PasswordAuthentication=no"
A=.fk.out
B=.fk.err
for L in $*
do
	echo "+++ arg ($L)"
	if ping $L -n 1 -m 0
	then
		ssh $SO $L uname >$A 2>$B
		cat -n $A
		KH=`grep -i offending $B | cut -d ':' -f 1 | awk '{print $NF}' | head -1`
		for N in `grep -i offending $B | tr -d "\r" | cut -d ':' -f 2 | sort -nr`
		do
			echo "+++ file ($KH) line ($N)"
			ed $KH <<EON
${N}d
w
EON
		done
	else
		N=$L
		case $N in
			[0-9]*)
				ed ~/.ssh/known_hosts <<EOE
${N}d
w
EOE
			;;
			*) echo ">>> bad arg ($N) <<<" ;;
		esac
	fi
done
