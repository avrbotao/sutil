### fix PrintMotd
L=$1
test -z "$L" && echo "use: $0 <hostlist>" && exit 1
for i in `cat $L`
do
	ssh $i sh <<EOS
		if test -s /etc/ssh/sshd_config
		then
			if grep -i ^PrintMotd /etc/ssh/sshd_config
			then
				ex /etc/ssh/sshd_config <<EOE
g/^.rint.otd/s/no/yes/p
w
q
EOE
ps -fe | grep /sshd | grep -v grep
				service sshd restart
ps -fe | grep /sshd | grep -v grep
			else
				echo ">>> good (sshd_config) on ($i)"
			fi
		else
			echo ">>> no (sshd_config) on ($i)"
		fi
EOS
done
# vi:nu ts=4
