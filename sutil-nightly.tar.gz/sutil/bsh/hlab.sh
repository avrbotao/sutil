if test $# -eq 0
then
	echo "use: $0 [ [--cgi] <htdocs> <title> <page> [ {dir|file} [...] ] ]"
	exit 1
fi
### HTB=/srv/www
### FIXME: HTD , DLY as conf
DLY=2
if test "$1" = "--cgi"
then
	shift
	CGI=1
fi
HTB=$1
shift
TIT=$1
shift
PAG=$1
shift
if test "$CGI" = "1"
then
	HTD=${HTB}/cgi-bin/lab
	PFX=cgi-bin/lab
else
	HTD=${HTB}/htdocs/lab
	PFX=lab
fi
	sudo cp -rp $PAG $HTD
	ls -ld $PAG ${HTD}/$PAG
for i in $*
do
	sudo cp -rp $i $HTD
	ls -ld $i ${HTD}/$i
done
cat > lab.html <<EOHTML
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title> lab ($TIT) `date` </title>
		<meta http-equiv="refresh" content="${DLY};URL=${PFX}/${PAG}">
	</head>
	<body>
		<h2> lab ($TIT) `date` </h2>
		<p> lab ($TIT) `date` </p>
	</body>
</html>
<!-- vi:nu
EOHTML
sudo cp -p lab.html ${HTB}/htdocs/lab.html
ls -l lab.html ${HTB}/htdocs/lab.html
rm -f lab.html
# vi:nu
