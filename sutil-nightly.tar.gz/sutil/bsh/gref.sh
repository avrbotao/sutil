s="$1"
shift
find $* -type f -exec grep -il "$s" {} \;
