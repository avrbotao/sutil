
basicpatch () {
	old=$1
	new=$2
	diff -u $old $new
}

applybasic () {
#	patch -p[num] < patchfile
#	patch [options] originalfile < patchfile 
}

treepatch () {
	old=$1
	new=$2
	diff -Naur $old $new
}

applytree () {
#	patch -p[num](default=0) < patchfile
}

backuppatch () {
#	patch -b -V numbered < patchfile
}

dryrunpatch () {
#	patch --dry-run < patchfile
}

unpatch () {
#	patch -R originalfile < patchfile
}

undotree () {
#	patch -R -p0 originalpath < patchfile
}

