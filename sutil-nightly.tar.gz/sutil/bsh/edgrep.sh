L=$1
F=$2
[ "$L" = "" ] && exit
[ "$F" = "" ] && exit
[ -f "$F" ] || exit
W=p
[ "$3" = -n ] && W=n
ed $F <<EOE
${L}${W}
EOE
