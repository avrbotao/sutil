old=$1
new=$2
fil=$3
opt=$4
[ "$old" = "" -o "$new" = "" -o "$fil" = "" ] && echo ">>> use : $0 <findstring> <replacestring> <filename> [g][p]" && exit
echo "gres / $old / $new / $fil" 
ed $fil <<EOG
g/$old/s//$new/$opt
w
EOG
