#	sbase	ssh	cmd
SSHOPT="-o StrictHostKeyChecking=no -o PreferredAuthentications=publickey -o connecttimeout=2 -o PasswordAuthentication=no"
X=scmd
test -s ${X}.in || exit 1
H=$1
C=`cat ${X}.in`
if test -z "$H"
then
	echo "noargs;nothing" > noargs.${X}
else
	if grep -i "^${H}$" newest-ssh.list >/dev/null
	then
		ULBS=/usr/local/bin/
	else
		ULBS=/usr/bin/
	fi
	${ULBS}ssh ${SSHOPT} $H "${C}" > ${H}.${X} 2> ${H}.${X}_err
	if test $? -eq 0
	then
		echo "${H};good" >> ${X}.log
	else
		echo "${H};fail" >> ${X}.log
	fi
fi
# vi:nu
