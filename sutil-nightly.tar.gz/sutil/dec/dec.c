
/*
 *	dec	dir	ent	cnt
 */

#define _XOPEN_SOURCE 500
#include <ftw.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

# define TREEDEC	1
# define NFTWDEC	2

int meth = TREEDEC ;

int decflags = 0 ;

int nftwflags = FTW_MOUNT | FTW_PHYS ;

struct stat stb;

char denbuf [BUFSIZ];

static int countdirent(const char *fpath, const struct stat *sb, int tflag, struct FTW *ftwbuf) {
	int rd;
	intmax_t fcount ;
	DIR * dip;
	struct dirent * dep;

	if (tflag == FTW_D) {
		dip = opendir(fpath);
		if ( dip != NULL ) {
			errno = 0;
			while ( ( dep = readdir (dip) ) != NULL ) {
				sprintf ( denbuf, "%s/%s", fpath, dep->d_name );
				rd = lstat (denbuf, &stb);
				if (rd == 0) {
					if ( S_ISREG ( stb.st_mode ) ) {
						++fcount;
					}
				} else {
					perror("lstat");
					exit(EXIT_FAILURE);
				}
			}
			if ( errno == 0 ) {
				printf ("%12jd %s\n", fcount, fpath);
				closedir (dip);
			} else {
				perror("readdir");
				exit(EXIT_FAILURE);
			}
		} else {
			perror("opendir");
			exit(EXIT_FAILURE);
		}
	}
	return 0;
}

int nftwdec (char * name, int flags) {
	if (nftw(name, countdirent, 20, flags) == -1) {
		perror("nftw");
		exit(EXIT_FAILURE);
	}
}

int treedec (char * name, int flags) {
	int rd;
	intmax_t fcount ;
	DIR * dip;
	struct dirent * dep;

	if ( ( dip = opendir(name) ) != NULL ) {
		errno = fcount = 0;
		while ( ( dep = readdir (dip) ) != NULL ) {
			sprintf ( denbuf, "%s/%s", name, dep->d_name );
			rd = lstat (denbuf, &stb);
			if (rd == 0) {
				if ( S_ISREG ( stb.st_mode ) ) {
					++fcount;
				}
			} else {
				perror("lstat");
				exit(EXIT_FAILURE);
			}
		}
		if ( errno == 0 ) {
			printf ("%12jd %s\n", fcount, name);
			closedir (dip);
		} else {
			perror("readdir");
			exit(EXIT_FAILURE);
		}
	} else {
		perror("opendir");
		exit(EXIT_FAILURE);
	}
}

int dec (char * name) {
	int rd;

	rd = lstat (name, &stb);

	if (rd == 0) {
		if ( S_ISDIR ( stb.st_mode ) ) {
			if ( meth == TREEDEC ) {
				return treedec (name, decflags) ;
			}
			if ( meth == NFTWDEC ) {
				return nftwdec (name, decflags) ;
			}
		} else {
			perror("not dir");
			exit(EXIT_FAILURE);
		}
	} else {
		perror("lstat");
		exit(EXIT_FAILURE);
	}
}

int main(int argc, char *argv[]) {

	while (*++argv) {
		dec (*argv);
	}
	exit(EXIT_SUCCESS);
}

/*
 * vi:nu
 */
