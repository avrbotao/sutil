
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   dtck                         date time check   |
 *                   |__________________________________________________|
 */

# define	SWNAME			"dtck"
# define	SWVERS			"1.0.14"
# define	SWFORG			"$"		/* "$" = stable */
# define	SWDATE			"2018/11/22"
# define	SWDESC			"date time zone check"
# define	SWTAGS			"date,time,zone,check"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

char * versno = SWVERS ;

char * forgid = SWFORG ;

/*________________________________________________________________________
*/

# include <time.h>
# include <errno.h>
# include <stdio.h>
# include <string.h> 
# include <signal.h>
# include <unistd.h>

/*________________________________________________________________________
*/

# define	VENOM		44

# define	DTZH		"dtzh"		/*	date, time, zone, host		*/

# define	DFLLOGDIR	"/tmp"
# define	ALTLOGDIR	"/var/tmp"

/*________________________________________________________________________
*/

int	verboseflag = 0 ;
int	bladerunner = 0 ;
int	loggood = 0 ;

char * what ;

char * chorabuf () ;

char	myname [128] ;
char	myhost [128] ;
char	logfilnam [128] ;

FILE * logfp = NULL ;

/*________________________________________________________________________
*/

void strlog (msg) char * msg ; {
	char when [32] ;
	if ( loggood ) {
		logfp = fopen (logfilnam, "a") ;
		chorabuf (when) ;
		fprintf ( logfp , "%s %s %s[%ld]: %s\n" , when , myhost , myname , (long)getpid() , msg ) ;
		fflush (logfp) ;
		fclose (logfp) ;
	}
}

void strnlog (msg, len) char * msg ; int len ; {
	char tbuf [256] ;
	strncpy ( tbuf , msg , len ) ;
	tbuf[len] = '\0' ;
	strlog (tbuf) ;
}

void textlog (text, info) char * text , * info ; {
	char tbuf [256] ;
	sprintf ( tbuf , "%s %s" , text , info ) ;
	strlog (tbuf) ;
}

void textnlog (text, info, len) char * text , * info ; int len ; {
	char tbuf [256] ;
	strcpy ( tbuf , text ) ;
	strncat ( tbuf , info , len ) ;
	strlog (tbuf) ;
}

void longlog (text, info) char * text ; long info ; {
	char tbuf [256] ;
	sprintf ( tbuf , "%s %ld" , text , info ) ;
	strlog (tbuf) ;
}

/*________________________________________________________________________
*/

void loginit () {
	sprintf ( logfilnam , "%s/%s.log" , DFLLOGDIR , myname ) ;
	logfp = fopen (logfilnam, "a") ;
	if ( logfp == NULL ) {
        	fprintf (stderr, "%s : log (%s) failure\n", myname, logfilnam) ;
	} else {
		++loggood ;
		fclose (logfp) ;
		strlog (logfilnam) ;
		strlog (SWVERS) ;
	}
}

/*________________________________________________________________________
*/

void wakeup (signo) int signo ; {
        signal (SIGALRM, wakeup) ;
        fprintf (stderr, "%s : timed out (signal %d)\n", what, signo) ;
}

/*________________________________________________________________________
*/

void diesoft (signo) int signo ; {
        signal (SIGTERM, diesoft) ;
        fprintf (stderr, ">>> soft term (signal %d)\n", signo) ;
	++bladerunner ;
}

/*________________________________________________________________________
*/

char * chorabuf ( buf ) char * buf ; {
	time_t tbuf ; 
	struct tm * lot ;

	time ( &tbuf ) ; 
	lot = localtime ( &tbuf ) ; 
	sprintf (buf, "%04d/%02d/%02d %02d:%02d:%02d %03d", 1900 + lot->tm_year, 1 + lot->tm_mon, lot->tm_mday, lot->tm_hour, lot->tm_min, lot->tm_sec, (int)-(timezone/3600)) ;
	return buf ;
}

/*________________________________________________________________________
*/

# ifdef CHORA
chora ( ) {			/*	check	hora	*/
	time_t tbuf ; 
	struct tm * tptr ;
	char cbuf [32] ;

	time ( &tbuf ) ; 
	printf ( "ctime = %s", ctime ( &tbuf ) ) ; 
	tptr = localtime ( &tbuf ) ; 
	printf ( "asctime/localtime = %s", asctime ( tptr ) ) ; 
	printf ( "asctime/gmtime = %s", asctime ( gmtime ( &tbuf ) ) ) ; 
	printf ( "daylight=<%d> timezone=<%ld> tzname=<%s>\n", daylight, timezone, daylight < 0 ? "UNK" : tzname[daylight > 0 ? 1 : 0] ) ; 
}
main ( ) {
	chora ( ) ; 
}
# endif

/*________________________________________________________________________
*/

int	portlist [] = { 44444 , 4444 , 4 , -1 } ;

# define DFLPORTNO	44444
# define DFLPORTIX	0

# define DTSRV
# define DTCLI

# ifdef DTSRV

/*		 _______________________________________________________________
 *		|								|
 *		|	server							|
 *		|_______________________________________________________________|
 */

#include <unistd.h>

#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <sys/wait.h>
#include <arpa/inet.h>

#define MAX 1024 
#define PORT DFLPORTNO 
#define SA struct sockaddr 

/*________________________________________________________________________
*/

int srvfunc(int sockfd) 
{ 
	char buff[MAX]; 

		bzero(buff, MAX); 

		read(sockfd, buff, sizeof(buff)); 

		textnlog ( "cmd=" , buff , 4 ) ;

		if (strncmp("~bye", buff, 4) == 0) { /* exit server */
			write(sockfd, buff, sizeof(buff)); 
			kill ( getppid () , SIGTERM ) ;
			return VENOM ; 
		} 

		if (strncmp(DTZH, buff, 4) == 0) { /* what time is it ? */
			bzero(buff, MAX); 
			chorabuf (buff) ;
			strcat (buff, " ") ;
			strcat (buff, myhost) ;
			write(sockfd, buff, sizeof(buff)); 
			return 0 ;
		} 
	return 0 ;
} 

void srvmain() 
{ 
	int sockfd, connfd, exista, cpid ;
	socklen_t len ;
	struct sockaddr_in servaddr, cli; 

        signal (SIGTERM, diesoft) ;

	/*	 _______________________________
	 *	|____socket_____________________|
	 */

	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	bzero(&servaddr, sizeof(servaddr)); 

        /*------------------------------------------------------*/
        /*      parms                                           */
        /*------------------------------------------------------*/

	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(PORT); 

        /*------------------------------------------------------*/
        /*      bind                                            */
        /*------------------------------------------------------*/

	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("socket bind failed...\n"); 
		exit(0); 
	} 

        /*------------------------------------------------------*/
        /*      listen                                          */
        /*------------------------------------------------------*/

	if ((listen(sockfd, 5)) != 0) { 
		printf("Listen failed...\n"); 
		exit(0); 
	} 

# ifdef ONCE
	len = sizeof(cli); connfd = accept(sockfd, (SA*)&cli, &len); 
	if (connfd < 0) { printf("acccept failed...\n"); exit(0); } 
	srvfunc(connfd); close(sockfd); 
# else	/* LOOP */
	for ( ; ; ) {
		len = sizeof(cli) ;
        	signal (SIGTERM, diesoft) ;
		if ((connfd = accept (sockfd, (SA *) &cli, &len)) == -1) {
			fprintf (stderr, "(%s) <%s>\n", "accept", strerror (errno)) ;
			continue ;
		}
		textlog ( "accepted:" , inet_ntoa (cli.sin_addr) ) ;
		if ( ! fork () ) { /* child */
			longlog ( "son = " , (long) getpid () ) ;
			exista = srvfunc(connfd) ;
			longlog ( "ret = " , (long) exista ) ;
			close (connfd) ;
			exit (exista) ;
		}
		close(connfd) ;  /* parent */
		while ( ( cpid = waitpid (-1, &exista, WNOHANG ) ) > 0 ) { /* clean up children */
			longlog ( "waitpid = " , (long) cpid ) ;
			longlog ( "exit = " , (long) exista ) ;
			sleep (5) ;
		}
		if ( bladerunner ) {
        		strlog ("time to die") ;
			break ;
		}
	}
# endif	/* LOOP */
} 

# endif /* DTSRV */

/*		 _______________________________________________________________
 *		|								|
 *		|	client							|
 *		|_______________________________________________________________|
 */

# ifdef DTCLI

#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/socket.h> 
#define MAX 1024 
#define PORT DFLPORTNO 
#define SA struct sockaddr 

int timeout = 1 ;

void clifunc(int sockfd, char * cmd) 
{ 
	char buff[MAX]; 

		bzero(buff, sizeof(buff)); 
		strcpy ( buff , cmd ) ;
		write(sockfd, buff, sizeof(buff)); 
		bzero(buff, sizeof(buff)); 
		read(sockfd, buff, sizeof(buff)); 
		printf("%s\n", buff); 
} 

int climain(hostname, cmd) char * hostname , * cmd ; { 
	int sockfd; 
	struct sockaddr_in servaddr; 
        struct hostent *he ;
	int rd; 

        signal (SIGALRM, wakeup) ;

        /*------------------------------------------------------*/
        /*      hostname                                        */
        /*------------------------------------------------------*/

        what = "gethostbyname" ;

        alarm (timeout) ;

        he = gethostbyname (hostname) ;

        alarm (0) ; /* clean up */

        if ( he == NULL ) {
                perror (what) ;
                return -1 ;
        }

        /*------------------------------------------------------*/
        /*      socket                                          */
        /*------------------------------------------------------*/

	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		perror ("socket"); 
                return -1 ;
	} 

        /*------------------------------------------------------*/
        /*      connect                                         */
        /*------------------------------------------------------*/

	bzero(&servaddr, sizeof(servaddr)); 

	servaddr.sin_family = AF_INET; 
	servaddr.sin_port = htons(PORT); 
	servaddr.sin_addr = *((struct in_addr *)he->h_addr) ;

        what = "connect" ;

        bzero ( &(servaddr.sin_zero), 8 ) ;
        alarm (timeout) ;

	rd =  connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) ;

        alarm (0) ; /* clean up */

        if ( rd == -1 ) {
                perror(what) ;
                return -1 ;
        }

	clifunc(sockfd, cmd); 

	close(sockfd); 

	return 0 ;
} 

# endif /* DTCLI */


/*		 _______________________________________________________________
 *		|								|
 *		|	...							|
 *		|_______________________________________________________________|
 */

# define	BACNAM		"dtck"
# define	SRVNAM		"OVclock"

int	grd = 0 ;

int	errorflag = 0 ;
int	helpflag = 0 ;
int	killflag = 0 ;
int	listflag = 0 ;
int	queryflag = 0 ;

char	killfile [128] ;
char	listfile [128] ;

char	tmpbuf [128] ;

char * basename (name) char * name ; {
	char * tp ;
	tp = strrchr (name, '/') ;
	if ( tp == NULL )
		return name ;
	else
		return tp + 1 ;
}

void usage ( name ) char * name ; {
	fprintf ( stderr , "use : %s [options]\n" , name ) ;
}

int dtck ( host ) char * host ; {
	char * cmd = NULL ;
	if ( queryflag ) {
		cmd = DTZH ;
	}
	if ( killflag ) {
		cmd = "~bye" ;
	}
	if ( cmd == NULL ) {
		fprintf ( stderr , "no action specified\n" ) ;
		return -1 ;
	}
	climain ( host , cmd ) ;
	return 0 ;
}

void dolist ( listfile ) char * listfile ; {
	if ( listfile == NULL ) {
		return ;
	}
}

int main (argc, argv) int argc ; char * * argv ; {

	strcpy (myname, basename (argv[0])) ;
	gethostname (myhost, 128) ;
	loginit () ;

	if ( --argc ) {
		while ( *++argv ) {
			if ( **argv == '-' ) {
				if ( 0 == strcmp ( *argv , "-?" ) ) {
					++helpflag ;
				} else if ( 0 == strcmp ( *argv , "-k" ) ) {
					strcpy ( killfile , *++argv ) ; ++killflag ;
				} else if ( 0 == strcmp ( *argv , "-l" ) ) {
					strcpy ( listfile , *++argv ) ; ++listflag ;
				} else if ( 0 == strcmp ( *argv , "-q" ) ) {
					++queryflag ;
				} else if ( 0 == strcmp ( *argv , "-v" ) ) {
					++verboseflag ;
				} else {
					++errorflag ;
				}
			} else {
				dtck ( *argv ) ;
			}
		}
		if ( helpflag || errorflag ) {
			usage ( myname ) ;
			exit (1) ;
		}
		if ( listflag ) {
			dolist (listfile) ;
			exit (grd) ;
		}
	} else {
		if ( strcmp ( myname , SRVNAM ) == 0 ) {
			srvmain () ;
		}
		if ( strcmp ( myname , BACNAM ) == 0 ) {
			printf ( "%s\n", chorabuf ( tmpbuf ) ) ; 
		}
	}

	exit (grd) ;
}

/*
 * vi:nu ts=8
 */

