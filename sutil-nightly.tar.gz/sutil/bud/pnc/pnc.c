
/*
 *          |          _                    |~~~~~~~~~~~~~~~~~~~~~~~|
 *          |\       _/ \_                  |    Alexandre Botao    |
 *          | \_    /_    \_                |     www.botao.org     |
 *          \   \__/  \__   \               |   +55-11-98244-UNIX   |
 *           \_    \__/  \_  \              |   +55-11-9933-LINUX   |
 *             \_   _/     \ |              |     botao@linux.sh    |
 *               \_/        \|              |  alexandre@botao.org  |
 *                           |              |_______________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	pnc						  pathname components	|
 *		\ \/ /		|	(c) 2014-2015			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# include	<stdio.h>
# include	<stdlib.h>
# include	<libgen.h>
# include	<string.h>

# define	USE_STDSTR

# include	"abc.h"

/*________________________________________________________________________
*/

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

# define	TMPBUFSIZ	16384

# define	MAXALTARG	16384

# define	MAXNAMLEN	16384

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

int			altargc = -1 ;
char *		altargv [MAXALTARG] ;	/*	FIXME: calloc by argc	*/

int			argcount = -1 ;
int			argsused = 0 ;
char * *	arglist = NULL ;

int			grd = 0 ;

int			helpflag = 0 ;
int			verboseflag = 0 ;
int			versionflag = 0 ;
int			noargs = 0 ;

char *		execpathname = NULL ;
char *		execfilename = NULL ;

char		linbuf [TMPBUFSIZ] ;

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void pathed () {
	exit (grd) ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void initarg (argc) int argc ; {

	arglist = malloc ( argc * sizeof (char *) ) ;

	if ( arglist == NULL )
		return ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void savearg (arg) char * arg ; {
	/* FIXME: argobey() must trigger realloc(arglist[]) */
	arglist[argsused++] = strdup (arg) ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void usage () {
	fprintf (stderr, " use : \n\n") ;
	fprintf (stderr, "       %s [-options] [[pathname]...]\n\n", "pnc") ;
	fprintf (stderr, "       %s [-options] [[pathname]...]\n\n", "lpath") ;
	fprintf (stderr, "       %s [-options] [[pathname]...]\n\n", "llpath") ;
	fprintf (stderr, "       %s [-options] [[pathname]...]\n\n", "mkpath") ;
	fprintf (stderr, "       %s [-options] [[pathname]...]\n\n", "rmpath") ;
	fprintf (stderr, " -?  : show usage help\n" ) ;
	fprintf (stderr, " -V  : show version\n" ) ;
	fprintf (stderr, " -v  : verbose\n" ) ;
	fprintf (stderr, " `lpath'  is equivalent to `pnc' \n" ) ;
	fprintf (stderr, " `llpath' is equivalent to `pnc -l' \n" ) ;
	fprintf (stderr, " `mkpath' is equivalent to `pnc -m' \n" ) ;
	fprintf (stderr, " `rmpath' is equivalent to `pnc -r' \n" ) ;
	grd = 1 ;
	pathed () ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void argparse (argc, argv) int argc ; char * * argv ; {

	if ( argc == 0 || argv == NULL || *argv == NULL )
		return ;

	if ( **argv == '-' ) {
		--argv ;
		++argc ;
	}

	initarg (argc) ;

	execpathname = strdup (*argv) ;
	execfilename = strdup ( basename (*argv) ) ;

	if (--argc) {
		while (*++argv) {
			trimstr ( *argv , MAXNAMLEN ) ;
					if ( strcmp (*argv, "-?") == 0 || strcmp (*argv, "--help") == 0 ) {
				++helpflag ;
			} else	if ( strcmp (*argv, "-v") == 0 ) {
				++verboseflag ;
			} else	if ( strcmp (*argv, "-V") == 0 ) {
				++versionflag ;
			} else {
				savearg (*argv) ;
			}
		}
	} else {
		++noargs ;
	}
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void argobey (fp) FILE * fp ; {

	if (fp == NULL)
		return ;

	while ( fgets ( linbuf , TMPBUFSIZ , fp ) != NULL ) {
		stripeol ( linbuf ) ;
		altargc = strclip ( linbuf , altargv , ' ' ) ;
		argparse ( altargc , altargv ) ;
	}

	fclose (fp) ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void lpath () {

	if (noargs)
		usage () ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void llpath () {

	if (noargs)
		usage () ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void mkpath () {

	if (noargs)
		usage () ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void rmpath () {

	if (noargs)
		usage () ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void pnc () {

	if (noargs)
		lpath () ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void pathit () {

	if (helpflag)
		usage () ;

			if ( strcmp (execfilename, "lpath")  == 0 ) {
		lpath () ;
	} else	if ( strcmp (execfilename, "llpath") == 0 ) {
		llpath () ;
	} else	if ( strcmp (execfilename, "mkpath") == 0 ) {
		mkpath () ;
	} else	if ( strcmp (execfilename, "rmpath") == 0 ) {
		rmpath () ;
	} else	if ( strcmp (execfilename, "pnc")    == 0 ) {
		pnc () ;
	}
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

int main (argc, argv) int argc ; char * * argv ; {

	argparse ( argc , argv ) ;

	pathit () ;
	pathed () ;

	return grd ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

/*
 * vi:nu ts=4
 */

