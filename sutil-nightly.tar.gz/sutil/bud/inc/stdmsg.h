
/*		 _______________________________________________________________
 *		|																|
 *		|	stdmsg.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDMSG_H

# define _STDMSG_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef STDMEM

#	define	XE_NO_MEMORY					-1001

# endif /* STDMEM */

# ifdef STDCAP

#	define	XE_TERM_NOT_SET					-1102
#	define	XE_NULL_TERM					-1103
#	define	XE_NO_TERM_DB					-1104
#	define	XE_TERM_UNKNOWN					-1105

# endif /* STDCAP */

# ifdef STDTIO

#	define	XE_CANT_OPEN_TTY				-1106
#	define	XE_CANT_GET_TERM_ATTR			-1107
#	define	XE_CANT_SET_TERM_ATTR			-1108

# endif /* STDTIO */

# ifdef STDKEY

#	define	XE_CANT_FCNTL_GETFL				-1109
#	define	XE_CANT_FCNTL_SETFL_NDELAY		-1110
#	define	XE_CANT_FCNTL_SETFL_REST		-1111
#	define	XE_CANT_IOCTL_FIONREAD			-1112

# endif /* STDKEY */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDMSG_H */

/*
 * vi:tabstop=4
 */
