
/*		 _______________________________________________________________
 *		|																|
 *		|	stdcolor.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDCOLOR_H

# define _STDCOLOR_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void			initcolor	OF ( ( int, int, int, int )					) ;
void			endcolor	OF ( ( void )								) ;

void			termcolor	OF ( ( int, int )							) ;
void			ansicolor	OF ( ( int, int )							) ;
void			xenixcolor	OF ( ( int, int )							) ;

int				colorcode	OF ( ( char * )								) ;
int				checkcolor	OF ( ( char * )								) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

extern	char *	_colornames [] ;
extern	int		_ansicolors [] ;
extern	int		_vramcolors [] ;
extern	int *	_colorbits ;

extern	int		monochrome, monopaper ;
extern	int		attrbyte, forenorm, backnorm ;
extern	int		forerev, backrev, foreacs, backacs ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	TOTCOLORS			16

# define	CT_ANSI			0x0001
# define	CT_XENIX		0x0002

# define	_BGFG(_B,_F)	( ( (_B & 0x07) << 4 ) | (_F & 0x0f) )

# ifdef ORIGCODE

# define	_COLOR(_X)		(*(_colorbits+_X))
# define	_COLORNAME(_X)	(_colornames [ * ( _colorbits + ( _X & 0x0f ) ) ])

# else

#	define	_COLOR(_X)		( * ( _colorbits + ( _X & 0x0f ) ) )
#	define	_COLORNAME(_X)	( _colornames [ _COLOR ( _X ) ] )

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

											/* i b g r (ansi)		*/

# define	_BLACK			_COLOR( 0)		/* 0 0 0 0				*/
# define	_RED  			_COLOR( 1)		/* 0 0 0 1				*/
# define	_GREEN			_COLOR( 2)		/* 0 0 1 0				*/
# define	_BROWN			_COLOR( 3)		/* 0 0 1 1				*/
# define	_BLUE 			_COLOR( 4)		/* 0 1 0 0				*/
# define	_MAGENTA		_COLOR( 5)		/* 0 1 0 1				*/
# define	_CYAN 			_COLOR( 6)		/* 0 1 1 0				*/
# define	_LIGHTGRAY		_COLOR( 7)		/* 0 1 1 1				*/
# define	_GRAY 			_COLOR( 8)		/* 1 0 0 0				*/
# define	_LIGHTRED  		_COLOR( 9)		/* 1 0 0 1				*/
# define	_LIGHTGREEN		_COLOR(10)		/* 1 0 1 0				*/
# define	_YELLOW			_COLOR(11)		/* 1 0 1 1				*/
# define	_LIGHTBLUE 		_COLOR(12)		/* 1 1 0 0				*/
# define	_LIGHTMAGENTA	_COLOR(13)		/* 1 1 0 1				*/
# define	_LIGHTCYAN 		_COLOR(14)		/* 1 1 1 0				*/
# define	_WHITE			_COLOR(15)		/* 1 1 1 1				*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDCOLOR_H */

/*
 * vi:nu ts=4
 */
