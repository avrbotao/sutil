
/*		 _______________________________________________________________
 *		|																|
 *		|	stdwin.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDWIN_H

# define _STDWIN_H

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

struct screlm {
	unsigned	char se_byte ;
	unsigned	char se_attr ;
	unsigned	char se_fore ;	/* ground	*/
	unsigned	char se_back ;	/* ditto	*/
} ;

typedef			struct screlm	SCRELM ;

# define		SCRELMSIZ		(sizeof(SCRELM))

extern SCRELM	* stdseb ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

struct windes {
	int			ww_lin ;
	int			ww_col ;
	int			ww_wid ;
	int			ww_hei ;
	int			ww_cy ;
	int			ww_cx ;
	int			ww_atr ;
    int			ww_siz ;        /* # of screlms in ww_sav ...           */
	SCRELM *	ww_sav ;
} ;

typedef			struct windes	WINDES ;

# define		WINDESSIZ		(sizeof(WINDES))

extern WINDES	* stdwin , * curwin ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# define	WNORM		0x0000
# define	WBLINK		0x0010
# define	WREV		0x0020
# define	WHIGH		0x0040
# define	WUNDER		0x0080
# define	WALTCHRSET	0x0001 /* 0x0100 */
# define	WDFLCHRSET	0x0002 /* 0x0200 */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# define	winit()			wwinit(0,0)
# define	wend()			wwend()
# define	wgrow(H,W)		wwgrow(H,W)

# define	wwenter(W)		curwin = W
# define	wwleave()		curwin = stdwin

# define	wenter(W)		curwin = W
# define	wleave()		curwin = stdwin

# define	wopen(L,C,H,W)	wwopen(L,C,H,W)
# define	wclose(W)		wwclose(W)
# define	wflush()		wwflush()

# define	wfill(B,A)		wwfill(curwin,B,A)
# define	wtitle(T)		wwtitle(curwin,T)
# define	wclear()		wwclear(curwin)
# define	wceol()			wwceol(curwin)
# define	wbox(T)			wwbox(curwin,T)

# define	wgoto(L,C)		wwgoto(curwin,L,C)
# define	wattr(A)		wwattr(curwin,A)

# define	wputc(C)		wwputc(curwin,C)
# define	wputw(E)		wwputw(curwin,E)
# define	wputs(S)		wwputs(curwin,S)
# define	wputb(B,L)		wwputb(curwin,B,L)

# define	wdisp(L,C,S,A)	wwdisp(curwin,L,C,S,A)

# define	wwnorm(W)		wwattr(W,WNORM)
# define	wwrev(W)		wwattr(W,WREV)
# define	wwblink(W)		wwattr(W,WBLINK)
# define	wwhigh(W)		wwattr(W,WHIGH)
# define	wwaltchr(W)		wwattr(W,WALTCHRSET)
# define	wwdflchr(W)		wwattr(W,WDFLCHRSET)

# define	wnorm()			wwnorm(curwin)
# define	wrev()			wwrev(curwin)
# define	wblink()		wwblink(curwin)
# define	whigh()			wwhigh(curwin)
# define	waltchr()		wwaltchr(curwin)
# define	wdflchr()		wwdflchr(curwin)

# define	wwlines(W)		((W)->ww_hei)
# define	wwcols(W)		((W)->ww_wid)

# define	wlines()		wwlines(curwin)
# define	wcols()			wwcols(curwin)

# define	videolines()	wwlines(stdwin)
# define	videocols()		wwcols(stdwin)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int			wwinit			OF ( (int, int)								) ;
int			wwgrow			OF ( (int, int)								) ;
void		wwend			OF ( (void)									) ;

WINDES *	wwopen			OF ( (int, int, int, int)					) ;
void		wwclose			OF ( (WINDES *)								) ;
void		wwflush			OF ( (void)									) ;

void		wwfill			OF ( (WINDES *, int, int)					) ;
void		wwceol			OF ( (WINDES *)								) ;
void		wwclear			OF ( (WINDES *)								) ;
void		wwtitle			OF ( (WINDES *, char *)						) ;
void		wwbox			OF ( (WINDES *, char *)						) ;

void		wwgoto			OF ( (WINDES *, int, int)					) ;
void		wwattr			OF ( (WINDES *, int)						) ;

void		wwputc			OF ( (WINDES *, int)						) ;
void		wwputw			OF ( (WINDES *, SCRELM *)					) ;
void		wwputs			OF ( (WINDES *, char *)						) ;
void		wwputb			OF ( (WINDES *, char *, int)				) ;

void		wwdisp			OF ( (WINDES *, int, int, char *, int)		) ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# endif /* _STDWIN_H */

/*
 * vi:ts=4
 */
