
/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void *	_malloc_	OF ( ( size_t ) ) ;
void *	_calloc_	OF ( ( size_t , size_t ) ) ;
void *	_realloc_	OF ( ( void * , size_t ) ) ;
void	_free_		OF ( ( void * ) ) ;

void	_memdmp_	OF ( ( char * ) ) ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

