
# include <sys/time.h>

# include <time.h>

# ifdef ANSI

long long diftod ( struct timeval * , struct timeval * ) ;

char * fmtus (long long) ;

# else

long long diftod ( ) ;

char * fmtus ( ) ;

# endif

