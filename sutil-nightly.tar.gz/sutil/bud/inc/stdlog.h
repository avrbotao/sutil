/*		 _______________________________________________________________
 *		|																|
 *		|	stdlog.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef	_STDLOG_H

# define	_STDLOG_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	TRACELOG		"trace.log"
# define	COMMITLOG		0x0001
# define	LOGRECSIZ		1024

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int			setlogent		OF ( ( char * )						) ;
int			setlogopt		OF ( ( int )						) ;
int			putlogent		OF ( ( char * /* , ... */ )			) ;
void		endlogent		OF ( ( void )						) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif		/* _STDLOG_H */

