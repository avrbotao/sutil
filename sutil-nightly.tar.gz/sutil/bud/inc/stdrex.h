
/*		 _______________________________________________________________
 *		|																|
 *		|	stdrex.h					(c) 1998-2003 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDREX_H

# define _STDREX_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# if ( ( ! defined (GNUREX) ) && ( ! defined (OLDREX) ) )
#    error "must define {GNU|OLD}REX"
# endif /* ! def {GNU|OLD}REX */

# ifdef GNUREX
/* # include <sys/types.h> */
# include <regex.h>
# endif /* GNUREX */

# ifdef OLDREX
# include <libgen.h>
# endif /* OLDREX */

# include <stdio.h>

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *			vrexinit	OF ( (char *)								) ;
int				vrexmatch	OF ( (char *, char *)						) ;
int				vrexfree	OF ( (char *)								) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDREX_H */

/*
 * vi:tabstop=4
 */
