
/*		|-------------------------------------------------------|		*/
/*		|	includes											|		*/
/*		|-------------------------------------------------------|		*/

# include	<stdio.h>
# include	<stdlib.h>
# include	<string.h>

/*		|-------------------------------------------------------|		*/
/*		|	defines												|		*/
/*		|-------------------------------------------------------|		*/

# ifndef	TRUE
#	define	TRUE			1
# endif

# ifndef	FALSE
#	define	FALSE			0
# endif

# ifdef		ANSI
#	define					OF(X)	X
# else		/* K&R */
#	define					OF(X)	()
# endif		/* ANSI */

# define	BANAL			 0
# define	FATAL			-1
# define	CHKPT			-2

# define	NUL				'\0'

/*		|-------------------------------------------------------|		*/
/*		|	types												|		*/
/*		|-------------------------------------------------------|		*/

typedef		int				bool ;

typedef		char *			STRING ;

# define	STRINGSIZ		(sizeof (STRING))

/*		|-------------------------------------------------------|		*/

struct	clopt	{

	char *	sopt ;
	char *	lopt ;
	char *	addr ;
	char *	type ;
	char *	help ;
} ;

typedef		struct clopt	CLOPT ;

# define	CLOPTSIZ		(sizeof (CLOPT))

/*		|-------------------------------------------------------|		*/

struct parmqe {
	char *	addr ;
	char *	type ;
	bool	mpty ;
} ;

typedef		struct parmqe	PARMQE ;

# define	PARMQESIZ		(sizeof (PARMQE))

/*		|-------------------------------------------------------|		*/
/*		|	prototypes											|		*/
/*		|-------------------------------------------------------|		*/

void		banner		OF ( (void)										) ;
char *		buffinit	OF ( (char *, int)								) ;
void		chkarg		OF ( (char *)									) ;
bool		chkflag		OF ( (int)										) ;
bool		chkparm		OF ( (int)										) ;
void		doflags		OF ( (void)										) ;
void		enqparm		OF ( (char *, char *)							) ;
void		errmsg		OF ( (int, char *, ...)							) ;
char *		incrlist	OF ( (char * *, int *, int)						) ;
void		initargs	OF ( (char * *)									) ;
void		initflag	OF ( (bool *, char *, bool, char *)				) ;
void		initparm	OF ( (char *, char *, char *, char *)			) ;
void		noparms		OF ( (void)										) ;
void		setparm		OF ( (char *)									) ;
char *		strclone	OF ( (char *)									) ;
void		usage		OF ( (void)										) ;

/*		|-------------------------------------------------------|		*/

extern	bool	debugflag	;
extern	bool	dontflag	;
extern	bool	environflag	;
extern	bool	helpflag	;
extern	bool	licenseflag	;
extern	bool	quietflag	;
extern	bool	verboseflag	;
extern	bool	versionflag	;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

