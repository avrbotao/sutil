
/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# define	SIO_DFL_OPEN_TIME_US		1000
# define	SIO_DFL_CRET_TIME_US		2000
# define	SIO_DFL_CLOS_TIME_US		1000
# define	SIO_DFL_SEEK_TIME_US		2000 /* 3000 */
# define	SIO_DFL_READ_TIME_US		4000 /* 6000 */
# define	SIO_DFL_WRIT_TIME_US		6000 /* 9000 */

# define	SIO_DFL_FILESIZE		1073741824

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef _LARGEFILE_SOURCE
# define	FOFSBITS			64
# endif

# if ! ( defined (SYSIO) || defined (SIMIO) || defined (BUFIO) )
#	define	SYSIO
# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef SIMIO						/* simulated virtual fast i/o	*/

# define	MAXSIMFDS	16384 /* 256 */

typedef		int					VFD ;

struct simfile {
	char *	sf_name ;
	size_t	sf_size ;
	off_t	sf_offs ;
	VFD		sf_desc ;
	int		sf_flag ;
} ;

typedef		struct simfile		SIMFILE ;

struct simspec {
	char *	ss_name ;
	char *	ss_open_times ;
	char *	ss_creat_times ;
	char *	ss_close_times ;
	char *	ss_seek_times ;
	char *	ss_read_times ;
	char *	ss_write_times ;
} ;

typedef		struct simspec		SIMSPEC ;

#	define		TYPIO				"SIM"

#	define		VOPEN(N,F,M)		simopen(N,F)
#	define		VCLOSE(D)			simclos(D)
#	define		VCREAT(N,F,M)		simcret(N,F,M)
#	define		VSTAT(N,B)			simstat(N,B)
#	define		VSEEK(D,O,W)		simseek(D,O,W)
#	define		VREAD(B,S,N,D)		simread(D,B,N)
#	define		VWRITE(B,S,N,D)		simwrit(D,B,N)
#	define		VOPERR(D)			((D)<0)

#	define		MODEIN				( O_RDONLY | O_LARGEFILE )
#	define		MODEIO				( O_RDWR   | O_LARGEFILE )
#	define		MODEOUT				( O_WRONLY | O_LARGEFILE )
#	define		MODEZAP				( MODEOUT  | O_CREAT  | O_LARGEFILE )
#	define		MODEPERM			( S_IREAD  | S_IWRITE | S_IFREG )

# endif /* SIMIO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef SYSIO						/* raw unbuffered sys call i/o	*/

typedef		int					VFD ;

#	define		TYPIO				"SYS"

#	define		VOPEN(N,F,M)		open(N,F,M)
#	define		VCLOSE(D)			close(D)
#	define		VCREAT(N,F,M)		creat(N,F,M)
#	define		VSTAT(N,B)			stat(N,B)
#	define		VSEEK(D,O,W)		lseek(D,O,W)
#	define		VREAD(B,S,N,D)		read(D,B,N)
#	define		VWRITE(B,S,N,D)		write(D,B,N)
#	define		VOPERR(D)			((D)<0)

#	ifdef	DOS
#		define	MODEIN				( O_RDONLY | O_BINARY )
#		define	MODEIO				( O_RDWR   | O_BINARY )
#		define	MODEOUT				( O_WRONLY | O_BINARY )
#		define	MODEPERM			( S_IREAD  | S_IWRITE | S_IFREG )
#		define	MODEZAP				( MODEOUT  | O_CREAT  )
#	endif	/* DOS */

#	ifdef	FORCEDEFS /* LINUX */
#		ifndef O_DIRECT
#			define	O_DIRECT	 040000
#		endif
#		ifndef O_LARGEFILE
#			define	O_LARGEFILE	0100000
#		endif
#	endif	/* LINUX */

#	ifdef	ANYX
#		define	MODEIN				( O_RDONLY )
#		define	MODEIO				( O_RDWR   )
#		define	MODEOUT				( O_WRONLY )
#		define	MODEBIG				( O_LARGEFILE )
#		define	MODERAW				( O_DIRECT )
#		define	MODEPERM			( S_IREAD  | S_IWRITE | S_IFREG )
#		define	MODEZAP				( MODEOUT  | O_CREAT  )
#	endif	/* ANYX */

# endif /* SYSIO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef BUFIO						/* stdio buffered stream i/o	*/

typedef		FILE *				VFD ;

#	define		TYPIO				"BUF"

#	define		VOPEN(N,F,M)		fopen(N,F)
#	define		VCLOSE(D)			fclose(D)
#	define		VCREAT(N,F,M)		creat(N,F,M)
#	define		VSTAT(N,B)			stat(N,B)
#	define		VSEEK(D,O,W)		fseek(D,O,W)
#	define		VREAD(B,S,N,D)		fread(B,S,N,D)
#	define		VWRITE(B,S,N,D)		fwrite(B,S,N,D)
#	define		VOPERR(D)			((D)==NULL)

#	define		MODEIN				"rb"
#	define		MODEIO				"r+b"
#	define		MODEOUT				"r+b"
#	define		MODEZAP				"w+b"
#	define		MODEPERM			"rw-"

# endif /* BUFIO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

VFD		simopen		OF ( ( char * , int ) )			;
VFD		simcreat	OF ( ( char * , int ) )			;
int		simclos		OF ( ( VFD ) )					;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

/*
 * vi:nu ts=4
 */
