
/*		 _______________________________________________________________
 *		|																|
 *		|	stdpath.h					(c) 1996-2006 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDPATH_H

# define _STDPATH_H

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# define	PS_RECURSE			0x0002

# define	MAXPATHLINESIZE		2048
# define	MAXFILENAMESIZE		1024

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

struct pathlistentry {

	int							ple_sons ;
	int							ple_curr ;
	int							ple_depth ;
	char *						ple_raw ;
	char *						ple_base ;
	char *						ple_name ;
	struct stat *				ple_stat ;
	struct pathlistentry *		ple_mom ;
	struct pathlistentry * *	ple_kids ;
} ;

typedef		struct pathlistentry		PATHLISTENTRY ;

# define	PATHLISTENTRYSIZE	(sizeof(PATHLISTENTRY))

struct pathlistdescriptor {

	int					pld_sons ;
	int					pld_curr ;
	int					pld_depth ;
	FILE *				pld_fp ;
	char *				pld_buf ;
	char *				pld_name ;
	PATHLISTENTRY *		pld_entry ;
	PATHLISTENTRY * *	pld_kids ;
} ;

typedef		struct pathlistdescriptor	PATHLISTDESCR ;

# define	PATHLISTDESCRSIZE	(sizeof(PATHLISTDESCR))

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

DIRDES *		OpenPath			OF ( (char *)						) ;
DIRENT *		ReadPath			OF ( (DIRDES *)						) ;
int				ClosePath			OF ( (DIRDES *)						) ; 
int				dotpath				OF ( (char *)						) ; 

PATHLISTDESCR *	OpenPathList		OF ( (char *)						) ;
PATHLISTENTRY *	ReadPathList		OF ( (PATHLISTDESCR *)				) ;
int				ClosePathList		OF ( (PATHLISTDESCR *)				) ;

PATHLISTDESCR *	setpathlistent		OF ( (char *)						) ;
char *			getpathlistent		OF ( (PATHLISTDESCR *)				) ;
char *			getpathlistsel		OF ( (PATHLISTDESCR *, int)			) ;
int				endpathlistent		OF ( (PATHLISTDESCR *)				) ;

int				makepath			OF ( (char *)						) ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# endif /* _STDPATH_H */

/*
 * vi:tabstop=4
 */
