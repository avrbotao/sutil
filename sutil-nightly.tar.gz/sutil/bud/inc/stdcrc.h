
/*		 _______________________________________________________________
 *		|																|
 *		|	crc.h							 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _CRC_H

# define _CRC_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/* # define	FNV64A */

# define	CRC_IGNORECR	0x0001

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void		crcinit			OF ( ( void )					) ;
ULONG		crcbuff			OF ( ( char * , int )			) ;

void		crcsetflag		OF ( ( int )					) ;

ULONG		crcupdate		OF ( ( char * , int )			) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _CRC_H */

/*
 * vi:tabstop=4
 */
