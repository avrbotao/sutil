
# ifndef _ASTDINT_H_

# define _ASTDINT_H_

/*\___________________________________________________________________________
\*/

# ifdef _NEED_STDINT_H_
#	ifdef _HAS_STDINT_H_
#		include <stdint.h>
#	else
#		ifdef HPUX
#			include <inttypes.h>
#		else
#			include "stdbint.h"
#		endif /* HPUX */
#	endif /* _HAS_STDINT_H_ */
# endif /* _NEED_STDINT_H_ */

/*\___________________________________________________________________________
\*/

# endif /* _ASTDINT_H_ */

/*
 * vi:nu tabstop=8
 */
