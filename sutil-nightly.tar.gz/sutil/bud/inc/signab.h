
/*		 _______________________________________________________________
 *		|																|
 *		|	signab.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _SIGNAB_H

# define _SIGNAB_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/* still needing names for 0xba, 0x0a0b, 0x0a0b030f, 0x03ab, ... */

# define	UC_SIGNAB		0xAB				/*				  171	*/
# define	US_SIGNAB		0xAB03				/*		       43.779	*/
# define	UL_SIGNAB		0xAB03020F			/*		2.869.101.071	*/
# define	IP_SIGNAB		"171.3.2.15"

# define	SZ_SIGNAB		"\253\003\002\017"
# define	SZ_SIGNABLEN	4

# define	UL_SIGNAM		0xAB030C0E

# define	OL_SIGNAB		"@$#!&~^"
# define	OL_SIGNABLEN	7

# define	MAGICS			OL_SIGNAB

# define	UC_SIGNAC		0xAC				/*		          172	*/
# define	US_SIGNAC		0xABCF				/*		       43.983	*/
# define	UL_SIGNAC		0xAB03CF04			/*		2.869.153.540	*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _SIGNAB_H */

