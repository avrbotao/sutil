
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*		 ___________________________________________________________
 *		|															|
 *		|	abc.h					(c) 1990-2006 Alexandre Botao	|
 *		|___________________________________________________________|
 */

# ifndef _ABC_H

# define _ABC_H

# include "configure.h"

/*
# ifdef PRAGIDEN
# pragma ident	"@(#)abc.h	25.39	2006/03/31	avrb"
# else
# ident			"@(#)abc.h	25.39	2006/03/31	avrb"
# endif
*/

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef OPER_SYS_ENV		/*	operating system environments ...		*/

	VER7	SYSV	BSD		ANYX	XWIN	HURD	BEOS	VNOS
	MAC		DOS		WIN		LINUX	NEWOS	NETWARE	MENUET

# endif /* OPER_SYS_ENV */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef PROC_FAM			/*	processor family ...					*/

	ALPHA	ARM		HPPA
	IA8		IA16	IA32	IA64
	M68K	PPC		S390	SPARC

# endif /* PROC_FAM */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef STD_ENV				/*	standards conformance environments ...	*/

	ANSI	BSD		ISO		POSIX	SVID	XOPEN	XPGN

# endif /* STD_ENV */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef COMPILER_ENV		/*	compiler environments ...				*/

	KRC		ANSIC	__STDC__
	GCC		TC2		TC3		MSC6	MSVC	SUNC	AIXC	HPXC	MACC

# endif /* COMPILER_ENV */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef THREADS_ENV			/*	threads environments ...				*/

	STPTHR	CTHREADS	MACH_CTHREADS			/* nextstep / openstep	*/
	LWPTHR	LTHREADS	SUNOS_LWP_THREADS
	WNTTHR	NTHREADS	NT_THREADS
	PSXTHR	PTHREADS	POSIX_THREADS
	SOLTHR	STHREADS	SOLARIS_THREADS
	GNUTHR	GTHREADS	GNU_THREADS				/* GNU_PTH				*/
	FAKTHR	FTHREADS	STUB_THREADS			/* fake threads			*/

# define MACTHR STPTHR

# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef OS_NAMES

	MACOSX		GNUHURD		MENUET		NEWOS		VNOS		BEOS
	DARWIN		GNUDARWIN	SHARK		DGUX

	WIN31		WIN95		WIN98
	WINCE		WINME		WINNT
	WIN2K		WIN2K3		WINXP

	all these to define LINUX below ...

	2000
	CONECTIVA	COREL
	DEBIAN		DEFINITY
	INSIGNE
	KNOPPIX		KURUMIN
	LINDOWS		LINDOWSOS
	MOSIX		MSC
	RTLINUX
	SLACKWARE	STORM		SUSE
	TECH		TURBO

	LINUXPPC	YELLOWDOG	IMMUNIX		TRUSTIX		STAMPEDE	DEMOLINUX
	PEANUTLNX	ICEPACKLNX	ASPLINUX	LYCORIS		ENGARDESEC	VECTORLNX
	LIBRANET	JBLINUX		PLDLNXDSTR	KNOPPIX		GENTOOLNX	MINIRTL
	ELXLINUX	PHATLINUX	OWL			ZIPSLACK	SOTLINUX	ALTLINUX
	FREEDUC		BLACKRHINO	ASTAROSECURITYLINUX		TOPOLOGILINUX
	PLAMO		FEDORA

# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef SHORT_OS_NAMES

	CLD	CLDR	caldera
	HPX	HPUX	hp-ux
	KNP	KNPX	knoppix
	MDK	MDRK	mandrake
	RHT	RDHT	redhat
	SOL	SLRS	solaris

# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		MANDRAKE
#	define	LINUX
#	define	OPSYS			"MANDRAKE_LINUX"
# endif

# ifdef		REDHAT
#	define	LINUX
#	define	OPSYS			"REDHAT_LINUX"
# endif

# ifdef		UBUNTU
#	define	LINUX
#	define	OPSYS			"UBUNTU_LINUX"
#	define	HARDCOPY
/*
#	include <asm/termios.h>
*/
# endif

# ifdef		SUSE
#	define	LINUX
#	define	OPSYS			"SUSE_LINUX"
#	define	HARDCOPY
# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		FREEBSD
#	define	BSD
#	define	OPSYS			"FREEBSD"
# endif

# ifdef		NETBSD
#	define	BSD
#	define	OPSYS			"NETBSD"
# endif

# ifdef		OpenBSD
#	include <sys/filio.h>
#	define	OPENBSD
# endif

# ifdef		OPENBSD
#	define	BSD
#	define	OPSYS			"OPENBSD"
# endif

# ifdef		TRUSTEDBSD
#	define	BSD
#	define	OPSYS			"TRUSTEDBSD"
# endif

# include "absd.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		BCC55

#	define	DOS
#	define	far

# endif		/* BCC55 */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		TC2

#	define	DOS
#	define	ANSI
#	define	C_MKDIR
#	define	MEMLEFTOK
#	define	NONET

#	define	DIRSEP			'\\'	/* BACKSLASH */
#	define	MAINTYPE		void

#	define	lstat(X,Y)		stat(X,Y)

# endif		/* TC2 */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		DOS

#	define	OPSYS			"DOS"

# endif		/* DOS */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		MSVC

#	define	WIN32
#	define	ANSI
#	define	C_MKDIR
#	define	MEMLEFTOK
#	define	NONET

#	define	DIRSEP			'\\'	/* BACKSLASH */
#	define	MAINTYPE		void

#	define	lstat(X,Y)		stat(X,Y)

# endif		/* MSVC */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		WIN32

#	define	OPSYS			"WIN32"

# endif		/* WIN32 */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		AIX

#	define	OPSYS			"AIX"

#	define	ANYX
#	define	STRERROR
#	define	MEMLEFTOK
#	define	SYSVDIR
#	define	READ_COUNT
#	define	POSIX_MKDIR
#	define	MAINTYPE		int

#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	NONET

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

#	define	__H_LOCALEDEF

# endif		/* AIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		BOSX

# define	OPSYS			"BOSX"

# define	ANYX
# define	SYSVDIR
#	define	POSIX_MKDIR

# endif		/* BOSX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		HPUX

#	define	OPSYS			"HPUX"

#	define	ANYX
#	define	SYSVDIR
#	define	READ_COUNT
#	define	POSIX_MKDIR
/* #	define	C_MKDIR */
#	define	MAINTYPE		int
#	define	NONET
#	define	NOSTRICMP
#	define	NOMEMICMP

extern char *sys_errlist[];

# endif		/* HPUX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		LINUX

#	if ! defined (OPSYS)
#		define	OPSYS		"LINUX"
#	endif

#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	SYSVDIR

#	define	GCC

#	define	READ_COUNT
/* #	define	READ_DELAY	*/

#	define	NONET
#	define	LINUXIOCTLS
#	define	MAINTYPE		int

#	define	USE_TERMIOS
#	define	POSIX_MKDIR

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

# endif		/* LINUX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		CYGWIN

#	if ! defined (OPSYS)
#		define	OPSYS		"CYGWIN"
#	endif

#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	NOMEMICMP
#	define	SYSVDIR

#	define	GCC

#	define	READ_COUNT
#	define	FIONREAD	TIOCINQ

#	define	NONET
/*	#	define	LINUXIOCTLS	*/
#	define	MAINTYPE		int

#	define	NOSTRICMP
#	define	USE_TERMIOS
#	define	POSIX_MKDIR
#	define	HARDCOPY

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

#if __WORDSIZE == 64
typedef unsigned long uintptr_t;
#else
# if CCTGT != x86_64-pc-cygwin
typedef unsigned int uintptr_t;
# endif
#endif

# endif		/* CYGWIN */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		BSD

#	if ! defined (OPSYS)
#		define	OPSYS		"BSD"
#	endif

#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	SYSVDIR

#	define	GCC

#	define	READ_COUNT
/* #	define	READ_DELAY	*/

#	define	MAINTYPE		int

#	define	USE_TERMIOS
/*
#	define	C_MKDIR
*/
#	define	POSIX_MKDIR
#	define	NONET

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

# endif		/* BSD */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		SUNOS

#	define	OPSYS			"SUNOS"

#	define	SUNX
#	define	ANYX
#	define	SYSVDIR
#	define	USE_TERMIOS
#	define	READ_COUNT
#	define	C_MKDIR
#	define	NONET

/* #	include <sys/filio.h> */

# endif		/* SUNOS */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		SOLARIS

#	define	OPSYS			"SOLARIS"

#	define	SUNX
#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	USE_TLI
#	define	SYSVDIR
#	define	NOSTRICMP
#	define	NOMEMICMP
#	define	USE_TERMIOS
#	define	READ_DELAY
#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"
#	define	MAINTYPE		int
#	define	NONET

#	define	POSIX_MKDIR
#	ifdef COMMENT
#		define	C_MKDIR
#	endif	/* COMMENT */

# endif		/* SOLARIS */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		TRU64

# define	OPSYS			"TRU64"

# define	ANYX
# define	SYSVDIR
# define	C_MKDIR

# endif		/* TRU64 */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		DYNIX

# define	OPSYS			"DYNIX"

# define	ANYX
# define	SYSVDIR
# define	C_MKDIR

# endif		/* DYNIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		OSF1

# define	OPSYS			"OSF1"

# define	ANYX
# define	SYSVDIR
# define	C_MKDIR

# endif		/* OSF1 */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		UNICOS

# define	OPSYS			"UNICOS"

# define	ANYX
# define	SYSVDIR

# endif		/* UNICOS */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		IRIX

# define	OPSYS			"IRIX"

# define	ANYX
# define	SYSVDIR

# endif		/* IRIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		NEXTSTEP

# define	OPSYS			"NEXTSTEP"

# define	ANYX
# define	SYSVDIR

# endif		/* NEXTSTEP */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		OPENUNIX

# define	OPSYS			"OPENUNIX"

# define	ANYX
# define	SYSVDIR

# endif		/* OPENUNIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		RELIANTUNIX

# define	OPSYS			"RELIANTUNIX"

# define	ANYX
# define	SYSVDIR

# endif		/* RELIANTUNIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		ULTRIX

#	define	OPSYS			"ULTRIX"

#	define	ANYX
#	define	READ_COUNT
#	define	C_MKDIR

# endif		/* ULTRIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		SCOUNIX

# define	OPSYS			"SCO_UNIX"

# define	ANYX
# define	SYSVDIR

# endif		/* SCOUNIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		SCOXENIX

#	define	OPSYS			"SCO_XENIX"

typedef		unsigned short		mode_t ;

#	define	ANYX
#	define	SH_MKDIR
#	define	READ_DELAY
#	define	OLD_KEYNAMES
#	define	VRAMCOLOR
#	define	SYSULIMIT

#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	NONET

#	define	FIONREAD		FIORDCHK

#	define	lstat(X,Y)		stat(X,Y)

# endif		/* SCOXENIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		UNIXWARE

# define	OPSYS			"UNIXWARE"

# define	ANYX
# define	SYSVDIR

# endif		/* UNIXWARE */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		IUX

#	define	OPSYS			"INTERACTIVE"

#	define	ANYX
#	define	SYSVDIR

typedef		unsigned short		mode_t ;

# endif		/* IUX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		EDIX

# define	OPSYS		"EDIX"

# define	ANYX
# define	NO_STDLIB_H
# define	VOIDINT

# endif		/* EDIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		DIGIX

# define	OPSYS		"DIGIX"

# define	ANYX

# define	NO_STDLIB_H

# endif		/* DIGIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		SIDIX

# define	OPSYS		"SIDIX"

# define	ANYX

# define	NO_STDLIB_H
# define	VOIDINT

# endif		/* SIDIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		SIX

# define	OPSYS		"SIX"

# define	ANYX
# define	NO_STDLIB_H
# define	SYSVDIR

# endif		/* SIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef GCC
#	define	typeof			_type_of_
# else
#	if defined (SOLARIS) || defined (HPUX) || defined (AIX)
#		define	typeof			_type_of_
/*
#	else
*/
#	endif
# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef WHO_KNOWS /* ? */

	SCOODT	XINU	MINIX	QNX		OS2		SOX		(TANDEM)NSK

# endif /* WHO_CARES ? */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	libabc definitions ...						|
 *					|_______________________________________________|
 */

# ifdef		ANYX

# define	DIRSEP			'/'		/* SLASH */

# endif		/* ANYX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# include "params.h"

# ifdef		ANSI

#	define				OF(X)	X

# else		/* OLD */

#	define				OF(X)	()

# endif		/* ANSI */

# define	EVER		;;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef		NOVOID
#	define	void
# endif		/* NOVOID */

# ifdef		VOIDINT
#	define	void	int
# endif		/* VOIDINT */

# ifndef	SEEK_SET
# define	SEEK_SET			0
# endif		/* ! SEEK_SET */

# ifndef	SEEK_CUR
# define	SEEK_CUR			1
# endif		/* ! SEEK_CUR */

# ifndef	SEEK_END
# define	SEEK_END			2
# endif		/* ! SEEK_END */

# define	PTRSIZ			(sizeof(char *))

# define	XA_FATAL		0x4000
# define	XA_BANAL		0x2000

# define	COPYCRC			0x0001
# define	COPYBIN			0x0002
# define	COPYASC			0x0004

# define	CHRON_TIME

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef	X64BITS

typedef		long long		LONGINT ;

#	define	LIFMT			"%12lld"

# else	/* X32BITS */

typedef		long			LONGINT ;

#	define	LIFMT			"%12ld"

# endif /* X64BITS */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	operating system includes ...				|
 *					|_______________________________________________|
 */

# ifdef USE_SYSTYPES

#	include	<sys/types.h>

#	define	SYSTYPES		"^SYSTYPES"

# else

#	define	SYSTYPES		"~SYSTYPES"

# endif /* USE_SYSTYPES */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_MATH

#	include	<math.h>

#	define	MATH			"^MATH"

# else

#	define	MATH			"~MATH"

# endif /* USE_MATH */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDIO

#	include	<stdio.h>

#	define	STDIO			"^STDIO"

# else

#	define	STDIO			"~STDIO"

# endif /* USE_STDIO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDLIB

#	include	<stdlib.h>

#	define	STDLIB			"^STDLIB"

# else

#	define	STDLIB			"~STDLIB"

# endif /* USE_STDLIB */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_CTYPE

#	include	<ctype.h>

#	define	CTYPE			"^CTYPE"

# else

#	define	CTYPE			"~CTYPE"

# endif /* USE_CTYPE */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_ERRNO

#	include	<errno.h>

#	define	ERRNO			"^ERRNO"

# else

#	define	ERRNO			"~ERRNO"

# endif /* USE_ERRNO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_FCNTL

#	include	<fcntl.h>

#	define	FCNTL			"^FCNTL"

# else

#	define	FCNTL			"~FCNTL"

# endif /* USE_FCNTL */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_UNISTD

#	include	<unistd.h>

#	define	UNISTD		"^UNISTD"

# else

#	define	UNISTD		"~UNISTD"

# endif /* USE_UNISTD */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	libabc includes ...							|
 *					|_______________________________________________|
 */

# ifdef	USE_ABX

#	include	"abx.h"

#	define	STDABX			"+ABX"

# else

#	define	STDABX			"-ABX"

# endif	/* USE_ABX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef	USE_STDSTAT

#	include	"stdstat.h"

#	define	STDSTAT			"+STDSTAT"

# else

#	define	STDSTAT			"-STDSTAT"

# endif	/* USE_STDSTAT */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDTIME

#	include	"stdtime.h"

#	define	STDTIME			"+STDTIME"

# else

#	define	STDTIME			"-STDTIME"

# endif /* USE_STDTIME */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDHASH

#	include	"stdhash.h"

#	define	STDHASH			"+STDHASH"

# else

#	define	STDHASH			"-STDHASH"

# endif /* USE_STDHASH */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDMATCH

#	include "stdmatch.h"

#	define	STDMATCH		"+STDMATCH"

# else

#	define	STDMATCH		"-STDMATCH"

# endif /* USE_STDMATCH */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDASC

#	include "stdasc.h"

#	define	STDASC			"+STDASC"

# else

#	define	STDASC			"-STDASC"

# endif /* USE_STDASC */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDLOGIC

#	include "stdlogic.h"

#	define	STDLOGIC		"+STDLOGIC"

# else

#	define	STDLOGIC		"-STDLOGIC"

# endif /* USE_STDLOGIC */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDCOLOR

#	include "stdcolor.h"

#	define	STDCOLOR		"+STDCOLOR"

# else

#	define	STDCOLOR		"-STDCOLOR"

# endif /* USE_STDCOLOR */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDTYP

#	include "stdtyp.h"

#	define	STDTYP			"+STDTYP"

# else

#	define	STDTYP			"-STDTYP"

# endif /* USE_STDTYP */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDMATH

#	include	"stdmath.h"

#	define	STDMATH			"+STDMATH"

# else

#	define	STDMATH			"-STDMATH"

# endif /* USE_STDMATH */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDCMD

#	include "stdcmd.h"

#	define	STDCMD			"+STDCMD"

# else

#	define	STDCMD			"-STDCMD"

# endif /* USE_STDCMD */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDCAP

#	include "stdcap.h"

#	define	STDCAP			"+STDCAP"

# else

#	define	STDCAP			"-STDCAP"

# endif /* USE_STDCAP */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDWIN

#	include "stdwin.h"

#	define	STDWIN			"+STDWIN"

# else

#	define	STDWIN			"-STDWIN"

# endif /* USE_STDWIN */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDVIF

#	include "stdvif.h"

#	define	STDVIF			"+STDVIF"

# else

#	define	STDVIF			"-STDVIF"

# endif /* USE_STDVIF */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDKEY

#	include "stdkey.h"

#	define	STDKEY			"+STDKEY"

# else

#	define	STDKEY			"-STDKEY"

# endif /* USE_STDKEY */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDTIO

#	include "stdtio.h"

#	define	STDTIO			"+STDTIO"

# else

#	define	STDTIO			"-STDTIO"

# endif /* USE_STDTIO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDTERM

#	include "stdterm.h"

#	define	STDTERM			"+STDTERM"

# else

#	define	STDTERM			"-STDTERM"

# endif /* USE_STDTERM */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDBOX

#	include "stdbox.h"

#	define	STDBOX			"+STDBOX"

# else

#	define	STDBOX			"-STDBOX"

# endif /* USE_STDBOX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDLOG

#	include "stdlog.h"

#	define	STDLOG			"+STDLOG"

# else

#	define	STDLOG			"-STDLOG"

# endif /* USE_STDLOG */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDBUG

#	include "stdbug.h"

#	define	STDBUG			"+STDBUG"

# else

#	define	STDBUG			"-STDBUG"

# endif /* USE_STDBUG */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDPARM

#	include "stdparm.h"

#	define	STDPARM			"+STDPARM"

# else

#	define	STDPARM			"-STDPARM"

# endif /* USE_STDPARM */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDDIR

#	include "stddir.h"

#	define	STDDIR			"+STDDIR"

# else

#	define	STDDIR			"-STDDIR"

# endif /* USE_STDDIR */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDPATH

#	include "stdpath.h"

#	define	STDPATH			"+STDPATH"

# else

#	define	STDPATH			"-STDPATH"

# endif /* USE_STDPATH */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STRLIST

#	include "strlist.h"

#	define	STDLIST			"+STDLIST"

# else

#	define	STDLIST			"-STDLIST"

# endif /* USE_STRLIST */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDCRC

#	include "stdcrc.h"

#	define	STDCRC			"+STDCRC"

# else

#	define	STDCRC			"-STDCRC"

# endif /* USE_STDCRC */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDAPP

#	include "stdapp.h"

#	define	STDAPP			"+STDAPP"

# else

#	define	STDAPP			"-STDAPP"

# endif /* USE_STDAPP */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDLIC

#	include "stdlic.h"

#	define	STDLIC			"+STDLIC"

# else

#	define	STDLIC			"-STDLIC"

# endif /* USE_STDLIC */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDMISC

#	include "stdmisc.h"

#	define	STDMISC			"+STDMISC"

# else

#	define	STDMISC			"-STDMISC"

# endif /* USE_STDMISC */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDSTR

#	include	"stdstr.h"

#	define	STDSTR			"+STDSTR"

# else

#	define	STDSTR			"-STDSTR"

# endif /* USE_STDSTR */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDFILE

#	include	"stdfile.h"

#	define	STDFILE			"+STDFILE"

# else

#	define	STDFILE			"-STDFILE"

# endif /* USE_STDFILE */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDSIG

#	include "stdsig.h"

#	define	STDSIG			"+STDSIG"

# else

#	define	STDSIG			"-STDSIG"

# endif /* USE_STDSIG */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDMEM

#	ifdef	TC2

#		include	<mem.h>

#	endif	/* TC2 */

#	include "stdmem.h"

#	define	STDMEM			"+STDMEM"

# else  /* USE_SYSMEM */

#	ifdef USE_SYSMEM

#		define	xmalloc(s)		malloc(s)
#		define	xmcalloc(n,e)	calloc(n,e)
#		define	xmrealloc(p,s)	realloc(p,s)
#		define	xmfree(p)		free(p)

#	define	SYSMEM			"+SYSMEM"

#	else  /* USE_SYSMEM */

#	define	SYSMEM			"-SYSMEM"

#	endif /* USE_SYSMEM */

#	define	STDMEM			"-STDMEM"

# endif /* USE_STDMEM */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDMSG

#	include "stdmsg.h"

#	define	STDMSG			"+STDMSG"

# else

#	define	STDMSG			"-STDMSG"

# endif /* USE_STDMSG */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDNET

#	include "stdnet.h"

#	define	STDNET			"+STDNET"

# else

#	define	STDNET			"-STDNET"

# endif /* USE_STDNET */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDXFS

#	include "stdxfs.h"

#	define	STDXFS			"+STDXFS"

# else

#	define	STDXFS			"-STDXFS"

# endif /* USE_STDXFS */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDREX

#	include "stdrex.h"

#	define	STDREX			"+STDREX"

# else

#	define	STDREX			"-STDREX"

# endif /* USE_STDREX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef USE_STDXAR

#	include "stdxar.h"

#	define	STDXAR			"+STDXAR"

# else

#	define	STDXAR			"-STDXAR"

# endif /* USE_STDXAR */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# endif /* _ABC_H */

/*
 * vi:nu tabstop=4
 */
