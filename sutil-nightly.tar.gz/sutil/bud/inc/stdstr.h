
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdstr.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDSTR_H

# define _STDSTR_H

# include <string.h>

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *			strclone	OF ( (char *)								) ;
char *			stripeol	OF ( (char *)								) ;
char *			strlwr		OF ( (char *)								) ;
char *			strpad		OF ( (char *, int, int)						) ;
char *			strtrim		OF ( (char *, int)							) ;
char *			trimstr		OF ( (char *, int)							) ;
char *			struniq		OF ( (char *, int)							) ;
char *			strupr		OF ( (char *)								) ;
char *			strerr		OF ( (int)									) ;

int				strchop		OF ( (char *, char * *)						) ;
int				strclip		OF ( (char *, char * *, int)				) ;
int				streq		OF ( (char *, char *)						) ;
int				strfmt		OF ( (char *, char * /* , ... */)			) ;

void			lowstr		OF ( (char *)								) ;
void			padstr		OF ( (char *, int, int)						) ;
void			strchg		OF ( (char *, int, int)						) ;
void			strnchg		OF ( (char *, int, int, int)				) ;
void			uprstr		OF ( (char *)								) ;

# ifdef NOSTRSTR
char *			strstr		OF ( (char *, char *)						) ;
# endif /* NOSTRSTR */

# ifdef NOSTRICMP
int				stricmp		OF ( (char * , char *)						) ;
# endif /* NOSTRICMP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDSTR_H */

/*
 * vi:nu ts=4
 */
