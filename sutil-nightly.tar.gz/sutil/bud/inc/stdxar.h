
/*		 _______________________________________________________________
 *		|																|
 *		|	stdxar.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDXAR_H

# define _STDXAR_H

/*======================================================================*/
/*		data structures and types ...									*/
/*======================================================================*/

struct xarent {

	ULONG	xe_sign ;						/* header signature			*/
	long	xe_ctrl ;						/* control flags			*/
	char *	xe_name ;						/* native (original) name	*/
	char *	xe_nick ;						/* (possibly) adapted name	*/
	long	xe_osiz ;						/* original size			*/
	long	xe_psiz ;						/* (possibly) packed size	*/
	int		xe_meth ;						/* compression method		*/
	ULONG	xe_fcrc ;						/* full file crc			*/
	ULONG	xe_pcrc ;						/* packed data crc			*/
	long	xe_mtim ;						/* last modification time	*/
	long	xe_atim ;						/* last access time			*/
	long	xe_type ;						/* object type				*/
	long	xe_mode ;						/* access (protection)		*/
	char *	xe_usrn ;						/* owner username			*/
	char *	xe_grpn ;						/* group name				*/
	char *	xe_pswd ;						/* encrypted password		*/
	ULONG	xe_wcrc ;						/* password crc				*/
	ULONG	xe_kcrc ;						/* encrypted data crc		*/
	char *	xe_comm ;						/* comment					*/
	char *	xe_nosn ;						/* native o. s. name		*/
	char *	xe_nosv ;						/* native o. s. version		*/
	long	xe_auth ;						/* authenticity signature	*/

	long	xe_hbuf ;						/* header buffer			*/
	long	xe_hofs ;						/* header offset			*/
	long	xe_dofs ;						/* data offset				*/

# ifdef COMMENT
	int		xe_nlen ;						/* name length				*/
	int		xe_plen ;						/* password length			*/
	int		xe_clen ;						/* comment length			*/
# endif

} ;

typedef		struct xarent		XARENT ;

struct xardesc {

	char *		xd_name ;
	char *		xd_actx ;
	char *		xd_newx ;
	FILE *		xd_ifpx ;
	FILE *		xd_ofpx ;
	long		xd_ctrl ;					/* control flags			*/
	int			xd_type ;					/* collection type			*/
	XARENT *	xd_list ;					/* entry array				*/
	long		xd_size ;
	long		xd_mode ;
	long		xd_mtim ;
	int			xd_tent ;					/* total # of entries		*/
	int			xd_used ;					/* # of processed entries	*/
	long		xd_usiz ;					/* bytes processed			*/
} ;

typedef		struct xardesc		XAR ;

/*======================================================================*/
/*		symbolic constants ...											*/
/*======================================================================*/

# define	HDRFLDSEP			PIPE

# define	XARENTSIZ			sizeof(XARENT)

# define	EXTLEN					 4

# define	MAXHDRLEN			  4096
# define	MAXHDRFLD				64

# define	MADHDR				  0x0000
# define	KINHDR				  0x0001
# define	KITHDR				  0x0002
# define	XARHDR				  0x0004
# define	ZABHDR				  0x0008
# define	SPCHDR				  0x0010
# define	TARHDR				  0x0020
# define	CPIOHDR				  0x0040

			/*--------------------------------------------------*/
			/*		extensions ...								*/
			/*--------------------------------------------------*/

# define	KINEXT				".kin"
# define	XAREXT				".xar"
# define	ZABEXT				".zab"

# define	OLDEXT				".olx"
# define	NEWEXT				".nux"

# define	TAREXT				".tar"

# define	ZIPEXT				".zip"
# define	ARJEXT				".arj"

			/*--------------------------------------------------*/
			/*		bits in xd_ctrl & xarglops ...				*/
			/*--------------------------------------------------*/

# define	XAR_IO				  0x0000000fL

# define	XAR_READ			  0x00000001L
# define	XAR_WRITE			  0x00000002L
# define	XAR_RW				( XAR_READ | XAR_WRITE )

# define	XAR_OP				  0x0000ff00L

# define	XAR_ADD				( 0x00000100L | XAR_WRITE )
# define	XAR_BALANCE			( 0x00000200L | XAR_READ )
# define	XAR_CHECK			( 0x00000400L | XAR_RW )
# define	XAR_DELETE			( 0x00000800L | XAR_RW )
# define	XAR_FRESHEN			( 0x00001000L | XAR_RW )
# define	XAR_UPDATE			( 0x00002000L | XAR_RW )
# define	XAR_VIEW			( 0x00004000L | XAR_READ )
# define	XAR_EXTRACT			( 0x00008000L | XAR_READ )

# define	XAR_NEW				  0x00010000L
# define	XAR_VERBOSE			  0x00020000L
# define	XAR_STDERR			  0x00040000L
# define	XAR_STDOUT			  0x00080000L

			/*--------------------------------------------------*/
			/*		bits in xd_type ...							*/
			/*--------------------------------------------------*/

# define	XT_NONE				  0x0000
# define	XT_UNKNOWN			  0x1000

# define	XT_KIN				  0x0001
# define	XT_XAR				  0x0002
# define	XT_ZAB				  0x0004

# define	XT_TAR				  0x0010
# define	XT_CPIO				  0x0020

# define	XT_ZIP				  0x0100
# define	XT_ARJ				  0x0200

			/*--------------------------------------------------*/
			/*		miscellany ...								*/
			/*--------------------------------------------------*/

# define	XC_SOX				  0x0001	/* start of xar		*/
# define	XC_SOH				  0x0002	/* start of header	*/
# define	XC_SOD				  0x0004	/* start of data	*/

/*======================================================================*/
/*		function prototypes ...											*/
/*======================================================================*/

int				chkxarhdr		OF ( ( char * )							) ;
char *			chkxarnam		OF ( ( char * , int * )					) ;

void			clrxarent		OF ( ( XARENT * )						) ;
int				endxarent		OF ( ( XAR * )							) ;
XARENT *		getxarent		OF ( ( XAR * )							) ;
XAR *			setxarent		OF ( ( char * )							) ;
int				setxaropt		OF ( ( char * )							) ;

int				xarclose		OF ( ( XAR * )							) ;
void			xarerror		OF ( ( char * , char * )				) ;
int				xarlist			OF ( ( char * )							) ;
char *			xarname			OF ( ( char * , char * )				) ;
XAR *			xaropen			OF ( ( char * , long )					) ;
void			xaroption		OF ( ( long )							) ;
void			xarprint		OF ( ( char * , char * )				) ;
XARENT *		xarscan			OF ( ( XAR * )							) ;
void			xarshow			OF ( ( XARENT * )						) ;
void			xarpatterns		OF ( ( STRLISTCTRL * )					) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDXAR_H */

/*
 * vi:nu ts=4
 */
