/*
 *	from gnu readline and rsa md5 plus alternate configure
 */

#ifndef _PARAMS_H_

#define _PARAMS_H_

# if !defined (PARAMS)
#	if defined (__STDC__) || defined (__GNUC__) || defined (__cplusplus)
#		define PARAMS(protos) protos
#	else
#		if defined (PROTOTYPES)
#			define PARAMS(protos) protos
#		else
#			define PARAMS(protos) ()
#		endif
#	endif
# endif

#endif  /* _PARAMS_H_ */

/*
 * vi:nu ts=4
 */
