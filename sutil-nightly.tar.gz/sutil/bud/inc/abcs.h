
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*	
 *	abcs.h (C compilation environment sniffer)
 */

/*___________________________________________________________________________*/

# if ( defined (__unix) || defined (__unix__) || defined (unix) )
#	define	UNIX
# endif /* __unix */

# if ( defined (__SVR4) || defined (__svr4__) )
#	define	SVR4
# endif /* __SVR4 */

/*___________________________________________________________________________*/

# if ( defined (linux) || defined (__linux) || defined (__linux__) )
#	define	LINUX
# endif /* linux */

/*___________________________________________________________________________*/

# if ( defined (__CYGWIN__) || defined (__CYGWIN32__) )
#	define	CYGWIN
# endif /* CYGWIN */

/*___________________________________________________________________________*/

# if ( defined (__hpux) || defined (__hppa) || defined (_HPUX_SOURCE) )
#	define	HPUX
# endif /* __hpux */

/*___________________________________________________________________________*/

# if ( defined (sun) || defined (sparc) || defined (__sun) || defined (__sparc) || defined (__sun__) || defined (__sparc__) )
#	define	SUNX
# endif /* SUNX */

/*___________________________________________________________________________*/

# if ( defined (__FreeBSD__) )
#	define	BSD
#	define	FREEBSD
# endif /* __FreeBSD__ */

/*___________________________________________________________________________*/

# if ( defined (__APPLE__) )
#	define	APPLE
# endif /* _aix */

/*___________________________________________________________________________*/

# if ( defined (_aix) )
#	define	AIX
# endif /* _aix */

#ifdef COMMENT
# include <sys/dir.h>
# if ( defined (AIX_DIRSIZ) )
#  define	AIX
# endif /* _aix */
#endif /* COMMENT */

# include <unistd.h>
# if ( defined (_CS_AIX_ARCHITECTURE) )
#	define	AIX
# endif /* _aix */

# include "absd.h"

/*___________________________________________________________________________*/

/*
 * vi:nu ts=4
 */
