
/*		 _______________________________________________________________
 *		|																|
 *		|	strlist.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STRLIST_H

# define _STRLIST_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

struct	listelm {
	int			le_pos ;
	char *		le_ptr ;
} ;

typedef		struct listelm			LISTELM ;

struct	strlistctrl {
	char *		slc_nam ;		/*	list id								*/
	int			slc_max ;		/*	max entries (phys.len)				*/
	int			slc_tot ;		/*	used entries (log.len)				*/
	int			slc_cur ;		/*	current entry						*/
	int			slc_inx ;		/*	insertion point						*/
	int			slc_flg ;		/*	mode bits							*/
	LISTELM *	slc_vec ;		/*	the list itself						*/
} ;

typedef		struct strlistctrl		STRLISTCTRL ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	LISTELMSIZ			(sizeof(LISTELM))
# define	STRLISTCTRLSIZ		(sizeof(STRLISTCTRL))

# define	LM_GET				0x8000
# define	LM_SET				0x4000
# define	LM_ON				0x2000
# define	LM_OFF				0x1000

# define	LM_SORT				0x0001		/* OFF = unsorted			*/
# define	LM_ASCEND			0x0002		/* OFF = DESCENDING			*/
# define	LM_STACK			0x0004		/* pos , descending			*/
# define	LM_QUEUE			0x0008		/* pos , ascending			*/

# define	LM_UNIQ				0x0010		/* OFF = DUPLICATED			*/
# define	LM_WRAP				0x0020		/* OFF = AUTO_EXPAND		*/
# define	LM_VONLY			0x0040		/* OFF = PICKABLE			*/
# define	LM_SAVE				0x0080		/* OFF = NOTSAVEABLE		*/

# define	LM_RAW				0x0100		/* OFF = COOKED				*/
# define	LM_TAB				0x0200		/* EXPAND TABS to spaces	*/
# define	LM_MAP				0x0400		/* map NON-printable chrs	*/

# ifdef NOWRAP

# define	LM_DEFAULT			(LM_RAW|LM_SORT|LM_ASCEND|LM_UNIQ)

# define	DFL_MAXSTRLSTSIZ			0

# else  /* WRAP */

# define	LM_DEFAULT			(LM_RAW|LM_SORT|LM_ASCEND|LM_UNIQ|LM_WRAP)

# define	DFL_MAXSTRLSTSIZ		 4096

# endif /* NOWRAP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STRLISTCTRL *	alocstrlist		OF ( ( char * , int )					) ;
STRLISTCTRL *	makestrlist		OF ( ( char * , int )					) ;
STRLISTCTRL *	currstrlist		OF ( ( void )							) ;
void			freestrlist		OF ( ( STRLISTCTRL * )					) ;

int				pickstrlist		OF ( ( STRLISTCTRL * )					) ;
int				modestrlist		OF ( ( int , int )						) ;
int				sortstrlist		OF ( ( void )							) ;

int				fputstrlist		OF ( ( FILE * , STRLISTCTRL * )			) ;
int				fgetstrlist		OF ( ( FILE * , STRLISTCTRL * * )		) ;
int				savestrlist		OF ( ( char * )							) ;
int				loadstrlist		OF ( ( char * )							) ;
int				feedstrlist		OF ( ( char * )							) ;
int				killstrlist		OF ( ( int )							) ;

char *			viewstrvect		OF ( ( char * * , char * )				) ;
char *			viewstrfile		OF ( ( char * , char * )				) ;
char *			viewstrlist		OF ( ( char * )							) ;

char *			peekstrlist		OF ( ( char * , int )					) ;
char *			prevstrlist		OF ( ( char * )							) ;
char *			nextstrlist		OF ( ( char * )							) ;
int				findstrlist		OF ( ( char * )							) ;
int				matchstrlist	OF ( ( char * )							) ;

# ifdef TC3
#	ifdef BCC55
int				compstrlist		OF ( ( LISTELM * , LISTELM * )			) ;
#	else
int				compstrlist		OF ( ( const void * , const void * )	) ;
#	endif
# else
#	ifdef OLD
int				compstrlist		OF ( ( char * * , char * * )			) ;
#	else
int				compstrlist		OF ( ( LISTELM * , LISTELM * )			) ;
#	endif
# endif

void			dispnorm		OF ( ( char * )							) ;
void			disprev			OF ( ( char * )							) ;
char *			prepout			OF ( ( int , char * )					) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STRLIST_H */

