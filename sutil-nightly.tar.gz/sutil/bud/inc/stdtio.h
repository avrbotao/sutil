
# ifdef ANYX

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

#	ifdef	USE_TERMIOS

#		ifdef LINUX
#			include <asm/termios.h>
#		else
#			include <termios.h>
#		endif

#		ifdef CYGWIN
#			include <termios.h>
#			ifdef READ_COUNT
#				include <asm/socket.h>
#			endif
#		endif

#		define	C_CC_SIZE	NCCS

typedef		struct termios	TERMIO ;

#	else	/* TERMIO */

#		include <termio.h>

#		define	C_CC_SIZE	NCC

typedef		struct termio	TERMIO ;

#	endif	/* USE_TERMIOS */

#	ifdef	LINUXIOCTLS
#		include <asm/ioctls.h>
#	endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* ANYX */

void	getscrsiz		OF ( (int *, int *)							) ;
int		resetmode		OF ( (TERMIO *)								) ; 
int		origmode		OF ( (void)									) ; 
int		workmode		OF ( (void)									) ; 

/*
 * vi:tabstop=4
 */
