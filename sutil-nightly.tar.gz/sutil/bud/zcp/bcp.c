
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	bcp									better cp	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1997-2006			alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"bcp"
# define	VERSION			"1.2"
# define	VERCODE			"261"
# define	VERDATE			"2006.08.14"
# define	VERSIGN			"Alexandre Botao"

/*		 _______________________________________________________________
 *		|																|
 *		|	includes & operational definitions ...						|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO
# define	USE_STDLIB

# define	USE_SYSTYPES

# define	USE_STDASC
# define	USE_STDAPP
# define	USE_STDPARM
# define	USE_STDLOGIC

# define	USE_STDSTR
# define	USE_STDTYP
# define	USE_STDDIR
# define	USE_STDMISC
# define	USE_STDMEM
# define	USE_STDSTAT

# include	"abc.h"

/*		 _______________________________________________________________
 *		|																|
 *		|	application-specific definitions & data prototypes ...		|
 *		|_______________________________________________________________|
 */

# define	DFLBUFFSIZE		4194304

/*		 _______________________________________________________________
 *		|																|
 *		|	globcp variables ...										|
 *		|_______________________________________________________________|
 */

# ifdef DOS

unsigned	_stklen  = 16384 /* 8192 */ ;

# endif /* DOS */

int			bufsizeflag = FALSE ;
int			recurseflag = FALSE ;
int			mockrunflag = FALSE ;
int			verboseflag = FALSE ;

char *	cmdsbuff ;
char *	destpath ;
char *	origbuff ;
char *	destbuff ;

int		origlen ;

int		buffsize = DFLBUFFSIZE ;

FILE *	bsfp = NULL ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include "stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-b buffer_size] [-vELNV?] arq1 arq2 \n\n",
	"  ou : ", VERNAME, " [-b buffer_size] [-rvELNV?] dir1 dir2 \n\n",
	"  ou : ", VERNAME, " [-b buffer_size] [-vELNV?] arq1 ... arqN dir \n\n",

	"  -N : informa sem copiar \n",
	"  -b : tamanho do buffer \n",
	"  -r : pesquisa diretorios recursivamente \n",
	"  -v : mostra informacoes adicionais \n",

# include "stdflag.h"

	NULL
} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

PARMINFO	parminfo [] = {

	{ 'N',	&mockrunflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'b',	&buffsize,		NULL,		PI_SETNUM,		0				} ,
	{ 'r',	&recurseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'v',	&verboseflag,	NULL,		PI_SETVAL,		TRUE			} ,

# include "deflbits.h"

} ;

/*		 _______________________________________________________________
 *		|																|
 *		|	function prototypes ...										|
 *		|_______________________________________________________________|
 */

void	bcpdir		OF ( ( char * , char * )			) ;
void	bcpeqv		OF ( ( char * , char * )			) ;
void	bcpfil		OF ( ( char * , char * )			) ;
int		copfil		OF ( ( char * , char * )			) ;

void	chkhlp		OF ( ( void )						) ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	main, prologue, epilogue, parms	...							|
 *		|_______________________________________________________________|
 */

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	setargent (argc, argv) ;

	parseargs () ;

	prologue () ;

	drudgery () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	parsebits () ;

	sortargsflag = FALSE ;

	if ( ( origbuff = (char *) xmalloc (buffsize) ) == NULL ) {
		fprintf (stderr, "bcp: no memory for buffer 1 \n") ;
		exit (2) ;
	}

	if ( ( destbuff = (char *) xmalloc (buffsize) ) == NULL ) {
		fprintf (stderr, "bcp: no memory for buffer 2 \n") ;
		exit (2) ;
	}

	if ( ( destpath = (char *) xmalloc (4096) ) == NULL ) {
		fprintf (stderr, "bcp: no memory for buffer 3 \n") ;
		exit (2) ;
	}

	if ( ( cmdsbuff = (char *) xmalloc (8192) ) == NULL ) {
		fprintf (stderr, "bcp: no memory for buffer 4 \n") ;
		exit (2) ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	endargent () ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	SETBIT (flagbits, PI_SYNTAXBIT) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void chkhlp () {

	if ( ! ( flagbits & PI_SYNTAXBIT ) )
		cmdsyn () ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	the application itself ...									|
 *		|_______________________________________________________________|
 */

void drudgery () {

	register char * origin , * target ;
	register int typ1, typ2 , j ;

	if (totparms < 2) {
		fprintf (stderr, "bcp: too few parameters \n") ;
		chkhlp () ;
		return ;
	}

	if (totparms == 2) {

		/* file-pair, dir-pair, or file-to-dir copy */

		origin = getargent () ;
		target = getargent () ;
		typ1   = filetype (origin) ;
		typ2   = filetype (target) ;

		if ( typ1 == 'd' && typ2 == 'd' ) {			/* dir pair */

			if (recurseflag)
				origlen = strlen (origin) ;

			bcpdir (origin, target) ;

		} else if ( typ1 == 'f' && typ2 == 'f' ) {	/* file pair */

			bcpfil (origin, target) ;

		} else if ( typ1 == 'f' && typ2 == 'd' ) {	/* file to dir */

			bcpeqv (origin, target) ;

		} else {

			fprintf (stderr, "bcp: can't copy dir to file \n") ;
			chkhlp () ;
			return ;
		}

	} else {

		/* many-files-to-dir copy */

		j = totparms - 1 ;
		target = getargpos (j) ;
		typ2   = filetype (target) ;

		if ( typ2 != 'd' ) {
			fprintf (stderr, "bcp: last name is not a dir \n") ;
			chkhlp () ;
			return ;
		}

		while (j--) {
			origin = getargent () ;
			typ1   = filetype (origin) ;

			if ( typ1 == 'f' )
				bcpeqv (origin, target) ;
			else
				printf ( "bcp: can't access file %s\n", origin ) ;
		}
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	copy two directories ...									|
 *		|_______________________________________________________________|
 */

void bcpdir (origdir, destdir) char * origdir , * destdir ; {

	register char * np ;
	register DIRDES * ddp ;
	register DIRENT * dep ;
	char	 origpath [1024] ;

	ddp = OpenDir (origdir) ;

	if ( ddp == NULL ) {
		printf ("bcp: can't open %s\n", origdir) ;
		return ;
	}

	while ( (dep = ReadDir (ddp)) != NULL ) {

		np = dep->d_name ;

		if ( dotdir (np) )
			continue ;

		sprintf (origpath, "%s%c%s", origdir, DIRSEP, np) ;

		if ( ( filetype ( origpath ) == T_DIR ) && recurseflag )
			bcpdir (origpath, destdir) ;
		else
			bcpeqv (origpath, destdir) ;
	}

	CloseDir (ddp) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	copy a file to its equivalent on a dir ...					|
 *		|_______________________________________________________________|
 */

void bcpeqv (origfil, destdir) char * origfil , * destdir ; {

	if (recurseflag)
		sprintf (destpath, "%s%c%s", destdir, DIRSEP, origfil+origlen+1) ;
	else
		sprintf (destpath, "%s%c%s", destdir, DIRSEP, lastname (origfil)) ;

	bcpfil (origfil, destpath) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	copy two files ...											|
 *		|_______________________________________________________________|
 */

void bcpfil (origfil, destfil) char * origfil , * destfil ; {

	sbit64 bytesread , filesize = 0 , filebytes = (sbit64) 0 ;
	register FILE * fp1 , * fp2 ;

	if ( mockrunflag ) {
		printf ("copying %s to %s\n", origfil, destfil) ;
		return ;
	}

	if ( ( fp1 = fopen (origfil, "rb") ) == NULL ) {
		return ;
	}

	if ( ( fp2 = fopen (destfil, "wb") ) == NULL ) {
		fclose (fp1) ;
		return ;
	}

	if ( verboseflag ) {
		printf ("copying {%s} to {%s}\n", origfil, destfil) ;
		filesize = bytesof ( statof (origfil) ) ;
		ptrel64 (filebytes, filesize, 0) ;
	}

	while ( ( bytesread = fread (origbuff, 1, buffsize, fp1) ) > 0 ) {
		fwrite (origbuff, 1, bytesread, fp2) ;
		if ( verboseflag ) {
			filebytes += bytesread ;
			ptrel64 (filebytes, filesize, 0) ;
		}
	}

	fclose (fp1) ;
	fclose (fp2) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/* cc -DCYGWIN -DLABIX -Wall -Wextra -O3 -o bcp bcp.c stdmem.c stdmisc.c stddir.c stdapp.c stdparm.c stdfile.c stdlic.c stdcrc.c stdstat.c */

/*
 * vi:nu tabstop=4
 */
