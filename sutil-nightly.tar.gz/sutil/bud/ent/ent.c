
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   ent                            tree shepherd   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'ENT' ("the tree shepherd")                     |
 | as released by Alexandre Botao <botao.org> ;                         |
 |                                                                      |
 | 'ENT' is Free and Open Source Software (FOSS). This means you can    |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'ENT' is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'ENT'.  If not, see <http://www.gnu.org/licenses/>, or    |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# define	SWNAME			"ent"
# define	SWVERS			"0.0.46"
# define	SWFORG			"$"						/*	"$" = stable	*/
# define	SWDATE			"2014/12/07"
# define	SWDESC			"directory tree manager"
# define	SWTAGS			"directory,tree,manager,explorer,file,filesystem,folder,viewer,administration,host,net,network,remote,local"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	_XOPEN_SOURCE	500

#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

# include "configure.h"
# include "astdint.h"

#include <unistd.h>

#include <sys/time.h>
#include <sys/resource.h>

#include "growtab.h"

/*________________________________________________________________________
*/

# ifdef HPUX
#       define  STAT            stat64
#       define  LSTAT           lstat64
# else
#       define  STAT            stat
#       define  LSTAT           lstat
# endif

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

# ifdef	ENTSTAT

struct entstat {
	dev_t		es_dev ;		/*	ID of device containing file		*/
	ino_t		es_ino ;		/*	inode number						*/
	mode_t		es_mode ;		/*	protection							*/
	nlink_t		es_nlink ;		/*	number of hard links				*/
	uid_t		es_uid ;		/*	user ID of owner					*/
	gid_t		es_gid ;		/*	group ID of owner					*/
	dev_t		es_rdev ;		/*	device ID (if special file)			*/
	off_t		es_size ;		/*	total size, in bytes				*/
	blksize_t	es_blksize ;	/*	blocksize for filesystem I/O		*/
	blkcnt_t	es_blocks ;		/*	number of 512B blocks allocated		*/
	time_t		es_atime ;		/*	time of last access					*/
	time_t		es_mtime ;		/*	time of last modification			*/
	time_t		es_ctime ;		/*	time of last status change			*/
};

# endif /* ENTSTAT */

typedef		struct STAT			STABUF ;

# define	ENTSTAT
# define	FEWSTAT

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct ent_info {
	char *		ei_full ;		/*	full pathname						*/
	int			ei_flen ;		/*	full pathname length				*/
	int			ei_deep ;		/*	depth								*/
	int			ei_base ;		/*	base name offset					*/
	char *		ei_name ;		/*	base name							*/
# ifdef		ENTSTAT
	STABUF *	ei_stat ;		/*	full stat							*/
# endif		/* ENTSTAT */
# ifdef		FEWSTAT
	off_t		ei_size ;		/*	stat size							*/
	time_t		ei_time ;		/*	stat time							*/
	mode_t		ei_mode ;		/*	stat mode							*/
# endif		/* FEWSTAT */
	int			ei_flag ;		/*	nftw flags							*/
	int			ei_prop ;		/*	properties							*/
	int			ei_code ;		/*	unique reference					*/
} ;

typedef		struct ent_info		ENT_INFO ;

# define	ENT_INFO_SIZE		sizeof(ENT_INFO)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct top_info {
	char *			ti_name ;	/* rewt						*/
	int				ti_size ;	/* # of entries				*/
	int				ti_used ;	/* used entries				*/
	ENT_INFO * *	ti_list ;
} ;

typedef		struct top_info		TOP_INFO ;

# define	TOP_INFO_SIZE		sizeof(TOP_INFO)

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

typedef		struct rlimit		RLIMITBUF ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	TEMPBUFFSIZE		1048576

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	FPCT(P,T)			( ( (float)P / (float)T ) * ( float)100.0 )
# define	XOR(A,B)			( ( (! (A)) && (B) ) || ( (! (B)) && (A) ) )

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

int				allflag			= 0 ;
int				bigflag			= 0 ;
int				dumpflag		= 0 ;
int				errorsflag		= 0 ;
int				followflag		= 0 ;
int				helpflag		= 0 ;
int				cramflag		= 0 ;
int				mountflag		= 0 ;
int				reportflag		= 0 ;
int				summaryflag		= 0 ;
int				syntaxflag		= 0 ;
int				totalflag		= 0 ;
int				treeflag		= 0 ;
int				verboseflag		= 0 ;
int				versionflag		= 0 ;

int				growtabflags	= 0 ;

int				topcount		= 0 ;
int				ntwflags		= FTW_PHYS ;

int				grd				= 0 ;		/*	general result descriptor	*/

RLIMITBUF		rlimbuf ;

size_t			maxdepth		= 1024 ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

long long		   regbytes		= 0 ;
long long		totregbytes		= 0 ;
long long		   regcount		= 0 ;
long long		totregcount		= 0 ;
long long		   dirbytes		= 0 ;
long long		totdirbytes		= 0 ;
long long		   dircount		= 0 ;
long long		totdircount		= 0 ;

long long		   sylbytes		= 0 ;
long long		totsylbytes		= 0 ;
long long		   sylcount		= 0 ;
long long		totsylcount		= 0 ;

long long		   dnrcount		= 0 ;
long long		totdnrcount		= 0 ;
long long		   nspcount		= 0 ;
long long		totnspcount		= 0 ;
long long		   bslcount		= 0 ;
long long		totbslcount		= 0 ;

long long		   allbytes		= 0 ;
long long		totallbytes		= 0 ;
long long		   allcount		= 0 ;
long long		totallcount		= 0 ;

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

void	growtab ( char * * * tableptr , int * tablesiz , int elemsize , int pilesize , int growflag ) ;

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

# define	MAXLEV		8

char	verbullet [MAXLEV] = { '-' ,  '+' ,  '#' ,  '@' ,  '%' ,  '$' ,  '*' ,  '*' } ;

void ent_verb (
				int				level		,
				char *			label		,
				char *			compl
) {
	if ( verboseflag >= level ) {
		printf ("%c %s", verbullet[level%MAXLEV], label) ;
		if ( compl != NULL ) {
			printf (" (%s)\n", compl) ;
		}
		printf ("\n") ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int				bunchsize		= 1024 ;

int				entinftabused	= 0 ;
int				entinftabsize	= 0 ;

ENT_INFO * *	entinftab		= NULL ;

ENT_INFO * neweip () {

# ifdef BIGROW
	if ( entinftabused == entinftabsize ) {
# else  /* BIGROW */
	if ( ( entinftabused % bunchsize ) == 0 ) {
# endif /* BIGROW */
		if ( verboseflag >= 2 ) {
			fprintf (stderr, "eused=%d\n", entinftabused) ;
			fflush (stderr) ;
		}
		growtab ( (char * * *) &entinftab , &entinftabsize , ENT_INFO_SIZE , bunchsize , growtabflags ) ;
	}

	return entinftab[entinftabused++] ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

TOP_INFO *		tip				= NULL ;

int				topinftabused	= 0 ;
int				topinftabsize	= 0 ;

TOP_INFO * *	topinftab		= NULL ;

TOP_INFO * newtip () {

	if ( ( topinftabused % bunchsize ) == 0 ) {
		if ( verboseflag >= 2 ) {
			fprintf (stderr, "tused=%d\n", topinftabused) ;
			fflush (stderr) ;
		}
		growtab ( (char * * *) &topinftab , &topinftabsize , TOP_INFO_SIZE , bunchsize , growtabflags ) ;
	}

	return topinftab[topinftabused++] ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void ent_dump () {
	register	int				i			;
	register	int				tflag		;
	register	ENT_INFO *		eip			;

	if ( cramflag == 0 ) {
		return ;
	}

	for ( i = 0 ; i < entinftabused ; ++i ) {
		if ( verboseflag >= 3 ) {
			printf ( "%d;", i ) ;
		}
		eip = entinftab[i] ;
		tflag = eip->ei_flag ;
		if ( tflag == FTW_D || allflag )
			printf ( "\"%s\";\"%s\";%jd;\"%s\"\n",
				(tflag == FTW_D)	? "d"	:
				(tflag == FTW_DNR)	? "dnr"	:
				(tflag == FTW_DP)	? "dp"	:
				(tflag == FTW_F)	? "f"	:
				(tflag == FTW_NS)	? "ns"	:
				(tflag == FTW_SL)	? "sl"	:
				(tflag == FTW_SLN)	? "sln"	:
				"???",
				eip->ei_name,
				(intmax_t) eip->ei_size,
				eip->ei_full
			) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void ent_save (									/*	on-disk record			*/
) {
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# ifdef ENT_MIND

void ent_cram (									/*	in-core record			*/
	const		char *			fpath		,
	const		struct STAT *	sb			,
				int				tflag		,
				struct FTW *	ftwbuf
) {
	register	ENT_INFO *		eip			;
}

# endif /* ENT_MIND */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

static int ent_walk (
	const		char *			fpath		,
	const		struct STAT *	sb			,
				int				tflag		,
				struct FTW *	ftwbuf
) {
	register	int				i			;
	register	int				deep		;
	register	long long		size		;
	register	ENT_INFO *		eip			;
	register	char *			tp			;

	deep = 1 + ftwbuf->level ;
	size = sb->st_size ;

	++allcount ;
	allbytes += size ;

	if ( errorsflag ) {
		if ( tflag == FTW_DNR ) {
			dnrcount++ ;
		}
		if ( tflag == FTW_NS ) {
			nspcount++ ;
		}
		if ( tflag == FTW_SLN ) {
			bslcount++ ;
		}
	}

	if ( reportflag ) {
		if ( tflag == FTW_SL ) {
			sylbytes += size ;
			sylcount++ ;
		}
	}

	if ( summaryflag ) {
		if ( tflag == FTW_F ) {
			regbytes += size ;
			regcount++ ;
		}
		if ( tflag == FTW_D ) {
			dirbytes += size ;
			dircount++ ;
		}
	}

	if ( cramflag ) {
		eip = neweip () ;
		if ( eip == NULL ) {
			fprintf (stderr, "failed to cram #%lld (%s)\n", allcount, fpath) ;
			return -1 ;
		}
		tp = strdup (fpath) ;
		if ( tp == NULL ) {
			fprintf (stderr, "failed to dup #%lld (%s)\n", allcount, fpath) ;
			return -1 ;
		}
		eip->ei_full = tp ;
		eip->ei_deep = deep ;
		eip->ei_base = ftwbuf->base ;
		eip->ei_name = eip->ei_full + eip->ei_base ;
		eip->ei_flag = tflag ;
		eip->ei_mode = sb->st_mode ;
		eip->ei_size = size ;
		eip->ei_time = sb->st_mtime ;
	}

	if ( treeflag ) {
		if ( tflag == FTW_D || allflag ) {
			if ( verboseflag >= 4 )
				printf ( "%d\t%d" , tflag , deep ) ;
			for ( i = 0 ; i < deep ; ++i )
				putchar ('\t') ;
			printf ( "%s\n" , fpath + ftwbuf->base /* eip->ei_name */ ) ;
		}
	}

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void	walk_tots () {
}

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

void	show_vers () {
	printf ( "%s %s %s\n" , SWNAME , SWVERS , SWDATE ) ;
	exit (0) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void	wipe_errs () {
	dnrcount = nspcount = bslcount = 0 ;
}

void	wipe_reps () {
	sylbytes = sylcount = 0 ;
}

void	wipe_sums () {
	regbytes = dirbytes = regcount = dircount = 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void	show_tots () {

	if ( reportflag ) {
		printf ( "%s has %lld bytes in %lld symlinks\n" , "total" , totsylbytes , totsylcount ) ;
	}

	if ( summaryflag ) {
		printf ( "%s has %lld bytes in %lld files\n" , "total" , totregbytes , totregcount ) ;
		printf ( "%s has %lld bytes in %lld directories\n" , "total" , totdirbytes , totdircount ) ;
	}

	if ( errorsflag ) {
		printf ( "%s has %lld unreadable directories\n" , "total" , totdnrcount ) ;
		printf ( "%s has %lld unstatable pathnames\n" , "total" , totnspcount ) ;
		printf ( "%s has %lld broken symlinks\n" , "total" , totbslcount ) ;
	}

	printf ( "%s has %lld bytes in %lld objects\n" , "total" , (long long)totallbytes , totallcount ) ;
}

void	show_errs ( name ) char * name ; {		/*	FTW_DNR , FTW_NS , FTW_SLN	*/

	if ( name == NULL )
		name = "<unknown>" ;

	printf ( "%s has %lld unreadable directories\n" , name , dnrcount ) ;
	printf ( "%s has %lld unstatable pathnames\n" , name , nspcount ) ;
	printf ( "%s has %lld broken symlinks\n" , name , bslcount ) ;

	wipe_errs () ;
}

void	show_reps ( name ) char * name ; {

	if ( name == NULL )
		name = "<unknown>" ;

	printf ( "%s has %lld bytes in %lld symlinks\n" , name , sylbytes , sylcount ) ;

	wipe_reps () ;
}

void	show_sums ( name ) char * name ; {

	if ( name == NULL )
		name = "<unknown>" ;

	printf ( "%s has %lld bytes in %lld files\n" , name , regbytes , regcount ) ;
	printf ( "%s has %lld bytes in %lld directories\n" , name , dirbytes , dircount ) ;

	wipe_sums () ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void	save_errs () {
	totdnrcount += dnrcount ;
	totnspcount += nspcount ;
	totbslcount += bslcount ;
}

void	save_reps () {
	totsylbytes += sylbytes ;
	totsylcount += sylcount ;
}

void	save_sums () {
	totregbytes += regbytes ;
	totdirbytes += dirbytes ;
	totregcount += regcount ;
	totdircount += dircount ;
}

void	save_tots () {
	totallcount += allcount ;
	totallbytes += allbytes ;
	if ( errorsflag )
		save_errs () ;
	if ( reportflag )
		save_reps () ;
	if ( summaryflag )
		save_sums () ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

int ent_scan (
				char *	name
) {
				int		rd = -1 ;

	if ( name == NULL )
		return rd ;

	ent_verb (1, "scan", name) ;

	if ( cramflag ) {
		if ( ( tip = newtip () ) == NULL )
			return rd ;
		else
			tip->ti_name = strdup (name) ;

		/*	prep per-top stuff	*/

	}

# ifdef HPUX
	if ( ( rd = nftw64 ( name, ent_walk, maxdepth, ntwflags ) ) == -1 )
# else
	if ( ( rd = nftw ( name, ent_walk, maxdepth, ntwflags ) ) == -1 )
# endif /* HPUX */
		perror("nftw") ;

	if ( totalflag )
		save_tots () ;

	if ( reportflag )
		show_reps ( name ) ;

	if ( summaryflag )
		show_sums ( name ) ;

	if ( errorsflag )
		show_errs ( name ) ;

	printf ( "%s has %lld bytes in %lld objects\n" , name , allbytes , allcount ) ;
	allcount = 0 ;
	allbytes = 0 ;

	return rd ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	MAXNOT		1024

int		noteused = 0 ;

char *	notelist [MAXNOT] ;

void ent_note (
				char * name
) {
	if ( verboseflag >= 2 )
		printf ("# note (%s)\n", name) ;
	notelist [ noteused++ % MAXNOT ] = strdup (name) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int ent_march () {
	int i ;

	for ( i = 0 ; i < noteused ; ++i ) {
		if ( verboseflag >= 2 )
			printf ("# march (%s)\n", notelist[i]) ;
		ent_scan ( notelist[i] ) ;
	}

	if ( totalflag ) {
		if ( cramflag ) {
			walk_tots () ;
		}
		show_tots () ;
	}

	return grd ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int ent_end () {

	if ( dumpflag )
		ent_dump () ;

	return grd ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void usage (
	char *	name
) {
	fprintf (stderr, "Usage: %s [-aBDehlmMrstTvV?] [-d dir] [dir [...]]\n", name) ; 
	fprintf (stderr, "  -a       list all non-directory entries\n") ;
	fprintf (stderr, "  -B       optimize for big trees\n") ;
	fprintf (stderr, "  -d dir   scan <dir>\n") ;
	fprintf (stderr, "  -D       dump (implies -M)\n") ;
	fprintf (stderr, "  -e       errors\n") ;
	fprintf (stderr, "  -h       show help\n") ;
	fprintf (stderr, "  -l       follow symbolic links\n") ;
	fprintf (stderr, "  -m       mount point confinement\n") ;
	fprintf (stderr, "  -M       store in memory\n") ;
	fprintf (stderr, "  -r       report\n") ;
	fprintf (stderr, "  -s       summary\n") ;
	fprintf (stderr, "  -t       total\n") ;
	fprintf (stderr, "  -T       tree\n") ;
	fprintf (stderr, "  -v       verbose\n") ;
	fprintf (stderr, "  -V       version\n") ;
	fprintf (stderr, "  -?       show help\n") ;
	exit (EXIT_FAILURE) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void ent_avow () {

	if ( versionflag )
		show_vers () ;
	
	if ( followflag && mountflag ) {
		++syntaxflag ;
		fprintf (stderr, "* '-l' and '-m' are mutually exclusive\n") ;
	}

	if ( dumpflag ) {
		++cramflag ;
	}

	if ( syntaxflag || helpflag )
		usage (SWNAME) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void ent_init () {

	if ( getrlimit(RLIMIT_NOFILE, &rlimbuf) == -1 ) {
		perror("getrlimit") ;
		exit(EXIT_FAILURE) ;
	}

	maxdepth = rlimbuf.rlim_cur ;

	if ( bigflag ) {
		growtabflags |= BINARYGROW ;
	}

	if ( verboseflag >= 3 ) {
		growtabflags |= VERBOSEGROW ;
	}

	if ( followflag ) {
		ntwflags &= ~FTW_PHYS ;
	}

	if ( mountflag ) {
		ntwflags |= FTW_MOUNT ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int main (
				int		argc ,
				char	* argv []
) {
	register	int		i ;

	/* parse args */

	while ( EOF != ( i = getopt (argc, argv, "aBDd:ehlmMrstTvV?") ) )
		switch (i) {
			case 'a' : ++allflag ;					break ;
			case 'B' : ++bigflag ;					break ;
			case 'D' : ++dumpflag ;					break ;
			case 'd' : ent_note (optarg) ;			break ;
			case 'e' : ++errorsflag ;				break ;
			case 'h' : ++helpflag ;					break ;
			case 'l' : ++followflag ;				break ;
			case 'm' : ++mountflag ;				break ;
			case 'M' : ++cramflag ;					break ;
			case 'r' : ++reportflag ;				break ;
			case 's' : ++summaryflag ;				break ;
			case 't' : ++totalflag ;				break ;
			case 'T' : ++treeflag ;					break ;
			case 'v' : ++verboseflag ;				break ;
			case 'V' : ++versionflag ;				break ;
			case '?' : ++helpflag ;					break ;
			default  : ++syntaxflag ;				break ;
		}

	ent_avow () ;							/*	enforce semantics	*/

	if ( optind < argc )						/*	unchecked args	*/
		while (optind < argc)
			ent_note (argv[optind++]) ;

	if ( noteused == 0 )						/*	defaults here	*/
		ent_note (".") ;

	ent_init () ;									/*	prep stuff	*/

	ent_march () ;									/*	just ...	*/

	return ent_end () ;									/*	enough	*/
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

/*
 * vi:nu ts=4
 */
