
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   libpha     parallel hash alternative library   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This file is part of 'PHALANX' (the parallel hash alternative)      |
 |  as released by Alexandre Botao <botao.org> ;                        |
 |                                                                      |
 |  'PHA' is Free and Open Source software (FOSS). This means you can   |
 |  redistribute it and/or modify it under the terms of the GNU General |
 |  Public License as published by the Free Software Foundation, either |
 |  version 3 of the License, or (at your option) any later version.    |
 |                                                                      |
 |  'PHA' is distributed in the hope that it will be useful,            |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License	|
 |  along with 'PHA'.  If not, see <http://www.gnu.org/licenses/>, or   |
 |  write to the Free Software Foundation, Inc.,                        |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# include "configure.h"
# include "libmonkz.h"
# include "spice.h"
# include "zest.h"
# include "zeit.h"

/*________________________________________________________________________
*/

# include	<sys/types.h>
# include	<sys/stat.h>

# include	<ctype.h>
# include	<stdio.h>
# include	<string.h>
# include	<stdlib.h>
# include	<unistd.h>
# include	<pthread.h>

/*________________________________________________________________________
*/

# define	PIF_STDIN		0x01000000

struct phainfo {
	char *		pi_name ;
	size_t		pi_size ;
	char *		pi_time ;
	time_t		pi_start ;
	long long	pi_speed ;
	int			pi_flags ;
	int			pi_width ;
	int			pi_parts ;
	int			pi_buffer ;
	int			pi_threads ;
} ;

typedef		struct phainfo		PHAINFO ;

PHAINFO phadata [1048576] ; /* FIXME: dyn/y alloc */

int	phacount = 0 ;

/*________________________________________________________________________
*/

# define	MAXSYSTHR		1024

# define	PHASPICE(E,C,S)	( * ( spicevec[(E*(1+C))&0x0f] + ( SPICEMASK & ( (E*(1+C)) * pharng(S) ) ) ) )
 
# ifndef	_REENTRANT
# define	_REENTRANT
# endif		/* _REENTRANT */

int phawid = 64 ;
int octcount = 1 ;
int octmask = 0x00 ;
int maxrunthr = 1024 ;
int maxsysthr = 1024 ;

extern int giventhreads ;
extern int syscpu ;
extern int poolflag ;
extern int dumpflag ;
extern int timeflag ;
extern int perfflag ;
extern int fastflag ;
extern int progressflag ;
extern int verboseflag ;
extern int haleflag ;
extern int lessflag ;
extern int nameflag ;
extern int markflag ;
extern int headerflag ;

extern char * versno ;

int dominoflag = 0 ;
int singleflag = 0 ;
int threadedflag = 0 ;

/* size_t parsiz ; */

long long sizeperc = 0 ;
long long doneperc = 0 ;
long long donesize = 0 ;
long long prevperc = 0 ;
long long markperc = 5 ;

char msgbuf [1048576] ;

/*________________________________________________________________________
*/

# define	B32RNDMAX		0x7fffffff

# define	DFLRNDEGG		0x5f3759df

static int phaseed = DFLRNDEGG ;

int pharng (seedp) int * seedp ; {
	register int hi, lo ;

	if ( seedp == NULL ) {
		seedp = &phaseed ;
	}
	if ( fastflag ) { /* BSD randz... */
		*seedp = (*seedp) * 1103515245 + 12345 ;
		return (*seedp) % ((unsigned int)B32RNDMAX + 1) ;
	} else {
		hi = (*seedp) / 127773 ; lo = (*seedp) % 127773 ;
		*seedp = 16807 * lo - 2836 * hi ;
		if ((*seedp) <= 0)
			*seedp += B32RNDMAX ;
		return (*seedp) ;
	}
}

void phareseed () {
	phaseed = DFLRNDEGG ;
}

/*________________________________________________________________________
*/

void phanote (name, desc, what) char * name , * desc , * what ; {
	PHAINFO * pip ;
	int i, found ;
	char * tp = name ;

	for ( pip = phadata , found = i = 0 ; i < phacount ; ++i , ++pip ) {
		if ( 0 == strcmp ( name , pip->pi_name ) ) {
			found = 1 ;
			break ;
		}
	}
	if ( ! found ) {
		++phacount ;
		pip->pi_flags = 0x00000000 ;
		if ( 0 == strcmp ( tp , "--stdin" ) ) {
			/* tp += 2 ; */
			pip->pi_flags |= PIF_STDIN ;
		}
		pip->pi_name = strdup (tp) ;
	}
	if ( 0 == strcmp ( desc , "size" ) ) {
		pip->pi_size = *(size_t *)what ;
	} else if ( 0 == strcmp ( desc , "elapsed" ) ) {
		pip->pi_time = strdup (what) ;
	} else if ( 0 == strcmp ( desc , "start" ) ) {
		pip->pi_start = *(time_t *)what ;
	} else if ( 0 == strcmp ( desc , "speed" ) ) {
		pip->pi_speed = *(long long *)what ;
	} else if ( 0 == strcmp ( desc , "width" ) ) {
		pip->pi_width = *(int *)what ;
	} else if ( 0 == strcmp ( desc , "buffer" ) ) {
		pip->pi_buffer = *(int *)what ;
	} else if ( 0 == strcmp ( desc , "parts" ) ) {
		pip->pi_parts = *(int *)what ;
	} else if ( 0 == strcmp ( desc , "threads" ) ) {
		pip->pi_threads = *(int *)what ;
	}
}

/*________________________________________________________________________
*/

/*                    _________________________
 *                   |                         |
 *                   |   the hoplite           |
 *                   |_________________________|
 */

unsigned long long * xomd64buff (buf, len, phaleaf, seedp) unsigned char * buf ; int len ; unsigned long long phaleaf [] ; int * seedp ; {

	auto		unsigned long long		end = 0LL ;
	register	unsigned long long *	llp = (unsigned long long *) buf ;
	register	int						mix ;
	register	int						cnt ;
	register	int						lim ;
	register	int						off = 1 ;
	register	int						ibe ;
				int						tot ;
				int						pit ;
	unsigned long long * spiceptr = spicebuf ;


	if ( len < 0 || buf == NULL ) {
		goto eox ;
	}

	tot = ( len > 0 ) ? len : (int)strlen ( (char *) buf ) ;
	lim = tot / 8 ; pit = tot % 8 ; ibe = isbigend () ;

	memset ( phaleaf , 0 , MAXOCT * sizeof ( unsigned long long ) ) ;

		for ( cnt = 0 ; cnt < lim ; ++cnt ) {
			if ( haleflag ) {
				end = ibe ? fullswap (*llp) : *llp ;
				if ( lessflag ) {
					spiceptr = spicevec [ cnt & 0x0f ] ;
					for ( tot = 0 ; tot < 8 ; ++tot , ++off ) {
						mix = off + ( off * ( end >> ( tot << 3 ) ) ) ;
						end ^= spiceptr [ mix & 0xff ] ;
					}
				} else {
					for ( tot = 0 ; tot < 8 ; ++tot , ++off ) {
						mix = off + ( off * ( end >> ( tot << 3 ) ) ) ;
						spiceptr = spicevec [ mix & 0x0f ] ;
						end ^= spiceptr [ mix & 0xff ] ;
					}
				}
			} else {
				end = *llp ;
			}
			phaleaf [ cnt & octmask ] ^= end ;
			++llp ;
		}

	if ( pit != 0 ) {
		if ( haleflag ) {
			end = ibe ? fullswap (*llp) : *llp ;
			if ( lessflag ) {
				spiceptr = spicevec [ cnt & 0x0f ] ;
				for ( lim = 0 ; lim < 8 ; ++lim , ++off ) {
					mix = off + ( off * ( end >> ( lim << 3 ) ) ) ;
					end ^= spiceptr [ mix & 0xff ] ;
				}
			} else {
				for ( lim = 0 ; lim < 8 ; ++lim , ++off ) {
					mix = off + ( off * ( end >> ( lim << 3 ) ) ) ;
					spiceptr = spicevec [ mix & 0x0f ] ;
					end ^= spiceptr [ mix & 0xff ] ;
				}
			}
		} else {
			end = *llp ;
		}
		phaleaf [ cnt & octmask /* 0 */ ] ^= end ;
	}

	for ( cnt = 0 ; cnt < octcount ; ++cnt ) {
		if ( phaleaf [ cnt ] == 0LL ) {
			phaleaf [ cnt ] = PHASPICE ( end , cnt , seedp ) ;
		}
	}
eox:
	return & phaleaf [ 0 ] ;
}

/*________________________________________________________________________
*/

/*                    ___________________________
 *                   |                           |
 *                   |   the panoply             |
 *                   |___________________________|
 */

# define	PHA_DONE		0x00000001
# define	PHA_BUFF		0x00000020
# define	PHA_FAIL		0x08000000

struct phactl {
	char *				pha_name ;
	char *				pha_buff ;
	int					pha_part ;
	int					pha_size ;
	int					pha_last ;
	int					pha_flag ;
	int					pha_seed ;
	pthread_t			pha_self ;
	unsigned long long	pha_leaf [MAXOCT] ;
} ;

typedef		struct phactl		PHACTL ;

# define	XORSIZ		/* 524288 */ 1048576
# define	MAXPHA		1048576

pthread_mutex_t		act_mutex = PTHREAD_MUTEX_INITIALIZER ;
pthread_mutex_t		pct_mutex = PTHREAD_MUTEX_INITIALIZER ;
pthread_mutex_t		tot_mutex = PTHREAD_MUTEX_INITIALIZER ;

int		acthr = 0 ;

PHACTL	phactlvec [MAXPHA] ;

unsigned long long phatree [MAXPHA] [MAXOCT] ; /* all threads */

unsigned long long phacrop [MAXOCT] ; /* final */

int phabufsiz = XORSIZ ;
int okflag = 0 ; /* FIXME: mthr */

size_t phatotsiz = 0 ;
size_t phamaxsiz = 0 ;

/*________________________________________________________________________
*/

FILE * xfp = NULL ;

void * xomd64part ( arg ) void * arg ; {

	register	unsigned long long *	pha = NULL ;
	register	unsigned long long *	phaleaf ;
	register	unsigned char *			buf = NULL ;	/* useful */
	static		unsigned char *			sbuf = NULL ;	/* static */
				unsigned char *			tbuf = NULL ;	/* thread */
	register	char *					nam ;
	register	int						par = 0 ;
	register	int						xorsiz = 0 ;
	register	int						octi ;
	register	int						i ;
				int						ateof = 0 ;
	register	PHACTL					* pcp ;
				FILE *					fp = NULL ;
				off_t					pofs ;

	pcp = (PHACTL *) arg ;
	nam = pcp->pha_name ;
	phaleaf = pcp->pha_leaf ;

	if ( threadedflag ) {
		tbuf = (unsigned char *) calloc ((size_t)phabufsiz, 1) ;
		if ( tbuf == NULL ) {
			pcp->pha_flag |= PHA_FAIL ;
			goto nobuf ;
		}
		buf = tbuf ;
		if ( poolflag ) {
			pthread_mutex_lock(&act_mutex);
				++acthr ;
			pthread_mutex_unlock(&act_mutex);
		}
	} else {
		if ( sbuf == NULL ) {
			sbuf = (unsigned char *) calloc ((size_t)phabufsiz, 1) ;
		}
		buf = sbuf ;
	}

	if ( threadedflag ) {
		if ( pcp->pha_flag & PIF_STDIN ) {
			fp = stdin ;
		} else {
			fp = fopen ( nam , "r" ) ;
		}
		if ( fp == NULL ) {
			fprintf (stderr, "pha: open part #%d of '%s' failed\n", pcp->pha_part, nam) ;
			exit (2) ;
		}
		pcp->pha_flag &= ~ PHA_DONE ;
	} else {
		if ( xfp == NULL ) {
			if ( pcp->pha_flag & PIF_STDIN ) {
				xfp = stdin ;
			} else {
				xfp = fopen ( nam , "r" ) ;
			}
		}
		fp = xfp ;
	}

	for ( i = 0 ; i < pcp->pha_size ; ++i ) {
		par = pcp->pha_part * pcp->pha_size ;
		if ( ( par += i ) >= pcp->pha_last ) {
			break ;
		}

		if ( fp != stdin ) {
			pofs = par * phabufsiz ;
			fseek ( fp , pofs , SEEK_SET ) ;
		}

		memset (buf, 0, (size_t)phabufsiz) ;
/* FIXME: if ( mthr stdin ) { grab next buff } else ... */
		xorsiz = fread ( buf , (size_t)1 , (size_t)phabufsiz , fp ) ;
		ateof = feof ( fp ) ;

		if ( xorsiz <= 0 ) {
			if ( ateof ) {
				okflag = 0 ;
				break ;
			}
			fprintf (stderr, "pha: read part #%d of '%s' got %d bytes\n", par, nam, xorsiz) ;
			xorsiz = -1 ;
		} else {
			phatotsiz += xorsiz ;
			if ( phamaxsiz > 0 ) {
				pthread_mutex_lock(&tot_mutex);
				if ( phatotsiz >= phamaxsiz ) {
					okflag = 0 ;
					break ;
				}
				pthread_mutex_unlock(&tot_mutex);
			}
		}

		pha = xomd64buff ( buf , xorsiz , phaleaf , &pcp->pha_seed ) ;

		for ( octi = 0 ; octi < octcount ; ++octi ) {
			phatree [ par ] [ octi ] = phaleaf [ octi ] ;
		}

		if ( progressflag ) {
			pthread_mutex_lock(&pct_mutex);
			if ( xorsiz > 0 ) {
				donesize += xorsiz ;
				doneperc = ( donesize * 100 ) / sizeperc ;
				if ( ( doneperc - prevperc ) >= markperc ) {
					prevperc = doneperc ;
					fprintf (stderr, "~%2lld%%\r", doneperc) ;
				}
			}
			pthread_mutex_unlock(&pct_mutex);
		}
	}

	if ( threadedflag ) {
		if ( fp != stdin ) {
			fclose (fp) ;
		}
	} else {
		xfp = fp ;
	}

	if ( threadedflag ) {
		if ( verboseflag > 3 ) {
			fprintf(stderr,"#### tid<%ld> par(%d) pha{%016llx}\n",(long)pcp->pha_self,par,pha == NULL ? 0LL : *pha);
		}
		free (tbuf) ;
		pcp->pha_flag |= PHA_DONE ;
		if ( poolflag ) {
			pthread_mutex_lock(&act_mutex);
				--acthr ;
			pthread_mutex_unlock(&act_mutex);
		}
nobuf:
		pthread_exit ( (void *) pha ) ;
	}

	if ( verboseflag > 3 ) {
		fprintf(stderr,"---- tid<%ld> par(%d) pha{%016llx}\n",(long)pcp->pha_self,par,pha == NULL ? 0LL : *pha);
	}

	return (void *) pha ;
}

/*________________________________________________________________________
*/

/*                    ___________________________
 *                   |                           |
 *                   |   the phalanx             |
 *                   |___________________________|
 */

unsigned long long * xomd64file (nam) char * nam ; {

				unsigned long long		* res = NULL ;
				unsigned long long		end ;
				int						parcount ;
				int						thrcount ;
				int						parbythr ;
				int						stdinflag = 0 ;
				int						octi , rd , numpar = 0 ;
				struct stat				stabuf ;
				PHACTL					phactlbuf ;
				pthread_attr_t			ptat ;
				void *					ptst ;

	if ( 0 == strcmp ( nam , "--stdin" ) ) {
		rd = 0 ; stdinflag = PIF_STDIN ;
	} else {
		rd = stat ( nam , &stabuf ) ;
	}

	if ( rd < 0 ) {
		return NULL ;
	} else {
		if ( stdinflag == 0 ) {
			numpar = stabuf.st_size / phabufsiz ;
			if ( stabuf.st_size % phabufsiz ) {
				++numpar ;
			}
			phanote (nam, "size", (char *)&stabuf.st_size) ;
			phanote (nam, "parts", (char *)&numpar) ;
			if ( progressflag ) {
				sizeperc = stabuf.st_size ;
				donesize = 0 ;
				prevperc = 0 - markperc ;
			}
		} else {
			numpar = 0x7fffffff ;
			progressflag = 0 ;
		}
	}

	if ( giventhreads > 0 /* && giventhreads < maxsysthr */ ) {
		maxrunthr = giventhreads ;
	}

	if ( singleflag ) {
		threadedflag = 0 ;
		maxrunthr = 1 ;
	} else {
		threadedflag = 1 ;
	}

	if ( numpar == 1 ) {
		threadedflag = 0 ;
		maxrunthr = 1 ;
	}

	phanote (nam, "width", (char *)&phawid) ;
	phanote (nam, "buffer", (char *)&phabufsiz) ;
	phanote (nam, "threads", (char *)&maxrunthr) ;

	phatotsiz = 0 ; okflag = 1 ;
	memset ( phacrop , 0 , MAXOCT * sizeof ( unsigned long long ) ) ;
	memset ( phatree , 0 , MAXPHA * MAXOCT * sizeof ( unsigned long long ) ) ;

	if ( threadedflag ) {

		pthread_attr_init (&ptat) ;

		if ( numpar <= maxrunthr ) {
			pthread_attr_setdetachstate (&ptat, PTHREAD_CREATE_JOINABLE) ;
			for ( parcount = 0 ; parcount < numpar ; ++parcount ) {
				phactlvec[parcount].pha_name = nam ;
				phactlvec[parcount].pha_seed = DFLRNDEGG ;
				phactlvec[parcount].pha_part = parcount ;
				phactlvec[parcount].pha_last = numpar ;
				phactlvec[parcount].pha_size = 1 ;
				phactlvec[parcount].pha_flag = 0x00 | stdinflag ;
				rd = pthread_create (&phactlvec[parcount].pha_self, &ptat, xomd64part, (void *)&phactlvec[parcount]) ;
				if (rd) {
					printf ("*** pthread_create() got %d\n", rd) ; exit(-1) ;
				}
			}
			for ( parcount = 0 ; parcount < numpar ; ++parcount ) {
				rd = pthread_join (phactlvec[parcount].pha_self, &ptst) ;
				if (rd) {
					printf("*** pthread_join() got %d\n", rd) ; exit(-1) ;
				} /* printf("joined thread %ld status %ld\n",parcount,(long)ptst); */
			}
		} else {
			if ( poolflag ) { /* thread pool (fixed payload size) */
				pthread_attr_setdetachstate (&ptat, PTHREAD_CREATE_DETACHED) ;
				parcount = acthr = 0 ;
				while ( parcount < numpar ) {
					while ( acthr < maxrunthr ) {
						phactlvec[parcount].pha_name = nam ;
						phactlvec[parcount].pha_seed = DFLRNDEGG ;
						phactlvec[parcount].pha_part = parcount ;
						phactlvec[parcount].pha_last = numpar ;
						phactlvec[parcount].pha_size = 1 ;
						phactlvec[parcount].pha_flag = 0x00 | stdinflag ;
						rd = pthread_create (&phactlvec[parcount].pha_self, &ptat, xomd64part, (void *)&phactlvec[parcount]) ;
						if (rd) {
							printf("*** pthread_create() got %d\n", rd) ; exit(-1) ;
						}
						++parcount ;
					}
					usleep (100000) ;	/* FIXME: usleep (max_thr_run_usecs) */
				}
			} else { /* buffer pool (fixed max active threads) */
				pthread_attr_setdetachstate (&ptat, PTHREAD_CREATE_JOINABLE) ;
				parbythr = ( numpar / maxrunthr ) + ( numpar % maxrunthr ? 1 : 0 ) ;
				for ( thrcount = 0 ; thrcount < maxrunthr ; ++thrcount ) {
					phactlvec[thrcount].pha_name = nam ;
					phactlvec[thrcount].pha_seed = DFLRNDEGG ;
					phactlvec[thrcount].pha_part = thrcount ;
					phactlvec[thrcount].pha_last = numpar ;
					phactlvec[thrcount].pha_size = parbythr ;
					phactlvec[thrcount].pha_flag = 0x00 | stdinflag ;
					rd = pthread_create (&phactlvec[thrcount].pha_self, &ptat, xomd64part, (void *)&phactlvec[thrcount]) ;
					if (rd) {
						printf ("*** pthread_create() got %d\n", rd) ; exit(-1) ;
					}
				}
				for ( thrcount = 0 ; thrcount < maxrunthr ; ++thrcount ) {
					rd = pthread_join (phactlvec[thrcount].pha_self, &ptst) ;
					if (rd) {
						printf("*** pthread_join() got %d\n", rd) ; exit(-1) ;
					} /* printf("joined thread %ld status %ld\n",thrcount,(long)ptst); */
				}
			}
		}

		pthread_attr_destroy(&ptat);

		for ( parcount = 0 ; parcount < numpar ; ++parcount ) {
			for ( octi = 0 ; octi < octcount ; ++octi ) {
				phacrop [ octi ] ^= phatree [ parcount ] [ octi ] ;
			}
		}

	} else {	/* sequential/single/mono mode */

		for ( parcount = 0 ; parcount < numpar ; ++parcount ) {
			if ( okflag ) {
				phactlbuf.pha_name = nam ;
				phactlbuf.pha_seed = DFLRNDEGG ;
				phactlbuf.pha_part = parcount ;
				phactlbuf.pha_last = stdinflag ? 2 + parcount : numpar ;
				phactlbuf.pha_size = 1 ;
				phactlbuf.pha_flag = 0x00 | stdinflag ;
				res = xomd64part ( (void *) &phactlbuf ) ;
				if ( res != NULL ) {
					for ( octi = 0 ; octi < octcount ; ++octi ) {
						phacrop [ octi ] ^= phatree [ parcount ] [ octi ] ;
					}
				}
			} else {
				break ;
			}
		}

		if ( xfp != NULL ) {
			if ( xfp != stdin ) {
				fclose ( xfp ) ;
			}
			xfp = NULL ;
		}

	}

	if ( haleflag ) {
		if ( octcount > 1 ) { /* final round */
			for ( end = 0LL , octi = 0 ; octi < octcount ; ++octi ) {
				end ^= phacrop [ octi ] ;
			}
			end = niblswap (end) ;
			for ( octi = 0 ; octi < octcount ; ++octi ) {
				phacrop [ octi ] ^= end ;
			}
		}
	}

	if ( stdinflag != 0 ) {
		phanote (nam, "size", (char *)&phatotsiz) ;
		phanote (nam, "parts", (char *)&parcount) ;
	}

	return & phacrop [ 0 ] ;
}

/*________________________________________________________________________
*/

void sievewid (given) int given ; {

	if ( nameflag ) {
		fprintf (stderr, "* warning: width (%d) defined by name. ignored.\n", phawid) ;
		return ;
	}

	if ( given >= 64 && given <= 1024 ) {
		phawid = given & 0x000007c0 ;
	} else {
		phawid = -1 ;
	}

	if ( phawid < 0 ) {
		phawid = 64 ;
		fprintf (stderr, "* warning: bad width (%d)\n", given) ;
	}

	octcount = phawid / 64 ;
	octmask = octcount - 1 ;
}

/*________________________________________________________________________
*/

char delim = ';' ;

char * hdrvec [] = {
	"meth","vers","width",
	"date","time","host",
	"os","rel",
	"pus","clock","model",
	"threads","buffer",
	"parts","size",
	"elapsed","speed",
	"file",
	NULL
} ;

void phadump () {
	PHAINFO * pip ;
	char * tp ;
	char * pham = NULL ;
	char * node = NULL ;
	char * rtos = NULL ;
	char * osvr = NULL ;
	char * cpun = NULL ;
	long long clok = 0LL ;
	int i ;

	if ( ! ( dumpflag || timeflag || perfflag || markflag ) ) {
		return ;
	}
	if ( verboseflag && ! markflag ) {
		fprintf (stderr, "# cpus=%d\n", syscpu) ;
	}
	if ( markflag ) {
		if ( headerflag ) {
			for ( i = 0 ; hdrvec[i] != NULL ; ++i ) {
				fprintf (stderr, "%s", hdrvec[i]) ;
				if ( hdrvec[i+1] != NULL ) {
					fprintf (stderr, "%c", delim) ;
				}
			}
			fprintf (stderr, "\n") ;
		}
		if ( haleflag ) {
			if ( lessflag ) {
				pham = "pha2" ;
			} else {
				pham = "pha1" ;
			}
		} else {
			pham = "pha0" ;
		}
		node = getnodename () ;
		rtos = getosname () ;
		osvr = getosvers () ;
		clok = getcpufhz () ;
		cpun = getcpuinf ("model") ;
	}
	for ( pip = phadata ; pip->pi_name != NULL ; ++pip ) {
		if ( markflag ) {
			fprintf (stderr, "%s",   pham) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   versno) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%d",   pip->pi_width) ;			fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   strdate (pip->pi_start)) ;	fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   strtime (pip->pi_start)) ;	fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   node) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   rtos) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   osvr) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%d",   syscpu) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%lld", clok) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   cpun) ;					fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%d",   pip->pi_threads) ;			fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%d",   pip->pi_buffer) ;			fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%d",   pip->pi_parts) ;			fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%lld", (long long)pip->pi_size) ;	fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%s",   pip->pi_time) ;			fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "%lld", pip->pi_speed) ;			fprintf (stderr, "%c", delim) ;
			tp = pip->pi_name ;
			fprintf (stderr, "%s", *tp == '-' ? tp + 2 : tp) ;	fprintf (stderr, "%c", delim) ;
			fprintf (stderr, "\n") ;
		} else {
			if ( singleflag ) {
				fprintf (stderr, "- ") ;
			} else {
				fprintf (stderr, "# ") ;
			}
			if ( dumpflag ) {
				fprintf (stderr, "width=%d ", pip->pi_width ) ;
				fprintf (stderr, "buffer=%d " , pip->pi_buffer ) ;
				if ( ! singleflag ) {
					fprintf (stderr, "threads=%d ", pip->pi_threads) ;
				}
				fprintf (stderr, "size=%lld ", (long long)pip->pi_size) ;
				fprintf (stderr, "parts=%d " , pip->pi_parts ) ;
				fprintf (stderr, "last=%lld " , ((long long)pip->pi_size) % pip->pi_buffer ) ;
#ifdef EXPERIMENTAL
				if ( phamaxsiz ) {
					fprintf (stderr,  "max=%d " , pip->pi_limit ) ;
				}
#endif
			}
			if ( timeflag ) {
				fprintf (stderr, "elapsed=%s ", pip->pi_time) ;
			}
			if ( perfflag ) {
				fprintf (stderr, "speed=%lld ", pip->pi_speed) ;
			}
			if ( dumpflag || timeflag || perfflag ) {
				tp = pip->pi_name ;
				fprintf (stderr, "file=%s\n", *tp == '-' ? tp + 2 : tp) ;
			}
		}
	}
}

/*________________________________________________________________________
*/

int phaisdir (name) char * name ; {

	int rd ;
	static struct stat sb ;

	if ( stat ( name , &sb ) != 0 ) {
		sprintf (msgbuf, "monkz: stat (%s)", name) ;
		perror (msgbuf) ;
		exit (2) ;
	}

	switch (sb.st_mode & S_IFMT) {
		case S_IFDIR :	rd = 1 ;	break ;
		default :		rd = 0 ;	break ;
	}

	return rd ;
}

/*________________________________________________________________________
*/

char * graftname ( branch , leaf ) char * branch , * leaf ; {

	char * bp ;
	char * tp ;
	int blen ;

	blen = strlen (branch) ;

	bp = malloc ( 2 + blen + strlen (leaf) ) ;

	if ( bp == NULL ) {
		sprintf (msgbuf, "%s", "monkz: malloc failed") ;
		perror (msgbuf) ;
		exit (2) ;
	}

	strcpy ( bp , branch ) ;
	tp = bp + blen ;

	if ( *(tp-1) != '/' ) {
		*tp++ = '/' ;
	}

	strcpy ( tp , leaf ) ;
	return bp ;
}

/*________________________________________________________________________
*/

/*
 * vi:nu ts=4
 */
