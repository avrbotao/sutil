
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   monkz                parallel copy & compare   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This file is part of 'monkz' (the parallel copy & compare)          |
 |  as released by Alexandre Botao <botao.org> ;                        |
 |                                                                      |
 |  'monkz' is Free and Open Source software (FOSS). This means you can |
 |  redistribute it and/or modify it under the terms of the GNU General |
 |  Public License as published by the Free Software Foundation, either |
 |  version 3 of the License, or (at your option) any later version.    |
 |                                                                      |
 |  'monkz' is distributed in the hope that it will be useful,          |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License	|
 |  along with 'monkz'.  If not, see <http://www.gnu.org/licenses/>,    |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# define	SWNAME			"monkz"
# define	SWVERS			"0.6.12"
# define	SWFORG			"$"						/*	"$" = stable	*/
# define	SWDATE			"2015/10/03"
# define	SWDESC			"parallel copy & compare"
# define	SWTAGS			"parallel,copy,compare,digest,sum,checksum,multithread"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

char * versno = SWVERS ;

char * forgid = SWFORG ;

# include "configure.h"
# include "libmonkz.h"
# include "zeit.h"
# include "zest.h"

/*________________________________________________________________________
*/

# include	<sys/types.h>
# include	<sys/resource.h>
# include	<sys/stat.h>
# include	<sys/time.h>

# include	<ctype.h>
# include	<stdio.h>
# include	<string.h>
# include	<stdlib.h>

/*________________________________________________________________________
*/

# define MEGASIZE 1048576

size_t parsiz ;

int syscpu = 4 ;
int	givenwid = 0 ;
int giventhreads = 0 ;

int verboseflag = 0 ;
int demoflag = 0 ;
int dumpflag = 0 ;
int fastflag = 0 ;
int helpflag = 0 ;
int nameflag = 0 ;
int timeflag = 0 ;
int keepflag = 0 ;
int perfflag = 0 ;
int progressflag = 0 ;
int poolflag = 0 ;
int logflag = 0 ;
int haleflag = 0 ;
int lessflag = 0 ;
int markflag = 0 ;
int headerflag = 0 ;

int monkzflag = 1 ;

int argk = 0 ;

char * argp [MEGASIZE] ; /* FIXME: dyn/alloc */

char * givenlog = NULL ;

char phalogname [ 1024 ] ;

struct stat stabuf ;

/*________________________________________________________________________
*/

# define	LINESIZE	1024

# define	PHASUF		".pha"

char namebuff [LINESIZE] ;
char pharbuff [LINESIZE] ;

void phatest ( hash , name ) char * hash , * name ; {
	char * tp ;
	int namelen , octi ;
	unsigned long long * res = 0LL ;
	unsigned long long * bkp = 0LL ;
	for ( tp = name ; *tp == ' ' || *tp == '\t' ; ++tp ) ;
	namelen = strlen ( tp ) ;
	strcpy ( namebuff , tp ) ;
	tp = namebuff + namelen ;
	for ( --tp ; *tp == '\n' || *tp == '\r' ; *tp-- = '\0' ) ;
	printf ( "%s: " , namebuff ) ;
	tp = strchr (hash, ' ') ;
	if ( tp != NULL ) {
		*tp = '\0' ;
	}
	sievewid ( strlen ( hash ) * 4 ) ;
	bkp = res = xomd64file (namebuff) ;
	if ( res == NULL ) {
		printf ("FAILED\n") ;
	} else {
		for ( octi = 0 ; octi < octcount ; ++octi , ++res ) {
			sprintf ( &pharbuff[octi*16] , "%016llx" , *res ) ;
		}
		if ( 0 == strncmp ( hash , pharbuff , octcount * 16 ) ) {
			printf ("OK\n") ;
		} else {
			if ( isbigend () ) {
				for ( res = bkp , octi = 0 ; octi < octcount ; ++octi , ++res ) {
					sprintf ( &pharbuff[octi*16] , "%016llx" , fullswap ( *res ) ) ;
				}
				if ( 0 == strncmp ( hash , pharbuff , octcount * 16 ) ) {
					printf ("OK\n") ;
				} else {
					printf ("DIFFER\n") ;
				}
			} else {
				printf ("DIFFER\n") ;
			}
		}
	}
}

char listline [LINESIZE] ;

void phacheck (listfile) char * listfile ; {
	FILE * lfp ;
	char * tp ;

	lfp = fopen ( listfile , "r" ) ;
	if ( lfp == NULL ) {
		fprintf (stderr, "* check list file (%s) access error\n", listfile) ;
		return ;
	}

	while ( fgets ( listline , LINESIZE , lfp ) != NULL ) {
		tp = strrchr ( listline , ' ' ) ;
		if ( tp == NULL ) {
			fprintf (stderr, "* check list line (%s) format error\n", listline) ;
			continue ;
		}
		*tp++ = '\0' ;
		phatest ( listline , tp ) ;
	}

	fclose (lfp) ;
	exit (0) ;
}

/*________________________________________________________________________
*/

unsigned long long * phastr (str) char * str ; {
	unsigned long long * phax ;
	static unsigned long long	pha_leaf [MAXOCT] ;
	++singleflag ; ++haleflag ;
	phax = xomd64buff (str, 0, pha_leaf, NULL) ;
	return phax ;
}

/*________________________________________________________________________
*/

unsigned long long * phathis (name) char * name ; {
	unsigned long long * phax ;
	ETI sti ;
	long long selaps ;
	char * tp = name ;
	long long speed ;
	time_t tloc ;

	if ( timeflag || perfflag ) {
		time (&tloc) ;
		phanote (name, "start", (char *)&tloc) ;
		startimer (&sti) ;
	}
	phax = xomd64file (tp) ;
	if ( phax == NULL ) {
		fprintf ( stderr , "*ERR* %s\n" , *tp == '-' ? tp + 2 : tp ) ;
		return phax ;
	}
	if ( timeflag || perfflag ) {
		stoptimer (&sti) ;
		selaps = difelaps (&sti) ;
	}
	if ( timeflag ) {
		phanote (name, "elapsed", fmtelaps (selaps)) ;
	}
	if ( perfflag ) {
		if ( *tp == '-' ) {
		} else {
			if ( stat ( tp , &stabuf ) == 0 ) {
				speed = zeitfreq (selaps, (long long)stabuf.st_size) ;
				phanote (name, "speed", (char *)&speed) ;
			}
		}
	}
	return phax ;
}

/*________________________________________________________________________
*/

# include <math.h>

char tmpstr [MEGASIZE] ;

/*
	pha
3608030c3b070931  phatestasc.dat
0a23fd936a6f9938  phatestbin.dat
e3c2ef36a3ce5470  phatestmix.dat
	md5
ff178d494815f62a1405a3950f4d48e2  phatestasc.dat
67e1a793eaa21d51a044286a7ceacc67  phatestbin.dat
7c1afaf78393ed04bcae4ad4f5bb72fe  phatestmix.dat
	sha1
f542d7c285361042851c4b06b6575641a65121a1  phatestasc.dat
04d024c3345bd25bcf8c8057c0f10a8cc0732105  phatestbin.dat
9c8765bff239c278890231e48214554fe05b1e87  phatestmix.dat
	sha256
a224bc869afd8c4f3e3d8dcaf93c80aced23a50dccfdd4360919653615312b97  phatestasc.dat
c09cb005249014d9a3aba2904bb68227c3c57ee0fa7ac917ea05aafe5fb55afa  phatestbin.dat
3f8c36297b937fac13ca52d8d2faa0cf0fb7c14255b7a809f0a10710cdb44c3a  phatestmix.dat
*/

int demofact = 1 ;

void phademo () {
	FILE * fp ;
	int i ;
	char * name1 = "phatestasc.dat" ;
	char * name2 = "phatestbin.dat" ;
	char * name3 = "phatestmix.dat" ;
	unsigned long long * phares = NULL ;
	unsigned long long ascres = 0LL ;
	unsigned long long binres = 0LL ;
	unsigned long long mixres = 0LL ;
	unsigned long long bufres = 0LL ;
	unsigned long long phaver = 0LL ;
	int octi, lim, halebup = haleflag ;

	if ( singleflag ) {
		printf ("- ") ;
	} else {
		printf ("# ") ;
	}

	printf ("random/ascii...") ;

		printf ("create..") ; fflush (stdout) ;

			fp = fopen (name1, "w") ;
			phareseed () ;
			lim = demofact * 1000000 ;
			for ( i = 0 ; i < lim ; ++i ) {
				octi = pharng ( NULL ) ;
				fprintf (fp, "%d\n", octi) ;
			}
			fclose (fp) ;

		printf ("digest..") ; fflush (stdout) ;

			phares = phathis (name1) ;
			ascres = *phares ;
/*
			for ( octi = 0 ; octi < octcount ; ++octi ) {
				printf ( "%016llx" , * ( phares + octi ) ) ;
			} printf ( " %s\n" , name1 ) ;
*/
		printf ("verify..") ; fflush (stdout) ;

			switch (demofact) {
				case    1 : phaver = 0x3608030c3b070931LL ; break ;
				case   10 : phaver = 0x3a353f050332043cLL ; break ;
				case  100 : phaver = 0x33353f3b3a013109LL ; break ;
			}

			if ( isbigend () ) {
				phaver = fullswap ( phaver ) ;
			}

			if ( verboseflag ) {
				printf ( "(%016llx).." , ascres ) ;
			}

			if ( ascres == phaver ) {
				printf ("PASS") ;
			} else {
				printf ("FAIL") ;
			}

		printf ("\n") ;

	if ( singleflag ) {
		printf ("- ") ;
	} else {
		printf ("# ") ;
	}

	printf ("random/binary..") ;

		printf ("create..") ; fflush (stdout) ;

			fp = fopen (name2, "w") ;
			phareseed () ;
			lim = ( demofact * 1250000 ) + 1 ;
			for ( i = 0 ; i < lim ; ++i ) {
				octi = pharng ( NULL ) ;
				if ( isbigend () ) {
					octi = halfswap ( octi ) ;
				}
				fwrite ( &octi , sizeof (octi) , 1 , fp ) ;
			}
			fclose (fp) ;

		printf ("digest..") ; fflush (stdout) ;

			phares = phathis (name2) ;
			binres = *phares ;
/*
			for ( octi = 0 ; octi < octcount ; ++octi ) {
				printf ( "%016llx" , * ( phares + octi ) ) ;
			} printf ( " %s\n" , name2 ) ;
*/
		printf ("verify..") ; fflush (stdout) ;

			switch (demofact) {
				case    1 : phaver = 0x0a23fd936a6f9938LL ; break ;
				case   10 : phaver = 0x4da95e4761621152LL ; break ;
				case  100 : phaver = 0x35090928395fe985LL ; break ;
			}

			if ( isbigend () ) {
				phaver = fullswap ( phaver ) ;
			}

			if ( verboseflag ) {
				printf ( "(%016llx).." , binres ) ;
			}

			if ( binres == phaver ) {
				printf ("PASS") ;
			} else {
				printf ("FAIL") ;
			}

		printf ("\n") ;

	if ( singleflag ) {
		printf ("- ") ;
	} else {
		printf ("# ") ;
	}

	printf ("random/mixed...") ;

		printf ("create..") ; fflush (stdout) ;

			fp = fopen (name3, "w") ;
			phareseed () ;
			lim = demofact * 1500000 ;
			for ( i = 0 ; i < lim ; ++i ) {
				octi = pharng ( NULL ) ;
				if ( i & 0x1 ) {
					fprintf (fp, "%d\n", octi) ;
				} else {
					if ( isbigend () ) {
						octi = halfswap ( octi ) ;
					}
					fwrite ( &octi , sizeof (octi) , 1 , fp ) ;
				}
			}
			fclose (fp) ;

		printf ("digest..") ; fflush (stdout) ;

			phares = phathis (name3) ;
			mixres = *phares ;
/*
			for ( octi = 0 ; octi < octcount ; ++octi ) {
				printf ( "%016llx" , * ( phares + octi ) ) ;
			} printf ( " %s\n" , name2 ) ;
*/
		printf ("verify..") ; fflush (stdout) ;

			switch (demofact) {
				case    1 : phaver = 0xe3c2ef36a3ce5470LL ; break ;
				case   10 : phaver = 0xef390c23c631bdedLL ; break ;
				case  100 : phaver = 0xaf524a036d973a2aLL ; break ;
			}

			if ( isbigend () ) {
				phaver = fullswap ( phaver ) ;
			}

			if ( verboseflag ) {
				printf ( "(%016llx).." , mixres ) ;
			}

			if ( mixres == phaver ) {
				printf ("PASS") ;
			} else {
				printf ("FAIL") ;
			}

		printf ("\n") ;

	if ( singleflag ) {
		printf ("- ") ;
	} else {
		printf ("# ") ;
	}

	printf ("string/ascii...") ;

		printf ("ingest..") ; fflush (stdout) ;

			fp = fopen ("LICENSE", "r") ;

			if ( fp == NULL ) {
				printf ("OOPS (missing '%s' file)\n", "LICENSE") ;
				goto eotst ;
			}

			memset ( tmpstr , 0x00 , MEGASIZE ) ;
			i = fread ( tmpstr , (size_t)1 , (size_t)MEGASIZE , fp ) ;

			if ( i <= 0 ) {
				printf ("EMPTY\n") ;
				fclose (fp) ;
				goto eotst ;
			}

			fclose (fp) ;

		printf ("digest..") ; fflush (stdout) ;

			phares = phastr (tmpstr) ;
			bufres = *phares ;
/*
			for ( octi = 0 ; octi < octcount ; ++octi ) {
				printf ( "%016llx" , * ( phares + octi ) ) ;
			} printf ( " %s\n" , name2 ) ;
*/
		printf ("verify..") ; fflush (stdout) ;

			phaver = 0xd70327aaa6accc21LL ;

			if ( verboseflag ) {
				printf ( "(%016llx).." , bufres ) ;
			}

			if ( bufres == phaver ) {
				printf ("PASS") ;
			} else {
				printf ("FAIL") ;
			}

		printf ("\n") ; fflush (stdout) ;

eotst:

	haleflag = halebup ;

	if ( ! keepflag ) {
		unlink ( name1 ) ;
		unlink ( name2 ) ;
		unlink ( name3 ) ;
	}

}

/*________________________________________________________________________
*/

void pharoll (name) char * name ; {
	phanote (name, "name", NULL) ;
	argp[argk++] = strdup (name) ;
}

void phaname (name) char * name ; {
	char * tp = name ;
	char * omode = NULL ;
	unsigned long long * x64 = NULL ;
	register	int						octi ;
	FILE * ofp = stdout ;

	x64 = phathis (tp) ;
	if ( x64 == NULL ) {
		return ;
	}
	if ( *tp == '-' ) {
		tp += 2 ;
	}
	if ( logflag ) {
		if ( givenlog == NULL ) {
			strcpy ( phalogname , tp ) ;
			strcat ( phalogname , PHASUF ) ;
			omode = "w" ;
		} else {
			strcpy ( phalogname , givenlog ) ;
			omode = "a" ;
		}
		ofp = fopen ( phalogname , omode ) ;
		if ( ofp == NULL ) {
			fprintf ( stderr , "pha: log file (%s) creation error\n" , phalogname ) ;
			ofp = stdout ;
		}
	}
	for ( octi = 0 ; octi < octcount ; ++octi , ++x64 ) {
		fprintf ( ofp , "%016llx" , haleflag ? *x64 : isbigend () ? fullswap (*x64) : *x64 ) ;
	}
	fprintf ( ofp , "  %s\n" , tp ) ;
	if ( logflag ) {
		if ( ofp != stdout ) {
			fclose (ofp) ;
		}
	}
}

/*________________________________________________________________________
*/

void usage () {
	fprintf (stderr, "Usage : %s <options> <parameters> [filename [...] destination]\n\n", SWNAME) ;
	fprintf (stderr, "copy or compare (with multithreaded I/O) filename to destination.\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " arguments:\n") ;
    fprintf (stderr, "\n") ;
	fprintf (stderr, " 'filename'     copy or compare <filename>\n") ;
	fprintf (stderr, " 'destination'  file or directory\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " basic options:\n") ;
    fprintf (stderr, "\n") ;
	fprintf (stderr, " -S          single thread operation (for performance comparisons)\n") ;
	fprintf (stderr, " --stdin     hash standard input\n") ;
	fprintf (stderr, " -v          verbose info / extended help\n") ;
	fprintf (stderr, " -V          show version\n") ;
	fprintf (stderr, " -h, --help  usage help\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " basic parameters:\n") ;
    fprintf (stderr, "\n") ;
	fprintf (stderr, " -s string   hash <string>\n") ;
	fprintf (stderr, " -b size     use <size>-bytes i/o buffer (default 1MB)\n") ;
	fprintf (stderr, " -n N        spawn N threads\n") ;
	fprintf (stderr, " -w width    compute hash <width> bits long\n") ;
	fprintf (stderr, " -l [name]   save output to log file (default=filename.pha)\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " special options:\n") ;
    fprintf (stderr, "\n") ;
	fprintf (stderr, " -c, --check list   read PHA sums from <list> and check them\n") ;
	fprintf (stderr, " --demo             ascertain accurate operation\n") ;
	fprintf (stderr, " --Demo             ditto, with larger (~100MiB) files\n") ;
	fprintf (stderr, " --DEMO             even larger (~1GiB) files\n") ;
	fprintf (stderr, " -k                 keep demo files\n") ;
	fprintf (stderr, " -t                 show elapsed time\n") ;
	fprintf (stderr, " -p                 show performance estimate\n") ;
	fprintf (stderr, " -P                 show progress (%%)\n") ;
	fprintf (stderr, " -X, --hale         stronger method\n") ;
	if ( verboseflag ) {
    	fprintf (stderr, "\n") ;
    	fprintf (stderr, " experimental options:\n") ;
    	fprintf (stderr, "\n") ;
		fprintf (stderr, " -D           dump operation info\n") ;
		fprintf (stderr, " -d           dump benchmark info  in CSV format\n") ;
		fprintf (stderr, " -H           header line for '-d' in CSV format\n") ;
		fprintf (stderr, " -N M         pool of M threads\n") ;
		fprintf (stderr, " -m size      process just <size>-bytes\n") ;
		fprintf (stderr, " -x           less stronger (but faster) method\n") ;
	}
    fprintf (stderr, "\n") ;
	exit (1) ;
}

/*________________________________________________________________________
*/

void phainit () {
	struct rlimit rlbuf ;
	int rd ;
	int sysnof = 16 ;

	if ( singleflag ) {
		return ;
	}
	syscpu = atoi ( getcpuinf ("count") ) ;
	if ( syscpu <= 0 ) {
		syscpu = 1 ;
	}
	rd = getrlimit (RLIMIT_NOFILE, &rlbuf) ;
	if ( rd == 0 ) {
		sysnof = rlbuf.rlim_cur ;
	}
	if ( giventhreads > 0 ) {
		if ( giventhreads > sysnof ) {
			giventhreads = sysnof ;
		}
		if ( giventhreads > syscpu ) {
			giventhreads = syscpu ;
		}
	} else {
		giventhreads = syscpu ;
	}
	if ( giventhreads <= 0 ) {
		giventhreads = 1 ;
	}
}

/*________________________________________________________________________
*/

void parallelcat ( ak , ap , df )
	int		ak ;					/*	argk	*/
	char *	ap [ ] ;				/*	argp	*/
	char *	df ;					/*	dest	*/
{
	int i ;
	for ( i = 0 ; i < ak ; ++i ) {
		printf ( "%s %s\n" , ap[i] , df ) ;
	}
}

/*______________________________________________________________________
 |																		|
 |	monkz																|
 |______________________________________________________________________|
*/

void monkz ( fromname , destname )
	char * fromname , * destname ;
{
	if ( fromname == NULL || destname == NULL ) {
		return ;
	}
}

/*________________________________________________________________________
*/

void phadoit () {
	int i ;
	int todirflag ;
	char * lastname ;
	char * destname ;
	if ( demoflag ) {
		phademo () ;
	} else {
		lastname = argp[argk-1] ;
		todirflag = phaisdir ( lastname ) ;
		if ( argk == 2 ) {
			if ( todirflag ) {	/*	single file to dir	*/
				destname = graftname ( lastname , argp[0] ) ;
			} else {			/*	simple file to file	*/
				destname = lastname ;
			}
			monkz ( argp[0] , destname ) ;
		} else {
			--argk ;
			if ( todirflag ) {	/*	many files to dir	*/
				for ( i = 0 ; i < argk ; ++i ) {
					destname = graftname ( lastname , argp[i] ) ;
					monkz ( argp[i] , destname ) ;
				}
			} else {			/*	parallelcat : L8R...	*/
				parallelcat ( argk , argp , lastname ) ;
			}
		}
	}
}

void phaquit () {
	phadump () ;
}

void pha () {
	if ( helpflag ) {
		usage () ;
	}
	phainit () ;
	phadoit () ;
	phaquit () ;
}

/*________________________________________________________________________
*/

void nameck (name) char * name ; {
	char * tp ;
	tp = strrchr ( name , '/' ) ;
	if ( tp == NULL ) {
		tp = name ;
	} else {
		++tp ;
	}
	if ( ( 0 == strcmp ( tp , "pha" ) ) || ( 0 == strcmp ( tp , "phasum" ) ) ) {
		nameflag = 0 ;
	} else if ( ( 0 == strcmp ( tp , "pha64" )  ) || ( 0 == strcmp ( tp , "pha64sum" )  ) ) {
		givenwid =  64 ; sievewid (givenwid) ; ++nameflag ;
	} else if ( ( 0 == strcmp ( tp , "pha128" ) ) || ( 0 == strcmp ( tp , "pha128sum" ) ) ) {
		givenwid = 128 ; sievewid (givenwid) ; ++nameflag ; 
	} else if ( ( 0 == strcmp ( tp , "pha256" ) ) || ( 0 == strcmp ( tp , "pha256sum" ) ) ) {
		givenwid = 256 ; sievewid (givenwid) ; ++nameflag ; 
	} else if ( ( 0 == strcmp ( tp , "pha512" ) ) || ( 0 == strcmp ( tp , "pha512sum" ) ) ) {
		givenwid = 512 ; sievewid (givenwid) ; ++nameflag ; 
	}
}

/*________________________________________________________________________
*/

int main (argc, argv) int argc ; char * * argv ; {

	char * tp = argv[0] ;
	unsigned long long * x64 = 0LL ;
	unsigned long long	pha_leaf [MAXOCT] ;
	int octi ;

	if (--argc) {
		nameck (tp) ;
		while (*++argv) {
			if ( strcmp ( *argv , "-s" ) == 0 ) {
				if ( ( tp = *++argv ) == NULL ) {
					--argv ;
				} else {
					++singleflag ;
					++haleflag ;
					memset ( tmpstr , 0x00 , MEGASIZE ) ;
					strcpy ( tmpstr , tp ) ;
					x64 = xomd64buff (tmpstr, 0, pha_leaf, NULL) ;
					for ( octi = 0 ; octi < octcount ; ++octi , ++x64 ) {
						printf ( "%016llx" , *x64 ) ;
					}
					printf ( " (%s)\n" , tmpstr ) ;
				}
			} else if ( strcmp ( *argv , "-V" ) == 0 ) {
				printf ("%s_%s_%s_%s_%s\n", SWNAME, SWVERS, CPUMODEL, OSBRAND, OSVERS) ;
			} else if ( strcmp ( *argv , "--check" ) == 0 ) {
				if ( ( tp = *++argv ) == NULL ) {
					--argv ;
				} else {
					phacheck (tp) ;
				}
			} else if ( strcmp ( *argv , "-c" ) == 0 ) {
				if ( ( tp = *++argv ) == NULL ) {
					--argv ;
				} else {
					phacheck (tp) ;
				}
			} else if ( strcmp ( *argv , "-p" ) == 0 ) {
				++perfflag ;
			} else if ( strcmp ( *argv , "-P" ) == 0 ) {
				++progressflag ;
			} else if ( strcmp ( *argv , "-S" ) == 0 ) {
				++singleflag ;
			} else if ( strcmp ( *argv , "-t" ) == 0 ) {
				++timeflag ;
			} else if ( strcmp ( *argv , "-v" ) == 0 ) {
				++verboseflag ;
			} else if ( strcmp ( *argv , "-D" ) == 0 ) {
				++dumpflag ;
			} else if ( strcmp ( *argv , "-k" ) == 0 ) {
				++keepflag ;
			} else if ( strcmp ( *argv , "-l" ) == 0 ) {
				++logflag ;
				tp = *++argv ;
				if ( tp == NULL ) {
					--argv ;
				} else {
					if ( stat ( tp , &stabuf ) == 0 ) {
						if ( verboseflag ) {
							fprintf (stderr, "* warning: global log file (%s) already exists. ignored.\n", tp) ;
						}
						--argv ;
					} else {
						givenlog = strdup (tp) ;
					}
				}
			} else if ( strcmp ( *argv , "-d" ) == 0 ) {
				++dumpflag ;
				++markflag ;
				++timeflag ;
				++perfflag ;
			} else if ( strcmp ( *argv , "-n" ) == 0 ) {
				if ( ( tp = *++argv ) == NULL ) {
					--argv ;
				} else {
					giventhreads = atoi (tp) ;
				}
			} else if ( strcmp ( *argv , "-N" ) == 0 ) {
				if ( ( tp = *++argv ) == NULL ) {
					--argv ;
				} else {
					++poolflag ;
					giventhreads = atoi (tp) ;
				}
			} else if ( strcmp ( *argv , "-b" ) == 0 ) {
				phabufsiz = atoi (*++argv) ;
			} else if ( strcmp ( *argv , "-m" ) == 0 ) {
				phamaxsiz = atoi (*++argv) ;
			} else if ( strcmp ( *argv , "-w" ) == 0 ) {
				tp = *++argv ;
				if ( tp == NULL ) {
					--argv ;
				} else {
					givenwid = atoi (tp) ;
					sievewid (givenwid) ;
				}
			} else if ( strcmp ( *argv , "--demo" ) == 0 ) {
				++demoflag ; demofact = 1 ;
			} else if ( strcmp ( *argv , "--Demo" ) == 0 ) {
				++demoflag ; demofact = 10 ;
			} else if ( strcmp ( *argv , "--DEMO" ) == 0 ) {
				++demoflag ; demofact = 100 ;
			} else if ( strcmp ( *argv , "--fast" ) == 0 ) {
				++fastflag ;
			} else if ( strcmp ( *argv , "--stdin" ) == 0 ) {
				pharoll ( *argv ) ;
			} else if ( strcmp ( *argv , "-H" ) == 0 ) {
				++headerflag ;
			} else if ( strcmp ( *argv , "-?" ) == 0 ) {
				++helpflag ;
			} else if ( strcmp ( *argv , "-h" ) == 0 ) {
				++helpflag ;
			} else if ( strcmp ( *argv , "--help" ) == 0 ) {
				++helpflag ;
			} else if ( strcmp ( *argv , "-X" ) == 0 ) {
				++haleflag ;
			} else if ( strcmp ( *argv , "-x" ) == 0 ) {
				++haleflag ;
				++lessflag ;
			} else if ( strcmp ( *argv , "--hale" ) == 0 ) {
				++haleflag ;
			} else {	/* default : pathname */
				if ( **argv == '-' ) {
					++helpflag ;
				} else {
					pharoll ( *argv ) ;
				}
			}
		}
	} else {
		fprintf (stderr, "* try '%s -h' for help.\n", tp) ;
		exit (1) ;
	}

	if ( argk < 2 ) {
		++helpflag ;
	}

	pha () ;

	return 0 ;
}

/*________________________________________________________________________
*/

/*
 * vi:nu ts=4
 */
