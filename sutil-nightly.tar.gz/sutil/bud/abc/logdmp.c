
# include <stdio.h>

# ifdef LOGDMPDBG
/* const FILE * stdlog ; */
# endif

