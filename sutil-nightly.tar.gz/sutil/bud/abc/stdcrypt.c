
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdcrypt.c						 crypto stuff	|
 *		\ \/ /		|	(c) 2000				alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# ifdef LABIX

#	define	USE_STDIO
#	define	USE_STDCRYPT
#	include	"abc.h"

# else /* PLAIN */

# include  <stdio.h>
# include  "stdcrypt.h"

# endif /* LABIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef ICE

::::::::::::::
icepack/ANSI-C/Makefile
::::::::::::::
#
# This is a very rudimentary Makefile to compile the library libice.a
# from the ANSI-C source. Installation of the header files, library,
# and man pages is up to you.
#
# Written by Matthew Kwan, November 1996
#

CC =		gcc
CPPFLAGS =	-O

libice.a:	ice.o
		ar ruvs $@ ice.o

ice.o:		ice.c ice.h
::::::::::::::
icepack/ANSI-C/ice_key_create.html
::::::::::::::
<HTML>
<HEAD><TITLE>The ICE Encryption Library</TITLE></HEAD>
<BODY BGCOLOR="#d8d8d8" TEXT="#000080" LINK="#0000FF">
<H1>The ICE Encryption Library</H1>
<H3>Synopsis</H3>

<DL>
  <DD> <CODE>#include &lt;ice.h&gt;</CODE>
  <BR><BR>
  <DD> <CODE>ICE_KEY *ice_key_create (int level);</CODE>
  <BR><BR>
  <DD> <CODE>void ice_key_destroy (ICE_KEY *ik);</CODE>
  <BR><BR>
  <DD> <CODE>void ice_key_set (ICE_KEY *ik, const unsigned char *key);</CODE>
  <BR><BR>
  <DD> <CODE>void ice_key_encrypt (const ICE_KEY *ik,
       const unsigned char *plaintext, unsigned char *ciphertext);</CODE>
  <BR><BR>
  <DD> <CODE>void ice_key_decrypt (const ICE_KEY *ik,
       const unsigned char *ciphertext, unsigned char *plaintext);</CODE>
  <BR><BR>
  <DD> <CODE>int ice_key_key_size (const ICE_KEY *ik);</CODE>
  <BR><BR>
  <DD> <CODE>int ice_key_block_size (const ICE_KEY *ik);</CODE>
</DL>

<H3>Description</H3>
<P>
The ICE library <B>libice.a</B> contains functions for encrypting and
decrypting 64-bit blocks of data with the ICE (Information Concealment
Engine) encryption algorithm. </P>
<P>
The function <CODE>ice_key_create()</CODE> creates a new <CODE>ICE_KEY</CODE>
that can be used to encrypt and decrypt data. The <EM>level</EM> of
encryption determines the size of the key, and hence its speed.
Level 0 uses the Thin-ICE variant, which is an 8-round cipher taking
an 8-byte key. This is the fastest option, and is generally considered
to be at least as secure as DES, although it is not yet certain whether
it is as secure as its key size. </P>
<P>
For levels <EM>n</EM> greater than zero, a 16<EM>n</EM>-round cipher is
used, taking 8<EM>n</EM>-byte keys. Although not as fast as level 0, these
are very very secure. </P>
<P>
Before an <CODE>ICE_KEY</CODE> can be used to encrypt data, its key
schedule must be set with the <CODE>ice_key_set()</CODE> function.
The length of the key required is determined by the level, as described
above. </P>
<P>
The functions <CODE>ice_key_encrypt()</CODE> and <CODE>ice_key_decrypt()</CODE>
encrypt and decrypt respectively data in blocks of eight characters, using
the specified key. </P>
<P>
Two functions <CODE>ice_key_key_size()</CODE> and
<CODE>ice_key_block_size()</CODE>
are provided which return the key and block size
respectively, measured in bytes. The key size is determined by
the level, while the block size is always 8. </P>
<P>
To destroy a key when it is no longer needed, the function
<CODE>ice_key_destroy()</CODE> should be used. As well as freeing up
memory, it zeroes it out, thus preventing snooping. </P>

<HR>
<DIV ALIGN=RIGHT>
<FONT SIZE=-1>
Document last modified by Matthew Kwan, 28 November 1998 <BR>
Please send any comments or corrections to
<A HREF="mailto:mkwan@darkside.com.au">mkwan@darkside.com.au</A>
</FONT>
</DIV>

</BODY>
</HTML>
::::::::::::::
icepack/ANSI-C/ice.c
::::::::::::::
/*
 * Implementation of the ICE encryption algorithm.
 *
 * Written by Matthew Kwan - July 1996
 */

#include "ice.h"
#include <stdio.h>
#include <stdlib.h>


	/* Structure of a single round subkey */
typedef unsigned long	ICE_SUBKEY[3];


	/* Internal structure of the ICE_KEY structure */
struct ice_key_struct {
	int		ik_size;
	int		ik_rounds;
	ICE_SUBKEY	*ik_keysched;
};

	/* The S-boxes */
static unsigned long	ice_sbox[4][1024];
static int		ice_sboxes_initialised = 0;


	/* Modulo values for the S-boxes */
static const int	ice_smod[4][4] = {
				{333, 313, 505, 369},
				{379, 375, 319, 391},
				{361, 445, 451, 397},
				{397, 425, 395, 505}};

	/* XOR values for the S-boxes */
static const int	ice_sxor[4][4] = {
				{0x83, 0x85, 0x9b, 0xcd},
				{0xcc, 0xa7, 0xad, 0x41},
				{0x4b, 0x2e, 0xd4, 0x33},
				{0xea, 0xcb, 0x2e, 0x04}};

	/* Expanded permutation values for the P-box */
static const unsigned long	ice_pbox[32] = {
		0x00000001, 0x00000080, 0x00000400, 0x00002000,
		0x00080000, 0x00200000, 0x01000000, 0x40000000,
		0x00000008, 0x00000020, 0x00000100, 0x00004000,
		0x00010000, 0x00800000, 0x04000000, 0x20000000,
		0x00000004, 0x00000010, 0x00000200, 0x00008000,
		0x00020000, 0x00400000, 0x08000000, 0x10000000,
		0x00000002, 0x00000040, 0x00000800, 0x00001000,
		0x00040000, 0x00100000, 0x02000000, 0x80000000};

	/* The key rotation schedule */
static const int	ice_keyrot[16] = {
				0, 1, 2, 3, 2, 1, 3, 0,
				1, 3, 2, 0, 3, 1, 0, 2};


/*
 * Galois Field multiplication of a by b, modulo m.
 * Just like arithmetic multiplication, except that additions and
 * subtractions are replaced by XOR.
 */

static unsigned int
gf_mult (
	register unsigned int	a,
	register unsigned int	b,
	register unsigned int	m
) {
	register unsigned int	res = 0;

	while (b) {
	    if (b & 1)
		res ^= a;

	    a <<= 1;
	    b >>= 1;

	    if (a >= 256)
		a ^= m;
	}

	return (res);
}


/*
 * Galois Field exponentiation.
 * Raise the base to the power of 7, modulo m.
 */

static unsigned long
gf_exp7 (
	register unsigned int	b,
	unsigned int		m
) {
	register unsigned int	x;

	if (b == 0)
	    return (0);

	x = gf_mult (b, b, m);
	x = gf_mult (b, x, m);
	x = gf_mult (x, x, m);
	return (gf_mult (b, x, m));
}


/*
 * Carry out the ICE 32-bit P-box permutation.
 */

static unsigned long
ice_perm32 (
	register unsigned long	x
) {
	register unsigned long		res = 0;
	register const unsigned long	*pbox = ice_pbox;

	while (x) {
	    if (x & 1)
		res |= *pbox;
	    pbox++;
	    x >>= 1;
	}

	return (res);
}


/*
 * Initialise the ICE S-boxes.
 * This only has to be done once.
 */

static void
ice_sboxes_init (void)
{
	register int	i;

	for (i=0; i<1024; i++) {
	    int			col = (i >> 1) & 0xff;
	    int			row = (i & 0x1) | ((i & 0x200) >> 8);
	    unsigned long	x;

	    x = gf_exp7 (col ^ ice_sxor[0][row], ice_smod[0][row]) << 24;
	    ice_sbox[0][i] = ice_perm32 (x);

	    x = gf_exp7 (col ^ ice_sxor[1][row], ice_smod[1][row]) << 16;
	    ice_sbox[1][i] = ice_perm32 (x);

	    x = gf_exp7 (col ^ ice_sxor[2][row], ice_smod[2][row]) << 8;
	    ice_sbox[2][i] = ice_perm32 (x);

	    x = gf_exp7 (col ^ ice_sxor[3][row], ice_smod[3][row]);
	    ice_sbox[3][i] = ice_perm32 (x);
	}
}


/*
 * Create a new ICE key.
 */

ICE_KEY *
ice_key_create (
	int		n
) {
	ICE_KEY		*ik;

	if (!ice_sboxes_initialised) {
	    ice_sboxes_init ();
	    ice_sboxes_initialised = 1;
	}

	if ((ik = (ICE_KEY *) malloc (sizeof (ICE_KEY))) == NULL)
	    return (NULL);

	if (n < 1) {
	    ik->ik_size = 1;
	    ik->ik_rounds = 8;
	} else {
	    ik->ik_size = n;
	    ik->ik_rounds = n * 16;
	}

	if ((ik->ik_keysched = (ICE_SUBKEY *) malloc (ik->ik_rounds
					* sizeof (ICE_SUBKEY))) == NULL) {
	    free (ik);
	    return (NULL);
	}

	return (ik);
}


/*
 * Destroy an ICE key.
 * Zero out the memory to prevent snooping.
 */

void
ice_key_destroy (
	ICE_KEY		*ik
) {
	int		i, j;

	if (ik == NULL)
	    return;

	for (i=0; i<ik->ik_rounds; i++)
	    for (j=0; j<3; j++)
		ik->ik_keysched[i][j] = 0;

	ik->ik_rounds = ik->ik_size = 0;

	if (ik->ik_keysched != NULL)
	    free (ik->ik_keysched);

	free (ik);
}


/*
 * The single round ICE f function.
 */

static unsigned long
ice_f (
	register unsigned long	p,
	const ICE_SUBKEY	sk
) {
	unsigned long	tl, tr;		/* Expanded 40-bit values */
	unsigned long	al, ar;		/* Salted expanded 40-bit values */

					/* Left half expansion */
	tl = ((p >> 16) & 0x3ff) | (((p >> 14) | (p << 18)) & 0xffc00);

					/* Right half expansion */
	tr = (p & 0x3ff) | ((p << 2) & 0xffc00);

					/* Perform the salt permutation */
				/* al = (tr & sk[2]) | (tl & ~sk[2]); */
				/* ar = (tl & sk[2]) | (tr & ~sk[2]); */
	al = sk[2] & (tl ^ tr);
	ar = al ^ tr;
	al ^= tl;

	al ^= sk[0];			/* XOR with the subkey */
	ar ^= sk[1];

					/* S-box lookup and permutation */
	return (ice_sbox[0][al >> 10] | ice_sbox[1][al & 0x3ff]
		| ice_sbox[2][ar >> 10] | ice_sbox[3][ar & 0x3ff]);
}


/*
 * Encrypt a block of 8 bytes of data with the given ICE key.
 */

void
ice_key_encrypt (
	const ICE_KEY		*ik,
	const unsigned char	*ptext,
	unsigned char		*ctext
) {
	register int		i;
	register unsigned long	l, r;

	l = (((unsigned long) ptext[0]) << 24)
				| (((unsigned long) ptext[1]) << 16)
				| (((unsigned long) ptext[2]) << 8) | ptext[3];
	r = (((unsigned long) ptext[4]) << 24)
				| (((unsigned long) ptext[5]) << 16)
				| (((unsigned long) ptext[6]) << 8) | ptext[7];

	for (i = 0; i < ik->ik_rounds; i += 2) {
	    l ^= ice_f (r, ik->ik_keysched[i]);
	    r ^= ice_f (l, ik->ik_keysched[i + 1]);
	}

	for (i = 0; i < 4; i++) {
	    ctext[3 - i] = r & 0xff;
	    ctext[7 - i] = l & 0xff;

	    r >>= 8;
	    l >>= 8;
	}
}


/*
 * Decrypt a block of 8 bytes of data with the given ICE key.
 */

void
ice_key_decrypt (
	const ICE_KEY		*ik,
	const unsigned char	*ctext,
	unsigned char		*ptext
) {
	register int		i;
	register unsigned long	l, r;

	l = (((unsigned long) ctext[0]) << 24)
				| (((unsigned long) ctext[1]) << 16)
				| (((unsigned long) ctext[2]) << 8) | ctext[3];
	r = (((unsigned long) ctext[4]) << 24)
				| (((unsigned long) ctext[5]) << 16)
				| (((unsigned long) ctext[6]) << 8) | ctext[7];

	for (i = ik->ik_rounds - 1; i > 0; i -= 2) {
	    l ^= ice_f (r, ik->ik_keysched[i]);
	    r ^= ice_f (l, ik->ik_keysched[i - 1]);
	}

	for (i = 0; i < 4; i++) {
	    ptext[3 - i] = r & 0xff;
	    ptext[7 - i] = l & 0xff;

	    r >>= 8;
	    l >>= 8;
	}
}


/*
 * Set 8 rounds [n, n+7] of the key schedule of an ICE key.
 */

static void
ice_key_sched_build (
	ICE_KEY		*ik,
	unsigned short	*kb,
	int		n,
	const int	*keyrot
) {
	int		i;

	for (i=0; i<8; i++) {
	    register int	j;
	    register int	kr = keyrot[i];
	    ICE_SUBKEY		*isk = &ik->ik_keysched[n + i];

	    for (j=0; j<3; j++)
		(*isk)[j] = 0;

	    for (j=0; j<15; j++) {
		register int	k;
		unsigned long	*curr_sk = &(*isk)[j % 3];

		for (k=0; k<4; k++) {
		    unsigned short	*curr_kb = &kb[(kr + k) & 3];
		    register int	bit = *curr_kb & 1;

		    *curr_sk = (*curr_sk << 1) | bit;
		    *curr_kb = (*curr_kb >> 1) | ((bit ^ 1) << 15);
		}
	    }
	}
}


/*
 * Set the key schedule of an ICE key.
 */

void
ice_key_set (
	ICE_KEY			*ik,
	const unsigned char	*key
) {
	int		i;

	if (ik->ik_rounds == 8) {
	    unsigned short	kb[4];

	    for (i=0; i<4; i++)
		kb[3 - i] = (key[i*2] << 8) | key[i*2 + 1];

	    ice_key_sched_build (ik, kb, 0, ice_keyrot);
	    return;
	}

	for (i = 0; i < ik->ik_size; i++) {
	    int			j;
	    unsigned short	kb[4];

	    for (j=0; j<4; j++)
		kb[3 - j] = (key[i*8 + j*2] << 8) | key[i*8 + j*2 + 1];

	    ice_key_sched_build (ik, kb, i*8, ice_keyrot);
	    ice_key_sched_build (ik, kb, ik->ik_rounds - 8 - i*8,
							&ice_keyrot[8]);
	}
}


/*
 * Return the key size, in bytes.
 */

int
ice_key_key_size (
	const ICE_KEY	*ik
) {
	return (ik->ik_size * 8);
}


/*
 * Return the block size, in bytes.
 */

int
ice_key_block_size (
	const ICE_KEY	*ik
) {
	return (8);
}
::::::::::::::
icepack/ANSI-C/ice.h
::::::::::::::
/*
 * Header file for the ICE encryption library.
 *
 * Written by Matthew Kwan - July 1996
 */

#ifndef _ICE_H
#define _ICE_H

typedef struct ice_key_struct	ICE_KEY;

#if __STDC__
#define P_(x) x
#else
#define P_(x) ()
#endif

extern ICE_KEY	*ice_key_create P_((int n));
extern void	ice_key_destroy P_((ICE_KEY *ik));
extern void	ice_key_set P_((ICE_KEY *ik, const unsigned char *k));
extern void	ice_key_encrypt P_((const ICE_KEY *ik,
			const unsigned char *ptxt, unsigned char *ctxt));
extern void	ice_key_decrypt P_((const ICE_KEY *ik,
			const unsigned char *ctxt, unsigned char *ptxt));
extern int	ice_key_key_size P_((const ICE_KEY *ik));
extern int	ice_key_block_size P_((const ICE_KEY *ik));

#undef P_

#endif
::::::::::::::
icepack/ANSI-C/ice_key_create.3
::::::::::::::
.TH ICE_KEY_CREATE 3 "28 Nov 1998" "Version 1.3"
.SH NAME
ice_key_create, ice_key_destroy, ice_key_set,
ice_key_encrypt, ice_key_decrypt \- the ICE encryption library
.SH SYNOPSIS
.B #include <ice.h>
.PP
.B ICE_KEY *ice_key_create (int \fIlevel\fP);
.PP
.B void ice_key_destroy (ICE_KEY *\fIik\fP);
.PP
.B void ice_key_set (ICE_KEY *\fIik\fP,
.B const unsigned char *\fIkey\fP);
.PP
.B void ice_key_encrypt (const ICE_KEY *\fIik\fP,
.B const unsigned char *\fIplaintext\fP,
.B unsigned char *\fIciphertext\fP);
.PP
.B void ice_key_decrypt (const ICE_KEY *\fIik\fP,
.B const unsigned char *\fIciphertext\fP,
.B unsigned char *\fIplaintext\fP);
.PP
.B int ice_key_key_size (const ICE_KEY *\fIik\fP);
.PP
.B int ice_key_block_size (const ICE_KEY *\fIik\fP);
.SH DESCRIPTION
The ICE library \fBlibice.a\fP contains functions for encrypting
and decrypting 64-bit blocks of data with the ICE (Information
Concealment Engine) encryption algorithm.
.PP
The function \fBice_key_create()\fP creates a new \fBICE_KEY\fP that
can be used to encrypt and decrypt data. The \fIlevel\fP of encryption
determines the size of the key, and hence its speed. Level 0 uses
the Thin-ICE variant, which is an 8-round cipher taking an
8-byte key. This is the fastest option, and is generally considered
to be at least as secure as DES, although it is not yet certain whether
it is as secure as its key size.
.PP
For levels \fIn\fP greater that zero, a 16\fIn\fP-round cipher is
used, taking 8\fIn\fP-byte keys. Although not as fast as level 0,
these are very very secure.
.PP
Before an \fBICE_KEY\fP can be used to encrypt data, its key schedule
must be set with the \fBice_key_set()\fP function. The length of the
key required is determined by the level, as described above.
.PP
The functions \fBice_key_encrypt()\fP and \fBice_key_decrypt()\fP
encrypt and decrypt respectively data in blocks of eight characters,
using the specified key.
.PP
Two functions \fBice_key_key_size()\fP and \fBice_key_block_size()\fP
are provided which return the key and block size
respectively, measured in bytes. The key size is determined by
the level, while the block size is always 8.
.PP
To destroy a key when it is no longer needed, the function
\fBice_key_destroy()\fP should be used. As well as freeing up
memory, it zeroes it out, thus preventing snooping.
.SH AUTHOR
This library was written by Matthew Kwan, who can be reached at
mkwan@darkside.com.au
.SH SEE ALSO
\fBice\fP(1)
::::::::::::::
icepack/ANSI-C/icecrypt/Makefile
::::::::::::::
#
# This is a very rudimentary Makefile to compile the "ice" command-line
# encryption program. It also create a file "deice", which is simply a
# symbolic link to "ice".
#
# For this to work, libice.a must exist in the directory above.
# Installation is left as an exercise for the reader.
#
# Written by Matthew Kwan, November 1996
#

CC =		gcc
CPPFLAGS =	-O -I..
LDFLAGS =	-L.. -lice

ice:		main.o deice
		$(CC) -o $@ $< $(LDFLAGS)

deice:
		@if [ ! -h deice ] ; then ln -s ice deice ; fi

clean:
		rm -f *.o ice deice
::::::::::::::
icepack/ANSI-C/icecrypt/ice.1
::::::::::::::
.TH ICE 1 "7 Dec 1996" "Version 1.1"
.SH NAME
ice, deice \- encrypt and decrypt data
.SH SYNOPSIS
.B ice
[
.B -CDNZ
] [
.B -p
.I passwd
] [
.B -l
.I level
] [
.I file ...
]
.br
.B deice
[
.B -CNZ
] [
.B -p
.I passwd
] [
.B -l
.I level
] [
.I file ...
]
.SH DESCRIPTION
\fBice\fP and \fBdeice\fP
are programs for encrypting and decrypting files using the
ICE (Information Concealment Engine) encryption algorithm.
The data is encrypted in Cipher Block Chaining (CBC) mode,
with an initialization vector by default obtained from the
\fBgettimeofday\fP(2) function.
.PP
The ICE encryption algorithm allows key lengths of any multiple
of 64 bits by specifying the encryption \fIlevel\fP. Specifying
a level greater than 1 allows long passwords, and correspondingly
higher security. The drawback is slower encryption.
.PP
This program only uses the lower 7 bits from each character in
the password, so the first 10 characters are significant when
using levels 0 or 1. For higher levels \fIn\fP, the key size
is 64\fIn\fP, so the useful password length will be
(64\fIn\fP + 6)/7. Short passwords will be padded out with zeroes.
.PP
The \fBdeice\fP program is typically a symbolic link to the \fBice\fP
executable, since the program automatically uses decrypt mode if
the name of the executable begins with the characters "de".
.PP
When encrypting, a new file will be created with a \fI.ice\fP
suffix, and the original file deleted. Before deletion, the original
file is overwritten with zeroes to minimize the chance that the
data remains in the filesystem. Where possible the new file
will have the same permissions as the original. If no files are
specified, data will be read from standard input.
.PP
For decryption, the files must have a \fI.ice\fP suffix, or there
must be a \fIfile.ice\fP for every \fIfile\fP. The program will
check that the data is ICE-encrypted, but it will give no indication
as to whether the correct password is being used, so beware.
.PP
The encrypted file format contains "ice" as the first three
characters, followed the value of the character "0" added to
the ICE level being used. The next eight bytes contain the
initialization vector, followed by the actual encrypted data.
This information, plus padding of the last block, will increase
the file size by between 13 and 20 bytes.
.SH OPTIONS
.TP
.B -C
Send encrypted/decrypted output to standard output.
.TP
.B -D
Decrypt the data. This is the default in \fBdeice\fP.
.TP
.B -N
Do not ask for confirmation of the password when an interactive password
is required. By default, the user has to type the password twice.
.TP
.B -Z
Use a zero initializing vector. Only useful if identical files have
to encrypt identically. The initializing vector
is otherwise set from time of day information. In the case of
decryption the vector is read from the data anyway, so this flag
is ignored.
.TP
\fB-p\fP \fIpassword\fP
The password used to encrypt/decrypt the data. If this is set, no
interactive password is required. This password is zeroed out at the
first opportunity to prevent it appearing in the process table.
.TP
\fB-l\fP \fIlevel\fP
The ICE level used to encrypt the data. Defaults to 1. This is ignored
during decryption, since the level information is stored in the data.
.SH EXAMPLES
The following command will encrypt the file \fIfoo\fP, and store
the result in \fIfoo.ice\fP. The user will be prompted twice for a
password, which will have the first 10 of its characters used.
.PP
.RS
\fBice foo\fP
.RE
.PP
The next example will encrypt the same file with a command line
password using level 2 ICE.
.PP
.RS
\fBice -l2 -p"The first 19 charac" foo\fP
.RE
.PP
The resulting file can be decrypted with
.PP
.RS
\fBdeice -p"The first 19 charac" foo.ice\fP
.RE
.SH AUTHOR
This application was written by Matthew Kwan, who can be reached at
mkwan@darkside.com.au
.SH SEE ALSO
\fBice_key_create\fP(3)
::::::::::::::
icepack/ANSI-C/icecrypt/main.c
::::::::::::::
/*
 * Command-line program for encrypting/decrypting data files
 * with the ICE encryption algorithm.
 *
 * It uses Cipher Block Chaining (CBC) with an initialization
 * vector obtained by default from the gettimeofday call.
 *
 * Usage: ice [-C][-D][-N][-Z][-p passwd][-l level] [filename ...]
 *
 *	-C : Send encrypted/decrypted output to stdout
 *	-D : Decrypt the input data
 *	-N : Do not ask for confirmation for interactive passwords
 *	-Z : Use a zero initializing vector. Otherwise use time of day.
 *	-p : Specify the password on the command-line
 *	-l : Specify the ICE level of encryption
 *
 * If the program is executed with a name beginning with the
 * characters 'de' (e.g. via a symbolic link) the program will carry
 * out decryption by default.
 *
 * For encryption, an encrypted file "infile.ice" will be created for
 * each specified file. It should have the same permission bits as the
 * original files.
 *
 * For decryption, the files must have a ".ice" suffix, or there must
 * be a file "infile.ice" for each file.
 *
 * Written by Matthew Kwan - September 1996
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <memory.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <termio.h>
#include <fcntl.h>

#include "ice.h"


/*
 * Define boolean types.
 */

typedef unsigned int	BOOL;

#ifndef FALSE
#define FALSE	0
#endif

#ifndef TRUE
#define TRUE	1
#endif


/*
 * Maximum password length.
 * Max key is 1024 bytes. 7 bits per char yields 1171 characters.
 */

#define MAX_PASSLEN	1171


/*
 * Build the ICE key from the supplied password.
 * Only uses the lower 7 bits from each character.
 */

static ICE_KEY *
key_build (
	int		level,
	const char	*passwd
) {
	int		i = 0;
	unsigned char	buf[1024];
	ICE_KEY		*ik;

	if ((ik = ice_key_create (level)) == NULL)
	    return (NULL);

	memset (buf, 0, sizeof (buf));

	while (*passwd != '\0') {
	    unsigned char	c = *passwd & 0x7f;
	    int			idx = i / 8;
	    int			bit = i & 7;

	    if (bit == 0) {
		buf[idx] = (c << 1);
	    } else if (bit == 1) {
		buf[idx] |= c;
	    } else {
		buf[idx] |= (c >> (bit - 1));
		buf[idx + 1] = (c << (9 - bit));
	    }

	    i += 7;
	    passwd++;
	}

	ice_key_set (ik, buf);

	return (ik);
}


/*
 * If possible, zero out the contents of a file.
 */

static void
file_zero (
	const char	*fname
) {
	int		fd;
	int		flen, i;
	char		buf[4096];
	struct stat	statbuf;

	if ((fd = open (fname, O_WRONLY)) < 0)
	    return;

	if (fstat (fd, &statbuf) < 0) {
	    close (fd);
	    return;
	}

	for (i=0; i<4096; i++)
	    buf[i] = 0;

	flen = statbuf.st_size;
	for (i=0; i<flen; i+= 4096) {
	    int		n = flen - i;

	    if (n > 4096)
		n = 4096;

	    if (write (fd, buf, n) < 0) {
		close (fd);
		return;
	    }
	}

	close (fd);
}


/*
 * Erase a file.
 * Fill it with zeroes, then unlink it.
 */

static int
erase_file (
	const char	*fname
) {
	file_zero (fname);
	return (unlink (fname));
}


/*
 * Write an 8-byte block to the specified file.
 */

static BOOL
block_write (
	const unsigned char	*buf,
	FILE			*fp
) {
	if (fwrite (buf, sizeof (unsigned char), 8, fp) != 8) {
	    perror (NULL);
	    return (FALSE);
	}

	return (TRUE);
}


/*
 * Copy an 8-byte block.
 */

static void
block_copy (
	unsigned char		*dest,
	const unsigned char	*src
) {
	int		i;

	for (i=0; i<8; i++)
	    dest[i] = src[i];
}


/*
 * XOR an 8-byte block onto another one.
 */

static void
block_xor (
	unsigned char		*dest,
	const unsigned char	*src
) {
	int		i;

	for (i=0; i<8; i++)
	    dest[i] ^= src[i];
}


/*
 * Pad an 8-byte block in positions n .. 7
 * The lower 3 bits of the last byte will contain the value n.
 * The padding will be an encrypted copy of the IV so as to
 * thwart a ciphertext-only attack which might look for padding
 * bytes.
 */

static void
block_pad (
	unsigned char		*buf,
	int			n,
	const unsigned char	*padding
) {
	int		i;

	for (i=n; i<8; i++)
	    buf[i] = padding[i];

	buf[7] = (buf[7] & 0xf8) | n;
}


/*
 * Encrypt a data stream with the given key.
 * Uses cipher-block-chaining mode.
 * The first 3 bytes are the characters "ice". The next character
 * is the character "0" plus the ICE level being used.
 * The next 8 bytes are the initializing vector.
 */

static BOOL
encrypt_stream (
	const ICE_KEY		*ik,
	int			level,
	const unsigned char	*iv,
	FILE			*inf,
	FILE			*outf
) {
	int			n;
	unsigned char		buf[8], inbuf[8], outbuf[8];

	buf[0] = 'i';
	buf[1] = 'c';
	buf[2] = 'e';
	buf[3] = '0' + level;

	if (fwrite (buf, sizeof (unsigned char), 4, outf) != 4) {
	    perror (NULL);
	    return (FALSE);
	}

	block_copy (outbuf, iv);
	if (!block_write (outbuf, outf))
	    return (FALSE);

	while ((n = fread (inbuf, sizeof (unsigned char), 8, inf)) == 8) {
	    block_xor (inbuf, outbuf);
	    ice_key_encrypt (ik, inbuf, outbuf);
	    if (!block_write (outbuf, outf))
		return (FALSE);
	}

	ice_key_encrypt (ik, iv, buf);		/* Generate padding bytes */
	block_pad (inbuf, n, buf);
	block_xor (inbuf, outbuf);
	ice_key_encrypt (ik, inbuf, outbuf);

	if (!block_write (outbuf, outf))
	    return (FALSE);

	return (TRUE);
}


/*
 * Encrypt the specified file.
 * If an output stream isn't specified, write the encrypted data
 * to a file "fname.ice", then remove the original file "fname".
 */

static BOOL
encrypt_file (
	const ICE_KEY		*ik,
	int			level,
	const unsigned char	*iv,
	const char		*fname,
	FILE			*output_file
) {
	FILE			*inf, *outf;
	char			buf[BUFSIZ];
	BOOL			res;

	if ((inf = fopen (fname, "r")) == NULL) {
	    perror (fname);
	    return (FALSE);
	}

	if (output_file == NULL) {
	    struct stat		filestat;

	    sprintf (buf, "%s.ice", fname);
	    if ((outf = fopen (buf, "w")) == NULL) {
		perror (buf);
		fclose (inf);
		return (FALSE);
	    }

			/* Try to maintain same permissions */
	    if (stat (fname, &filestat) == 0)
		chmod (buf, filestat.st_mode);
	} else
	    outf = output_file;

	res = encrypt_stream (ik, level, iv, inf, outf);

	if (output_file == NULL)
	    fclose (outf);

	fclose (inf);

	if (!res)
	    return (FALSE);

			/* Delete the source file if a new file is made */
	if (output_file == NULL && erase_file (fname) < 0) {
	    perror (fname);
	    return (FALSE);
	}

	return (TRUE);
}


/*
 * Decrypt a data stream with the given key.
 * The first 3 characters must be "ice", followed by the encryption
 * level + '0'. Next is the initializing vector, followed by the
 * actual encrypted data.
 * The final block read will be padded. Its true length is given in
 * the lower 3 bits of the 7th byte of the block.
 */

static BOOL
decrypt_stream (
	const char	*passwd,
	FILE		*inf,
	FILE		*outf
) {
	unsigned char	prevbuf[8], inbuf[8], outbuf[8];
	int		n, level;
	ICE_KEY		*ik;
	BOOL		block_loaded_flag;

			/* Check the magic number */
	if (fread (inbuf, sizeof (unsigned char), 4, inf) != 4) {
	    fprintf (stderr, "Could not read magic number\n");
	    return (FALSE);
	}

	if (inbuf[0] != 'i' || inbuf[1] != 'c' || inbuf[2] != 'e') {
	    fprintf (stderr, "Illegal magic number\n");
	    return (FALSE);
	}

	level = inbuf[3] - '0';
	if (level < 0)
	    level += 256;

	if (level > 128) {
	    fprintf (stderr, "Level %d is too high\n", level);
	    return (FALSE);
	}

	if ((ik = key_build (level, passwd)) == NULL)
	    return (FALSE);

			/* Read the initializing vector */
	if (fread (prevbuf, sizeof (unsigned char), 8, inf) != 8) {
	    fprintf (stderr, "Could not read initializing vector\n");
	    return (FALSE);
	}

	block_loaded_flag = FALSE;
	while ((n = fread (inbuf, sizeof (unsigned char), 8, inf)) == 8) {
	    if (block_loaded_flag && !block_write (outbuf, outf))
		return (FALSE);

	    ice_key_decrypt (ik, inbuf, outbuf);
	    block_xor (outbuf, prevbuf);
	    block_loaded_flag = TRUE;

	    block_copy (prevbuf, inbuf);
	}

	if (n != 0)
	    fprintf (stderr, "Warning: truncated final block\n");

		/* The buffer should contain padding info in its last byte */
	n = outbuf[7] & 7;
	if (fwrite (outbuf, sizeof (unsigned char), n, outf) != n) {
	    perror (NULL);
	    return (FALSE);
	}

	ice_key_destroy (ik);

	return (TRUE);
}


/*
 * Decrypt the specified file.
 * If the filename is of the form "foo.ice", that will be the source file.
 * Otherwise, look for a file "filename.ice".
 * If the output stream isn't specified, write to output to a file
 * without the ".ice" suffix, then delete the original file.
 */

static BOOL
decrypt_file (
	const char	*passwd,
	const char	*fname,
	FILE		*output_file
) {
	FILE		*inf, *outf;
	int		n = strlen (fname);
	char		inbuf[BUFSIZ], outbuf[BUFSIZ];
	BOOL		res;

	if (n > 4 && strcmp (&fname[n-4], ".ice") == 0) {
	    strcpy (inbuf, fname);
	    strcpy (outbuf, fname);
	    outbuf[n-4] = '\0';
	} else {
	    sprintf (inbuf, "%s.ice", fname);
	    strcpy (outbuf, fname);
	}

	if ((inf = fopen (inbuf, "r")) == NULL) {
	    perror (inbuf);
	    return (FALSE);
	}
	if (output_file == NULL) {
	    struct stat		filestat;

	    if ((outf = fopen (outbuf, "w")) == NULL) {
		perror (outbuf);
		fclose (inf);
		return (FALSE);
	    }

			/* Try to maintain same permissions */
	    if (stat (inbuf, &filestat) == 0)
		chmod (outbuf, filestat.st_mode);
	} else
	    outf = output_file;

	res = decrypt_stream (passwd, inf, outf);

	if (output_file == NULL)
	    fclose (outf);

	fclose (inf);

	if (!res)
	    return (FALSE);

			/* Delete the source file if a new file is made */
	if (output_file == NULL && erase_file (inbuf) < 0) {
	    perror (inbuf);
	    return (FALSE);
	}

	return (TRUE);
}


/*
 * Prompt the user for a password, with echo disabled.
 * Ask for confirmation if required.
 */

static BOOL
password_read (
	char		*passwd,
	BOOL		confirm_flag
) {
	int		i, fd;
	BOOL		match_ok = TRUE;
	struct termio	t;
	unsigned short	save_lflag;

	if ((fd = open ("/dev/tty", O_RDWR)) < 0) {
	    perror ("/dev/tty");
	    return (FALSE);
	}

	write (fd, "Password:", 9);
	ioctl (fd, TCGETA, &t);
	save_lflag = t.c_lflag;
	t.c_lflag &= ~ECHO;
	ioctl (fd, TCSETAW, &t);

	for (i=0; i<MAX_PASSLEN; i++) {
	    if (read (fd, &passwd[i], 1) != 1)
		break;
	    if (passwd[i] == '\n')
		break;
	}

	passwd[i] = '\0';
	write (fd, "\n", 1);

	if (confirm_flag) {
	    char	buf2[MAX_PASSLEN + 1];

	    write (fd, "Retype password:", 16);
	    for (i=0; i<MAX_PASSLEN; i++) {
		if (read (fd, &buf2[i], 1) != 1)
		    break;
		if (buf2[i] == '\n')
		    break;
	    }

	    buf2[i] = '\0';
	    write (fd, "\n", 1);

	    if (strcmp (passwd, buf2) != 0)
		match_ok = FALSE;
	}

	t.c_lflag = save_lflag;
	ioctl (fd, TCSETAF, &t);
	close (fd);

	if (passwd[0] == '\0') {
	    fprintf (stderr, "No password entered\n");
	    return (FALSE);
	}

	if (match_ok)
	    return (TRUE);

	fprintf (stderr, "Password mismatch\n");
	return (FALSE);
}


/*
 * Build the initial value string.
 * If it isn't zero, set it from the time of day.
 */

static void
build_iv (
	unsigned char	*iv,
	BOOL		zero_flag
) {
	if (zero_flag)
	    memset (iv, 0, 8 * sizeof (unsigned char));
	else {
	    struct timeval	tv;
	    int			i;

	    gettimeofday (&tv, NULL);
	    for (i=0; i<4; i++) {
		iv[i] = tv.tv_sec & 0xff;
		iv[i + 4] = tv.tv_usec & 0xff;

		tv.tv_sec >>= 8;
		tv.tv_usec >>= 8;
	    }
	}
}


/*
 * Fill a string with zeroes.
 * This is used to hide the password argument.
 */

static void
blank_string (
	char	*s
) {
	int	i, n = strlen (s);

	for (i=0; i<n; i++)
	    *s++ = '\0';
}


/*
 * Program's starting point.
 * Processes command-line args and starts things running.
 */

void
main (
	int		argc,
	char		*argv[]
) {
	int		c;
	BOOL		errflag = FALSE;
	BOOL		confirm_flag = TRUE;
	BOOL		decrypt_flag = FALSE;
	BOOL		passwd_flag = FALSE;
	BOOL		zero_iv_flag = FALSE;
	char		passwd[MAX_PASSLEN + 1];
	FILE		*dest_fp = NULL;
	int		level = 1;

	extern char	*optarg;
	extern int	optind;

	while ((c = getopt (argc, argv, "p:l:CDNZ")) != -1)
	    switch (c) {
		case 'C':
		    dest_fp = stdout;
		    break;
		case 'D':
		    decrypt_flag = TRUE;
		    break;
		case 'N':
		    confirm_flag = FALSE;
		    break;
		case 'Z':
		    zero_iv_flag = TRUE;
		    break;
		case 'l':
		    if (sscanf (optarg, "%d", &level) != 1 || level > 128) {
			fprintf (stderr, "Illegal level value '%s'\n", optarg);
			errflag = TRUE;
		    }
		    break;
		case 'p':
		    if (strlen (optarg) > MAX_PASSLEN) {
			fprintf (stderr,
		"Warning: password truncated to %d characters\n", MAX_PASSLEN);
			optarg[MAX_PASSLEN] = '\0';
		    }
		    strcpy (passwd, optarg);
		    blank_string (optarg);
		    passwd_flag = TRUE;

		    break;
		default:
		    errflag = TRUE;
		    break;
	    }

	if (errflag) {
	    fprintf (stderr, "Usage: %s [-C][-D][-N][-Z]", argv[0]);
	    fprintf (stderr, "[-p passwd][-l level] [filename ...]\n");
	    exit (1);
	}

	if (argv[0][0] == 'd' && argv[0][1] == 'e')
	    decrypt_flag = TRUE;

	if (!passwd_flag) {
	    if (!password_read (passwd, confirm_flag))
		exit (1);
	}

	if (decrypt_flag) {
	    if (level != 1)
		fprintf (stderr,
	"Warning: level setting is ignored during decryption\n");

	    if (optind == argc) {
		if (!decrypt_stream (passwd, stdin, stdout))
		    exit (1);
	    } else {
		int	i;

		for (i=optind; i<argc; i++)
		    if (!decrypt_file (passwd, argv[i], dest_fp))
			exit (1);
	    }
	} else {
	    ICE_KEY		*ik;
	    unsigned char	iv[8];

	    if ((ik = key_build (level, passwd)) == NULL)
		exit (1);

	    build_iv (iv, zero_iv_flag);

	    if (optind == argc) {
		if (!encrypt_stream (ik, level, iv, stdin, stdout))
		    exit (1);
	    } else {
		int	i;

		for (i=optind; i<argc; i++)
		    if (!encrypt_file (ik, level, iv, argv[i], dest_fp))
			exit (1);
	    }

	    ice_key_destroy (ik);
	}

	exit (0);
}
::::::::::::::
icepack/C++/Makefile
::::::::::::::
#
# This is a very rudimentary Makefile to compile an object file from
# the C++ source. What you do with the object file is up to you.
#
# Written by Matthew Kwan, November 1996
#

CPPFLAGS =	-O

IceKey.o:	IceKey.C
::::::::::::::
icepack/C++/IceKey-C++.html
::::::::::::::
<HTML>
<HEAD><TITLE>The C++ ICE Encryption Class</TITLE></HEAD>
<BODY BGCOLOR="#d8d8d8" TEXT="#000080" LINK="#0000FF">

<H1>The C++ ICE Encryption Class</H1>

<H3>Synopsis</H3>

<DL>
  <DD> <CODE>#include &lt;IceKey.H&gt;</CODE>
  <BR><BR>
  <DD> <CODE>IceKey::IceKey (int level)</CODE>
  <BR><BR>
  <DD> <CODE>IceKey::~IceKey ();</CODE>
  <BR><BR>
  <DD> <CODE>void IceKey::set (const unsigned char *key);</CODE>
  <BR><BR>
  <DD> <CODE>void IceKey::encrypt (const unsigned char *plaintext,
       unsigned char *ciphertext) const;</CODE>
  <BR><BR>
  <DD> <CODE>void IceKey::decrypt (const unsigned char *ciphertext,
       unsigned char *plaintext) const;</CODE>
  <BR><BR>
  <DD> <CODE>int IceKey::keySize () const;</CODE>
  <BR><BR>
  <DD> <CODE>int IceKey::blockSize () const;</CODE>
</DL>

<H3>Description</H3>
<P>
The <EM>IceKey</EM> class is used for encrypting and decrypting 64-bit
blocks of data with the ICE (Information Concealment Engine) encryption
algorithm. </P>
<P>
The constructor creates a new <CODE>IceKey</CODE> object that can be used
to encrypt and decrypt data. The <EM>level</EM> of encryption determines
the size of the key, and hence its speed. Level 0 uses the Thin-ICE
variant, which is an 8-round cipher taking an 8-byte key. This is the
fastest option, and is generally considered to be at least as secure
as DES, although it is not yet certain whether it is as secure as its
key size. </P>
<P>
For levels <EM>n</EM> greater than zero, a 16<EM>n</EM>-round cipher is
used, taking 8<EM>n</EM>-byte keys. Although not as fast as level 0,
these are very very secure. </P>
<P>
Before an <CODE>IceKey</CODE> can be used to encrypt data, its key
schedule must be set with the <CODE>set()</CODE> member function. The
length of the key required is determined by the level, as described above. </P>
<P>
The member functions <CODE>encrypt()</CODE> and <CODE>decrypt()</CODE>
encrypt and decrypt respectively data in blocks of eight chracters,
using the specified key. </P>
<P>
Two functions <CODE>keySize()</CODE> and <CODE>blockSize()</CODE>
are provided which return the key and block size
respectively, measured in bytes. The key size is determined by
the level, while the block size is always 8. </P>
<P>
The destructor zeroes out and frees up all memory associated with the key. </P>

<HR>
<DIV ALIGN=RIGHT>
<FONT SIZE=-1>
Document last modified by Matthew Kwan, 28 November 1998 <BR>
Please send any comments or corrections to
<A HREF="mailto:mkwan@darkside.com.au">mkwan@darkside.com.au</A>
</FONT>
</DIV>

</BODY>
</HTML>
::::::::::::::
icepack/C++/IceKey.3
::::::::::::::
.TH ICEKEY 3 "28 Nov 1998" "Version 1.4"
.SH NAME
IceKey \- the C++ ICE encryption class
.SH SYNOPSIS
.B #include <IceKey.H>
.PP
.B IceKey::IceKey (int \fIlevel\fP);
.PP
.B IceKey::~IceKey ();
.PP
.B void IceKey::set (const unsigned char *\fIkey\fP);
.PP
.B void IceKey::encrypt
.B (const unsigned char *\fIplaintext\fP,
.B unsigned char *\fIciphertext\fP) const;
.PP
.B void IceKey::decrypt
.B (const unsigned char *\fIciphertext\fP,
.B unsigned char *\fIplaintext\fP) const;
.PP
.B int IceKey::keySize () const;
.PP
.B int IceKey::blockSize () const;
.SH DESCRIPTION
The \fBIceKey\fP class is used for encrypting
and decrypting 64-bit blocks of data with the ICE (Information
Concealment Engine) encryption algorithm.
.PP
The constructor creates a new \fBIceKey\fP object that
can be used to encrypt and decrypt data. The \fIlevel\fP of encryption
determines the size of the key, and hence its speed. Level 0 uses
the Thin-ICE variant, which is an 8-round cipher taking an
8-byte key. This is the fastest option, and is generally considered
to be at least as secure as DES, although it is not yet certain whether
it is as secure as its key size.
.PP
For levels \fIn\fP greater that zero, a 16\fIn\fP-round cipher is
used, taking 8\fIn\fP-byte keys. Although not as fast as level 0,
these are very very secure.
.PP
Before an \fBIceKey\fP can be used to encrypt data, its key schedule
must be set with the \fBset()\fP member function. The length of the
key required is determined by the level, as described above.
.PP
The member functions \fBencrypt()\fP and \fBdecrypt()\fP
encrypt and decrypt respectively data in blocks of eight characters,
using the specified key.
.PP
Two functions \fBkeySize()\fP and \fBblockSize()\fP
are provided which return the key and block size
respectively, measured in bytes. The key size is determined by
the level, while the block size is always 8.
.PP
The destructor zeroes out and frees up all memory associated with the key.
.SH AUTHOR
This library was written by Matthew Kwan, who can be reached at
mkwan@darkside.com.au
.SH SEE ALSO
\fBice\fP(1)
::::::::::::::
icepack/C++/IceKey.C
::::::::::::::
/*
 * C++ implementation of the ICE encryption algorithm.
 *
 * Written by Matthew Kwan - July 1996
 */

#include "IceKey.H"


	/* Structure of a single round subkey */
class IceSubkey {
    public:
	unsigned long	val[3];
};


	/* The S-boxes */
static unsigned long	ice_sbox[4][1024];
static int		ice_sboxes_initialised = 0;


	/* Modulo values for the S-boxes */
static const int	ice_smod[4][4] = {
				{333, 313, 505, 369},
				{379, 375, 319, 391},
				{361, 445, 451, 397},
				{397, 425, 395, 505}};

	/* XOR values for the S-boxes */
static const int	ice_sxor[4][4] = {
				{0x83, 0x85, 0x9b, 0xcd},
				{0xcc, 0xa7, 0xad, 0x41},
				{0x4b, 0x2e, 0xd4, 0x33},
				{0xea, 0xcb, 0x2e, 0x04}};

	/* Permutation values for the P-box */
static const unsigned long	ice_pbox[32] = {
		0x00000001, 0x00000080, 0x00000400, 0x00002000,
		0x00080000, 0x00200000, 0x01000000, 0x40000000,
		0x00000008, 0x00000020, 0x00000100, 0x00004000,
		0x00010000, 0x00800000, 0x04000000, 0x20000000,
		0x00000004, 0x00000010, 0x00000200, 0x00008000,
		0x00020000, 0x00400000, 0x08000000, 0x10000000,
		0x00000002, 0x00000040, 0x00000800, 0x00001000,
		0x00040000, 0x00100000, 0x02000000, 0x80000000};

	/* The key rotation schedule */
static const int	ice_keyrot[16] = {
				0, 1, 2, 3, 2, 1, 3, 0,
				1, 3, 2, 0, 3, 1, 0, 2};


/*
 * 8-bit Galois Field multiplication of a by b, modulo m.
 * Just like arithmetic multiplication, except that additions and
 * subtractions are replaced by XOR.
 */

static unsigned int
gf_mult (
	register unsigned int	a,
	register unsigned int	b,
	register unsigned int	m
) {
	register unsigned int	res = 0;

	while (b) {
	    if (b & 1)
		res ^= a;

	    a <<= 1;
	    b >>= 1;

	    if (a >= 256)
		a ^= m;
	}

	return (res);
}


/*
 * Galois Field exponentiation.
 * Raise the base to the power of 7, modulo m.
 */

static unsigned long
gf_exp7 (
	register unsigned int	b,
	unsigned int		m
) {
	register unsigned int	x;

	if (b == 0)
	    return (0);

	x = gf_mult (b, b, m);
	x = gf_mult (b, x, m);
	x = gf_mult (x, x, m);
	return (gf_mult (b, x, m));
}


/*
 * Carry out the ICE 32-bit P-box permutation.
 */

static unsigned long
ice_perm32 (
	register unsigned long	x
) {
	register unsigned long		res = 0;
	register const unsigned long	*pbox = ice_pbox;

	while (x) {
	    if (x & 1)
		res |= *pbox;
	    pbox++;
	    x >>= 1;
	}

	return (res);
}


/*
 * Initialise the ICE S-boxes.
 * This only has to be done once.
 */

static void
ice_sboxes_init (void)
{
	register int	i;

	for (i=0; i<1024; i++) {
	    int			col = (i >> 1) & 0xff;
	    int			row = (i & 0x1) | ((i & 0x200) >> 8);
	    unsigned long	x;

	    x = gf_exp7 (col ^ ice_sxor[0][row], ice_smod[0][row]) << 24;
	    ice_sbox[0][i] = ice_perm32 (x);

	    x = gf_exp7 (col ^ ice_sxor[1][row], ice_smod[1][row]) << 16;
	    ice_sbox[1][i] = ice_perm32 (x);

	    x = gf_exp7 (col ^ ice_sxor[2][row], ice_smod[2][row]) << 8;
	    ice_sbox[2][i] = ice_perm32 (x);

	    x = gf_exp7 (col ^ ice_sxor[3][row], ice_smod[3][row]);
	    ice_sbox[3][i] = ice_perm32 (x);
	}
}


/*
 * Create a new ICE key.
 */

IceKey::IceKey (int n)
{
	if (!ice_sboxes_initialised) {
	    ice_sboxes_init ();
	    ice_sboxes_initialised = 1;
	}

	if (n < 1) {
	    _size = 1;
	    _rounds = 8;
	} else {
	    _size = n;
	    _rounds = n * 16;
	}

	_keysched = new IceSubkey[_rounds];
}


/*
 * Destroy an ICE key.
 */

IceKey::~IceKey ()
{
	int	i, j;

	for (i=0; i<_rounds; i++)
	    for (j=0; j<3; j++)
		_keysched[i].val[j] = 0;

	_rounds = _size = 0;

	delete[] _keysched;
}


/*
 * The single round ICE f function.
 */

static unsigned long
ice_f (
	register unsigned long	p,
	const IceSubkey		*sk
) {
	unsigned long	tl, tr;		/* Expanded 40-bit values */
	unsigned long	al, ar;		/* Salted expanded 40-bit values */

					/* Left half expansion */
	tl = ((p >> 16) & 0x3ff) | (((p >> 14) | (p << 18)) & 0xffc00);

					/* Right half expansion */
	tr = (p & 0x3ff) | ((p << 2) & 0xffc00);

					/* Perform the salt permutation */
			// al = (tr & sk->val[2]) | (tl & ~sk->val[2]);
			// ar = (tl & sk->val[2]) | (tr & ~sk->val[2]);
	al = sk->val[2] & (tl ^ tr);
	ar = al ^ tr;
	al ^= tl;

	al ^= sk->val[0];		/* XOR with the subkey */
	ar ^= sk->val[1];

					/* S-box lookup and permutation */
	return (ice_sbox[0][al >> 10] | ice_sbox[1][al & 0x3ff]
		| ice_sbox[2][ar >> 10] | ice_sbox[3][ar & 0x3ff]);
}


/*
 * Encrypt a block of 8 bytes of data with the given ICE key.
 */

void
IceKey::encrypt (
	const unsigned char	*ptext,
	unsigned char		*ctext
) const
{
	register int		i;
	register unsigned long	l, r;

	l = (((unsigned long) ptext[0]) << 24)
				| (((unsigned long) ptext[1]) << 16)
				| (((unsigned long) ptext[2]) << 8) | ptext[3];
	r = (((unsigned long) ptext[4]) << 24)
				| (((unsigned long) ptext[5]) << 16)
				| (((unsigned long) ptext[6]) << 8) | ptext[7];

	for (i = 0; i < _rounds; i += 2) {
	    l ^= ice_f (r, &_keysched[i]);
	    r ^= ice_f (l, &_keysched[i + 1]);
	}

	for (i = 0; i < 4; i++) {
	    ctext[3 - i] = r & 0xff;
	    ctext[7 - i] = l & 0xff;

	    r >>= 8;
	    l >>= 8;
	}
}


/*
 * Decrypt a block of 8 bytes of data with the given ICE key.
 */

void
IceKey::decrypt (
	const unsigned char	*ctext,
	unsigned char		*ptext
) const
{
	register int		i;
	register unsigned long	l, r;

	l = (((unsigned long) ctext[0]) << 24)
				| (((unsigned long) ctext[1]) << 16)
				| (((unsigned long) ctext[2]) << 8) | ctext[3];
	r = (((unsigned long) ctext[4]) << 24)
				| (((unsigned long) ctext[5]) << 16)
				| (((unsigned long) ctext[6]) << 8) | ctext[7];

	for (i = _rounds - 1; i > 0; i -= 2) {
	    l ^= ice_f (r, &_keysched[i]);
	    r ^= ice_f (l, &_keysched[i - 1]);
	}

	for (i = 0; i < 4; i++) {
	    ptext[3 - i] = r & 0xff;
	    ptext[7 - i] = l & 0xff;

	    r >>= 8;
	    l >>= 8;
	}
}


/*
 * Set 8 rounds [n, n+7] of the key schedule of an ICE key.
 */

void
IceKey::scheduleBuild (
	unsigned short	*kb,
	int		n,
	const int	*keyrot
) {
	int		i;

	for (i=0; i<8; i++) {
	    register int	j;
	    register int	kr = keyrot[i];
	    IceSubkey		*isk = &_keysched[n + i];

	    for (j=0; j<3; j++)
		isk->val[j] = 0;

	    for (j=0; j<15; j++) {
		register int	k;
		unsigned long	*curr_sk = &isk->val[j % 3];

		for (k=0; k<4; k++) {
		    unsigned short	*curr_kb = &kb[(kr + k) & 3];
		    register int	bit = *curr_kb & 1;

		    *curr_sk = (*curr_sk << 1) | bit;
		    *curr_kb = (*curr_kb >> 1) | ((bit ^ 1) << 15);
		}
	    }
	}
}


/*
 * Set the key schedule of an ICE key.
 */

void
IceKey::set (
	const unsigned char	*key
) {
	int		i;

	if (_rounds == 8) {
	    unsigned short	kb[4];

	    for (i=0; i<4; i++)
		kb[3 - i] = (key[i*2] << 8) | key[i*2 + 1];

	    scheduleBuild (kb, 0, ice_keyrot);
	    return;
	}

	for (i=0; i<_size; i++) {
	    int			j;
	    unsigned short	kb[4];

	    for (j=0; j<4; j++)
		kb[3 - j] = (key[i*8 + j*2] << 8) | key[i*8 + j*2 + 1];

	    scheduleBuild (kb, i*8, ice_keyrot);
	    scheduleBuild (kb, _rounds - 8 - i*8, &ice_keyrot[8]);
	}
}


/*
 * Return the key size, in bytes.
 */

int
IceKey::keySize () const
{
	return (_size * 8);
}


/*
 * Return the block size, in bytes.
 */

int
IceKey::blockSize () const
{
	return (8);
}
::::::::::::::
icepack/C++/IceKey.H
::::::::::::::
/*
 * Header file for the C++ ICE encryption class.
 *
 * Written by Matthew Kwan - July 1996
 */

#ifndef _IceKey_H
#define _IceKey_H

class IceSubkey;

class IceKey {
    public:
	IceKey (int n);
	~IceKey ();

	void		set (const unsigned char *key);

	void		encrypt (const unsigned char *plaintext,
					unsigned char *ciphertext) const;

	void		decrypt (const unsigned char *ciphertext,
					unsigned char *plaintext) const;

	int		keySize () const;

	int		blockSize () const;

    private:
	void		scheduleBuild (unsigned short *k, int n,
							const int *keyrot);

	int		_size;
	int		_rounds;
	IceSubkey	*_keysched;
};

#endif
::::::::::::::
icepack/Java/IceKey-java.html
::::::::::::::
<HTML>
<HEAD><TITLE>Class IceKey</TITLE></HEAD>
<BODY BGCOLOR="#d8d8d8" TEXT="#000080" LINK="#0000FF">
<H1> Class IceKey</H1>

<PRE>
class <STRONG>IceKey</STRONG>
{
        // Constructors
    public <A HREF="#1">IceKey</A>(int level);

        // Methods
    public void  <A HREF="#2">set</A>(byte key[]);
    public void  <A HREF="#3">encrypt</A>(byte plaintext[], byte ciphertext[]);
    public void  <A HREF="#4">decrypt</A>(byte ciphertext[], byte plaintext[]);
    public void  <A HREF="#5">clear</A>();
    public int   <A HREF="#6">keySize</A>();
    public int   <A HREF="#7">blockSize</A>();
}
</PRE>

<P>
An <B>IceKey</B> object is used to encrypt and decrypt 8-byte blocks
of data using the ICE encryption algorithm. ICE, an acronym for
<EM>Information Concealment Engine</EM>, is a 64-bit block cipher in
the tradition of DES. However, it aims to be faster and significantly
more secure than DES. </P>
<P>
Unlike DES, ICE has various levels of encryption, where higher levels
provide more security, but at the expense of speed. It also makes use of
a technique called <EM>keyed permutation</EM> internally, which gives
it increased resistance to differential and linear cryptanalysis. </P>
<P>
Once an <B>IceKey</B> object has been created, it will usually have
its key set from a password of some sort. The object can then be used
to encrypt and decrypt data using that key. </P>
<HR>

<H2> Constructors </H2>

<A NAME="1"><H3> IceKey </H3></A>
<CODE> public IceKey(int level) </CODE>
<DL>

  <DD> Creates an <B>IceKey</B> object. The <EM>level</EM> parameter specifies
       the level of ICE encryption to use, where higher levels require
       longer keys and are slower, but are more secure.

  <DD> Level 0 uses the <EM>Thin-ICE</EM> variant of ICE, which is an 8-round
       cipher taking an 8-byte key. This is the fastest option, and is
       generally considered to be at least as secure as DES. For levels
       <EM>n</EM> greater than zero, a 16<EM>n</EM>-round cipher is used,
       taking 8<EM>n</EM>-byte keys. Although not as fast as level 0, these
       are very secure.
  <BR><BR>
  <DL>
    <DT> <B>Parameters:</B>
    <DD> <CODE>level - </CODE>the ICE level of encryption
  </DL>
</DL>
<HR>

<H2> Methods </H2>

<A NAME="2"><H3> set </H3></A>
<CODE> public void set(byte key[]) </CODE>
<DL>
  <DD> This method sets the key schedule for the <B>IceKey</B>. This should
       be called before any encryption or decryption is done, or the results
       will not be secure. The number of key bytes used depends on the level
       of encryption set in the constructor. For levels 0 and 1, 8 bytes are
       used. For levels <EM>n</EM> > 1, 8<EM>n</EM> bytes are used.
  <DD> If the key array is not large enough to contain the required number
       of bytes, an array bounds error will occur.
  <BR><BR>
  <DL>
    <DT> <B>Parameters:</B>
    <DD> <CODE>key - </CODE>the key used to encrypt and decrypt data
  </DL>
</DL>

<A NAME="3"><H3> encrypt </H3></A>
<CODE> public void encrypt(byte plaintext[], byte ciphertext[]) </CODE>
<DL>
  <DD> This method is called to encrypt 8 bytes of the plaintext with the
       key specified in the <A HREF="#2">set</A> method. The result is stored
       in the ciphertext array.
  <BR><BR>
  <DL>
    <DT> <B>Parameters:</B>
    <DD> <CODE>plaintext - </CODE>the data to be encrypted
    <DD> <CODE>ciphertext - </CODE>the resulting encrypted data
  </DL>
</DL>

<A NAME="4"><H3> decrypt </H3></A>
<CODE> public void decrypt(byte ciphertext[], byte plaintext[]) </CODE>
<DL>
  <DD> This method is called to decrypt 8 bytes of the plaintext with the
       key specified in the <A HREF="#2">set</A> method. The result is stored
       in the plaintext array.
  <BR><BR>
  <DL>
    <DT> <B>Parameters:</B>
    <DD> <CODE>ciphertext - </CODE>the data to be decrypted
    <DD> <CODE>plaintext - </CODE>the resulting decrypted data
  </DL>
</DL>

<A NAME="5"><H3> clear </H3></A>
<CODE> public void clear() </CODE>
<DL>
  <DD> This method zeroes out the key schedule, which prevents memory
       snoopers from finding key information. It should only be called when
       the key is no longer needed for encryption or decryption.
</DL>

<A NAME="6"><H3> keySize </H3></A>
<CODE> public int keySize() </CODE>
<DL>
  <DD> This method returns the key size, in bytes.
</DL>

<A NAME="7"><H3> blockSize </H3></A>
<CODE> public int blockSize() </CODE>
<DL>
  <DD> This method returns the block size, in bytes. The value is always 8.
</DL>

<HR>
<DIV ALIGN=RIGHT>
<FONT SIZE=-1>
Document last modified by Matthew Kwan, 28 November 1998 <BR>
Please send any comments or corrections to
<A HREF="mailto:mkwan@darkside.com.au">mkwan@darkside.com.au</A>
</FONT>
</DIV>

</BODY>
</HTML>
::::::::::::::
icepack/Java/IceKey.java
::::::::::::::
/*
 * This class implements the ICE encryption algorithm.
 *
 * Written by Matthew Kwan - December 1996
 */

class IceKey {

	private int		size;
	private int		rounds;
	private int		keySchedule[][];

	private static int	spBox[][];
	private static boolean	spBoxInitialised = false;

	private static final int	sMod[][] = {
						{333, 313, 505, 369},
						{379, 375, 319, 391},
						{361, 445, 451, 397},
						{397, 425, 395, 505}};

	private static final int	sXor[][] = {
						{0x83, 0x85, 0x9b, 0xcd},
						{0xcc, 0xa7, 0xad, 0x41},
						{0x4b, 0x2e, 0xd4, 0x33},
						{0xea, 0xcb, 0x2e, 0x04}};

	private static final int	pBox[] = {
			0x00000001, 0x00000080, 0x00000400, 0x00002000,
			0x00080000, 0x00200000, 0x01000000, 0x40000000,
			0x00000008, 0x00000020, 0x00000100, 0x00004000,
			0x00010000, 0x00800000, 0x04000000, 0x20000000,
			0x00000004, 0x00000010, 0x00000200, 0x00008000,
			0x00020000, 0x00400000, 0x08000000, 0x10000000,
			0x00000002, 0x00000040, 0x00000800, 0x00001000,
			0x00040000, 0x00100000, 0x02000000, 0x80000000};

	private static final int	keyrot[] = {
						0, 1, 2, 3, 2, 1, 3, 0,
						1, 3, 2, 0, 3, 1, 0, 2};

		// 8-bit Galois Field multiplication of a by b, modulo m.
		// Just like arithmetic multiplication, except that
		// additions and subtractions are replaced by XOR.
	private int	gf_mult (int a, int b, int m) {
	    int		res = 0;

	    while (b != 0) {
		if ((b & 1) != 0)
		    res ^= a;

		a <<= 1;
		b >>>= 1;

		if (a >= 256)
		    a ^= m;
	    }

	    return (res);
	}

		// 8-bit Galois Field exponentiation.
		// Raise the base to the power of 7, modulo m.
	private int	gf_exp7 (int b, int m) {
	    int	x;

	    if (b == 0)
		return (0);

	    x = gf_mult (b, b, m);
	    x = gf_mult (b, x, m);
	    x = gf_mult (x, x, m);
	    return (gf_mult (b, x, m));
	}

		// Carry out the ICE 32-bit permutation.
	private int	perm32 (int x) {
	    int		res = 0;
	    int		i = 0;

	    while (x != 0) {
		if ((x & 1) != 0)
		    res |= pBox[i];
		i++;
		x >>>= 1;
	    }

	    return (res);
	}

		// Initialise the substitution/permutation boxes.
	private void	spBoxInit () {
	    int		i;

	    spBox = new int[4][1024];

	    for (i=0; i<1024; i++) {
		int	col = (i >>> 1) & 0xff;
		int	row = (i & 0x1) | ((i & 0x200) >>> 8);
		int	x;

		x = gf_exp7 (col ^ sXor[0][row], sMod[0][row]) << 24;
		spBox[0][i] = perm32 (x);

		x = gf_exp7 (col ^ sXor[1][row], sMod[1][row]) << 16;
		spBox[1][i] = perm32 (x);

		x = gf_exp7 (col ^ sXor[2][row], sMod[2][row]) << 8;
		spBox[2][i] = perm32 (x);

		x = gf_exp7 (col ^ sXor[3][row], sMod[3][row]);
		spBox[3][i] = perm32 (x);
	    }
	}

		// Create a new ICE key with the specified level.
	IceKey (int level) {
	    if (!spBoxInitialised) {
		spBoxInit ();
		spBoxInitialised = true;
	    }

	    if (level < 1) {
		size = 1;
		rounds = 8;
	    } else {
		size = level;
		rounds = level * 16;
	    }

	    keySchedule = new int[rounds][3];
	}

		// Set 8 rounds [n, n+7] of the key schedule of an ICE key.
	private void	scheduleBuild (int kb[], int n, int krot_idx) {
	    int		i;

	    for (i=0; i<8; i++) {
		int	j;
		int	kr = keyrot[krot_idx + i];
		int	subkey[] = keySchedule[n + i];

		for (j=0; j<3; j++)
		    keySchedule[n + i][j] = 0;

		for (j=0; j<15; j++) {
		    int		k;
		    int		curr_sk = j % 3;

		    for (k=0; k<4; k++) {
			int	curr_kb = kb[(kr + k) & 3];
			int	bit = curr_kb & 1;

			subkey[curr_sk] = (subkey[curr_sk] << 1) | bit;
			kb[(kr + k) & 3] = (curr_kb >>> 1) | ((bit ^ 1) << 15);
		    }
		}
	    }
	}

		// Set the key schedule of an ICE key.
	public void	set (byte key[]) {
	    int		i;
	    int		kb[] = new int[4];

	    if (rounds == 8) {
		for (i=0; i<4; i++)
		    kb[3 - i] = ((key[i*2] & 0xff) << 8)
						| (key[i*2 + 1] & 0xff);

		scheduleBuild (kb, 0, 0);
		return;
	    }

	    for (i=0; i<size; i++) {
		int	j;

		for (j=0; j<4; j++)
		    kb[3 - j] = ((key[i*8 + j*2] & 0xff) << 8)
						| (key[i*8 + j*2 + 1] & 0xff);

		scheduleBuild (kb, i*8, 0);
		scheduleBuild (kb, rounds - 8 - i*8, 8);
	    }
	}

		// Clear the key schedule to prevent memory snooping.
	public void	clear () {
	    int		i, j;

	    for (i=0; i<rounds; i++)
		for (j=0; j<3; j++)
		    keySchedule[i][j] = 0;
	}

		// The single round ICE f function.
	private int	roundFunc (int p, int subkey[]) {
	    int		tl, tr;
	    int		al, ar;

	    tl = ((p >>> 16) & 0x3ff) | (((p >>> 14) | (p << 18)) & 0xffc00);
	    tr = (p & 0x3ff) | ((p << 2) & 0xffc00);

	    			// al = (tr & subkey[2]) | (tl & ~subkey[2]);
	    			// ar = (tl & subkey[2]) | (tr & ~subkey[2]);
	    al = subkey[2] & (tl ^ tr);
	    ar = al ^ tr;
	    al ^= tl;

	    al ^= subkey[0];
	    ar ^= subkey[1];

	    return (spBox[0][al >>> 10] | spBox[1][al & 0x3ff]
				| spBox[2][ar >>> 10] | spBox[3][ar & 0x3ff]);
	}

		// Encrypt a block of 8 bytes of data.
	public void	encrypt (byte plaintext[], byte ciphertext[]) {
	    int		i;
	    int		l = 0, r = 0;

	    for (i=0; i<4; i++) {
		l |= (plaintext[i] & 0xff) << (24 - i*8);
		r |= (plaintext[i + 4] & 0xff) << (24 - i*8);
	    }

	    for (i=0; i<rounds; i+=2) {
		l ^= roundFunc (r, keySchedule[i]);
		r ^= roundFunc (l, keySchedule[i + 1]);
	    }

	    for (i=0; i<4; i++) {
		ciphertext[3 - i] = (byte) (r & 0xff);
		ciphertext[7 - i] = (byte) (l & 0xff);

		r >>>= 8;
		l >>>= 8;
	    }
	}

		// Decrypt a block of 8 bytes of data.
	public void	decrypt (byte ciphertext[], byte plaintext[]) {
	    int		i;
	    int		l = 0, r = 0;

	    for (i=0; i<4; i++) {
		l |= (ciphertext[i] & 0xff) << (24 - i*8);
		r |= (ciphertext[i + 4] & 0xff) << (24 - i*8);
	    }

	    for (i = rounds - 1; i > 0; i -= 2) {
		l ^= roundFunc (r, keySchedule[i]);
		r ^= roundFunc (l, keySchedule[i - 1]);
	    }

	    for (i=0; i<4; i++) {
		plaintext[3 - i] = (byte) (r & 0xff);
		plaintext[7 - i] = (byte) (l & 0xff);

		r >>>= 8;
		l >>>= 8;
	    }
	}

		// Return the key size, in bytes.
	public int	keySize () {
	    return (size * 8);
	}

		// Return the block size, in bytes.
	public int	blockSize () {
	    return (8);
	}
}
::::::::::::::
icepack/Java/Makefile
::::::::::::::
#
# This is a very rudimentary Makefile to compile a Java .class file
# from the source. However, since the .class file is included in the
# distribution, this is largely unnecessary.
#
# Written by Matthew Kwan, November 1996
#

IceKey.class:	IceKey.java
		javac IceKey.java
::::::::::::::
icepack/README
::::::::::::::
This icepack distribution contains source code and documentation for
the ICE encryption algorithm. The source code is provided in ANSI-C,
C++, and Java.

All directories contain HTML documentation, and the ANSI-C and C++
directories also contain man pages.

In the "icecrypt" subdirectory of the ANSI-C directory contains the
source for the programs "ice" and "deice".

The makefiles in this distribution are rudimentary at best, so you
will probably need to rewrite them to suit your needs.

Any corrections and comments should be sent to the author,
Matthew Kwan (mkwan@darkside.com.au)

# endif /* ICE */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef FEAL8

/* FEAL8 - Implementation of NTT's FEAL-8 cipher. ---------------------------
Version of 11 September 1989.
*/

#include "feal8.h"
#ifdef DEBUG
#include <stdio.h>
#endif

typedef unsigned long HalfWord ;

typedef unsigned int QuarterWord ;

QuarterWord K[16] ;
HalfWord K89, K1011, K1213, K1415 ;

void Decrypt( ByteType *Cipher, ByteType *Plain )
/*
     Decrypt a block, using the last key set.
*/
{
    HalfWord L, R, NewL ;
    int r ;
    HalfWord MakeH1( ByteType * ) ;
    HalfWord f( HalfWord, QuarterWord ) ;
    void DissH1( HalfWord, ByteType * ) ;

    R = MakeH1( Cipher ) ;
    L = MakeH1( Cipher+4 ) ;
    R ^= K1213 ;
    L ^= K1415 ;
    L ^= R ;

    for ( r = 7 ; r >= 0 ; --r )
    {
     NewL = R ^ f( L, K[r] ) ;
     R = L ;
     L = NewL ;
    }

    R ^= L ;
    R ^= K1011 ;
    L ^= K89 ;

    DissH1( L, Plain ) ;
    DissH1( R, Plain + 4 ) ;
}

void DissH1( HalfWord H, ByteType *D )
/*
     Disassemble the given halfword into 4 bytes.
*/
{
    union {
     HalfWord All ;
     ByteType Byte[4] ;
    } T ;

    T.All = H ;
    *D++ = T.Byte[0] ;
    *D++ = T.Byte[1] ;
    *D++ = T.Byte[2] ;
    *D   = T.Byte[3] ;
}

void DissQ1( QuarterWord Q, ByteType *B )
/*
     Disassemble a quarterword into two Bytes.
*/
{
    union {
     QuarterWord All ;
     ByteType Byte[2] ;
    } QQ ;

    QQ.All = Q ;
    *B++ = QQ.Byte[0] ;
    *B   = QQ.Byte[1] ;
}

void Encrypt( ByteType *Plain, ByteType *Cipher )
/*
     Encrypt a block, using the last key set.
*/
{
    HalfWord L, R, NewR ;
    int r ;
    HalfWord MakeH1( ByteType * ) ;
    HalfWord f( HalfWord, QuarterWord ) ;
    void DissH1( HalfWord, ByteType * ) ;

    L = MakeH1( Plain ) ;
    R = MakeH1( Plain+4 ) ;
    L ^= K89 ;
    R ^= K1011 ;
    R ^= L ;

#ifdef DEBUG
    printf( "p:  %08lx %08lx\n", L, R ) ;
#endif
    for ( r = 0 ; r < 8 ; ++r )
    {
     NewR = L ^ f( R, K[r] ) ;
     L = R ;
     R = NewR ;
#ifdef DEBUG
     printf( "%2d: %08lx %08lx\n", r, L, R ) ;
#endif
    }

    L ^= R ;
    R ^= K1213 ;
    L ^= K1415 ;

    DissH1( R, Cipher ) ;
    DissH1( L, Cipher + 4 ) ;
}

HalfWord f( HalfWord AA, QuarterWord BB )
/*
     Evaluate the f function.
*/
{
    ByteType f1, f2 ;
    union {
     unsigned long All ;
     ByteType Byte[4] ;
    } RetVal, A ;
    union {
     unsigned int All ;
     ByteType Byte[2] ;
    } B ;
    ByteType S0( ByteType, ByteType ) ;
    ByteType S1( ByteType, ByteType ) ;

    A.All = AA ;
    B.All = BB ;
    f1 = A.Byte[1] ^ B.Byte[0] ^ A.Byte[0] ;
    f2 = A.Byte[2] ^ B.Byte[1] ^ A.Byte[3] ;
    f1 = S1( f1, f2 ) ;
    f2 = S0( f2, f1 ) ;
    RetVal.Byte[1] = f1 ;
    RetVal.Byte[2] = f2 ;
    RetVal.Byte[0] = S0( A.Byte[0], f1 ) ;
    RetVal.Byte[3] = S1( A.Byte[3], f2 ) ;
    return RetVal.All ;
}

HalfWord FK( HalfWord AA, HalfWord BB )
/*
     Evaluate the FK function.
*/
{
    ByteType FK1, FK2 ;
    union {
     unsigned long All ;
     ByteType Byte[4] ;
    } RetVal, A, B ;
    ByteType S0( ByteType, ByteType ) ;
    ByteType S1( ByteType, ByteType ) ;

    A.All = AA ;
    B.All = BB ;
    FK1 = A.Byte[1] ^ A.Byte[0] ;
    FK2 = A.Byte[2] ^ A.Byte[3] ;
    FK1 = S1( FK1, FK2 ^ B.Byte[0] ) ;
    FK2 = S0( FK2, FK1 ^ B.Byte[1] ) ;
    RetVal.Byte[1] = FK1 ;
    RetVal.Byte[2] = FK2 ;
    RetVal.Byte[0] = S0( A.Byte[0], FK1 ^ B.Byte[2] ) ;
    RetVal.Byte[3] = S1( A.Byte[3], FK2 ^ B.Byte[3] ) ;
    return RetVal.All ;
}

HalfWord MakeH1( ByteType *B )
/*
     Assemble a HalfWord from the four bytes provided.
*/
{
    union {
     unsigned long All ;
     ByteType Byte[4] ;
    } RetVal ;

    RetVal.Byte[0] = *B++ ;
    RetVal.Byte[1] = *B++ ;
    RetVal.Byte[2] = *B++ ;
    RetVal.Byte[3] = *B ;
    return RetVal.All ;
}

HalfWord MakeH2( QuarterWord *Q )
/*
     Make a halfword from the two quarterwords given.
*/
{
    ByteType B[4] ;
    void DissQ1( QuarterWord, ByteType * ) ;

    DissQ1( *Q++, B ) ;
    DissQ1( *Q, B+2 ) ;
    return MakeH1( B ) ;
}

ByteType Rot2( ByteType X )
/*
     Evaluate the Rot2 function.
*/
{
    static int First = 1 ;
    static ByteType RetVal[ 256 ] ;

    if ( First )
    {
     int i, High, Low ;
     for ( i = 0, High = 0, Low = 0 ; i < 256 ; ++i )
     {
         RetVal[ i ] = High + Low ;
         High += 4 ;
         if ( High > 255 )
         {
          High = 0 ;
          ++Low ;
         }
     }
     First = 0 ;
    }
    return RetVal[ X ] ;
}

ByteType S0( ByteType X1, ByteType X2 )
{
    ByteType Rot2( ByteType X ) ;

    return Rot2( ( X1 + X2 ) & 0xff ) ;
}

ByteType S1( ByteType X1, ByteType X2 )
{
    ByteType Rot2( ByteType X ) ;

    return Rot2( ( X1 + X2 + 1 ) & 0xff ) ;
}

void SetKey( ByteType *KP )
/*
     KP points to an array of 8 bytes.
*/
{
    union {
     HalfWord All ;
     ByteType Byte[4] ;
    } A, B, D, NewB ;
    union {
     QuarterWord All ;
     ByteType Byte[2] ;
    } Q ;
    int i ;
    QuarterWord *Out ;
    HalfWord FK( HalfWord, HalfWord ) ;
    HalfWord MakeH2( QuarterWord * ) ;

    A.Byte[0] = *KP++ ;
    A.Byte[1] = *KP++ ;
    A.Byte[2] = *KP++ ;
    A.Byte[3] = *KP++ ;
    B.Byte[0] = *KP++ ;
    B.Byte[1] = *KP++ ;
    B.Byte[2] = *KP++ ;
    B.Byte[3] = *KP ;
    D.All = 0 ;

    for ( i = 1, Out = K ; i <= 8 ; ++i )
    {
     NewB.All = FK( A.All, B.All ^ D.All ) ;
     D = A ;
     A = B ;
     B = NewB ;
     Q.Byte[0] = B.Byte[0] ;
     Q.Byte[1] = B.Byte[1] ;
     *Out++ = Q.All ;
     Q.Byte[0] = B.Byte[2] ;
     Q.Byte[1] = B.Byte[3] ;
     *Out++ = Q.All ;
    }
    K89 = MakeH2( K+8 ) ;
    K1011 = MakeH2( K+10 ) ;
    K1213 = MakeH2( K+12 ) ;
    K1415 = MakeH2( K+14 ) ;
}

# endif /* FEAL8 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef FEALNX

/* FEALNX.C - Implementation of the FEALNX package.
Version of 92.12.28 by Peter Pearson.

This implementation strives primarily for portability and secondarily for
clarity, with execution speed only a tertiary consideration. On
processors with 16-bit or 32-bit registers, the quickest way to boost
execution speed is to lump the data into pieces bigger than 8 bits.
*/

#include <alloc.h>  /* For "malloc".          */
#include <mem.h>    /* For "memcpy" and "memset".*/
#include "fealnx.h"

#define S0(x,y)Rot2((x)+(y))
#define S1(x,y)Rot2((x)+(y)+1)

void CalcFk( unsigned char Output[4], unsigned char Alpha[4],
                                unsigned char Beta[4] )
/*
       Calculate the function "fk" of the two specified inputs,
       and write the resulting four bytes to the provided output.
*/
{
    unsigned char t1, t2 ;
    unsigned char Rot2( int A ) ;

    t1 = Alpha[0] ^ Alpha[1] ;
    t2 = Alpha[2] ^ Alpha[3] ;
    t1 = S1( t1, t2 ^ Beta[0] ) ;
    t2 = S0( t2, t1 ^ Beta[1] ) ;
    Output[1] = t1 ;
    Output[2] = t2 ;
    Output[0] = S0( Alpha[0], t1 ^ Beta[2] ) ;
    Output[3] = S1( Alpha[3], t2 ^ Beta[3] ) ;
}

void Decrypt( KeyScheduleType K, DataBlockType Cipher, DataBlockType Plain )
{
    int Rounds ;
    int i ;
    unsigned char L[4], R[4], NewR[4] ;
    unsigned char *KP ;
    unsigned char *Xor4( unsigned char A[4], unsigned char B[4] ) ;
    unsigned char *F( unsigned char K[2], unsigned char R[4] ) ;

    Rounds = K->NRounds ;
    KP = K->KSchedule + 2 * Rounds ;
    movmem(          Xor4( KP + 8,  Cipher       ), L, 4 ) ;
    movmem( Xor4( L, Xor4( KP + 12, Cipher + 4 ) ), R, 4 ) ;
    for ( i = 0 ; i < Rounds ; ++i )
    {
       KP -= 2 ;
       movmem( Xor4( L, F( KP, R ) ), NewR, 4 ) ;
       movmem( R, L, 4 ) ;
       movmem( NewR, R, 4 ) ;
    }  /* Fall out with KP pointing to KSchedule.*/
    KP = K->KSchedule + 2 * Rounds ;
    movmem( Xor4( KP    , R            ), Plain, 4 ) ;
    movmem( Xor4( KP + 4, Xor4( R, L ) ), Plain + 4, 4 ) ;
}

void Encrypt( KeyScheduleType K, DataBlockType Plain, DataBlockType Cipher )
{
    int Rounds ;
    int i ;
    unsigned char L[4], R[4], NewR[4] ;
    unsigned char *KP ;
    unsigned char *Xor4( unsigned char A[4], unsigned char B[4] ) ;
    unsigned char *F( unsigned char K[2], unsigned char R[4] ) ;

    KP = K->KSchedule ;
    Rounds = K->NRounds ;
    movmem(          Xor4( KP + 2 * Rounds,     Plain       ), L, 4 ) ;
    movmem( Xor4( L, Xor4( KP + 2 * Rounds + 4, Plain + 4 ) ), R, 4 ) ;
    for ( i = 0 ; i < Rounds ; ++i, KP += 2 )
    {
       movmem( Xor4( L, F( KP, R ) ), NewR, 4 ) ;
       movmem( R, L, 4 ) ;
       movmem( NewR, R, 4 ) ;
    }  /* Fall out with KP pointing to KSchedule[ 2*Rounds ].*/
    movmem( Xor4( KP + 8,  R            ), Cipher, 4 ) ;
    movmem( Xor4( KP + 12, Xor4( R, L ) ), Cipher + 4, 4 ) ;
}

unsigned char *F( unsigned char Beta[2], unsigned char Alpha[4] )
/*
       This function implements the "f" box in the Feal-N
       flowchart.

The result is returned in a static array, and will be overwritten
when this function is next called.
*/
{
    unsigned char t1, t2 ;
    static unsigned char Result[4] ;
    unsigned char Rot2( int A ) ;

    t1 = Alpha[0] ^ Alpha[1] ^ Beta[0] ;
    t2 = Alpha[2] ^ Alpha[3] ^ Beta[1] ;
    t1 = S1( t1, t2 ) ;
    t2 = S0( t2, t1 ) ;
    Result[1] = t1 ;
    Result[2] = t2 ;
    Result[0] = S0( t1, Alpha[0] ) ;
    Result[3] = S1( t2, Alpha[3] ) ;
    return Result ;
}

KeyScheduleType NewKeySchedule( int Rounds, unsigned char *Key )
{
    KeyScheduleType Result ;
    int Step ;
    unsigned char *KSP ;
    unsigned char a[4], b[4], c[4], d[4] ;
    void CalcFk( unsigned char Output[4], unsigned char In1[4],
                                   unsigned char In2[4] ) ;
    unsigned char *Xor4( unsigned char A[4], unsigned char B[4] ) ;

    Result = malloc( ( sizeof( *Result ) + Rounds + 8 ) * 2 ) ;
    if ( Result != NULL )
    {
       Result->NRounds = Rounds ;
       Result->KSchedule = ( unsigned char *) ( Result + 1 ) ;
       memcpy( a, Key,   4 ) ;
       memcpy( b, Key+4, 4 ) ;
       memcpy( c, Xor4( Key + 8, Key + 12 ), 4 ) ;
       memset( d, 0, 4 ) ;
       KSP = Result->KSchedule ;
       for ( Step = 0 ; Step < Rounds/2 + 4 ; ++Step, KSP += 4 )
       {
           switch( Step % 3 )
           {
             case 0:
                 CalcFk( KSP, a, Xor4( d, Xor4( b, c ) ) ) ;
                 break ;

             case 1:
                 CalcFk( KSP, a, Xor4( d, Xor4( b, Key + 8 ) ) ) ;
                 break ;

             case 2:
                 CalcFk( KSP, a, Xor4( d, Xor4( b, Key + 12 ) ) ) ;
                 break ;
           }
           memcpy( d, a, 4 ) ;
           memcpy( a, b, 4 ) ;
           memcpy( b, KSP, 4 ) ;
       }
    }
    return Result ;
}

unsigned char Rot2( int X )
/*
       Return X (an 8-bit quantity) rotated left by two bits.

       (In an uncharacteristic concession to execution speed, we
       implement this function by table lookup.)
*/
{
    static First = 1 ;
    static unsigned char Result[ 256 ] ;

    if ( First )
    {
       int i ;

       for ( i = 0 ; i < 256 ; ++i )
           Result[i] = ( i << 2 ) + ( i >> 6 ) ;
       First = 0 ;
    }

    return Result[ X & 0xFF ] ;
}

unsigned char *Xor4( unsigned char A[4], unsigned char B[4] )
/*
       Exclusive-or two 4-byte quantities. Return a pointer to
       the result.

       The pointer returned points to a static variable that will
       be overwritten the next time this function is called. We
       guarantee that calls to this function may be nested simply
       (e.g., Xor4( a, Xor4( b, Xor4( c, d ) ) ) ) but anything
       more complex may behave badly. (For example,
       Xor4( Xor4( a, b ), Xor4( c, d ) ) will result in all 0s) .
*/
{
    static unsigned char Result[4] ;

    Result[0] = A[0] ^ B[0] ;
    Result[1] = A[1] ^ B[1] ;
    Result[2] = A[2] ^ B[2] ;
    Result[3] = A[3] ^ B[3] ;
    return Result ;
}

# endif /* FEALNX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu ts=4
 */
