
/*		|-------------------------------------------------------|		*/
/*		|	includes											|		*/
/*		|-------------------------------------------------------|		*/

# include	"stdclopt.h"

/*		|-------------------------------------------------------|		*/
/*		|	globals												|		*/
/*		|-------------------------------------------------------|		*/

# ifdef DEBUG
bool		debugflag	= TRUE ;
# else  /* NOBUG */
bool		debugflag	= FALSE ;
# endif /* DEBUG */

bool		dontflag	= FALSE ;
bool		environflag	= FALSE ;
bool		helpflag	= FALSE ;
bool		licenseflag	= FALSE ;
bool		quietflag	= FALSE ;
bool		verboseflag	= FALSE ;
bool		versionflag	= FALSE ;

CLOPT *		clopts		= NULL ;
int			totclopts	= 0 ;

PARMQE *	parmque  = NULL ;
int			totparmq = 0 ;

STRING *	cltargs  = NULL ;
int			tottargs = 0 ;

char *		swid = NULL ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void setswid (name) char * name ; {

	char * tp ;

	errmsg (CHKPT, "setswid (%s) \n", name) ;

	if ( name == NULL )
		return ;

	swid = name ;

	tp = strrchr (swid, '/') ;

	if ( tp != NULL )
		swid = tp + 1 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void waitclopt (addr, type) char * addr , * type ; {

	PARMQE * tpqp ;

	errmsg (CHKPT, "waitclopt (%s) \n", type) ;

	tpqp = (PARMQE *) incrlist (&parmque, &totparmq, PARMQESIZ) ;

	tpqp->addr = addr ;
	tpqp->type = type ;
	tpqp->mpty = TRUE ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void peekclopt (cinx) {

	int i = cinx ;
	CLOPT * tcop ;

	errmsg (CHKPT, "peekclopt (%d) \n", cinx) ;

	if ( i < 0 || i >= totclopts )
		errmsg (FATAL, "invalid clopt index (%d) \n", i) ;

	tcop = clopts + i ;

	switch ( tcop->type[0] ) {

		case 't' :
		case 'T' :
			*( (bool *) tcop->addr ) = TRUE ;
		break ;

		case 'f' :
		case 'F' :
			*( (bool *) tcop->addr ) = FALSE ;
		break ;

		case 'i' :
		case 'I' :
			waitclopt ( tcop->addr , "%d" ) ;
		break ;

		case 'l' :
		case 'L' :
			waitclopt ( tcop->addr , "%ld" ) ;
		break ;

		case 's' :
		case 'S' :
			waitclopt ( tcop->addr , "%s" ) ;
		break ;

		default :
			errmsg (FATAL, "invalid parameter type (%c) \n", tcop->type[0]) ;
		break ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

bool longclopt (arg) char * arg ; {

	int i ;

	errmsg (CHKPT, "longclopt (%s) \n", arg) ;

	for ( i = 0 ; i < totclopts ; ++i )
		if ( strcmp ( arg , (clopts+i)->lopt ) == 0 ) {
			peekclopt (i) ;
			return TRUE ;
		}

	return FALSE ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

bool tinyclopt (arg) {

	int i ;

	errmsg (CHKPT, "tinyclopt (%c) \n", arg) ;

	for ( i = 0 ; i < totclopts ; ++i )
		if ( arg == (clopts+i)->sopt[1] ) {
			peekclopt (i) ;
			return TRUE ;
		}

	return FALSE ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void pickclopt (arg) char * arg ; {

	int i ;
	STRING * tctp ;

	errmsg (CHKPT, "pickclopt (%s) \n", arg) ;

	/* check awaited queue */

	for ( i = 0 ; i < totparmq ; ++i )
		if ( (parmque+i)->mpty ) {
			sscanf ( arg, (parmque+i)->type, (parmque+i)->addr ) ;
			(parmque+i)->mpty = FALSE ;
			return ;
		}

	/* no queued parms ; grow target list */

	tctp = (STRING *) incrlist (&cltargs, &tottargs, STRINGSIZ) ;

	*tctp = strclone (arg) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

/*
 *		V4.0 to use any (!alnum) char as flag-prefix ...
 */

void testclopt (arg) char * arg ; {

	char * tp = arg ;

	errmsg (CHKPT, "testclopt (%s) \n", arg) ;

	if ( *tp == '-' ) {
		if ( longclopt (tp) )
			return ;
		while (*++tp)
			if ( ! tinyclopt (*tp) )
				errmsg (FATAL, "bad flag/parm (-%c) \n", *tp) ;
	} else {
		pickclopt (arg) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int scanclopt (argc, argv) char * * argv ; {

	errmsg (CHKPT, "scanclopt (%d,argv) \n", argc) ;

	setswid (*argv) ;

	if (--argc)
		while (*++argv)
			testclopt (*argv) ;
	else
		noclopts () ;

	testflags () ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void loadclopt (sopt, lopt, addr, type, help) char * sopt, * lopt, * addr, * type, * help ; {

	CLOPT * tcop ;

	errmsg (CHKPT, "initclopt (%s,%s,%s,%s) \n", sopt, lopt, type, help) ;

	tcop = (CLOPT *) incrlist ( &clopts, &totclopts, CLOPTSIZ ) ;

	tcop->sopt = strclone (sopt) ;
	tcop->lopt = strclone (lopt) ;
	tcop->addr = addr ;
	tcop->type = strclone (type) ;
	tcop->help = strclone (help) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void initclopt () {

	/* standard clopts */

	loadclopt ( "-D", "--debug",	&debugflag,		"t", "debug mode" ) ;
	loadclopt ( "-E", "--env",		&environflag,	"t", "show environment" ) ;
	loadclopt ( "-L", "--license",	&licenseflag,	"t", "show license" ) ;
	loadclopt ( "-N", "--dont",		&dontflag,		"t", "fake mode" ) ;
	loadclopt ( "-Q", "--quiet",	&quietflag,		"t", "quiet mode" ) ;
	loadclopt ( "-V", "--version",	&versionflag,	"t", "show version" ) ;
	loadclopt ( "-v", "--verbose",	&verboseflag,	"t", "verbose mode" ) ;
	loadclopt ( "-?", "--help",		&helpflag,		"t", "usage help" ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void helpclopt () {

	int i ;
	int optionalflagcount = 0, mandatoryflagcount = 0 ;
	int optionalparmcount = 0, mandatoryparmcount = 0 ;
	CLOPT * tcop ;

	errmsg (CHKPT, "helpclopt () \n") ;

	for ( i = 0 ; i < totclopts ; ++i ) {
		tcop = clopts + i ;
		switch (tcop->type[0]) {
			case 't' :
			case 'f' :
				++optionalflagcount ;
			break ;

			case 'T' :
			case 'F' :
				++mandatoryflagcount ;
			break ;

			case 'i' :
			case 'l' :
			case 's' :
				++optionalparmcount ;
			break ;

			case 'I' :
			case 'L' :
			case 'S' :
				++mandatoryparmcount ;
			break ;

			default :
				errmsg (FATAL, "invalid parameter type (%c) \n", tcop->type[0]) ;
			break ;
		}
	}

	printf (" use : %s", swid) ;

	if (optionalflagcount > 0) {
		printf (" [-") ;
		for ( i = 0 ; i < totclopts ; ++i ) {
			tcop = clopts + i ;
			printf ("%c", tcop->sopt[1]) ;
		}
		printf ("]") ;
	}

	if (mandatoryflagcount > 0) {
		printf (" [-") ;
		for ( i = 0 ; i < totclopts ; ++i ) {
			tcop = clopts + i ;
			printf ("%c", tcop->sopt[1]) ;
		}
		printf ("]") ;
	}

	if (totparms > 0)
		for ( i = 0 ; i < totparms ; ++i )
			printf (" [-%s \"%s\"]", (clparms+i)->name, (clparms+i)->help) ;

	printf ("\n\n") ;

	if (totflags > 0)
		for ( i = 0 ; i < totflags ; ++i )
			printf ("  -%s : %s \n", (clflags+i)->name, (clflags+i)->help) ;

	printf ("\n") ;

	exit (0) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * incrlist (base, totelm, elmsiz) char * * base ; int * totelm ; {

	char * tp ;

	if ( *base == NULL )
		tp = malloc ( elmsiz ) ;
	else
		tp = realloc ( *base , (1 + *totelm) * elmsiz ) ;

	if ( tp == NULL )
		errmsg (FATAL, "no mem for incrlist \n") ;

	*base = tp ;

	tp += (*totelm * elmsiz) ;
	++(*totelm) ;

	return tp ;
}

char * strclone (s) char * s ; {

	char * tp = strdup (s) ;

	if (tp == NULL)
		errmsg (FATAL, "no mem for strclone (%s) \n", s) ;

	return tp ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

