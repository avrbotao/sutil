
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdnet.c				 network connectivity	|
 *		\ \/ /		|	(c) 1994-2003			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define	USE_STDIO
# define	USE_ERRNO

# define	USE_STDSTR
# define	USE_STDNET

# include	"abc.h"

# ifndef NONET

# include <stdlib.h>

# include <sys/types.h>
# include <sys/varargs.h>

	/*------------------------------------------------------------------*/
	/*		get (specially localhost's) fully qualified domain name		*/
	/*------------------------------------------------------------------*/

char * getfqdn (hostname, fqdnbuf) char * hostname , * fqdnbuf ; {

# ifdef NOTYET

	if ( fqdnbuf == NULL )
		return fqdnbuf ;

	if ( hostname == NULL ) {

		hostname = gethostname () ...

	}

	tmphost1 = gethostbyname (hostname)

	tmphost2 = gethostbyaddr (tmphost1->addr)

	fqdn = tmphost2 -> hostname

	return fqdn

# endif

}

/*----------------------------------------------------------------------*/
/*		model connects ...												*/
/*----------------------------------------------------------------------*/

int connectsock (
					const char * host ,
					const char * service ,
					const char * transport ) {

    struct hostent      *phe;   /* pointer to host information entry    */
    struct servent      *pse;   /* pointer to service information entry */
    struct protoent *ppe;       /* pointer to protocol information entry*/
    struct sockaddr_in sin;     /* an Internet endpoint address         */
    int s, type;        /* socket descriptor and socket type    */

    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;

    /* Map service name to port number */
    if ( pse = getservbyname(service, transport) )
        sin.sin_port = pse->s_port;
    else if ( (sin.sin_port =
              htons((u_short)atoi(service))) == 0 )
        errexit("can't get \"%s\" service entry\n", service);

    /* Map host name to IP address, allowing for dotted decimal */
    if ( phe = gethostbyname(host) )
        memcpy(&sin.sin_addr, phe->h_addr,
               phe->h_length);
    else if ( (sin.sin_addr.s_addr = inet_addr(host))
              == INADDR_NONE )
        errexit("can't get \"%s\" host entry\n", host);

    /* Map transport protocol name to protocol number */
    if ( (ppe = getprotobyname(transport)) == 0)
        errexit("can't get \"%s\" protocol entry\n", transport);

    /* Use protocol to choose a socket type */
    if (strcmp(transport, "udp") == 0)
        type = SOCK_DGRAM;
    else
        type = SOCK_STREAM;

    /* Allocate a socket */
    s = socket(PF_INET, type, ppe->p_proto);
    if (s < 0)
        errexit("can't create socket: %s\n", strerror(errno));

    /* Connect the socket */
    if (connect(s, (struct sockaddr *)&sin,
                sizeof(sin)) < 0)
        errexit("can't connect to %s.%s: %s\n", host, service,
                strerror(errno));
    return s;
}

int connectTCP(const char *host, const char *service ) {

    return connectsock( host, service, "tcp");
}

int connectUDP(const char *host, const char *service ) {

    return connectsock(host, service, "udp");
}

/*----------------------------------------------------------------------*/
/*		setcli : connect to "service" on "host" using "protocol"		*/
/*----------------------------------------------------------------------*/

int setcli (host, service, protocol, ppud)

char * host , * service , * protocol ; struct t_unitdata * * ppud ;

{
	struct sockaddr_in		sin ;

	if ( strcmp ( protocol , "tcp" ) == 0 )

		return tcpcli (host, service) ;

	else if ( strcmp ( protocol , "udp" ) == 0 )

		return udpcli (host, service, ppud) ;

	else

		return tlicli (host, service, protocol, &sin) ;
}

/*----------------------------------------------------------------------*/
/*		tcpcli : connect to TCP service on a host						*/
/*----------------------------------------------------------------------*/

# ifdef USE_TLI

int tcpcli (host, service) char * host , * service ; {

	struct sockaddr_in		sin ;
	struct t_call *			pcall ;
	int						cd ;

	cd = tlicli (host, service, "tcp", &sin) ;

	pcall = (struct t_call *) t_alloc (cd, T_CALL, T_ADDR) ;

	if (pcall == NULL)

		errexit ("tcpcli: t_alloc failed (%s)\n", t_errlist[t_errno]) ;

	memcpy (pcall->addr.buf, &sin, pcall->addr.len = sizeof (sin)) ;

	if ( t_connect (cd, pcall, 0) < 0 )

		errexit ("tcpcli: t_connect failed: (%s)\n", t_errlist[t_errno]) ;

	t_free ( (char *) pcall, T_CALL ) ;

	return cd ;
}

/*----------------------------------------------------------------------*/
/*		udpcli : set up call to a UDP service on a host					*/
/*----------------------------------------------------------------------*/

int udpcli (host, service, ppud)

char * host , * service ; struct t_unitdata * * ppud ;

{

	struct sockaddr_in		sin ;
	struct t_unitdata *		pud ;
	int						cd ;

	cd = tlicli (host, service, "udp", &sin) ;

	pud = (struct t_unitdata *) t_alloc (cd, T_UNITDATA, T_ADDR | T_UDATA) ;

	if (pud == NULL)

		errexit ("udpcli: t_alloc failed (%s)\n", t_errlist[t_errno]) ;

	memcpy (pud->addr.buf, &sin, pud->addr.len = sizeof (sin)) ;

	*ppud = pud ;

	return cd ;
}

/*----------------------------------------------------------------------*/
/*		tlicli : allocate & connect a TLI descriptor (TCP|UDP)			*/
/*----------------------------------------------------------------------*/

int tlicli (host, service, protocol, psin)

char * host , * service , * protocol ; struct sockaddr_in * psin ;

{
	struct hostent *	phe ;
	struct servent *	pse ;
	char *				pdevname ;
	int					cd ;

	memset ( (char *) psin, 0x00, sizeof (struct sockaddr_in) ) ;

	psin->sin_family = AF_INET ;

	/*----------------------------------------------*/
	/*	map service name to port number ...			*/
	/*----------------------------------------------*/

	if ( pse = getservbyname (service, protocol) )

		psin->sin_port = pse->s_port ;

	else if ( (psin->sin_port = htons ((u_short) atoi (service))) == 0 )

		errexit ("tlicli: service \"%s\" unknown\n", service) ;

	/*----------------------------------------------*/
	/*	map host name to IP address ...				*/
	/*----------------------------------------------*/

	if ( phe = gethostbyname (host) )

		memcpy ((char *) &psin->sin_addr, phe->h_addr, phe->h_length) ;

	else if ( (psin->sin_addr.s_addr = inet_addr (host)) == INADDR_NONE )

		errexit ("tlicli: host \"%s\" unknown\n", host) ;

	/*----------------------------------------------*/
	/*	select TLI device by protocol ...			*/
	/*----------------------------------------------*/

	if ( strcmp ( protocol , "tcp" ) == 0 )

		pdevname = TCPNETDEV ;

	else if ( strcmp ( protocol , "udp" ) == 0 )

		pdevname = UDPNETDEV ;

	else

		errexit ("tlicli: protocol \"%s\" unknown\n", protocol) ;

	/*----------------------------------------------*/
	/*	open TLI device & bind to it ...			*/
	/*----------------------------------------------*/

	if ( ( cd = t_open ( pdevname , O_RDWR , 0 ) ) < 0 )

		errexit ("tlicli: can't open \"%s\" (%s)\n", pdevname, strerr (errno)) ;

	if ( t_bind (cd, 0, 0) < 0 )

		errexit ("tlicli: t_bind failed (%s)\n", t_errlist[t_errno]) ;

	return cd ;
}

# endif /* USE_TLI */

/*----------------------------------------------------------------------*/
/*		errexit : choke & die ...										*/
/*----------------------------------------------------------------------*/

/*VARARGS1*/

int errexit (format, va_alist) char * format ; va_dcl {

	va_list		args ;

	va_start (args) ;
	_doprnt (format, args, stderr) ;
	va_end (args) ;
	exit (1) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* NONET */

/*
 * vi:tabstop=4
 */
