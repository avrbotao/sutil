
/*
 *
 *	  /\
 *	 /  \		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	/ OO \		|	stdxfs.c	  virtual file system	|
 *	\ \/ /		|	(c) 1994-2003	alexandre v. r. botao	|
 *	 \  /		|_______________________________________________|
 *	  \/
 *
 */

# define	USE_SYSTYPES

# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDSTR
# define	USE_STDTYP
# define	USE_STDMISC
# define	USE_STDMEM
# define	USE_STDLOGIC
# define	USE_STDXFS

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	*/

XFSDAT * *	xfstab = NULL ;
XFSDAT		sumxfs ;
XFSDAT *	xfsp ;

int		totxfs = 0 ;
int		curxfs = 0 ;

int plainxfs = 0 ;
int fancyxfs = 0 ;
int fullnameflag = 0 ;

int		rd ;
FILE *		mfp ;

MOUNTENTRY	meb ;
MOUNTENTRY *	mep ;
FSYSSTATUS	fsb ;

/*	--	--	--	--	--	--	--	--	*/

void initxfs () {

# ifdef WIN32

# endif /* WIN32 */

# ifdef LINUX
	mfp = setmntent ( MOUNT_TABLE, "r" ) ;
# endif /* LINUX */

# ifdef SOLARIS
	mfp = fopen ( MOUNT_TABLE, "r" ) ;
# endif /* SOLARIS */

}

/*	--	--	--	--	--	--	--	--	*/

int readxfs () {

	int rd = 0 ;

# ifdef LINUX
	if ( ( mep = getmntent (mfp) ) == NULL )
		rd = -1 ;
# endif /* LINUX */

# ifdef SOLARIS
	if ( getmntent (mfp, mep = &meb) != 0 )
		rd = -1 ;
# endif /* SOLARIS */

	return rd ;
}

/*	--	--	--	--	--	--	--	--	*/

void statxfs () {

# ifdef LINUX
#   ifdef USE_STATVFS
	if ( ( rd = statvfs ( mep->MNT_PATH , &fsb ) ) == -1 )
		fsb.f_blocks = -1 ;
#   endif /* USE_STATVFS */
#   ifdef USE_STATFS
	if ( ( rd = statfs ( mep->MNT_PATH , &fsb ) ) == -1 )
		fsb.f_blocks = -1 ;
#   endif /* USE_STATFS */
# endif /* LINUX */

# ifdef SOLARIS
	if ( ( rd = statvfs ( mep->MNT_PATH , &fsb ) ) == -1 )
		fsb.f_blocks = -1 ;
# endif /* SOLARIS */

}

/*	--	--	--	--	--	--	--	--	*/

int nullxfs () {

	int isnull = FALSE ;

# ifdef LINUX
	if ( fsb.f_blocks <= 0 )
		isnull = TRUE ;
# endif /* LINUX */

# ifdef SOLARIS
	if ( hasmntopt (mep, MNTOPT_IGNORE) != NULL )
		isnull = TRUE ;
	if ( strcmp (mep->MNT_TYPE, MNTTYPE_LOFS) == 0 )
		isnull = TRUE ;
	if ( fsb.f_blocks <= 0 )
		isnull = TRUE ;
# endif /* SOLARIS */

	return isnull ;
}

/*	--	--	--	--	--	--	--	--	*/

XFSDAT * alocxfs () {

	XFSDAT * tp , * * tpp ;

	if ( xfstab == NULL ) {
		tpp = (XFSDAT * *) xmalloc ( sizeof (XFSDAT *) ) ;
	} else {
		tpp = (XFSDAT * *) xmrealloc ( xfstab, (1+totxfs) * sizeof (XFSDAT *) ) ;
	}

	if ( tpp == NULL ) {
		fprintf (stderr, "xfs: erro em xm[re]alloc (%d x XFSDAT*) \n", 1+totxfs) ;
		exit (1) ;
	}

	xfstab = tpp ;

	tp = (XFSDAT *) xmalloc ( sizeof (XFSDAT) ) ;

	if ( tp == NULL ) {
		fprintf (stderr, "xfs: erro em xmalloc (XFSDAT) \n") ;
		exit (1) ;
	}

	*(xfstab+totxfs++) = tp ;

	return tp ;
}

/*	--	--	--	--	--	--	--	--	*/

void fillxfs (tp) XFSDAT * tp ; {

	tp->xfs_mntent = mep ;
	tp->xfs_status = &fsb ;

	tp->xfs_device  = strclone (mep->MNT_DEV) ;
	tp->xfs_path    = strclone (mep->MNT_PATH) ;
	tp->xfs_type    = strclone (mep->MNT_TYPE) ;
	tp->xfs_options = strclone (mep->MNT_OPTS) ;

	tp->xfs_block_size   = fsb.f_bsize ;

# ifdef HASFRSIZE
	tp->xfs_alt_blksiz   = fsb.f_frsize ;
# else  /* NOTFRSIZE */
	tp->xfs_alt_blksiz   = fsb.f_bsize ;
# endif /* HASFRSIZE */

	sumxfs.xfs_tot_blocks   += ( tp->xfs_tot_blocks   = fsb.f_blocks ) ;
	sumxfs.xfs_free_blocks  += ( tp->xfs_free_blocks  = fsb.f_bfree ) ;
	sumxfs.xfs_avail_blocks += ( tp->xfs_avail_blocks = fsb.f_bavail ) ;

	sumxfs.xfs_tot_files    += ( tp->xfs_tot_files    = fsb.f_files ) ;
	sumxfs.xfs_free_files   += ( tp->xfs_free_files   = fsb.f_ffree ) ;

	sumxfs.xfs_tot_bytes    += ( tp->xfs_tot_bytes    = tp->xfs_alt_blksiz * tp->xfs_tot_blocks ) ;
	sumxfs.xfs_free_bytes   += ( tp->xfs_free_bytes   = tp->xfs_alt_blksiz * tp->xfs_free_blocks ) ;
	sumxfs.xfs_avail_bytes  += ( tp->xfs_avail_bytes  = tp->xfs_alt_blksiz * tp->xfs_avail_blocks ) ;

	sumxfs.xfs_used_bytes   += ( tp->xfs_used_bytes   = tp->xfs_tot_bytes - tp->xfs_free_bytes ) ;
	sumxfs.xfs_used_files   += ( tp->xfs_used_files   = tp->xfs_tot_files - tp->xfs_free_files ) ;

	tp->xfs_capacity = tp->xfs_tot_bytes ? ( tp->xfs_used_bytes * 100 ) / tp->xfs_tot_bytes : 0L ;
	tp->xfs_ino_perc = tp->xfs_tot_files ? ( tp->xfs_used_files * 100 ) / tp->xfs_tot_files : 0L ;
}

/*	--	--	--	--	--	--	--	--	*/

void storxfs () {

	XFSDAT * tp ;

	tp = alocxfs () ;
	fillxfs (tp) ;
}

/*	--	--	--	--	--	--	--	--	*/

void quitxfs () {

# ifdef LINUX
	endmntent (mfp) ;
# endif /* LINUX */

# ifdef SOLARIS
	fclose (mfp) ;
# endif /* SOLARIS */

}

/*	--	--	--	--	--	--	--	--	*/

# define NALL

void loadxfs () {

	initxfs () ;

	while ( readxfs () != -1 ) {

		statxfs () ;
# ifdef NALL
		if ( nullxfs () )
			continue ;
# endif
		storxfs () ;
	}

	quitxfs () ;
}

/*	--	--	--	--	--	--	--	--	*/

XFSDAT * walkxfs () {

	XFSDAT * tp = NULL ;

	if ( curxfs < totxfs )
		tp = *(xfstab+curxfs++) ;
	else
		curxfs = 0 ;

	return tp ;
}

/*	--	--	--	--	--	--	--	--	*/

# define PLAIN
# define FANCY

# if ! defined FANCY && ! defined PLAIN
#    error "display mode undefined"
# endif

void dispxfs (tp) XFSDAT * tp ; {

# ifdef PLAIN

	if (plainxfs) {
		printf ( "\n" ) ;
		printf ( "device ................ [%s] \n", tp->xfs_device ) ;
		printf ( "path .................. [%s] \n", tp->xfs_path ) ;
		printf ( "type .................. [%s] \n", tp->xfs_type ) ;
		printf ( "options ............... [%s] \n", tp->xfs_options ) ;

		printf ( "block size (opt) ...... [%lld] \n", (long long) tp->xfs_block_size ) ;
		printf ( "block size (alt) ...... [%lld] \n", (long long) tp->xfs_alt_blksiz ) ;

		printf ( "total blocks .......... [%lld] \n", (long long) tp->xfs_tot_blocks ) ;
		printf ( "free blocks ........... [%lld] \n", (long long) tp->xfs_free_blocks ) ;
		printf ( "available blocks ...... [%lld] \n", (long long) tp->xfs_avail_blocks ) ;

		printf ( "total bytes ........... [%lld] \n", (long long) tp->xfs_tot_bytes ) ;
		printf ( "free bytes ............ [%lld] \n", (long long) tp->xfs_free_bytes ) ;
		printf ( "available bytes ....... [%lld] \n", (long long) tp->xfs_avail_bytes ) ;
		printf ( "used bytes ............ [%lld] \n", (long long) tp->xfs_used_bytes ) ;

		printf ( "capacity .............. [%d %%] \n", tp->xfs_capacity ) ;

		printf ( "total files ........... [%lld] \n", (long long) tp->xfs_tot_files ) ;
		printf ( "free files ............ [%lld] \n", (long long) tp->xfs_free_files ) ;
		printf ( "used files ............ [%lld] \n", (long long) tp->xfs_used_files ) ;

		printf ( "file capacity ......... [%d %%] \n", tp->xfs_ino_perc ) ;
	}

# endif /* PLAIN */

# ifdef FANCY

	if (fancyxfs) {
		if (fullnameflag)
			printf ( "%-16s ", tp->xfs_device ) ;
		else
			printf ( "%-16.16s ", tp->xfs_device ) ;
		printf ( "%s ", KMGTPE (tp->xfs_tot_bytes) ) ;
		printf ( "%s ", KMGTPE (tp->xfs_used_bytes) ) ;
		printf ( "%s ", KMGTPE (tp->xfs_free_bytes) ) ;
		printf ( "%s ", KMGTPE (tp->xfs_avail_bytes) ) ;
		printf ( "%3d%% ", tp->xfs_capacity ) ;
		printf ( "%s ", KMGTPE (tp->xfs_tot_files) ) ;
		printf ( "%s ", KMGTPE (tp->xfs_used_files) ) ;
		printf ( "%s ", KMGTPE (tp->xfs_free_files) ) ;
		printf ( "%3d%% ", tp->xfs_ino_perc ) ;
		if (fullnameflag)
			printf ( "%s\n", tp->xfs_path ) ;
		else
			printf ( "%-16.16s\n", tp->xfs_path ) ;
	}

# endif /* FANCY */

}

/*	--	--	--	--	--	--	--	--	*/

void listxfs () {

	XFSDAT * tp ;

# ifdef FANCY
	if (fancyxfs) {
		printf ( "---------------- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----------------\n") ;
		printf ( "device           size used free avns full inos used free ino%% directory\n") ;
		printf ( "---------------- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----------------\n") ;
	}
# endif /* FANCY */

	while ( ( tp = walkxfs () ) != NULL )
		dispxfs (tp) ;

# ifdef FANCY
	if (fancyxfs) {
		sumxfs.xfs_capacity = sumxfs.xfs_tot_bytes ? ( sumxfs.xfs_used_bytes * 100 ) / sumxfs.xfs_tot_bytes : 0L ;
		sumxfs.xfs_ino_perc = sumxfs.xfs_tot_files ? ( sumxfs.xfs_used_files * 100 ) / sumxfs.xfs_tot_files : 0L ;

		printf ( "---------------- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----------------\n") ;
		printf ( "%-16s ", "total" ) ;

		printf ( "%s ", KMGTPE (sumxfs.xfs_tot_bytes) ) ;
		printf ( "%s ", KMGTPE (sumxfs.xfs_used_bytes) ) ;
		printf ( "%s ", KMGTPE (sumxfs.xfs_free_bytes) ) ;
		printf ( "%s ", KMGTPE (sumxfs.xfs_avail_bytes) ) ;
		printf ( "%3d%% ", sumxfs.xfs_capacity ) ;
		printf ( "%s ", KMGTPE (sumxfs.xfs_tot_files) ) ;
		printf ( "%s ", KMGTPE (sumxfs.xfs_used_files) ) ;
		printf ( "%s ", KMGTPE (sumxfs.xfs_free_files) ) ;
		printf ( "%3d%% ", sumxfs.xfs_ino_perc ) ;

		printf ( "%d\n", totxfs ) ;
		printf ( "---------------- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----------------\n") ;
	}
# endif /* FANCY */

}

/*	--	--	--	--	--	--	--	--	*/
