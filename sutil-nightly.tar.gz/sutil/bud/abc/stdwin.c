
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdwin.c				 blessings window pkg	|
 *		\ \/ /		|	(c) 1998				alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define USE_SYSTYPES
# define USE_STDIO
# define USE_STDLIB

# define USE_STDASC
# define USE_STDTYP
# define USE_STDVIF
# define USE_STDBOX
# define USE_STDWIN
# define USE_STDMEM
# define USE_STDTIO
/* # define USE_SYSMEM */

# include "abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

WINDES *	stdwin = NULL ;
WINDES *	curwin = NULL ;

SCRELM *	stdseb = NULL ;

SCRELM		SE_SPACE = { SPC , WNORM , 0 , 0 } ;

char		wwobuf [524288] ;
char *		wwoptr = wwobuf ;

# define	WWPUTB(X)		*wwoptr++ = (X)

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int wwinit (int hei, int wid) {

	/* REG int x ; */
	register WINDES * wwp ;
    register SCRELM * sep ;
	int pgsz, lnsz ;

	wwp = (WINDES *) xmalloc (WINDESSIZ) ;

	if (wwp == NULL)
		return -1 ;

	if (hei == 0 && wid == 0) {
		getscrsiz ( &pgsz, &lnsz ) ;
		hei = pgsz ;
		wid = lnsz ;
	}

	if (hei <= 0)
		hei = 24 ;

	if (wid <= 0)
		wid = 80 ;

	wwp->ww_atr = WNORM ;
	wwp->ww_lin = wwp->ww_cy = 0 ;
	wwp->ww_col = wwp->ww_cx = 0 ;

	wwp->ww_hei = hei /* 50 */ ;
	wwp->ww_wid = wid /* 80 */ ;

    wwp->ww_siz = wwp->ww_hei * wwp->ww_wid ;

	sep = (SCRELM *) xmalloc (wwp->ww_siz * SCRELMSIZ) ;

	if (sep == NULL)
		return -1 ;

	stdseb = wwp->ww_sav = sep ;
	curwin = stdwin = wwp ;

	wwclear (stdwin) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwend () {

	if (stdwin == NULL)
		return ;

	wwclear (stdwin) ;

	xmfree ( (char *) stdseb ) ;
	xmfree ( (char *) stdwin ) ;

	curwin = stdwin = NULL ;
	stdseb = NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int wwgrow (int deltahei, int deltawid) {

	REG SCRELM * sep ;
	REG int x ;

	x = (stdwin->ww_hei + deltahei) * (stdwin->ww_wid + deltawid) * SCRELMSIZ ;
	sep = (SCRELM *) xmrealloc ( (char *) stdseb , x ) ;

	if ( sep == NULL ) {
		return -1 ;
	}

	stdwin->ww_hei += deltahei ;
	stdwin->ww_wid += deltawid ;
	stdwin->ww_sav = stdseb = sep ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

WINDES * wwopen (int lin, int col, int hei, int wid) {

	REG SCRELM * seb = stdseb ;
	REG SCRELM * sep ;
	REG WINDES * wwp ;
	REG int x, y, w = stdwin->ww_wid ;
	REG int bot = lin + hei ;
	REG int lim = col + wid ;

	wwp = (WINDES *) xmalloc (WINDESSIZ) ;

/*fprintf(stderr,"wwopen(%d,%d,%d,%d)_wwp=(%ld)\r\n",lin,col,hei,wid,(long)wwp);*/

	if ( wwp == NULL )
		return wwp ;

	sep = (SCRELM *) xmalloc (wid * hei * SCRELMSIZ) ;

	if ( sep == NULL ) {
		xmfree ( (char *) wwp ) ;
		return NULL ;
	}

	wwp->ww_lin = lin ;
	wwp->ww_col = col ;
	wwp->ww_cy = lin ;
	wwp->ww_cx = col ;
	wwp->ww_wid = wid ;
	wwp->ww_hei = hei ;
	wwp->ww_atr = WNORM ;
	wwp->ww_sav = sep ;

	for ( y = lin ; y < bot ; ++y )
		for ( x = col ; x < lim ; ++x )
			*sep++ = *(seb+( y * w + x )) ;

	return curwin = wwp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwclose (wwp) WINDES * wwp ; {

	SCRELM * sep = wwp->ww_sav ;
	REG int x, y ;
	REG int bot = wwp->ww_lin + wwp->ww_hei ;
	REG int lim = wwp->ww_col + wwp->ww_wid ;
	REG int tmpatr = stdwin->ww_atr ;

	wwattr (stdwin, sep->se_attr) ;

	for ( y = wwp->ww_lin ; y < bot ; ++y ) {

		x = wwp->ww_col ;
		wwgoto (stdwin, y, x) ;

		for ( ; x < lim ; ++x , ++sep ) {
# ifdef WINDEBUG
fprintf (stderr, "wwclose: byt=[%c] atr=[0x%04x]\r\n", sep->se_byte, sep->se_attr) ;
fflush (stderr) ;
# endif
			wwputw (stdwin, sep) ;
		}
	}

	wwattr (stdwin, tmpatr) ;
	xmfree ( (char *) wwp->ww_sav ) ;
	xmfree ( (char *) wwp ) ;
	curwin = stdwin ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwfill (wwp, byt, atr) WINDES * wwp ; int byt , atr ; {

	REG int x, y ;
	REG int w = wwp->ww_wid ;
	REG int h = wwp->ww_hei ;

	wwattr (wwp, atr) ;

	for ( y = 0 ; y < h ; ++y ) {

		wwgoto (wwp, y, 0) ;

		for ( x = 0 ; x < w ; ++x ) {

			wwputc (wwp, byt) ;
		}
	}

	wwflush () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwclear ( wwp ) WINDES * wwp ; {

	wwfill (wwp, SPC, WNORM) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwceol ( wwp ) WINDES * wwp ; {

	SCRELM * seb = stdseb ;
	REG int w = stdwin->ww_wid ;
	REG int y = wwp->ww_cy ;
	REG int x = wwp->ww_cx ;
	SCRELM tse ;

	clearline () ;

	tse.se_byte = SPC ;
	tse.se_attr = wwp->ww_atr ;
	tse.se_back = tse.se_fore = 0 ;

	for ( ; x < w ; ++x )
		* ( seb + ( y * w + x ) ) = tse ;

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwgoto (wwp, l, c) WINDES * wwp ; int l , c ; {

	wwflush () ;
	wwp->ww_cy = wwp->ww_lin + l ;
	wwp->ww_cx = wwp->ww_col + c ;
	cursorat (wwp->ww_cy, wwp->ww_cx) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwattr (wwp, a) WINDES * wwp ; int a ; {

	REG int attr = a ;

	wwflush () ;

	switch (a) {
		case WBLINK	 	:	blinkvideo () ;		break ;

		case WNORM		:	dflchrset () ;
							normalvideo () ;	break ;

		case WREV	 	:	reversevideo () ;	break ;
		case WHIGH		:	boldvideo () ;		break ;
		case WALTCHRSET	:	altchrset () ;		break ;

		case WDFLCHRSET	:	attr = WNORM ;
							dflchrset () ;
							normalvideo () ;	break ;

# ifdef LATER
		case WUNDER		:	undervideo () ;		break ;
# endif

		default			:	attr = WNORM ;
							normalvideo () ;	break ;
	}

   	wwp->ww_atr = attr ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwputc (wwp, byt) WINDES * wwp ; int byt ; {

	SCRELM * seb = stdseb ;
	REG int w = stdwin->ww_wid ;
	REG int y = wwp->ww_cy ;
	REG int x = wwp->ww_cx ;
	SCRELM tse ;

	tse.se_byte = byt ;
	tse.se_attr = wwp->ww_atr ;
	tse.se_back = tse.se_fore = 0 ;

# ifdef NOWINDEBUG
fprintf (stderr, "wwputc: byt=[%c] atr=[0x%04x]\r\n", tse.se_byte, tse.se_attr) ;
fflush (stderr) ;
# endif

	* ( seb + ( y * w + x ) ) = tse ;

	WWPUTB (byt) ;

	if ( ++x >= wwp->ww_col + wwp->ww_wid ) {
		x = wwp->ww_col ;
		if ( ++y >= wwp->ww_lin + wwp->ww_hei ) {
			y = wwp->ww_lin ;
		}
		wwgoto (wwp, y - wwp->ww_lin, x - wwp->ww_col) ;
	} else {
		wwp->ww_cx = x ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwputw (wwp, sep) WINDES * wwp ; SCRELM * sep ; {

	if (sep->se_attr != wwp->ww_atr)
		wwattr (wwp, sep->se_attr) ;

	wwputc (wwp, sep->se_byte) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwputs (wwp, buf) WINDES * wwp ; char * buf ; {

	while (*buf) {
		wwputc (wwp, *buf++) ;
	}

	wwflush () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwputb (wwp, buf, siz) WINDES * wwp ; char * buf ; int siz ; {

	while (siz-- > 0) {
		wwputc (wwp, *buf++) ;
	}

	wwflush () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwdisp (wwp, lin, col, buf, atr) WINDES * wwp ; char * buf ; int lin , col , atr ; {

	wwgoto (wwp, lin, col) ;
	wwattr (wwp, atr) ;
	wwputs (wwp, buf) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwtitle (wwp, tit) WINDES * wwp ; char * tit ; {

	if (tit == NULL)
		return ;

# ifdef NEAT

	/* centralized text ; same color as border ... */

# else  /* PLAIN */

	wwgoto (wwp, 0, 3) ;
	wwattr (wwp, WREV) ;
	wwputs (wwp, tit) ;
	wwattr (wwp, WNORM) ;

# endif /* NEAT */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwbox (wwp, tit) WINDES * wwp ; char * tit ; {

	register int w = wwp->ww_wid - 2 ;
	register int h = wwp->ww_hei - 2 ;
	register int i ;

	wwattr (wwp, WALTCHRSET) ;
/*	wwattr (wwp, WREV) ; */

	wwgoto (wwp, 0, 0) ;
	wwputc (wwp, box_ul) ;

	for ( i = 0 ; i < w ; ++i )
		wwputc (wwp, box_hl) ;

	wwputc (wwp, box_ur) ;

	for ( i = 0 ; i < h ; ++i ) {
		wwgoto (wwp, 1+i, 0) ;
		wwputc (wwp, box_vl) ;
		wwgoto (wwp, 1+i, w+1) ;
		wwputc (wwp, box_vl) ;
	}

	wwgoto (wwp, h+1, 0) ;
	wwputc (wwp, box_ll) ;

	for ( i = 0 ; i < w ; ++i )
		wwputc (wwp, box_hl) ;

	wwputc (wwp, box_lr) ;

/*	wwattr (wwp, WNORM) ; */
	wwattr (wwp, WDFLCHRSET) ;

	wwtitle (wwp, tit) ;

/*	wwflush (wwp) ;  */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void wwflush () {

	if (wwoptr > wwobuf) {
		strout (wwobuf, (int) (wwoptr-wwobuf)) ;
		wwoptr = wwobuf ;
	}
}

/*
 *		#################################################################
 *		#																#
 *		#	WWFLUSH per-window...										#
 *		#																#
 *		#	WWCEOL MUST TREAT DIFF/LY STDWIN & SMALLER WINS				#
 *		#																#
 *		#	WWCLEAR MUST TREAT THE "WHOLE SCREEN" CASE PROPERLY			#
 *		#																#
 *		#	STDWIN COULD BE INITIALIZED VIA WWOPEN() ? (THINK...)		#
 *		#																#
 *		#################################################################
 */

/*
 * vi:tabstop=4
 */
