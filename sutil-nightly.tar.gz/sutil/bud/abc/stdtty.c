
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# define SWNAME	"ttyx"
# define SWVERS	"0.1.44"
# define SWFORG	"$"				/*	"$" = stable	*/
# define SWDATE	"2014-12-22"
# define SWCOPY	"(fos)"
# define SWAUTH	"alexandre@botao.org"

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdtty								tty stuff	|
 *		\ \/ /		|	(c) 1995-2015			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

#include "stdtty.h"

/*____________________________________________________________________________
*/

static	int		tty_verbosity = 0 ;

static	int		tty_saved_fd = -1 ;

static	int		tty_work_fd = -1 ;

static	struct	termios		tty_saved_term ;

static	enum	{
	TTY_RESET,
	TTY_RAW,
	TTY_CBREAK
}	tty_term_state	=	TTY_RESET ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char * tty_key_names [ ] =  {
	"F1",	"F2",	"F3",	"F4",	"F5",	"F6",
	"F7",	"F8",	"F9",	"F10",	"F11",	"F12",
	"HOME",	"END",	"PGUP",	"PGDN",	"INS",	"DEL",
	"UP",	"DOWN",	"LEFT",	"RIGHT",		
	NULL
} ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

TTY_KEY_DATA tty_key_data [ ] = {

	{ "k1",		KEY_F(1),	"F1",		NULL	} ,
	{ "k2",		KEY_F(2),	"F2",		NULL	} ,
	{ "k3",		KEY_F(3),	"F3",		NULL	} ,
	{ "k4",		KEY_F(4),	"F4",		NULL	} ,
	{ "k5",		KEY_F(5),	"F5",		NULL	} ,
	{ "k6",		KEY_F(6),	"F6",		NULL	} ,
	{ "k7",		KEY_F(7),	"F7",		NULL	} ,
	{ "k8",		KEY_F(8),	"F8",		NULL	} ,
	{ "k9",		KEY_F(9),	"F9",		NULL	} ,
	{ "k;",		KEY_F(10),	"F10",		NULL	} ,
	{ "F1",		KEY_F(11),	"F11",		NULL	} ,
	{ "F2",		KEY_F(12),	"F12",		NULL	} ,

	{ "kh",		KEY_HOME,	"Home",		NULL	} ,
	{ "@7",		KEY_END,	"End",		NULL	} ,

	{ "kP",		KEY_PPAGE,	"PgUp",		NULL	} ,
	{ "kN",		KEY_NPAGE,	"PgDn",		NULL	} ,

	{ "kI",		KEY_IC,		"Ins",		NULL	} ,
	{ "kD",		KEY_DC,		"Del",		NULL	} ,

	{ "ku",		KEY_UP,		"Up",		NULL	} ,
	{ "kd",		KEY_DOWN,	"Down",		NULL	} ,
	{ "kl",		KEY_LEFT,	"Left",		NULL	} ,
	{ "kr",		KEY_RIGHT,	"Right",	NULL	} ,

	{ "ks",		KEY_PADS,	"spad",		NULL	} ,
	{ "ke",		KEY_PADE,	"epad",		NULL	} ,

	{ NULL,		-1,			NULL,		NULL	}
/*
	{ "al",		KEY_IC,		"Ins",		NULL	} ,
	{ "dc",		KEY_DC,		"Del",		NULL	} ,
	{ "ho",		KEY_HOME,	"Home",		NULL	} ,
	{ "EN",		KEY_END,	"End",		NULL	} ,
	{ "PU",		KEY_PPAGE,	"PgUp",		NULL	} ,
	{ "PD",		KEY_NPAGE,	"PgDn",		NULL	} ,
*/
} ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char * keylab [] = {

/*	  0		  1		  2		  3		  4		  5		  6		  7		*/

	"NUL",  "SOH",  "STX",  "ETX",  "EOT",  "ENQ",  "ACK",  "BEL",	 /*	 0	*/
	"BS",   "HT",   "LF",   "VT",   "FF",   "CR",   "SO",   "SI",	 /*	 1	*/
	"DLE",  "DC1",  "DC2",  "DC3",  "DC4",  "NAK",  "SYN",  "ETB",	 /*	 2	*/
	"CAN",  "EM",   "SUB",  "ESC",  "FS",   "GS",   "RS",   "US",	 /*	 3	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 4	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 5	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 6	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 7	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 8	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 9	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 A	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 B	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 C	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 D	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"...",	 /*	 E	*/
	"...",	"...",	"...",	"...",	"...",	"...",	"...",	"DEL",	 /*	 F	*/

	"???",  "???",  "???",  "???",  "???",  "???",  "???",  "???",	 /*	 0	*/
	"???",  "???",  "???",  "???",  "???",  "???",  "???",  "???",	 /*	 1	*/
	"???",  "???",  "???",  "???",  "???",  "???",  "???",  "???",	 /*	 2	*/
	"???",  "???",  "???",  "???",  "???",  "???",  "???",  "???",	 /*	 3	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 4	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 5	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 6	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 7	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 8	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 9	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 A	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 B	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 C	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 D	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 E	*/
	"???",	"???",	"???",	"???",	"???",	"???",	"???",	"???",	 /*	 F	*/

	NULL
} ;

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

int tty_cbreak () {
	struct termios term ;
	int		fd = tty_work_fd ;

	if (tcgetattr (fd, &tty_saved_term) == -1)
		return -1 ;

	term = tty_saved_term ;
	term.c_lflag &= ~(ECHO | ICANON) ;
	term.c_cc [VMIN] = 1 ;
	term.c_cc [VTIME] = 0 ;
	if (tcsetattr (fd, TCSAFLUSH, &term) == -1)
		return -1 ;

	tty_term_state = TTY_CBREAK ;
	tty_saved_fd = fd ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int tty_raw () {
	struct termios term ;
	int		fd = tty_work_fd ;

	if (tcgetattr (fd, &tty_saved_term) == -1)
		return -1 ;

	term = tty_saved_term ;
	term.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON) ;
	term.c_oflag &= ~(OPOST) ;
	term.c_cflag &= ~(CSIZE | PARENB) ;
	term.c_cflag |= CS8 ;
	term.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG) ;
	term.c_cc [VMIN] = 1 ;
	term.c_cc [VTIME] = 0 ;
	if (tcsetattr (fd, TCSAFLUSH, &term) == -1)
		return -1 ;

	tty_term_state = TTY_RAW ;
	tty_saved_fd = fd ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int tty_reset () {
	int		fd = tty_work_fd ;

	if (tty_term_state == TTY_RESET)
		return 0 ;

	if (tcsetattr (fd, TCSAFLUSH, &tty_saved_term) == -1)
		return -1 ;

	tty_term_state = TTY_RESET ;
	close (tty_saved_fd) ;
	tty_saved_fd = -1 ;
	tty_work_fd = -1 ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void tty_atexit (void) {
	tty_reset () ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct termios *tty_getoldattr (void) {
	return (&tty_saved_term) ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

# define	TTYKEYBUFSIZ	256

char	tty_burst_buff [TTYKEYBUFSIZ] ;
char	tty_unget_buff [TTYKEYBUFSIZ] ;

int		tty_unget_mark = 0 ;

int		tty_fc_prev = -1 ;
int		tty_fc_work = -1 ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void	tty_ungetchar ( int c ) {
	if ( tty_unget_mark >= TTYKEYBUFSIZ )
		fprintf ( stderr , "unget overflow\r\n" ) ;
	else
		tty_unget_buff [ tty_unget_mark++ ] = c ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void	tty_ungets ( char s [] ) {
	int		i ;
    
    for ( i = strlen (s) ; i > 0 ; )
        tty_ungetchar ( s [ --i ] ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int tty_getchar () {
	char	buf [16] ;
	int		n ;

	if ( tty_unget_mark > 0 ) {
		return (int) tty_unget_buff [ --tty_unget_mark ] ;
	}

	n = read (tty_work_fd, buf, 1) ;

	if ( n <= 0 ) {
		return n ;
	}

	return (int)buf[0] ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int tty_key_queue (int key) {

	int		i = 1 ;

# ifdef TTY_KEY_HIT

	/*	unblock		*/

	if ( ( tty_fc_prev = fcntl ( tty_work_fd , F_GETFL , 0 ) ) < 0 ) {
		perror ("fcntl,GETFL") ;
	} else {
		if ( tty_fc_work == -1 ) {
			tty_fc_work = tty_fc_prev | O_NDELAY | O_NONBLOCK ;
		}
		if ( fcntl ( tty_work_fd , F_SETFL , tty_fc_work ) < 0 ) {
			perror ("fcntl,SETFL") ;
		}
	}

	/*	probe		*/

	for ( tty_burst_buff [0] = key ; ( key = tty_getchar () ) > 0 ; ) {
		tty_burst_buff [i++] = key ;
	}

	/*	reblock		*/

	if ( fcntl ( tty_work_fd , F_SETFL , tty_fc_prev ) < 0 ) {
		perror ("fcntl,RESFL") ;
	}

# else  /* TTY_KEY_INQ */

	int		result = -1 ;
	int		chars_avail = 0 ;

	errno = 0 ;
	result = ioctl (tty_work_fd, FIONREAD, &chars_avail) ;

	if (result == -1 && errno == EIO)
		return -1 ;

	if ( chars_avail <= 0 )
		return chars_avail ;

	for ( tty_burst_buff [0] = key ; i <= chars_avail ; ++i ) {
		key = tty_getchar () ;
		if ( key > 0 ) {
			tty_burst_buff [i] = key ;
		} else {
			break ;
		}
	}

# endif /* TTY_KEY_HIT */

	tty_burst_buff [i] = '\0' ;

	if ( tty_verbosity >= 4 ) {
		fprintf ( stdout, "\r\n" ) ;
		for ( key = 0 ; key < i ; ++key ) {
			fprintf ( stdout ,
				isprint ( (int) tty_burst_buff[key] ) ? " '%c'" : " (%d)" ,
				tty_burst_buff[key]
			) ;
		}
		fprintf ( stdout, "\r\n" ) ;
	}

	return i - 1 /* chars_avail */ ;

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int tty_key_match () {
	int		i ;
	char *	tp ;

	for ( i = 0 ; tty_key_data[i].tcap != NULL ; ++i ) {
		if ( NULL != ( tp = tty_key_data[i].buff ) ) {
			if ( 0 == strcmp ( tty_burst_buff , tp ) ) {
				return tty_key_data[i].code ;
			}
		}
	}

	return -1 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int tty_getkey () {
	int		key ;

	key = tty_getchar () ;

	/*	simple ?	*/

	if ( key != 27 ) {
		return key ;
	}

	/*	burst ?		*/

	if ( tty_key_queue (key) <= 0 ) {
		return key ;
	}

	/*	match ?		*/

	if ( ( key = tty_key_match () ) <= 0 ) {
		key = (int)tty_burst_buff[0] ;
		tty_ungets ( &tty_burst_buff[1] ) ;
	}

	return key ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char * tty_key_label ( int key ) {
			int		i ;
	static	char *	label = "????" ;

	if ( key >=0 && key <= 255 ) {
		return keylab [ key & 0x00ff ] ;
	} else {
		for ( i = 0 ; tty_key_data[i].tcap != NULL ; ++i ) {
			if ( key == tty_key_data[i].code ) {
				return tty_key_data[i].name ;
			}
		}
	}

	return label ;
}

/*____________________________________________________________________________
*/

void tty_key_error (char * text) {
	if (text != NULL) {
		perror (text) ;
	}
	tty_atexit () ;
	exit (1) ;
}

#ifdef SOLARIS

int tty_outc (char c) {

#else  /* ! SOLARIS */

int tty_outc (int c) {

#endif /* ! SOLARIS */

	return fputc (c, stdout) ;
}

void tty_outs (int key) {
	int		i ;
	char *	label = "{??}" ;

	if ( key > 0 ) {
		for ( i = 0 ; tty_key_data[i].tcap != NULL ; ++i ) {
			if ( key == tty_key_data[i].code ) {
				label = tty_key_data[i].buff ;
				break ;
			}
		}
	}

	tputs ( label , 0 , tty_outc ) ;
}

void tty_key_quit (void) {
	tty_outs (KEY_PADE) ;
	tty_atexit () ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char	tgetbuff [1024] ;

void tty_key_init (void) {
	int		ttyfd ;
	int		i , j ;
	char	buf [1024] ;
	char *	tp ;

	tp = getenv ("TERM") ;

	if ( tp == NULL ) {
		tty_key_error ("TERM") ;
	}

	if ( tgetent ( tgetbuff , tp ) <= 0 ) {
		tty_key_error ("tgetent") ;
	}

	for ( i = 0 ; tty_key_data[i].tcap != NULL ; ++i ) {
		tp = buf ;
		tp = tgetstr ( tty_key_data[i].tcap , &tp ) ;
		if ( tp != (char *) 0 ) {
			tp = strdup (buf) ;
			if ( tp == NULL ) {
				tty_key_error ("strdup") ;
			}
			tty_key_data[i].buff = tp ;
			if ( tty_verbosity >= 3 ) {
				fprintf ( stdout, "\t<%s>\t{%d}\t[%s]\t", tty_key_data[i].tcap , tty_key_data[i].code , tty_key_data[i].name ) ;
				for ( j = 0 ; *(tp+j) != '\0' ; ++j ) {
					if ( isprint ( (int) *(tp+j) ) ) {
						printf ( " '%c'",  *(tp+j) ) ;
					} else {
						printf ( " (%d)",  *(tp+j) ) ;
					}
				}
				fprintf ( stdout, "\r\n" ) ;
			}
		} else {
			if ( tty_verbosity >= 3 ) {
				fprintf ( stderr, "~\t<%s>\t{%d}\t[%s]\r\n", tty_key_data[i].tcap , tty_key_data[i].code , tty_key_data[i].name ) ;
			}
		}
	}

	ttyfd = open ("/dev/tty", O_RDWR) ;

	if ( ttyfd < 0 ) {
		tty_key_error ("/dev/tty") ;
	}

	tty_outs (KEY_PADS) ;

	tty_work_fd = ttyfd ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

# define	TTYDFLPROMPT	"@>"

char * tty_readline ( char prompt [] ) {
	char * lp = NULL ;

	if ( prompt == NULL )
		prompt = TTYDFLPROMPT ;

	return lp ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

# ifdef TESTTY

# define	DFL_MAX		20

void usage () {

	fprintf (stderr, "options:\n") ;
	fprintf (stderr, "\t-m maxbytes\n") ;
	fprintf (stderr, "\t--key\n") ;
	fprintf (stderr, "\t--raw\n") ;
	fprintf (stderr, "\t--cbrk\n") ;
	fprintf (stderr, "\t--help\n") ;

	exit (1) ;
}

int main (int argc, char * * argv) {

	int		key ;
	int		max = DFL_MAX ;
	int		cbrflag = 0 ;
	int		rawflag = 0 ;
	int		keyflag = 0 ;

	printf ("%s %s %s\r\n", SWNAME, SWVERS, SWDATE) ;

	if ( --argc ) {
		while ( *++argv != NULL ) {
			if ( 0 == strcmp ( *argv , "-m" ) ) {
			} else if ( 0 == strcmp ( *argv , "--key" ) ) {
				++keyflag ;
			} else if ( 0 == strcmp ( *argv , "--raw" ) ) {
				++rawflag ;
			} else if ( 0 == strcmp ( *argv , "--cbrk" ) ) {
				++cbrflag ;
			} else if ( 0 == strcmp ( *argv , "--help" ) ) {
				usage () ;
			}
		}
	} else {
		++rawflag ;
	}

	tty_key_init () ;

	if ( cbrflag ) {
		if ( tty_cbreak () < 0 ) {
			fprintf (stderr, "cbreak\r\n") ;
			exit (1) ;
		}
	}

	if ( rawflag ) {
		if ( tty_raw () < 0 ) {
			fprintf (stderr, "raw\r\n") ;
			exit (1) ;
		}
	}

	for ( ; max > 0 ; --max ) {

		if ( keyflag ) {
			key = tty_getkey () ;
		} else {
			key = tty_getchar () ;
		}

		printf ("%d\t(%d)", max, key) ;

		if ( isascii (key) && isprint (key) ) {
			printf ("\t'%c'", key) ;
		} else {
			printf ( "\t%s", tty_key_label ( key ) ) ;
		}

		printf ("\r\n") ;

		if ( key <= 0 ) {
			fprintf (stderr, "bad key (%d)\r\n", key) ;
			break ;
		}
	}

	tty_key_quit () ;

	return 0 ;
}

# endif /* TESTTY */

/*____________________________________________________________________________
*/

/*
 *	cc -Wall -Wextra -DTESTTY -o ttyio stdtty.c
 *	vi:nu ts=4
 */

