
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdapp.c					application stuff	|
 *		\ \/ /		|	(c) 2000				alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define	USE_STDIO

# define	USE_STDAPP
# define	USE_STDPARM

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

extern char * optinf [] ;

void lisopt () {

	char * * tpp ;

	printf (" headers : ") ;

	for ( tpp = optinf ; *tpp ; ++tpp )
		if ( **tpp == '^' )
			printf ( "%s ", (*tpp)+1 ) ;

	printf ("\n") ;

	printf (" modules : ") ;

	for ( tpp = optinf ; *tpp ; ++tpp )
		if ( **tpp == '+' )
			printf ( "%s ", (*tpp)+4 ) ;

	printf ("\n") ;

}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	version banner ...											|
 *		|_______________________________________________________________|
 */

# define	VXNAM	verinf[0]		/* name					*/
# define	VXVER	verinf[1]		/* version				*/
# define	VXBID	verinf[2]		/* binary id			*/
# define	VXDAT	verinf[3]		/* date					*/
# define	VXOPS	verinf[4]		/* operating system		*/
# define	VXSIG	verinf[5]		/* signature			*/

extern char * verinf [] ;
extern int    flagbits ;

void verban () {

	printf ("\n \"%s\" %s * %s @ %s / %s (C) %s \n\n",
			VXNAM, VXVER, VXBID, VXDAT, VXOPS, VXSIG) ;

	if (flagbits & PI_ENVIRONBIT)
		lisopt () ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history ..............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v rls   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

