
# include "configure.h"

# define	BANNER		"xd5 5.0.02 2015-01-21 bud"

# define	NEWPRETA

#include <stdio.h>
#include <stdlib.h>

#include <ftw.h>
#include <time.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>

#define PRETA preta /* ptrel64 */
#define MD5SIZ 1048576

# define	MINBUFSIZ		512
# define	MAXBUFSIZ		134217728

# ifdef AIX
#     define  __H_LOCALEDEF
# endif

#ifndef MD
#define MD 5
#define MD5C
#endif

# include "stdhash.h"
# include "preta.h"

int progressbarinterval = 3;

int binarymode = 1 ;

int MDok = 0 ;

int bufsiz = MD5SIZ ;
int maxdepth = 32 ;	/* FIXME: ulimit -n */

short cflag = 0;	/* check */
short Fflag = 0;	/* fast */
short Pflag = 0;	/* Progress bar */
short vflag = 0;	/* verbose/version */

static unsigned char compbuff[32];
static unsigned char digest[16];
static unsigned char * buffer = NULL ;

static void MDList   PROTO_LIST ((char *));
static void MDTree   PROTO_LIST ((char *));
static void MDCheck  PROTO_LIST ((char *));
static void MDVerify PROTO_LIST ((char *,char *));

void banner () {
	puts (BANNER) ;
}

void buffinit () {
	buffer = malloc ( bufsiz ) ;
	if ( buffer == NULL ) {
		perror ("no memory") ;
		exit (1) ;
	}
}

void usage () {
	fprintf (stderr, "use : xd5 [options]\n") ;
	fprintf (stderr, "          filename   : digests file\n") ;
	fprintf (stderr, "          -S size    : alternate buffer size\n") ;
	fprintf (stderr, "          -B         : print MD5 sum in binary on stdout\n") ;
	fprintf (stderr, "          -b         : binary mode (default)\n") ;
	fprintf (stderr, "          -F         : fast processing (no verbose or progress)\n") ;
	fprintf (stderr, "          -h         : usage help\n") ;
	fprintf (stderr, "          -i list    : digests files in list\n") ;
	fprintf (stderr, "          -R dirname : recursively digests files under directory\n") ;
	fprintf (stderr, "          -sstring   : digests string\n") ;
	fprintf (stderr, "          -T         : runs time trial\n") ;
	fprintf (stderr, "          -t         : text mode\n") ;
	fprintf (stderr, "          -x         : runs test script\n") ;
	fprintf (stderr, "          (none)     : digests standard input\n") ;
}

/*________________________________________________________________________
*/

/*
MDDRIVER.C - test driver for MD2, MD4 and MD5

Copyright (C) 1990-2, RSA Data Security, Inc. Created 1990. All rights reserved.

RSA Data Security, Inc. makes no representations concerning either
the merchantability of this software or the suitability of this
software for any particular purpose. It is provided "as is"
without express or implied warranty of any kind.

These notices must be retained in any copies of any part of this documentation and/or software.
*/

/* The following makes MD default to MD5 if it has not already been defined with C compiler flags.  */

/* #include "global.h" */

#if MD == 2
#include "md2.h"
#endif
#if MD == 4
#include "md4.h"
#endif
#if MD == 5
/* #include "md5.h" */
#endif

/* Length of test block, number of test blocks.  */
#define TEST_BLOCK_LEN 1000
#define TEST_BLOCK_COUNT 1000

static void MDString    PROTO_LIST ((char *));
static void MDTimeTrial PROTO_LIST ((void));
static void MDTestSuite PROTO_LIST ((void));
static void MDFile      PROTO_LIST ((char *));
static void MDFilter    PROTO_LIST ((void));
static void MDPrint     PROTO_LIST ((unsigned char [16]));

#if MD == 2
#define MD_CTX MD2_CTX
#define MDInit MD2Init
#define MDUpdate MD2Update
#define MDFinal MD2Final
#endif
#if MD == 4
#define MD_CTX MD4_CTX
#define MDInit MD4Init
#define MDUpdate MD4Update
#define MDFinal MD4Final
#endif
#if MD == 5
#define MD_CTX MD5_CTX
#define MDInit MD5Init
#define MDUpdate MD5Update
#define MDFinal MD5Final
#endif

/* Main driver.

Arguments (may be any combination):
  -sstring - digests string
  -T       - runs time trial
  -x       - runs test script
  -B       - print MD5 sum in binary on stdout
  filename - digests file
  (none)   - digests standard input
 */

short bflag = 0;	/* 1 == print sums in binary */

/*________________________________________________________________________
*/

int main (argc, argv)
int argc;
char *argv[];
{
  int i, t;
  char * p ;

  if (argc > 1) {
    for (i = 1; i < argc; i++) {
      if (argv[i][0] == '-' && argv[i][1] == 's') {
        MDString (argv[i] + 2);
      } else if (strcmp (argv[i], "-b") == 0) {
        binarymode = 1 ;
      } else if (strcmp (argv[i], "-T") == 0) {
        MDTimeTrial ();
      } else if (strcmp (argv[i], "-t") == 0) {
        binarymode = 0 ;
      } else if (strcmp (argv[i], "-x") == 0) {
        MDTestSuite ();
      } else if (strcmp (argv[i], "-B") == 0) {
        bflag = 1;
      } else if ( strcmp ( argv[i] , "-c" ) == 0 ) {
        if ( ( p = argv[++i] ) == NULL ) {
          --i ;
          fprintf (stderr, "* missing arg (%s)\n", "-c") ;
        } else {
          cflag = 1 ; MDCheck (p) ;
        }
      } else if (strcmp (argv[i], "-F") == 0) {
        Fflag = 1;
      } else if (strcmp (argv[i], "-R") == 0) {
        MDTree ( argv[++i] ) ;
      } else if (strcmp (argv[i], "-P") == 0) {
        Pflag = 1;
      } else if (strcmp (argv[i], "-i") == 0) {
        MDList ( argv[++i] ) ;
      } else if (strcmp (argv[i], "-v") == 0) {
        vflag = 1;
      } else if (strcmp (argv[i], "-h") == 0) {
        usage () ;
      } else if (strcmp (argv[i], "-?") == 0) {
        usage () ;
      } else if ( strcmp ( argv[i] , "-I" ) == 0 ) {
        if ( ( p = argv[++i] ) == NULL ) {
          --i ;
          fprintf (stderr, "* missing arg (%s)\n", "-I") ;
        } else {
          progressbarinterval = atoi ( p ) ;
        }
      } else if ( strcmp ( argv[i] , "-S" ) == 0 ) {
        if ( ( p = argv[++i] ) == NULL ) {
          --i ;
          fprintf (stderr, "* missing arg (%s)\n", "-B") ;
        } else {
          t = atoi ( p ) ;
          if ( t > MINBUFSIZ && t < MAXBUFSIZ ) {
            bufsiz = t ;
          } else {
            bufsiz = MD5SIZ ;
          }
        }
      } else {
        MDFile (argv[i]);
      }
    }
  } else {
    MDFilter ();
  }

  return (0);
}

/* Digests a string and prints the result.  */
static void MDString (string) char *string; {
  MD_CTX context;
  unsigned int len = strlen (string);

	if ( buffer == NULL )
		buffinit () ;

  MDInit (&context);
  MDUpdate (&context, (unsigned char *) string, len);
  MDFinal (digest, &context);

  if (!bflag) printf ("MD%d (\"%s\") = ", MD, string);
  MDPrint (digest);
  if (!bflag) printf ("\n");
}

/* Measures the time to digest TEST_BLOCK_COUNT TEST_BLOCK_LEN-byte blocks.  */
static void MDTimeTrial ()
{
  MD_CTX context;
  time_t endTime, startTime;
  unsigned char block[TEST_BLOCK_LEN];
  unsigned int i;

	if ( buffer == NULL )
		buffinit () ;

  printf
 ("MD%d time trial. Digesting %d %d-byte blocks ...", MD,
  TEST_BLOCK_LEN, TEST_BLOCK_COUNT);

  /* Initialize block */
  for (i = 0; i < TEST_BLOCK_LEN; i++)
 block[i] = (unsigned char)(i & 0xff);

  /* Start timer */
  time (&startTime);

  /* Digest blocks */
  MDInit (&context);
  for (i = 0; i < TEST_BLOCK_COUNT; i++)
 MDUpdate (&context, block, TEST_BLOCK_LEN);
  MDFinal (digest, &context);

  /* Stop timer */
  time (&endTime);

  printf (" done\n");
  printf ("Digest = ");
  MDPrint (digest);
# if defined ( AIX ) || defined ( BSD )
  printf ("\nTime = %ld seconds\n", (long)(endTime-startTime));
# else
  printf ("\nTime = %ld seconds\n", (time_t)(endTime-startTime));
# endif
  /*
   * Be careful that endTime-startTime is not zero.
   * (Bug fix from Ric Anderson, ric@Artisoft.COM.)
   */
  printf
# if defined ( AIX ) || defined ( BSD )
 ("Speed = %ld bytes/second\n", (long)TEST_BLOCK_LEN * (time_t)TEST_BLOCK_COUNT/((endTime-startTime) != 0 ? (endTime-startTime):1));
# else
 ("Speed = %ld bytes/second\n", (time_t)TEST_BLOCK_LEN * (time_t)TEST_BLOCK_COUNT/((endTime-startTime) != 0 ? (endTime-startTime):1));
# endif
}

/* Digests a reference suite of strings and prints the results.  */
static void MDTestSuite ()
{
  printf ("MD%d test suite:\n", MD);

	if ( buffer == NULL )
		buffinit () ;

  MDString ("");
  MDString ("a");
  MDString ("abc");
  MDString ("message digest");
  MDString ("abcdefghijklmnopqrstuvwxyz");
  MDString ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
  MDString ("12345678901234567890123456789012345678901234567890123456789012345678901234567890");
}

/*________________________________________________________________________
*/

	FILE *file;
	MD_CTX context;
	size_t		tmpsiz = 0 ;

	struct stat	stabuf ;

static void MDFast () {
	MDInit (&context);
	while ( ( tmpsiz = fread (buffer, 1, bufsiz, file) ) > 0 ) {
		MDUpdate (&context, buffer, tmpsiz);
	}
	MDFinal (digest, &context);
	fclose (file);
}

# define	LISTITEMSIZE	4096

char listitem [LISTITEMSIZE] ;

static void MDList (filelist) char *filelist; {
	FILE * list ;
	int len;

	if (vflag)
		banner () ;

	list = fopen (filelist, "r") ;

	if ( list == NULL ) {
		perror (filelist) ;
		exit (1) ;
	}

	while ( fgets ( listitem , LISTITEMSIZE , list ) != NULL ) {
		for ( len = strlen ( listitem ) - 1 ; listitem [ len ] == '\n' || listitem [ len ] == '\r' ; --len ) {
			listitem [ len ] = '\0' ;
		}
		MDFile ( listitem ) ;
	}

	fclose (list) ;
}

int MDWalk (nam, sta, typ)
const char * nam ;
const struct stat * sta ;
int typ ;
{
	if ( typ == FTW_F && sta != NULL ) {
		MDFile ( (char *) nam ) ;
	}
	return 0 ;
}

static void MDTree (treename) char *treename; {

	if (vflag)
		banner () ;

	if ( stat ( treename , &stabuf ) != 0 ) {
		fprintf (stderr, "* stat <%s> fail\n", treename) ;
		exit (1) ;
	}
	if ( S_ISDIR ( stabuf.st_mode ) ) {
		if ( ftw ( treename , MDWalk , maxdepth ) != 0 ) {
			fprintf (stderr, "* ftw <%s> fail\n", treename) ;
			exit (1) ;
		}
	} else {
		fprintf (stderr, "* <%s> is not a directory\n", treename) ;
		exit (1) ;
	}
}

static void MDVerify (hashtext, filename) char *hashtext, *filename; {

	char * tp ;
	int i ;

	tp = filename ;

	if ( *tp == ' ' ) {
		binarymode = 0 ;
	} else if ( *tp == '*' ) {
		binarymode = 1 ;
	} else {
		fprintf (stderr, "* check list line (%s) invalid mode\n", tp) ;
		return ;
	}

	printf ( "%s: " , ++tp ) ;

	MDFile ( tp ) ;

	if ( ! MDok ) {
		printf ("FAILED\n") ;
	} else {
		for (i = 0; i < 16; i++) {
			sprintf ((char*)&compbuff[i<<1], "%02x", digest[i]);
		}
		if ( 0 == strncasecmp ( hashtext , (char *)compbuff , 32 ) ) {
			printf ("OK\n") ;
		} else {
			printf ("DIFFER\n") ;
		}
	}
}

static void MDCheck (listfile) char *listfile; {

	FILE * lfp ;
	char * tp ;

	lfp = fopen ( listfile , "r" ) ;
	if ( lfp == NULL ) {
		fprintf (stderr, "* check list file (%s) access error\n", listfile) ;
		return ;
	}

	while ( fgets ( listitem , LISTITEMSIZE , lfp ) != NULL ) {
		tp = listitem + strlen ( listitem ) ;
		for ( --tp ; *tp == '\n' || *tp == '\r' ; *tp-- = '\0' ) ;
		tp = strchr ( listitem , ' ' ) ;
		if ( tp == NULL ) {
			fprintf (stderr, "* check list line (%s) format error\n", listitem) ;
			continue ;
		}
		*tp++ = '\0' ;
		/* FIXME: assert isxdigit 32 bytes */
		MDVerify ( listitem , tp ) ;
	}

	fclose (lfp) ;
	exit (0) ;
}

/*________________________________________________________________________
*/

/* Digests a file and prints the result.  */

static void MDFile (filename) char *filename; {
# ifdef NEWPRETA
	off_t		totsiz = 0, cursiz = 0 ;
# else  /* ! NEWPRETA */
	size_t		totsiz = 0, cursiz = 0 ;
# endif /* NEWPRETA */

	if ( buffer == NULL )
		buffinit () ;

	MDok = 0 ;

	if ((file = fopen (filename, binarymode ? "rb" : "r")) == NULL) {
		printf ("%s can't be opened\n", filename);
		return ;
	} else {
		if ( Fflag ) {
			MDFast () ;
		} else {
			if ( fstat ( fileno (file) , &stabuf ) < 0 ) {
				fprintf (stderr, "* stat <%s> fail\n", filename) ;
				return ;
			}
			totsiz = stabuf.st_size ;
			if (Pflag)
# ifdef NEWPRETA
				PRETA (&cursiz, &totsiz, (long) (PTE_INIT|progressbarinterval)) ;
# else  /* ! NEWPRETA */
				PRETA ((long long)cursiz, (long long)totsiz, (long) progressbarinterval) ;
# endif /* NEWPRETA */
			MDInit (&context);
			while ( ( tmpsiz = fread (buffer, 1, bufsiz, file) ) > 0 ) {
				cursiz += tmpsiz ;
# ifndef NEWPRETA
				if (Pflag)
					PRETA ((long long)cursiz, (long long)totsiz, (long) progressbarinterval) ;
# endif /* NEWPRETA */
				MDUpdate (&context, buffer, tmpsiz);
			}
			MDFinal (digest, &context);
			fclose (file);
			if (Pflag)
# ifdef NEWPRETA
				PRETA (&cursiz, &totsiz, PTE_DONE|PTE_NEWL) ;
# else  /* ! NEWPRETA */
				PRETA ((long long)cursiz, (long long)totsiz, PTE_DONE|PTE_NEWL) ;
# endif /* NEWPRETA */
		}

		if ( ! cflag ) {
			MDPrint (digest) ;
			if (!bflag) printf (" %c%s\n", binarymode ? '*' : ' ', filename) ;
		}
	}

	MDok = 1 ;
}

/* Digests the standard input and prints the result.  */
static void MDFilter ()
{
  MD_CTX context;
  int len;

	if (vflag)
		banner () ;

	if ( buffer == NULL )
		buffinit () ;

  MDInit (&context);
  while ( ( len = fread (buffer, 1, bufsiz, stdin) ) > 0 )
    MDUpdate (&context, buffer, len);
  MDFinal (digest, &context);

  MDPrint (digest);
  if (!bflag) printf ("\n");
}

/* Prints a message digest in hexadecimal or binary.  */
static void MDPrint (digest)
unsigned char digest[16];
{
  unsigned int i;

  if (bflag) {
	/* print in binary */
	i = write(1, &digest[0], 16);
  } else {
	/* print in hex */
	for (i = 0; i < 16; i++)
		printf ("%02x", digest[i]);
  }
}

/* cc -DMD5C -o xd5 xd5.c stdhash.c preta.c */

/*
 * vi:nu ts=8
 */
