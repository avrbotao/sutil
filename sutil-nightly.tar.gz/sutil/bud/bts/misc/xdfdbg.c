
# ifdef DEBUG
	printf ("bavail = %ld\n", (long) x_bavail) ;
	printf ("bfree  = %ld\n", (long) x_bfree) ;
	printf ("blocks = %ld\n", (long) x_blocks) ;
	printf ("bused  = %ld\n", (long) x_bused) ;
	printf ("bsize  = %ld\n", (long) x_bsize) ;
# ifdef USE_STATVFS
	printf ("size   = %ld\n", (long) x_size) ;
	printf ("frsize = %ld\n", (long) x_frsize) ;
# endif /* USE_STATVFS */
# endif /* DEBUG */

# ifdef DEBUG2
	printf ("%6d ", x_bsize) ;
# ifdef USE_STATVFS
	printf ("%6d ", x_frsize) ;
# endif /* USE_STATVFS */
# endif /* DEBUG2 */

