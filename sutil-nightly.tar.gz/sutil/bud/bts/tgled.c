
# define	VERNAME			"tgled"
# define	VERSION			"0.1"
# define	VERCODE			"163"
# define	VERDATE			"2000.03.20"
# define	VERSIGN			"Alexandre Botao"

# include <stdio.h>
# include <string.h>

# define USE_STDLIB
# define USE_STDTYP
# define USE_STDVIF
# define USE_STDWIN
# define USE_STDBOX
# define USE_STDMISC
# define USE_STDTERM

# include "abc.h"

# include "stdinfo.h"

char * r1 = "         1         2         3         4         5         6" ;
char * r2 = "123456789012345678901234567890123456789012345612301234567890" ;
char * b1 = "the quick brown fox jumps over the lazy dog" ;

# define	TESTSIZE		80

int main (argc, argv) int argc ; char * * argv ; {

	int lin = 4, col = 4, wid = 50, siz = 80 ;
	char buf[TESTSIZE] ;

	if (argc >= 4) {
		lin = atoi (*++argv) ;
		col = atoi (*++argv) ;
		wid = atoi (*++argv) ;
		siz = atoi (*++argv) ;
	}

	if (argc == 6) {
		if ( strcmp ( *++argv , "-" ) == 0 ) {
			strcpy (buf, b1) ;
		} else {
			strcpy (buf, *argv) ;
		}
	}

	terminit () ;
	winit () ;

	clearscreen () ;

	border (lin, col, wid, 3) ;

	cursorat (lin-2, col+1) ;
	strout (r1, wid-2);

	cursorat (lin-1, col+1) ;
	strout (r2, wid-2);

	gled (lin+1, col+1, buf, siz, wid-2) ;

	cursorat (lin+6, 10) ;

	wend () ;
	termend () ;

	printf ("--> [%s] \n\n", buf) ;

	return 0 ;
}

void epilogue () {

}

