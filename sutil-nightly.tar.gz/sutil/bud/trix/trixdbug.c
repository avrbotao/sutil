
# define GRAPHCHECK
# ifdef GRAPHCHECK
graphcheck () {
	printf("C_G25P(%u)\r\n",C_G25P&0x00ff);
	printf("C_G50P(%u)\r\n",C_G50P&0x00ff);
	printf("C_G75P(%u)\r\n",C_G75P&0x00ff);
	printf("C_G99P(%u)\r\n",C_G99P&0x00ff);
	printf("C_SHBX(%u)\r\n",C_SHBX&0x00ff);
	printf("C_WHBX(%u)\r\n",C_WHBX&0x00ff);
	printf("C_EHBX(%u)\r\n",C_EHBX&0x00ff);
	printf("C_NHBX(%u)\r\n",C_NHBX&0x00ff);
}
# endif

