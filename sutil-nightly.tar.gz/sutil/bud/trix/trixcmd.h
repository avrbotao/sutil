/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixcmd.h + customizable command coding ...			|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre V.R. Botao                       (1991)	|
 *		|_______________________________________________________|
 */
# define	XCMD(A)			(0x4000 | A)

# define	CMD_CPYFIL		XCMD ('c')	/* copy		single file		*/
# define	CMD_DELFIL		XCMD ('d')	/* delete	single file		*/
# define	CMD_EDTMNU		XCMD ('e')	/* edit		menu ...        */
# define	CMD_LNKFIL		XCMD ('l')	/* link		single file		*/
# define	CMD_MOVFIL		XCMD ('m')	/* move		single file		*/
# define	CMD_TOUFIL		XCMD ('n')	/* touch	single file		*/
# define	CMD_PRTFIL		XCMD ('p')	/* print	single file		*/
# define	CMD_RENFIL		XCMD ('r')	/* rename	single file		*/
# define	CMD_SECFIL		XCMD ('s')	/* protect	single file		*/
# define	CMD_TAGFIL		XCMD ('t')	/* tag		single file		*/
# define	CMD_UNTFIL		XCMD ('u')	/* untag	single file		*/
# define	CMD_VUEFIL		XCMD ('v')	/* view		single file		*/
# define	CMD_EXEFIL		XCMD ('x')	/* execute	single file		*/

# define	CMD_CPYTAG		XCMD ('C')	/* copy		tagged files	*/
# define	CMD_DELTAG		XCMD ('D')	/* delete	tagged files	*/
# define	CMD_INVMNU		XCMD ('I')	/* invert menu ...          */
# define	CMD_LNKTAG		XCMD ('L')	/* link		tagged files	*/
# define	CMD_MOVTAG		XCMD ('M')	/* move		tagged files	*/
# define	CMD_TOUTAG		XCMD ('N')	/* touch	tagged files	*/
# define	CMD_PRTTAG		XCMD ('P')	/* print	tagged files	*/
# define	CMD_RENTAG		XCMD ('R')	/* rename	tagged files	*/
# define	CMD_SECTAG		XCMD ('S')	/* protect	tagged files	*/
# define	CMD_TAGTAG		XCMD ('T')	/* tag		tagged files	*/
# define	CMD_UNTTAG		XCMD ('U')	/* untag	tagged files	*/
# define	CMD_VUETAG		XCMD ('V')	/* view		tagged files	*/
# define	CMD_EXETAG		XCMD ('X')	/* execute	tagged files	*/
# define	CMD_TXSTAG		XCMD ('Y')	/* search	tagged files	*/

# define	CMD_DELDIR		XCMD (300)	/* delete	directory		*/
# define	CMD_MAKDIR		XCMD (301)	/* make		directory		*/
# define	CMD_RENDIR		XCMD (302)	/* rename	directory		*/
# define	CMD_CMPDIR		XCMD (303)	/* compare	directory		*/
# define	CMD_MOVDIR		XCMD (304)	/* graft	directory		*/
# define	CMD_SECDIR		XCMD (305)	/* protect	directory		*/
# define	CMD_ZAPDIR		XCMD (306)	/* prune	directory		*/

# define	CMD_FINFIL		XCMD (400)	/* find file's dir			*/
# define	CMD_LOGMNU		XCMD (401)	/* log menu ...				*/
# define	CMD_ORDMNU		XCMD (402)	/* sort menu ...			*/
# define	CMD_FAMRXP		XCMD (403)	/* family (reg. expr.)		*/
# define	CMD_GLOBAL		XCMD (404)	/* global files window		*/
# define	CMD_FDSTAT		XCMD (405)	/* file display status menu	*/
# define	CMD_QUITOS		XCMD (406)	/* quit to oper. sys.		*/
# define	CMD_XSHELL		XCMD (407)	/* escape to shell ...		*/
# define	CMD_SWTREE		XCMD (408)	/* switch 2 other tree ...	*/
# define	CMD_SWTREB		XCMD (409)	/* idem, backwards ...		*/

# define	CMD_FILWIN		XCMD (420)	/* enter file window ...	*/
# define	CMD_BIGWIN		XCMD (421)	/* expand file window ...	*/
# define	CMD_TREWIN		XCMD (422)	/* return to tree window	*/

# define	CMD_LOGDIR		XCMD (501)	/* log files only			*/
# define	CMD_LOGTRE		XCMD (502)	/* log subtree (dirs also)	*/
# define	CMD_LOGDOS		XCMD (503)	/* log dos disk				*/
# define	CMD_LOGZIP		XCMD (504)	/* log zip file				*/
# define	CMD_LOGCWD		XCMD (505)	/* log curr working dir		*/
# define	CMD_LOGCWT		XCMD (506)	/* log curr working tree	*/

# define	CMD_TEDFIL		XCMD (801)	/* text edit file			*/
# define	CMD_BEDFIL		XCMD (802)	/* binary edit file			*/

# define	CMD_INVTAG		XCMD (811)	/* invert tags ...		    */
# define	CMD_INVFAM		XCMD (812)	/* invert family ...		*/

# define	CMD_VUEMNU		XCMD (820)	/* vue file mnu ...			*/
# define	CMD_BEDVUE		XCMD (821)	/* hex vuer ...				*/
# define	CMD_ASCVUE		XCMD (822)	/* ascii vuer ...			*/

# define	CMD_SELFIL		XCMD (830)	/* select (flip tag, untag)	*/
# define	CMD_SELALL		XCMD (831)	/* curr file & all files	*/

# define	CMD_ORDCUR		XCMD (840)	/* sort current dir ...		*/
# define	CMD_ORDALL		XCMD (841)	/* sort all dirs ...		*/

# define	CMD_SWFRAM		XCMD (901)	/* switch frame style ...	*/
# define	CMD_FLPBNJ		XCMD (902)	/* flip big name justify	*/

/*
 * vi:tabstop=4
 */
