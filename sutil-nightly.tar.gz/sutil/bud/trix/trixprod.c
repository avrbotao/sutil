
/*
 *			|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *			|	PRODESCR :	PROduct's Description, Environment,		|
 *			|				Security & Customer Record				|
 *			|_______________________________________________________|
 */

# ifdef AIX
# define        TLOC        time_t
# else
# define        TLOC        long
# endif

# define	PDSIGNAT	"@$#!&~^%+*"
# define	PDRNDSIZ	600

struct prodescr {
	BYT pd_niknam [ 20] ;		/* small name 4 small windows		*/
	BYT pd_hwname [ 30] ;		/* computer manufacturer & model	*/
	BYT pd_hwsrno [ 12] ;		/* computer (h/w) serial number		*/
	BYT pd_mputyp [ 12] ;		/* mpu type (386, 68k, risc, ...)	*/
	BYT pd_hopsys [ 30] ;		/* operating system name & version	*/
	BYT pd_hosrno [ 12] ;		/* operating system serial number	*/
	BYT pd_siteid [ 20] ;		/* net node or site name ...		*/
	BYT pd_adinfo [ 70] ;		/* aditional information, comments	*/
	BYT pd_filsec [632] ;		/* stuff to fill 1024 bytes			*/
	BYT pd_bignam [ 70] ;		/* customer's full name				*/
	BYT pd_prodid [ 40] ;		/* product name & version ...		*/
	BYT pd_swsrno [ 12] ;		/* product (s/w) serial number		*/
	BYT pd_signat [ 12] ;		/* record signature : "@$#!&~^%+*"	*/
	BYT pd_acqdat [ 12] ;		/* acquisition date or demo start	*/
	BYT pd_expdat [ 12] ;		/* demo expiration date				*/
	BYT pd_execnt [ 12] ;		/* execution count in ascii octal	*/
	BYT pd_xflags [ 16] ;		/* 15 general control flags			*/
} ;

typedef		struct prodescr		PRODESCR ;

# define	PDRECSIZ			( sizeof ( PRODESCR ) )

void	prodcrap	OF ( ( BYT * , int ) ) ;
void	initseal	OF ( ( void ) ) ;
int		initprod	OF ( ( char * , PRODESCR * ) ) ;
int		prodchk		OF ( ( PRODESCR * ) ) ;
long	datol		OF ( ( int , int , int , int , int , int ) ) ;

# ifndef	PRODFOPEN
# define	PRODFOPEN			fopen
# endif		/* PRODFOPEN */

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	read, decypher, inspect, & validate prodescr ...		|
 *		|___________________________________________________________|
 */

int initprod (np, xp) char * np ; PRODESCR * xp ; {

	FILE * pfp ;

	if ( (pfp = PRODFOPEN (np, "rb")) == (FILE *) 0 )
		return -1 ;

	if ( fread ( (char *) xp, 1, PDRECSIZ, pfp ) != PDRECSIZ ) {
		fclose (pfp) ;
		return -1 ;
	}

	fclose (pfp) ;

	prodcrap ( (BYT *) xp , PDRECSIZ ) ;

	return prodchk (xp) ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	validate control flags ...	|
 *									|_______________________________|
 */

int prodchk (xp) PRODESCR * xp ; {
	int py, pm, pd, nd, nm, ny ;
	TLOC tloc, tnow, tpro ;
	struct tm * tp ;
	char * wp ;
	char exdbuf [20] ;

	if ( strchr ( (char *) xp->pd_xflags, 't') != (char *) 0 ) {
		time (&tloc) ;
		tp = localtime (&tloc) ;
		strcpy (exdbuf, (char *) xp->pd_expdat) ;
		if ( ( wp = strchr (exdbuf, '/') ) != (char *) 0 )
			*wp = ' ' ;
		if ( ( wp = strchr (exdbuf, '/') ) != (char *) 0 )
			*wp = ' ' ;
		if (sscanf (exdbuf, "%d %d %d", &pd, &pm, &py) != 3)
			return -3 ;
		nd = tp->tm_mday ;
		nm = (tp->tm_mon) + 1 ;
		ny = tp->tm_year ;
		tnow = datol (nd, nm, ny, 0, 0, 0) ;
		tpro = datol (pd, pm, py, 0, 0, 0) ;
		if (tnow > tpro)
			return -4 ;
	}
	return 0 ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	date to long-ix style ...	|
 *									|_______________________________|
 */

long datol (da, mo, yr, ho, mi, se) int da, mo, yr, ho, mi, se ; {

	char		buf [40] ;	/* AAMMDDHHMM:SS */
	/* struct tm	tmbuf ; */
	struct tm *	t = NULL /* &tmbuf */ ;
	long		tempo;
/*	long *		tp;	*/
	char		strloc[3];
	char *		str, * p;
	long		numanos, bissexto, n29fev;
	long		fuso = 3 * 60 * 60;
	register	int			i,j;

	static		short	ndiasmes [] =	{
										31, 28, 31, 30, 31, 30,
										31, 31, 30, 31, 30, 31
									} ;
# ifdef COMMENT
	time (&tempo);
	t = localtime (&tempo);
# endif /* COMMENT */

	t = (struct tm *) malloc ( sizeof ( struct tm ) ) ;

	if ( t == NULL )
		return -9 ;

	sprintf (buf, "%02d%02d%02d%02d%02d:%02d",
					yr, mo, da, ho, mi, se) ;
	t->tm_sec = 0;

	for (i = 0, p = buf ; *p != '\0' ; i++, p++) {
		if (isdigit ((int)(*p)))
			continue;
		if ((*p == ':') || (*p == '.')) {
			t->tm_sec = atoi (++p);
			if (t->tm_sec > 59)
				return (-1) ;
			p--;
			break;
		}
		return (-1) ;
	}
	if ((i % 2) != 0)
		return (-1) ;
	p--;
	strloc[2] = '\0';
	j = 0;

	while (i >= 2) {
		str = &strloc[1];
		*str-- = *p--;
		*str   = *p--;

		switch (j) {
			case 0:	t->tm_min = atoi (str);
				if (t->tm_min > 59)
					return (-1) ;
				break;

			case 1:	t->tm_hour = atoi (str);
				if (t->tm_hour > 23)
					return (-1) ;
				break;

			case 2:	t->tm_mday = atoi (str);
				if (t->tm_mday > 31)
					return (-1) ;
				break;

			case 3:	t->tm_mon = atoi (str) - 1;
				if (t->tm_mon > 11)
					return (-1) ;
				break;

			case 4:	t->tm_year = atoi (str);
				if ((t->tm_year > 37) && (t->tm_year < 70))
					return (-1) ;
				break;

			default: return (-1) ;
		}
		i -= 2;
		j++;
	}
	numanos = t->tm_year - 70;
	if (numanos < 0)
		numanos += 100;
	if (((numanos + 2) % 4) == 0)
		bissexto = 1;
	else
		bissexto = 0;
	if (t->tm_mday > ndiasmes[t->tm_mon])
		if ((t->tm_mon  !=  1) ||
		    (t->tm_mday != 29) ||
		    (bissexto   !=  1))
				return (-1) ;
	n29fev = (numanos + 1) / 4;
	tempo = (numanos * 365 + n29fev);
	t->tm_yday = (int) tempo;

	for (i = 0; i < t->tm_mon; i++) {
		tempo += ndiasmes[i];
		if (i == 1)
			tempo += bissexto;
	}
	tempo += t->tm_mday - 1;
	t->tm_yday = (int) tempo - t->tm_yday;
	t->tm_wday = ((int) tempo + 4) % 7;
	tempo = ((tempo * 24) + t->tm_hour) * 60;
	tempo = (tempo + t->tm_min) * 60 + t->tm_sec;
	tempo += fuso;
	/* printf ("%s", asctime (t)); */
	free (t) ;
	return (tempo) ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	jumble some bits a bit ...	|
 *									|_______________________________|
 */

# define	Z1(X)		(X ^ 0xaa)
# define	Z2(X)		(X ^ 0x95)
# define	Z3(X)		(X ^ 0xac)
# define	Z4(X)		(X ^ 0xa5)
# define	Z5(X)		(X ^ 0x9a)
# define	Z6(X)		(X ^ 0xc5)
# define	Z7(X)		(X ^ 0xa9)
# define	Z8(X)		(X ^ 0xca)

void prodcrap (buf, cnt) BYT * buf ; int cnt ; {

	static BYT zest [] = {
		Z1('X'),Z2('M'),Z3('a'),Z4('y'),Z5('n'),Z6('o'),Z7('u'),Z8('P'),
		Z1('a'),Z2('a'),Z3('e'),Z4('K'),Z5('d'),Z6('r'),Z7('e'),Z8('a'),
		Z1('n'),Z2('t'),Z3('l'),Z4('f'),Z5('r'),Z6('R'),Z7('s'),Z8('z'),
		Z1('d'),Z2('h'),Z3('V'),Z4('A'),Z5('e'),Z6('o'),Z7('B'),Z8('W'),
		Z1('i'),Z2('e'),Z3('a'),Z4('l'),Z5('V'),Z6('d'),Z7('o'),Z8('a'),
		Z1('n'),Z2('u'),Z3('l'),Z4('e'),Z5('i'),Z6('r'),Z7('t'),Z8('t'),
		Z1('h'),Z2('s'),Z3('e'),Z4('x'),Z5('c'),Z6('i'),Z7('a'),Z8('e'),
		Z1('o'),Z2('J'),Z3('Q'),Z4('a'),Z5('t'),Z6('g'),Z7('o'),Z8('r')
	} ;

	register BYT * bp = buf ;
	register BYT * zp = zest ;
	register int	bk = 0 ;
	register int	zk = 0 ;

	for ( ; bk < cnt ; ++bk , ++zk , ++bp , ++zp ) {
		if (zk > 63) {
			zk = 0 ;
			zp = zest ;
		}
		*bp ^= /* ~ */ *zp ;
	}
}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/*
 * vi:nu tabstop=4
 */
