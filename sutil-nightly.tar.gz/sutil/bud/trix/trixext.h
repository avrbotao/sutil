
/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixext.h + some useful external declarations  ...	|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

EXT	int			errno			;
EXT	int			xerrno			;
EXT	int			xtabsiz			;

# ifdef ANYX

EXT	USHORT		realuid			;
EXT	USHORT		realgid			;
EXT	USHORT		effuid			;
EXT	USHORT		effgid			;

# endif /* ANYX */

EXT char		tmpbuf [ ]		;
EXT	char *		rgxpat			;
EXT	TOPDAT *	gtop			;
EXT	DIRDAT *	groot			;
EXT	DIRDAT *	gpan			;

# ifdef XTRC

EXT FILE *      trcfp ;

# endif /* XTRC */

/*________________________________________________________________*/

/*
 * vi:tabstop=4
 */
