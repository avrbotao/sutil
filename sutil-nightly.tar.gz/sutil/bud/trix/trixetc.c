/************************************************************************
*	trixetc.c + extra stuff 4 trix ...									*
************************************************************************/

# include	<stdio.h>
# include	<string.h>
# include	<signal.h>
# include	<math.h>
# include   <time.h>

# include	<stdlib.h>

# ifdef		DOS

/*	# include	<bios.h>	*/

# include	<ctype.h>
# include	<conio.h>
# include	<dir.h>

# include	<io.h>

# else		/* ! DOS (ANYX,...) */

# include   <unistd.h>

# endif		/* DOS */

# include	"trixasci.h"
# include	"trixaloc.h"
# include	"trix.h"
# include	"trixkeys.h"
# include	"trixchrs.h"
# include	"trixblue.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixwind.h"
# include	"trixterm.h"

EXT		int				( * filcmp ) () ;
EXT		int				xfmb , vdotyp ;
EXT     char            altgcs [] ;
EXT     char            gtfpn  [] ;
EXT		char *			currwd ;

# ifdef		ANYX

EXT		int				tfd ;
EXT		char *			blbuf ;
EXT		char *			cibuf ;
EXT		char *			cvbuf ;
EXT		char *			clbuf ;
EXT		char * *		efon [ ] ;
EXT		char * *		efof [ ] ;
EXT		CAPCTL			capbuf [ ] ;

# endif		/* ANYX */

# ifdef AIX
# define        TLOC        time_t
# else
# define        TLOC        long
# endif

extern	char	trixworkpath [] ;
extern	int		fastworkflag ;

/*__________________________________________________________________________
*/

# define	SETKMG(X)	kmg[3] = X ; kmg[4] = '\0' ;

/*
typedef		unsigned long	ULONG ;
*/
typedef		long long	sbit64 ;

char * lltokmgtpe (x) sbit64 x ; {

	static char kmg [128] ;
	static char kc = 'K' , mc = 'M' , gc = 'G' , sc = ' ' ;
	static char tc = 'T' , pc = 'P' , ec = 'E' ;
	double bval, kval, mval, gval ;
	double       tval, pval, eval ;

	bval = x ;

	if (bval < 1000) {
		sprintf (kmg, "%3d", (int) bval) ; SETKMG(sc) ;
		return kmg ;
	}

	kval = bval / 1024.0 ;

	if ( kval < 10.0 ) {
		sprintf (kmg, "%11.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	if ( kval < 1000.0 ) {
		sprintf (kmg, "%13.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	mval = bval / 1048576.0 ;

	if ( mval < 10.0 ) {
		sprintf (kmg, "%11.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	if ( mval < 1000.0 ) {
		sprintf (kmg, "%13.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	gval = bval / 1073741824.0 ;

	if ( gval < 10.0 ) {
		sprintf (kmg, "%11.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	if ( gval < 1000.0 ) {
		sprintf (kmg, "%13.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	tval = bval / 1099511627776.0 ;

	if ( tval < 10.0 ) {
		sprintf (kmg, "%11.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	if ( tval < 1000.0 ) {
		sprintf (kmg, "%13.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	pval = bval / 1125899906842624.0 ;

	if ( pval < 10.0 ) {
		sprintf (kmg, "%11.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	if ( pval < 1000.0 ) {
		sprintf (kmg, "%13.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	eval = bval / 1152921504606846976.0 ;

	if ( eval < 10.0 ) {
		sprintf (kmg, "%11.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	if ( eval < 1000.0 ) {
		sprintf (kmg, "%13.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	return "????" ;
}

/************************************************************************
*																		*
*	listree + walk & fancy list ...										*
*																		*
*	+ some important point is : b4 descend on a (next) level, to		*
*	  leave set the "trackbone" of the current level (which has			*
*	  only 2 possible statuses : more brother dirs to come ahead,		*
*	  or this is the last entry of the current "parent" dir ...)		*
*																		*
*	+ this must b resolved pretty early (soon) 'cause it defines		*
*	  also the (graphic) prefix of the current entry					*
*																		*
************************************************************************/

EXT int eflg ;

EXT char glast [] ;				/* "@DD" last		*/
EXT char geach [] ;				/* "CDD" each		*/
EXT char gspac [] ;				/* "   " gap		*/
EXT char gstik [] ;				/* "3  " link		*/
EXT char origwd [] ;

EXT char * * picptr ;
EXT DIRDAT * * wabptr ;

void listree (dp) DIRDAT * dp ; {

	REG DIRDAT * * tdpp = dp->dd_dil ;
	REG int dk ;
	REG int ns ;
	REG char * xp ;
	REG char * gwhat ;
	FIX int depth = 0 ;
	FIX char gbuf [ 400 ] = { NUL } ;
	NEW char gtmp [ 400 ] /* = { NUL } */ ;

# ifdef		ANYX

	REG int ghl ;

    if (vdotyp == 't')
# ifdef TREEDRAWW
		ghl = 0 ;
# else  /* OLDTREEDRAW */
        ghl = strlen (*(efon[VEAGCS])) + strlen (*(efof[VEAGCS])) ;
# endif /* TREEDRAWW */
    else
        ghl = 0 ;

# endif		/* ANYX */

	if (ghl < 0) {
		return ;
	}

# ifdef XTRC
	if ( dp == VZRO(DIRDAT *) )
		fprintf (trcfp, "listree(NULL)\r\n") ;
	else
		fprintf (trcfp, "listree(%s)\r\n", dp->dd_path) ;
# endif

	if (dp->dd_dik > 1)
		qsort ( (char *) tdpp, (int)(dp->dd_dik),
				sizeof (DIRDAT *), dilcmp ) ;

	if (dp->dd_fik > 0)
		inimfl (dp) ;		/* (perhaps re) aloc & fil match lst	*/

	if (dp->dd_mfk > 1) {
		qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
				sizeof (FILDAT *), filcmp) ;
	}

	*wabptr++ = dp ;	/* fill up walk about list ...			*/

	for ( dk = 0 ; dk < dp->dd_dik ; ++dk, ++tdpp ) {

# ifdef		DOS

		*(gbuf+(depth*GTPLEN)) = NUL ;

# else		/* ANYX */

        if (vdotyp == 't')
# ifdef TREEDRAWW
    		*(gbuf+(depth*GTPLEN)) = NUL ;
# else  /* OLD */
    		*(gbuf+(depth*(GTPLEN+ghl))) = NUL ;
# endif /* TREEDRAWW */
        else
    		*(gbuf+(depth*GTPLEN)) = NUL ;

# endif		/* DOS */

		*gtmp = NUL ;

		if (*gbuf)
			strcpy (gtmp, gbuf) ;

# ifdef		DOS

		if ( (dp->dd_dik - dk) == 1 ) {
			strcat (gbuf, gspac) ;
			xp = glast ;
		} else {
			strcat (gbuf, gstik) ;
			xp = geach ;
		}

# else		/* ANYX */

        if (vdotyp == 't') {
# ifdef TREEDRAWW
    		if ( (dp->dd_dik - dk) == 1 ) {
    			strcat (gbuf, gspac) ;
    			xp = glast ;
    		} else {
    			strcat (gbuf, gstik) ;
    			xp = geach ;
    		}
# else  /* OLD */
    		if ( (dp->dd_dik - dk) == 1 ) {
    			strcat (gbuf, *(efon[VEAGCS])) ;
    			strcat (gbuf, gspac) ;
    			strcat (gbuf, *(efof[VEAGCS])) ;
    			xp = glast ;
    		} else {
    			strcat (gbuf, *(efon[VEAGCS])) ;
    			strcat (gbuf, gstik) ;
    			strcat (gbuf, *(efof[VEAGCS])) ;
    			xp = geach ;
    		}
# endif /* TREEDRAWW */
        } else {
    		if ( (dp->dd_dik - dk) == 1 ) {
    			strcat (gbuf, gspac) ;
    			xp = glast ;
    		} else {
    			strcat (gbuf, gstik) ;
    			xp = geach ;
    		}
        }

# endif		/* DOS */

# ifdef		DOS

		strcat (gtmp, xp) ;

# else		/* ANYX */

        if (vdotyp == 't') {
# ifdef TREEDRAWW
    		strcat (gtmp, xp) ;
# else  /* OLD */
    		strcat (gtmp, *(efon[VEAGCS])) ;
    		strcat (gtmp, xp) ;
    		strcat (gtmp, *(efof[VEAGCS])) ;
# endif /* TREEDRAWW */
        } else {
    		strcat (gtmp, xp) ;
        }

# endif		/* DOS */

# ifdef COMMENT /* DON'T RELEASE 'TILL SEVERE DEBUGGING ! */
		if (*picptr != (char *) 0)
			free (*picptr) ;
# endif /* COMMENT */

		strcat (gtmp, (*tdpp)->dd_nam) ;

		ns = 1 + strlen (gtmp) ;

		if (NALLOC (gwhat, ns))
			trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;

		strcpy (gwhat, gtmp) ;

		*picptr++ = gwhat ;

		++depth ;
		listree (*tdpp) ;
		--depth ;

	} /* endof (dil scan) */

} /* endof listree */

/************************************************************************
*	isdir																*
************************************************************************/

char * isdir (nam, stap) char * nam ; STABLK * stap ; {
	FIX char fulnam [MAXPATHLEN] ;
# ifdef DOS
	REG int xcurdsk, namdsk, samdsk = TRUE ;
# endif /* DOS */

	strcpy (fulnam, nam) ;

	if (trixcd (currwd) == -1) {
		trixerr (T_XWDERR, currwd, errno, BANAL) ;
		goto badir ;
	}

# ifdef   DOS

	if (*(nam+1) == ':') {
		if (*(nam+2) == '\0')
			goto goodir ;
		xcurdsk = getdisk () ; namdsk = toupper (*nam) - 'A' ;
		samdsk = (xcurdsk == namdsk) ;
		if (access (nam, 0) == 0)
			goto gs ;
		trixerr (T_ACCESS, nam, errno, BANAL) ;
		goto badir ;
	}
gs :
	if ( findfirst (nam, stap, FA_BOTH) == -1 ) {
		if (access (nam, 0) == 0)
			goto gn ; /* return fulnam ; */
		trixerr (T_NOINFO, nam, errno, BANAL) ;
		goto badir ;
	}
	if ( ! ( stap->ff_attrib & FA_DIREC ) ) {
		trixerr (T_NOTADIR, nam, -1, BANAL) ;
		goto badir ;
	}
gn :
	if (! samdsk)
		setdisk (namdsk) ;
	if (trixcd (nam) == -1) {
		if (access (nam, 0) == 0)
			goto goodir ;
		trixerr (T_XWDERR, nam, errno, BANAL) ;
		goto badir ;
	}
	if (getcwd (fulnam, MAXPATHLEN) == NOSTR) {
		trixerr (T_EGETCWD, nam, errno, BANAL) ;
		goto badir ;
	}

# else    /* ANYX */

	if (STAT (nam, stap) == -1) {
		trixerr (T_NOINFO, nam, errno, BANAL) ;
		goto badir ;
	}
	if ( ! ( (stap->st_mode & S_IFMT) == S_IFDIR ) ) {
		trixerr (T_NOTADIR, nam, -1, BANAL) ;
		goto badir ;
	}
	if (trixcd (nam) == -1) {
		trixerr (T_XWDERR, nam, errno, BANAL) ;
		goto badir ;
	}
	if (getcwd (fulnam, MAXPATHLEN) == NOSTR) {
		trixerr (T_EGETCWD, nam, errno, BANAL) ;
		goto badir ;
	}

# endif   /* DOS, ANYX */

# ifdef DOS
goodir :
	if (! samdsk)
		setdisk (xcurdsk) ;
# endif /* DOS */
	trixcd (origwd) ;
	return fulnam ;
badir :
# ifdef DOS
	if (! samdsk)
		setdisk (xcurdsk) ;
# endif /* DOS */
	trixcd (origwd) ;
	return NOSTR ;
}
# ifdef COMMENT
/************************************************************************
*																		*
************************************************************************/
void erasecho (x) {

	while (x--) {
# ifdef DOS
		putch ('\b') ;
		putch (' ') ;
		putch ('\b') ;
# else  /* ! DOS (ANYX,...) */
		gwrd = write (tfd, "\b \b", 3) ;
# endif /* DOS */
	}
}
# endif /* COMMENT */
/************************************************************************
*																		*
************************************************************************/

# ifdef		TC

void intrap () {

# else		/* ANYX */

SIGHANTYP intrap (sn) int sn ; {

# endif		/* TC */

/*	static char tb [80] ;	*/

	fprintf (stderr, "\r\n") ;
	fprintf (stderr, "******************\r\n") ;
	fprintf (stderr, "*** signal(%02d) ***\r\n", sn) ;
	fprintf (stderr, "******************\r\n") ;

	byechk () ;

	/* MUST RESET / REFRESH ALL SIGNALS !!! */

	signal (SIGINT, intrap) ;
}

/************************************************************************
*																		*
************************************************************************/

void hidecursor () {

# ifdef DOS

	sizecursor (-1, -1) ; /* vga=-1,-1 cga=16,16 ega=?,? */

# else  /* ANYX */

	if (vdotyp == 't')
		gwrd = write (tfd, cibuf, capbuf[CINVIS].caplen) ;
	else
		sizecursor (20, 20) ;

# endif /* DOS */

}

/************************************************************************
*																		*
************************************************************************/

void showcursor () {

# ifdef DOS

	sizecursor (1, 6) ;		/* does it work on vga as well ? ...		*/

# else  /* ANYX */

	if (vdotyp == 't')
		gwrd = write (tfd, cvbuf, capbuf[CVISIB].caplen) ;
	else
		sizecursor (0, 12) ;

# endif /* DOS */

}

/************************************************************************
*	set cursor size														*
************************************************************************/

void sizecursor (x, y) int x, y ; {

# ifdef DOS

	union REGS r ;

	r.h.ah = 1 ;
	r.h.ch = x ;
	r.h.cl = y ;
	int86 (0x10, &r, &r) ;

# else  /* ANYX */

	char tb [40] ;

	sprintf (tb, "\033[=%d;%dC", x, y) ;
	gwrd = write (tfd, tb, strlen (tb)) ;

# endif /* DOS */

}

/*______________________________________________________________________
 |																		|
 |	xltoa + extra-fancy long to ascii conversion ...					|
 |______________________________________________________________________|
 */
char xlabuf [64] = { '+' } ;

char * xltoa (val, wid, flg) long val ; int wid , flg ; {
	static char * bp ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/

	bp = xlabuf + 60 ;
	*bp = '\0' ;

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}
	do {
		if (flg & KPOINTS) {
			if ( (tk % 4) == 0 ) {
				*--bp = '.' ;
				++tk ;
			}
		}
		*--bp = '0' + (char) (val % 10) ;
		++tk ;
		if (tk >= wid)
			break ;
	} while ((val /= 10) > 0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}
	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

# ifdef BIGTRX

/*______________________________________________________________________
 |																		|
 |	xlltoa + extra-fancy longlong to ascii conversion ...				|
 |______________________________________________________________________|
 */

char xllabuf [128] = { '+' } ;

char * xlltoa (val, wid, flg) _INT64_ val ; int wid , flg ; {
	static char * bp ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/

	if ( scaleflag && val > 999999 ) {
		sprintf (xllabuf, "%19s", lltokmgtpe ((long long) val)) ;
		return xllabuf ;
	}

	bp = xllabuf + 124 ;
	*bp = '\0' ;

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}
	do {
		if (flg & KPOINTS) {
			if ( (tk % 4) == 0 ) {
				*--bp = '.' ;
				++tk ;
			}
		}
		*--bp = '0' + (char) (val % 10) ;
		++tk ;
		if (tk >= wid)
			break ;
	} while ((val /= 10) > 0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}
	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

# endif

/*______________________________________________________________________
 |																		|
 |	xdtoa + extra-fancy double to ascii conversion ...					|
 |______________________________________________________________________|
 */
char * xdtoa (val, wid, flg) double val ; int wid , flg ; {
	static char buf [24] = { '+' } ;
	register char * bp = buf + 20 ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/
	double dblten = (double) 10 ;

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}
	do {
		if (flg & KPOINTS) {
			if ( (tk % 4) == 0 ) {
				*--bp = '.' ;
				++tk ;
			}
		}
		*--bp = '0' + (int) fmod (val, dblten) ;
		++tk ;
		if ((tk-1) >= wid)
			break ;
		val /= dblten ;
		if (val < 1000000000.0) {
			if ((long) val <= 0)
				break ;
		}
	} while (val > (double)0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}
	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}
/************************************************************************
*	+ trix + honk (d # of hertz & milisecs must be cfg'abl) ...			*
************************************************************************/
# define  HERTZ
# define  MILISECONDS

void honk () {
# ifdef   DOS
	sound (1000 HERTZ) ;
	delay (50 MILISECONDS) ;
	nosound () ;
# else    /* ANYX */
#	ifdef		CURSES
		beep () ;
#	else		/* PROPRIETARY */
		VPUTS (blbuf) ;
#	endif		/* CURSES */
# endif   /* DOS */
}
/************************************************************************
*																		*
************************************************************************/
void byechk () {
	char tb [80] ;

	/* FIXME: chk config opt */

	sprintf (tb, T_FINISH, OPSYS) ;
	if (askyn (tb, T_RUSURE) == YEAH) {
		epilog () ;
	}
}

# ifdef COMMENT

/*				                     _______________________________
 *									|								|
 *									|	path name dismantler ...	|
 *				                    |_______________________________|
 */

char *	pnd (pn) char *	pn ; {

	static char * pnp = (char *) 0 ;
	static char   buf[512] ;
	static char * bp = buf ;

	if (pnp == (char *) 0)
		pnp = pn ;

	if (*pnp == '\0') {
		pnp = (char *) 0 ;
		bp = buf ;
		return (pnp) ;
	}

	if ((pnp == pn) && (*pnp == '/')) {
		*bp++ = *pnp++ ;
	} else {
		if (*pnp == '/')
			*bp++ = *pnp++ ;
		while (*pnp && *pnp != '/')
			*bp++ = *pnp++ ;
	}

	*bp = '\0' ;
	return (buf) ;
}

# endif /* COMMENT */

/*
 *      |-----------------------------------------------------------|
 *      |	+ trixdm : display unix mode bits ...                   |
 *      |-----------------------------------------------------------|
 */
# ifdef ANYX

# ifdef NOBULL
char *	bitv = " ugtrwxrwxrwx " ;
char *	mbit = "              " ;
# else  /* BULLSHIT */
char bitv [16] = " ugtrwxrwxrwx " ;
char mbit [16] = "              " ;
# endif

# define    MODE    mode
# define    MBIT    (010000)

char * trixdm (mode) unsigned mode ; {
	register int i ;

# ifdef XTRC
	fprintf (trcfp, "trixdm(%lo)\r\n", mode) ;
# endif

	switch (MODE & S_IFMT) {
		case S_IFREG: *mbit = 'f' ; break ;
		case S_IFDIR: *mbit = 'd' ; break ;
		case S_IFCHR: *mbit = 'c' ; break ;
		case S_IFBLK: *mbit = 'b' ; break ;
		case S_IFIFO: *mbit = 'p' ; break ;
		default:      *mbit = '?' ; break ;
	}

	for ( i = 1 ; i < 13 ; i++ )
		*(mbit + i) = ((MODE & (MBIT >> i)) ? (*(bitv + i)) : '-') ;

	return mbit ;
}

# else  /* DOS, NETWARE, ... */

char * trixdm (mode) unsigned mode ; {
	static char bitv [20] ;

	strcpy (bitv, "-----") ;

	if (mode & FA_DIREC)
		bitv[0] = 'd' ;
	if (mode & FA_ARCH)
		bitv[1] = 'a' ;
	if (mode & FA_RDONLY)
		bitv[2] = 'r' ;
	if (mode & FA_SYSTEM)
		bitv[3] = 's' ;
	if (mode & FA_HIDDEN)
		bitv[4] = 'h' ;
	return bitv ;
}

# endif /* ANYX */
/*
 *      |-----------------------------------------------------------|
 *      |	+ trixtm : display time stamp ...                       |
 *      |-----------------------------------------------------------|
 */
char txtim [20] ;

# ifdef ANYX

char * trixtm (t) long t ; {
    struct tm * tp ;
    TLOC tloc = t ;

    tp = localtime (&tloc) ;
	sprintf (txtim, "%02d/%02d/%02d %02d:%02d",
            tp->tm_mday, tp->tm_mon+1, tp->tm_year,
            tp->tm_hour, tp->tm_min) ;

	return txtim ;
}

# else  /* DOS, NETWARE, ... */

char * trixtm (d, t) unsigned d, t ; {

	sprintf (txtim, "%02d/%02d/%02d %02d:%02d",
		(  (d)        & 0x1f ) ,
		( ((d) >>  5) & 0x0f ) ,
		( ((d) >>  9) & 0x7f ) + 80 ,
		( ((t) >> 11) & 0x1f ) ,
		( ((t) >>  5) & 0x3f )
	) ;

	return txtim ;
}

# endif /* ANYX */
/*======================================================================*
 *	+ ...																*
 *======================================================================*/
# ifdef COMMENT
int strank (buf) char * buf ; {
	REG char * * sp = &buf ;
	REG char *   bp = buf ;
	REG char *   tp ;

	for ( ++sp ; *sp ; ++sp )
		for ( tp = *sp ; *tp ; *bp++ = *tp++ )
			;
	*bp = NUL ;
	return (bp - buf) ;
}
# endif /* COMMENT */
/************************************************************************
*																		*
************************************************************************/
void strpad (bp, tp, nb) char * bp , * tp ; int nb ; {

	if (tp != NOSTR)
		while (*tp) {
			*bp++ = *tp++ ;
			--nb ;
		}

	while (nb > 0) {
		*bp++ = ' ' /* C_GSPC */ ;
		--nb ;
	}

	*bp = '\0' ;
}
/*      |-------------------------------------------------------|
 *      |   ...                                                 |
 *      |-------------------------------------------------------|
 */
EXT char * trixpath ;

FILE * trixfopen (nam, mod) char * nam , * mod ; {
    REG int i ;
    REG FILE * fp ;
    REG char * tp ;
    FIX char * datpath [] = {
		NOSTR,              /*	0	getenv (SWENVAR)			*/
        NOSTR,              /*	1	T_TRIXPATH					*/
        "\\trix",           /*	2	dos, net, ...				*/
        "/usr/trix",		/* 3							*/
        "/usr/lib/trix"		/* 4							*/,
        NOSTR,              /*	5	next + "/.trix"				*/
        NOSTR,              /*	6	getenv ("HOME")				*/
		"./"				/* 7							*/,
		".\\"				/* 8							*/,
        "/usr/local/trix"	/* 9							*/,
		"@"					/* A							*/,
    } ;
	FIX int  dpcnt = 0 ;
    NEW char tb [80] ;

# ifdef ANYX

    NEW int perm ;

    if (*mod == 'r')
        perm = R_OK ;
    else
        perm = W_OK ;

# endif /* ANYX */

# ifdef XTRC
	fprintf (trcfp, "trixfopen(%s,%s)\r\n", nam,mod) ;
# endif

    if (dpcnt == 0) {

		tp = getenv (SWENVAR) ;

		if (tp == NOSTR) {
# ifdef COMMENT
			fprintf (stderr, "%s: variavel %s nao definida !\r\n",
					SWID, SWENVAR) ;
			return VZRO (FILE *) /* (FILE *) 0 */ ;
# endif
			tp = getcwd ( trixworkpath , 4096 ) ;
			++fastworkflag ;
		}

        dpcnt = 11 ;
		datpath[0] = tp ;
        datpath[6] = getenv ("HOME") ;

		if (datpath[6] != NOSTR) {
			datpath[5] = malloc (80) ;
			strcpy (datpath[5], datpath[6]) ;
			strcat (datpath[5], "/.trix") ;
		}
    }
    datpath[1] = trixpath ; fp = (FILE *) 0 ;

    for ( i = 0 ; i < dpcnt ; ++i ) {
        tp = datpath[i] ;

		if (tp == NOSTR)
			continue ;

		if (*tp == '@')
			break ;

# ifdef DOS
		sprintf (tb, "%s\\%s", tp, nam) ;
# else  /* ANYX */
		sprintf (tb, "%s/%s", tp, nam) ;
# endif /* DOS */

# ifdef XTRC
		fprintf (trcfp, "<<< try(%s) ...\r\n", tb) ;
# endif

# ifdef ANYX

        if (access (tb, perm) < 0)
            if (perm == R_OK)
                continue ;

# endif /* ANYX */

        if ( ( fp = fopen ( tb , mod ) ) != (FILE *) 0 ) {
            strcpy (gtfpn, tb) ;
			return fp ;
        }
    }
	return VZRO (FILE *) /* (FILE *) 0 */ ;
}
/*      |-------------------------------------------------------|
 *      |   ...                                                 |
 *      |-------------------------------------------------------|
 */
void epilog ( ) {
	EXT char * xwhy ;
# ifdef COMMENT
	EXT int Tflg ;
# endif /* COMMENT */
						/* should we clear screen ? ...	*/
	endhist () ;        /* update history data ...      */
	endhelp () ;

# ifdef COMMENT
    /* ... call other END* updating procedures ...      */
    /*
     *  if ( config-clearscreen-on-end )
     *      clrscr
     *  else
	 */     locat (23, 0) ;

	if (Tflg)
		CLRSCR ;
# endif /* COMMENT */

	wwend () ;

	reseterm () ;

	if (xwhy != NOSTR)
		fprintf (stderr, "\n%s\n\n", xwhy) ;

# ifdef XTRC
	fprintf (trcfp, "\r\n%s\r\n\r\n", xwhy) ;
    fflush (trcfp) ;
	fclose (trcfp) ;
# endif /* XTRC */

	exit (0) ;
}
/*
 *	|---------------------------------------------------------------|
 *	|   trixetc/tabexp() : buf-2-buf tab-2-space expansion !		|
 *  |---------------------------------------------------------------|
 */
void tabexp (expbuf, tabuf, tabwid) char * expbuf , * tabuf ; int tabwid ; {
	register char * lp = tabuf ;
	register int tk = 0 ;
	register char * bp = expbuf ;

	do {
		if (*lp != '\t') {
			if (++tk >= tabwid)
				tk = 0 ;
			*bp = *lp ;
		} else {
			while (tk++ < tabwid)
				*bp++ = /* C_GSPC */ ' ' ;
			tk = 0 ; --bp ;
		}
		++lp ;
	} while (*bp++ != '\0') ;
}
/*
 *	|---------------------------------------------------------------|
 *	|	...															|
 *  |---------------------------------------------------------------|
 */
long strcod (s) char * s ; {
	register unsigned char * p = (unsigned char *) s ;
	register long r = 0 ;
	register int i = 1 ;

	while (*p) {
		r += *p++ * i++ ;
	}
	return r ;
}
/*
 *	|---------------------------------------------------------------|
 *	|	...															|
 *  |---------------------------------------------------------------|
 */
void strend (b, m) char * b , * m ; {
	REG char * p ;

	p = strpbrk (b, m) ;

	if (p != NOSTR)
		*p = '\0' ;
}
/*	        		 _______________________________________________
 *	    	    	|												|
 *		    	    |	portably get file or directory status ...	|
 *			        |_______________________________________________|
 */
int xstatus (nam, stap) char * nam ; STABLK * stap ; {

# ifdef XTRC
	fprintf (trcfp, "xstatus(%s,%lx)\r\n", nam, (ULONG) stap) ;
# endif

# ifdef DOS

	if ( findfirst (nam, stap, FA_BOTH) == -1 ) {
		if (access (nam, 0) == 0)
			return 0 ;

# else  /* ANYX */

	if (STAT (nam, stap) == -1) {

# endif /* DOS */

		trixerr (T_NOINFO, nam, errno, BANAL) ;
		return -1 ;
	}

	return 0 ;
}
/*                               ___________________________________
 *	    	    	            |									|
 *		    	                |	safely chg curr wrk'n dir ...	|
 *	            		        |___________________________________|
 */
int trixcd (nam) char * nam ; {

# ifdef XTRC
	fprintf (trcfp, "trixcd(%s)\r\n", nam) ;
# endif

# ifdef ANYX

    if (access (nam, X_OK) < 0)
        return -1 ;

# endif /* ANYX */

    return chdir (nam) ;
}
/*                           _______________________________________
 *	    	    	        |										|
 *		    	            |	check for abort (quit) on log ...	|
 *	            		    |_______________________________________|
 */
void chkquit () {

	int x ;

# ifdef DOS
	x = kbhit () ;
# else
	x = xkbhit () ;
# endif

	if ( x == ESC || x == CTRL_Q ) {
		byechk () ;
	}
}
/********************************************************************/
/*
 * vi:nu tabstop=4
 */
