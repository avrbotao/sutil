
/*
 *	trixkey + keyboard interface ...
 */

# if defined (FREEBSD) || defined (OPENBSD)
#	define		NOFIORK
# include	<termios.h>
# define	termio		termios
# else
# include	<termio.h>
# endif

# include <stdio.h>

# ifdef		SUNX
#	define		NOFIORK
# endif		/* SUNX */

# ifdef		SOLARIS
#	define		NOFIORK
# endif		/* SOLARIS */

# ifdef		CYGWIN
# include <termios.h>
int ioctl () ;
# endif		/* CYGWIN */

# ifdef		LINUX
# define	FIORDCHK		FIONREAD
# endif		/* LINUX */

# ifdef		XENIX
#	define		NOFIORK
# endif		/* XENIX */

# ifdef		AIX
/*	# define	FIORDCHK		FIONREAD	*/
#	define	NOFIORK
# endif		/* AIX */

# ifdef		SIDIX
#	ifdef		COMMENT
#		include	<sys/filio.h>
#		define	FIORDCHK		FIONREAD
#	endif		/* COMMENT */
#	define	NOFIORK
# endif		/* SIDIX */

# ifdef		EDIX
# include	<sys/ioctl.h>
# define	FIORDCHK		FIONREAD
# endif		/* EDIX */

# ifdef		SIX
#	ifdef		COMMENT
#		define	IOC_OUT		0x40000000	/* copy_out parametros */
#		define	IOCPARM_MASK	0x7f		/* parametros devem ser < que 128 bytes */
#		define	_IOR(x,y,t)	(IOC_OUT|((sizeof(t)&IOCPARM_MASK)<<16)|('x'<<8)|y)
#		define	FIONREAD	_IOR(f, 127, int)	/* obtem # bytes p/ leitura */
#		define	FIORDCHK		FIONREAD
#	endif		/* COMMENT */
#	define	NOFIORK
# endif		/* SIX */

# ifdef		DIGIX
/*	# define	FIORDCHK		FIONREAD	*/
#	define	NOFIORK
# endif		/* DIGIX */

# ifdef		NOFIORK
#	include		<fcntl.h>
# endif		/* NOFIORK */

# include "trix.h"
# include "trixfunc.h"

EXT int tfd , totkeys ;
EXT KEYINFO keylst [] ;

# ifdef		HPUX
# define	FIORDCHK		FIONREAD
#	include		<fcntl.h>
# endif		/* HPUX */

int trixkey () {

	char b [ 40 ] ;
	KEYINFO k ;
	register int i = 0 ;
	register char * p = b ;
	register int r ;
# ifndef NOFIORK
	int g ;
# endif /* NOFIORK */
	register KEYINFO * x ;
# ifdef		CYGWIN
	int rd ;
# endif		/* CYGWIN */

	r = read (tfd, p+i, 1) ;

	if (r <= 0)
		return -1 ;

	if (*(p+i) == 27) { /* ESC : get more chars ... */

# ifdef NOFIORK

		int fc_ant ;

		fc_ant = fcntl (tfd, F_GETFL, 0) ;
		fcntl (tfd, F_SETFL, fc_ant | O_NDELAY) ;
gmc :
		++i ;
		r = read (tfd, p+i, 1) ;

		if (r == 0) {
			fcntl (tfd, F_SETFL, fc_ant) ; --i ;
			if ( i > 0 ) {
				b[i+1] = '\0' ; k.ki_sig = b ;
				x = (KEYINFO *)
					bsearch ( (void *) & k,
						  (void *) keylst,
						  (size_t) totkeys,
						  (size_t) KI_SIZ,
						  keycmp             ) ;
				if (x == (KEYINFO *) 0)
					return -1 ;
				return x->ki_cod ;
			}
			return *(p+i) ;
		}
		if (r < 0)
			return -1 ;
		goto gmc ;

# else  /* FIORK */

# ifdef HPUX
gmc :		g = ioctl (tfd, FIORDCHK, &g) ;
# else  /* ! HPUX */
#	ifdef CYGWIN
gmc :		rd = ioctl (tfd, TIOCINQ, &g) ;
			if ( rd < 0)
				g = 0 ;
#	else  /* ! CYGWIN */
gmc :		g = ioctl (tfd, FIORDCHK, (char *) 0) ;
#	endif /* CYGWIN */
# endif /* HPUX */
		if (g < 0)
			return -1 ;
		if (g == 0) {
			if ( i > 0 ) {
				b[i+1] = '\0' ; k.ki_sig = b ;
				x = (KEYINFO *)
					bsearch ( (void *) & k,
						  (void *) keylst,
						  (size_t) totkeys,
						  (size_t) KI_SIZ,
						  keycmp             ) ;
				if (x == (KEYINFO *) 0)
					return -1 ;
				return x->ki_cod ;
			}
			return *(p+i) ;
		}
		++i ; r = read (tfd, p+i, 1) ;
		if (r <= 0)
			return -1 ;
		goto gmc ;		/* go get more chars ... */

# endif /* NOFIORK */

	}

	return *(p+i) ;

} /* endof trixkey() */

/*                               ___________________________________
 *	    	    	            |									|
 *		    	                |	portable kbhit sense test ...	|
 *	            		        |___________________________________|
 */

# ifdef CYGWIN
#	include		<fcntl.h>
# endif

# ifdef LINUX
#	include		<fcntl.h>
# endif

int xkbhit () {

	char b [ 40 ] ;
	KEYINFO k ;
	register int i = 0 ;
	register char * p = b ;
	register int r ;
	register KEYINFO * x ;
	int fc_ant ;

	fc_ant = fcntl (tfd, F_GETFL, 0) ;
	fcntl (tfd, F_SETFL, fc_ant | O_NDELAY) ;

	r = read (tfd, p+i, 1) ;

	if (r <= 0) {
		fcntl (tfd, F_SETFL, fc_ant) ;
		return -1 ;
	}

	if (*(p+i) == 27) { /* ESC : get more chars ... */

gmc :
		++i ;
		r = read (tfd, p+i, 1) ;

		if (r == 0) {
			fcntl (tfd, F_SETFL, fc_ant) ; --i ;
			if ( i > 0 ) {
				b[i+1] = '\0' ; k.ki_sig = b ;
				x = (KEYINFO *)
					bsearch ( (void *) & k,
						  (void *) keylst,
						  (size_t) totkeys,
						  (size_t) KI_SIZ,
						  keycmp             ) ;
				if (x == (KEYINFO *) 0)
					return -1 ;
				return x->ki_cod ;
			}
			return *(p+i) ;
		}
		if (r < 0)
			return -1 ;
		goto gmc ;

	}

	return *(p+i) ;

} /* endof xkbhit() */

/*
 * vi:nu tabstop=4
 */
