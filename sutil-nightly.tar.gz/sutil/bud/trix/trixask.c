
/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixask.c + miscellany asking funtions ...			|
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include <stdio.h>
# include <string.h>

#	ifdef	DOS
#		include	<conio.h>
#	endif	/* DOS */

# include "trixasci.h"
# include "trix.h"
# include "trixblue.h"
# include "trixkeys.h"
# include "trixfunc.h"
# include "trixwig.h"
# include "trixterm.h"

EXT		int				xfmb, vdotyp ;
EXT     char *          cebuf ;
EXT     char *          ghyid ;

/************************************************************************
*	+ prompt out & ask 4 yeap or nope or esc or f1 (help)				*
************************************************************************/

int askyn (msg, prompt) char * msg , * prompt ; {
	int whatever ;
	int plen = strlen (prompt) ;

	xfmb = 'y' ;
	frescrn (CLRMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	dispat (_msglin, 0, msg, strlen (msg), VEHILT) ;
	dispat (_msglin+1, 0, prompt, plen, VEHILT) ;
# ifdef DOS
	locat (_msglin+1, plen) ;
# else  /* ANYX */
    if (vdotyp != 't')
    	locat (_msglin+1, plen) ;
# endif /* DOS */
it :
	showcursor () ;
	whatever = getkey () ;
	hidecursor () ;

	switch (whatever) {
		case 's'  :
		case 'S'  :
		case 'y'  :
		case 'Y'  : whatever = YEAH ;  break ;
		case 'n'  :
		case 'N'  : whatever = NOPE ;  break ;
		case '\r' :
		case '\n' : whatever = ENTER ; break ;
		case CTRL_Q :
		case ESC  : break ;
		case '?'  :
		case KF1  : hyxhelp (NOSTR) ; goto it ;
		default   : honk () ; goto it ;
	}
	frescrn (UDMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	return whatever ;
}
/************************************************************************
*	+ prompt out & ask 4 any key or ENTER or esc or f1 (help)			*
************************************************************************/
int askany (msg, prompt) char * msg , * prompt ; {
	int whatever ;
	int plen = strlen (prompt) ;

	xfmb = 'a' ;
	frescrn (CLRMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	dispat (_msglin, 0, msg, strlen (msg), VEHILT) ;
	dispat (_msglin+1, 0, prompt, plen, VEHILT) ;
# ifdef DOS
	locat (_msglin+1, plen) ;
# else  /* ANYX */
    if (vdotyp != 't')
    	locat (_msglin+1, plen) ;
# endif /* DOS */
aa :
	showcursor () ;
	whatever = getkey () ;
	hidecursor () ;
	switch (whatever) {
		case '\r' :
		case '\n' : whatever = ENTER ; break ;
		case CTRL_Q :
		case ESC  : break ;
		case '?'  :
		case KF1  : hyxhelp (NOSTR) ; goto aa ;
		default   : break ;
	}
	frescrn (UDMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	return whatever ;
}
/************************************************************************
*	+ prompt out & ask 4 up to a lineful of text ...					*
************************************************************************/
int asktxt (msg, prompt, buf, siz, flg) char * msg , * prompt , * buf ; int siz , flg ; {
	REG	char * tp ;
	int grd, whatever ;
	int plen = strlen (prompt) ;

	xfmb = 'a' ;
	frescrn (CLRMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	dispat (_msglin, 0, msg, strlen (msg), VEHILT) ;
	dispat (_msglin+1, 0, prompt, plen, VEHILT) ;

	for ( ; ; ) {
		grd = whatever = geds (_msglin+1, plen, buf, siz, flg) ;

		if (grd == KUP || grd == KDOWN
					   || grd == CTRL_E || grd == CTRL_X) {
			addhist (ghyid, buf) ;
			if ((tp = trixhist (ghyid, grd)) != (char *) 0) {
				strcpy (buf, tp) ;
				flg |= USEBUF ;
			}
		} else
			break ;
	}

	if (ghyid != NOSTR)
		addhist (ghyid, buf) ;

	if ((flg & KEEPMNUS) == 0x0000)
		frescrn (UDMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;

	return whatever ;
}
/************************************************************************
*	+ prompt out & ask 4 CR or LF to confirm an info was read and		*
*	  understood														*
************************************************************************/
int askok (msg, prompt) char * msg , * prompt ; {
	int whatever ;
	int plen = strlen (prompt) ;

	xfmb = 'o' ;
	frescrn (CLRMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	dispat (_msglin, 0, msg, strlen (msg), VEHILT) ;
	dispat (_msglin+1, 0, prompt, plen, VEHILT) ;
it :
	whatever = getkey () ;
	switch (whatever) {
		case '\r' :
		case '\n' : whatever = ENTER ;
		case CTRL_Q :
		case ESC  : break ;
		case '?'  :
        case KF1  : hyxhelp (NOSTR) ; goto it ;
		default   : honk () ; goto it ;
	}
	frescrn (UDMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	return whatever ;
}
/************************************************************************
*	+ prompt out & ask 4 yeap or nope or esc or f1 (help) AT PF MNU LIN	*
************************************************************************/
int vaskyn (msg, vpfmnu) char * msg , * vpfmnu ; {
	int whatever ;
	int plen = strlen (vpfmnu) ;
	int mlen = strlen (msg) ;

	locat (_lfmb1, 0) ; CLRTOEOL ;
	dispat (_lfmb1, 79-plen, vpfmnu, plen, VEHILT) ;
	dispat (_lfmb1, 0,       msg,    mlen, VEHILT) ;
# ifdef DOS
	locat (_lfmb1, mlen) ;
# else  /* ANYX */
    if (vdotyp != 't')
    	locat (_lfmb1, mlen) ;
# endif /* DOS */
yit :
	showcursor () ;
	whatever = getkey () ;
	hidecursor () ;

	switch (whatever) {
		case 's'  :
		case 'S'  :
		case 'y'  :
		case 'Y'  : whatever = YEAH ;  break ;
		case 'n'  :
		case 'N'  : whatever = NOPE ;  break ;
		case '\r' :
		case '\n' : whatever = ENTER ; break ;
		case CTRL_Q :
		case ESC  :
		case '?'  :
		case KF1  : break ;
		default   : honk () ; goto yit ;
	}
	locat (_lfmb1, 0) ; CLRTOEOL ;
	return whatever ;
}
/*******************************************************************/
/*
 * vi:nu tabstop=4
 */
