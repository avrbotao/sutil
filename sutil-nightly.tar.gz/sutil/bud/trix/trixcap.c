/*
 *==================================================================*
 *																	*
 *	NAME                                                            *
 *			trixcap -- List terminal capabilities                   *
 *	SYNOPSIS                                                        *
 *			trixcap [-x]                                            *
 *	DESCRIPTION                                                     *
 *			Tcaps lists characteristics and capabilities for        *
 *			the terminal in use, or the one specified in the        *
 *			'TERM' environment variable. If the '-x' flag is        *
 *			used, each characteristic/capability is followed        *
 *			by a brief explanatory sentence.                        *
 *	OPTIONS                                                         *
 *			-x = explain each capability.                           *
 *	DIAGNOSTICS                                                     *
 *                                                                  *
 *	FILES                                                           *
 *			/etc/termcap                                            *
 *	LIBRARIES                                                       *
 *			/usr/lib/libtermcap.a                                   *
 *	FUNCTIONS                                                       *
 *			tgetent, tgetstr, tgetnum, tgetflag.                    *
 *	SYSCALLS                                                        *
 *			exit.                                                   *
 *	NOTES                                                           *
 *                                                                  *
 *	RELATED                                                         *
 *																	*
 *==================================================================*
 */

/*
 *-------------------------------------------------------------------
 *	compile & test ...
 *-------------------------------------------------------------------
 *	m1		cc -o trixterm trixcap.c -ltermcap
 *	m2		cc -DABXTCAP -c bcaps.c
 *	m3		cc -o trixterm trixcap.c bcaps.o
 *-------------------------------------------------------------------
 *	t1		trixterm | more
 *	t2		TERMCAP=/etc/termcap trixterm | more
 *	t3		TERMCAP=/u/ab/trix/trixterm.dat trixterm | more
 *-------------------------------------------------------------------
 */

# define	TBUFSIZ		1024 /* 2048 */

# include <stdio.h>
# include <ctype.h>

# ifdef COMMENT

# include "termcaps.h"

# else  /* EASY */

struct capability {
	char *	tc_name ;
	char *	tc_desc ;
	char	tc_type ;
	char *	tc_str  ;
	int		tc_num  ;
	int		tc_flag ;
	char *	tc_altn ;
} ;

struct capfamily {
	char *					tcf_name ;
	struct capability *		tcf_caps ;
} ;

# define    TCT_STR    's'
# define    TCT_NUM    'n'
# define    TCT_FLG    'f'

# endif /* COMMENT */

struct capability trixwork[] = {
	{ "cm", "Move to Column and Row",		TCT_STR, 0, 0, 0, "--" },
	{ "bl", "audible signal - bell",		TCT_STR, 0, 0, 0, "--" },
	{ "cl", "Clear Screen",					TCT_STR, 0, 0, 0, "--" },
	{ "ce", "Clear to End of Line",			TCT_STR, 0, 0, 0, "--" },
	{ "md", "Highlight start",				TCT_STR, 0, 0, 0, "GU" },
	{ "mb", "Blink start",					TCT_STR, 0, 0, 0, "--" },
	{ "me", "Blink end",					TCT_STR, 0, 0, 0, "--" },
	{ "so", "Begin Standout Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "se", "End Standout Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "us", "Begin Underline Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "ue", "End Underline Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "ku", "UP Arrow Key",					TCT_STR, 0, 0, 0, "--" },
	{ "kd", "DOWN Arrow Key",				TCT_STR, 0, 0, 0, "--" },
	{ "kr", "RIGHT Arrow Key",				TCT_STR, 0, 0, 0, "--" },
	{ "kl", "LEFT Arrow Key",				TCT_STR, 0, 0, 0, "--" },
	{ "kh", "Home Key",						TCT_STR, 0, 0, 0, "--" },
	{ "EN", "End key",						TCT_STR, 0, 0, 0, "--" },
	{ "PU", "Page up",						TCT_STR, 0, 0, 0, "--" },
	{ "PD", "Page down",					TCT_STR, 0, 0, 0, "--" },
	{ "k1", "Function key One",				TCT_STR, 0, 0, 0, "--" },
	{ "k2", "Function key Two",				TCT_STR, 0, 0, 0, "--" },
	{ "k3", "Function key Three",			TCT_STR, 0, 0, 0, "--" },
	{ "k4", "Function key Four",			TCT_STR, 0, 0, 0, "--" },
	{ "k5", "Function key Five",			TCT_STR, 0, 0, 0, "--" },
	{ "k6", "Function key Six",				TCT_STR, 0, 0, 0, "--" },
	{ "k7", "Function key Seven",			TCT_STR, 0, 0, 0, "--" },
	{ "k8", "Function key Eight",			TCT_STR, 0, 0, 0, "--" },
	{ "k9", "Function key Nine",			TCT_STR, 0, 0, 0, "--" },
	{ "k0", "Function key Ten",				TCT_STR, 0, 0, 0, "--" },
	{ "GS", "Graphics mode Start",			TCT_STR, 0, 0, 0, ".-" },
	{ "GE", "Graphics mode End",			TCT_STR, 0, 0, 0, ".-" },
	{ "G2", "upper-left  (2nd qdt) corner",	TCT_STR, 0, 0, 0, ".-" },
	{ "G1", "upper-right (1st qdt) corner",	TCT_STR, 0, 0, 0, ".-" },
	{ "G3", "lower-left  (3rd qdt) corner",	TCT_STR, 0, 0, 0, ".-" },
	{ "G4", "lower-right (4th qdt) corner",	TCT_STR, 0, 0, 0, ".-" },
	{ "GU", "up-tick (upper-tee)",			TCT_STR, 0, 0, 0, ".-" },
	{ "GD", "down-tick (lower-tee)",		TCT_STR, 0, 0, 0, ".-" },
	{ "GL", "left-tick (left-tee)",			TCT_STR, 0, 0, 0, ".-" },
	{ "GR", "right-tick (right-tee)",		TCT_STR, 0, 0, 0, ".-" },
	{ "GC", "center-tick (cross-tee)",		TCT_STR, 0, 0, 0, ".-" },
	{ "GV", "vertical bar",					TCT_STR, 0, 0, 0, ".-" },
	{ "GH", "horizontal bar",				TCT_STR, 0, 0, 0, ".-" },
	{ "CF", "Cursor ON",					TCT_STR, 0, 0, 0, "--" },
	{ "CO", "Cursor OFF",					TCT_STR, 0, 0, 0, "--" },
	{ "li", "Lines on Screen", 				TCT_NUM, 0, 0, 0, "--" } ,
	{ "co", "Columns on Screen", 			TCT_NUM, 0, 0, 0, "--" } ,
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability bascaps[] = {
	{ "li", "Lines on Screen", 				TCT_NUM, 0, 0, 0, "--" } ,
	{ "co", "Columns on Screen", 			TCT_NUM, 0, 0, 0, "--" } ,
	{ "am", "Automargin or Wraparound", 	TCT_FLG, 0, 0, 0, "--" } ,
	{ "os", "Overstrike without Erasing", 	TCT_FLG, 0, 0, 0, "--" } ,
	{ "bs", "Backspace is ^H", 				TCT_FLG, 0, 0, 0, "--" } ,
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability localmov[] = {
	{ "up", "Move Cursor UP",				TCT_STR, 0, 0, 0, "--" },
	{ "do", "Move Cursor DOWN",				TCT_STR, 0, 0, 0, "--" },
	{ "nd", "Non-Destructive Space",		TCT_STR, 0, 0, 0, "--" },
	{ "le", "Move Cursor LEFT",				TCT_STR, 0, 0, 0, "--" },
	{ "ho", "Move Cursor HOME",				TCT_STR, 0, 0, 0, "--" },
	{ "ll", "Move Cursor to Left Corner",	TCT_STR, 0, 0, 0, "--" },
	{ "hu", "Half a Linefeed UP",			TCT_STR, 0, 0, 0, "--" },
	{ "hd", "Half a Linefeed DOWN",			TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability absmove[] = {
	{ "cm", "Move to Column and Row",		TCT_STR, 0, 0, 0, "--" },
	{ "ch", "Move Cursor Horizontally",		TCT_STR, 0, 0, 0, "--" },
	{ "cv", "Move Cursor Vertically",		TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability arrowkey[] = {
	{ "ku", "UP Arrow Key",					TCT_STR, 0, 0, 0, "--" },
	{ "kd", "DOWN Arrow Key",				TCT_STR, 0, 0, 0, "--" },
	{ "kr", "RIGHT Arrow Key",				TCT_STR, 0, 0, 0, "--" },
	{ "kl", "LEFT Arrow Key",				TCT_STR, 0, 0, 0, "--" },
	{ "kb", "Backspace Key",				TCT_STR, 0, 0, 0, "--" },
	{ "kh", "Home Key",						TCT_STR, 0, 0, 0, "--" },
	{ "ks", "Keypad ON",					TCT_STR, 0, 0, 0, "--" },
	{ "ke", "Keypad OFF",					TCT_STR, 0, 0, 0, "--" },
	{ "ma", "Keypad Cursor Keys",			TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability inscaps[] = {
	{ "im", "Start Insert Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "ei", "End Insert Mode",				TCT_STR, 0, 0, 0, "--" },
	{ "ic", "Insert next Character",		TCT_STR, 0, 0, 0, "--" },
	{ "ip", "Pad Time for Insert Mode",		TCT_STR, 0, 0, 0, "--" },
	{ "mi", "Move Cursor in Insert Mode",	TCT_FLG, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability delcaps[] = {
	{ "dm", "Begin Delete Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "ed", "End Delete Mode",				TCT_STR, 0, 0, 0, "--" },
	{ "dc", "Delete Character at Cursor",	TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability funckeys[] = {
	{ "kn", "Number of Fuction Keys",		TCT_NUM, 0, 0, 0, "--" },
	{ "k0", "Function key Zero",			TCT_STR, 0, 0, 0, "--" },
	{ "k1", "Function key One",				TCT_STR, 0, 0, 0, "--" },
	{ "k2", "Function key Two",				TCT_STR, 0, 0, 0, "--" },
	{ "k3", "Function key Three",			TCT_STR, 0, 0, 0, "--" },
	{ "k4", "Function key Four",			TCT_STR, 0, 0, 0, "--" },
	{ "k5", "Function key Five",			TCT_STR, 0, 0, 0, "--" },
	{ "k6", "Function key Six",				TCT_STR, 0, 0, 0, "--" },
	{ "k7", "Function key Seven",			TCT_STR, 0, 0, 0, "--" },
	{ "k8", "Function key Eight",			TCT_STR, 0, 0, 0, "--" },
	{ "k9", "Function key Nine",			TCT_STR, 0, 0, 0, "--" },
	{ "l0", "Labeled key Zero",				TCT_STR, 0, 0, 0, "--" },
	{ "l1", "Labeled key One",				TCT_STR, 0, 0, 0, "--" },
	{ "l2", "Labeled key Two",				TCT_STR, 0, 0, 0, "--" },
	{ "l3", "Labeled key Three",			TCT_STR, 0, 0, 0, "--" },
	{ "l4", "Labeled key Four",				TCT_STR, 0, 0, 0, "--" },
	{ "l5", "Labeled key Five",				TCT_STR, 0, 0, 0, "--" },
	{ "l6", "Labeled key Six",				TCT_STR, 0, 0, 0, "--" },
	{ "l7", "Labeled key Seven",			TCT_STR, 0, 0, 0, "--" },
	{ "l8", "Labeled key Eight",			TCT_STR, 0, 0, 0, "--" },
	{ "l9", "Labeled key Nine",				TCT_STR, 0, 0, 0, "--" },
	{ "ko", "Other Cursor Keys",			TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability screened[] = {
	{ "cl", "Clear Screen",					TCT_STR, 0, 0, 0, "--" },
	{ "ce", "Clear to End of Line",			TCT_STR, 0, 0, 0, "--" },
	{ "cd", "Clear to End of Screen",		TCT_STR, 0, 0, 0, "--" },
	{ "dl", "Delete Current Line",			TCT_STR, 0, 0, 0, "--" },
	{ "al", "Add Line Above Current Line",	TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability initcaps[] = {
	{ "is", "Initialize Terminal",			TCT_STR, 0, 0, 0, "--" },
	{ "if", "File Contains Initialization",	TCT_STR, 0, 0, 0, "--" },
	{ "ti", "Initialize for Cursor Motion",	TCT_STR, 0, 0, 0, "--" },
	{ "te", "Deinitialize Cursor Motion",	TCT_STR, 0, 0, 0, "--" },
	{ "vs", "Start Special Screen Editing", TCT_STR, 0, 0, 0, "--" },
	{ "ve", "End Special Screen Editing",	TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability scroll[] = {
	{ "sf", "Scroll Forward One Line",		TCT_STR, 0, 0, 0, "--" },
	{ "sr", "Scroll Backwards One Line",	TCT_STR, 0, 0, 0, "--" },
	{ "ns", "No Scroll",					TCT_FLG, 0, 0, 0, "--" },
	{ "cs", "Change Scrolling",				TCT_STR, 0, 0, 0, "--" },
	{ "da", "Display Above Paging",			TCT_FLG, 0, 0, 0, "--" },
	{ "db", "Display Below Paging",			TCT_FLG, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability standout[] = {
	{ "so", "Begin Standout Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "se", "End Standout Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "sg", "Spaces to Begin Standout",		TCT_NUM, 0, 0, 0, "--" },
	{ "vb", "Visual Bell or Flash",			TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability underlin[] = {
	{ "us", "Begin Underline Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "ue", "End Underline Mode",			TCT_STR, 0, 0, 0, "--" },
	{ "uc", "Underline Character",			TCT_STR, 0, 0, 0, "--" },
	{ "ul", "Underline Without Overstrike",	TCT_FLG, 0, 0, 0, "--" },
	{ "ug", "Spaces to Begin Underline",	TCT_NUM, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability altctrl[] = {
	{ "nl", "Newline if not ^J",			TCT_STR, 0, 0, 0, "--" },
	{ "ta", "Tab Character if not ^I",		TCT_STR, 0, 0, 0, "--" },
	{ "bc", "Backspace if not ^H",			TCT_STR, 0, 0, 0, "--" },
	{ "cr", "Carriage Return if not ^M",	TCT_STR, 0, 0, 0, "--" },
	{ "pc", "Pad Character if not NULL",	TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability altchars[] = {
	{ "as", "Use Alternate Character Set",	TCT_STR, 0, 0, 0, "--" },
	{ "ae", "Use Default Character Set",	TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability glitches[] = {
	{ "xn", "Newline Glitch",				TCT_FLG, 0, 0, 0, "--" },
	{ "xb", "Beehive Glitch",				TCT_FLG, 0, 0, 0, "--" },
	{ "xr", "Return Clears the Line",		TCT_FLG, 0, 0, 0, "--" },
	{ "xs", "Text is in Standout Mode",		TCT_FLG, 0, 0, 0, "--" },
	{ "xt", "Tab Inserts Spaces",			TCT_FLG, 0, 0, 0, "--" },
	{ "xx", "Tektronix 4025 Glitch",		TCT_FLG, 0, 0, 0, "--" },
	{ "hz", "Hazeltine Glitch",				TCT_FLG, 0, 0, 0, "--" },
	{ "nc", "No Working Carriage Return",	TCT_FLG, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability hardcopy[] = {
	{ "hc", "Specify Hardcopy Terminal",	TCT_FLG, 0, 0, 0, "--" },
	{ "dB", "Delay for Backspace",			TCT_NUM, 0, 0, 0, "--" },
	{ "dC", "Delay for Carriage Return",	TCT_NUM, 0, 0, 0, "--" },
	{ "dF", "Delay for Formfeed",			TCT_NUM, 0, 0, 0, "--" },
	{ "dN", "Delay for Newline",			TCT_NUM, 0, 0, 0, "--" },
	{ "dT", "Delay for Tab",				TCT_NUM, 0, 0, 0, "--" },
	{ "ff", "Formfeed if not ^L",			TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability miscell[] = {
	{ "tc", "Use Entry of Other Terminal",	TCT_STR, 0, 0, 0, "--" },
	{ "bw", "Backspace to Previous Line",	TCT_FLG, 0, 0, 0, "--" },
	{ "CC", "Command Character",			TCT_STR, 0, 0, 0, "--" },
	{ "eo", "Space Erases Characters",		TCT_FLG, 0, 0, 0, "--" },
	{ "ml", "Memory Lock Above Cursor",		TCT_STR, 0, 0, 0, "--" },
	{ "mu", "Memory Unlock",				TCT_STR, 0, 0, 0, "--" },
	{ "pt", "Perform Tabs with ^I",			TCT_FLG, 0, 0, 0, "--" },
	{ "bt", "Back Tab",						TCT_STR, 0, 0, 0, "--" },
	{ "in", "Nulls Fill Whitespace",		TCT_FLG, 0, 0, 0, "--" },
	{ "ms", "Move in Standout & Underline", TCT_FLG, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability modern[] = {
	{ "CF", "Cursor ON",					TCT_STR, 0, 0, 0, "--" },
	{ "CO", "Cursor OFF",					TCT_STR, 0, 0, 0, "--" },
	{ "md", "Highlight start",				TCT_STR, 0, 0, 0, "--" },
	{ "mb", "Blink start",					TCT_STR, 0, 0, 0, "--" },
	{ "me", "Blink end",					TCT_STR, 0, 0, 0, "--" },
	{ "EN", "End key",						TCT_STR, 0, 0, 0, "--" },
	{ "PU", "Page up",						TCT_STR, 0, 0, 0, "--" },
	{ "PD", "Page down",					TCT_STR, 0, 0, 0, "--" },
	{ "bl", "audible signal - bell",		TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capability graphics[] = {
	{ "GS", "Graphics mode Start",			TCT_STR, 0, 0, 0, "--" },
	{ "GE", "Graphics mode End",			TCT_STR, 0, 0, 0, "--" },
	{ "G1", "upper-right (1st qdt) corner",	TCT_STR, 0, 0, 0, "--" },
	{ "G2", "upper-left  (2nd qdt) corner",	TCT_STR, 0, 0, 0, "--" },
	{ "G3", "lower-left  (3rd qdt) corner",	TCT_STR, 0, 0, 0, "--" },
	{ "G4", "lower-right (4th qdt) corner",	TCT_STR, 0, 0, 0, "--" },
	{ "GU", "up-tick (upper-tee)",			TCT_STR, 0, 0, 0, "--" },
	{ "GD", "down-tick (lower-tee)",		TCT_STR, 0, 0, 0, "--" },
	{ "GL", "left-tick (left-tee)",			TCT_STR, 0, 0, 0, "--" },
	{ "GR", "right-tick (right-tee)",		TCT_STR, 0, 0, 0, "--" },
	{ "GH", "horizontal bar",				TCT_STR, 0, 0, 0, "--" },
	{ "GV", "vertical bar",					TCT_STR, 0, 0, 0, "--" },
	{ "GC", "center-tick (cross-tee)",		TCT_STR, 0, 0, 0, "--" },
	{ NULL, NULL,							'\0',    0, 0, 0, "--" }
} ;

struct capfamily trixcaps[] = {
	{ "TRIX Working Capabilities",	trixwork },
	{ NULL,							NULL     }
} ;

struct capfamily termcaps[] = {
	{ "Basic Capabilities",			bascaps  },
	{ "Local Movement",				localmov },
	{ "Absolute Movement",			absmove  },
	{ "Arrow Keys",					arrowkey },
	{ "Insert",						inscaps  },
	{ "Delete",						delcaps  },
	{ "Special Function Keys",		funckeys },
	{ "Screen Editing",				screened },
	{ "Initialization",				initcaps },
	{ "Scrolling",					scroll   },
	{ "Standout",					standout },
	{ "Underlining",				underlin },
	{ "Alternate Control Codes",	altctrl  },
	{ "Alternate Character Set",	altchars },
	{ "Glitches",					glitches },
	{ "Hardcopy",					hardcopy },
	{ "Miscellaneous",				miscell  },
	{ "Modern Stuff",				modern   },
	{ "Graphic Stuff",				graphics },
	{ NULL,							NULL     }
} ;

char	det_flag = '\0' ;

char *	useterm = NULL ;

# define    OK(c)		((c > 32) && (c < 127))
# define    ISESC(c)	(c == 27)
# define	CHFMT		(OK (*tmptr) ? "%c " : ISESC (*tmptr) ? "\\E " : "\\%03o ")
# define	TEFMT		(OK (*tmptr) ? "%c"  : ISESC (*tmptr) ? "\\E"  : "\\%03o" )

char
		* getenv  () ,
		* tgetstr () ;

main (argc, argv) char * * argv ; {

	fprintf (stderr, "\nTRIXTERM 1.0 @ 19/05/93\n") ;

	if (argc == 1) {
		convterm (NULL) ;
	} else {
		while (*++argv) {
			if (**argv == '-') {
				switch ( *((*argv)+1) ) {

					case 'x' :	det_flag++ ;	break ;

					case 'l' :	ptermcaps (trixcaps) ;	break ;

					case 'L' :	ptermcaps (termcaps) ;	break ;

					case 't' :	useterm = *++argv ; break ;

					default : usage () ; return ;
				}
			} else {
				convterm (*argv) ;
			}
		}
	}
}

usage () {

	fprintf (stderr, "\ntrixterm: erro de sintaxe\n\n") ;
	fprintf (stderr, "use:\ttrixterm [-lLxt] [terminal...]\n\n") ;
	fprintf (stderr, "\t-l\tlista caracteristicas usadas pelo TRIX\n") ;
	fprintf (stderr, "\t-L\tlista todas as caracteristicas do terminal\n") ;
	fprintf (stderr, "\t-t\tusa terminal diferente de $TERM\n") ;
	fprintf (stderr, "\t-x\tdescreve sucintamente cada caracteristica\n\n") ;
}

convterm (termid) char * termid ; {
	struct capfamily * tcfptr = trixcaps ;
	char	tgebuf [TBUFSIZ] ;
	char	*tmptr ;
	char	tmpbuf [TBUFSIZ] ;
	char	*termname ;
	char	holdbuf [20] ;
	int		held ;

	if (termid != NULL) {
		termname = termid ;
	} else if (useterm != NULL) {
		termname = useterm ;
	} else {
		if ((termname = getenv ("TERM")) == NULL) {
			fprintf (stderr, "trixterm: variavel TERM ausente ...\n") ;
			exit (2) ;
		}
	}

	if (tgetent (tgebuf, termname) <= 0) {
		fprintf (stderr, "trixterm: terminal %s nao encontrado\n",
		   		 termname) ;
		exit (1) ;
	}

	printf ("\n**|%s|%s|%s|Terminal %s ...:\\\n",
			termname, termname, termname, termname) ;

	while (tcfptr->tcf_name) {

		while (tcfptr->tcf_caps->tc_name) {

			if (strcmp (tcfptr->tcf_caps->tc_altn, ".-") == 0) {
				tcfptr->tcf_caps++ ;
				continue ;
			} else if (strcmp (tcfptr->tcf_caps->tc_altn, "--") == 0)
				sprintf (holdbuf, "\t:%s=", tcfptr->tcf_caps->tc_name) ;
			else
				sprintf (holdbuf, "\t:%s=", tcfptr->tcf_caps->tc_altn) ;

			held = 1 ;

			switch (tcfptr->tcf_caps->tc_type) {

				case TCT_STR:
					tmptr = tmpbuf /* tcfptr->tcf_caps->tc_str */ ;

					if (tmptr = tgetstr (tcfptr->tcf_caps->tc_name, &tmptr)) {
						printf (holdbuf) ; held = 0 ;
						if (*tmptr) {
							while (isdigit (*tmptr))
								++tmptr ;
							while (*tmptr) {
								printf (TEFMT, *tmptr) ;
								++tmptr ;
							}
						} else
							printf ("^@") ;
					}

			    break ;

			    case TCT_NUM:
					if ((tcfptr->tcf_caps->tc_num =
					     tgetnum (tcfptr->tcf_caps->tc_name)) >= 0) {

						printf (holdbuf) ; held = 0 ;
						printf ("%d", tcfptr->tcf_caps->tc_num) ;
					}
			    break ;

# ifdef COMMENT
			    case TCT_FLG: /* must obey tcap flag rules ... */
					if ((tcfptr->tcf_caps->tc_flag =
					     tgetflag (tcfptr->tcf_caps->tc_name)) >= 0) {

						printf (holdbuf) ; held = 0 ;
						putchar (tcfptr->tcf_caps->tc_flag ? 'T' : 'F') ;
					}
			    break ;
# endif /* COMMENT */

				default:
					fprintf (stderr,
							 "trixterm: tipo / cap (%d) indefinido\n",
							 tcfptr->tcf_caps->tc_type) ;
				break ;

			}

			if (held == 0)
				printf (":\\\n") ;

			tcfptr->tcf_caps++ ;
		}

		tcfptr++ ;
	}
	printf ("\t:zz:\n\n") ;
}

ptermcaps (tcfptr) struct capfamily * tcfptr ; {
	char	tgebuf[TBUFSIZ] ;
	char	*tmptr ;
	char	tmpbuf[TBUFSIZ] ;
	char	*termname ;

	if (useterm != NULL) {
		termname = useterm ;
	} else {
		if ((termname = getenv ("TERM")) == NULL) {
			fprintf (stderr, "trixterm: variavel TERM ausente ...\n") ;
			exit (2) ;
		}
	}

	if (tgetent (tgebuf, termname) <= 0) {
		fprintf (stderr, "trixterm: terminal %s nao encontrado\n",
		   		 termname) ;
		exit (1) ;
	}

	while (tcfptr->tcf_name) {

		putchar ('\n') ;
		fputs (termname, stdout) ;
		fputs (": ", stdout) ;
		puts (tcfptr->tcf_name) ;
		putchar ('\n') ;

		while (tcfptr->tcf_caps->tc_name) {

			fputs (tcfptr->tcf_caps->tc_name, stdout) ;

			if (det_flag) {
				fputs (" (", stdout) ;
				fputs (tcfptr->tcf_caps->tc_desc, stdout) ;
				putchar (')') ;
			}

			fputs (" = ", stdout) ;

			switch (tcfptr->tcf_caps->tc_type) {

				case TCT_STR:

					tmptr = tmpbuf /* tcfptr->tcf_caps->tc_str */ ;

					if (tmptr = tgetstr (tcfptr->tcf_caps->tc_name, &tmptr)) {
						if (*tmptr) {
							while (*tmptr) {
								printf (CHFMT, *tmptr) ;
								tmptr++ ;
							}
							putchar ('\n') ;
						} else
							puts ("Null") ;
					} else
						puts ("Undefined") ;

			    break ;

			    case TCT_NUM:

				if ((tcfptr->tcf_caps->tc_num =
				     tgetnum (tcfptr->tcf_caps->tc_name)) < 0)
					puts ("Undefined") ;
				else
					printf ("%d\n",
						tcfptr->tcf_caps->tc_num) ;

			    break ;

			    case TCT_FLG:

				if ((tcfptr->tcf_caps->tc_flag =
				     tgetflag (tcfptr->tcf_caps->tc_name)) < 0)
					puts ("Undefined") ;
				else
					puts (tcfptr->tcf_caps->tc_flag ?
					      "True" : "False") ;

			    break ;

				default:
					fprintf (stderr,
						 "trixterm: tipo / cap (%d) indefinido\n",
						 tcfptr->tcf_caps->tc_type) ;
				break ;

			}

			tcfptr->tcf_caps++ ;
		}

		tcfptr++ ;
	}
}
/*
 * vi:nu tabstop=4
 */
