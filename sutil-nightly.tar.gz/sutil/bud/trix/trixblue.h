/************************************************************************
*	colors & video effects ...			   I R G B						*
************************************************************************/

# ifdef ANYX

# define	BLACK			 0			/* 0 0 0 0						*/
# define	BLUE 			 1			/* 0 0 0 1						*/
# define	GREEN			 2			/* 0 0 1 0						*/
# define	CYAN 			 3			/* 0 0 1 1						*/
# define	RED  			 4			/* 0 1 0 0						*/
# define	VIOLET			 5			/* 0 1 0 1						*/
# define	BROWN			 6			/* 0 1 1 0						*/
# define	LIGHTGRAY		 7			/* 0 1 1 1						*/
# define	GRAY 			 8			/* 1 0 0 0						*/
# define	LT_BLUE 		 9			/* 1 0 0 1						*/
# define	LT_GREEN		10			/* 1 0 1 0						*/
# define	LT_CYAN 		11			/* 1 0 1 1						*/
# define	LT_RED  		12			/* 1 1 0 0						*/
# define	LT_VIOLET		13			/* 1 1 0 1						*/
# define	YELLOW			14			/* 1 1 1 0						*/
# define	WHITE			15			/* 1 1 1 1						*/

# define	MAGENTA			VIOLET
# define	LT_MAGENTA		LT_VIOLET

# endif /* ANYX */

# define	BGFG(X,Y)		( ( X << 4 ) | Y )

/*----------------------------------------------------------------------*/
# ifdef		TCWINDOWS

# define	VENORM		  0x07			/* normal video					*/
# define	VEHILT		  0x0f			/* highlight					*/
# define	VEULIN		  0x02			/* underline					*/
# define	VEBLNK		  0x87			/* blink						*/
# define	VEREVS		  0x70			/* reverse video				*/
# define	VERVHL		  0x7e			/* reverse highlight			*/
# define	VEBVHL		  0x8f			/* blink + highlight			*/
# define	VEAGCS		VENORM			/* alternate graphic char set	*/
# define	VERVBL		  0xf0			/* reverse + blink			    */  

# else		/* ANYX ... */

# ifdef		CURSES

# define	VENORM		A_NORMAL		/* normal video					*/
# define	VEHILT		A_BOLD			/* A_STANDOUT = highlight		*/
# define	VEULIN		A_UNDERLINE		/* underline					*/
# define	VEBLNK		A_BLINK			/* blink						*/
# define	VEREVS		A_REVERSE		/* reverse video				*/
# define	VERVHL			 5			/* reverse highlight			*/
# define	VEBVHL			 6			/* blink + highlight			*/
# define	VEALTC		A_ALTCHARSET	/* alternate character set		*/
# define	VERVBL		     8			/* reverse + blink			    */  
# define	VEAGCS		VEALTC			/* alternate graphic char set	*/

# else		/* PROPRIETARY EFFECTS */

# define	VENORM			 0			/* normal video					*/
# define	VEHILT			 1			/* highlight					*/
# define	VEULIN			 2			/* underline					*/
# define	VEBLNK			 3			/* blink						*/
# define	VEREVS			 4			/* reverse video				*/
# define	VEAGCS			 5			/* alternate graphic char set	*/
# define	VERVHL			 6			/* reverse highlight			*/
# define	VEBVHL			 7			/* blink + highlight			*/
# define	VERVBL		     8			/* reverse + blink			    */  

# endif		/* CURSES */

# endif		/* TCWINDOWS */

/*
 * vi:tabstop=4
 */
