/*
 *			|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *			|	PRODESCR :	PROduct's Description, Environment,		|
 *			|				Security & Customer Record				|
 *			|_______________________________________________________|
 */

typedef		/*unsigned*/ char	BYTE ;

# define	PDSIGNAT	"@$#!&~^%+*"
# define	PDRNDSIZ	600

struct prodescr {
	BYTE pd_niknam [ 20] ;		/* small name 4 small windows		*/
	BYTE pd_hwname [ 30] ;		/* computer manufacturer & model	*/
	BYTE pd_hwsrno [ 12] ;		/* computer (h/w) serial number		*/
	BYTE pd_mputyp [ 12] ;		/* mpu type (386, 68k, risc, ...)	*/
	BYTE pd_hopsys [ 30] ;		/* operating system name & version	*/
	BYTE pd_hosrno [ 12] ;		/* operating system serial number	*/
	BYTE pd_siteid [ 20] ;		/* net node or site name ...		*/
	BYTE pd_adinfo [ 70] ;		/* aditional information, comments	*/
	BYTE pd_filsec [632] ;		/* stuff to fill 1024 bytes			*/
	BYTE pd_bignam [ 70] ;		/* customer's full name				*/
	BYTE pd_prodid [ 40] ;		/* product name & version ...		*/
	BYTE pd_swsrno [ 12] ;		/* product (s/w) serial number		*/
	BYTE pd_signat [ 12] ;		/* record signature : "@$#!&~^%+*"	*/
	BYTE pd_acqdat [ 12] ;		/* acquisition date or demo start	*/
	BYTE pd_expdat [ 12] ;		/* demo expiration date				*/
	BYTE pd_execnt [ 12] ;		/* execution count in ascii octal	*/
	BYTE pd_xflags [ 16] ;		/* 15 general control flags			*/
} ;

typedef		struct prodescr		PRODESCR ;

# define	PDRECSIZ			( sizeof (PRODESCR) )

# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>

# ifdef ANSI
# define	OF(X)		X
# else  /* OLD */
# define	OF(X)		()
# endif /* ANSI */

/*
 *								|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *								|	stamp, mark, seal a product,	|
 *								|	write <prodescr> record ...		|
 *								|___________________________________|
 */

void	rndfil		OF ( ( BYTE * , int ) ) ;
void	getfld		OF ( ( int , BYTE * , char * ) ) ;
void	ratata		OF ( ( int , int ) ) ;
void	prodcrap	OF ( ( BYTE * , int ) ) ;

int iflg = 0 ;

void main (argc, argv) char * * argv ; {
	PRODESCR xp ;

	FILE * dfp = fopen ("prodseal.dat", "wb") ;

	printf ("\nProdSeal 1.6 (C) Alexandre Botao @ 01/10/92\n\n") ;

	if (argc > 1)
		if (strcmp ( *(argv+1) , "-i" ) == 0)
			++iflg ;

	strcpy (    xp.pd_signat, PDSIGNAT) ;
	rndfil (    xp.pd_filsec, PDRNDSIZ) ;

	getfld (30, xp.pd_prodid, "produto & versao") ;
	getfld (12, xp.pd_swsrno, "numero de serie do produto") ;
	getfld (12, xp.pd_acqdat, "data de aquisicao") ;
	getfld (12, xp.pd_expdat, "data de expiracao") ;
	getfld (70, xp.pd_bignam, "nome completo do cliente") ;
	getfld (20, xp.pd_niknam, "nome abreviado ...") ;
	getfld (30, xp.pd_hwname, "fabricante e modelo") ;
	getfld (12, xp.pd_hwsrno, "numero de serie do h/w") ;
	getfld (12, xp.pd_mputyp, "tipo da mpu (386, 68k, s800 risc, ...)") ;
	getfld (30, xp.pd_hopsys, "sistema operacional e versao") ;
	getfld (12, xp.pd_hosrno, "numero de serie do s/o") ;
	getfld (20, xp.pd_siteid, "sitename ou nodename") ;
	getfld (16, xp.pd_xflags, "flags de controle") ;
	getfld (70, xp.pd_adinfo, "informacoes adicionais, comentarios") ;

	prodcrap ( (BYTE *) &xp, PDRECSIZ) ;

	fwrite ( (char *) &xp, PDRECSIZ, 1, dfp ) ;
}

void rndfil (buf, siz) BYTE * buf ; {
	register char * bp = buf ;

	srand ( (int) time ( (long *) 0 ) ) ;

	while (siz--)
		*bp++ = rand () % 256 ;
}

void getfld (siz, buf, msg) BYTE * buf ; char * msg ; {
	char tb [100] ;

	if (iflg) {
		printf ("\n") ;
		ratata (78, '*') ;
		printf ("\n\n%s\n\n", msg) ;
		ratata (siz, '_') ;
		printf ("\n") ;
		ratata (siz, '_') ;
	}
	gets (tb) ;
	memcpy (buf, tb, siz-1) ;
	buf[siz-1] = '\0' ;
}

void ratata (cnt, byt) {

	while (cnt--)
		putchar (byt) ;

	putchar ('\r') ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	jumble some bits a bit ...	|
 *									|_______________________________|
 */

# define	Z1(X)		(X ^ 0xaa)
# define	Z2(X)		(X ^ 0x95)
# define	Z3(X)		(X ^ 0xac)
# define	Z4(X)		(X ^ 0xa5)
# define	Z5(X)		(X ^ 0x9a)
# define	Z6(X)		(X ^ 0xc5)
# define	Z7(X)		(X ^ 0xa9)
# define	Z8(X)		(X ^ 0xca)

void prodcrap (buf, cnt) BYTE * buf ; {

	static BYTE zest [] = {
		Z1('X'),Z2('M'),Z3('a'),Z4('y'),Z5('n'),Z6('o'),Z7('u'),Z8('P'),
		Z1('a'),Z2('a'),Z3('e'),Z4('K'),Z5('d'),Z6('r'),Z7('e'),Z8('a'),
		Z1('n'),Z2('t'),Z3('l'),Z4('f'),Z5('r'),Z6('R'),Z7('s'),Z8('z'),
		Z1('d'),Z2('h'),Z3('V'),Z4('A'),Z5('e'),Z6('o'),Z7('B'),Z8('W'),
		Z1('i'),Z2('e'),Z3('a'),Z4('l'),Z5('V'),Z6('d'),Z7('o'),Z8('a'),
		Z1('n'),Z2('u'),Z3('l'),Z4('e'),Z5('i'),Z6('r'),Z7('t'),Z8('t'),
		Z1('h'),Z2('s'),Z3('e'),Z4('x'),Z5('c'),Z6('i'),Z7('a'),Z8('e'),
		Z1('o'),Z2('J'),Z3('Q'),Z4('a'),Z5('t'),Z6('g'),Z7('o'),Z8('r')
	} ;

	register BYTE * bp = buf ;
	register BYTE * zp = zest ;
	register int	bk = 0 ;
	register int	zk = 0 ;

	for ( ; bk < cnt ; ++bk , ++zk , ++bp , ++zp ) {
		if (zk > 63) {
			zk = 0 ;
			zp = zest ;
		}
		*bp ^= /* ~ */ *zp ;
	}
}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
