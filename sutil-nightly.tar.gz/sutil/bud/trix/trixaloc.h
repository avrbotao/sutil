/************************************************************************
*	+ xalloc ...							*
************************************************************************/

# ifdef		TC

# include "alloc.h"

# endif		/* TC */

# ifdef		XENIX

# include	<memory.h>

# endif		/* XENIX */

# ifdef   LOFMEM				/* lots of memory ...	*/

# define  FAR		far
# define  HUG		huge

# define  MEMGET(X)	( /* memget */ farmalloc  (X)   )
# define  MEMRID(X)	( /* memrid */ farfree    (X)   )
# define  CALLOC(N,S)	( /* memblk */ farcalloc  (N,S) )
# define  REALLOC(P,S)	( /* memchg */ farrealloc (P,S) )

# else    /* ! LOFMEM */

# define  FAR
# define  HUG

# ifdef   DBG

# define  MEMGET(X)	( valloc   (X)   )
# define  MEMRID(X)	( vfree    (X)   )
# define  CALLOC(N,S)	( vcalloc  (N,S) )
# define  REALLOC(P,S)	( vrealloc (P,S) )

# else    /* ! DBG (4 real) */

# define  MEMGET(X)	( /* memget */ malloc  (X)   )
# define  MEMRID(X)	( /* memrid */ free    (X)   )
# define  CALLOC(N,S)	( /* memblk */ calloc  (N,S) )
# define  REALLOC(P,S)	( /* memchg */ realloc (P,S) )

# endif   /* DBG */

# endif   /* LOFMEM */

# ifdef   MEMACS

# define  SALLOC(X)	( (char *) malloc (X) )
# define  FALLOC(P,X)	( (P = SALLOC (X)) == VZRO (char *) )
# define  MALLOC(T)	( (T *) malloc (sizeof (T)) )
# define  NALLOC(P,T)	( (P = MALLOC (T)) == VZRO (T *) )
# define  KALLOC(X,T)	( (T *) calloc (X, sizeof (T)) )
# define  BALLOC(P,X,T)	( (P = CALLOC (X, T)) == VZRO (T *) )
# define  REALOC(P,X,T)	( (T *) realloc (P, X) )
# define  NEALOC(P,X,T)	( (P = REALOC (P, X, T)) == VZRO (T *) )

# else    /* EASY */

# define  FALLOP(X,Y)	( ( X = (Y *) MEMGET (sizeof (Y)) ) == (Y *) 0 )
# define  NALLOC(X,Y)	( ( X = MEMGET (Y) ) == (char *) 0 )

# endif   /* MEMACS */

/************************************************************************
* ... 									*
************************************************************************/
