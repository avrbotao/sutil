/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixcopy.c + copy files somewhere ...				|
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

#	include	<stdio.h>
#	include	<string.h>

#	ifdef	DOS

#		include	<conio.h>
#		include <io.h>
#		include	<sys/types.h>
#		include	<sys/stat.h>

#		define	F_OK		0

#	else	/* ANYX	*/

#		include <unistd.h>

#	endif	/* DOS		*/

#	include	"trix.h"
#	include	"trixaloc.h"
#	include	"trixblue.h"
#	include	"trixkeys.h"
#	include	"trixfunc.h"
#	include	"trixext.h"
#	include	"trixtext.h"
#	include	"trixasci.h"
#	include	"trixcmd.h"
#	include	"trixwig.h"
# include	"trixterm.h"

# ifdef		ANSI

EXT	int		( * filcmp )	( ) ;
	int		xcopfil			( char * , char * ) ;

# else		/* OLD STYLE */

EXT	int		( * filcmp )	( ) ;
	int		xcopfil			( ) ;

# endif		/* ANSI */

EXT char *	currwd , * cebuf , * ghelpt , * ghyid , * xwhy ;
EXT	char	origwd [ ] ;

/*
 *	+---------------------------------------------------------------+
 *	|	copy file ...												|
 *	+---------------------------------------------------------------+
 */
EXT int overcopy ;

int copfil (fp, pdestdir, flgs) FILDAT * fp ; char * pdestdir ; int flgs ; {

	REG int grd ;
		char * xp ;
	REG char * np = pdestdir ;
		char origup [140] , destup [140] ;
/*
 *	@ build dest (path)name
 */
	strcpy (tmpbuf, np) ;
	xp = tmpbuf + strlen (np) ;
	*xp++ = DIRSEP ; *xp++ = '\0' ;
	strcat (tmpbuf, fp->fd_nam) ;
	strcpy (destup, tmpbuf) ;
	strcpy (origup, fp->fd_path) ;
# ifdef DOS
	strupr (origup) ;
	strupr (destup) ;
# endif /* DOS */
/*
 *	@ tell we're copying ...
 */
	locat (_lcmb1, 0) ; CLRTOEOL ;
	locat (_lcmb2, 0) ; CLRTOEOL ;
	locat (_lfmb1, 0) ; CLRTOEOL ;
	sprintf (tmpbuf, T_COPFIL, origup) ;
	dispat (_lcmb1, 0, tmpbuf, 80, VEHILT) ;
	sprintf (tmpbuf, "%s\"%s\"", T_TODEST, destup) ;
	dispat (_lcmb2, 0, tmpbuf, 80, VEHILT) ;
/*
 *	@ chk 4 self destructive copy ...
 */
	if (strcmp (origup, destup) == 0) {
		grd = vaskyn (T_EMOVSELF, T_VOKFMB) ;
		switch (grd) {
			case CTRL_Q :
			case ESC    : return ESC ;
			default     : return -1 ;	 /* should ask 4 create ! */
		}
	}
/*
 *	||=============================================================||
 *	||	+ confirm & destroy dest (path)name                        ||
 *  ||                                                             ||
 *	||	+ should link dest to $TRIXWASTEBASKET,                    ||
 *	||	  not only to be able to revert things out if the link	   ||
 *	||	  doesn't succeed, but also to honor trix's r.f.           ||
 *	||	+ trix should keep a wastebasket on all mounted			   ||
 *	||	  filesystems (in 'lost+found' style) so we could save &   ||
 *	||	  unerase on every dir ...								   ||
 *	||=============================================================||
 */
	if ((grd = access (destup, F_OK)) == 0) {
		overcopy = FALSE ;
		if (flgs & CONFLG) {	/* confirm deletion if dest exists */
cit :		grd = vaskyn (T_RMXFIL, T_VYNFMB) ;
			switch (grd) {
				case ENTER :
				case NOPE  : return -1 ;
				case CTRL_Q :
				case ESC   : return ESC ;
				case YEAH  : overcopy = TRUE ; break ;
				case '?'   :
				case KF1   : hyxhelp (T_RMXFIL) ; goto cit ;
			}
		} else {
			overcopy = TRUE ;
		}
		if ( unlink ( destup ) < 0 ) {
			overcopy = FALSE ;
			grd = trixerr (T_CANTRM, destup, errno, BANAL) ;
			switch (grd) {
				case CTRL_Q :
				case ESC   : return ESC ;
				default    : return -1 ;
			}
		}
		chkover (fp) ;
	} else
		overcopy = FALSE ;

	/*
	 *	copy it ! ...
	 *
	 *	trixerr must be window-(dialog box)-oriented ...
	 */

	grd = xcopfil ( origup , destup ) ;

	if ( grd != 0 ) {
		overcopy = FALSE ;
		grd = trixerr (T_ECOPFIL, origup, xerrno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
	}
	return 0 ;
}
/*	+---------------------------------------------------------------+
 *	|	physically (& portably) copy file ...						|
 *	+---------------------------------------------------------------+
 */
int xcopfil (old, new) char * old, * new ; {

	int grd ;
	char tmpbuf [ 512 ] ;

# define	INAHURRY

# ifdef		INAHURRY

# ifdef		DOS
	sprintf (tmpbuf, "copy %s %s > nul", old, new) ;
# else		/* ANYX */
	sprintf (tmpbuf, "cp %s %s > /dev/null 2> /dev/null", old, new) ;
# endif		/* DOS */
	grd = trixrun (tmpbuf) ;
	return grd ;

# else		/* EASYLY */

# endif		/* INAHURRY */

}

/**********************************************************************/

# ifdef COMMENT
/* x cp */

# include <io.h>
# include <string.h>
# include <stdio.h>

int xcp ( char * , char * ) ;

void main (argc, argv) char * * argv ; {
	char * filnam = *(argv+1) ;
	char * dstdir = *(argv+2) ;

	if (argc != 3)
		return ;

	if (dstdir && filnam)
		xcp (dstdir, filnam) ;
}

int xcp (dir, fil) char * dir , * fil ; {
	char dstpathnam [512] ;
	char dstfil [80] ;
	char dstdir [80] ;
	char srcdir [80] ;
	char srcfil [80] ;
	char rsvp [80] ;
	char * np ;
	FILE * ifp , * ofp ;
	int x ;

	dirfilsplit (fil, srcdir, srcfil) ;
	dirfilsplit (dir, dstdir, dstfil) ;
	ifp = fopen (fil, "rb") ;
	if (ifp == VZRO) {
		printf ("ERRO ao abrir arquivo \"%s\" : ", fil) ;
		perror ("xcp") ;
		return -1 ;
	}
bn :
	sprintf (dstpathnam, "%s\\%s", dstdir, srcfil) ;

	if (access (dstpathnam, 0) == 0) {
		printf ("Arquivo \"%s\" ja' existe ! ", dstpathnam) ;
gr :	gets (rsvp) ;
		np = rsvp + 2 ;
		switch (*rsvp) {
			case 'n' : strcpy (srcfil, np) ; goto bn ;
			case 'd' : strcpy (dstdir, np) ; goto bn ;
			case 's' : break ;
			case 'a' : return -1 ;
			default  : goto gr ;
		}
	}
	ofp = fopen (dstpathnam, "wb") ;
	if (ofp == VZRO) {
		printf ("ERRO ao abrir arquivo \"%s\" : ", fil) ;
		perror ("xcp") ;
		return -1 ;
	}
	while ((x = getc (ifp)) != EOF)
		putc (x, ofp) ;

	fclose (ifp) ; fclose (ofp) ;
	return 0 ;
}
# endif /* COMMENT */
/**********************************************************************/
# ifdef COMMENT
/*
 *	vcp + verbose cp ...
 *
 *	10/03/92	v1.0	file-2-file cp, %, bar
 *	11/03/92	v1.1	many-files 2 dir
 *	12/03/92	v1.2	estimated & elapsed time
 *
 *	round-midnight copies craps estimated time on dos.
 */
# include	<stdio.h>
# include	<stdlib.h>
# include	<string.h>
# ifdef DOS
#	include <dir.h>
#	include <dos.h>
#	include <bios.h>
#	include <conio.h>
# endif /* DOS */
# include <sys/types.h>
# include <sys/stat.h>

struct cpinfo {
	char * ifn ;		/* input  file name		*/
	char * ofn ;		/* output file name		*/
	long   xsz ;		/* transfer size		*/
} ;

typedef		struct cpinfo		CPINFO ;
/* typedef		struct stat			STAT ; */

# define	VBSIZ		 4096
# define	YET			  177
# define	VOK			  219
# define	SCALE		   40

# define	DIRSEP		'\\'

# define    LINFROM		4
# define	LINTO		6

# define    LINXPER		8
# define	LINFPER     10
# define	LINTPER     12

# define	LINETIM		14

char cpbuf [ VBSIZ ] ;
struct STAT stabuf ;
FILE * ifp , * ofp ;
CPINFO * cplst = (CPINFO *) 0 ;
int totfiles = 0 ;
int todir = 0 ;
long totbyts = 0L ;
long allbyts = 0L ;
long itiks ;

char * vcpfram [] = {
	"'*'s7'=78's-'s9",
	"'p2,3vcp 1.2 (c) 1992 Alexandre Botao",
	"'p2,1's|'p2,80's|",
	"'p3,1's4'=28's-'s6 Arquivo de  Origem 's4'=28's-'s6",
	"'p4,1's|'p4,80's|",
	"'p5,1's4'=28's-'s6 Arquivo de Destino 's4'=28's-'s6",
	"'p6,1's|'p6,80's|",
	"'p7,1's4'=28's-'s6 Bytes Trasnferidos 's4'=28's-'s6",
	"'p8,1's|'p8,80's|",
	"'p9,1's4'=28's-'s6 Arquivos  Copiados 's4'=28's-'s6",
	"'p10,1's|'p10,80's|",
	"'p11,1's4'=24's-'s6 Total  de  Bytes  Copiados 's4'=24's-'s6",
	"'p12,1's|'p12,80's|",
	"'p13,1's4'=10's-'s6 Tempo Estimado 's4'=10's-'s8's8",
			 "'=10's-'s6 Tempo  R e a l 's4'=10's-'s6",
	"'p14,1's|'p14,40's|'s|'p14,80's|",
	"'p15,1's4'=38's-'s2's2'=38's-'s6",
	"'p16,1's|'p16,80's|",
	"'p17,1's|'p17,80's|",
	"'p18,1's|'p18,80's|",
	"'p19,1's4'=33's-'s6 Mensagem 's4'=33's-'s6",
	"'p20,1's|'p20,80's|",
	"'p21,1's|'p21,80's|",
	"'p22,1's|'p22,80's|",
	"'p23,1's1'=78's-'s3",
	(char *) 0
} ;

void growlist (char *, char *) ;
void proclist (void) ;
void vcp      (char *, char *, long) ;
void invest   (void) ;
void vestim   (void) ;
void ltohms   (long, long *, long *, long *) ;
void flexfram (char * *) ;
int  stodec   (char *, int *) ;
int  lastoc   (char *, char) ;

void main (argc, argv) char * * argv ; {
	char * destname ;
	register int wk ;

	flexfram (vcpfram) ;

	if (argc < 3) {
		gotoxy (3,20) ; cprintf ("use: vcp arquivo novonome") ;
		gotoxy (3,21) ; cprintf (" ou: vcp arquivo ... diretorio") ;
		gotoxy (1,24) ; return ;
	}
	destname = *(argv+(argc-1)) ;

	if (STAT (destname, &stabuf) == -1) {
		if (argc > 3) {
dnf :		gotoxy (3,20) ; cprintf ("Diretorio abaixo nao encontrado :") ;
			gotoxy (3,21) ; cprintf ("%-76s", destname) ;
			return ;
		}
		/* cp file 2 file ... */
		growlist (*(argv+1), destname) ;
	} else {
		/* dest exists ... */
		if ((stabuf.st_mode & S_IFMT) == S_IFREG) {
			if (argc > 3)
				goto dnf ;
			else {
				growlist (*(argv+1), destname) ;
			}
		} else if ((stabuf.st_mode & S_IFMT) != S_IFDIR) {
			goto dnf ;
		} else {
			/* build file list 2 cp 2 dir ... */
			todir = 1 ;
			for ( wk = 1 ; wk < (argc-1) ; ++wk ) {
				growlist (*(argv+wk), destname) ;
			} /* endof for argv */
		}
	}
	proclist () ;
	gotoxy (1, 24) ;
}

void growlist (pname, dname) char * pname, * dname ; {
	struct ffblk ffbuf ;
	char nup [80] ;
	char fnbuf [80] ;
	register char * fnptr = ffbuf.ff_name ;
	register char * cp ;
	register int slasti ;
	register size_t /* int */ nusiz ;
	CPINFO * xp ;

# ifdef DOS
	strcpy (nup, dname) ;
	if (findfirst (pname, &ffbuf, FA_ARCH) == 0) {
		if ((slasti = lastoc (pname, DIRSEP)) >= 0)
			strcpy (fnptr = fnbuf, pname) ;
		do {
			if (fnptr == fnbuf) {
				strncpy (fnptr+slasti+1, ffbuf.ff_name, 13) ;
			}
			if (todir) {
				sprintf (nup, "%s\\", dname) ;
				strncat (nup, ffbuf.ff_name, 12) ;
			}
			/* src = fnptr , dst = nup : chk all & collect */
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
			if (cplst == (CPINFO *) 0) {
				cplst = (CPINFO *) malloc (sizeof (CPINFO)) ;
				if (cplst == (CPINFO *) 0) {
vnm :				gotoxy (1, 24) ;
					cprintf ("vcp: faltou memoria ...") ;
					exit (1) ;
				}
			} else {
				nusiz = (totfiles+1) * (sizeof (CPINFO)) ;
				cplst = (CPINFO *) realloc (cplst, nusiz) ;
				if (cplst == (CPINFO *) 0)
					goto vnm ;
			}
			xp = cplst + totfiles ; ++totfiles ;
			xp->xsz = ffbuf.ff_fsize ; totbyts += xp->xsz ;
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
			cp = malloc (1+strlen (fnptr)) ;
			if (cp == (char *) 0)
				goto vnm ;
			strcpy (cp, fnptr) ;
			xp->ifn = cp;
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
			cp = malloc (1+strlen (nup)) ;
			if (cp == (char *) 0)
				goto vnm ;
			strcpy (cp, nup) ;
			xp->ofn = cp;
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
		} while (findnext (&ffbuf) != -1) ;
	} else {
		gotoxy (3,20) ; cprintf ("ERRO ao acessar :") ;
		gotoxy (3,21) ; cprintf ("%-76s", pname) ;
		gotoxy (3,22) ; cprintf ("Tecle [Esc] ") ;
		while (getch () != 27) ;
		gotoxy (1, 24) ;
	}
# else  /* ANYX */

# endif /* DOS */
}

void proclist () {
	register CPINFO * xp = cplst ;
	register int filecnt = 0 ;
	register int i, perctof, scaltof ;
/*	struct time tbuf ;	*/

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	gotoxy (3, LINTPER) ;  cprintf ("0000000000 (000 %) ") ;
	gotoxy (22, LINTPER) ;
	for ( i = 0 ; i < SCALE ; ++i )
		putch (YET) ;
	gotoxy (63, LINTPER) ; cprintf ("%ld", totbyts) ;
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	gotoxy (3, LINFPER) ;  cprintf ("    000000 (000 %) ") ;
	gotoxy (22, LINFPER) ;
	for ( i = 0 ; i < SCALE ; ++i )
		putch (YET) ;
	gotoxy (63, LINFPER) ; cprintf ("%d", totfiles) ;
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
# ifdef COMMENT
	gotoxy (60, 16) ; cprintf ("Inicio  = __:__:__") ;
	gotoxy (60, 17) ; cprintf ("Termino = __:__:__") ;
	gettime (&tbuf) ; gotoxy (70, 16) ;
	cprintf ("%02d:%02d:%02d",tbuf.ti_hour,tbuf.ti_min,tbuf.ti_sec) ;
# endif /* COMMENT */
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	invest () ;

	while (filecnt < totfiles) {
		vcp (xp->ifn, xp->ofn, xp->xsz) ;
		++xp ; ++filecnt ;
		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
		perctof = (int) ( ( filecnt * 100 ) / totfiles ) ;
		scaltof = ( SCALE * perctof ) / 100 ;
		gotoxy (15, LINFPER) ; cprintf ("%3d", perctof) ;
		gotoxy (22, LINFPER) ;
		for ( i = 0 ; i < scaltof ; ++i )
			putch (VOK) ;
		gotoxy (7, LINFPER) ;  cprintf ("%6d", filecnt) ;
	}
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
# ifdef COMMENT
	gettime (&tbuf) ; gotoxy (70, 17) ;
	cprintf ("%02d:%02d:%02d",tbuf.ti_hour,tbuf.ti_min,tbuf.ti_sec) ;
# endif /* COMMENT */
}

void vcp (iname, oname, xsize) char * iname , * oname ; long xsize ; {
	register int i, bytio ;
	register int percok, perctob, scalok, scaltob ;
	register long filebyts = 0L ;
	register long xtotb = totbyts ;

	if ((ifp = fopen (iname, "rb")) == VZRO) {
		gotoxy (3,20) ; cprintf ("arquivo abaixo nao encontrado :") ;
		gotoxy (3,21) ; cprintf ("%-76s", iname) ;
		gotoxy (3,22) ; cprintf ("Tecle [Esc] ") ;
		while (getch () != 27) ;
		return ;
	}

	if ((ofp = fopen (oname, "wb")) == VZRO) {
		gotoxy (3,20) ; cprintf ("ERRO ao criar arquivo abaixo :") ;
		gotoxy (3,21) ; cprintf ("%-76s", oname) ;
		gotoxy (3,22) ; cprintf ("Tecle [Esc] ") ;
		while (getch () != 27) ;
		return ;
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	gotoxy (3, LINFROM) ; cprintf ("%-76s", iname) ;
	gotoxy (3, LINTO) ;   cprintf ("%-76s", oname) ;
	gotoxy (3, LINXPER) ; cprintf ("           (000 %) ") ;
	gotoxy (22, LINXPER) ;
	for ( i = 0 ; i < SCALE ; ++i )
		putch (YET) ;
	gotoxy (63, LINXPER) ; cprintf ("%-10ld", xsize) ;
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	while ((bytio = fread (cpbuf, 1, VBSIZ, ifp)) > 0) {
		fwrite (cpbuf, 1, bytio, ofp) ;
		filebyts += bytio ; allbyts += bytio ;
		vestim () ;
		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
		percok = (int) ( ( filebyts * 100 ) / xsize ) ;
		scalok = ( SCALE * percok ) / 100 ;
		gotoxy (15, LINXPER) ; cprintf ("%3d", percok) ;
		gotoxy (22, LINXPER) ;
		for ( i = 0 ; i < scalok ; ++i )
			putch (VOK) ;
		gotoxy (3, LINXPER) ; cprintf ("%10ld", filebyts) ;
		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
		perctob = (int) ( ( allbyts * 100 ) / xtotb ) ;
		scaltob = ( SCALE * perctob ) / 100 ;
		gotoxy (15, LINTPER) ; cprintf ("%3d", perctob) ;
		gotoxy (22, LINTPER) ;
		for ( i = 0 ; i < scaltob ; ++i )
			putch (VOK) ;
		gotoxy (3, LINTPER) ; cprintf ("%10ld", allbyts) ;
		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	}
	fclose (ifp) ; fclose (ofp) ;
}

int lastoc (s, c) char * s ; char c ; {
	register char * p = s ;
	register int i = -1 ;

	while (*p) {
		if (*p == c)
			i = p - s ;
		++p ;
	}
	return (i) ;
}

void invest () {

# ifdef DOS
	gotoxy (15, LINETIM) ;
	cprintf ("00 : 00 : 00") ;
	gotoxy (55, LINETIM) ;
	cprintf ("00 : 00 : 00") ;
	itiks = biostime (0, 0L) ;
# else  /* ANYX */

# endif /* DOS */
}

void vestim () {
	register long esecs ;
	register double brat = (double) totbyts / (double) allbyts ;
	register long rtiks, rsecs ;
	long xh, xm, xs ;

# ifdef DOS
	rtiks = biostime (0, 0L) - itiks ;
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	rsecs = ( (double) rtiks / 18.2 ) ;
	ltohms (rsecs, &xh, &xm, &xs) ;
	gotoxy (55, LINETIM) ;
	cprintf ("%02ld : %02ld : %02ld", xh, xm, xs) ;
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	esecs = ( ( brat * rtiks ) / 18.2 ) ;
	ltohms (esecs, &xh, &xm, &xs) ;
	gotoxy (15, LINETIM) ;
	cprintf ("%02ld : %02ld : %02ld", xh, xm, xs) ;
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
# else  /* ANYX */

# endif /* DOS */
}

void ltohms (ns, ph, pm, ps) long ns ; long * ph, * pm, * ps ; {

	*ph = *pm = *ps = 0L ;

	if ((*ph = ns / 3600) > 0L)
		ns -= *ph * 3600 ;

	if ((*pm = ns / 60) > 0L)
		ns -= *pm * 60 ;

	*ps = ns ;
}

# endif /* COMMENT */
/**********************************************************************/
/*
 * vi:nu ts=4
 */
