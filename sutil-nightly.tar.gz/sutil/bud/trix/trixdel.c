/************************************************************************
*	trixdel.c + ...														*
************************************************************************/

# include	<stdio.h>

# ifdef     ANYX
# include   <unistd.h>
# endif     /* ANYX */

# include	"trix.h"
# include	"trixkeys.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixasci.h"

/*											 _______________________
 *											|						|
 *											|	delete file ...		|
 *											|_______________________|
 */

int delfil (fp, flgs) FILDAT * fp ; int flgs ; {
	REG int grd ;
	char tb [ 80 ] ;

# ifdef ANYX

    REG char * pp ;

    pp = fp->fd_dir->dd_path ;

    if ( access (pp, W_OK) < 0 ) {
		grd = trixerr (T_ENWDIR, pp, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
	}

# endif /* ANYX */

	if (flgs & CONFLG) {	/* confirm deletion flag */
it :
		sprintf (tb, T_CONDEL, fp->fd_path) ;
		grd = askyn (tb, T_RUSURE) ;

		switch (grd) {
			case ENTER :
			case NOPE  : return -1 ;
			case CTRL_Q :
			case ESC   : return ESC ;
			case YEAH  : break ;
			case '?'  :
			case KF1   : hyxhelp ("delfil") ; goto it ;
		}
	}
	if ( unlink ( fp->fd_path ) < 0 ) {
		grd = trixerr (T_CANTRM, fp->fd_path, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
	}
	return 0 ;
}
/*******************************************************************/
/*
 * vi:nu ts=4
 */
