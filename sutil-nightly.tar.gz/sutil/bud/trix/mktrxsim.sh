set -x
cc -DCYGWIN -DCURSWIOS -o trxsim_c trixsimw.c -lncurses
cc -DUBUNTU -DCURSWIOS -o trxsim_c trixsimw.c -lcurses
cc -DUBUNTU -DBLESWIOS -o trxsim_b trixsimw.c ~/lib/libabx.a -ltermcap
