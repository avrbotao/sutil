/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixhelp.c + hypertext crosslink help system ...	|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */
# include	<stdio.h>
# include   <string.h>

# ifdef     DOS
# include	<sys/types.h>
# include	<sys/stat.h>
# include	<conio.h>
# endif     /* DOS */

# ifdef     XENIX
#   include <unistd.h>
# endif     /* XENIX */

# ifdef     SIDIX
#   include <unistd.h>
# endif     /* SIDIX */

# ifdef     SIX
#   include <unistd.h>
# endif     /* SIX */

# ifdef     DIGIX
#   include <unistd.h>
# endif     /* DIGIX */

# include	"trix.h"
# include	"trixfunc.h"
# include	"trixtext.h"
# include	"trixblue.h"
# include	"trixwind.h"
# include	"trixkeys.h"
# include	"trixchrs.h"
# include	"trixext.h"
# include	"trixasci.h"
# include	"trixwig.h"

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

# define	HELPAGES	50
# define	LINSIZ		TEBSIZ

# define	TMARK		'+'
# define	IMARK		'`'
# define	XFMARK		'`'

# define    TOPINDEX	'i'
# define    NEXTOPIC	'n'
# define    LASTOPIC	'l'
# define    QUITOPIC	 0
# define    BADTOPIC	-1

# define	NOCODOFS	( VZRO (CODOFS *) )

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

typedef  struct codofs  CODOFS ;

struct codofs {
	long hh_cod ;
	long hh_ofs ;
	CODOFS * hh_last ;
} ;

typedef  struct topyx  TOPYX ;

struct topyx {
	int vl ;
	int vc ;
	char bufic [40] ;
} ;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

		char *		dathelp = "trixhelp.dat" ;
		char *		daxhelp = "trixhelp.dax" ;

		FILE *		htfp = NOFILE , * hxfp = NOFILE ;
		int			htabwid = 8 ;
		int			nohelp ;
		long		ncodofs ;
		CODOFS *	lastopic = (CODOFS *) 0 ;
		CODOFS *	hxb ;
		char		hhinfo [80] ;
		char		hhcofs [80] ;
		char		nextopic [80] ;
		WWINFO *	hwwp = NOWWP ;

EXT		int			vdotyp ;
EXT     char        altgcs [] ;
EXT     char        gtfpn  [] ;
EXT		char *		ghelpt ;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

# ifdef		ANSI

		void		revvideo	(void) ;

		int			hyxmake		(char *, char *) ;
		int			hyxopen		(char *, char *) ;
		int			hyxhelp		(char *) ;
		void		hyxclos		(void) ;
		int			hyxplay		(CODOFS *) ;
		int			hyxcmp		(CODOFS *, CODOFS *) ;

# else		/* OLD STYLE */

		void		revvideo	( ) ;

		int			hyxmake		( ) ;
		int			hyxopen		( ) ;
		int			hyxhelp		( ) ;
		void		hyxclos		( ) ;
		int			hyxplay		( ) ;
		int			hyxcmp		( ) ;

# endif		/* ANSI */
/*
 *	|---------------------------------------------------------------|
 *	|	+ must detect aut/y if *.dat is newer than *.dax so we		|
 *	|	  hyxmake() with due reason ...								|
 *	|	+ when cmds get cfg'abl, there must be a way 2 link d		|
 *	|	  nu-cfg'ed-cmd-key 2 d help text. if it proves 2 b as hard	|
 *	|	  as it seems, then just leave that work 2 the user ...		|
 *  |---------------------------------------------------------------|
 */
void inithelp () {

# ifdef XTRC
	fprintf (trcfp, "inithelp()\r\n") ;
# endif

# ifdef COMMENT
	if (vflg) {
		printf ("+ HYPERHELP ... ") ;
		fflush (stdout) ;
	}
# endif /* COMMENT */

	nohelp = FALSE ;

	if (hyxopen (dathelp, daxhelp) == -1) {
		if (hyxmake (dathelp, daxhelp) == -1) {
			nohelp = TRUE ;
		} else {
			if (hyxopen (dathelp, daxhelp) == -1) {
				nohelp = TRUE ;
			}
		}
	}

# ifdef COMMENT
	if (vflg) {
		if (nohelp)
			printf ("ERRO !\n") ;
		else
			printf ("OK !\n") ;
	}
# endif /* COMMENT */
}
/*
 *	|---------------------------------------------------------------|
 *	|	...															|
 *  |---------------------------------------------------------------|
 */
int hyxopen (info, cofs) char * info , * cofs ; {
	struct STAT stabuf ;
	long hxsz ;

	if (htfp != NOFILE)
		return -1 ;
	if ( ( htfp = trixfopen (info, "r") ) == NOFILE )
		return -1 ;
	if ( ( hxfp = trixfopen (cofs, "rb") ) == NOFILE )
		goto nox ;
	if (FSTAT (fileno (hxfp), &stabuf) == -1)
		goto nox ;
	hxsz = stabuf.st_size ;
	if ( ( hxb = (CODOFS *) malloc ( (unsigned) hxsz ) ) == NOCODOFS )
		goto nox ;
	if (fread ((char *) hxb, 1, (int) hxsz, hxfp) != (size_t)hxsz)
		goto nox ;

	fclose (hxfp) ; hxfp = NOFILE ; ncodofs = hxsz / sizeof (CODOFS) ;
	return 0 ;
nox:
	if (hxfp != NOFILE) {
		fclose (hxfp) ; hxfp = NOFILE ;
	}
	fclose (htfp) ; htfp = NOFILE ;
	return -1 ;
}
/*
 *	|---------------------------------------------------------------|
 *	|	...															|
 *  |---------------------------------------------------------------|
 */
int hyxhelp (what) char * what ; {
	CODOFS * rp ;
	CODOFS z ;
	char * ptopic = what ;
	int rd ;

	if (nohelp)
		return -1 ;

	if (ghelpt != NOSTR)
		ptopic = ghelpt ;

	if (ptopic == NOSTR)
		ptopic = T_NOHELP ;

	hwwp = NOWWP ;
srch :
	z.hh_cod = strcod (ptopic) ;

	rp = (CODOFS *) bsearch ( (void *) &z , (void *) hxb ,
							 (size_t) ncodofs ,
							 (size_t) sizeof (CODOFS) , hyxcmp ) ;

	if (rp == (CODOFS *) 0) {
		ptopic = /* "Indice" */ T_NOHELP ;
		goto srch ;
	}

	rp->hh_last = lastopic ;
play :
	rd = hyxplay (rp) ;

	switch (rd) {
		case TOPINDEX :
		case NEXTOPIC : ptopic = nextopic ; goto srch ;
		case LASTOPIC : rp = rp->hh_last ;  goto play ;
		case BADTOPIC : return -1 ;
/*		case QUITOPIC : return  0 ;		*/
	}

	wwclos (hwwp) ; hwwp = NOWWP ;
	return 0 ;
}

/*										 ___________________________
 *										|							|
 *										|	play hyperhelp ...		|
 *			                    		|___________________________|
 */

int hyxplay (tp) CODOFS * tp ; {

	REG int			hrd, key = 0 , vlin , vcol , ktopg, k, j ;
		char		linbuf [LINSIZ] , titbuf [LINSIZ] , expbuf [LINSIZ] ;
	REG char * 		xp , * yp ;
		TOPYX		pgtopix [50] ;
	REG TOPYX *		tonp = pgtopix ;
		char		tb [80] ;
	REG int			pgx, ateoh = FALSE ;
		long		pgofs [HELPAGES] ;

	for ( pgx = 0 ; pgx < HELPAGES ; ++pgx )
		pgofs [pgx] = 0L ;

	pgx = 0 ;

	/*
	 *	seek on topic, get title & strip nl ...
	 */

	if (fseek (htfp, tp->hh_ofs, SEEK_SET) != 0)
		return BADTOPIC ;

	xp = fgets (titbuf, LINSIZ, htfp) ;
	strend (titbuf, "\r\n") ;

	/*
	 *	open help window, frame it out ...
	 */

	if (hwwp == NOWWP) {

		hwwp = wwopen (_l_hlpbox, _c_hlpbox, _hlpwlen, _hlpwhei) ;

		if (vdotyp == 't')
			wwfram (hwwp, WW_REVERSE) ;
		else
			wwfram (hwwp, BGFG (LIGHTGRAY, BLACK)) ;

		if (vdotyp == 't')
			wwsatr (hwwp, WW_REVERSE) ;
		else
			wwsatr (hwwp, BGFG (LIGHTGRAY, BLACK)) ;

		j = ( _hlpwlen - strlen (T_HLPTIT) ) / 2 ;
		wwgoyx (hwwp, 0, j) ;
		wwputs (hwwp, T_HLPTIT) ;
	}

/*	wwfill (hwwp, C_GSPC, WW_NORMAL) ;	*/

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	display top topic title & bottom pf guideline ...	|
 *	|_______________________________________________________|
 */

	if (vdotyp == 't')
		wwsatr (hwwp, WW_REVERSE) ;
	else
		wwsatr (hwwp, BGFG (LIGHTGRAY, BLACK)) ;

	tb[0] = ' ' /* C_GSPC */ ;
	strpad (&tb[1], &titbuf[1], _hlpwlen-3) ;

	wwgoyx (hwwp, 1, 1) ;
	wwputs (hwwp, tb) ;

	/* - - - - - - - - - - - - - - - - - - - - - - - - */

	strpad (&tb[1], T_HELPFMB, _hlpwlen-3) ;

	wwgoyx (hwwp, _hlpwhei-2, 1) ;
	wwputs (hwwp, tb) ;

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	collect offset & display a windowfull of help text ...	|
 *	|___________________________________________________________|
 */

codp :

	if (pgofs[pgx] == 0L)
		pgofs[pgx] = ftell (htfp) ;

	if (vdotyp == 't')
		wwsatr (hwwp, WW_NORMAL) ;
	else
		wwsatr (hwwp, BGFG (BLACK, LIGHTGRAY)) ;

	vlin = 1 ; j = 0 ;

	for ( ; ; ++j ) {

		if (j >= _hlpwhei-4)
			break ;

		if (fgets (linbuf, LINSIZ, htfp) == NOSTR) {
			ateoh = TRUE ;
			break ;
		}

		if (linbuf[0] == TMARK) {
			ateoh = TRUE ;
			break ;
		}

		strend (linbuf, "\r\n") ;
		++vlin ; vcol = 1 ;
		wwgoyx (hwwp, vlin, 1) ;
		tabexp (expbuf, linbuf, htabwid) ;

		for ( xp = expbuf , k = 0 ; *xp ; ++xp , ++k ) {

			if (k >= _hlpwlen-2)
				break ;

			if (*xp == IMARK) {

				if (vdotyp == 't')
					wwsatr (hwwp, WW_HIGHLIGHT) ;
				else
					wwsatr (hwwp, BGFG (BLACK, WHITE)) ;

				++xp ; ++k ; yp = tonp->bufic ;
				tonp->vl = vlin ; tonp->vc = vcol ;

				do {
					wwputq (hwwp, *xp) ;
					*yp++ = *xp ;
					++xp ; ++k ; ++vcol ;
				} while (*xp != XFMARK) ;

				if (vdotyp == 't')
					wwsatr (hwwp, WW_NORMAL) ;
				else
					wwsatr (hwwp, BGFG (BLACK, LIGHTGRAY)) ;

				*yp = '\0' ; ++tonp ; k -= 2 ;

			} else {

/*              if (*xp >= ' ' && *xp <= '~')	*/
					++vcol ;
					wwputq (hwwp, *xp) ;

			} /* endif (topic mark) */

		} /* endof for (scan help line) */

		/*
		 *	clear to e-o-helpline ...
		 */

		while (k < _hlpwlen-2) {
			wwputq (hwwp, ' ' /* C_GSPC */) ; ++k ;
		}

	} /* endof for (read help lines) */

	/*
	 *	clear to e-o-helpwindow ...
	 */

	memset (tb, ' ' /* C_GSPC */, _hlpwlen-2) ;
	tb[_hlpwlen-2] = '\0' ;

	while (j < _hlpwhei-4) {
		wwgoyx (hwwp, ++vlin, 1) ;
		wwputs (hwwp, tb) ; ++j ;
	}

	/*
	 *	interface loop ...
	 */

	ktopg = (int) (tonp - pgtopix) ; tonp = pgtopix ;

	for ( ; ; ) {

		if (ktopg > 0) {
			if (vdotyp == 't')
				wwdisp (hwwp, tonp->vl, tonp->vc, tonp->bufic, WW_REVERSE) ;
			else
				wwdisp (hwwp, tonp->vl, tonp->vc, tonp->bufic, BGFG (LIGHTGRAY, BLACK)) ;
		}

		key = getkey () ;

		if (ktopg > 0) {
			if (vdotyp == 't')
				wwdisp (hwwp, tonp->vl, tonp->vc, tonp->bufic, WW_HIGHLIGHT) ;
			else
				wwdisp (hwwp, tonp->vl, tonp->vc, tonp->bufic, BGFG (BLACK, WHITE)) ;
		}

		switch (key) {

			case KF3 :
			case '\t' :	/* tab = next topic */
			case '2' :
			case KDOWN :
			case '6' :
			case KRIGHT :
				if (ktopg > 0) {
					++tonp ;
					if ((tonp - pgtopix) >= ktopg)
						tonp = pgtopix ;
				}
			break ;

			case '\b' :	/* bs = previous keyword */
			case '4' :
			case KLEFT :
			case '8' :
			case KUP :
				if (ktopg > 0) {
					if (tonp > pgtopix)
						--tonp ;
					else
						tonp = pgtopix + (ktopg - 1) ;
				}
			break ;

			case '?'  :
			case KF1 :	/* pick topic */
			case '\n' :
			case '\r' :
				if (ktopg > 0) {
					lastopic = tp ;
					strcpy (nextopic, tonp->bufic) ;
					hrd = NEXTOPIC ; goto eohp ;
				}
			break ;

			case 'i' :
			case 'I' :
			case KF2 :	/* help index */
				lastopic = tp ;
				strcpy (nextopic, T_HLPINX) ;
				hrd = TOPINDEX ; goto eohp ;
		/*	break ;	*/

			case 'L' :
			case 'l' : /* last topic ... */
			case 'u' :
			case 'U' :
			case KF4 :
				if (tp->hh_last != (CODOFS *) 0) {
					hrd = LASTOPIC ; goto eohp ;
				}
			break ;

			case '3' :
			case KPGDN :
				if (! ateoh) {
					++pgx ;
					goto codp ;
				}
			break ;

			case '9' :
			case KPGUP :
				if (pgx > 0) {
					--pgx ; ateoh = FALSE ;
					fseek (htfp, pgofs[pgx], SEEK_SET) ;
					goto codp ;
				}
			break ;

			case '\033' : /* ESC , ^Quit */
			case CTRL_Q :
				lastopic = tp ;
				hrd = QUITOPIC ; goto eohp ;
		}
	}
eohp :
	return hrd ;
}
/*
 *	|---------------------------------------------------------------|
 *	|	...															|
 *  |---------------------------------------------------------------|
 */
void endhelp () {

	hyxclos () ;
}

void hyxclos () {

	if (nohelp == TRUE)
		return ;

	fclose (htfp) ;	htfp = NOFILE ;
	free ((char *) hxb) ; hxb = NOCODOFS ;
}
/*
 *	|---------------------------------------------------------------|
 *	|	...															|
 *  |---------------------------------------------------------------|
 */
int hyxcmp (a, b) CODOFS * a , * b ; {

	return (int) a->hh_cod - (int) b->hh_cod ;
}
/*
 *	|---------------------------------------------------------------|
 *	|	...															|
 *  |---------------------------------------------------------------|
 */
# define    USEGPN

int hyxmake (info, cofs) char * info , * cofs ; {

	char lin [LINSIZ] ;
	struct STAT stabuf ;
	long hxsz ;
	long ofs ;
	CODOFS tt ;
	int ll ;
    char xpn [80] ;

/*	printf ("**** opening & creating ...\n") ;	*/

	if (htfp != NOFILE)
		return -1 ;
	if ( ( htfp = trixfopen (info, "r") ) == NOFILE )
		return -1 ;
	if ( ( hxfp = trixfopen (cofs, "wb") ) == NOFILE )
		goto nox ;
# ifdef USEGPN
    strcpy (xpn, gtfpn) ;
# endif /* USEGPN */

/*	printf ("**** processing cross-links ...\n") ;	*/

	ofs = ftell (htfp) ;
	while (fgets (lin, LINSIZ, htfp) != NOSTR) {
		if (lin[0] == TMARK) {
			ll = strlen (lin) - 1 ;
			if (lin[ll] == '\n')
				lin[ll] = '\0' ;
			tt.hh_cod = strcod (&lin[1]) ;
			tt.hh_ofs = ofs ;
			fwrite ( (void *) &tt, 1, sizeof (CODOFS), hxfp) ;
		}
		ofs = ftell (htfp) ;
	}
	fclose (htfp) ; fclose (hxfp) ; htfp = NOFILE ;

/*	printf ("**** mallocing & reading back ...\n") ;	*/

# ifdef USEGPN
	hxfp = fopen (xpn, "rb") ;
# else  /* OK */
	hxfp = trixfopen (cofs, "rb") ;
# endif /* COMMENT */
	if (FSTAT (fileno (hxfp), &stabuf) == -1)
		goto nox ;
	hxsz = stabuf.st_size ;
	ncodofs = hxsz / sizeof (CODOFS) ;
	if ( ( hxb = (CODOFS *) malloc ( (unsigned) hxsz ) ) == NOCODOFS )
		goto nox ;
	if (fread ((char *) hxb, 1, (int) hxsz, hxfp) != (size_t)hxsz)
		goto nox ;
	fclose (hxfp) ;

/*	printf ("**** sorting ...\n") ;	*/

	qsort ((char *) hxb, (size_t) ncodofs,
            (size_t) sizeof (CODOFS), hyxcmp) ;

/*	printf ("**** writing back sorted ...\n") ;	*/

# ifdef USEGPN
	hxfp = fopen (xpn, "wb") ;
# else  /* OK */
	hxfp = trixfopen (cofs, "wb") ;
# endif /* COMMENT */
	fwrite ((char *) hxb, 1, (int) hxsz, hxfp) ;
	fclose (hxfp) ; hxfp = NOFILE ;

# ifdef ANYX

    if (chown (xpn, realuid, realgid) < 0) {
        unlink (cofs) ;
		trixerr (T_ESUGID, cofs, errno, BANAL) ;
        goto nox ;
    }

# endif /* ANYX */

	return 0 ;
nox:
	if (hxfp != NOFILE) {
		fclose (hxfp) ; hxfp = NOFILE ;
	}
	fclose (htfp) ; htfp = NOFILE ;
	return -1 ;

} /* endof hyxmake() */

# ifdef COMMENT
void main () {
	char what [20] , rsvp [10] ;

	for ( ; ; ) {
		printf ("\ninfo : ") ; gets (hhinfo) ;
		if (hhinfo[0] == '\0') break ;
		printf ("\ncode : ") ; gets (hhcofs) ;
		if (hhcofs[0] == '\0') break ;
		printf ("\nbuild ? ") ; gets (rsvp) ;
		if (rsvp[0] == 'y') hyxmake (hhinfo, hhcofs) ;
		if (hyxopen (hhinfo, hhcofs) == -1) return ;
		for ( ; ; ) {
			printf ("\nwhat ? ") ; gets (what) ;
			if (what[0] == '\0') break ;
			hyxhelp (what) ;
		}
		hyxclos () ;
	}
}
# endif /* COMMENT */
/*------------------------------------------------------------------*/
/*
 * vi:nu tabstop=4
 */
