/************************************************************************
*	function prototypes													*
************************************************************************/

# ifdef		ANSI

# ifdef		UNIX
char *	getcwd		( char * , int ) ;
# endif		/* UNIX */

# ifdef		OPENBSD
char *	getcwd		( char * , int ) ;
# endif

# ifdef		FREEBSD
char *	getcwd		( char * , int ) ;
# endif

# ifdef		CYGWIN
char *	getcwd		( char * , int ) ;
# endif

# ifdef		LINUX
char *	getcwd		( char * , int ) ;
# endif

void	initrix		( void ) ;
void	frescrn		( ULONG , DIRDAT * , FILDAT * ) ;
void	trix		( void ) ;
void	logtrix		( DIRDAT * ) ;
void	listree		( DIRDAT * ) ;
void	wabtrix		( void ) ;
void	inimfl		( DIRDAT * ) ;
void	initerm		( void ) ;
void	reseterm	( void ) ;
void	dispat		( int , int , char * , int , int ) ;
void	locat		( int , int ) ;
void	honk		( void ) ;
void	xbanner		( void ) ;
void	xsectrl 	( void ) ;
void	drawfenc	( int ) ;
void	epilog		( void ) ;
void	hidecursor	( void ) ;
void	showcursor	( void ) ;
void	sizecursor	( int, int ) ;
void	erasecho	( int ) ;
void	fliptot		( int ) ;
void	flipcur		( int ) ;
void	flipfram	( void ) ;
void	flipath		( int ) ;
void	flipcmb		( int ) ;
void	flipfmb		( int ) ;
void	bigwfram	( void ) ;
void	divfram		( void ) ;
void	wipefram	( void ) ;
void	initban		( void ) ;
void	rescreen	( DIRDAT * , FILDAT * ) ;
void	disptree	( void ) ;
void	byechk		( void ) ;
void	initsigs	( void ) ;
void	trixfam		( void ) ;
void	chtermod	( int ) ;
void	trixsort	( void ) ;
void	trixpan		( int ) ;
void    initmsg     ( void ) ;
void    inithelp    ( void ) ;
void    initown     ( void ) ;
void    inithist    ( void ) ;
void    endhist     ( void ) ;
void    endhelp     ( void ) ;
void    initvdo     ( void ) ;
void    initxt		( void ) ;
void	switfram	( void ) ;
void	strpad		( char * , char * , int ) ;
void    pcharset    ( void ) ;
void	isdestin	( char * ) ;
void	udirdat		( DIRDAT * , FILDAT * , int ) ;
void    putbox      ( int , int , int , int ) ;
void    protboxs    ( void ) ;
void	addhist		( char * , char * ) ;
void	tabexp		( char * , char * , int ) ;
void	strend		( char * , char * ) ;
void	chkover		( FILDAT * ) ;
void	initseal	( void ) ;

char *	xltoa		( long , int , int ) ;
# ifdef BIGTRX
char *	xlltoa		( _INT64_ , int , int ) ;
# endif
char *	isdir		( char * , STABLK * ) ;
char *	trixdm		( unsigned ) ;
char *	trixhist	( char * , int ) ;
char *	xmemchr		( char * , int , int ) ;
char *	exetag		( void ) ;

# ifdef ANYX
char *	trixtm		( long ) ;
# else  /* DOS */
char *	trixtm		( unsigned, unsigned ) ;
# endif /* ANYX */

long	strcod		( char * ) ;

int		rootrix		( char * ) ;
int		filwut		( DIRDAT * , int ) ;
int		dilcmp		( DIRDAT * * , DIRDAT * * ) ;
int		namcmp		( FILDAT * * , FILDAT * * ) ;
int		extcmp		( FILDAT * * , FILDAT * * ) ;
int		sizcmp		( FILDAT * * , FILDAT * * ) ;
int		timcmp		( FILDAT * * , FILDAT * * ) ;
int		torcmp		( FILDAT * * , FILDAT * * ) ;
int		owncmp		( void * , void * ) ;
int		grpcmp		( void * , void * ) ;
int		keycmp		( void * , void * ) ;
int		patmat		( char * , char * ) ;
# ifndef TRIXKEY
int		getkey		( void ) ;
# endif  /* ! TRIXKEY */
int		trixgets	( char * , int , char * , int , int ) ;
int		xoutc		( int ) ;
int		geds		( int , int , char * , int , int ) ;
int		askyn		( char * , char * ) ;
int		vaskyn		( char * , char * ) ;
int		askany		( char * , char * ) ;
int		asktxt		( char * , char * , char * , int , int ) ;
int		askok		( char * , char * ) ;
int		renfil		( char * , char * ) ;
int		delfil		( FILDAT * , int ) ;
int		copfil		( FILDAT * , char * , int ) ;
int		trixvue		( FILDAT * ) ;
int		trixerr		( char * , char * , int , int ) ;
int		trixexec	( FILDAT * ) ;
int		trixord		( int ) ;
int		trixshel	( void ) ;
int		trixren		( FILDAT * ) ;
int		trixdest	( FILDAT * , char * , int ) ;
int		movfil		( FILDAT * , char * , int );
int		xmovfil		( char * , char * ) ;
int		trixedit	( FILDAT * ) ;
int		trixebit	( FILDAT * ) ;
int		trixprint	( FILDAT * ) ;
int     proted      ( FILDAT * , DIRDAT * , int ) ;
int     protfil     ( FILDAT * , UNS , int , DIRDAT * , int ) ;
int		histcmp		( void * , void * ) ;
int		hyxhelp		( char * ) ;
int		logcwd		( DIRDAT * ) ;
int		trixmkdir	( DIRDAT * ) ;
int		xmkdir		( DIRDAT * , char * ) ;
int		xstatus		( char * , STABLK * ) ;
int		trixrmdir	( DIRDAT * ) ;
int		xrmdir		( DIRDAT * ) ;
int		trixcd		( char * ) ;
int		trixrun		( char * ) ;
int		runtag		( FILDAT * , char * ) ;

FILE *  trixfopen   ( char * , char * ) ;

# else		/* GOOD'OL STYLE */

# ifdef		UNIX
char *	getcwd		( ) ;
# endif		/* UNIX */

# ifdef		FREEBSD
char *	getcwd		( ) ;
# endif

# ifdef		CYGWIN
char *	getcwd		( ) ;
# endif

# ifdef		LINUX
char *	getcwd		( ) ;
# endif

void	initrix		( ) ;
void	frescrn		( ) ;
void	trix		( ) ;
void	logtrix		( ) ;
void	listree		( ) ;
void	wabtrix		( ) ;
void	inimfl		( ) ;
void	initerm		( ) ;
void	reseterm	( ) ;
void	dispat		( ) ;
void	locat		( ) ;
void	honk		( ) ;
void	xbanner		( ) ;
void	xsectrl 	( ) ;
void	drawfenc	( ) ;
void	epilog		( ) ;
void	hidecursor	( ) ;
void	showcursor	( ) ;
void	sizecursor	( ) ;
void	erasecho	( ) ;
void	fliptot		( ) ;
void	flipcur		( ) ;
void	flipfram	( ) ;
void	flipath		( ) ;
void	flipcmb		( ) ;
void	flipfmb		( ) ;
void	bigwfram	( ) ;
void	divfram		( ) ;
void	wipefram	( ) ;
void	initban		( ) ;
void	rescreen	( ) ;
void	disptree	( ) ;
void	byechk		( ) ;
void	initsigs	( ) ;
void	trixfam		( ) ;
void	chtermod	( ) ;
void	trixsort	( ) ;
void	trixpan		( ) ;
void    initmsg     ( ) ;
void    inithelp    ( ) ;
void    initown     ( ) ;
void    inithist    ( ) ;
void    endhist     ( ) ;
void    endhelp     ( ) ;
void    initvdo     ( ) ;
void    initxt		( ) ;
void	switfram	( ) ;
void	strpad		( ) ;
void    pcharset    ( ) ;
void	isdestin	( ) ;
void	udirdat		( ) ;
void    putbox      ( ) ;
void    protboxs    ( ) ;
void	addhist		( ) ;
void	tabexp		( ) ;
void	strend		( ) ;
void	chkover		( ) ;
void	initseal	( ) ;

char *	xltoa		( ) ;
# ifdef BIGTRX
char *	xlltoa		( ) ;
# endif
char *	isdir		( ) ;
char *	trixdm		( ) ;
char *	trixhist	( ) ;
char *	trixtm		( ) ;
char *	xmemchr		( ) ;
char *	exetag		( ) ;

long	strcod		( ) ;

int		rootrix		( ) ;
int		filwut		( ) ;
int		dilcmp		( ) ;
int		namcmp		( ) ;
int		extcmp		( ) ;
int		sizcmp		( ) ;
int		timcmp		( ) ;
int		torcmp		( ) ;
int		owncmp		( ) ;
int		grpcmp		( ) ;
int		keycmp		( ) ;
int		patmat		( ) ;
# ifndef TRIXKEY
int		getkey		( ) ;
# endif  /* ! TRIXKEY */
int		trixgets	( ) ;
int		xoutc		( ) ;
int		geds		( ) ;
int		askyn		( ) ;
int		vaskyn		( ) ;
int		askany		( ) ;
int		asktxt		( ) ;
int		askok		( ) ;
int		renfil		( ) ;
int		delfil		( ) ;
int		copfil		( ) ;
int		trixvue		( ) ;
int		trixerr		( ) ;
int		trixexec	( ) ;
int		trixord		( ) ;
int		trixshel	( ) ;
int		trixren		( ) ;
int		trixdest	( ) ;
int		movfil		( );
int		xmovfil		( ) ;
int		trixedit	( ) ;
int		trixebit	( ) ;
int		trixprint	( ) ;
int     proted      ( ) ;
int     protfil     ( ) ;
int		histcmp		( ) ;
int		hyxhelp		( ) ;
int		logcwd		( ) ;
int		trixmkdir	( ) ;
int		xmkdir		( ) ;
int		xstatus		( ) ;
int		trixrmdir	( ) ;
int		xrmdir		( ) ;
int		trixcd		( ) ;
int		trixrun		( ) ;
int		runtag		( ) ;

FILE *  trixfopen   ( ) ;

# endif		/* ANSI */
