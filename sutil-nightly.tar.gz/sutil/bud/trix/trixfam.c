/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixfam.c + regular expression file specification	|
 *		|				pattern family selection & matching ...	|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include	<stdio.h>
# include	<string.h>

# include	"trixasci.h"
# include	"trix.h"
# include	"trixstd.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixkeys.h"
# include	"trixtext.h"

EXT		int			( * filcmp ) () ;
EXT		DIRDAT * *	wablst ;
EXT		char *		ghyid ;
EXT		char *		ghelpt ;
/*
 *	|---------------------------------------------------------------|
 *	|	+ fut/y we must accept many reg.exprs. blank-sep'ed ...		|
 *	|	  (like xt's "*.com *.exe ...")								|
 *	|---------------------------------------------------------------|
 */
void trixfam () {
	REG	FILDAT * *	tmlp ;
	REG	FILDAT * *	emlp ;
	REG FILDAT * tfp ;
	REG DIRDAT * *	wabp = wablst ;
	REG DIRDAT * *	wabe = wabp + (int) (TOTDIRS) ;
	REG DIRDAT *	dp ;
	REG long		tmx = 0L ;
	REG long		totmfk = 0L ;
	REG	long		totmfb = 0L ;
	REG long		xmfk = 0L ;
	REG	long		xmfb = 0L ;
	REG int			ns , maxns, grd ;
	REG int			copy = FALSE ;
		char		tmpat [40] ;

	strcpy (tmpat, rgxpat) ;

	ghelpt = T_FAMOF ;
	ghyid = "fam" ;
	grd = trixgets (T_PATBAN, 'm', tmpat, 20, USEBUF) ;
	ghyid = NOSTR ;
	ghelpt = NOSTR ;

	if (grd == ESC)
		return ;
	if (grd == KF8) {
		strcpy (tmpat, ALLFIL) ;
		copy = TRUE ;
	} else if (grd != ENTER)
		return ;

	for ( ; wabp < wabe ; ++wabp ) {
		dp = *wabp ;

		if (dp->dd_flg & UNREADIR)
			continue ;

		tmlp = dp->dd_mfl ; emlp = dp->dd_fil ; tmx = dp->dd_fik ;
		xmfk = xmfb = 0L ; ns = maxns = 0 ;

		if (copy) {
			dp->dd_mfk = dp->dd_fik ;
			dp->dd_mfb = dp->dd_fib ;
# ifdef XENIX
			memcpy ( ( char * ) dp->dd_mfl, ( char * ) dp->dd_fil,
					 ( int ) ( dp->dd_fik * sizeof (FILDAT *) ) ) ;
# else  /* ! XENIX */
			memcpy (dp->dd_mfl, dp->dd_fil,
					((unsigned)dp->dd_fik * sizeof (FILDAT *))) ;
# endif /* XENIX */
			qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
					sizeof (FILDAT *), filcmp) ;
			totmfk += dp->dd_mfk ; totmfb += dp->dd_mfb ;
			while (tmx--) {
				tfp = *emlp++ ;
				if ( ( ns = strlen (tfp->fd_nam) ) > maxns)
					maxns = ns ;
			}
			dp->dd_maxlen = maxns ;
			continue ;
		}

		while (tmx--) {
			tfp = *emlp++ ;
			if (patmat (tfp->fd_nam, tmpat) == TRUE) {
				xmfb += tfp->fd_stabuf.STASIZ ;
				tfp->fd_mix = xmfk ;
				++xmfk ; *tmlp++ = tfp ;
				if ( ( ns = strlen (tfp->fd_nam) ) > maxns)
					maxns = ns ;
			}
		}
		dp->dd_mfk = xmfk ; dp->dd_mfb = xmfb ; dp->dd_maxlen = maxns ;
		qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
				sizeof (FILDAT *), filcmp) ;
		totmfk += xmfk ; totmfb += xmfb ;
	}
	MATFILS = totmfk ; MATBYTS = totmfb ;
	strcpy (rgxpat, tmpat) ;
	frescrn (UDRGXP, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
}
/************************************************************************/
