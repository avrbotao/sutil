
/*				 ___________________________________________________
 *  __________  |													|
 * /\  _______\	|	TRIX + directory & file administration utility	|
 * \ \ \____  /	|---------------------------------------------------|
 *	\ \ \/ / /	|	trix.c + main entry point, setup & startup ...	|
 *   \ \/ / /	|---------------------------------------------------|
 *	  \  / /	|	TRIX & the TRIX logo are registered trademarks	|
 *	   \/_/		|	of Alexandre Victor Rodrigues Botao (1991)		|
 *				|___________________________________________________|
 */

# include	<stdio.h>
# include	<string.h>
# include	<signal.h>
# include	<stdlib.h>

# include	"trixasci.h"
# include	"trixaloc.h"
# include	"trix.h"
# include	"trixcfg.h"
# include	"trixblue.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixwind.h"
# include	"trixwig.h"
# include	"trixchrs.h"

EXT		int			qflg ;
EXT		int			nflg ;
EXT		int			uflg ;
EXT		int			eflg ;
EXT		int			gflg ;
EXT		int			pflg ;
EXT		int			sflg ;
EXT     int         Tflg ;
EXT		int			topn ;
EXT		int			ascord ;
EXT     int         curwax ;
EXT     int         cmask ;
EXT     int         jkey ;

EXT		int			( * filcmp ) () ;

# ifdef		TC
EXT		void		intrap () ;			/* trap 4 interrupt ...			*/
# else		/* ANYX */
EXT		SIGHANTYP	intrap () ;			/* trap 4 interrupt ...			*/
# endif		/* TC */

EXT		TRXSIZ		totdirs ;
EXT		TRXSIZ		totfils ;
EXT		TRXSIZ		totbyts ;

EXT		DIRDAT * *	wablst ;
EXT		DIRDAT * *	wabptr ;

EXT		TOPDAT * *	tops ;

EXT     CFGIT       cfglst [ ] ;

EXT		char		altgcs [ ] ;
EXT		char		origwd [ ] ;
EXT		char *		currwd ;
EXT		char * *	piclst ;
EXT		char * *	picptr ;

char * avrb			=	"(C) 1991-2014 Alexandre V. R. Botao" ;
char * avrbfoss		=	"(foss) 2014 alexandre botao" ;

char * execname = NULL ;

/*	 _______________________________________________________________
 *	|																|
 *	|	+ rootrix													|
 *	|---------------------------------------------------------------|
 *	|	+ on dos, as \ isn't quite a dir, there's no way of getting	|
 *	|	  its status (so what ?) ...								|
 *	|	+ there should be no reason to chk if isdir() when			|
 *	|	  (nam == curdir) except, perhaps, 2 acquire status info...	|
 *	|---------------------------------------------------------------|
 *	| + REKNOWN BUGS :												|
 *	| 	+ a 2nd log on d sam top gets weird status values (???)		|
 *	|_______________________________________________________________|
 */

int rootrix (nam) char * nam ; {

	REG DIRDAT * dp ;
	REG TOPDAT * topp ;
	REG char * tp ;
	REG char * xp ;
	REG char * np ;						/* dir's full pathname ptr ...	*/
	REG int ns , tx ;
	STABLK stabuf ;

# ifdef XTRC
	fprintf (trcfp, "rootrix(%s)\r\n", nam) ;
# endif

/*	 _______________________________________________________________
 *	|	+ ...														|
 *	|_______________________________________________________________|
 */

	if ((np = isdir (nam, &stabuf)) == NOSTR)
		return -1 ;
	if (FALLOP (dp, DIRDAT))
nomem :	trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;

	if (topn > 0)
		frescrn (REFIRST, VZRO (DIRDAT *), VZRO (FILDAT *)) ;

	ns = strlen (np) + 1 ;

	if (NALLOC (tp, ns))
		goto nomem ;

	dp->dd_flg = 0x0000 ; dp->dd_depth = -1 ;
	strcpy (dp->dd_path = tp, np) ;
# ifdef DOS
	strupr (tp) ;
# endif /* DOS */
/*	 _______________________________________________________________
 *	|	+ ...														|
 *	|_______________________________________________________________|
 */
	if ( ( xp = strrchr (tp, DIRSEP) ) == NOSTR ) {		/* "dir"		*/
		dp->dd_nam = tp ;
	} else {
		if (*(xp+1) != NUL) {							/* "/dir"		*/
			dp->dd_nam = xp + 1 ;
		} else {
			if (xp == tp) {								/* "/"   (root)	*/
				dp->dd_nam = tp ;
				dp->dd_flg |= DIROOT ;
			} else {									/* "dir/"		*/
				*xp = NUL ;								/*    ... "dir"	*/
				dp->dd_nam = tp ;
			}
		}
	}
/*	 _______________________________________________________________
 *	|	+ manage root array ...										|
 *	|_______________________________________________________________|
 */
	if (tops != VZRO (TOPDAT * *)) {
		tx = (topn + 1) * sizeof (TOPDAT *) ;
		tops = (TOPDAT * *) REALLOC ( (char *) tops, tx) ;

		if (tops == (TOPDAT * *) 0)
			trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;
	} else {
		if (FALLOP (tops, TOPDAT *))
			goto nomem ;
	}
	if (FALLOP (topp, TOPDAT))
		goto nomem ;

	*(tops+topn) = topp ;
	strcpy (topp->td_rxp, ALLFIL) ;
	topp->td_wax = -1 ;
	topp->td_ord = ascord = TRUE ;
	topp->td_cmp = filcmp = namcmp ;
	if (eflg)
		topp->td_cmp = filcmp = extcmp ;
/*	 ___________________________________________________________________
 *	|	+ ...															|
 *	|___________________________________________________________________|
 */
	STRUCPY (dp->dd_stabuf, stabuf) ; totdirs = 1L ;
	dp->dd_fib = dp->dd_mfb = dp->dd_tfb = totfils = totbyts = 0L ;
	dp->dd_fik = dp->dd_dik = dp->dd_mfk = dp->dd_tfk = 0 ;
	dp->dd_fil = dp->dd_mfl = (FILDAT * *) 0 ;
    dp->dd_dir = (DIRDAT *) 0 ; dp->dd_dil = (DIRDAT * *) 0 ;

	if (qflg)
		dispat (_fwlofs, _fwcofs, T_READING, 14, VEBLNK) ;

	logtrix (groot = topp->td_bot = dp) ;
/*	 ___________________________________________________________________
 *	|	+ ...															|
 *	|___________________________________________________________________|
 */
	piclst = (char * *) CALLOC ((int) totdirs, sizeof (char *)) ;
	wablst = (DIRDAT * *) CALLOC ((int) totdirs, sizeof (DIRDAT *)) ;

	if (piclst == VZRO (char * *) || wablst == VZRO (DIRDAT * *))
		goto nomem ;

	topp->td_pil = picptr = piclst ; topp->td_wal = wabptr = wablst ;
	*picptr++ = dp->dd_nam ; ++topn ;
	listree (groot) ;
/*	 ___________________________________________________________________
 *	|	+ "panoramic" pre-processing ...								|
 *	|___________________________________________________________________|
 */
	if (FALLOP (dp, DIRDAT))
		goto nomem ;
	dp->dd_path = groot->dd_path ; dp->dd_nam = groot->dd_nam ;
	dp->dd_fib = dp->dd_mfb = dp->dd_tfb = 0L ;
	dp->dd_fik = dp->dd_mfk = dp->dd_tfk = 0 ;
	dp->dd_fil = dp->dd_mfl = (FILDAT * *) 0 ;
	dp->dd_dil = (DIRDAT * *) 0 ;
	gpan = topp->td_pan = dp ;	  TOTDIRS = totdirs ;
	TOTFILS = /* MATFILS = */ totfils ;
	TOTBYTS = /* MATBYTS = */ totbyts ;

	if (! sflg) {
		MATFILS = totfils ;
		MATBYTS = totbyts ;
	}

	return 0 ;
}

/************************************************************************
*																		*
* + trix + entry [ flags & parameters ] processing ...					*
*																		*
* + flags :																*
*																		*
*	-e			: defaults 2 sort by extension							*
*	-f "pat"	: specify initial regular expression pattern			*
*	-n			: don't recurse (same as -p 0)							*
*	-d x		: max depth 2 recurse within							*
*	-q			: quiet operation										*
*	-T			: force tty-like i/o (even on monitors) - DBUG			*
*	-p			: pause with message on log security errors				*
*	-s			: speedy "dir-struct-only" log (olny count files)		*
*	-u			: ignore effective uid not root							*
*																		*
************************************************************************/

int main (argc, argv) int argc ; char * * argv ; {

	REG char *		ap = NOSTR ;
	REG char * *	argp ;
	REG int			argk ;
# ifdef XTRC
		int			rd ;
# endif

	execname = argv[0] ;

# ifdef XTRC
	trcfp = fopen ("trix.trc", "w") ;
	if (trcfp == NULL) {
		fprintf (stderr, "trx: can't open trace file\r\n") ;
		exit (-2) ;
	}
	rd = setvbuf (trcfp, NULL, _IONBF, 0) ;
	if (rd != 0) {
		fprintf (stderr, "trx: can't unbuffer trace file\r\n") ;
		exit (-3) ;
	}
	fprintf (trcfp, "main()\r\n") ;
# endif

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	pre-init parsing ...	|
 *	|___________________________|
 */
	argk = argc ;
	argp = argv ;

	if (--argk) {
		while (*++argp) {
			if (**argp == '-') {
				switch ( *((*argp)+1) ) {

					case 'G' :
					case 'g' :	gflg = TRUE ; break ;

					case 'N' :
					case 'n' :	nflg = TRUE ; break ;

					case 'Q' :
					case 'q' :	qflg = TRUE ; break ;

					case 'U' :
					case 'u' :	uflg = TRUE ; break ;

                	case 'T' :  Tflg = TRUE ; break ;
				}
			}
		}
	}

	/*___________________________________________________________________
	 *	+ prologue processing ...
	 */

	initrix () ;

	frescrn (REFIRST, VZRO (DIRDAT *), VZRO (FILDAT *)) ;

	if (! qflg)
		frescrn (UPATHDR, VZRO (DIRDAT *), VZRO (FILDAT *)) ;

	/*___________________________________________________________________
	 *	+ command line scanning & parsing ...
	 */

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch ( *((*argv)+1) ) {

                	case 'T' :  /* Tflg = TRUE ; */ break ;

					case 'G' :
					case 'g' :	/* gflg = TRUE ; */ break ;

					case 'N' :
					case 'n' :	nflg = TRUE ; break ;

					case 'Q' :
					case 'q' :	qflg = TRUE ; break ;

					case 'E' :
					case 'e' :	eflg = TRUE ; break ;

					case 's' :
					case 'S' :	sflg = TRUE ; break ;

					case 'P' :
					case 'p' :	pflg = TRUE ; break ;

					case 'Z' :	scaleflag = TRUE ; break ;

					case 'U' :
					case 'u' :	uflg = TRUE ; break ;

					case 'V' :
# ifdef COMMENT
						byechk () ;
# else
						askok ("Pressione [Enter]", "para Terminar") ;
# endif
						epilog () ; return 0 ;

					case '?' :
					default :
							trixerr (T_USAGE, NOSTR, NOWHY, BANAL) ;
							epilog () ; return -1 ;
				}
			} else {	/* process free parms ...	*/
				if (ap == NOSTR)
					ap = *argv ;

				rootrix (*argv) ;
			}
		}

		if (topn <= 0 && ap == NOSTR)
			goto lod ;
	/*___________________________________________________________________
	 *	+ intrinsic processing ...
	 */

	} else {	/* no parms nor flags ...	*/
lod :
		rootrix (origwd) ;
	}

	/*	 _______________________________________________________________
	 *	|_______+ personal processing___________________________________|
	 */

	trix () ;

	/*	 _______________________________________________________________
	 *	|_______+ epilogue processing___________________________________|
	 */

	epilog () ;
	return 0 ;

} /* endof main */

/*	 ___________________________________________________________________
 *	|___________________________________________________________________|
 */

void initrix () {

# define	T_WAITRIX	"Aguarde ..."

	printf ("\n\t%s %s %s\n\n", execname, SWVRSNO, avrbfoss) ;

	printf ("\n%s\n\n", T_WAITRIX) ;

# ifdef XTRC
	fprintf (trcfp, "initrix()\r\n") ;
# endif

# ifdef ANYX

    realuid = getuid () ; realgid = getgid () ;
    effuid = geteuid () ; effgid = getegid () ;

#ifdef PRIVENFO			/* privilege enforcement */
    if (effuid != 0) {
        fprintf (stderr, "* UID EFETIVO deve ser SUPER-USUARIO !\n\n") ;
        if (! uflg)
			exit (-1) ;
    }
#endif

    cmask = umask (0) ; umask (cmask) ;

# endif /* ANYX */

	initsigs () ;
    initxt () ;                     /* trixtext.c                       */
    initcfg (cfglst) ;				/* trixcfg.c                        */

#define BUGGYHELP
#ifdef BUGGYHELP
    inithelp () ;                   /* trixhelp.c                       */
#endif

/*
	getscrsiz ( &termrows , &termcols ) ;
*/

	wwinit () ;
	mapwig () ;

	initerm () ;

	if (getcwd (origwd, 80) == NOSTR)
		trixerr (T_EGETCWD, NOSTR, errno, FATAL) ;

	currwd = origwd ;

	initban () ;

	inithist () ;

# ifdef ANYX
	initown () ;                    /* trixown.c (passwd, group)    */
# endif /* ANYX */

# ifdef LATER
	initseal () ;					/* prodescr ... */
# endif

	flipath ('d') ;
	fliptot ('g') ;
	flipcur ('d') ;
	flipcmb ('d') ;
	flipfmb ('d') ;
}

/*	 ___________________________________________________________________
 *	|___________________________________________________________________|
 */

void initsigs () {

# ifdef XTRC
	fprintf (trcfp, "initsigs()\r\n") ;
# endif

	signal ( SIGINT , /* intrap */ SIG_IGN ) ;

# ifdef DOS
	signal ( SIGQUIT   , SIG_IGN ) ;
# else	/* ANYX */
	signal ( SIGQUIT   , intrap ) ;
# endif

# ifdef ANYX
	signal ( SIGABRT   , intrap ) ;
	signal ( SIGBUS    , intrap ) ;
	signal ( SIGFPE    , intrap ) ;
	signal ( SIGSEGV   , intrap ) ;
	if ( SIGILL != SIGSEGV )
		signal ( SIGILL    , intrap ) ;
# endif

# ifdef SIGSTKFLT
	signal ( SIGSTKFLT , intrap ) ;
# endif

}

/*	 ___________________________________________________________________
 *	|																	|
 *	|	trix + walks about & flips among the logged "tops" ...			|
 *	|___________________________________________________________________|
 */
void trix () {
	REG int topx = 0 ;
	REG int topk = topn ;

# ifdef XTRC
	fprintf (trcfp, "trix()\r\n") ;
# endif

	frescrn ((FRESCLR|REFRAME|UDHDRS), NODID, NOFID) ;

	for ( ; ; ) {

		if (topn <= 0)
			break ;

		if (topx >= topn)
			topx = 0 ;

		gtop   = *(tops+topx) ;
		groot  = gtop->td_bot ; gpan   = gtop->td_pan ;
		wablst = gtop->td_wal ; piclst = gtop->td_pil ;
		filcmp = gtop->td_cmp ; ascord = gtop->td_ord ;
		curwax = gtop->td_wax ; rgxpat = gtop->td_rxp ;

		wabtrix () ;

		if (topn > topk) {
			topk = topn ; topx = topk - 1 ;
		} else if (jkey == '>') {
			++topx ;
		} else if (jkey == '<') {
/*
 *			O---------------------------------------O
 *			|	much care must be taken fut/y when	|
 *			|	the 'release tree' cmd becomes ok,	|
 *			|	'cause getting back b4 start wraps	|
 *			|	to e-o-lst & it must be updated !!	|
 *			O---------------------------------------O
 */
			if (topx == 0) {
				topx = topk - 1 ;
			} else
				--topx ;
		}

		gtop->td_cmp = filcmp ; gtop->td_ord = ascord ;
		gtop->td_wax = curwax ;
	}
}
/***********************************************************************/
/*
 * vi:nu tabstop=4
 */
