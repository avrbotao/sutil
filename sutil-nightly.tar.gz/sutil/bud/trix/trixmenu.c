/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixmenu.c + stuff 4 well-tempered menus ...		|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre V.R. Botao                       (1991)	|
 *		|_______________________________________________________|
 */

# include	<stdio.h>

# include	<stdlib.h>

# ifdef		DOS
# include	<conio.h>
# endif		/* DOS */

# include	"trixmenu.h"
# include	"trixcmd.h"
# include	"trix.h"
# include	"trixblue.h"
# include	"trixwind.h"
# include	"trixfunc.h"
# include	"trixkeys.h"
# include	"trixchrs.h"
# include	"trixtext.h"
# include	"trixasci.h"

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT orditem [] = {

	{ 0x0000, 0, 0, 'a', CMD_ORDCUR, "Diretorio atual",		NOCMD, NOFUN, NOMNU, "Ordenar o diretorio atual" } ,
	{ 0x0000, 0, 0, 't', CMD_ORDALL, "Todos os diretorios",	NOCMD, NOFUN, NOMNU, "Ordenar todos os diretorios" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL ordmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, orditem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT edititem [] = {

	{ 0x0000, 0, 0, 't', CMD_TEDFIL, "Editor de Texto",	NOCMD, NOFUN, NOMNU, "Editar o arquivo atual com seu editor favorito" } ,
	{ 0x0000, 0, 0, 'b', CMD_BEDFIL, "Editor Binario",	NOCMD, NOFUN, NOMNU, "Ativar o editor binario (Hexadecimal/Ascii)" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           	NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL editmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, edititem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT vueitem [] = {

	{ 0x0000, 0, 0, 'a', CMD_ASCVUE, "Visor ASCII",			NOCMD, NOFUN, NOMNU, "Examinar o arquivo atual como texto ASCII" } ,
	{ 0x0000, 0, 0, 'h', CMD_BEDVUE, "Visor Hexadecimal",	NOCMD, NOFUN, NOMNU, "Examinar o arquivo em DUMP (Hexadecimal/Ascii)" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL vuemenu = { MM_BOX, 0, 0, 0, 0, 0, 0, vueitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT logitem [] = {

	{ 0x0000, 0, 0, 'o', CMD_LOGTRE, "Outra Arvore",	NOCMD, NOFUN, NOMNU, "Ler outra arvore" } ,
	{ 0x0000, 0, 0, 'a', CMD_LOGCWD, "Diretorio Atual",	NOCMD, NOFUN, NOMNU, "Ler o diretorio atual (apenas os arquivos)" } ,
	{ 0x0000, 0, 0, 's', CMD_LOGCWT, "Sub-Diretorios",	NOCMD, NOFUN, NOMNU, "Ler o diretorio atual (e seus sub-diretorios)" } ,

# ifdef COMMENT
	{ 0x0000, 0, 0, 'd', CMD_LOGDOS, "Disco DOS",		NOCMD, NOFUN, NOMNU, "Ler disco formatado pelo DOS" } ,
	{ 0x0000, 0, 0, 'z', CMD_LOGZIP, "Arquivo ZIP",	    NOCMD, NOFUN, NOMNU, "Ler arquivo ZIP" } ,
# endif /* COMMENT */

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL logmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, logitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT invitem [] = {

	{ 0x0000, 0, 0, 's', CMD_INVTAG, "Arquivos Selecionados",	NOCMD, NOFUN, NOMNU, "Inverter Arquivos Selecionados" } ,
	{ 0x0000, 0, 0, 'f', CMD_INVFAM, "Familia de Arquivos",	NOCMD, NOFUN, NOMNU, "Inverter Familia de Arquivos" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           	NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL invmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, invitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT dselitem [] = {

	{ 0x0000, 0, 0, 'a', CMD_TAGFIL, "Diretorio atual",		NOCMD, NOFUN, NOMNU, "Selecionar os arquivos do diretorio atual" } ,
	{ 0x0000, 0, 0, 't', CMD_TAGTAG, "Todos os diretorios",	NOCMD, NOFUN, NOMNU, "Selecionar todos os arquivos de todos os diretorios" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL dselmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, dselitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT fselitem [] = {

	{ 0x0000, 0, 0, 'a', CMD_TAGFIL, "Arquivo atual",		NOCMD, NOFUN, NOMNU, "Selecionar o arquivo atual" } ,
	{ 0x0000, 0, 0, 't', CMD_TAGTAG, "Todos os arquivos",	NOCMD, NOFUN, NOMNU, "Selecionar todos os arquivos deste diretorio" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL fselmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, fselitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT duntitem [] = {

	{ 0x0000, 0, 0, 'a', CMD_UNTFIL, "Diretorio atual",		NOCMD, NOFUN, NOMNU, "Desmarcar os arquivos do diretorio atual" } ,
	{ 0x0000, 0, 0, 't', CMD_UNTTAG, "Todos os diretorios",	NOCMD, NOFUN, NOMNU, "Desmarcar todos os arquivos de todos os diretorios" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL duntmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, duntitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT funtitem [] = {

	{ 0x0000, 0, 0, 'a', CMD_UNTFIL, "Arquivo atual",		NOCMD, NOFUN, NOMNU, "Desmarcar o arquivo atual" } ,
	{ 0x0000, 0, 0, 't', CMD_UNTTAG, "Todos os arquivos",	NOCMD, NOFUN, NOMNU, "Desmarcar todos os arquivos deste diretorio" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU, NOSTR }
} ;

MENUCTL funtmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, funtitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT fileitem [] = {

	{ 0x0000, 0, 0, 'c', CMD_CPYFIL, "Copiar",		NOCMD, NOFUN, NOMNU,	 "Copiar Arquivo" } ,
	{ 0x0000, 0, 0, 'd', CMD_DELFIL, "Deletar",		NOCMD, NOFUN, NOMNU,	 "Deletar Arquivo" } ,
	{ MI_MNU, 0, 0, 'e', CMD_EDTMNU, "Editar",		NOCMD, NOFUN, &editmenu, "Editar Arquivo" } ,

# ifdef COMMENT
	{ 0x0000, 0, 0, 'l', CMD_LNKFIL, "Ligar",		NOCMD, NOFUN, NOMNU,	 "Ligar Arquivo" } ,
	{ 0x0000, 0, 0, 'a', CMD_TOUFIL, "Atualizar",	NOCMD, NOFUN, NOMNU,	 "Modificar datas de leitura/gravacao de arquivos" } ,
# endif /* COMMENT */

	{ 0x0000, 0, 0, 'm', CMD_MOVFIL, "Mover",		NOCMD, NOFUN, NOMNU,	 "Mover Arquivo" } ,
	{ 0x0000, 0, 0, 'i', CMD_PRTFIL, "Imprimir",	NOCMD, NOFUN, NOMNU,	 "Imprimir o arquivo atual" } ,
	{ 0x0000, 0, 0, 'r', CMD_RENFIL, "Renomear",	NOCMD, NOFUN, NOMNU,	 "Mudar o nome do arquivo atual" } ,
	{ 0x0000, 0, 0, 'p', CMD_SECFIL, "Proteger",	NOCMD, NOFUN, NOMNU,	 "Modificar a seguranca do arquivo atual" } ,
	{ MI_MNU, 0, 0, 's',          0, "Selecionar",  NOCMD, NOFUN, &fselmenu, "Comandos de selecao de arquivos" } ,
	{ MI_MNU, 0, 0, 'u',          0, "Desmarcar",   NOCMD, NOFUN, &funtmenu, "Desfazer selecao de arquivos" } ,
	{ MI_MNU, 0, 0, 'v', CMD_VUEMNU, "Ver",			NOCMD, NOFUN, &vuemenu,	 "Examinar o conteudo do arquivo atual" } ,
	{ 0x0000, 0, 0, 'x', CMD_EXEFIL, "Executar",	NOCMD, NOFUN, NOMNU,	 "Executar o arquivo atual" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,         NOCMD, NOFUN, NOMNU, 	 NOSTR }
} ;

MENUCTL filemenu = { MM_BOX, 0, 0, 0, 0, 0, 0, fileitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT tagitem [] = {

	{ 0x0000, 0, 0, 'C', CMD_CPYTAG, "Copiar",		NOCMD, NOFUN, NOMNU,    "Copiar os Arquivos Selecionados" } ,
	{ 0x0000, 0, 0, 'D', CMD_DELTAG, "Deletar",		NOCMD, NOFUN, NOMNU,    "Deletar os Arquivos Selecionados" } ,

# ifdef COMMENT
	{ MI_MNU, 0, 0, 'I', CMD_INVMNU, "Inverter",	NOCMD, NOFUN, &invmenu, "Inverter Familia ou Selecionados" } ,
	{ 0x0000, 0, 0, 'L', CMD_LNKTAG, "Ligar",		NOCMD, NOFUN, NOMNU,    "Ligar os Arquivos Selecionados" } ,
	{ 0x0000, 0, 0, 'N', CMD_TOUTAG, "Atualizar",	NOCMD, NOFUN, NOMNU,    "Modificar datas de leitura/gravacao dos arquivos selecionados" } ,
	{ 0x0000, 0, 0, 'R', CMD_RENTAG, "Renomear",	NOCMD, NOFUN, NOMNU,    "Mudar o nome dos arquivos selecionados" } ,
# endif /* COMMENT */

	{ 0x0000, 0, 0, 'M', CMD_MOVTAG, "Mover",		NOCMD, NOFUN, NOMNU,    "Mover Arquivos Selecionados" } ,
	{ 0x0000, 0, 0, 'I', CMD_PRTTAG, "Imprimir",	NOCMD, NOFUN, NOMNU,    "Imprimir os arquivos selecionados" } ,
	{ 0x0000, 0, 0, 'P', CMD_SECTAG, "Proteger",	NOCMD, NOFUN, NOMNU,    "Modificar a seguranca dos arquivos selecionados" } ,
	{ 0x0000, 0, 0, 'V', CMD_VUETAG, "Ver",			NOCMD, NOFUN, NOMNU,    "Examinar o conteudo dos arquivos selecionados" } ,
	{ 0x0000, 0, 0, 'X', CMD_EXETAG, "Executar",	NOCMD, NOFUN, NOMNU,    "Executar os arquivos selecionados" } ,
	{ 0x0000, 0, 0, 'Q', CMD_TXSTAG, "Pesquisar",	NOCMD, NOFUN, NOMNU,    "Procurar um texto nos arquivos selecionados" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,         NOCMD, NOFUN, NOMNU,    NOSTR }
} ;

MENUCTL tagmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, tagitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT diritem [] = {

	{ 0x0000, 0, 0, 'd', CMD_DELDIR, "Deletar ",     NOCMD, NOFUN, NOMNU,	  "Eliminar o diretorio atual" } ,
	{ 0x0000, 0, 0, 'c', CMD_MAKDIR, "Criar   ",     NOCMD, NOFUN, NOMNU,	  "Criar um sub-diretorio no diretorio atual" } ,
	{ 0x0000, 0, 0, 'r', CMD_RENDIR, "Renomear",     NOCMD, NOFUN, NOMNU,	  "Mudar o nome do diretorio atual" } ,
	{ MI_MNU, 0, 0, 's', 0,          "Selecionar",   NOCMD, NOFUN, &dselmenu, "Comandos de selecao de arquivos" } ,
	{ MI_MNU, 0, 0, 'u',          0, "Desmarcar",    NOCMD, NOFUN, &duntmenu, "Desfazer selecao de arquivos" } ,
	{ 0x0000, 0, 0, 'p', CMD_SECDIR, "Proteger",     NOCMD, NOFUN, NOMNU,	  "Modificar a seguranca do diretorio atual" } ,

# ifdef COMMENT
	{ 0x0000, 0, 0, 'o', CMD_CMPDIR, "Comparar",     NOCMD, NOFUN, NOMNU,	  "Comparar os arquivos do diretorio atual com os de outro diretorio" } ,
	{ 0x0000, 0, 0, 'm', CMD_MOVDIR, "Mover   ",     NOCMD, NOFUN, NOMNU,	  "Mover o diretorio atual para outro diretorio" } ,
	{ 0x0000, 0, 0, 'i', CMD_ZAPDIR, "Implodir",	 NOCMD, NOFUN, NOMNU,	  "Eliminar TODOS os arquivos e sub-diretorios do diretorio atual" } ,
# endif /* COMMENT */

	{ 0x0000, 0, 0,   0,          0, NOSTR,      NOCMD, NOFUN, NOMNU,	 NOSTR }
} ;

MENUCTL dirmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, diritem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT toolitem [] = {

	{ MI_MNU, 0, 0, 'o',          0, "Ordenar Arquivos",    NOCMD, NOFUN, &ordmenu,	"Classificar Arquivos" } ,
	{ 0x0000, 0, 0, 'f', CMD_FAMRXP, "Familia de Arquivos", NOCMD, NOFUN, NOMNU,	"Especificar o padrao da familia de arquivos" } ,

# ifdef COMMENT
	{ 0x0000, 0, 0, 'p', CMD_FINFIL, "Procurar Arquivo",    NOCMD, NOFUN, NOMNU,	"Localizar um arquivo pelo nome" } ,
	{ 0x0000, 0, 0, 's', CMD_FDSTAT, "Formato do Status",   NOCMD, NOFUN, NOMNU,	"Escolher o formato de apresentacao do Status dos arquivos" } ,
# endif /* COMMENT */

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU,	NOSTR }
} ;

MENUCTL toolmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, toolitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT xdiritem [] = {

	{ 0x0000, 0, 0, 'g', CMD_GLOBAL, "Englobar Arquivos",   NOCMD, NOFUN, NOMNU,	"Reunir os arquivos de todos os diretorios" } ,
	{ MI_MNU, 0, 0, 'l', CMD_LOGMNU, "Ler",	        		NOCMD, NOFUN, &logmenu, "Menu de leitura" } ,
	{ 0x0000, 0, 0, 't', CMD_SWTREE, "Trocar de Arvore",    NOCMD, NOFUN, NOMNU,	"Explorar as outras arvores lidas" } ,
	{ 0x0000, 0, 0, 'j', CMD_FILWIN, "Janela de Arquivos",	NOCMD, NOFUN, NOMNU,	"Passar para a janela de arquivos" } ,
	{ 0x0000, 0, 0, 'x', CMD_XSHELL, "Executar um Shell",	NOCMD, NOFUN, NOMNU,	"Invocar o processador de comandos do sistema operacional" } ,
	{ 0x0000, 0, 0, 'v', CMD_SWFRAM, "Variar Moldura   ",	NOCMD, NOFUN, NOMNU,	"Mudar os caracteres das molduras das janelas" } ,
	{ 0x0000, 0, 0, 'q', CMD_QUITOS, "FIM",					NOCMD, NOFUN, NOMNU,	"Terminar o programa" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,           		NOCMD, NOFUN, NOMNU,	NOSTR }
} ;

MENUCTL xdirmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, xdiritem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT xfilitem [] = {

	{ 0x0000, 0, 0, 'e', CMD_BIGWIN, "Expandir",				NOCMD, NOFUN, NOMNU,	"Expandir a janela de arquivos" } ,
	{ 0x0000, 0, 0, 'd', CMD_TREWIN, "Janela de Diretorios",	NOCMD, NOFUN, NOMNU,	"Retornar a janela de diretorios" } ,
	{ 0x0000, 0, 0, 'x', CMD_XSHELL, "Executar um Shell",		NOCMD, NOFUN, NOMNU,	"Invocar o processador de comandos do sistema operacional" } ,
	{ 0x0000, 0, 0, 'q', CMD_QUITOS, "FIM",						NOCMD, NOFUN, NOMNU,	"Terminar o programa" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,			NOCMD, NOFUN, NOMNU,	NOSTR }
} ;

MENUCTL xfilmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, xfilitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT xbigitem [] = {

	{ 0x0000, 0, 0, 'c', CMD_BIGWIN, "Contrair",				NOCMD, NOFUN, NOMNU,	"Contrair a janela de arquivos" } ,
	{ 0x0000, 0, 0, 'd', CMD_TREWIN, "Janela de Diretorios",	NOCMD, NOFUN, NOMNU,	"Retornar a janela de diretorios" } ,
	{ 0x0000, 0, 0, 'x', CMD_XSHELL, "Executar um Shell",		NOCMD, NOFUN, NOMNU,	"Invocar o processador de comandos do sistema operacional" } ,
	{ 0x0000, 0, 0, 'q', CMD_QUITOS, "FIM",						NOCMD, NOFUN, NOMNU,	"Terminar o programa" } ,

	{ 0x0000, 0, 0,   0,          0, NOSTR,			NOCMD, NOFUN, NOMNU,	NOSTR }
} ;

MENUCTL xbigmenu = { MM_BOX, 0, 0, 0, 0, 0, 0, xbigitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT primitem [] = {

	{ MI_MNU, 0, 0, 'd', 0, " Diretorio ",    NOCMD, NOFUN, &dirmenu,  "Comandos de Diretorio" } ,
	{ MI_MNU, 0, 0, 'e', 0, " Extra ",        NOCMD, NOFUN, &xdirmenu, "Comandos Especiais" } ,
	{ MI_MNU, 0, 0, 'o', 0, " Organizacao ",  NOCMD, NOFUN, &toolmenu, "Comandos de classificacao/pesquisa" } ,

	{ 0x0000, 0, 0,   0, 0, NOSTR,            NOCMD, NOFUN, NOMNU, 	 NOSTR }
} ;

MENUCTL primenu = { MM_BAR, 1, 2, 78, 1, 0, 0, primitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT auxitem [] = {

	{ MI_MNU, 0, 0, 'a', 0, " Arquivo ",      NOCMD, NOFUN, &filemenu, "Comandos de Arquivo" } ,
	{ MI_MNU, 0, 0, 'e', 0, " Extra ",        NOCMD, NOFUN, &xfilmenu, "Comandos Especiais" } ,
	{ MI_MNU, 0, 0, 'o', 0, " Organizacao ",  NOCMD, NOFUN, &toolmenu, "Comandos de classificacao/pesquisa" } ,
	{ MI_MNU, 0, 0, 's', 0, " Selecionados ", NOCMD, NOFUN, &tagmenu,  "Comandos para Arquivos Selecionados" } ,

	{ 0x0000, 0, 0,   0, 0, NOSTR,            NOCMD, NOFUN, NOMNU, 	 NOSTR }
} ;

MENUCTL auxmenu = { MM_BAR, 1, 2, 78, 1, 0, 0, auxitem } ;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

MENUIT bfwitem [] = {

	{ MI_MNU, 0, 0, 'a', 0, " Arquivo ",      NOCMD, NOFUN, &filemenu, "Comandos de Arquivo" } ,
	{ MI_MNU, 0, 0, 'e', 0, " Extra ",        NOCMD, NOFUN, &xbigmenu, "Comandos Especiais" } ,
	{ MI_MNU, 0, 0, 'o', 0, " Organizacao ",  NOCMD, NOFUN, &toolmenu, "Comandos de classificacao/pesquisa" } ,
	{ MI_MNU, 0, 0, 's', 0, " Selecionados ", NOCMD, NOFUN, &tagmenu,  "Comandos para Arquivos Selecionados" } ,

	{ 0x0000, 0, 0,   0, 0, NOSTR,            NOCMD, NOFUN, NOMNU, 	 NOSTR }
} ;

MENUCTL bfwmenu = { MM_BAR, 1, 2, 78, 1, 0, 0, bfwitem } ;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

EXT     int             vdotyp ;
EXT     char            altgcs [] ;

/*
 *		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
int runmenu (mmp, mml, mmc) MENUCTL * mmp ; int mml, mmc ; {

	if (mmp->mm_flg & MM_BAR)
		return barmenu (mmp, mml, mmc) ;
	else if (mmp->mm_flg & MM_BOX)
		return boxmenu (mmp, mml, mmc) ;
	else
		return -1 ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
int mmval = -1 ;
WWINFO * xwwp ;
char midesc [80] ;

int barmenu (mmp, mml, mmc) MENUCTL * mmp ; int mml, mmc ; {

	WWINFO * wwp ;
	char * barbuf ;
	MENUIT * mip , * tmip ;
	int i, grd = -2, key = 0 ;

	if (mml >= 0)
		mmp->mm_lin = mml ;

	if (mmc >= 0)
		mmp->mm_col = mmc ;

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	wwp = wwopen (mmp->mm_lin, mmp->mm_col, mmp->mm_wid, 1) ;

	if (wwp == (WWINFO *) 0) {
		wwputs (stdww, "ERRO INTERNO em wwopen () !!!") ;
		return -1 ;
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	xwwp = wwopen (20, 2, 76, 3) ;

	if (vdotyp == 't')
		wwfram (xwwp, WW_REVERSE) ;
	else
		wwfram (xwwp, BGFG (LIGHTGRAY, BLACK)) ;

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	barbuf = malloc (mmp->mm_wid) ;
	barbuf[0] = '\0' ; midesc[0] = ' ' /* C_GSPC */ ;
	mmp->mm_nit = 0 ;

	for ( mip = mmp->mm_item ; mip->mi_name != NOSTR ; ++mip ) {
		mmp->mm_nit += 1 ;
		strcat (barbuf, "  ") ;
		mip->mi_lin = 0 ;
		mip->mi_col = strlen (barbuf) ;
		strcat (barbuf, mip->mi_name) ;
	}
	strcat (barbuf, "  ") ;

	if (vdotyp == 't')
		wwdisp (wwp, 0, 0, barbuf, WW_REVERSE) ;
	else
		wwdisp (wwp, 0, 0, barbuf, BGFG (LIGHTGRAY, BLACK)) ;

	mip = mmp->mm_item + mmp->mm_lit ;

	for ( ; ; ) {

		switch (grd) {

			case KLEFT   :						/* <- left arrow */
				if ((mip - mmp->mm_item) > 0)
					--mip ;
				else
					mip = mmp->mm_item + (mmp->mm_nit - 1) ;
			break ;

			case KRIGHT :						/* -> right arrow */
				++mip ;
				if ((mip - mmp->mm_item) >= mmp->mm_nit) {
					mip = mmp->mm_item ;
				}
			break ;
		}

		if (vdotyp == 't')
			wwdisp (wwp, mip->mi_lin, mip->mi_col,
					mip->mi_name, WW_NORMAL) ;
		else
			wwdisp (wwp, mip->mi_lin, mip->mi_col,
					mip->mi_name, BGFG (BLACK, LIGHTGRAY /* WHITE */)) ;

		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

		strpad (midesc+1, mip->mi_help, 73) ;

		if (vdotyp == 't')
			wwdisp (xwwp, 1, 1, midesc, WW_REVERSE) ;
		else
			wwdisp (xwwp, 1, 1, midesc,
					BGFG (LIGHTGRAY, BLACK /* WHITE */)) ;

		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

		if (grd == KLEFT || grd == KRIGHT || grd == -3) {
			if (key == '\r')
				goto kt ;
		}

		key = getkey () ;

        if (key == '\n')
            key = '\r' ;

kt :	grd = -2 ;
		if (key != '\r') {
			if (vdotyp == 't')
				wwdisp (wwp, mip->mi_lin, mip->mi_col,
						mip->mi_name, WW_REVERSE) ;
			else
				wwdisp (wwp, mip->mi_lin, mip->mi_col,
						mip->mi_name, BGFG (LIGHTGRAY, BLACK)) ;
		}

		switch (key) {

			case '\r' :
				if (mip->mi_flg & MI_MNU) {
					grd = runmenu (mip->ma_menu, (mmp->mm_lin)+1,
												 (mip->mi_col)+3 ) ;
				}
				if (grd == 0 || key == -1) {
					key = grd ; goto eom ;
				}
				if (vdotyp == 't')
					wwdisp (wwp, mip->mi_lin, mip->mi_col,
							mip->mi_name, WW_REVERSE) ;
				else
					wwdisp (wwp, mip->mi_lin, mip->mi_col,
							mip->mi_name, BGFG (LIGHTGRAY, BLACK)) ;
			break ;

			case '\b'  :
			case '4'   :
			case KLEFT :
				key = KLEFT ;
				if ((int) (mip - mmp->mm_item) > 0)
					--mip ;
				else
					mip = mmp->mm_item + (mmp->mm_nit - 1) ;
			break ;

			case '\t'   :
			case ' '    :
			case '6'    :
			case KRIGHT :
				key = KRIGHT ;
				++mip ;
				if ((int) (mip - mmp->mm_item) >= mmp->mm_nit) {
					mip = mmp->mm_item ;
				}
			break ;

			case CTRL_Q :
			case ESC :		key = -1 ; goto eom ;

			case '?'  :
			case KF1 :
				hyxhelp (mip->mi_name) ;
			break ;

			default :
				tmip = mmp->mm_item ;
				for ( i = 0 ; i < mmp->mm_nit ; ++i , ++tmip )
					if (key == tmip->mi_key) {
						mip = tmip ;
						key = '\r' ; grd = -3 ;
					}
			break ;
		}
	}
eom :
	mmp->mm_lit = (int) ( mip - mmp->mm_item ) ;
	wwclos (xwwp) ;
	wwclos (wwp) ;
	return key ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
int boxmenu (mmp, mml, mmc) MENUCTL * mmp ; int mml, mmc ; {
	WWINFO * wwp ;
	MENUIT * mip , * tmip ;
	int i, grd = 0, x, key = 0 ;
	char tb [80] ;

	mip = mmp->mm_item ;
	mmp->mm_nit = 0 ;

	for ( i = x = 0 ; mip->mi_name != NOSTR ; ++i , ++mip ) {
		mmp->mm_nit += 1 ;
		mip->mi_lin = 1 + i ;
		mip->mi_col = 1 ;
		key = strlen (mip->mi_name) ;
		if (key > x)
			x = key ;
	}

	if (mml >= 0)
		mmp->mm_lin = mml ;

	if (mmc >= 0)
		mmp->mm_col = mmc ;

	wwp = wwopen (mmp->mm_lin, mmp->mm_col, x+4, mmp->mm_nit+2) ;

	if (vdotyp == 't')
		wwfram (wwp, WW_REVERSE) ;
	else
		wwfram (wwp, BGFG (LIGHTGRAY, BLACK)) ;

	mip = mmp->mm_item ;
	tb[0] = ' ' /* C_GSPC */ ;

	if (vdotyp == 't')
		wwsatr (wwp, WW_NORMAL) ;
	else
		wwsatr (wwp, BGFG (BLACK, LIGHTGRAY)) ;

	for ( i = 0 ; i < mmp->mm_nit ; ++i , ++mip ) {
		wwgoyx (wwp, mip->mi_lin, mip->mi_col) ;
		strpad (&tb[1], mip->mi_name, x+1) ;
		wwputs (wwp, tb) ;
	}

	mip = mmp->mm_item + mmp->mm_lit ;

	for ( ; ; ) {
		strpad (&tb[1], mip->mi_name, x+1) ;

		if (vdotyp == 't')
			wwdisp (wwp, mip->mi_lin, mip->mi_col,
					tb, WW_REVERSE) ;
		else
			wwdisp (wwp, mip->mi_lin, mip->mi_col,
					tb, BGFG (LIGHTGRAY, BLACK /* WHITE */)) ;

		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

		strpad (midesc+1, mip->mi_help, 73) ;

		if (vdotyp == 't')
			wwdisp (xwwp, 1, 1, midesc, WW_REVERSE) ;
		else
			wwdisp (xwwp, 1, 1, midesc,
					BGFG (LIGHTGRAY, BLACK /* WHITE */)) ;

		/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

		if (grd == -3)
			goto tk ;

		key = getkey () ;

        if (key == '\n')
            key = '\r' ;

tk :	grd = -2 ;

		if (key != '\r') {
			if (vdotyp == 't')
				wwdisp (wwp, mip->mi_lin, mip->mi_col,
						tb, WW_NORMAL) ;
			else
				wwdisp (wwp, mip->mi_lin, mip->mi_col,
						tb, BGFG (BLACK, LIGHTGRAY)) ;
		}

		switch (key) {

			case '\r' :
				if (mip->mi_flg & MI_MNU) {
					grd = runmenu (mip->ma_menu, (mip->mi_lin)+3,
												 (mmp->mm_col)+2 ) ;
				} else {
					grd = 0 ;
					mmval = mip->mi_val ;
				}
				if (grd != -1) {
					key = grd ; goto eom ;
				}
			break ;

			case '+' :
				switfram () ;
				if (vdotyp == 't')
					wwfram (wwp, WW_REVERSE) ;
				else
					wwfram (wwp, BGFG (LIGHTGRAY, BLACK)) ;
			break ;

			case '?'  :
			case KF1 :
				hyxhelp (mip->mi_name) ;
			break ;

			case KRIGHT :
			case '6'	: key = KRIGHT ; goto eom ;

			case KLEFT  :
			case '4'	: key = KLEFT ;  goto eom ;

			case '8'  :
			case '\b' :
			case KUP  :
				if ((mip - mmp->mm_item) > 0)
					--mip ;
				else
					mip = mmp->mm_item + (mmp->mm_nit - 1) ;
			break ;

			case ' '   :
			case '2'   :
			case '\t'  :
			case KDOWN :
				++mip ;
				if ((mip - mmp->mm_item) >= mmp->mm_nit) {
					mip = mmp->mm_item ;
				}
			break ;

			case CTRL_Q :
			case ESC :		key = -1 ; goto eom ;

			default :
				tmip = mmp->mm_item ;
				for ( i = 0 ; i < mmp->mm_nit ; ++i , ++tmip )
					if (key == tmip->mi_key) {
						mip = tmip ;
						key = '\r' ; grd = -3 ;
					}
			break ;
		}
	}
eom :
	mmp->mm_lit = (int) ( mip - mmp->mm_item ) ;
	wwclos (wwp) ;
	return key ;
}

/*
 * vi:nu ts=4
 */
