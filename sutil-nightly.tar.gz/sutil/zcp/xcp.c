
/*
 *                   _______________________________________________
 *		  /\        |												|
 *		 /  \       |	 xcp							fancy cp	|
 *		/ OO \      |_______________________________________________|
 *		\ \/ /      |												|
 *		 \  /       |	 (c) 1992-1994     alexandre v. r. botao	|
 *		  \/        |_______________________________________________|
 *
 */

# define	VERNAME			"xcp"
# define	VERSION			"1.2"
# define	VERCODE			"254"
# define	VERDATE			"1997.06.18"
# define	VERSIGN			"Alexandre Botao"

# include	<stdio.h>

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		DOS

# define	LOPSYS			"DOS"

#	include <dir.h>
#	include <dos.h>
#	include <conio.h>
#	include <io.h>

typedef		struct ffblk	FFBLK ;

# define	FA_MASK			(FA_ARCH|FA_RDONLY|FA_SYSTEM|FA_HIDDEN)

# endif		/* DOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# if defined (CALDERA) || defined (MANDRAKE) || defined (REDHAT)
#	define	LINUX
# endif

# ifdef		LINUX

# define	LOPSYS			"LINUX"

# define	ANYX

# endif		/* LINUX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SCOXENIX

# define	LOPSYS			"SCOXENIX"

# define	ANYX

# endif		/* SCOXENIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		HPUX

# define	LOPSYS			"HPUX"

# define	ANYX

# endif		/* HPUX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SOLARIS

# define	LOPSYS			"SOLARIS"

# define	ANYX

# endif		/* SOLARIS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SUNOS

# define	LOPSYS			"SUNOS"

# define	ANYX

# endif		/* SUNOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include	<stdlib.h>
# include	<string.h>

# include	<sys/types.h>
# include	<sys/stat.h>

# include	<sys/timeb.h>
# include	<time.h>
# include	<utime.h>

# ifdef ANYX

# include	<utime.h>

# endif

# define	USE_STDMEM
# define	USE_STDTYP
# define	USE_STDMISC

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

struct cpinfo {
	char * ifn ;		/* input  file name		*/
	char * ofn ;		/* output file name		*/
	long   xsz ;		/* transfer size		*/
	long   mtm ;		/* mtime				*/
	long   atm ;		/* atime				*/
	long   mod ;		/* mode					*/
} ;

typedef		struct cpinfo		CPINFO ;
typedef		struct stat			STAT ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	DOT			'.'
# define	DIRSEP		'/'

# define	VBSIZ		30720 /* 16384, 4096 */
# define	YET			  DOT /*  177 */
# define	VOK			  '#' /*  219 */
# define	SCALE		   40 /*   40 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	LIN_BANNER			 1
# define	COL_BANNER			 2

# define    LIN_ORIG_HEAD		 3
# define	COL_ORIG_HEAD		 2

# define    LIN_ORIG_NAME		LIN_ORIG_HEAD
# define	COL_ORIG_NAME		11

# define    LIN_DEST_HEAD		 5
# define	COL_DEST_HEAD		 2

# define    LIN_DEST_NAME		LIN_DEST_HEAD
# define	COL_DEST_NAME		11

# define	LIN_FILBYT_VAL		 7
# define	COL_FILBYT_VAL		62

# define	LIN_TOTFIL_VAL		 9
# define	COL_TOTFIL_VAL		COL_FILBYT_VAL

# define	LIN_TOTBYT_VAL		11
# define	COL_TOTBYT_VAL		COL_FILBYT_VAL

# define	COL_PERC			14
# define	COL_SCALE			21

# define	LINETIM		13

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int			argk ;
char *		swid = "xcp" ;						/* s/w id ...		*/
char * *	argp = (char * *) 0 ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char resp [40] ;
char cpbuf [ VBSIZ ] ;
struct stat stabuf ;
FILE * ifp , * ofp ;
CPINFO * cplst = (CPINFO *) 0 ;
int totfiles = 0 ;
int todir = 0 ;
long totbyts = 0L ;
long allbyts = 0L ;
long itiks ;
long maxest , minest ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		ANSI

# define	OF(X)		X

# else		/* OLD STYLE */

# define	OF(X)		()

# endif		/* ANSI */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void growlist		OF ( (char *, char *) ) ;
void proclist		OF ( (void) ) ;
void xcp			OF ( (char *, char *, long) ) ;
void invest			OF ( (void) ) ;
void vestim			OF ( (void) ) ;
void ltohms			OF ( (long, long *, long *, long *) ) ;
int  stodec			OF ( (char *, int *) ) ;

void banner			OF ( (void) ) ;
void headers		OF ( (void) ) ;
void frames			OF ( (void) ) ;
void lineat			OF ( (int, int, int) ) ;
void preparm		OF ( (int, char * *) ) ;
void blowild		OF ( (char *) ) ;
void argrow			OF ( (char *) ) ;
long militime		OF ( (void) ) ;

void cursorat		OF ( (int, int) ) ;
void clearscreen	OF ( (void) ) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int main (argc, argv) int argc ; char * * argv ; {
	char * destname , * thisparm ;
	register int wk ;

	headers () ;

	preparm (argc, argv) ;

	if (argk < 3) {
		cursorat (19, 2) ; printf ("use: xcp arquivo novonome") ;
		cursorat (20, 2) ; printf (" ou: xcp arquivo ... diretorio") ;
		cursorat (23, 0) ; return 1 ;
	}
	destname = *(argp+(argk-1)) ;

	if (stat (destname, &stabuf) == -1) {
		if (argk > 3) {
dnf :		cursorat (19,2) ; printf ("Diretorio abaixo nao encontrado :") ;
			cursorat (20,2) ; printf ("%-76s", destname) ;
			return 2 ;
		}
		/* cp file 2 file ... */
		growlist (*(argp+1), destname) ;
	} else {
		/* dest exists ... */
		if ((stabuf.st_mode & S_IFMT) == S_IFREG) {
			if (argk > 3)
				goto dnf ;
			else {
				growlist (*(argp+1), destname) ;
			}
		} else if ((stabuf.st_mode & S_IFMT) != S_IFDIR) {
			goto dnf ;
		} else {

			/* build file list 2 cp 2 dir ... */

			todir = 1 ;

			for ( wk = 1 ; wk < (argk-1) ; ++wk ) {

				thisparm = *(argp+wk) ;

				if (strcmp (thisparm, "-f") == 0)
					frames () ;
				else
					growlist (thisparm, destname) ;
			}
		}
	}
	proclist () ;
	cursorat (23,0) ;
	return 0 ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	banner ...	|
 *													|_______________|
 */

void banner () {

	printf ("\"%s\" %s * %s @ %s / %s (C) %s\n\n",
			VERNAME, VERSION, VERCODE, VERDATE, OPSYS, VERSIGN) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void headers () {
	register int i ;

# ifdef ANYX
	setbuf (stdout, NULL) ;
# endif /* ANYX */

	clearscreen () ;

	cursorat (LIN_BANNER, COL_BANNER) ;
	banner () ;

	cursorat (LIN_ORIG_HEAD, COL_ORIG_HEAD) ;
	printf ("Origem:  ") ;

	cursorat (LIN_DEST_HEAD, COL_DEST_HEAD) ;
	printf ("Destino: ") ;

	cursorat (LIN_FILBYT_VAL, 2) ;
	printf ("0000000000 (000 %%) ") ;

	cursorat (LIN_TOTFIL_VAL, 2) ;
	printf ("0000000000 (000 %%) ") ;

	cursorat (LIN_TOTBYT_VAL, 2) ;
	printf ("0000000000 (000 %%) ") ;

	cursorat (LIN_FILBYT_VAL, COL_SCALE) ;
	for ( i = 0 ; i < SCALE ; ++i )
		putchar (YET) ;

	cursorat (LIN_TOTFIL_VAL, COL_SCALE) ;
	for ( i = 0 ; i < SCALE ; ++i )
		putchar (YET) ;

	cursorat (LIN_TOTBYT_VAL, COL_SCALE) ;
	for ( i = 0 ; i < SCALE ; ++i )
		putchar (YET) ;

	cursorat (LIN_FILBYT_VAL, 62) ; printf ("0000000000 Bytes") ;
	cursorat (LIN_TOTFIL_VAL, 62) ; printf ("0000000000 Arqs.") ;
	cursorat (LIN_TOTBYT_VAL, 62) ; printf ("0000000000 Total") ;

	cursorat (13, 2) ; printf ("Tempo Estimado") ;

	cursorat (15, 2) ; printf ("Melhor __:__:__") ;
	cursorat (16, 2) ; printf ("Atual  __:__:__") ;
	cursorat (17, 2) ; printf ("Pior   __:__:__") ;

	cursorat (13,20) ; printf ("Tempo Real") ;

	cursorat (15,20) ; printf ("Inicio  __:__:__") ;
	cursorat (16,20) ; printf ("Tempo   __:__:__") ;
	cursorat (17,20) ; printf ("Termino __:__:__") ;

	cursorat (13,39) ; printf ("Taxas    Leit.    Grav.    (E/S)") ;

	cursorat (15,39) ; printf ("Maxima  ......   ......   ......   KB/s") ;
	cursorat (16,39) ; printf ("Atual   ......   ......   ......   KB/s") ;
	cursorat (17,39) ; printf ("Minima  ......   ......   ......   KB/s") ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void frames () {

/*	lineat ( 0,  0, 80) ;	*/
	lineat ( 2,  0, 80) ;
	lineat (18,  0, 80) ;
	lineat (22,  0, 80) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void lineat (int lin, int col, int len) {
	register int j ;

	cursorat (lin, col) ;

	for ( j = 0 ; j < len ; ++j )
		putchar ('-') ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	parms preprocessing ...		|
 *									|_______________________________|
 */

void preparm (argc, argv) int argc ; char * * argv ; {

# ifdef	DOS

	argk = 0 ;

	while (argc--)
		blowild (*argv++) ;

# else	/* ANYX */

	argk = argc ; argp = argv ;

# endif	/* DOS */

}

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	wildcards (dos-style regular expressions) explosion ...		|
 *	|_______________________________________________________________|
 */

# ifdef		DOS

void blowild (nam) char * nam ; {
	struct ffblk ffbuf ;
	char fnbuf [ 80 ] ;
	char * fnptr = ffbuf.ff_name ;
	int slasti ;								/* last slash inx	*/

	if (findfirst (nam, &ffbuf, FA_MASK) < 0) {
		argrow (nam) ;
		return ;
	}

	if ((slasti = lastoc (nam, '\\')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;
	else if ((slasti = lastoc (nam, ':')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;

	do {

		if (fnptr == fnbuf)
			strcpy (fnptr + slasti + 1, ffbuf.ff_name) ;

		argrow ( fnptr ) ; /* , & ffbuf */

	} while (findnext (&ffbuf) >= 0) ;
}

/*
 *						|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *						|	grow up argument (parameter) list ...	|
 *						|___________________________________________|
 */

void argrow (str) char * str ; {
	register char * * tpp ;
	register char *   tp ;

	tp = (char *) xmalloc (1 + strlen (str)) ;

	if (tp == (char *) 0) {
nm:		fprintf (stderr, "%s: memoria insuficiente\n", swid) ;
		exit (1) ;
	}

	if (argp == (char * *) 0)
		tpp = (char * *) xmalloc (2 * sizeof (char *)) ;
	else
		tpp = (char * *) xmrealloc (argp, (2+argk) * sizeof (char *)) ;

	if (tpp == (char * *) 0)
		goto nm ;

	strcpy (tp, str) ;
	argp = tpp ;
	*(argp+argk) = tp ;
	++argk ;
	*(argp+argk) = (char *) 0 ;
}

# endif		/* DOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void growlist (pname, dname) char * pname, * dname ; {

	char nup [80] ;
	char fnbuf [80] ;

# ifdef DOS
	struct ffblk ffbuf ;
# endif /* DOS */

	register char * fnptr ;
	register char * cp ;
	register int slasti ;
	register size_t /* int */ nusiz ;
	CPINFO * xp ;

# ifdef DOS

	fnptr = ffbuf.ff_name ;
	strcpy (nup, dname) ;

	if (findfirst (pname, &ffbuf, FA_ARCH) == 0) {

		if ((slasti = lastoc (pname, DIRSEP)) >= 0)
			strcpy (fnptr = fnbuf, pname) ;
		else if ((slasti = lastoc (pname, ':')) >= 0)
			strcpy (fnptr = fnbuf, pname) ;

		do {
			if (fnptr == fnbuf) {
				strncpy (fnptr+slasti+1, ffbuf.ff_name, 13) ;
			}
			if (todir) {
				sprintf (nup, "%s\\", dname) ;
				strncat (nup, ffbuf.ff_name, 12) ;
			}
			/* src = fnptr , dst = nup : chk all & collect */
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
			if (cplst == (CPINFO *) 0) {
				cplst = (CPINFO *) xmalloc (sizeof (CPINFO)) ;
				if (cplst == (CPINFO *) 0) {
vnm :				cursorat (23,0) ;
					printf ("xcp: faltou memoria ...") ;
					exit (1) ;
				}
			} else {
				nusiz = (totfiles+1) * (sizeof (CPINFO)) ;
				cplst = (CPINFO *) xmrealloc (cplst, nusiz) ;
				if (cplst == (CPINFO *) 0)
					goto vnm ;
			}
			xp = cplst + totfiles ;
			++totfiles ;
			xp->xsz = ffbuf.ff_fsize ;
			totbyts += xp->xsz ;
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
			cp = xmalloc (1+strlen (fnptr)) ;
			if (cp == (char *) 0)
				goto vnm ;
			strcpy (cp, fnptr) ;
			xp->ifn = cp;
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
			cp = xmalloc (1+strlen (nup)) ;
			if (cp == (char *) 0)
				goto vnm ;
			strcpy (cp, nup) ;
			xp->ofn = cp;
			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
		} while (findnext (&ffbuf) != -1) ;
	} else {
		cursorat (19,2) ; printf ("ERRO ao acessar :") ;
		cursorat (20,2) ; printf ("%-76s", pname) ;
		cursorat (21,2) ; printf ("Tecle [Esc] ") ;
		while (getch () != 27) ;
		cursorat (23,0) ;
	}

# else  /* ANYX */

	fnptr = pname ;
	strcpy (nup, dname) ;

	if ( stat ( pname , &stabuf ) == 0 ) {

		if ((slasti = lastoc (pname, DIRSEP)) >= 0)
			strcpy ( fnbuf , fnptr+(slasti+1) ) ;
		else
			strcpy ( fnbuf , fnptr ) ;

		if (todir)
			sprintf (nup, "%s%c%s", dname, DIRSEP, fnbuf) ;

		/* src = fnptr , dst = nup : chk all & collect */

		if (cplst == (CPINFO *) 0) {
			cplst = (CPINFO *) xmalloc (sizeof (CPINFO)) ;
			if (cplst == (CPINFO *) 0) {
vnm :			cursorat (23,0) ;
				printf ("xcp: faltou memoria ...") ;
				exit (1) ;
			}
		} else {
			nusiz = (totfiles+1) * (sizeof (CPINFO)) ;
			cplst = (CPINFO *) xmrealloc (cplst, nusiz) ;
			if (cplst == (CPINFO *) 0)
				goto vnm ;
		}

		xp = cplst + totfiles ;
		++totfiles ;
		xp->xsz = stabuf.st_size ;
		xp->mtm = stabuf.st_mtime ;
		xp->atm = stabuf.st_atime ;
		xp->mod = stabuf.st_mode ;
		totbyts += xp->xsz ;

		cp = (char *) xmalloc (1+strlen (fnptr)) ;
		if (cp == (char *) 0)
			goto vnm ;
		strcpy (cp, fnptr) ;
		xp->ifn = cp;

		cp = (char *) xmalloc (1+strlen (nup)) ;
		if (cp == (char *) 0)
			goto vnm ;
		strcpy (cp, nup) ;
		xp->ofn = cp;

	} else {

		cursorat (19,2) ; printf ("ERRO ao acessar :") ;
		cursorat (20,2) ; printf ("%-76s", pname) ;
		cursorat (21,2) ; printf ("Tecle [Enter] ") ;
		cp = fgets (resp, 40, stdin) ; cursorat (23,0) ;
	}

# endif /* DOS */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void proclist () {

	register CPINFO * xp = cplst ;
	register int filecnt = 0 ;
	register int i, perctof, scaltof ;
	register long tini, tend ;
	register long maxior, minior, iorate ;
	register struct tm * tp ;
	long tloc ;
	struct utimbuf y ;

	cursorat (LIN_TOTBYT_VAL, COL_TOTBYT_VAL) ;
	printf ("%10ld", totbyts) ;

	cursorat (LIN_TOTFIL_VAL, COL_TOTFIL_VAL) ;
	printf ("%10d", totfiles) ;

	time (&tloc) ;
	tp = localtime (&tloc) ;
	cursorat (15,28) ;
	printf ("%02d:%02d:%02d",tp->tm_hour,tp->tm_min,tp->tm_sec) ;

	invest () ;
	maxior = -1L ;
	minior = 999999999L ;

	while (filecnt < totfiles) {

		tini = militime () ;

		xcp (xp->ifn, xp->ofn, xp->xsz) ;

		/* touch and chmod ... */

		y.actime = xp->atm ;
		y.modtime = xp->mtm ;

		utime (xp->ofn, &y) ;

		chmod (xp->ofn, (mode_t) xp->mod) ;

		/* process times ... */

		if ( xp->xsz > 4096 ) {

			tend = militime () - tini ;
			tend = tend ? tend : 1 ;
			iorate = ( ( xp->xsz / tend ) * 1000 ) / 1024 ;

			if (iorate > maxior) {
				maxior = iorate ;
				cursorat (15, 65) ;
				printf ("%6ld", maxior) ;
			}

			if (iorate < minior) {
				minior = iorate ;
				cursorat (17, 65) ;
				printf ("%6ld", minior) ;
			}

			cursorat (16, 65) ;
			printf ("%6ld", iorate) ;
		}

		++xp ;
		++filecnt ;

		perctof = (int) ( ( filecnt * 100 ) / totfiles ) ;
		scaltof = ( SCALE * perctof ) / 100 ;

		cursorat (LIN_TOTFIL_VAL, COL_PERC) ;
		printf ("%3d", perctof) ;

		cursorat (LIN_TOTFIL_VAL, COL_SCALE) ;
		for ( i = 0 ; i < scaltof ; ++i )
			putchar (VOK) ;

		cursorat (LIN_TOTFIL_VAL, 2) ;
		printf ("%10d", filecnt) ;
	}

	time (&tloc) ;
	tp = localtime (&tloc) ;
	cursorat (17,28) ;
	printf ("%02d:%02d:%02d",tp->tm_hour,tp->tm_min,tp->tm_sec) ;

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xcp (iname, oname, xsize) char * iname , * oname ; long xsize ; {

	register int i, bytio ;
	register int percok, perctob, scalok, scaltob ;
	register long filebyts = 0L ;
	register long xtotb = totbyts ;
			 char * xp = NULL ;
# ifdef DOS
	struct ftime xftp ;
# endif /* DOS */

	if ((ifp = fopen (iname, "rb")) == NULL) {
		cursorat (19,2) ; printf ("arquivo abaixo nao encontrado :") ;
		cursorat (20,2) ; printf ("%-76s", iname) ;
		cursorat (21,2) ; printf ("Tecle [Enter] ") ;
		xp = fgets (resp, 40, stdin) ;
		return ;
	}

	if ((ofp = fopen (oname, "wb")) == NULL) {
		cursorat (19,2) ; printf ("ERRO ao criar arquivo abaixo :") ;
		cursorat (20,2) ; printf ("%-76s", oname) ;
		cursorat (21,2) ; printf ("Tecle [Enter] ") ;
		xp = fgets (resp, 40, stdin) ;
		return ;
	}

	cursorat (LIN_ORIG_NAME, COL_ORIG_NAME) ;
	printf ("%-66s", iname) ;

	cursorat (LIN_DEST_NAME, COL_DEST_NAME) ;
	printf ("%-66s", oname) ;

	cursorat (LIN_FILBYT_VAL, COL_SCALE) ;
	for ( i = 0 ; i < SCALE ; ++i )
		putchar (YET) ;

	cursorat (LIN_FILBYT_VAL, COL_FILBYT_VAL) ;
	printf ("%10ld", xsize) ;

	while ((bytio = fread (cpbuf, 1, VBSIZ, ifp)) > 0) {

		fwrite (cpbuf, 1, bytio, ofp) ;
		filebyts += bytio ; allbyts += bytio ;
		vestim () ;

		percok = (int) ( ( filebyts * 100 ) / xsize ) ;
		scalok = ( SCALE * percok ) / 100 ;
		cursorat (LIN_FILBYT_VAL, COL_PERC) ;
		printf ("%3d", percok) ;
		cursorat (LIN_FILBYT_VAL, COL_SCALE) ;
		for ( i = 0 ; i < scalok ; ++i )
			putchar (VOK) ;
		cursorat (LIN_FILBYT_VAL, 2) ;
		printf ("%10ld", filebyts) ;

		perctob = (int) ( ( allbyts * 100 ) / xtotb ) ;
		scaltob = ( SCALE * perctob ) / 100 ;
		cursorat (LIN_TOTBYT_VAL, COL_PERC) ;
		printf ("%3d", perctob) ;
		cursorat (LIN_TOTBYT_VAL, COL_SCALE) ;
		for ( i = 0 ; i < scaltob ; ++i )
			putchar (VOK) ;
		cursorat (LIN_TOTBYT_VAL, 2) ;
		printf ("%10ld", allbyts) ;
	}

# ifdef DOS
	if (getftime (fileno (ifp), &xftp) == 0) {
		setftime (fileno (ofp), &xftp) ;
	}
# endif /* DOS */

	fclose (ifp) ; fclose (ofp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void invest () {

	itiks = militime () ;
	maxest = -1L ;
	minest = 999999999L ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void vestim () {
	register long esecs ;
	register long brat = totbyts / allbyts ;
	register long rtiks, rsecs ;
	long xh, xm, xs ;

	rtiks = militime () - itiks ;
	rsecs = ( rtiks / 1000 ) ;
	esecs = ( ( brat * rtiks ) / 1000 ) ;

	ltohms (rsecs, &xh, &xm, &xs) ;
	cursorat (16,28) ;
	printf ("%02ld:%02ld:%02ld", xh, xm, xs) ;

	ltohms (esecs, &xh, &xm, &xs) ;
	cursorat (16, 9) ;
	printf ("%02ld:%02ld:%02ld", xh, xm, xs) ;

	if (esecs < minest) {
		minest = esecs ;
		ltohms (minest, &xh, &xm, &xs) ;
		cursorat (15, 9) ;
		printf ("%02ld:%02ld:%02ld", xh, xm, xs) ;
	}

	if (esecs > maxest) {
		maxest = esecs ;
		ltohms (maxest, &xh, &xm, &xs) ;
		cursorat (17, 9) ;
		printf ("%02ld:%02ld:%02ld", xh, xm, xs) ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void ltohms (ns, ph, pm, ps) long ns ; long * ph, * pm, * ps ; {

	*ph = *pm = *ps = 0L ;

	if ((*ph = ns / 3600) > 0L)
		ns -= *ph * 3600 ;

	if ((*pm = ns / 60) > 0L)
		ns -= *pm * 60 ;

	*ps = ns ;
}

/*		 ___________________________________________________________
 *		|															|
 *		|		militime : miliseconds elapsed since midnight		|
 *		|___________________________________________________________|
 */

long militime () {

	struct timeb tb ;
	register struct tm * tp ;
	register long mt ;

	ftime (&tb) ;
	tp = localtime (&tb.time) ;
	mt  = ( tp->tm_min  *   60 ) + tp->tm_sec ;
	mt += ( tp->tm_hour * 3600 ) ;
	mt *= 1000 ;
	mt += tb.millitm ;

	return mt ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void cursorat (int lin, int col) {

# ifdef DOS
	gotoxy (col+1, lin+1) ;
# else  /* ANYX */
	printf ("\033[%d;%dH", lin, col) ; fflush (stdout) ;
# endif /* DOS */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void clearscreen () {

# ifdef DOS
	clrscr () ;
# else  /* ANYX */
	printf ("\014") ; fflush (stdout) ;
# endif /* DOS */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 *	xcp + fancy cp ...
 *
 *	10/03/92	v1.0	file-2-file cp, %, bar
 *	11/03/92	v1.1	many-files 2 dir
 *	12/03/92	v1.2	estimated & elapsed time
 *	13/12/92	v1.3	touch dest as src
 *
 *	cc -DCYGWIN -DLABIX -Wall -Wextra -O3 -o xcp xcp.c stdmem.c stdmisc.c
 *
 *	round-midnight copies craps estimated time on dos.
 */

/*		 ___________________________________________________________
 *		|															|
 *		|  date....   version   history...........................	|
 *		|			 		   										|
 *		|  94 02 23   1.2 201   portability edition					|
 *		|     05 20       236   milisecond precision				|
 *		|___________________________________________________________|
 *		|															|
 *		|  + chg biostime (dos ticks) to miliseconds (port/y)		|
 *		|    this'll be done initially as per flag (-m, from mili-	|
 *		|    -second precision) for test & validation purposes.		|
 *		|    when implemented ok, the biostime & ticks dos stuff	|
 *		|    will be permanently expunged from the source code.		|
 *		|															|
 *		|  + display rates (i, o, i/o : worst, best, mean, current)	|
 *		|															|
 *		|  + impl. verify (-v) option : read-after-write			|
 *		|															|
 *		|  + user-given buffer size (-b #) ...						|
 *		|___________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
