/*
 *	version.h
 */

# ifndef _VERSION_H_

# define _VERSION_H_

extern const char * bal_program_string ;
extern const char * bal_version_string ;
extern const char * bal_release_string ;
extern const char * bal_relogio_string ;
extern const char * bal_summary_string ;
extern const char * bal_taglist_string ;
extern const char * bal_license_string ;
extern const char * bal_creator_string ;
extern const char * bal_contact_string ;
extern const char * bal_builder_string ;
extern const char * bal_compile_string ;

	/*  legacy  */

# define	SWNAME		bal_program_string
# define	SWVERS		bal_version_string
# define	SWDATE		bal_release_string
# define	SWTIME		bal_relogio_string
# define	SWDESC		bal_summary_string
# define	SWTAGS		bal_taglist_string
# define	SWCOPY		bal_license_string
# define	SWAUTH		bal_creator_string
# define	SWMAIL		bal_contact_string
# define	SWBLDR		bal_builder_string
# define	SWCOMP		bal_compile_string

# define	SWFORG		" " /* deprecated */

# endif /* _VERSION_H_ */

/*
 * vi:nu ts=8
 */
