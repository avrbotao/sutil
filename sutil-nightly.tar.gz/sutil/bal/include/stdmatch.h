
/*		 _______________________________________________________________
 *		|																|
 *		|	stdmatch.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDMATCH_H

# define _STDMATCH_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef TC2

#	define	WILDCHARLIST	"*?[]^$~"
#	define	MATCHALL		"*.*"

# endif

# ifdef MSVC

#	define	WILDCHARLIST	"*?[]^$~"
#	define	MATCHALL		"*.*"

# endif

# ifdef	ANYX

#	define	WILDCHARLIST	"*?[]^$~\\"
#	define	MATCHALL		"*"

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int				patmat		OF ( ( char * , char * )					) ;
int				isaregexp	OF ( ( char * )								) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDMATCH_H */

