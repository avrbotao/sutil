
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdlogic.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# ifndef _STDLOGIC_H

# define _STDLOGIC_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	XOR(A,B)	( ( (! (A)) && (B) ) || ( (! (B)) && (A) ) )

# define	SETBIT(V,B)		V |= B

# ifndef	FALSE
#	define	FALSE		(0)
# endif  /* FALSE */

# ifndef	TRUE
# define	TRUE		(-1)
# endif  /* TRUE */

# define	AND			&&
# define	OR			||
# define	NOT			!

# define	EQL			==
# define	NEQ			!=
# define	LEQ			<=
# define	GEQ			>=
# define	LST			<
# define	GRT			>

# define	EQ			==
# define	NE			!=
# define	LE			<=
# define	GE			>=
# define	LT			<
# define	GT			>

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDLOGIC_H */

/*
 * vi:nu ts=4
 */
