
/*		 _______________________________________________________________
 *		|																|
 *		|	stdparm.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDPARM_H

# define _STDPARM_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef MSVC

# include	<io.h>

typedef		struct _finddatai64_t	FFBLK ;

/* # define	FA_MASK				(FA_ARCH|FA_DIREC|FA_RDONLY|FA_SYSTEM|FA_HIDDEN) */

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		TC2

# include	<dir.h>
# include	<dos.h>

typedef		struct ffblk		FFBLK ;

# define	FA_MASK				(FA_ARCH|FA_DIREC|FA_RDONLY|FA_SYSTEM|FA_HIDDEN)

# endif		/* TC2 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

struct	parminfo {

	int		pi_chr ;
	int *	pi_var ;
	char *	pi_ptr ;
	int		pi_flg ;
	int		pi_val ;

} ;

typedef		struct parminfo		PARMINFO ;

# define	PI_SETVAL			0x0001
# define	PI_SETBUF			0x0002
# define	PI_SETBIT			0x0004
# define	PI_SETNUM			0x0008

# define	PI_SYNTAXBIT		0x0001
# define	PI_ENVIRONBIT		0x0002
# define	PI_LICENSEBIT		0x0004
# define	PI_VERSIONBIT		0x0008

# define	PI_DEBUGBIT			0x0010

# define	FLAGPREFIX			'-'

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

extern	int			argk ;
extern	char * *	argp ;

extern	int			totparms ;
extern	int			sortargsflag ;
extern	char * *	parmlist ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void	setargent	OF ( ( int , char * * )						) ;
void	parseargs	OF ( ( void )								) ;
void	parseflags	OF ( ( char * )								) ;
void	parsebits	OF ( ( void )								) ;
void	endargent	OF ( ( void )								) ;

char *	getargent	OF ( ( void )								) ;
char *	getargpos	OF ( ( int )								) ;
void	putargent	OF ( ( char * )								) ;

# if defined (TC3) || defined (MSVC)
int		parmcmp		OF ( ( const void * , const void * )		) ;
# else
int		parmcmp		OF ( ( char * * , char * * )				) ;
# endif

# if defined (TC2) || defined (MSVC)

void	blowild		OF ( ( char * )								) ;
void	argrow		OF ( ( char * )								) ;

# endif /* TC2 || MSVC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDPARM_H */

