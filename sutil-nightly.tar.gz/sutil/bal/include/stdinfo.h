
int	flagbits = 0x0000 ;

# if 0

char * swid = SWNAME ;

char * verinf [] = { SWNAME, VERSION, VERCODE, VERDATE, OPSYS, VERSIGN } ;

# else

char * swid = NULL ;

char * verinf [] = { NULL, NULL, NULL, NULL, NULL, NULL } ;

# endif

char * optinf [] = {

	CTYPE		,
	ERRNO		,
	FCNTL		,
	MATH		,

	STDIO		,
	STDLIB		,

	SYSTYPES	,

	STDAPP		,
	STDASC		,
	STDBOX		,
	STDBUG		,
	STDCAP		,
	STDCMD		,
	STDCOLOR	,
	STDCRC		,
	STDDIR		,
	STDKEY		,
	STDLIC		,
	STDLIST		,
	STDLOG		,
	STDLOGIC	,
	STDMATCH	,
	STDMEM		,
	STDMISC		,
	STDMSG		,
	STDNET		,
	STDPARM		,
	STDSIG		,
	STDSTAT		,
	STDSTR		,
	STDTERM		,
	STDTIME		,
	STDTIO		,
	STDTYP		,
	STDVIF		,
	STDWIN		,
	STDXFS		,
	STDXAR		,

	NULL
} ;

