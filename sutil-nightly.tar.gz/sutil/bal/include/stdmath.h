
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*	 _______________________________________________________________
 *	|								|
 *	|	stdmath.h		 (c) 1998 Alexandre Botao	|
 *	|_______________________________________________________________|
 */

# ifndef _STDMATH_H

# define _STDMATH_H

/*	--	--	--	--	--	--	--	--	*/

typedef		sbit64		BINT ;

/*	--	--	--	--	--	--	--	--	*/

BINT		gcd2	OF ( (BINT, BINT)	) ;
BINT		modexp	OF ( (BINT, BINT, BINT)	) ;
BINT		modinv	OF ( (BINT, BINT)	) ;

/*	--	--	--	--	--	--	--	--	*/

# endif /* _STDMATH_H */

/*
 * vi:nu ts=8
 */
