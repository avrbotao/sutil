
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*		 ___________________________________________________________
 *		|															|
 *		|	abc.h					(c) 1990-2006 Alexandre Botao	|
 *		|___________________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# ifndef _ABC_H

# define _ABC_H

#ifdef SRCIDENT
# define	ABCHIDENT	"@(#)abc.h	25.41	2007/04/12	avrb"
# ifdef PRAGIDEN
# pragma ident	ABCHIDENT
# endif
#endif

# include	"abcs.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef OPER_SYS_ENV		/*	operating system environments ...		*/

	VER7	SYSV	BSD		ANYX	XWIN	HURD	BEOS	VNOS
	MAC		DOS		WIN		LINUX	NEWOS	NETWARE	MENUET

# endif /* OPER_SYS_ENV */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef PROC_FAM			/*	processor family ...					*/

	ALPHA	ARM		HPPA
	IA8		IA16	IA32	IA64
	M68K	PPC		S390	SPARC

# endif /* PROC_FAM */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef STD_ENV				/*	standards conformance environments ...	*/

	ANSI	BSD		ISO		POSIX	SVID	XOPEN	XPGN

# endif /* STD_ENV */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef COMPILER_ENV		/*	compiler environments ...				*/

	KRC		ANSIC	__STDC__
	GCC		TC2		TC3		MSC6	MSVC	SUNC	AIXC	HPXC	MACC

# endif /* COMPILER_ENV */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef THREADS_ENV			/*	threads environments ...				*/

	STPTHR	CTHREADS	MACH_CTHREADS			/* nextstep / openstep	*/
	LWPTHR	LTHREADS	SUNOS_LWP_THREADS
	WNTTHR	NTHREADS	NT_THREADS
	PSXTHR	PTHREADS	POSIX_THREADS
	SOLTHR	STHREADS	SOLARIS_THREADS
	GNUTHR	GTHREADS	GNU_THREADS				/* GNU_PTH				*/
	FAKTHR	FTHREADS	STUB_THREADS			/* fake threads			*/

# define MACTHR STPTHR

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef OS_NAMES

	MACOSX		GNUHURD		MENUET		NEWOS		VNOS		BEOS
	DARWIN		GNUDARWIN	SHARK		DGUX

	WIN31		WIN95		WIN98
	WINCE		WINME		WINNT
	WIN2K		WIN2K3		WINXP

	all these to define LINUX below ...

	2000
	CONECTIVA	COREL
	DEBIAN		DEFINITY
	INSIGNE
	KNOPPIX		KURUMIN
	LINDOWS		LINDOWSOS
	MOSIX		MSC
	RTLINUX
	SLACKWARE	STORM		SUSE
	TECH		TURBO

	LINUXPPC	YELLOWDOG	IMMUNIX		TRUSTIX		STAMPEDE	DEMOLINUX
	PEANUTLNX	ICEPACKLNX	ASPLINUX	LYCORIS		ENGARDESEC	VECTORLNX
	LIBRANET	JBLINUX		PLDLNXDSTR	KNOPPIX		GENTOOLNX	MINIRTL
	ELXLINUX	PHATLINUX	OWL			ZIPSLACK	SOTLINUX	ALTLINUX
	FREEDUC		BLACKRHINO	ASTAROSECURITYLINUX		TOPOLOGILINUX
	PLAMO		FEDORA

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef SHORT_OS_NAMES

	CLD	CLDR	caldera
	HPX	HPUX	hp-ux
	KNP	KNPX	knoppix
	MDK	MDRK	mandrake
	RHT	RDHT	redhat
	SOL	SLRS	solaris

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		MANDRAKE
#	define	LINUX
#	define	OPSYS			"MANDRAKE_LINUX"
# endif

# ifdef		REDHAT
#	define	LINUX
#	define	OPSYS			"REDHAT_LINUX"
# endif

# ifdef		UBUNTU
#	define	LINUX
#	define	OPSYS			"UBUNTU_LINUX"
#	define	HARDCOPY
/*
#	include <asm/termios.h>
*/
# endif

# ifdef		SUSE
#	define	LINUX
#	define	OPSYS			"SUSE_LINUX"
#	define	HARDCOPY
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		FREEBSD
#	define	BSD
#	define	OPSYS			"FREEBSD"
# endif

# ifdef		NETBSD
#	define	BSD
#	define	OPSYS			"NETBSD"
# endif

# ifdef		OPENBSD
#	define	BSD
#	define	OPSYS			"OPENBSD"
# endif

# ifdef		TRUSTEDBSD
#	define	BSD
#	define	OPSYS			"TRUSTEDBSD"
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		BCC55

#	define	DOS
#	define	far

# endif		/* BCC55 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		TC2

#	define	DOS
#	define	ANSI
#	define	C_MKDIR
#	define	MEMLEFTOK
#	define	NONET

#	define	DIRSEP			'\\'	/* BACKSLASH */
#	define	MAINTYPE		void

#	define	lstat(X,Y)		stat(X,Y)

# endif		/* TC2 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		DOS

#	define	OPSYS			"DOS"

# endif		/* DOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		MSVC

#	define	WIN32
#	define	ANSI
#	define	C_MKDIR
#	define	MEMLEFTOK
#	define	NONET

#	define	DIRSEP			'\\'	/* BACKSLASH */
#	define	MAINTYPE		void

#	define	lstat(X,Y)		stat(X,Y)

# endif		/* MSVC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		WIN32

#	define	OPSYS			"WIN32"

# endif		/* WIN32 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		AIX

#	define	OPSYS			"AIX"

#	define	ANYX
#	define	STRERROR
#	define	MEMLEFTOK
#	define	SYSVDIR
#	define	READ_COUNT
#	define	POSIX_MKDIR
#	define	MAINTYPE		int

#	define	NOMEMICMP
#	define	NOSTRICMP

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

# endif		/* AIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		BOSX

# define	OPSYS			"BOSX"

# define	ANYX
# define	SYSVDIR
#	define	POSIX_MKDIR

# endif		/* BOSX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		HPUX

#	define	OPSYS			"HPUX"

#	define	ANYX
#	define	SYSVDIR
#	define	READ_COUNT
#	define	POSIX_MKDIR
/* #	define	C_MKDIR */
#	define	STRERROR
#	define	NOSTRICMP

#if defined (__HP_cc)
# if __HP_cc == 111108
#  define	NOCONST
# endif
#endif

#ifdef	NOCONST
# define	const
#endif

# endif		/* HPUX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		LINUX

#	if ! defined (OPSYS)
#		define	OPSYS		"LINUX"
#	endif

#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	SYSVDIR

#	define	GCC

#	define	READ_COUNT
/* #	define	READ_DELAY	*/

#	define	NONET
#	define	LINUXIOCTLS
#	define	MAINTYPE		int

#	define	USE_TERMIOS
#	define	POSIX_MKDIR

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

# endif		/* LINUX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		CYGWIN

#	if ! defined (OPSYS)
#		define	OPSYS		"CYGWIN"
#	endif

#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	SYSVDIR

#	define	GCC

#	define	READ_COUNT
#	define	FIONREAD	TIOCINQ

#	define	NONET
/*	#	define	LINUXIOCTLS	*/
#	define	MAINTYPE		int

#	define	USE_TERMIOS
#	define	POSIX_MKDIR
#	define	HARDCOPY

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

# endif		/* CYGWIN */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		BSD

#	if ! defined (OPSYS)
#		define	OPSYS		"BSD"
#	endif

#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	SYSVDIR

#	define	GCC

#	define	READ_COUNT
/* #	define	READ_DELAY	*/

#	define	MAINTYPE		int

#	define	USE_TERMIOS
#	define	POSIX_MKDIR
/* #	define	C_MKDIR */

#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"

# endif		/* BSD */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SUNX
#	define	SOLARIS
# endif		/* SUNX */

# ifdef		SUNOS

#	define	OPSYS			"SUNOS"

/* #	define	SUNX	*/
#	define	ANYX
#	define	SYSVDIR
#	define	USE_TERMIOS
#	define	READ_COUNT
#	define	C_MKDIR

/* #	include <sys/filio.h> */

# endif		/* SUNOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SOLARIS

#	define	OPSYS			"SOLARIS"

#	define	ANYX
#	define	GETRLIMIT
#	define	STRERROR
#	define	USE_TLI
#	define	SYSVDIR
#	define	NOSTRICMP
#	define	NOMEMICMP
#	define	USE_TERMIOS
#	define	READ_DELAY
#	define	TCPNETDEV		"/dev/tcp"
#	define	UDPNETDEV		"/dev/udp"
#	define	MAINTYPE		int

# endif		/* SOLARIS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		TRU64

# define	OPSYS			"TRU64"

# define	ANYX
# define	SYSVDIR
# define	C_MKDIR

# endif		/* TRU64 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		DYNIX

# define	OPSYS			"DYNIX"

# define	ANYX
# define	SYSVDIR
# define	C_MKDIR

# endif		/* DYNIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		OSF1

# define	OPSYS			"OSF1"

# define	ANYX
# define	SYSVDIR
# define	C_MKDIR

# endif		/* OSF1 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		UNICOS

# define	OPSYS			"UNICOS"

# define	ANYX
# define	SYSVDIR

# endif		/* UNICOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		IRIX

# define	OPSYS			"IRIX"

# define	ANYX
# define	SYSVDIR

# endif		/* IRIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		NEXTSTEP

# define	OPSYS			"NEXTSTEP"

# define	ANYX
# define	SYSVDIR

# endif		/* NEXTSTEP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		OPENUNIX

# define	OPSYS			"OPENUNIX"

# define	ANYX
# define	SYSVDIR

# endif		/* OPENUNIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		RELIANTUNIX

# define	OPSYS			"RELIANTUNIX"

# define	ANYX
# define	SYSVDIR

# endif		/* RELIANTUNIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		ULTRIX

#	define	OPSYS			"ULTRIX"

#	define	ANYX
#	define	READ_COUNT
#	define	C_MKDIR

# endif		/* ULTRIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SCOUNIX

# define	OPSYS			"SCO_UNIX"

# define	ANYX
# define	SYSVDIR

# endif		/* SCOUNIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SCOXENIX

#	define	OPSYS			"SCO_XENIX"

typedef		unsigned short		mode_t ;

#	define	ANYX
#	define	SH_MKDIR
#	define	READ_DELAY
#	define	OLD_KEYNAMES
#	define	VRAMCOLOR
#	define	SYSULIMIT

#	define	NOMEMICMP
#	define	NOSTRICMP
#	define	NONET

#	define	FIONREAD		FIORDCHK

#	define	lstat(X,Y)		stat(X,Y)

# endif		/* SCOXENIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		UNIXWARE

# define	OPSYS			"UNIXWARE"

# define	ANYX
# define	SYSVDIR

# endif		/* UNIXWARE */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		IUX

#	define	OPSYS			"INTERACTIVE"

#	define	ANYX
#	define	SYSVDIR

typedef		unsigned short		mode_t ;

# endif		/* IUX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		EDIX

# define	OPSYS		"EDIX"

# define	ANYX
# define	NO_STDLIB_H
# define	VOIDINT

# endif		/* EDIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		DIGIX

# define	OPSYS		"DIGIX"

# define	ANYX

# define	NO_STDLIB_H

# endif		/* DIGIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SIDIX

# define	OPSYS		"SIDIX"

# define	ANYX

# define	NO_STDLIB_H
# define	VOIDINT

# endif		/* SIDIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		SIX

# define	OPSYS		"SIX"

# define	ANYX
# define	NO_STDLIB_H
# define	SYSVDIR

# endif		/* SIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef GCC
#	define	typeof			_type_of_
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef WHO_KNOWS /* ? */

	SCOODT	XINU	MINIX	QNX		OS2		SOX		(TANDEM)NSK

# endif /* WHO_CARES ? */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	libabc definitions ...						|
 *					|_______________________________________________|
 */

# ifdef		ANYX

# define	DIRSEP			'/'		/* SLASH */

# endif		/* ANYX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		ANSI

#	define				OF(X)	X

# else		/* OLD */

#	define				OF(X)	()

# endif		/* ANSI */

# define	EVER		;;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef		NOVOID
#	define	void
# endif		/* NOVOID */

# ifdef		VOIDINT
#	define	void	int
# endif		/* VOIDINT */

# ifndef	SEEK_SET
# define	SEEK_SET			0
# endif		/* ! SEEK_SET */

# ifndef	SEEK_CUR
# define	SEEK_CUR			1
# endif		/* ! SEEK_CUR */

# ifndef	SEEK_END
# define	SEEK_END			2
# endif		/* ! SEEK_END */

# define	PTRSIZ			(sizeof(char *))

# define	XA_FATAL		0x4000
# define	XA_BANAL		0x2000

# define	COPYCRC			0x0001
# define	COPYBIN			0x0002
# define	COPYASC			0x0004

# define	CHRON_TIME

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef	X64BITS

typedef		long long		LONGINT ;

#	define	LIFMT			"%12lld"

# else	/* X32BITS */

typedef		long			LONGINT ;

#	define	LIFMT			"%12ld"

# endif /* X64BITS */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	operating system includes ...				|
 *					|_______________________________________________|
 */

# ifdef USE_MATH

#	include	<math.h>

#	define	MATH			"^MATH"

# else

#	define	MATH			"~MATH"

# endif /* USE_MATH */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDIO

#	include	<stdio.h>

#	define	STDIO			"^STDIO"

# else

#	define	STDIO			"~STDIO"

# endif /* USE_STDIO */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDLIB

#	include	<stdlib.h>

#	define	STDLIB			"^STDLIB"

# else

#	define	STDLIB			"~STDLIB"

# endif /* USE_STDLIB */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_CTYPE

#	include	<ctype.h>

#	define	CTYPE			"^CTYPE"

# else

#	define	CTYPE			"~CTYPE"

# endif /* USE_CTYPE */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_ERRNO

#	include	<errno.h>

#	define	ERRNO			"^ERRNO"

# else

#	define	ERRNO			"~ERRNO"

# endif /* USE_ERRNO */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_FCNTL

#	include	<fcntl.h>

#	define	FCNTL			"^FCNTL"

# else

#	define	FCNTL			"~FCNTL"

# endif /* USE_FCNTL */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_SYSTYPES

#	include	<sys/types.h>

#	define	SYSTYPES		"^SYSTYPES"

# else

#	define	SYSTYPES		"~SYSTYPES"

# endif /* USE_SYSTYPES */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_UNISTD

#	include	<unistd.h>

#	define	UNISTD		"^UNISTD"

# else

#	define	UNISTD		"~UNISTD"

# endif /* USE_UNISTD */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	libabc includes ...							|
 *					|_______________________________________________|
 */

# ifdef	USE_ABX

#	include	"abx.h"

#	define	STDABX			"+ABX"

# else

#	define	STDABX			"-ABX"

# endif	/* USE_ABX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef	USE_STDSTAT

#	include	"stdstat.h"

#	define	STDSTAT			"+STDSTAT"

# else

#	define	STDSTAT			"-STDSTAT"

# endif	/* USE_STDSTAT */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDTIME

#	include	"stdtime.h"

#	define	STDTIME			"+STDTIME"

# else

#	define	STDTIME			"-STDTIME"

# endif /* USE_STDTIME */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDMATCH

#	include "stdmatch.h"

#	define	STDMATCH		"+STDMATCH"

# else

#	define	STDMATCH		"-STDMATCH"

# endif /* USE_STDMATCH */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDASC

#	include "stdasc.h"

#	define	STDASC			"+STDASC"

# else

#	define	STDASC			"-STDASC"

# endif /* USE_STDASC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDLOGIC

#	include "stdlogic.h"

#	define	STDLOGIC		"+STDLOGIC"

# else

#	define	STDLOGIC		"-STDLOGIC"

# endif /* USE_STDLOGIC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDCOLOR

#	include "stdcolor.h"

#	define	STDCOLOR		"+STDCOLOR"

# else

#	define	STDCOLOR		"-STDCOLOR"

# endif /* USE_STDCOLOR */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDTYP

#	include "stdtyp.h"

#	define	STDTYP			"+STDTYP"

# else

#	define	STDTYP			"-STDTYP"

# endif /* USE_STDTYP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDMATH

#	include	"stdmath.h"

#	define	STDMATH			"+STDMATH"

# else

#	define	STDMATH			"-STDMATH"

# endif /* USE_STDMATH */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDCMD

#	include "stdcmd.h"

#	define	STDCMD			"+STDCMD"

# else

#	define	STDCMD			"-STDCMD"

# endif /* USE_STDCMD */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDCAP

#	include "stdcap.h"

#	define	STDCAP			"+STDCAP"

# else

#	define	STDCAP			"-STDCAP"

# endif /* USE_STDCAP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDWIN

#	include "stdwin.h"

#	define	STDWIN			"+STDWIN"

# else

#	define	STDWIN			"-STDWIN"

# endif /* USE_STDWIN */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDVIF

#	include "stdvif.h"

#	define	STDVIF			"+STDVIF"

# else

#	define	STDVIF			"-STDVIF"

# endif /* USE_STDVIF */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDKEY

#	include "stdkey.h"

#	define	STDKEY			"+STDKEY"

# else

#	define	STDKEY			"-STDKEY"

# endif /* USE_STDKEY */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDTIO

#	include "stdtio.h"

#	define	STDTIO			"+STDTIO"

# else

#	define	STDTIO			"-STDTIO"

# endif /* USE_STDTIO */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDTERM

#	include "stdterm.h"

#	define	STDTERM			"+STDTERM"

# else

#	define	STDTERM			"-STDTERM"

# endif /* USE_STDTERM */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDBOX

#	include "stdbox.h"

#	define	STDBOX			"+STDBOX"

# else

#	define	STDBOX			"-STDBOX"

# endif /* USE_STDBOX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDLOG

#	include "stdlog.h"

#	define	STDLOG			"+STDLOG"

# else

#	define	STDLOG			"-STDLOG"

# endif /* USE_STDLOG */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDBUG

#	include "stdbug.h"

#	define	STDBUG			"+STDBUG"

# else

#	define	STDBUG			"-STDBUG"

# endif /* USE_STDBUG */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDPARM

#	include "stdparm.h"

#	define	STDPARM			"+STDPARM"

# else

#	define	STDPARM			"-STDPARM"

# endif /* USE_STDPARM */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDDIR

#	include "stddir.h"

#	define	STDDIR			"+STDDIR"

# else

#	define	STDDIR			"-STDDIR"

# endif /* USE_STDDIR */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDPATH

#	include "stdpath.h"

#	define	STDPATH			"+STDPATH"

# else

#	define	STDPATH			"-STDPATH"

# endif /* USE_STDPATH */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STRLIST

#	include "strlist.h"

#	define	STDLIST			"+STDLIST"

# else

#	define	STDLIST			"-STDLIST"

# endif /* USE_STRLIST */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDCRC

#	include "stdcrc.h"

#	define	STDCRC			"+STDCRC"

# else

#	define	STDCRC			"-STDCRC"

# endif /* USE_STDCRC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDAPP

#	include "stdapp.h"

#	define	STDAPP			"+STDAPP"

# else

#	define	STDAPP			"-STDAPP"

# endif /* USE_STDAPP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDLIC

#	include "stdlic.h"

#	define	STDLIC			"+STDLIC"

# else

#	define	STDLIC			"-STDLIC"

# endif /* USE_STDLIC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDMISC

#	include "stdmisc.h"

#	define	STDMISC			"+STDMISC"

# else

#	define	STDMISC			"-STDMISC"

# endif /* USE_STDMISC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDSTR

#	include	"stdstr.h"

#	define	STDSTR			"+STDSTR"

# else

#	define	STDSTR			"-STDSTR"

# endif /* USE_STDSTR */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDFILE

#	include	"stdfile.h"

#	define	STDFILE			"+STDFILE"

# else

#	define	STDFILE			"-STDFILE"

# endif /* USE_STDFILE */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDSIG

#	include "stdsig.h"

#	define	STDSIG			"+STDSIG"

# else

#	define	STDSIG			"-STDSIG"

# endif /* USE_STDSIG */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDMEM

#	ifdef	TC2

#		include	<mem.h>

#	endif	/* TC2 */

#	include "stdmem.h"

#	define	STDMEM			"+STDMEM"

# else  /* USE_SYSMEM */

#	ifdef USE_SYSMEM

#		define	xmalloc(s)		malloc(s)
#		define	xmcalloc(n,e)	calloc(n,e)
#		define	xmrealloc(p,s)	realloc(p,s)
#		define	xmfree(p)		free(p)

#	define	SYSMEM			"+SYSMEM"

#	else  /* USE_SYSMEM */

#	define	SYSMEM			"-SYSMEM"

#	endif /* USE_SYSMEM */

#	define	STDMEM			"-STDMEM"

# endif /* USE_STDMEM */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDMSG

#	include "stdmsg.h"

#	define	STDMSG			"+STDMSG"

# else

#	define	STDMSG			"-STDMSG"

# endif /* USE_STDMSG */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDNET

#	include "stdnet.h"

#	define	STDNET			"+STDNET"

# else

#	define	STDNET			"-STDNET"

# endif /* USE_STDNET */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDXFS

#	include "stdxfs.h"

#	define	STDXFS			"+STDXFS"

# else

#	define	STDXFS			"-STDXFS"

# endif /* USE_STDXFS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDREX

#	include "stdrex.h"

#	define	STDREX			"+STDREX"

# else

#	define	STDREX			"-STDREX"

# endif /* USE_STDREX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef USE_STDXAR

#	include "stdxar.h"

#	define	STDXAR			"+STDXAR"

# else

#	define	STDXAR			"-STDXAR"

# endif /* USE_STDXAR */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _ABC_H */

/*
 * vi:nu tabstop=4
 */
