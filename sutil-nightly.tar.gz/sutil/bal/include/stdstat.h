
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdstat.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# ifndef _STDSTAT_H

# define _STDSTAT_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include	<sys/stat.h>

struct		utmbuf		{
	time_t	atime ;
	time_t	mtime ;
} ;

typedef		struct utmbuf	UTMBUF ;

typedef		struct stat		STABUF ;

# define	STABUFSIZ		(sizeof(STABUF))

# define	T_FILE			'f'
# define	T_DIR			'd'
# define	T_BLK			'b'
# define	T_CHR			'c'
# define	T_FIFO			'p'
# define	T_LINK			'l'
# define	T_SOCK			's'
# define	T_NONE			'?'

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STABUF *	statof			OF ( ( char * )					) ;
STABUF *	laststat		OF ( ( void )					) ;

int			typeof			OF ( ( STABUF * )				) ;
long		bytesof			OF ( ( STABUF * )				) ;
long		timeof			OF ( ( STABUF * )				) ;

int			filetype		OF ( ( char * )					) ;
long		filesize		OF ( ( char * )					) ;
long		filetime		OF ( ( char * )					) ;

char *		strmodes			OF ( ( long /* mode_t */ )		) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDSTAT_H */

/*
 * vi:nu ts=4
 */
