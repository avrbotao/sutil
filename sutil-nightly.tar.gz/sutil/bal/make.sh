set -x
cc -Wall -I ./include -o bal ./src/*.c
