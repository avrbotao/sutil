
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdtime.c						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

/* # include "configure.h" */

# ifdef AIX71
#include <sys/types.h>
typedef uint_t          rid_t;          /* role ID */
# endif /* AIX71 */

# ifdef LABIX

#	define	USE_STDIO
#	define	USE_STDTYP
#	define	USE_STDMATH
#	define	USE_STDTIME
#	include	"abc.h"

# else /* PLAIN */

# include	"abc.h"
# include	<stdio.h>
# include	<time.h>
# include	<string.h>
# include	"stdtyp.h"
# include	"stdmath.h"
# include	"stdtime.h"

# endif /* LABIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef GCDTIMES

BINT diftod (tvp1, tvp2) struct timeval * tvp1, * tvp2 ; {

	BINT sec1, sec2, usec1, usec2, d ;

	sec1 = tvp1->tv_sec ;
	sec2 = tvp2->tv_sec ;
	usec1 = tvp1->tv_usec ;
	usec2 = tvp2->tv_usec ;

	d = (1000000 * (sec2 - sec1)) + (usec2 - usec1) ;

	return d ;
}

char * fmtus (t) BINT t ; {

	BINT u, s, m, h ;
	static char b [64] ;

	u = t % 1000000 ;
	s = t / 1000000 ;
	m = s / 60 ;
	h = m / 60 ;

	sprintf (b, "%02lld:%02lld:%02lld:%06lld", h, m, s, u) ;

	return b ;
}

# endif /* GCDTIMES */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef CHRON_TIME			/* using time()				*/

time_t	gc1time, gc2time, gcdtime ;

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock() - wraps around after 2147 secs		*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * monport [] = {
	"jan" , "fev" , "mar" , "abr" , "mai" , "jun" ,
	"jul" , "ago" , "set" , "out" , "nov" , "dez" ,
	NULL
} ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void setchron (flg) int flg ; {		/* start chronometer		*/

# ifdef CHRON_TIME			/* using time()				*/

	if (flg & CF_TIME) {
		time (&gc1time) ;
	}

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock()			*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

}

void endchron (flg) int flg ; {		/* stop chronometer			*/

# ifdef CHRON_TIME			/* using time()				*/

	if (flg & CF_TIME) {
		time (&gc2time) ;
	}

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock()			*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

}

void difchron (flg) int flg ; {		/* eval chronometer			*/

# ifdef CHRON_TIME			/* using time()				*/

	if (flg & CF_TIME) {
		gcdtime = gc2time - gc1time ;
	}

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock()			*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * strtime (tloc) time_t tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = /* gmtime */ localtime ( &tloc ) ;

	sprintf ( buf , "%02d:%02d:%02d" ,

				tp->tm_hour , tp->tm_min , tp->tm_sec ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * strhourmin (tloc) time_t tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%02d:%02d" , tp->tm_hour , tp->tm_min ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * strdate (tloc) time_t tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%4d/%02d/%02d" ,

				tp->tm_year + 1900 , tp->tm_mon + 1 , tp->tm_mday ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * strdaymon (tloc) time_t tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%02d/%3s" , tp->tm_mday , monport[tp->tm_mon] ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * timestamp (tloc, tflg) time_t tloc ; int tflg ; {

	static char buf [64] ;
	register char * fmt = NULL ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	if ( tflg == RAWSTAMP )
		fmt = "%4d%02d%02d%02d%02d%02d" ;

	if ( tflg == PLUSTAMP )
		fmt = "%4d.%02d.%02d+%02d:%02d:%02d" ;

	sprintf ( buf , fmt ,

				tp->tm_year + 1900 , tp->tm_mon + 1 , tp->tm_mday ,
				tp->tm_hour , tp->tm_min , tp->tm_sec				) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void timechop (tloc, yearp, monp, dayp, hourp, minp, secp)
time_t tloc ; int * yearp, * monp, * dayp, * hourp, * minp, * secp ;
{
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	*dayp  = tp->tm_mday ;
	*monp  = tp->tm_mon + 1 ;
	*yearp = tp->tm_year + 1900 ;

	*hourp = tp->tm_hour ;
	*minp  = tp->tm_min ;
	*secp  = tp->tm_sec ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	SECONDS		* 1L
# define	MINUTES		* 60L
# define	HOURS		* 3600L
# define	DAYS		* 86400L
# define	MONTHS		* 2592000L
# define	YEARS		* 31536000L

long maketime (year, mon, day, hour, min, sec, adj)
int year, mon, day, hour, min, sec, adj ;
{

	time_t tloc = 0x00 ;

	if (adj) {
# ifdef TZADJ
		time (&tloc) ;
		tloc = localtime (&tloc) -> tm_tzadj ;
# endif /* TZADJ */
	}

	tloc += (year>1970?year-1970:year-70) YEARS ;
	tloc += (mon-1)  MONTHS ;
	tloc += (day-1)  DAYS ;
	tloc +=  hour    HOURS ;
	tloc +=  min     MINUTES ;
	tloc +=  sec     SECONDS ;

	return tloc ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long long diftod (tvp1, tvp2) struct timeval * tvp1, * tvp2 ; {
	struct timeval tv3 ;

	tv3.tv_sec = tvp2->tv_sec - tvp1->tv_sec ;
	tv3.tv_usec = tvp2->tv_usec - tvp1->tv_usec ;
	if (tv3.tv_usec < 0) {
		--tv3.tv_sec ;
		tv3.tv_usec += 1000000 ;
	}
	return (long long) ( ( 1000000 * tv3.tv_sec ) + tv3.tv_usec ) ;
}

char * fmtus (t) long long t ; {
	long long u, s, m, h ;
	static char b [64] ;

	u = t % 1000000 ;
	s = t / 1000000 ;
	m = s / 60 ;
	h = m / 60 ;
	sprintf (b, "%02lld:%02lld:%02lld:%06lld", h, m, s, u) ;
	return b ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

#ifdef TSTDTP
#include <time.h>
#include <stdio.h>
#include <string.h>
struct tm * dtparse (char *) ;
int main (argc, argv) int argc ; char * * argv ; {
	if (--argc)
		while (*++argv) {
			printf ( "%15s = ", *argv ) ;
			printf ( "%s", asctime ( dtparse ( *argv ) ) ) ;
		}
	return 0 ;
}
#endif

/*
 *	parse date+time a la `touch(1)' ... [[[CC]YY]MMDD]hhmm[.ss]
 */

struct tm * dtparse (s, flags) char * s ; int flags ; {
	static struct tm tmbuf ;
	char * tp ;
	int year=10000, mon=999, day=999, hour=-1, min=-1, sec=-1 ;

	if ( s == NULL )
		return (struct tm *) NULL ;

	if ( ( tp = strchr (s, '.') ) != NULL ) {
		sscanf (tp+1, "%02d", &sec) ;
		*tp = '\0' ;
		if ( sec < 0 || sec > 59 )
			sec = 0 ;
	}

	switch ( strlen (s) ) {
		case  4 :									/*			hhmm	*/
			sscanf (s, "%02d%02d",
				&hour, &min) ;
		break ;
		case  8 :									/*		MMDDhhmm	*/
			sscanf (s, "%02d%02d%02d%02d",
				&mon, &day, &hour, &min) ;
		break ;
		case 10 :									/*	  YYMMDDhhmm	*/
			sscanf (s, "%02d%02d%02d%02d%02d",
				&year, &mon, &day, &hour, &min) ;
		break ;
		case 12 :									/*	CCYYMMDDhhmm	*/
			sscanf (s, "%04d%02d%02d%02d%02d",
				&year, &mon, &day, &hour, &min) ;
		break ;
		default :
			return (struct tm *) NULL ;
		break ;
	}

	if ( min < 0 || min > 59 )
		min = 0 ;

	if ( hour < 0 || hour > 23 )
		hour = 0 ;

	if ( day == 999 ) {
		if ( flags & DTP_MARK ) {
			day = -1 ;
		} else {
			day = 1 ;
		}
	} else {
		if ( day < 1 || day > 31 ) {
			day = 1 ;
		}
	}

	if ( mon == 999 ) {
		if ( flags & DTP_MARK ) {
			mon = -1 ;
		} else {
			mon = 1 ;
		}
	} else {
		if ( mon < 1 || mon > 12 ) {
			mon = 1 ;
		}
	}

	if ( year == 10000 ) {
		if ( flags & DTP_MARK ) {
			year = -1 ;
		} else {
			year = 1970 ;
		}
	} else {
		if ( year < 70 )
			if ( year >= 0 )
				if ( year < 38 )
					year += 2000 ;
				else
					year = 1970 ;
			else
				year = 1970 ;
		else
			if ( year < 100 )
				year += 1900 ;
			else
				if ( year < 1970 || year > 2037 )
					year = 1970 ;
	}

	tmbuf.tm_year = year == -1 ? year : year - 1900 ;
	tmbuf.tm_mon  = mon  == -1 ? mon  : mon - 1 ;
	tmbuf.tm_mday = day ;
	tmbuf.tm_hour = hour ;
	tmbuf.tm_min  = min ;
	tmbuf.tm_sec  = sec ;

	return &tmbuf ;
}

/*
 *	        1234.56 = Sun Jan  1 12:34:56 1970
 *	    11121234.56 = Sun Nov 12 12:34:56 1970
 *	  0011121234.56 = Sun Nov 12 12:34:56 2000
 *	  1011121234.56 = Sun Nov 12 12:34:56 2010
 *	  2011121234.56 = Sun Nov 12 12:34:56 2020
 *	  3011121234.56 = Sun Nov 12 12:34:56 2030
 *	  4011121234.56 = Sun Nov 12 12:34:56 1970
 *	  5011121234.56 = Sun Nov 12 12:34:56 1970
 *	  6011121234.56 = Sun Nov 12 12:34:56 1970
 *	  7011121234.56 = Sun Nov 12 12:34:56 1970
 *	  8011121234.56 = Sun Nov 12 12:34:56 1980
 *	  9011121234.56 = Sun Nov 12 12:34:56 1990
 *	196911121234.56 = Sun Nov 12 12:34:56 1970
 *	199911121234.56 = Sun Nov 12 12:34:56 1999
 *	201011121234.56 = Sun Nov 12 12:34:56 2010
 *	203711121234.56 = Sun Nov 12 12:34:56 2037
 *	203811121234.56 = Sun Nov 12 12:34:56 1970
 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
