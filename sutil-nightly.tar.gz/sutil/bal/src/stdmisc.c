
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdmisc.c					 miscellany stuff	|
 *		\ \/ /		|	(c) 1995-2010			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

/* # include	"configure.h" */

# ifdef AIX71
#include <sys/types.h>
typedef uint_t          rid_t;          /* role ID */
# endif /* AIX71 */

# ifdef LABIX

# define	USE_MATH
# define	USE_STDIO
# define	USE_CTYPE
# define	USE_UNISTD
# define	USE_SYSTYPES

# define	USE_STDTYP
# define	USE_STDASC
# define	USE_STDSTR
# define	USE_STDDIR
# define	USE_STDMISC
# define	USE_STDTIME
# define	USE_STDSTAT
# define	USE_STDLOGIC

# include	"abc.h"

# else /* PLAIN */

# include  "abc.h"

# include  <math.h>
# include  <time.h>
# include  <errno.h>
# include  <stdio.h>
# include  <ctype.h>
# include  <stdlib.h>
# include  <string.h>
# include  <unistd.h>

# include  <sys/types.h>
# include  <sys/utsname.h>
# include  <sys/stat.h>

# include  "bud.h"
# include  "stdasc.h"
# include  "stdtyp.h"
# include  "stdlogic.h"
# include  "stdmisc.h"

# endif /* LABIX */
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
# define	SETKMG(X)	kmg[3] = X ; kmg[4] = '\0' ;

char * ltokmg (x) long x ; {

	static char kmg [64] ;
	static char kc = 'K' , mc = 'M' , gc = 'G' , sc = ' ' ;
	double bval, kval, mval, gval ;

	bval = x ;

	if (bval < 1000) {
		sprintf (kmg, "%3d", (int) bval) ; SETKMG(sc) ;
		return kmg ;
	}

	kval = bval / 1024.0 ;

# ifdef DEBUG
	printf ("--> b %.9f k %.9f \n", bval, kval) ;
# endif

	if ( kval < 10.0 ) {
		sprintf (kmg, "%11.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	if ( kval < 1000.0 ) {
		sprintf (kmg, "%13.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	mval = bval / 1048576.0 ;

# ifdef DEBUG
	printf ("--> b %.9f m %.9f \n", bval, mval) ;
# endif

	if ( mval < 10.0 ) {
		sprintf (kmg, "%11.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	if ( mval < 1000.0 ) {
		sprintf (kmg, "%13.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	gval = bval / 1073741824.0 ;

# ifdef DEBUG
	printf ("--> b %.9f g %.9f \n", bval, gval) ;
# endif

	if ( gval < 10.0 ) {
		sprintf (kmg, "%11.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	if ( gval < 1000.0 ) {
		sprintf (kmg, "%13.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	return "????" ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
char * lltokmgtpe (x) sbit64 x ; {

	static char kmg [64] ;
	static char kc = 'K' , mc = 'M' , gc = 'G' , sc = ' ' ;
	static char tc = 'T' , pc = 'P' , ec = 'E' ;
	double bval, kval, mval, gval ;
	double       tval, pval, eval ;

	bval = x ;

	if (bval < 1000) {
		sprintf (kmg, "%3d", (int) bval) ; SETKMG(sc) ;
		return kmg ;
	}

	kval = bval / 1024.0 ;

# ifdef DEBUG
	printf ("--> b %.9f k %.9f \n", bval, kval) ;
# endif

	if ( kval < 10.0 ) {
		sprintf (kmg, "%11.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	if ( kval < 1000.0 ) {
		sprintf (kmg, "%13.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	mval = bval / 1048576.0 ;

# ifdef DEBUG
	printf ("--> b %.9f m %.9f \n", bval, mval) ;
# endif

	if ( mval < 10.0 ) {
		sprintf (kmg, "%11.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	if ( mval < 1000.0 ) {
		sprintf (kmg, "%13.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	gval = bval / 1073741824.0 ;

# ifdef DEBUG
	printf ("--> b %.9f g %.9f \n", bval, gval) ;
# endif

	if ( gval < 10.0 ) {
		sprintf (kmg, "%11.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	if ( gval < 1000.0 ) {
		sprintf (kmg, "%13.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	tval = bval / 1099511627776.0 ;

# ifdef DEBUG
	printf ("--> b %.9f t %.9f \n", bval, tval) ;
# endif

	if ( tval < 10.0 ) {
		sprintf (kmg, "%11.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	if ( tval < 1000.0 ) {
		sprintf (kmg, "%13.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	pval = bval / 1125899906842624.0 ;

# ifdef DEBUG
	printf ("--> b %.9f p %.9f \n", bval, pval) ;
# endif

	if ( pval < 10.0 ) {
		sprintf (kmg, "%11.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	if ( pval < 1000.0 ) {
		sprintf (kmg, "%13.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	eval = bval / 1152921504606846976.0 ;

# ifdef DEBUG
	printf ("--> b %.9f e %.9f \n", bval, eval) ;
# endif

	if ( eval < 10.0 ) {
		sprintf (kmg, "%11.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	if ( eval < 1000.0 ) {
		sprintf (kmg, "%13.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	return "????" ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
char * lltosikmgtpe (x) sbit64 x ; {

	static char kmg [64] ;
	static char kc = 'k' , mc = 'm' , gc = 'g' , sc = ' ' ;
	static char tc = 't' , pc = 'p' , ec = 'e' ;
	double bval, kval, mval, gval ;
	double       tval, pval, eval ;

	bval = x ;

	if (bval < 1000) {
		sprintf (kmg, "%3d", (int) bval) ; SETKMG(sc) ;
		return kmg ;
	}

	kval = bval / 1000.0 /* 1024.0 */ ;

# ifdef DEBUG
	printf ("--> b %.9f k %.9f \n", bval, kval) ;
# endif

	if ( kval < 10.0 ) {
		sprintf (kmg, "%11.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	if ( kval < 1000.0 ) {
		sprintf (kmg, "%13.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	mval = bval / 1000000.0 /* 1048576.0 */ ;

# ifdef DEBUG
	printf ("--> b %.9f m %.9f \n", bval, mval) ;
# endif

	if ( mval < 10.0 ) {
		sprintf (kmg, "%11.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	if ( mval < 1000.0 ) {
		sprintf (kmg, "%13.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	gval = bval / 1000000000.0 /* 1073741824.0 */ ;

# ifdef DEBUG
	printf ("--> b %.9f g %.9f \n", bval, gval) ;
# endif

	if ( gval < 10.0 ) {
		sprintf (kmg, "%11.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	if ( gval < 1000.0 ) {
		sprintf (kmg, "%13.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	tval = bval / 1000000000000.0 /* 1099511627776.0 */ ;

# ifdef DEBUG
	printf ("--> b %.9f t %.9f \n", bval, tval) ;
# endif

	if ( tval < 10.0 ) {
		sprintf (kmg, "%11.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	if ( tval < 1000.0 ) {
		sprintf (kmg, "%13.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	pval = bval / 1000000000000000.0 /* 1125899906842624.0 */ ;

# ifdef DEBUG
	printf ("--> b %.9f p %.9f \n", bval, pval) ;
# endif

	if ( pval < 10.0 ) {
		sprintf (kmg, "%11.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	if ( pval < 1000.0 ) {
		sprintf (kmg, "%13.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	eval = bval / 1000000000000000000.0 /* 1152921504606846976.0 */ ;

# ifdef DEBUG
	printf ("--> b %.9f e %.9f \n", bval, eval) ;
# endif

	if ( eval < 10.0 ) {
		sprintf (kmg, "%11.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	if ( eval < 1000.0 ) {
		sprintf (kmg, "%13.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	return "????" ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
char * strhms (secs) ULONG secs ; {

	static char hms [32] ;
	ULONG n = secs ;
	int h, m, s ;

	if ( n == 0 )
		return "00:00:00" ;

	if ( ( h = n / 3600 ) > 0 )
		n -= h * 3600 ;

	if ( ( m = n / 60 ) > 0 )
		n -= m * 60 ;

	s = n ;

	sprintf (hms, "%02d:%02d:%02d", h, m, s) ;

	return hms ;
}

/*----------------------------------------------------------------------*/
/*	ptrel : percent, time, rate & estimated left (u = [BKMG])			*/
/*	NNNu (PPP%) of TTTu in HH:MM:SS @ YYYu/s (HH:MM:SS left)			*/
/*	NNNu (PPP%) of TTTu in HH:MM:SS @ YYYu/s >>>>|||||| (HH:MM:SS left)	*/
/*----------------------------------------------------------------------*/

# define	BARYET		'|'
# define	BARPOK		'>'

int ptrel (sof, tot, flg) ULONG sof, tot, flg ; {

			ULONG	etl ;					/*	estimated time left		*/
			ULONG	dt, rt ;
	static	char	barbuf [16] ;
	static	time_t	t0 , tl ;
			time_t	tx ;
			int		pok , barlen = 10 , barpok , /* i, */ mtbs ;

	if ( sof == 0 ) {
		time (&t0) ;
		tl = t0 ;
		memset (barbuf, (int) BARYET, barlen) ;
		barbuf[barlen] = '\0' ;
# ifdef DEBUG
		printf (" 000  (  0%%) of %s in 00:00:00 @ ??? /s |||||||||| (??:??:?? left)\n",
				ltokmg (tot)) ;
# endif /* DEBUG */
		return 0 ;
	}

	time (&tx) ;

	mtbs = flg & 0x007f ;

	if ( mtbs <= 0 )
		mtbs = 1 ;

	if ( tx - tl < mtbs )
		return 0 ;

	dt = tx - t0 ;
	pok = ((double) sof * 100) / (double) tot ;
	barpok = ( barlen * pok ) / 100 ;
	memset (barbuf, (int) BARPOK, barpok) ;
	rt = sof / dt ;
	etl = (tot - sof) / rt ;
	tl = tx ;

	printf (" %s (%3d%%) of", ltokmg (sof), pok) ;
	printf (" %s in %s @", ltokmg (tot), strhms (dt)) ;
	printf (" %s/s %s (%s left) \r", ltokmg (rt), barbuf, strhms (etl)) ;
	fflush (stdout) ;

	if ( flg & PTE_NEWL )
		printf ("\n") ;

	return 0 ;
}

int ptrel64 (sof, tot, flg) sbit64 sof, tot ; ULONG flg ; {

			ULONG	etl ;					/*	estimated time left		*/
			ULONG	dt ;
			sbit64	rt ;
	static	char	barbuf [16] ;
	static	time_t	t0 , tl ;
			time_t	tx ;
			int		pok , barlen = 10 , barpok , /* i, */ mtbs ;

	if ( sof == 0 ) {
		time (&t0) ;
		tl = t0 ;
		memset (barbuf, (int) BARYET, barlen) ;
		barbuf[barlen] = '\0' ;
# ifdef DEBUG
		printf (" 000  (  0%%) of %s in 00:00:00 @ ??? /s |||||||||| (??:??:?? left)\n",
				lltokmgtpe (tot)) ;
# endif /* DEBUG */
		return 0 ;
	}

	time (&tx) ;

	mtbs = flg & 0x007f ;

	if ( mtbs <= 0 )
		mtbs = 2 ;

	if ( tx - tl < mtbs ) /* min secs between samples */
		return 0 ;

	dt = tx - t0 ;
	pok = (sof * 100) / tot ;
	barpok = ( barlen * pok ) / 100 ;
	memset (barbuf, (int) BARPOK, barpok) ;
	rt = sof / dt ;
	etl = (tot - sof) / rt ;
	tl = tx ;

	printf (" %s (%3d%%) of", lltokmgtpe (sof), pok) ;
	printf (" %s in %s @", lltokmgtpe (tot), strhms (dt)) ;
	printf (" %s/s %s (%s left) \r", lltokmgtpe (rt), barbuf, strhms (etl)) ;
	fflush (stdout) ;

	if ( flg & PTE_NEWL )
		printf ("\n") ;

	return 0 ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
int strcount (s, c) char * s ; int c ; {

	int k ;
	char * p ;

	for ( k = 0 , p = s ; *p ; ++p ) {
		if ( *p == c )
			++k ;
	}

	return k ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
void trimeol (s, l) char * s ; int l ; {

	int n ;

	for ( n = l ; n >= l - 2 ; --n )
		if ( s[n] == '\n' || s[n] == '\r' )
			s[n] = '\0' ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

/* index of the last occurrance of a char w/in a str */

int lastoc (s, c) char * s ; int c ; {

	register char * p = s ;
	register int i = -1 ;

	while (*p) {
		if (*p == c)
			i = (int) (p - s) ;		/* i = p - s ; */
		++p ;
	}

	return i ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
char * lastname (name) char * name ; {

	register char * tp ;

	tp = strrchr (name, DIRSEP) ;

	if (tp == NULL)
		return name ;

	if (*(tp+1) == NUL)
		return name ;
	else
		return tp + 1 ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
STR bintos (buf) STR buf ; {

	FIX char war [512] ;
	REG STR bp = buf ;
	REG STR wp = war ;

	for ( ; *bp ; ++bp )
		if (*bp > ' ' && *bp <= '~')
			*wp++ = *bp ;
		else {
			switch (*bp) {
				case BS  : sprintf (wp, "\\b") ; wp += 2 ; break ;
				case FF  : sprintf (wp, "\\f") ; wp += 2 ; break ;
				case NL  : sprintf (wp, "\\n") ; wp += 2 ; break ;
				case CR  : sprintf (wp, "\\r") ; wp += 2 ; break ;
				case TAB : sprintf (wp, "\\t") ; wp += 2 ; break ;
				default  : sprintf (wp, "\\%03o", *bp) ; wp += 4 ; break ;
			}
		}
	*wp = NUL ;
	return (war) ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
STR stobin (buf) STR buf ; {

	REG STR  mp = buf ;
	REG STR  rp = mp ;
	REG char od ;
	REG char nd ;

	while (*mp) {
		if (*mp == BACKSLASH)
			switch (*++mp) {
				case 'a' : *rp = BEL  ; break ;
				case 'b' : *rp = BS   ; break ;
				case 'e' : *rp = ESC  ; break ;
				case 'f' : *rp = FF   ; break ;
				case 'n' : *rp = NL   ; break ;
				case 'r' : *rp = CR   ; break ;
				case 's' : *rp = SPC  ; break ;
				case 't' : *rp = TAB  ; break ;
				case 'v' : *rp = VT   ; break ;
				case '"' : *rp = VANE ; break ;
				default :
					if (isupper ((int) *mp)) {
						*rp = *mp - AT ;
					} else if (isdigit ((int) *mp)) {
						for ( od = 0 , nd = 1 ; isdigit ((int) *mp) && nd <= 3 ;
						      ++mp , ++nd )
							od = (od << 3) + (*mp - '0') ;
						*rp = od ;
						--mp ;
					} else
						*rp = *mp ;
				break ;
			}
		else
			*rp = *mp ;
		++mp ; ++rp ;
	}
	*rp = NUL ;
	return (buf) ;
}

/*				 _______________________________________________________
 *				|														|
 *				|	xlltoa + long long to ascii conversion ...			|
 *				|_______________________________________________________|
 */

# define	MAXWID		128

char * xlltoa (val, wid, flg) sbit64 val ; int wid, flg ; {

	static char buf [MAXWID] = { '+' } ;
	register char * bp = buf + ( MAXWID - 1 ) ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}

/*	memset ( buf , NUL , MAXWID ) ; */

	do {
		if (flg & 0x08) {
			if ( (tk % 4) == 0 ) {
				*--bp = DOT ;
				++tk ;
			}
		}
		*--bp = '0' + (char) (val % 10) ;
		++tk ;
		if (tk >= wid)
			break ;
	} while ((val /= 10) > 0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}

	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

/*				 _______________________________________________________
 *				|														|
 *				|	xltoa + extra-fancy long to ascii conversion ...	|
 *				|_______________________________________________________|
 */

char * xltoa (val, wid, flg) long val ; int wid, flg ; {

	static char buf [MAXWID] = { '+' } ;
	register char * bp = buf + ( MAXWID - 1 ) ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}

/*	memset ( buf , NUL , MAXWID ) ; */

	do {
		if (flg & 0x08) {
			if ( (tk % 4) == 0 ) {
				*--bp = DOT ;
				++tk ;
			}
		}
		*--bp = '0' + (char) (val % 10) ;
		++tk ;
		if (tk >= wid)
			break ;
	} while ((val /= 10) > 0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}

	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

# ifdef XLDTOA

# include <stdio.h>
# include <stdlib.h>

char * xltoa (long, int, int) ;

int main (argc, argv) int argc ; char * * argv ; {
	long x ;

	if (argc == 1) {
		printf ("use: xltoa long ...\n") ;
		return ;
	}

	printf (" 123456789000...   111.222.333.444  ") ;
	printf (" 123456789000...   111.222.333.444\n") ;

	while (*++argv) {
		x = atol (*argv) ;
		printf ( "|%15.15s| ", xltoa (x, 15, 0x00) ) ;
		printf ( "|%15.15s| |%15ld| (%s) \n",
				xltoa (x, 15, 0x08) , x , xltoa (x, 15, 0x08) ) ;
	}
}

# endif /* XLDTOA */

/*______________________________________________________________________
 |																		|
 |	xdtoa + extra-fancy double to ascii conversion ...					|
 |______________________________________________________________________|
 */

# ifdef XLDTOA

char * xdtoa (val, wid, flg) double val ; int wid, flg ; {
	static char buf [24] = { '+' } ;
	register char * bp = buf + 20 ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/
	double dblten = (double) 10 ;

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}

	do {
		if (flg & 0x08) {
			if ( (tk % 4) == 0 ) {
				*--bp = DOT ;
				++tk ;
			}
		}
		*--bp = '0' + (int) fmod (val, dblten) ;
		++tk ;
		if ((tk-1) >= wid)
			break ;
		val /= dblten ;
		if (val < 1000000000.0) {
			if ((long) val <= 0)
				break ;
		}
	} while (val > (double)0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}

	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

# endif /* XLDTOA */

# ifdef XLDTOA

# include <stdio.h>
# include <stdlib.h>

char * xdtoa (double, int, int) ;

int main (argc, argv) int argc ; char * * argv ; {
	double x ;

	if (argc == 1) {
		printf ("use: xdtoa double ...\n") ;
		return ;
	}

	printf (" 111222333444555   111.222.333.444\n") ;

	while (*++argv) {
		x = atof (*argv) ;
		printf ( "|%15.15s| ", xdtoa (x, 15, 0x00) ) ;
		printf ( "|%15.15s| %15.0lf\n", xdtoa (x, 15, 0x08) , x) ;
	}
}

# endif /* XLDTOA */
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

/*
 *		check if name is "." or ".."
 */

int dotdir (name) char * name ; {

	register int tj ;
	register char * tp = name ;

	tj = lastoc (name, DIRSEP) ;

	if (tj >= 0)
		tp += (tj+1) ;

	if ( *tp == DOT )
		if ( *(tp+1) == NUL )
			return TRUE ;
		else
			if ( *(tp+1) == DOT )
				if ( *(tp+2) == NUL )
					return TRUE ;
				else
					return FALSE ;
			else
				return FALSE ;
	else
		return FALSE ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
int makedir (name) char * name ; {

# ifdef POSIX_MKDIR
	return mkdir (name, 0777) ;
# endif /* POSIX_MKDIR */

# ifdef SH_MKDIR
	char tb [512] ;

	sprintf (tb, "mkdir %s", name) ;
	return system (tb) ;
# endif /* SH_MKDIR */

# ifdef C_MKDIR
	return mkdir (name) ;
# endif /* C_MKDIR */

}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
# ifdef DOS
# include	<io.h>
# endif

char makpthdirnam [1024] ;

int makepath (nam) char * nam ; {

	register char * np ;
	register char * dp ;
	register char * ep ;

	if ( (ep = strrchr (nam, DIRSEP)) == NULL )
		return 0 ;

	if ( strcmp (nam, "/") == 0 )
		return 0 ;

	np = nam ;
	dp = makpthdirnam ;

	if ( *np == DIRSEP )
		*dp++ = *np++ ;

	for ( ; ; ) {

		while (np != ep && *np != DIRSEP)
			*dp++ = *np++ ;

		*dp = '\0' ;

		if ( access (makpthdirnam, 0) == -1 ) {
			if ( makedir (makpthdirnam) < 0 ) {
				return -1 /* xalert(...) */ ;
			}
		}

		if (np == ep)
			return 0 ;
		else
			*dp++ = *np++ ;
	}
}

/************************************************************************
*	expand tabs 2 spaces (to, from, siz) ...							*
************************************************************************/

char * tabexp (expbuf, tabuf, tabsiz) char * expbuf , * tabuf ; int tabsiz ; {
	register char * tp = tabuf ;
	register int ts = tabsiz ;
	register char * ep = expbuf ;

	do {
		if (*tp != '\t') {
			*ep++ = *tp ;
			if (--ts == 0)
				ts = tabsiz ;
		} else {
			while (ts--)
				*ep++ = ' ' ;
			ts = tabsiz ;
		}
	} while (*tp++) ;

	return expbuf ;
}

/************************************************************************
*	tab expansion in static buffer ...									*
************************************************************************/

char * exptab (tabuf, tabsiz) char * tabuf ; int tabsiz ; {

	static char expbuf [512] ;
	register char * tp = tabuf ;
	register int ts = tabsiz ;
	register char * ep = expbuf ;

	do {
# ifdef NOTSURE
		if (((ep+ts) - expbuf) > 512) {
			*ep = NUL ;
			break ;
		}
# endif
		if (*tp != '\t') {
			*ep++ = *tp ;
			if (--ts == 0)
				ts = tabsiz ;
		} else {
			while (ts--)
				*ep++ = ' ' ;
			ts = tabsiz ;
		}
	} while (*tp++) ;

	return expbuf ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
ULONG blkstokb (blks, bsiz) ULONG blks , bsiz ; {

	ULONG kbs ;

	if ( bsiz > 1024 ) {
		kbs = blks * ( bsiz / 1024 ) ;
	} else if ( bsiz == 1024 ) {
		kbs = blks ;
	} else if ( bsiz == 512 ) {
		kbs = blks >> 1 ;
	} else {
		kbs = ( blks * bsiz ) >> 10 ;
	}

	return kbs ;
}
/*\___________________________________________________________________________
\*/
static long long atolli (s) char * s ; {
	long long	tll = 0 ;
#	ifdef RAWATOLL
	int neg = 0 ;
	while (*s) {
		if ( *s == '-' )
			++neg ;
		if ( *s >= '0' && *s <= '9' )
			tll = ( tll * 10 ) + ( *s - '0' ) ;
		++s ;
	}
	if ( neg )
		tll = -tll ;
#	else
	sscanf ( s , "%lld" , &tll ) ;
#	endif
	return tll ;
}
/*\___________________________________________________________________________
\*/
long long bunitz (s) char * s ; {

# define	MAXNUM		100
# define	MAXLET		8

	register	char *		p ;
	register	int			nk , ak ;
				long long	m = 1LL ;
	static		char		n [128] ;
	static		char		a [16] ;

	if ( *s == '-' ) {
		m = -1LL ;
		++s ;
	}
	for ( nk = ak = 0 , p = s ; *p ; ++p )
		if ( *p >= '0' && *p <= '9' )
			if ( nk < MAXNUM )
				n[nk++] = *p ;
			else
				return 0LL ;
		else
			if ( ak < MAXLET )
				a[ak++] = *p ;
			else
				return 0LL ;

	n[nk] = '\0' ;
	a[ak] = '\0' ;

	switch ( a[0] ) {
		case 's'  : m *= 500LL ;			break ;
		case 'S'  : m *= 512LL ;			break ;
		case 'k'  : m *= 1000LL ;			break ;
		case 'K'  : m *= 1024LL ;			break ;
		case 'm'  : m *= 1000000LL ;		break ;
		case 'M'  : m *= 1048576LL ;		break ;
		case 'g'  : m *= 1000000000LL ;		break ;
		case 'G'  : m *= 1073741824LL ;		break ;
		case 't'  : m *= 1000000000000LL ;	break ;
		case 'T'  : m *= 1099511627776LL ;	break ;
		case '\0' :
		default   : m *= 1LL ;				break ;
	}

	return m * atolli (n) ;
}
/*\___________________________________________________________________________
\*/
char * getverno (buf) char * buf ; {
	static		char vbuf [64] ;
	register	char * bp ;
	register	char * vp ;

	for ( bp = buf , vp = vbuf ; *bp && ( isdigit ((int)(*bp)) || *bp == '.' ) ; ++bp , ++vp )
		*vp = *bp ;
	*vp = '\0' ;
	return vbuf ;
}

char * cpufam = "weird" ;

char * getosver (unp) struct utsname * unp ; {
	static		char tbuf [256] ;
#ifdef HPUX
				long cpuver ;
#endif

	if ( 0 == strcmp ( unp->sysname , "AIX" ) ) {
#ifdef AIX
		if ( _system_configuration.architecture == POWER_RS ) {
			cpufam = strdup ("rspower");
		} else if ( _system_configuration.architecture == IA64 ) {
			cpufam = strdup ("ia64");
		} else if ( _system_configuration.architecture == POWER_PC ) {
			if ( _system_configuration.implementation == POWER_4 ) {
				cpufam = strdup ("power4");
			} else if ( _system_configuration.implementation == POWER_5 ) {
				cpufam = strdup ("power5");
			} else if ( _system_configuration.implementation == POWER_6 ) {
				cpufam = strdup ("power6");
			} else if ( _system_configuration.implementation == POWER_7 ) {
				cpufam = strdup ("power7");
			} else {
				cpufam = strdup ("powerpc");
			}
		} else {
			cpufam = strdup ("ibmaixcpu") ;
		}
# ifdef CF_CPU_FAM
		cpufam = strdup (CF_CPU_FAM) ;
# endif
#endif
		sprintf (tbuf, "%s.%s", unp->version, unp->release) ;
		return tbuf ;
	}

	if ( 0 == strcmp ( unp->sysname , "SunOS" ) ) {
#ifdef SUNX
		if ( sysinfo ( SI_ARCHITECTURE , tbuf , 64 ) < 0 )
			cpufam = "sunoscpu" ;
		else
			cpufam = strdup ( tbuf ) ;
#endif
		return unp->release ;
	}

	if ( 0 == strcmp ( unp->sysname , "HP-UX" ) ) {
		if ( 0 == strcmp ( unp->machine , "ia64" ) )
			{
				cpufam = strdup ( unp->machine ) ;
			}
#ifdef HPUX
#ifndef CPU_IA64_ARCHREV_0
/* HP-UX 11.11 doesn't define this, so take it from 11.31's <sys/unistd.h> */
#define CPU_IA64_ARCHREV_0       0x300 /* IA-64 archrev 0 */
#endif
		else {
			cpuver = sysconf (_SC_CPU_VERSION);
			if (cpuver == CPU_IA64_ARCHREV_0) {
				cpufam = strdup ("ia64");
			} else if (CPU_IS_HP_MC68K(cpuver)) {
				cpufam = strdup ("mc68k");
			} else if (CPU_IS_PA_RISC(cpuver)) {
				cpufam = strdup ("parisc");
			} else {
				cpufam = "hpuxcpu" ;
			}
		}
#endif
		return unp->release ;
	}

	if ( 0 == strcmp ( unp->sysname , "OpenBSD" ) ) {
		cpufam = strdup ( unp->machine ) ;
		return unp->release ;
	}

	if ( 0 == strcmp ( unp->sysname , "NetBSD" ) ) {
		cpufam = strdup ( unp->machine ) ;
		return unp->release ;
	}

	if ( 0 == strcmp ( unp->sysname , "FreeBSD" ) ) {
		cpufam = strdup ( unp->machine ) ;
		return getverno ( unp->release ) ;
	}

	if ( 0 == strncmp ( unp->sysname, "CYGWIN" , 6 ) ) {
		cpufam = strdup ( unp->machine ) ;
		osname = unp->sysname ;
		*(osname+6) = '\0' ;
		return getverno ( unp->release ) ;
	}

	if ( 0 == strcmp ( unp->sysname , "Linux" ) ) {
		cpufam = strdup ( unp->machine ) ;
		return getverno ( unp->release ) ;
	}

	cpufam = "gencpu" ;
	return "?.?" ;
}
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
#ifdef LINUX

DISTROINF distrotab [ ] = {
	{ "SuSE",		"suse",			"/etc/SuSE-release"				} ,
	{ "SuSE",		"suse",			"/etc/SUSE-release"				} ,
	{ "Fedora",		"fedora",		"/etc/fedora-release"			} ,
	{ "RedHat",		"red hat",		"/etc/redhat-release"			} ,
	{ "CentOS",		"centos",		"/etc/redhat-release"			} ,
	{ "RedHat",		"red hat",		"/etc/redhat_version"			} ,
	{ "Slackware",	"slackware",	"/etc/slackware-release"		} ,
	{ "Slackware",	"slackware",	"/etc/slackware-version"		} ,
	{ "Ubuntu",		"ubuntu",		"/etc/lsb-release"				} ,
	{ "Debian",		"debian",		"/etc/debian_release"			} ,
	{ "Debian",		"debian",		"/etc/debian_version"			} ,
	{ "Mandriva",	"mandriva",		"/etc/mandriva-release"			} ,
	{ "Mandrake",	"mandrake",		"/etc/mandrake-release"			} ,
	{ "Mandrake",	"mandrake",		"/etc/mandrakelinux-release"	} ,
	{ "YellowDog",	"yellow dog",	"/etc/yellowdog-release"		} ,
	{ "YellowDog",	"yellowdog",	"/etc/yellowdog-release"		} ,
	{ "SunJDS",		"sunjds",		"/etc/sun-release"				} ,
	{ "Solaris",	"solaris",		"/etc/release"					} ,
	{ "Gentoo",		"gentoo",		"/etc/gentoo-release"			} ,
	{ "United",		"united",		"/etc/UnitedLinux-release"		} ,
	{ "RSA",		"RSA",			"/etc/distro-release"			} ,
	{ NULL,			NULL,			NULL							} 
} ;

char * getdistro () {
			int i ;
			DISTROINF * dip ;
			char * np = NULL ;
			char tmplinbuf [256] ;
			char provernam [32] ;
			char etcrelnam [32] ;
	static	char distronam [32] ;
			FILE * fp = fopen ("/proc/version", "r") ;
	tmplinbuf [0] = provernam [0] = etcrelnam [0] = distronam [0] = '\0' ;
	if ( fp != NULL ) {
		if ( fgets ( tmplinbuf, 256, fp ) != NULL ) {
			fclose (fp) ;
			for ( i = 0 ; i < 256 && tmplinbuf[i] != '\0' ; ++i ) {
				tmplinbuf[i] = tolower ( (int)tmplinbuf[i] ) ;
			}
			for ( dip = distrotab ; dip->di_sys != NULL ; ++dip ) {
				if ( NULL != strstr ( tmplinbuf , dip->di_nam ) ) {
					strcpy ( provernam , dip->di_sys ) ;
					break ;
				}
			}
		}
	}
	for ( dip = distrotab , tmplinbuf[0] = '\0' ; dip->di_sys != NULL ; ++dip ) {
		if ( access ( dip->di_rel , F_OK ) == 0 ) {
			strcpy ( etcrelnam , dip->di_sys ) ;
			if ( NULL != ( fp = fopen ( dip->di_rel, "r" ) ) ) {
				while ( fgets ( tmplinbuf, 256, fp ) != NULL ) {
					for ( i = 0 ; i < 256 && tmplinbuf[i] != '\0' ; ++i ) {
						if ( isdigit ( (int)tmplinbuf[i] ) ) {
							np = &tmplinbuf[i] ;
							break ;
						}
					}
					if ( np != NULL ) {
						break ;
					}
				}
				fclose (fp) ;
			}
			break ;
		}
	}
	if ( provernam[0] == '\0' ) {
		if ( etcrelnam[0] == '\0' ) {
			return "gnu-2" ;
		} else {
			strcpy ( distronam , etcrelnam ) ;
		}
	} else {
		strcpy ( distronam , provernam ) ;
	}
	if ( etcrelnam[0] != '\0' && tmplinbuf[0] != '\0' ) {
		if ( NULL != strstr ( tmplinbuf , "Red Hat Enterprise Linux" ) ) {
			strcpy ( distronam , "RHEL" ) ;
			if ( NULL != strstr ( tmplinbuf , " AS " ) ) {
				strcat ( distronam , "-AS" ) ;
			} else if ( NULL != strstr ( tmplinbuf , " ES " ) ) {
				strcat ( distronam , "-ES" ) ;
			} else if ( NULL != strstr ( tmplinbuf , " WS " ) ) {
				strcat ( distronam , "-WS" ) ;
			}
		} else if ( NULL != strstr ( tmplinbuf , "CentOS" ) ) {
			strcpy ( distronam , "CentOS" ) ;
		} else if ( NULL != strstr ( tmplinbuf , "Fedora" ) ) {
			strcpy ( distronam , "Fedora" ) ;
		} else if ( NULL != strstr ( tmplinbuf , "SUSE Linux Enterprise Server" ) ) {
			strcpy ( distronam , "SLES" ) ;
		} else if ( NULL != strstr ( tmplinbuf , "Mandriva Linux Corporate Server" ) ) {
			strcpy ( distronam , "MLCS" ) ;
		}
	}
	if ( np != NULL ) {
		strcat ( distronam , "-" ) ;
		strcat ( distronam , getverno ( np ) ) ;
	}
	return distronam ;
}

#endif
/*\___________________________________________________________________________
\*/
long hms2sec (s) char * s ; {
	long nsec = 0 , tsec = 0 ;
	int ck = 0 ;
	register char * p = s ;
	if ( p == NULL )
		return -1L ;
	if ( ! ( *p >= '0' && *p <= '9' ) )
		return -2L ;
	while ( *p ) {
		if ( *p >= '0' && *p <= '9' ) {
			nsec = ( 10 * nsec ) + ( *p - '0' ) ;
		} else if ( *p == ':' ) {
			if ( ++ck > 2 ) {
				return -2L ;
			}
			tsec = ( 60 * tsec ) + ( 60 * nsec ) ; nsec = 0 ;
		} else {
			return -2L ;
		}
		++p ;
	}
	return tsec + nsec ;
}

#ifdef TSTHMS2SEC
main (argc, argv) char * * argv ; {

	while (*++argv)
		printf ("<%s>=%lds\n", *argv, hms2sec(*argv)) ;
}
#endif

/*__________________________________________________________________________
 *	binio : bit stringz...
 */

unsigned long long bits2ull (bsp) char * bsp ; {
	unsigned long long bit = 0ULL ;
	unsigned long long val = 0ULL ;
	register int bsl = 0 ;
	if ( bsp == NULL )
		return 0ULL ;
	bsl = strlen (bsp) ;
	if ( bsl > 64 )
		return 0ULL ;
	for ( --bsl , bit = 0x01ULL ; bsl >= 0 ; --bsl , bit <<= 1 )
		if ( *(bsp+bsl) == '1' )
			val |= bit ;
	return val ;
}

char * ull2bits (val) unsigned long long val ; {
	unsigned long long bit = 0ULL ;
	static char bitbuf [65] ;
	register int i = 0 ;
	bitbuf[64] = '\0' ;
	for ( i = 0 , bit = 0x8000000000000000ULL ; bit != 0x00 ; ++i , bit >>= 1 )
		bitbuf [i] = val & bit ? '1' : '0' ;
	return bitbuf ;
}

#ifdef TSTBINIO
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
long long llval ;
void usage () {
	printf ("use: binio [-?] [-d decval] [-b binval]\n") ;
	exit (1) ;
}
int main (argc, argv) int argc ; char * * argv ; {
	char * bsp = NULL ;
	while ( *++argv ) {
		if ( strcmp (*argv, "-?") == 0 ) {
			usage () ;
		} else if ( strcmp (*argv, "-b") == 0 ) {
			bsp = *++argv ;
			printf ( "%s=%lld\n" , bsp , bits2ull ( bsp ) ) ;
		} else if ( strcmp (*argv, "-d") == 0 ) {
			sscanf ( *++argv, "%lld", &llval ) ;
			printf ( "%lld=%s\n" , llval , ull2bits ( llval ) ) ;
		} else {
			usage () ;
		}
	}
	return 0 ;
}
#endif
/*____________________________________________________________________________
*/
char *signame(sig) int sig;
{
#ifdef NO_STRSIGNAL
   static char sigmess[BUFSIZ];
   (void)sprintf(sigmess,"SIG%d",sig);
   return(sigmess);
#else
   return strsignal (sig) ;
#endif
}
/*____________________________________________________________________________
*/
# ifdef USEITOSTR
char * itostr (int x) {
	static char s[32] ;
	sprintf (s, "%d", x) ;
	return s ;
}
# endif
/*____________________________________________________________________________
*/
long long getsysram () {
#ifdef AIX
	long long z = (long long) sysconf(_SC_AIX_REALMEM) ;
	z = 1024LL * z ;
#endif
#ifdef HPUX
#ifdef _SC_MEM_MBYTES
	long long z = (long long) sysconf(_SC_MEM_MBYTES);
	z = 1000000LL * z ;
#else
	long long z = 0 ;
#endif
#endif
#if defined(LINUX) || defined(SUNX) || defined(CYGWIN)
	long pp = sysconf(_SC_PHYS_PAGES) ;
	long ps = sysconf(_SC_PAGE_SIZE) ;
	long long z ;
	z = (long long)pp * (long long)ps ;
#endif
	return z ;
}
/*____________________________________________________________________________
*/
int			cpucount = 0 ;
long long	cpuclock = 0 ;	/*	in Hz	*/
char *      cpumodel = "generic" ;

char *      cpunotfound = "unavailable" ;

char		txtcpucount [32] ;
char		txtcpuclock [32] ;
char		txtcpumodel [32] ;
/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
char * getcpuinf (what) char * what ; {

#ifdef SUNX

	processorid_t i , cpuid_max ;
	processor_info_t infop ;

	cpuid_max = sysconf(_SC_CPUID_MAX) ;
	if ( (long)cpuid_max == -1L ) {
		return cpunotfound ;
	}
   	for ( i = 0 ; i <= cpuid_max ; i++ ) {
		if ( p_online ( i , P_STATUS ) != -1 ) {
			++cpucount ;
			if ( processor_info ( i , &infop ) != -1 ) {
				cpuclock = 1000000LL * infop.pi_clock ;
			}
		}
   	}

#endif /* SUNX */

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

#ifdef AIX

	struct CuDv *q;
	CLASS_SYMBOL cudv;
	char * devname = "proc0" ;
	char * attrname = "frequency" ;
	int getall = 0 ;
	int howmany ;
	struct CuAt * captr ;

	if (odm_initialize())
		return cpunotfound ;

    cudv = odm_open_class_rdonly(CuDv_CLASS);

    if (cudv == (CLASS_SYMBOL) -1) {
		odm_terminate();
		return cpunotfound ;
    }

    q = odm_get_first(cudv, "name like 'proc*'", NULL);

    if ((q == NULL) || (q == (struct CuDv *) -1)) {
		odm_close_class(cudv);
		odm_terminate();
		return cpunotfound ;
    }

    devname = strdup (q->name);

	do {
		++cpucount ;
		q = odm_get_next (cudv, NULL);
	} while ( ( q != NULL ) && ( q != (struct CuDv *) -1 ) ) ;

    free(q);
    odm_close_class(cudv);

	captr = getattr (devname, attrname, getall, &howmany) ;

	if ( captr == NULL ) {
		odm_terminate();
        return cpunotfound ;
	}

	sscanf ( captr->value , "%lld" , &cpuclock ) ;

    captr = getattr (devname, "type", getall, &howmany) ;

    if ( captr == NULL ) {
        odm_terminate();
        return cpunotfound ;
    }

    cpumodel = strdup ( captr->value ) ;

	odm_terminate () ;

#endif /* AIX */

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

#ifdef HPUX

	struct pst_processor pinfo;
	struct pst_dynamic psd;
	long clktck = 0 , chiptype = 0 , cpuver = 0 ;
	static char * cpuarcht [] = { "HP" , "PA-RISC" , "Itanium" , NULL } ;

	if (pstat_getdynamic(&psd, sizeof(psd), 1, 0) == -1) {
		return cpunotfound ;
	}

	cpucount = (int)(psd.psd_proc_cnt);

	if (pstat_getprocessor(&pinfo, sizeof(pinfo), 1, 0) == -1) {
		return cpunotfound ;
	}

#ifdef HPUX1131
	cpuclock = (long long)(pinfo.psp_cpu_frequency);
#endif /* HPUX1131 */

	if ( cpuclock <= 0 ) {
		clktck = sysconf(_SC_CLK_TCK);
		if ( clktck == -1L ) {
			return cpunotfound ;
		} else {
			cpuclock = (long long)(pinfo.psp_iticksperclktick) * clktck ;
		}
	}

#ifdef HPUX1131
	cpumodel = cpuarcht [ (int) pinfo.psp_cpu_architecture ] ;
#endif /* HPUX1131 */

	chiptype = sysconf(_SC_CPU_CHIP_TYPE);
	cpuver = sysconf(_SC_CPU_VERSION);

	switch ( chiptype ) {
		case 0x20000704 : cpumodel = strdup ( "Itanium2-9000" ) ;
		case 0x20010104 : cpumodel = strdup ( "Itanium2-9100" ) ;
		case 0x00000285 : cpumodel = strdup ( "PA8800" ) ;
		case 0x0000028a : cpumodel = strdup ( "PA8900" ) ;
	}

# ifdef CHIPRANG
	switch ( chiptype >> 5 ) {
		case	0x000b : cpumodel = strdup ( "PA7200"		) ;
		case	0x000d : cpumodel = strdup ( "PA7100LC"		) ;
		case	0x000e : cpumodel = strdup ( "PA8000"		) ;
		case	0x000f : cpumodel = strdup ( "PA7300LC"		) ;
		case	0x0010 : cpumodel = strdup ( "PA8200"		) ;
		case	0x0011 : cpumodel = strdup ( "PA8500"		) ;
		case	0x0012 : cpumodel = strdup ( "PA8600"		) ;
		case	0x0013 : cpumodel = strdup ( "PA8700"		) ;
		case	0x0015 : cpumodel = strdup ( "PA8750"		) ;
	}
# endif /* CHIPRANG */

#endif /* HPUX */

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

#if defined(LINUX) || defined(CYGWIN)

	FILE * fp = NULL ;
	char pciline [512] ;
	char * np = NULL ;
	double dclock = 0.0 ;

	fp = fopen ( "/proc/cpuinfo" , "r" ) ;

	if ( fp == NULL ) {
		return cpunotfound ;
	}

	while ( NULL != fgets ( pciline , 512 , fp ) ) {
		if ( NULL != (char *) strcasestr ( pciline , "cpu" ) ) {
			if ( NULL != (char *) strcasestr ( pciline , "mhz" ) ) {
				++cpucount ;
				if ( NULL != ( np = strchr ( pciline , ':' ) ) ) {
					sscanf ( 1+np , "%lf" , &dclock ) ;
					cpuclock = (long long) ( 1000000.0 * dclock ) ;
				}
			}
		}
	}

	fclose (fp) ;

#endif /* LNX/CYG */

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/
	if ( 0 == strcmp ( what , "count" ) ) {
		sprintf ( txtcpucount , "%d" , cpucount ) ;
		return txtcpucount ;
	} else if ( 0 == strcmp ( what , "clock" ) ) {
		sprintf ( txtcpuclock , "%lld" , cpuclock ) ;
		return txtcpuclock ;
	} else if ( 0 == strcmp ( what , "model" ) ) {
		strcpy ( txtcpumodel , cpumodel ) ;
		return txtcpumodel ;
	} else {
		return cpunotfound ;
	}

} /* getcpuinf() */
/*\___________________________________________________________________________
\*/
int isbigend () {
	int no = 1;
	char *chk = (char *)&no;

	if (chk[0] == 1)
		return 0;
	else
		return 1;
}

int islilend () {
	return ! isbigend () ;
}
/*\___________________________________________________________________________
\*/

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history ..............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v rls   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
