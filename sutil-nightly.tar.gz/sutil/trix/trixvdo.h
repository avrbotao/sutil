
# ifdef XENIX
# include <sys/machdep.h>
# endif /* XENIX */

# ifdef UNIX
# ifndef HPUX
# include <sys/machdep.h>
# endif	/* HPUX */
# endif /* UNIX */

struct vstat {
    int vs_flag ;
    int vs_lins ;
    int vs_cols ;
    int vs_adap ;
    int vs_mode ;   /* current mode     */
    int vs_orig ;   /* original mode    */
} ;
typedef     struct vstat    VSTAT ;

# define    VS_TERM     0x0001
# define    VS_CONS     0x0002
# define    VS_4380     0x0004
# define    VS_ORIG     0x0008

# define    VSMODE(X)   (MODESWITCH | X)

# ifdef ANSI

int vstat (int, VSTAT *, int) ;

void revvideo (void) ;
void revblink (void) ;
void blinkvideo (void) ;
void undervideo (void) ;
void agcsvideo (void) ;
void normvideo (void) ;
void highvideo (void) ;
void textattr (int) ;

# else  /* OLD STYLE */

int vstat ( ) ;

void revvideo ( ) ;
void revblink ( ) ;
void blinkvideo ( ) ;
void undervideo ( ) ;
void agcsvideo ( ) ;
void normvideo ( ) ;
void highvideo ( ) ;
void textattr ( ) ;

# endif /* ANSI */
