
/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	trixstd.h 1.0						 92/11/11	|
 *		|	Copyright (c) 1992		Alexandre V. R. Botao	|
 *		|___________________________________________________|
 */

# ifdef XSTD

#	ifdef ANYX

extern		char *		sys_errlist [] ;

#	endif /* ANYX */

#	ifdef COMMENT

int			atoi		OF ( ( char * ) ) ;
long		atol		OF ( ( char * ) ) ;
char * 		bsearch		OF ( ( char *, char *, unsigned, unsigned, int (*)() ) ) ;
char *		malloc		OF ( ( unsigned ) ) ;
void		exit		OF ( ( int ) ) ;
void 		free		OF ( ( char * ) ) ;
char *		getenv		OF ( ( char * ) ) ;
int			qsort		OF ( ( char *, unsigned, unsigned, int(*)() ) ) ;
int			system		OF ( ( char * ) ) ;

#	endif /* COMMENT */

# else  /* STDLIB.H */

#	include	<stdlib.h>

#	ifdef AIX

extern		char *		sys_errlist [] ;

#	endif /* AIX */

#	ifdef SOLARIS

extern		char *		sys_errlist [] ;

#	endif /* SOLARIS */

#	ifdef HPUX

extern		char *		sys_errlist [] ;

#	endif /* HPUX */

# endif /* XSTD */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/*
 * vi:tabstop=4
 */
