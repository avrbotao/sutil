/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixget.c + generic input miscellanea ...			|
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include <stdio.h>
# include <string.h>

# ifdef		DOS

/*	# include	<bios.h>	*/

# include	<conio.h>

# endif		/* DOS */

# include	"trixasci.h"
# include	"trix.h"
# include	"trixblue.h"
# include	"trixkeys.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixwig.h"

EXT		int				xfmb ;
EXT		char *			ghyid ;
/*----------------------------------------------------------------------*
*	...																	*
*----------------------------------------------------------------------*/
# ifdef		ANYX

EXT		int				tfd ;

EXT		char * *		efon [ ] ;
EXT		char * *		efof [ ] ;

# endif		/* ANYX */
/*======================================================================*
*	trixgets ...														*
*======================================================================*/
int trixgets (prompt, fmb, buf, siz, flg) char * prompt, * buf ; int fmb , siz , flg ; {
	REG int plen = strlen (prompt) ;
	REG int grd ;
	REG char * tp ;

	xfmb = fmb ;
	frescrn (CLRMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	dispat (_msglin, 0, prompt, plen, VEHILT) ;

	for ( ; ; ) {
		grd = geds (_msglin, plen, buf, siz, flg) ;

		if (grd == KUP || grd == KDOWN
					   || grd == CTRL_E || grd == CTRL_X) {
			addhist (ghyid, buf) ;
			if ((tp = trixhist (ghyid, grd)) != (char *) 0) {
				strcpy (buf, tp) ;
				flg |= USEBUF ;
			}
		} else
			break ;
	}

	if (ghyid != NOSTR)
		addhist (ghyid, buf) ;

	frescrn (UDMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	return grd ;
}
/*
 *		O-------------------------------------------------------O
 *		|	geds : Get, perhaps EDiting a String !  			|
 *      |   + don't forget compat/y (^S,^D,^A,^F,...)           |
 *		|	+ when get an ESC : if (empty line) rtn ESC			|
 *		|						else clear buffer & continue	|
 *		O-------------------------------------------------------O
 */

int geds (glin, gcol, buf, siz, flg) int glin , gcol ; char * buf ; int siz , flg ; {

	register char * tp ;
	register char * bp = buf ;
	REG int blen = 0 ;
	REG int xcol = 0 ;
	REG int x, y ;
	REG int ins = TRUE ;

# ifdef ANYX
	char cx ;		/* used by ECHOKEY() */
# endif /* ANYX */

	showcursor () ;

	if (flg & USEBUF) {
		xcol = blen = strlen (buf) ;
		dispat (glin, gcol, buf, siz, VENORM) ;
		memset (buf+blen, '\0', siz-blen) ;
		bp = buf + blen ;
	} else {
		memset (buf, '\0', siz) ;
	}

	locat (glin, gcol+xcol) ;

	for ( ; ; ) {

		x = getkey () ;

		if (x == '\r' || x == '\n') {
			x = ENTER ;
			break ;
		}

		if (x == KF1) {
			hyxhelp (NOSTR) ; continue ;
		}

		if (x == ESC || x == KF2 || x == KF3 || x == KF8)
			break ;

		if (x == KUP || x == KDOWN || x == CTRL_X || x == CTRL_E) {

			if (ghyid == NOSTR)
				continue ;

			break ;
		}

		if (x == KHOME) {

			locat (glin, gcol) ;
			xcol = 0 ;
			bp = buf ;

		} else if (x == KEND) {

			xcol = blen ;
			locat (glin, gcol+xcol) ;
			bp = buf + blen ;

		} else if (x == KPGUP) {

		} else if (x == KPGDN) {

		} else if (x == KLEFT) {

			if (bp > buf) {
				--bp ; --xcol ;
				locat (glin, gcol+xcol) ;
			}

		} else if (x == KRIGHT) {

			if (bp < buf+blen) {
				++bp ; ++xcol ;
				locat (glin, gcol+xcol) ;
			}

		} else if (x == KINS) {

			ins = ! ins ;

		} else if (x == KDEL || x == CTRL_G || x == '\177') {

			if (*bp != '\0') {
                --blen ; goto ueol ;
            }

		} else if (x == '\b') {

			if (bp > buf) {
				--bp ; --xcol ; --blen ;
				locat (glin, gcol+xcol) ;
ueol :
				for ( tp = bp+1 ; *tp ; ++tp ) {
					ECHOKEY (*tp) ;
					*(tp-1) = *tp ;
				}

				ECHOKEY (' ') ; *(tp-1) = '\0' ;
				locat (glin, gcol+xcol) ;
			}

		} else if (x >= ' ' && x <= '~') {

			if (ins) {

				if ( blen == (siz - 1) )
					goto uk ;

				if (bp >= buf + blen)
					goto ak ;

				for ( tp = bp ; x != '\0' ; ++tp ) {
					y = *tp ;
					*tp = x ; ECHOKEY (x) ;
					x = y ;
				}

				++blen ; ++bp ; ++xcol ;
				*(bp+blen) = '\0' ;
				locat (glin, gcol+xcol) ;

			} else {
ak :
				ECHOKEY (x) ;
				*bp++ = x ; ++xcol ;

				if (bp >= buf + blen)
					++blen ;
			}

		} else { /* default : ... */
uk :
			honk () ; continue ;
		}

		if ( (int) (bp - buf) == (siz - 1) )
			/* break */ goto uk ;
	}

	*(bp+blen) = '\0' ;
	hidecursor () ;

	return x ;
}

/************************************************************************
*																		*
*	+ every place where getkey() is used must chk if == invalid key &	*
*	  then ioctl (flush input queue buffer), so wrong commands fired	*
*	  by lost key bursts is avoided ...									*
*																		*
************************************************************************/

# ifndef TRIXKEY

int getkey () {

# ifdef DOS

	REG int key ;

	GETKEY (key) ;

	if (key == '\0') {                      /* PC */
		GETKEY (key) ;
		return (PCKEY (key)) ;
	} else {                                /* anything ... */
		return (key) ;
	}

# else  /* ANYX */

	REG int key ;

# ifdef		CURSES

	noecho () ;
	key = getch () ;
	echo () ;
	return ( key ) ;

# else		/* PROPRIETARY ... */

	FIX UNS char * kyb = (UNS char *) "    " ;

	GETKEY (key) ;

	if (key == ESC) {
vt52:
		GETKEY (key) ;

		switch (key) {
			case 'A' :  return (KUP) ;
			case 'B' :  return (KDOWN) ;
			case 'C' :  return (KRIGHT) ;
			case 'D' :  return (KLEFT) ;
			case 'H' :  return (KHOME) ;
			case L_BK : goto vt52 ;
			default :   goto badky ;
		}

	} else { /* anything ... */
badky :
		return (key) ;
	}

# endif	/* CURSES */

# endif /* DOS */

}

# endif /* ! TRIXKEY */

/*----------------------------------------------------------------------*
*	...																	*
*----------------------------------------------------------------------*/

# ifdef COMMENT

char * xgetpass (prompt, maxchr) char * prompt ; {

	static char b [40] ;
	register char * p = b ;
	int x ;

	cputs (prompt) ;

	for ( ; ; ) {
		x = bioskey (0) & 0xff ;
		if (x == '\r' || x == '\n')
			break ;
		if (x == '\b') {
			if (p > b)
				--p ;
		} else
			*p++ = x ;
		if ((int) (p - b) == maxchr)
			break ;
	}
	*p = '\0' ;
	return b ;
}

# endif /* COMMENT */

/***********************************************************************/
/*
 * vi:nu tabstop=4
 */
