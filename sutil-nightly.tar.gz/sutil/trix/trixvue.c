
/*                	 _______________________________________________
 *  ______________	|												|
 * /\  ___________\	|	TRIX + file system administration utility	|
 * \ \ \________  /	|_______________________________________________|
 *  \ \ \    / / /	|                                               |
 *   \ \ \  / / /	|	object-oriented polymorphic browser ...		|
 *    \ \ \/ / /	|_______________________________________________|
 *     \ \/ / /		|												|
 *		\  / /		|	TRIX & its logo are registered trademarks	|
 *		 \/_/		|	of Alexandre Victor Rodrigues Botao (1991)	|
 *					|_______________________________________________|
 */

# include	<stdio.h>
# include	<string.h>

# ifdef		DOS

# include	<conio.h>

# include	<sys/types.h>
# include	<sys/stat.h>

# else		/* ANYX */

# include	<unistd.h>

# include	"trixterm.h"

# endif		/* DOS */

# include	"trix.h"
# include	"trixstd.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixkeys.h"
# include	"trixblue.h"
# include	"trixaloc.h"
# include	"trixasci.h"
# include	"trixchrs.h"
# include	"trixvdo.h"
# include	"trixwig.h"
# include	"trixwind.h"

EXT     char *  clbuf ;
EXT		BYT		xfram [] ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	local definitions ...	|
 *		|___________________________|
 */

# define	COWARD						/* binary data craps ...	*/
# define	FOLDEM						/* fold long lines ...		*/

# define	VBUFSIZ		20000			/*   8k ?  16k ?			*/
# define	HBUFSIZ		(VBUFSIZ / 2)
# define	VMAXLIN		2000			/*  500 ? 1000 ?			*/
# define	VLINSIZ		300				/*  400 ?					*/
# define	VMAXTAB		20
# define	LBUFSIZ		(VMAXTAB * VLINSIZ + 1)

# define	EBINDAT		-8

# define	VWEIRDB		'.'				/*		'~'		'?'		...	*/

# define	LINTOFS		0
# define	COLTOFS		75
# define	LENTOFS		5

# define	LINNAME		0
# define	COLNAME		12
# define	WIDNAME		60

# ifdef		FOLDEM

# undef		COWARD

# define	FOLDLIM		(VLINSIZ-2)

# define	VUEBUF		foldbuf

# else		/* LETHEM */

# define	VUEBUF		filebuf

# endif		/* FOLDEM */

# ifdef CYGWIN
# define  cprintf  printf
# define  kbhit    xkbhit
# endif

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	local function prototypes ...	|
 *		|___________________________________|
 */

# ifdef ANSI

void		avufac		(void)  ;
void		flexfram	(char * *) ;

# else  /* OLD STYLE */

void	    avufac		()  ;
void		flexfram	() ;

# endif /* ANSI */

/*
 *		|~~~~~~~~~~~~~~~~~~~|
 *		|	globals ...		|
 *		|___________________|
 */

EXT	char *	cebuf ;

FIX char *	vnam ;
FIX int		vtofs ;
FIX int		vtabsiz = -1 ;

char * vuefram [] = {
    "'-'g",
	"'p2,1'=80's-",
/*	"'p21,1'=80's-", */
	"'p1,1'n* Arquivo :",
	(char *) 0
} ;

/* - - - - - - - - - - - - - - - - - - - - - */

/*
 *												|~~~~~~~~~~~~~~~~~~~|
 *												|	ascii vur ...	|
 *												|___________________|
 */

int trixvue (ffp) FILDAT * ffp ; {

	register char * bp , * lp ;
	register int tk, y, x, foldx, key=0, xb ;
	FILE * fp = (FILE *) 0 ;
	char tb [40] ;
	REG char * vlinbuf = (char *) 0 ;
	REG int rs=0, vy, vmaxlin=0, topg=0, stopg, blino, byon ;
	char * filebuf = (char *) 0 ;

# ifdef		FOLDEM

	char *	foldbuf = (char *) 0 ;
	int		foldk ;

# endif		/* FOLDEM */

	char * * linptr = (char * *) 0 ;
	long /* size_t */ vbufsiz, byrd=0L ;
	long balr, byet ;			/* byts already & yet 2 b seen */
	long filsiz, xofs = 0L ;
	struct STAT stabuf ;
	int vpaghei = _vdolins - 6 , grd ;

	vnam = ffp->fd_path ;
	vtofs = 0 ;

# ifdef ANYX

	if (access (vnam, R_OK) < 0)
		goto ae ;

# endif /* ANYX */

	if (vtabsiz == -1)
		vtabsiz = xtabsiz ;

	if ((fp = fopen (vnam, "rb")) == NOFILE) {
ae :	trixerr (T_ACCESS, vnam, errno, BANAL) ;
		return -1 ;
	}

	if (FSTAT (fileno (fp), &stabuf) < 0)
		goto ae ;

	if (stabuf.st_size == 0) {
		return -1 ;
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - */

	CLRSCR ;

rehom :

	avufac () ;

	byet = filsiz = stabuf.st_size ; balr = 0L ; topg = byon = 0 ;
rebuf :
	if (byet < VBUFSIZ) {
		vbufsiz = (size_t) byet ;
	} else {
		vbufsiz = VBUFSIZ ;
	}

	if (filebuf == (char *) 0) {
		filebuf = calloc ((size_t)vbufsiz, sizeof (char)) ;

		if (filebuf == (char *) 0) {
nmv :		trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
			goto vkk ;
		}
		linptr = (char * *) calloc (VMAXLIN, sizeof (char *)) ;

		if (linptr == (char * *) 0) {
			goto nmv ;
		}
	}

	if (vlinbuf == (char *) 0) {
		vlinbuf = malloc ((size_t)LBUFSIZ) ;

		if (vlinbuf == (char *) 0) {
			goto nmv ;
		}
	}

# ifdef		FOLDEM

	if (foldbuf == (char *) 0) {
		foldbuf = malloc ( (size_t) (vbufsiz+(vbufsiz/FOLDLIM)+1) ) ;

		if (foldbuf == (char *) 0) {
			goto nmv ;
		}
	}

# endif		/* FOLDEM */

	fseek (fp, balr, SEEK_SET) ;
	byrd = fread (filebuf, 1, (size_t) vbufsiz, fp) ;

	if (byrd != vbufsiz) {
		trixerr (T_READERR, vnam, errno, BANAL) ;
		goto vkk ;
	}

	linptr[0] = VUEBUF ;

# ifdef		FOLDEM

	foldk = foldx = 0 ;

	for ( x = 0 , y = 1 ; x < vbufsiz ; ++x ) {

# else		/* LETHEM */

	for ( x = y = 1 ; x < vbufsiz ; ++x ) {

# endif		/* FOLDEM */

# ifdef		FOLDEM

		if (++foldk > FOLDLIM) {
			goto ml ;
		}

		VUEBUF [foldx] = filebuf [x] ;

# endif		/* FOLDEM */

		xb = filebuf [x] ;

		if (xb != '\n' && xb != '\t') {
			if (xb < ' ' || xb > '~')
				goto eb ;
		}

		if (filebuf[x] & 0x80) {
eb :
# ifdef COWARD
			rs = EBINDAT ;			/* binary (non-ascii) data ...	*/
			goto eov ;
# else  /* ! COWARD */
			VUEBUF [foldx] = VWEIRDB ;
# endif /* COWARD */
		}

		if (filebuf[x] == '\n') {
# ifdef		FOLDEM
ml :
			VUEBUF [foldx] = '\0' ; linptr[y++] = & VUEBUF [foldx+1] ;
			if (foldk > FOLDLIM) {
				VUEBUF [foldx+1] = filebuf [x] ; ++foldx ;
				foldk = 1 ;
			} else
				foldk = 0 ;
# else		/* LETHEM */
			VUEBUF [x] = '\0' ; linptr[y++] = & VUEBUF [x+1] ;
# endif		/* FOLDEM */
		}

		if (y == VMAXLIN)
			break ;

# ifdef		FOLDEM

		++foldx ;

# endif		/* FOLDEM */

	}

	vmaxlin = y - 1 ;

	while (y < VMAXLIN)
		linptr[y++] = (char *) 0 ;

	if (filsiz <= VBUFSIZ) {
		byon = (int) (balr = filsiz) ; byet = 0L ;
	}

	for ( ; ; ) {

# ifdef VUETRC
if (kbhit ())
	goto eov ;
# endif /* VUETRC */

		for ( vy=0, y=2, blino=topg ; vy < vpaghei ; ++vy, ++y, ++blino ) {

			locat (y, 0) ;	/*	gotoxy (1, y) ;		*/
			CLRTOEOL ;		/*	clreol () ;			*/

			if (blino < vmaxlin) {

				lp = linptr[blino] ;

				if (lp == (char *) 0 || blino < 0) {
# ifdef COMMENT
					if (trixerr ("ieav0001", NOSTR, NOWHY, BANAL) == ESC)
                        goto eov ;
# endif /* COMMENT */
					goto rehom ;
                }

				if (*lp == '\n' || *lp == '\r')
					continue ;

				bp = vlinbuf ; tk = 0 ;

				do {

					if (*lp != '\t') {

						if (++tk >= vtabsiz)
							tk = 0 ;

						*bp = *lp ;

					} else {

						while (tk++ < vtabsiz)
							*bp++ = ' ' ;

						tk = 0 ; --bp ;
					}

					++lp ;

				} while (*bp++ != '\0') ;

				if (vtofs < (bp-vlinbuf)) {

						tk = (int) (bp-(vlinbuf+vtofs)) ;

						if (tk > 80)
							tk = 80 ;

						dispat (y, 0, vlinbuf+vtofs, tk, VENORM) ;
					/*	cprintf ("%.80s", vlinbuf+vtofs) ;	*/
				}

			} else {

				if (filsiz > VBUFSIZ) {

					if (balr+byon < filsiz) { /* ? || <= ? */

						byon = (int) (linptr[topg]-/*filebuf*/linptr[0]) ;
						balr += byon ;
						byet -= byon ;
						topg = 0 ; goto rebuf ;
					}
				}
			}
		}

# ifdef VUETRC
gotoxy(1,2);
cprintf("?bs%5ldbr%5ldba%5ldby%5ldfs%5ldml%5dtp%5dln%5dbo%5d xo %ld",vbufsiz,byrd,balr,byet,filsiz,vmaxlin,topg,blino,byon,xofs);
# endif /* VUETRC */

		/*
		 *	+ select action ...
		 */
aw :
		key = getkey () ;
		switch (key) {

            case '\t' :     /* tab size */

				grd = asktxt ("* Mudar o tamanho do TAB ...",
							  "* Informe o novo tamanho : ", tb, 8, 0) ;

				if (grd != ENTER)
					break ;

				x = atoi (tb) ;

				if (x >= 1 && x <= VMAXTAB) {
                    vtabsiz = x ;
                }

			break ;

			case '?' :
			case KF1 : hyxhelp ("Visor ASCII") ; break ;

			case CTRL_V :
			case KF9 :		rs = 'h' ;

			case CTRL_Q :
			case ESC :		goto eov ;

			case KEND : /* End */
			case '1'  :

				if (vmaxlin <= vpaghei)
					goto aw ;

				if (filsiz > VBUFSIZ) {

					vbufsiz = VBUFSIZ ;
					byet = 0 ; xofs = vbufsiz ;
					fseek (fp, -xofs, SEEK_END) ;
					byrd = fread (filebuf, 1, (size_t) vbufsiz, fp) ;

					if (byrd != vbufsiz) {
						trixerr (T_READERR, vnam, errno, BANAL) ;
						goto vkk ;
					}
# ifdef		FOLDEM
					linptr[0] = VUEBUF ;
					lp = strchr (filebuf, '\n') ;

					if (lp == (char *) 0)
						lp = filebuf ;
					else {
						++lp ;
					}

# else		/* LETHEM */

					lp = linptr[0] = strchr (filebuf, '\n') ;

					if (lp == (char *) 0)
						lp = linptr [0] = filebuf ;
					else {
						++lp ; linptr[0] += 1 ;
					}

# endif		/* FOLDEM */

					vy = (int) (lp-filebuf) ; tk = (size_t) vbufsiz - vy ;
					balr = filsiz - VBUFSIZ + vy ;
					byon = VBUFSIZ - vy ;

# ifdef		FOLDEM

					foldk = foldx = 0 ;

					for ( x = 0 , y = 1 ; x < tk ; ++x ) {

# else		/* LETHEM */

					for ( x = y = 1 ; x < tk ; ++x ) {

# endif		/* FOLDEM */

# ifdef		FOLDEM
						if (++foldk > FOLDLIM) {
							goto ml1 ;
						}

						VUEBUF [foldx] = *(lp+x) ;
# endif		/* FOLDEM */
						xb = *(lp+x) ;

						if (xb != '\n' && xb != '\t') {
							if (xb < ' ' || xb > '~')
								goto eb1 ;
						}

						if (*(lp+x) & 0x80) {
eb1 :
# ifdef COWARD
							rs = EBINDAT ;	/* binary data ...	*/
							goto eov ;
# else  /* ! COWARD */
							VUEBUF [foldx] = VWEIRDB ;
# endif /* COWARD */
						}

						if (*(lp+x) == '\n') {
# ifdef		FOLDEM
ml1 :
							VUEBUF [foldx] = '\0' ;
							linptr[y++] = & VUEBUF [foldx+1] ;

							if (foldk > FOLDLIM) {
								VUEBUF [foldx+1] = *(lp+x) ; ++foldx ;
								foldk = 1 ;
							} else
								foldk = 0 ;
# else		/* LETHEM */
							*(lp+x) = '\0' ;
							linptr[y++] = lp+(x+1) ;
# endif		/* FOLDEM */
						}

						if (y == VMAXLIN)
							break ;
# ifdef		FOLDEM
						++foldx ;
# endif		/* FOLDEM */

					}

					vmaxlin = y - 1 ;

					while (y < VMAXLIN)
						linptr[y++] = (char *) 0 ;

				}

				topg = vmaxlin - vpaghei ;

			break ;

			case '\r'  :
			case '2'   : /* South Arrow */
			case KDOWN :

				if (blino > vmaxlin)
					goto aw ;
				if (blino == vmaxlin && byrd+balr >= filsiz)
					goto aw ;
				++topg ;

			break ;

			case '3'   :
			case ' '   : /* PgDn */
			case KPGDN :
				topg += vpaghei ;
				if (topg >= vmaxlin && byrd+balr >= filsiz) {
					topg -= vpaghei ;
					goto aw ;
				}
			break ;

			case '4'   : /* left arrow */
			case KLEFT :

				if (vtofs > 0) {

					vtofs -= vtabsiz ;

					if (vtofs > 0) {
						sprintf (tb, "+%d", vtofs+1) ;
					} else {
						strcpy (tb, "      ") ;
					}

					dispat (LINTOFS, COLTOFS, tb, LENTOFS, VENORM) ;

				} else
					goto aw ;
			break ;

			case '6'    : /* right arrow */
			case KRIGHT :

				if (vtofs < VLINSIZ - vtabsiz /* vtofs */) {

					vtofs += vtabsiz ;

					if (vtofs > 0) {
						sprintf (tb, "+%d", vtofs+1) ;
					} else {
						strcpy (tb, "      ") ;
					}

					dispat (LINTOFS, COLTOFS, tb, LENTOFS, VENORM) ;

				} else
					goto aw ;
			break ;

			case '7'   : /* Home */
			case KHOME :
				goto rehom ;

            case '-' :
			case '8' : /* North Arrow */
			case KUP :

				if (filsiz <= VBUFSIZ) {

					if (topg == 0)
                        goto aw ;

					--topg ;

				} else {

					if (topg > 0) {

						--topg ;

					} else {

						if (balr == 0)
							goto aw ;
												/* buffing back ...		*/
						if (balr <= HBUFSIZ) {	/* top-of-file ...		*/
							byet = filsiz = stabuf.st_size ;
							vmaxlin = (int) balr ;
							balr = xofs = 0L ; byon = 0 ;
							vbufsiz = VBUFSIZ ;
						} else {
							xofs = balr - HBUFSIZ ; vmaxlin = HBUFSIZ ;
							vbufsiz = (filsiz - xofs) ;
							if (vbufsiz > VBUFSIZ)
								vbufsiz = VBUFSIZ ;
							balr = xofs ; byet = filsiz - balr ;
						}

						fseek (fp, xofs, SEEK_SET) ;
						byrd = fread (filebuf, 1, (size_t) vbufsiz, fp) ;

						if (byrd != vbufsiz) {
							trixerr (T_READERR, vnam, errno, BANAL) ;
							goto vkk ;
						}
# ifdef	FOLDEM
						linptr[0] = VUEBUF ;
						lp = strchr (filebuf, '\n') ;

						if ((lp == (char *) 0) || (xofs == 0L))
							lp = filebuf ;
						else {
							++lp ;
						}
# else	/* LETHEM */
						lp = linptr[0] = strchr (filebuf, '\n') ;

						if ((lp == (char *) 0) || (xofs == 0L))
							lp = linptr [0] = filebuf ;
						else {
							++lp ; linptr[0] += 1 ;
						}
# endif	/* FOLDEM */
						topg = -1 ; vy = (int) (lp-filebuf) ;
						tk = (size_t) vbufsiz - vy ; balr += vy ; byet -= vy ;
# ifdef	FOLDEM
						foldk = foldx = 0 ;

						for ( x = 0 , y = 1 ; x < tk ; ++x ) {
# else	/* LETHEM */
						for ( x = y = 1 ; x < tk ; ++x ) {
# endif	/* FOLDEM */

# ifdef	FOLDEM
							if (++foldk > FOLDLIM) {
								goto ml8 ;
							}

							VUEBUF [foldx] = *(lp+x) ;
# endif	/* FOLDEM */
							xb = *(lp+x) ;

							if (xb != '\n' && xb != '\t') {
								if (xb < ' ' || xb > '~')
									goto eb8 ;
							}

							if (*(lp+x) & 0x80) {
eb8 :
# ifdef COWARD
								rs = EBINDAT ;	/* binary data ...	*/
								goto eov ;
# else  /* ! COWARD */
								VUEBUF [foldx] = VWEIRDB ;
# endif /* COWARD */
							}

							if (*(lp+x) == '\n') {
# ifdef		FOLDEM
ml8 :
								if (((x+1)+vy) == vmaxlin)
									topg = y ;

								VUEBUF [foldx] = '\0' ;
								linptr[y++] = & VUEBUF [foldx+1] ;

								if (foldk > FOLDLIM) {
									VUEBUF [foldx+1] = *(lp+x) ; ++foldx ;
									foldk = 1 ;
								} else
									foldk = 0 ;
# else		/* LETHEM */
								if (((x+1)+vy) == vmaxlin)
									topg = y ;

								*(lp+x) = '\0' ;
								linptr[y++] = lp+(x+1) ;
# endif		/* FOLDEM */
							}

							if (y == VMAXLIN)
								break ;
# ifdef		FOLDEM
							++foldx ;
# endif		/* FOLDEM */
						}

						if (topg < 0) {
# ifdef COMMENT
							if (trixerr("ieav0002",NOSTR,NOWHY,BANAL)==ESC)
                                goto eov ;
# endif /* COMMENT */
                            goto rehom ;
						}

						vmaxlin = y - 1 ;

						while (y < VMAXLIN)
							linptr[y++] = (char *) 0 ;

						byon = (int) (linptr[topg]-lp) ;
						--topg ; /* fit ! */

						if (topg < 0)
                            topg = 0 ;
					}
                }

			break ;

			case '9'   : /* PgUp */
			case KPGUP :

				if (filsiz <= VBUFSIZ) {

					if (topg == 0) {
                        goto aw ;
					}

					if (topg > vpaghei) {
    					topg -= vpaghei ;
    				} else {
						goto rehom ;
					}

				} else {

					if (topg > vpaghei) {

						topg -= vpaghei ;

					} else {

						if (balr == 0L) {
							if (topg > 0) {
								goto rehom ;
							} else {
								goto aw ;
							}
						}

    					/*
    					 *	buf back half way ...
						 */
												/* buffing back ...		*/
						if (balr <= HBUFSIZ) {	/* top-of-file ...		*/
							byet = filsiz = stabuf.st_size ;
							vmaxlin = (int) balr ;
							balr = xofs = 0L ; byon = 0 ;
							vbufsiz = VBUFSIZ ;
						} else {
							xofs = balr - HBUFSIZ ; vmaxlin = HBUFSIZ ;
							vbufsiz = (filsiz - xofs) ;
							if (vbufsiz > VBUFSIZ)
								vbufsiz = VBUFSIZ ;
							balr = xofs ; byet = filsiz - balr ;
						}

						fseek (fp, xofs, SEEK_SET) ;
						byrd = fread (filebuf, 1, (size_t) vbufsiz, fp) ;

						if (byrd != vbufsiz) {
							trixerr (T_READERR, vnam, errno, BANAL) ;
							goto vkk ;
						}
# ifdef	FOLDEM
						linptr[0] = VUEBUF ;
						lp = strchr (filebuf, '\n') ;

						if ((lp == (char *) 0) || (xofs == 0L)) {
							lp = filebuf ;
						} else {
							++lp ;
						}
# else	/* LETHEM */
						lp = linptr[0] = strchr (filebuf, '\n') ;

						if ((lp == (char *) 0) || (xofs == 0L)) {
							lp = linptr [0] = filebuf ;
						} else {
							++lp ; linptr[0] += 1 ;
						}
# endif	/* FOLDEM */
						stopg = topg ; topg = -1 ;
                        vy = (int) (lp-filebuf) ;
						tk = (size_t) vbufsiz - vy ; balr += vy ; byet -= vy ;
# ifdef		FOLDEM
						foldk = foldx = 0 ;

						for ( x = 0 , y = 1 ; x < tk ; ++x ) {

# else		/* LETHEM */

						for ( x = y = 1 ; x < tk ; ++x ) {

# endif		/* FOLDEM */

# ifdef		FOLDEM
							if (++foldk > FOLDLIM) {
								goto ml9 ;
							}

							VUEBUF [foldx] = *(lp+x) ;
# endif		/* FOLDEM */
							xb = *(lp+x) ;

							if (xb != '\n' && xb != '\t') {
								if (xb < ' ' || xb > '~') {
									goto eb9 ;
								}
							}

							if (*(lp+x) & 0x80) {
eb9 :
# ifdef COWARD
								rs = EBINDAT ;	/* binary data ...	*/
								goto eov ;
# else  /* ! COWARD */
								VUEBUF [foldx] = VWEIRDB ;
# endif /* COWARD */
							}

							if (*(lp+x) == '\n') {
# ifdef		FOLDEM
ml9 :
								if (((x+1)+vy) == vmaxlin)
									topg = y ;

								VUEBUF [foldx] = '\0' ;
								linptr[y++] = & VUEBUF [foldx+1] ;

								if (foldk > FOLDLIM) {
									VUEBUF [foldx+1] = *(lp+x) ; ++foldx ;
									foldk = 1 ;
								} else {
									foldk = 0 ;
								}
# else		/* LETHEM */
								if (((x+1)+vy) == vmaxlin) {
									topg = y ;
								}

								*(lp+x) = '\0' ;
								linptr[y++] = lp+(x+1) ;
# endif		/* FOLDEM */
							}

							if (y == VMAXLIN) {
								break ;
							}
# ifdef		FOLDEM
							++foldx ;
# endif		/* FOLDEM */
						}

						vmaxlin = y - 1 ;
# ifdef VUETRC
gotoxy (1,21) ;
cprintf("bs%5ldbr%5ldba%6ldby%6ldfs%7ldml%5dtp%5dln%5dbo%5d xo %ld",vbufsiz,byrd,balr,byet,filsiz,vmaxlin,topg,blino,byon,xofs);
# endif /* VUETRC */
						if (topg < 0) {
# ifdef COMMENT
							if (trixerr("ieav0003",NOSTR,NOWHY,BANAL)==ESC)
                                goto eov ;
# endif /* COMMENT */
							goto rehom ;
						}

						while (y < VMAXLIN)
							linptr[y++] = (char *) 0 ;

						byon = (int) (linptr[topg]-lp) ;
   						topg -= vpaghei ; /* fit ! */
                        topg += stopg ;

						if (topg < 0) {
                            topg = 0 ;
						}
    				}
                }

			break ;

			default : goto aw ;
		}
	}
vkk :
	rs = -1 ;
eov :
# ifdef		FOLDEM
	if (foldbuf != (char *) 0)
		free (foldbuf) ;
# endif		/* FOLDEM */
	if (filebuf != (char *) 0)
		free (filebuf) ;
	if (vlinbuf != (char *) 0)
		free (vlinbuf) ;
	if (linptr != (char * *) 0)
		free ( (char *) linptr ) ;
	if (fp != (FILE *) 0)
		fclose (fp) ;
	return rs  ;

} /* endof trixvue() */

/*
 *											|~~~~~~~~~~~~~~~~~~~~~~~|
 *											|	retouch makeup ...	|
 *											|_______________________|
 */

void avufac () {
	char tb [20] ;
	char xb [256] ;
	int  x ;

	for ( x = 0 ; x < _vdocols ; ++x )
		xb[x] = HORZBAR ;

	xb[_vdocols] = '\0' ;

	dispat ( _vdolins-4 , 0 , xb, _vdocols , VEAGCS ) ;

	flexfram (vuefram) ;
	dispat (LINNAME, COLNAME, vnam, WIDNAME, VENORM) ;
	flipcmb ('v') ; flipfmb ('v') ;
	frescrn (CMNUBAR|FMNUBAR, NODID, NOFID) ;

	if (vtofs > 0) {
		sprintf (tb, "+%d", vtofs+1) ;
	} else {
		strcpy (tb, "      ") ;
	}
	dispat (LINTOFS, COLTOFS, tb, LENTOFS, VENORM) ;
}

/*====================================================================*/

/*
 * vi:nu tabstop=4
 */
