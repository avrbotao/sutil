/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixtext.c + customizable text file management ...  |
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include	<stdio.h>
# include	<ctype.h>
# include	<string.h>

# include	"trix.h"
# include	"trixstd.h"
# include	"trixfunc.h"
# include	"trixtext.h"
# include	"trixext.h"

# undef		DBG

char * trixtxt [MAXTXT] = { SWID } ;
char * tferm = "Trix : Erro no arquivo de textos !\n" ;

# ifdef		ANSI
void initxt (void) ;
# else		/* OLD STYLE */
void initxt ( ) ;
# endif		/* ANSI */

void initxt () {
	char * txtfil = "trixtext.dat" ;
	FILE * tfp ;
	char tebuf [TEBSIZ] , txbuf [TEBSIZ] ;
	register char * tep , * txp ;
	register int tix ;

# ifdef XTRC
	fprintf (trcfp, "initxt()\r\n") ;
# endif

	tfp = trixfopen (txtfil, "r") ;

	if (tfp == (FILE *) 0) {
		fprintf (stderr,
			"Trix : Erro ao abrir arquivo de textos (%s) !\n",
			txtfil) ;
		exit (-1) ;
	}
	while (fgets (tebuf, TEBSIZ, tfp) != (char *) 0) {
		tep = tebuf ; txp = txbuf ; tix = 0 ;
		if (*tep == '#' || *tep == '\n' || *tep == '\r')
			continue ;
		while (isspace ((int)(*tep)))
			++tep ;
		if (isdigit ((int)(*tep)))
			while (isdigit ((int)(*tep)))
				tix = ( tix * 10 ) + ( *tep++ - '0' ) ;
		else {
			fprintf (stderr, "%s", tferm) ;
			fprintf (stderr, "-----> texto sem codigo numerico ...\n") ;
			fputs (tebuf, stderr) ; continue ;
		}
        if (tix < 1 || tix >= MAXTXT) {
			fprintf (stderr, "%s", tferm) ;
			fprintf (stderr, "-----> codigo < 1 ou >= %d ...\n", MAXTXT) ;
			fputs (tebuf, stderr) ; continue ;
		}
		while (isspace ((int)(*tep)))
			++tep ;
		if (*tep == '"') {
			while (*++tep != '"') {
				if (*tep == '\0' || *tep == '\n' || *tep == '\r') {
					fprintf (stderr, "%s", tferm) ;
					fprintf (stderr, "%s", "-----> texto sem \"fecha-aspas\" ...\n") ;
					fputs (tebuf, stderr) ; continue ;
				}
				if (*tep == '\\') {
						switch (*++tep) {
							case '"'  :
							case '\\' : *txp++ = *tep ; break ;
						}
				} else
					*txp++ = *tep ;
			}
		} else {
			while (*tep != '\n' && *tep != '\0' && *tep != '\r') {
				if (*tep == '\\') {
						switch (*++tep) {
							case '"'  :
							case '\\' : *txp++ = *tep ; break ;
						}
				} else
					*txp++ = *tep ;
				++tep ;
			}
		}
		*txp++ = '\0' ;
		txp = malloc ( (int) (txp - txbuf) ) ;
		if (txp == (char *) 0) {
			fprintf (stderr, "%s", "Trix : Memoria insuficiente para textos !\n") ;
			exit (-1) ;
		}
		if (trixtxt[tix] != (char *) 0) {
			fprintf (stderr, "Trix : Texto # %d redefinido ...\n", tix) ;
			free (trixtxt[tix]) ;
		}
		strcpy (txp, txbuf) ; trixtxt[tix] = txp ;
	}
	fclose (tfp) ;
}
/*------------------------------------------------------------------*/
/*
 * vi:nu tabstop=4
 */
