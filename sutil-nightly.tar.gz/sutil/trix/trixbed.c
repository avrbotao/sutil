
/*                	 _______________________________________________
 *  ______________	|												|
 * /\  ___________\	|	TRIX + file system administration utility	|
 * \ \ \________  /	|_______________________________________________|
 *  \ \ \    / / /	|                                               |
 *   \ \ \  / / /	|	trixbed.c + binary (hex & ascii) editor		|
 *    \ \ \/ / /	|_______________________________________________|
 *     \ \/ / /		|												|
 *		\  / /		|	TRIX & its logo are registered trademarks	|
 *		 \/_/		|	of Alexandre Victor Rodrigues Botao (1991)	|
 *					|_______________________________________________|
 */

# include 	<stdio.h>
# include	<ctype.h>
# include	<fcntl.h>

# ifdef DOS
#	include	<sys/types.h>
#	include	<sys/stat.h>
#	include <io.h>
#	include <conio.h>
#	include <stdlib.h>
#	include <string.h>
# else  /* ANYX */
#	include		<memory.h>
#   include		<unistd.h>
#  ifndef	CYGWIN
#	define   O_BINARY     0x00
#  endif	/* ! CYGWIN */
# endif /* DOS */

# include	"trix.h"
# include	"trixfunc.h"
# include	"trixkeys.h"
# include	"trixasci.h"
# include	"trixblue.h"
# include	"trixtext.h"
# include	"trixchrs.h"
# include	"trixvdo.h"
# include	"trixext.h"
# include	"trixwind.h"

/* typedef  struct stat  STAT  ; */

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	local function prototypes ...	|
 *	|___________________________________|
 */

# ifdef ANSI

void	bedit		(void)  ;
void	bedface		(void)  ;
void	savblk		(void)  ;
void	restaura	(void)  ;
void	savedblk	(void)  ;
void	unsavedblk	(void)  ;
void	go_home		(char)  ;
void	lin_prox	(void)  ;
void	lin_ant		(void)  ;
void	col_prox	(char)  ;
void	col_ant		(char)  ;
void	flexfram	(char * *) ;
void	sidetop		(void) ;

int		dispart		(void)  ;
int		getblock	(int)  ;
int		cntbyts		(long)  ;
int		prefind		(char)  ;
int		procura		(char *)  ;
int		nextpart	(void)  ;
int		prevpart	(void)  ;
int		onde_parte	(void)  ;
int		bytsblk		(void)  ;
int		stodec		(char *, int *) ;
int		ignchgs		(void) ;

char	tr_hexa		(char)  ;
char	tr_asc		(char)  ;
char	go_hexa		(void)  ;
char	go_asc		(void)  ;

# else  /* OLD STYLE */

char		tr_hexa () ;
char		tr_asc () ;
char		go_hexa () ;
char		go_asc () ;
int			nextpart () ;
int			prevpart () ;
int			prefind () ;
int			procura () ;
int			getblock () ;
int			dispart () ;
int			cntbyts () ;
int			bytsblk () ;
int			onde_parte () ;
int			stodec () ;
int		ignchgs		() ;
void		bedit () ;
void	    bedface		()  ;
void	    savblk		()  ;
void	    restaura	()  ;
void	    savedblk	()  ;
void	    unsavedblk	()  ;
void	    go_home		()  ;
void	    lin_prox	()  ;
void	    lin_ant		()  ;
void	    col_prox	()  ;
void	    col_ant		()  ;
void		flexfram () ;
void		sidetop () ;

# endif /* ANSI */

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	^C , PgUp	: avanga pagina									|
 *	|	^R ,		: retrocede pagina                          	|
 *	|	^X ,		: avanga o cursor uma linha             	    |
 *	|	^E ,		: retrocede o cursor uma linha             		|
 *	|	^D ,		: avanga o cursor uma coluna                	|
 *	|	^S ,		: retrocede o cursor uma coluna             	|
 *	|	^A , TAB	: edita em ASCII                            	|
 *	|	^H , TAB	: edita em hexadecimal                      	|
 *	|	^T ,		: posiciona o cursor em "home"             	 	|
 *	|	^W ,		: salva o bloco editado                     	|
 *	|	^Q ,		: encerra                                  		|
 *	|	^F ,		: procura uma string dentro do arquivo      	|
 *	|	^L ,		: repete a busca                            	|
 *	|	^I ,		: lista Comandos                            	|
 *	|	^B ,		: posiciona no princmpio do arquivo         	|
 *	|	^G ,		: posiciona no fim do arquivo               	|
 *	|	^U ,		: reimprime a tela                          	|
 *	|_______________________________________________________________|
 */

# define		CTLA		0x01
# define		CTLB		0x02
# define		CTLC		0x03
# define		CTLD		0x04
# define		CTLE		0x05
# define		CTLF		0x06
# define		CTLG		0x07
# define		CTLH		0x08
# define		CTLI		0x09
# define		CTLL		0x0C
# define		CTLN		0x0E
# define		CTLQ		0x11
# define		CTLR		0x12
# define		CTLS		0x13
# define		CTLT		0x14
# define		CTLU		0x15
# define		CTLV		0x16
# define		CTLW		0x17
# define		CTLX		0x18
# define		ESC 		0x1b

/*
 *		|~~~~~~~~~~~~~~~~~~~|
 *		|	definitions		|
 *		|___________________|
 */

# define		LININI		4	/* Linha inicial de dados */
# define		COLEND		1	/* Coluna do deslocamento relativo */
# define		COLHEX		12	/* Coluna inicial da parte hexa */
# define		COLASC		62	/* Coluna inicial da parte ascii */
# define		LINBASE		0
# define		COLBASE		68
# define		LINBYNO		1
# define		COLBYNO		68
# define		LINBLOK		2
# define		COLBLOK		68
# define		LINNAME		0
# define		COLNAME		COLHEX
# define		WIDNAME		47
# define		LINHOW		1
# define		COLHOW		COLHEX

# define		RCOK	 0
# define		ERRO	-1

# define		READ		0
# define		WRITE		1
# define		RDWR		2

# ifndef		L_SET
# define		L_SET		0
# endif

# define		TAMBLK		512
# define		TAMPAR		256
# define		TAMAREA		TAMBLK /* * 2 */

# define		CR		0x0D
# define		BS		0x08

# define		BED_MODE	(O_RDWR|O_EXCL|O_BINARY)

/*
 *		|~~~~~~~~~~~~~~~|
 *		|	macros ...	|
 *		|_______________|
 */

# define		PALTA(x)	(short)(x >> 8)
# define		PBAIXA(x)	(unsigned short)(x & 0x00ff)
# define		CARAC(c)	(unsigned char)(((c < 0x20) || (c > 0x7e)) ? '.' : c)
# define		termxy(C,L)	locat (L, C)

/*
 *		|~~~~~~~~~~~~~~~~~~~|
 *		|	globals ...		|
 *		|___________________|
 */
	char	bedpat [40] ;
	int		bloted = FALSE ;
	long	bedsize ;

FIX	char	*arq ;
FIX	char	*area,
			*bedbuf ;
FIX	char	fim ;
FIX	int		lin,
			col ;
FIX	long	bedblk ;
FIX int		robed,
			ascvuok,
			parte ;
FIX	int		fd ;
FIX	struct STAT	stabed ;
FIX	int		numbase = 10 ;
FIX	int		hexa = TRUE ;
FIX	int		gkey,
			brd = 0 ;

EXT	char *	ghyid ;
EXT int		bedvue ;

# ifdef ANYX

EXT char    altgcs [] ;
EXT char *  clbuf ;

# endif /* ANYX */

/*------------------------------------------------------------------*/

char * bedfram [] = {
    "'-",
	"'g'p4,1's7'=78's-'s9'p4,11's8'p4,61's8",
	"'p5,1's|'p5,11's|'p5,61's|'p5,80's|",
	"'p6,1's|'p6,11's|'p6,61's|'p6,80's|",
	"'p7,1's|'p7,11's|'p7,61's|'p7,80's|",
	"'p8,1's|'p8,11's|'p8,61's|'p8,80's|",
	"'p9,1's|'p9,11's|'p9,61's|'p9,80's|",
	"'p10,1's|'p10,11's|'p10,61's|'p10,80's|",
	"'p11,1's|'p11,11's|'p11,61's|'p11,80's|",
	"'p12,1's|'p12,11's|'p12,61's|'p12,80's|",
	"'p13,1's|'p13,11's|'p13,61's|'p13,80's|",
	"'p14,1's|'p14,11's|'p14,61's|'p14,80's|",
	"'p15,1's|'p15,11's|'p15,61's|'p15,80's|",
	"'p16,1's|'p16,11's|'p16,61's|'p16,80's|",
	"'p17,1's|'p17,11's|'p17,61's|'p17,80's|",
	"'p18,1's|'p18,11's|'p18,61's|'p18,80's|",
	"'p19,1's|'p19,11's|'p19,61's|'p19,80's|",
	"'p20,1's|'p20,11's|'p20,61's|'p20,80's|",
	"'p21,1's1'=78's-'s3'p21,11's2'p21,61's2",
	"'p1,63'nBase:'p3,3Posicao +'p3,63Setor:",
	"'p1,3Arquivo :'p2,3Estado  : Intacto'p2,63Byte:",
	(char *) 0
} ;

/*
 *												|~~~~~~~~~~~~~~~~~~~|
 *												|	bit processor	|
 *												|___________________|
 */

int trixebit (ffp) FILDAT * ffp ; {

	bedblk = parte = 0 ;
	arq = ffp->fd_path ;
	bloted = FALSE ;
	memset (bedpat, '\0', 40) ;

# ifdef ANYX

	if (access (arq, R_OK) < 0) {
		trixerr (T_ACCESS, arq, errno, BANAL) ;
		return -1 ;
	}

	if (access (arq, W_OK) < 0) {
	/*	trixerr (T_ROFILE, arq, errno, BANAL) ;	*/
		robed = TRUE ;
	} else
		robed = FALSE ;

# else  /* DOS */

	robed = FALSE ;

# endif /* ANYX */

	if (bedvue)
		robed = TRUE ;

	if (STAT (arq, &stabed) == ERRO) {
		trixerr (T_NOINFO, arq, errno, BANAL) ;
		return -1 ;
	}

	bedsize = stabed.st_size ;
 
	if (bedsize <= 0L) {
		bedsize = 4 * 1024 * 1024 ; /* PROVISORY ! ! ! */
		ascvuok = FALSE ;
	} else {
		ascvuok = TRUE ;
	}

	if ((fd = open (arq, BED_MODE)) == ERRO) {
		trixerr (T_ACCESS, arq, errno, BANAL) ;
		return -1 ;
	}

	if ((area = (char *) calloc (TAMAREA, sizeof (char))) == NOSTR) {
		trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
		return -1 ;
	}

/*	memset (area, 0, TAMAREA) ;	*/

	if (getblock (0) == ERRO) {
		close (fd) ;
		return -1 ;
	}

	bedface () ;
	dispart () ;

	fim = 0 ;
	bedpat[0] ='\0' ;

	do {
		bedit () ;
	} while (!fim) ;

	free (area) ;
	close (fd) ;
	return brd ;

}	/* endof trixebit */

/*
 *												|~~~~~~~~~~~~~~~~~~~|
 *												|	seek 2 sector	|
 *												|___________________|
 */

int getblock (fator) int fator ; {

	long	desl ;
	int		grd  ;

	desl = ( bedblk + fator ) * TAMBLK ;

	if (bedsize > 0L) {
		if ((desl < 0L) || (desl >= bedsize)) {
			return (ERRO) ;
		}
	} else {
		if ((desl < 0) || ((desl > 0L) && (desl >= bedsize))) {
		/*	trixerr (T_SEEKERR, arq, NOWHY, BANAL) ;	*/
			return (ERRO) ;
		}
	}

	if (lseek (fd, desl, 0 /* SEEK_SET */) == ERRO) {
		trixerr (T_SEEKERR, arq, errno, BANAL) ;
		return (ERRO) ;
	}

	bedbuf = area ;

	grd = read (fd, bedbuf, TAMBLK) ;

	if (grd < 0) {
		trixerr (T_READERR, arq, errno, BANAL) ;
		return (ERRO)  ;
	}

	return (RCOK) ;
}
/*
 *										|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *										|	retouch makeup ...		|
 *										|___________________________|
 */
void bedface () {
    char tb [4] ;

	CLRSCR ;
	flexfram (bedfram) ;
	dispat (LINNAME, COLNAME, arq, WIDNAME, VENORM) ;
	sprintf (tb, "%2d", numbase) ;
	dispat (LINBASE, COLBASE, tb, 2, VENORM) ;
	sidetop () ;
	flipcmb ('b') ;

	if (bedvue)
		flipfmb ('h') ;
	else
		flipfmb ('b') ;

	frescrn (CMNUBAR|FMNUBAR, NODID, NOFID) ;
}
/*
 *										|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *										|	side & top guidelines   |
 *										|___________________________|
 */
void sidetop () {

	REG int x, j ;
    REG char * tp ;
	REG char * pfp ;
        char tb [80] ;

	if (numbase == 16)
		pfp = "%02x " ;
	else
		pfp = "%2d " ;

	for ( x = 0 , tp = tb ; x < 16 ; ++x , tp += 3 ) {
		sprintf (tp, pfp, x) ;
	}

    dispat (2, 12, tb, (int) (tp-tb), VENORM) ;

	if (numbase == 16)
		pfp = "     +%02x" ;
	else
		pfp = "    +%3d" ;

	for ( j = 1 , x = 16 ; j < 16 ; ++j , x += 16 ) {
		sprintf (tb, pfp, x) ;
		dispat (LININI+j, COLEND, tb, 8, VENORM) ;
	}
}
/*
 *											|~~~~~~~~~~~~~~~~~~~~~~~|
 *											|	disp half sect ...	|
 *											|_______________________|
 */
int dispart () {

    char    tb [80] , sb [4] ;
	long	endr ;
	int	qtby ;
	int	i, j ;
    REG char * tp ;
	REG char * pfp  ;

	endr = bedblk * TAMBLK + parte * TAMPAR ;

	if ((qtby = cntbyts (endr)) == ERRO)
		return (ERRO) ;

	if (numbase == 16)
		pfp = "  %08lx" ;
	else
		pfp = "%-10ld" ;

	sprintf (tb, pfp, bedblk) ;
	dispat (LINBLOK, COLBLOK, tb, 10, VENORM) ;

	lin = LININI ;
    sb [0] = sb [1] = sb [2] = ' ' /* C_GSPC */ ; sb [3] = '\0' ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	disp sector offset ...	|
 *	|___________________________|
 */
	if (numbase == 16)
		pfp = "%8lx" ;
	else
		pfp = "%8ld" ;

	sprintf (tb, pfp, endr) ;
	dispat (lin, COLEND, tb, 8, VENORM) ;

	for (i = 0 ; i < qtby ; i += 16) {
		endr += 16 ;
/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	disp hex view ...	|
 *		|_______________________|
 */
		j = 0 ; tp = tb ;

		do {

			sprintf (tp, "%02x ", (unsigned char)*(bedbuf + i + j)) ;
			j++ ; tp += 3 ;
# ifdef AIX
			if ((j < 16) && (i + j < qtby))
				continue ;
			else
				break ;
		} while (1) ;
# else  /* ! AIX */
		} while ((j < 16) && (i + j < qtby)) ;
# endif /* AIX */

		for (  ; j < 16 ; j++ , tp += 3 )
			strcpy (tp, sb) ;

        dispat (lin, COLHEX, tb, (int) (tp-tb), VENORM) ;
/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	disp ascii view ...	|
 *		|_______________________|
 */
		j = 0 ; tp = tb ;

		do {
			char	c ;

			c = *(bedbuf + i + j) ;
			*tp++ = (CARAC (c)) ;
			j++ ;
		} while ((j < 16) && (i + j < qtby)) ;

		for (  ; j < 16 ; j++)
			*tp++ = ' ' /* C_GSPC */ ;

        *tp = '\0' ;
		dispat (lin++, COLASC, tb, 16, VENORM) ;
	}

    memset (tb, ' ' /* C_GSPC */, 50) ;

	for ( j = (i / 16) ; j < 16 ; j++, lin++ ) {
		dispat (lin, 12, tb, 47, VENORM) ;
		dispat (lin, 62, tb, 16, VENORM) ;
	}

	lin = LININI ;
	if (hexa)
		col = COLHEX ;
	else
		col = COLASC ;

/*	termxy (col, lin) ; */
	return (RCOK) ;
}
/*
 *											|~~~~~~~~~~~~~~~~~~~~~~~|
 *											|	interface loop ...	|
 *											|_______________________|
 */
void bedit () {

	register int i, x, p, key, xcol, hocol, volin ;
	int		pos ;
	long	salvblk ;
	int		salvpar ;
	char		c, xc ;
	char		*salvbuf ;
	char * pfp ;
	long	endr, byno ;
	char	tb [80] ;

	endr = bedblk * TAMBLK + parte * TAMPAR ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	highlight counter view ...	|
 *	|_______________________________|
 */
	p = onde_parte () ; x = p % 16 ;
	hocol = COLHEX + x * 3 ; volin = LININI + (p / 16) ;
	byno = endr + ((p / 16) * 16) + x ;

	if (numbase == 16)
		pfp = "  %08lx" ;
	else
		pfp = "%-10ld" ;

	sprintf (tb, pfp, byno) ;
	dispat (LINBYNO, COLBYNO, tb, 10, VENORM) ;

	/* - - - - - - - - - - - - - - - - - - - - - */

	if (hexa) {
		xcol = COLASC + x ;
		xc = CARAC(*bedbuf) ;
		sprintf (tb, "%c", xc) ;
        dispat (lin, xcol, tb, 1, VEHILT) ;
	} else {
		xcol = COLHEX + x * 3 ;
		xc = *bedbuf ;
		sprintf (tb, "%02x", (unsigned char)xc) ;
        dispat (lin, xcol, tb, 2, VEHILT) ;
	}

	/* - - - - - - - - - - - - - - - - - - - - - */

	if (numbase == 16) {
		sprintf (tb, "%02x", x) ;
	} else {
		sprintf (tb, "%2d", x) ;
	}

    dispat (2, hocol, tb, 2, VEHILT) ;

	/* - - - - - - - - - - - - - - - - - - - - - */

	i = (p / 16) * 16 ;

	if ( i == 0 ) {
		if (numbase == 16)
			pfp = "%8lx" ;
		else
			pfp = "%8ld" ;
		sprintf (tb, pfp, endr) ;
	} else {
		if (numbase == 16)
			pfp = "     +%02x" ;
		else
			pfp = "    +%3d" ;
		sprintf (tb, pfp, i) ;
	}

    dispat (volin, COLEND, tb, 8, VEHILT) ;

	/* - - - - - - - - - - - - - - - - - - - - - */

	if (hexa) {
		xc = *bedbuf ;
		sprintf (tb, "%02x", (unsigned char)xc) ;
        dispat (lin, col, tb, 2, VEREVS/*RVBL*/) ;
	} else {
		xc = CARAC(*bedbuf) ;
		sprintf (tb, "%c", xc) ;
        dispat (lin, col, tb, 1, VEREVS/*RVBL*/) ;
	}

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	get keystroke ...	|
 *	|_______________________|
 */

/*	termxy (col, lin) ; */
	key = getkey () ;
	c = (char) key ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	un-highlight counter view ...	|
 *	|___________________________________|
 */
	if (! (hexa && ((key > 0x1f) && (key < 0x7e)))) {

    	if (hexa) {
    		xc = CARAC(*bedbuf) ;
    		sprintf (tb, "%c", xc) ;
            dispat (lin, xcol, tb, 1, VENORM) ;
	    } else {
		    xc = *bedbuf ;
	    	sprintf (tb, "%02x", (unsigned char)xc) ;
            dispat (lin, xcol, tb, 2, VENORM) ;
    	}

		/* - - - - - - - - - - - - - - - - - - - - - - - - */

    	if (numbase == 16) {
	    	sprintf (tb, "%02x", x) ;
    	} else {
		    sprintf (tb, "%2d", x) ;
    	}

        dispat (2, hocol, tb, 2, VENORM) ;

		/* - - - - - - - - - - - - - - - - - - - - - - - - */

    	if ( i == 0 ) {
	    	if (numbase == 16)
		    	pfp = "%8lx" ;
		    else
			    pfp = "%8ld" ;
    		sprintf (tb, pfp, endr) ;
	    } else {
		    if (numbase == 16)
			    pfp = "     +%02x" ;
	    	else
		    	pfp = "    +%3d" ;
		    sprintf (tb, pfp, i) ;
    	}

        dispat (volin, COLEND, tb, 8, VENORM) ;

		/* - - - - - - - - - - - - - - - - - - - - - - - - */

    	if (hexa) {
	    	xc = *bedbuf ;
		    sprintf (tb, "%02x", (unsigned char)xc) ;
            dispat (lin, col, tb, 2, VENORM) ;
	    } else {
		    xc = CARAC(*bedbuf) ;
		    sprintf (tb, "%c", xc) ;
            dispat (lin, col, tb, 1, VENORM) ;
    	}

		/* - - - - - - - - - - - - - - - - - - - - - */

/*		termxy (col, lin) ;     */
	}
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	reflect modification ...	|
 *	|_______________________________|
 */
	if ((key > 0x1f) && (key < 0x7e))
	{
		if (hexa) {

			bloted = tr_hexa (c) ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - */

        	if (numbase == 16) {
	        	sprintf (tb, "%02x", x) ;
    	    } else {
		        sprintf (tb, "%2d", x) ;
    	    }

            dispat (2, hocol, tb, 2, VENORM) ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - */

        	if ( i == 0 ) {
	        	if (numbase == 16)
		        	pfp = "%8lx" ;
		        else
			        pfp = "%8ld" ;
        		sprintf (tb, pfp, endr) ;
	        } else {
		        if (numbase == 16)
			        pfp = "     +%02x" ;
	    	    else
		    	    pfp = "    +%3d" ;
    		    sprintf (tb, pfp, i) ;
        	}

            dispat (volin, COLEND, tb, 8, VENORM) ;

		} else
			bloted = tr_asc (c) ;

		if (bloted)
			unsavedblk () ;

		return ;
	}
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	process command ...		|
 *	|___________________________|
 */
	switch (key)
	{
		case KF3 :
		case CTLN : /* xg number base */
			if (numbase == 10)
				numbase = 16 ;
			else
				numbase = 10 ;

        	sprintf (tb, "%2d", numbase) ;
	        dispat (LINBASE, COLBASE, tb, 2, VENORM) ;
			sidetop () ;

        	if (numbase == 16)
				pfp = "  %08lx" ;
	        else
				pfp = "%-10ld" ;

        	sprintf (tb, pfp, bedblk) ;
	        dispat (LINBLOK, COLBLOK, tb, 10, VENORM) ;

			if (volin > LININI) {
				if (numbase == 16)
					pfp = "%8lx" ;
				else
					pfp = "%8ld" ;

				sprintf (tb, pfp, endr) ;
				dispat (LININI, COLEND, tb, 8, VENORM) ;
			}

			if (bloted)
				unsavedblk () ;

/*			termxy (col, lin) ;     */
		break ;

		case CTLI :
			if (hexa)
				hexa = go_asc () ;
			else
				hexa = go_hexa () ;
		break ;

		case CTLA :
			hexa = go_asc () ;
		break ;

		case CTLH :
			hexa = go_hexa () ;
		break ;

		case CTLT :
			go_home (hexa) ;
		break ;

		case KHOME :
		case CTLB :
			if (!bedblk && !parte)
				break ;
			if (bloted) {
				if (ignchgs () == FALSE)
					break ;
			}
			bedblk = 0 ;
			parte = 0 ;
			getblock (0) ;
			dispart () ;
		break ;

		case KEND :
		case CTLG :
			if (bloted) {
				if (ignchgs () == FALSE)
					break ;
			}
			while (getblock (1) != ERRO)
			{
				bedblk++ ;
				parte = 0 ;
			}
			if (nextpart () == ERRO)
				dispart () ;
			else
				parte = 1 ;
		break ;

		case KDOWN :
		case CTLX :
			lin_prox () ;
		break ;

		case KUP :
		case CTLE :
			lin_ant () ;
		break ;

		case KRIGHT :
		case CTLD :
			col_prox (hexa) ;
		break ;

		case KLEFT :
		case CTLS :
			col_ant (hexa) ;
		break ;

		case KPGDN :
		case CTLC :
			if (bloted && parte == 1) {
				if (ignchgs () == FALSE)
					break ;
			}
			if (nextpart () != ERRO) {
				if (parte) {
					if (bloted)
						unsavedblk () ;
				} else {
					bloted = FALSE ;
				}
			}
		break ;

		case KPGUP :
		case CTLR :
			if (bloted && bedblk > 0 && parte == 0) {
				if (ignchgs () == FALSE)
					break ;
			}
			if (prevpart () != ERRO) {
				if (!parte) {
					if (bloted)
						unsavedblk () ;
				} else {
					bloted = FALSE ;
				}
			}
		break ;

		case KF4  :
		case CTLF :
		case KF5  :
		case CTLL :

			if (key == KF4) {
				key = c = gkey = CTLF ;
			} else if (key == KF5) {
				key = c = gkey = CTLL ;
			}

			if (bloted) {
				if (ignchgs () == FALSE)
					break ;
			}

			salvblk = bedblk ;
			salvpar = parte ;
			salvbuf = bedbuf ;
# ifdef COMMENT
			if (key == CTLL)
				col_prox (hexa) ;
# endif /* COMMENT */
			pos = prefind (c) ;

			if (pos != ERRO) {

				if ((salvblk != bedblk) || (salvpar != parte))
					dispart () ;

				if (hexa)
					col = COLHEX + (pos % 16) * 3 ;
				else
					col = COLASC + (pos % 16) ;

				lin = LININI + (pos / 16) ;
				bedbuf += pos ;
				bloted = FALSE ;

			} else {

				bedblk = salvblk ;
				parte = salvpar ;
				getblock (0) ;
				bedbuf = salvbuf ;
			}
			termxy (col, lin) ;
# ifdef COMMENT
			if (key == CTLL && pos == ERRO)
				col_ant (hexa) ;
# endif /* COMMENT */
		break ;

		case KF2 :
		case CTLW :
					if (bloted) {
						if (robed && ! bedvue) {
							honk () ;
							sprintf (tb, T_CANTSAV, arq) ;
							askok (tb, T_ROFILE) ;
						} else {
							savblk () ;
							bloted = FALSE ;
							savedblk () ;
						}
					}
		break ;

		case CTLQ :
        case ESC :
			if (bloted) {
				if (ignchgs () == FALSE)
					break ;
			}
			fim = 1 ; brd = 0 ;
		break ;

		case CTLU :
			restaura () ;
			if (bloted)
				unsavedblk () ;
			termxy (col, lin) ;
		break ;

		case KF1 : hyxhelp ("Editor Binario") ; break ;

		case KF8 :
					switfram () ;
					flexfram (bedfram) ;
		break ;

		case CTLV :
		case KF9 :
					if (bedvue && ascvuok) {
						fim = 1 ; brd = 'a' ;
					}
		break ;

		default : honk () ;
	}
}

/*
 *		Salva o bloco editado em disco
 */

void savblk ()
{
	long	desl ;
	int	nb, aux ;

	desl = bedblk * TAMBLK ;

	lseek (fd, desl, L_SET) ;

	nb = cntbyts (desl) ;

	desl += TAMPAR ;

	if ((aux = cntbyts (desl)) != ERRO)
		nb += aux ;

	gwrd = write (fd, area, nb) ;
}

/*
 *	Restaura a tela
 */

void restaura () {

	bedbuf = area + parte * TAMPAR ;
	bedface () ;
	dispart () ;
}

/*
 *	Trata entrada de caracter na area Hexa
 */

char tr_hexa (c) char c ; {

	char	num[3] ;
    char tb [80] ;
	int	cola , key2 ;

	if (isxdigit ((int)c)) {
		num[0] = c ; c = (char)toupper((int)c) ;

		tb [0] = c ; tb [1] = '\0' ;
        dispat (lin, col, tb, 1, VENORM) ;

		termxy (col + 1, lin) ;
		key2 = getkey () ;

		if (key2 >= ' ' && key2 <= '~')
			num[1] = (char) key2 ;
		else
			goto bk ;

		if (isxdigit ((int)num[1])) {
			c = (char)toupper((int)num[1]) ;

    		tb [0] = c ; tb [1] = '\0' ;
            dispat (lin, col+1, tb, 1, VENORM) ;

			num[2] = '\0' ;
			*bedbuf = (char)(strtol (num, (char **)0, 16)) ;
			cola = COLASC + (onde_parte () % 16) ;
			c = CARAC(*bedbuf) ;

    		tb [0] = c ; tb [1] = '\0' ;
            dispat (lin, cola, tb, 1, VENORM) ;

			col_prox (TRUE) ;
			return (TRUE) ;

		} else {

bk :		honk () ;
			sprintf (tb, "%02x", (unsigned char)*bedbuf) ;
            dispat (lin, col, tb, 2, VENORM) ;
		/*	termxy (col, lin) ; */
		}
	} else
		honk () ;

	return (FALSE) ;
}

/*
 *	Trata entrada de caracter na area Ascii
 */

char tr_asc (c) char	c ; {

    char tb [80] ;
	int	colh, j ;

	*bedbuf = c ;

	tb [0] = c ; tb [1] = '\0' ;
    dispat (lin, col, tb, 1, VENORM) ;

	j = onde_parte () % 16 ;
	colh = COLHEX + j * 3 ;

	sprintf (tb, "%02x", (unsigned char) c) ;
    dispat (lin, colh, tb, 2, VENORM) ;

	col_prox (FALSE) ;
	return (TRUE) ;
}

/*
 *		Posiciona cursor na area Ascii
 */

char
go_asc ()
{
	/*
	 *	Se ja esta na area ascii, nco faz nada
	 */
	if (col >= COLASC)
	{
		honk () ;
		return (FALSE) ;
	}
	else
	{
		col = COLASC + (onde_parte () % 16) ;
		termxy (col, lin) ;
		return (FALSE) ;
	}
}

/*
 *		Posiciona cursor na area Hexa
 */

char
go_hexa ()
{
	int	j ;

	/*
	 *	Se ja esta na area hexa, nco faz nada
	 */
	if (col < COLASC)
	{
		honk () ;
		return (TRUE) ;
	}

	j = (onde_parte () % 16) ;

	col = COLHEX + j * 3 ;

	termxy (col, lin) ;

	return (TRUE) ;
}

/*
 *		Posiciona cursor em "home"
 */

void go_home (hexa)
char	hexa ;
{
	if (hexa)
		col = COLHEX ;
	else
		col = COLASC ;

	lin = LININI ;

	bedbuf = area + parte * TAMPAR ;

	termxy (col, lin) ;
}

/*
 *		Posiciona na proxima linha
 */

void lin_prox ()
{
	long	endr ;

	endr = bedblk * TAMBLK + parte * TAMPAR ;

	/*
	 *	Se ja esta na zltima linha, vai para a primeira
	 */
	if ((lin == LININI + 15) ||
		(onde_parte () + 16 >= cntbyts (endr))) {
		lin = LININI ;
		bedbuf = area + parte * TAMPAR + (onde_parte () % 16) ;
	} else {
		lin++ ;
		bedbuf += 16 ;
	}

	termxy (col, lin) ;
}

/*
 *		Posiciona na linha anterior
 */

void lin_ant ()
{
	long	endr ;
	int	aux ;

	endr = bedblk * TAMBLK + parte * TAMPAR ;

	/*
	 *	Se ja esta na primeira linha, vai para a zltima
	 */
	if (lin == LININI)
	{
		aux = cntbyts (endr) - 1 ;

		lin = LININI + (aux / 16) ;

		if (aux % 16 != 15)
			if ((onde_parte () % 16) > aux % 16)
			{
				lin-- ;
				endr = ((aux / 16) - 1) * 16 ;
			}
			else
				endr = (aux / 16) * 16 ;
		else
			endr = (aux / 16) * 16 ;

		bedbuf = area + parte * TAMPAR + onde_parte () ;
		bedbuf += (int) endr ;

	}
	else
	{
		lin-- ;
		bedbuf -= 16 ;
	}

	termxy (col, lin) ;
}
/*
 *		Posiciona na proxima coluna
 */
void col_prox (hexa) char hexa ; {
	long	endr ;

	endr = bedblk * TAMBLK + parte * TAMPAR ;

	if (onde_parte () + 2 > cntbyts (endr))
	{
		bedbuf = area + parte * TAMPAR ;
		lin = LININI ;
		col = hexa ? COLHEX : COLASC ;
		termxy (col, lin) ;
		return ;
	}

	if (hexa)
		if (col == COLHEX + 45)
		{
			col = COLHEX ;
			lin++ ;
		}
		else
			col +=3 ;
	else
		if (col == COLASC + 15)
		{
			col = COLASC ;
			lin++ ;
		}
		else
			col++ ;

	bedbuf++ ;

	termxy (col, lin) ;
}
/*
 *		Posiciona na coluna anterior
 */
void col_ant (hexa)
char	hexa ;
{
	long	endr ;
	int	aux ;

	endr = bedblk * TAMBLK + parte * TAMPAR ;

	/*
	 *	Se ja esta no primeiro byte da parte,
	 *		vai para o zltimo
	 */
	if (bedbuf == area + parte * TAMPAR)
	{
		aux = cntbyts (endr) - 1 ;

		lin = LININI + (aux / 16) ;

		if (hexa)
		{
			col = COLHEX ;
			col += ((aux % 16) * 3) ;
		}
		else
			col = COLASC + (aux % 16) ;

		bedbuf = area + parte * TAMPAR + aux ;

		termxy (col, lin) ;

		return ;
	}

	/*
	 *	Em qualquer das areas, se esta na primeira coluna,
	 *		passa para a zltima coluna da linha anterior
	 */
	if (hexa)
		if (col == COLHEX)
		{
			col = COLHEX + 45 ;
			lin-- ;
		}
		else
			col -= 3 ;
	else
		if (col == COLASC)
		{
			col = COLASC + 15 ;
			lin-- ;
		}
		else
			col-- ;

	bedbuf-- ;

	termxy (col, lin) ;
}
/*
 *		Posiciona na proxima parte
 */
int nextpart ()
{
	char	*bufant ;

	if (parte)
		if (getblock (1) != ERRO)
		{
			bedblk++ ;
			parte = 0 ;
			dispart () ;
		}
		else
		{
			honk () ;
			return (ERRO) ;
		}
	else
	{
		parte++ ;
		bufant = bedbuf ;
		bedbuf = area + TAMPAR ;

		if (dispart () == ERRO)
		{
			parte-- ;
			bedbuf = bufant ;
			honk () ;
			return (ERRO) ;
		}
	}

	return (RCOK) ;
}

/*
 *		Posiciona na parte anterior
 */

int prevpart ()
{
	if (parte)
	{
		parte-- ;
		bedbuf = area ;
		dispart () ;
	}
	else
		if (getblock (-1) != ERRO)
		{
			bedblk-- ;
			parte = 1 ;
			bedbuf += TAMPAR ;
			dispart () ;
		}
		else
		{
			honk () ;
			return (ERRO) ;
		}

	return (RCOK) ;
}

/*
 *		Prepara para buscar string no arquivo
 */

int prefind (comando) char comando ; {
	char mb [80] ;
	int	i, grd ;

	i = grd = 0 ;

	if (comando == CTLF) {
		sprintf (mb, "* Pesquisar Texto em \"%s\" ...", arq) ;
		memset (bedpat, '\0', 30) ;

		ghyid = "str" ;
		grd = asktxt (mb, "* Informe o Texto : ", bedpat, 30, 0) ;
		ghyid = NOSTR ;

		if (grd != ENTER)
			return -1 ;

		grd = bedpat[0] ;

		if (grd == '\r' || grd == '\n' || grd == '\0')
			return -1 ;

	} else {
		if (!strlen (bedpat)) {
			honk () ;
			return (ERRO) ;
		}
	}

	if ((i = procura (bedpat)) != ERRO)
		return (i) ;

	trixerr (T_NOTEXT, bedpat, NOWHY, BANAL) ;

	return (ERRO) ;
}

/*
 *		Procura string no arquivo
 */

int procura (string) char	*string  ; {
	REG char	* pos , * salvpos ;
	REG int	xb, nb, aux, c, ts, tam, i, j ;
	REG int once = 1 ;

	c = (int)*string ; ts = strlen (string) ;
	do {
		pos = bedbuf ; nb = bytsblk () ;
		if (gkey == CTLL) {
			if (once++ == 1) {
				++pos ;
			}
		}
		while (nb > 0) {
			bedbuf = pos ; xb = TAMBLK - (int) (bedbuf-area) ;
			pos = memchr (bedbuf, c, /* nb */ xb) ;
			if ( pos != (char *) 0 ) {
				nb -= (int) (pos - bedbuf) + 1 ; j = 0 ;
				tam = ts - 1 ; salvpos = NOSTR ;
				for (i = 1 ; (i < ts) && (nb) ; i++) {
					if (*(string + i) != *(pos + i - j))
						break ;
					nb-- ; tam-- ;
					if (!nb) {
						if (getblock (1) == ERRO)
							return (ERRO) ;
						bedblk++ ; parte = 0 ;
						salvpos = pos ; pos = bedbuf ;
						nb = bytsblk () ; j = i + 1 ;
					}
				}
				if (!tam) {
					if (salvpos != NOSTR) {
						pos = salvpos ; getblock (-1) ;
						bedblk-- ; parte = 1 ;
					}
					parte = (int) (pos - area) / TAMPAR ;
					bedbuf = pos ; aux = onde_parte () ;
					bedbuf = area + parte * TAMPAR ;
					return (aux) ;
				}
				pos += i ; nb-- ;
			} else {
				nb = 0 ;
			}
		}
		bedblk++ ; parte = 0 ;
	} while (getblock (0) != ERRO) ;
	return (ERRO) ;
}
# ifdef COMMENT
/*
 *										|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *										|	prop/y memchr() ...		|
 *										|___________________________|
 */
char * xmemchr (s, c, n) char * s ; {
	REG char * p = s ;
	REG int    x = n ;

	while (x--) {
		if (*p == c)
			return p ;
		++p ;
	}

	return (char *) 0 ;
}
# endif /* COMMENT */

/*
 *		Encontra a posicao dentro do bedbuf
 */

int onde_parte () {
	int	aux ;

# ifdef DOS
	aux = (int)area + parte * TAMPAR ;
	aux = (int)bedbuf - aux ;
# else  /* ANYX */
	aux = (int) (bedbuf - (area + parte * TAMPAR)) ;
# endif /* DOS */

	return (aux) ;
}
/*
 *	Calcula o numero de bytes da parte
 */
int cntbyts (endr) long	endr ; {
	long	nb ;
	int	qtby = 0 ;

	nb = endr + TAMPAR ;

	if (nb > bedsize)
		qtby = (int) ( bedsize - endr )  ;
	else
		qtby = TAMPAR ;

	if (qtby <= 0)
		return (ERRO) ;
	else
		return (qtby) ;
}
/*
 *		Calcula o numero de bytes do bloco
 */
int bytsblk () {
	long	endr ;
	int	nb = 0, aux = 0 ;

	endr = bedblk * TAMBLK ;

	if (!parte)
		nb = cntbyts (endr) ;

	endr += TAMPAR ;

	if ((aux = cntbyts (endr)) != ERRO)
		nb += aux ;

	return (nb) ;
}
/*
 *										|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *										|	tell it's not saved !	|
 *										|___________________________|
 */
void unsavedblk () {

	if (robed) {
		bloted = FALSE ;
	} else {
		dispat (LINHOW, COLHOW, "Modificado", 20, VENORM) ;
		termxy (col, lin) ;
	}
}
/*
 *										|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *										|	tell we saved it ...	|
 *										|___________________________|
 */
void savedblk () {

	dispat (LINHOW, COLHOW, "Gravado", 20, VENORM) ;
	termxy (col, lin) ;
}
/*
 *								|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *								|	warn changes will be lost ...	|
 *								|___________________________________|
 */
int ignchgs () {
	int grd ;

	honk () ;
	grd = askyn ("* ATENCAO ! Este setor foi MODIFICADO ...",
				 "* ABANDONA as alteracoes ? ") ;

	switch (grd) {
		case CTRL_Q :
		case ESC	:
		case NOPE	:
		case ENTER	:	return FALSE ;
		case YEAH	:	return TRUE ;
	}
	return FALSE ;
}

/*==================================================================*/

/*
 * vi:nu tabstop=4
 */
