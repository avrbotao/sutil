
/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixvdo.c + video display adapter interface         |
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include	<stdio.h>

# ifdef DOS
#	include <conio.h>
# endif /* DOS */

# include	<stdlib.h>

# include	"trix.h"
# include	"trixvdo.h"
# include	"trixwig.h"

EXT     int         Tflg ;

int		pageparm = 0 ;

void getscrsiz (linp, colp) int * linp , * colp ; {

# ifdef DOS
					char far * _rowp = MK_FP (0x0040, 0x0084) ;
					int  far * _colp = MK_FP (0x0040, 0x004a) ;
					int _rows, _cols ;

					*linp = _rows = (*_rowp) + 1 ;
					*colp = _cols = (unsigned char) *_colp ;

# else  /* ANYX */

					REG char * tp ;

					if ( ! pageparm ) {
						tp = getenv ("LINES") ;
						if (tp == VZRO(char *))
							*linp = 24 ;
						else
							*linp = atoi (tp) ;
					}

						tp = getenv ("COLUMNS") ;
						if (tp == VZRO(char *))
							*colp = 80 ;
						else
							*colp = atoi (tp) ;

# endif /* DOS */

}

/*
 *      O-------------------------------------------------------O
 *      |   vstat : video status information ...                |
 *      O-------------------------------------------------------O
 *      |   + must perform a serious test w/ a real terminal to |
 *      |     decide the real action when cons_curr < 0 (not to |
 *      |     rtn -1, just set falg's bits 2 reflect we're on a |
 *      |     serial tty instead of a console monitor ...)      |
 *      O-------------------------------------------------------O
 */

int vstat (vfd, vsb, flg) VSTAT * vsb ; int vfd , flg ; {

	int x = -1 , f = 0 ;
    int adapter = -1, curmod = -1, l = 24, c = 80 ;

# ifdef XENIX /* or SCO-UNIX, 386IX, ... */

	extern int maxvdo ;		/* configurable # of video lines	*/

    if (flg & VS_ORIG) {
        ioctl (vfd, VSMODE (vsb->vs_orig), 0) ;
        return 0 ;
    }

    if (Tflg) { /* force term i/o */
    	f |= VS_TERM ;
		getscrsiz (&l, &c) ;
        goto eovs ;
    }

    if ((adapter = ioctl (vfd, CONS_CURRENT, 0)) < 0) {
        l = 24 ; f |= VS_TERM ;
	} else {
        f |= VS_CONS ;

		switch (adapter) {
			case MONO : break ;
			case CGA  : break ;
			case PGA  : break ;
			case EGA  : break ;
			case VGA  : break ;
			default   : return -1 ;
		}
		if ((curmod = ioctl (vfd, CONS_GET, 0)) < 0) {
			return -1 ;
		}
		switch (curmod) {
			case M_B40x25		: break ;
			case M_C40x25		: break ;
			case M_B80x25		: break ;
			case M_C80x25		: break ;
			case M_BG320		: break ;
			case M_CG320		: break ;
			case M_BG640		: break ;
			case M_EGAMONO80x25	: break ;
			case M_CG320_D	    : break ;
			case M_CG640_E  	: break ;
			case M_EGAMONOAPA	: break ;
			case M_CG640x350	: break ;
			case M_ENHMONOAPA2  : break ;
			case M_ENH_CG640	: break ;
			case M_ENH_B40x25	: break ;
			case M_ENH_C40x25	: break ;
			case M_ENH_B80x25	: break ;
			case M_ENH_C80x25	: break ;
			case M_VGA_40x25	: break ;
			case M_VGA_80x25	: break ;
			case M_VGA_M80x25	: break ;
			case M_VGA11		: break ;
			case M_VGA12		: break ;
			case M_VGA13		: break ;
			case M_ENH_B80x43	: maxvdo = 43 ; break ;
			case M_ENH_C80x43	: maxvdo = 43 ; break ;
			case M_HGC_P0		: break ;
			case M_HGC_P1		: break ;
			case M_MCA_MODE		: break ;
			default             : return -1 ;
		}
		if (maxvdo == 43) {
			if ((x = ioctl (vfd, SW_ENHC80x43, 0)) == 0) {
				l = 43 ; x = SW_ENHC80x43 ; f |= VS_4380 ;
			} else
				x = curmod ;
		} else
				x = curmod ;
	}

# else  /* NON-INTEL ANYX, ... */

    if (Tflg) { /* force term i/o */
    	f |= VS_TERM ; l = 24 ;
		getscrsiz (&l, &c) ;
        goto eovs ;
    }

# ifdef DOS

	if (vfd == -2 && flg == -2)
		return -1 ;
/*
 *	+ test if vga, ega, ... is present
 *	+ chk if cfg req > 25 lines
 *	* don't try > 25 w/ tc !
 */

	f |= VS_CONS ;

    if (Tflg) { /* force term i/o */
    	f |= VS_TERM ;
	}

	getscrsiz (&l, &c) ;

# else  /* ANYX */

	f |= VS_TERM ;

	getscrsiz (&l, &c) ;

	vfd = flg ? 1 : 2 ;

	if (vfd < 0) {
		return vfd ;
	}

# endif /* DOS */

# endif /* XENIX */

eovs :
	vsb->vs_lins = _vdolins = l ;
    vsb->vs_cols = _vdocols = c ;
    vsb->vs_adap = adapter ;
    vsb->vs_mode = x ;
    vsb->vs_orig = curmod ;
    vsb->vs_flag = f ;
# ifdef DBG
printf ("\r\nLINES=%d\r\n",_vdolins);
# endif
    return 0 ;
}
/*		O-----------------------------------------------------------O
 *		|	must generalize ! ...									|
 *		O-----------------------------------------------------------O
 */
# ifdef ANYX

# ifdef COMMENT

int getch (void) ;

int getch () {
	char x ;
	struct termio acts, xuts ;

	ioctl (0, TCGETA, &acts) ;
	xuts = acts ;
	acts.c_lflag &= ~ (ICANON | ECHO) ;
	acts.c_iflag &= ~ (ICRNL) ;
	acts.c_cc [ VMIN ] = 1 ;
	ioctl (0, TCSETA, &acts) ;
	read (0, &x, 1) ;
	ioctl (0, TCSETA, &xuts) ;
	return (x & 0xff) ;
}

# endif /* COMMENT */

# ifdef		ANSI
void clrscr (void) ;
void clreol (void) ;
void putch (int) ;
void highvideo (void) ;
void normvideo (void) ;
void textattr (int) ;
# else		/* OLD STYLE */
void clrscr ( ) ;
void clreol ( ) ;
void putch ( ) ;
void highvideo ( ) ;
void normvideo ( ) ;
void textattr ( ) ;
# endif		/* ANSI */

# define  cprintf  printf
# define  cputs    puts

# else  /* DOS */

# endif /* ANYX */

/*----------------------------------------------------------------------*/

# ifdef DOS

void revvideo () {
	textcolor (BLACK) ; textbackground (LIGHTGRAY) ;
}

void undervideo () {
	textattr (0x8f) ;
}

void blinkvideo () {
	textattr (0x87) ;
}

void revblink () {
	textattr (0xf0) ;
}

# else  /* ANYX */

/*						*===========================================*
 *						*	these all below must be termcap'ed !	*
 *						*===========================================*
 */

void clrscr () {
    printf ("\033[2J") ;
}

void clreol () {
    printf ("\033[K") ;
}

void putch (c) int c ; {
	putchar (c) ;
}

void revvideo () {
    printf ("\033[7m") ;
}

void revblink () {
    printf ("\033[5;7m") ;
}

void highvideo () {
    printf ("\033[1m") ;
}

void normvideo () {
	printf ("\033[10m") ;
    printf ("\033[m") ;
}

void undervideo () {
	printf ("\033[4m") ;
}

void blinkvideo () {
	printf ("\033[5m") ;
}

void agcsvideo () {
	printf ("\033[12m") ;
}

void textattr (a) int a ; {
	if (a < 0)
		a = -a ;
}

# endif /* DOS */

/*----------------------------------------------------------------------*/

/*
 * vi:nu tabstop=4
 */
