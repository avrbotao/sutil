# ifdef COMMENT
/*		+-------------------------------------------------------+
 *		|	xg + mini grep ...									|
 *		+-------------------------------------------------------+
 */
# include <stdio.h>

void xgrep (char *, FILE *) ;
int patmat (char *, char *) ;

char * rx ;

void main (argc, argv) char * * argv ; {
	FILE * fp ;

	if (argc < 2) {
		fprintf (stderr, "use: xg expr [files...]\n") ;
		return ;
	}
	rx = *++argv ;
	if (argc == 2)
		xgrep ("stdin", stdin) ;
	else
		while (*++argv)
			if ((fp = fopen (*argv, "r")) == VZRO)
				fprintf (stderr, "xg: can't access %s\n", *argv) ;
			else {
				xgrep (*argv, fp) ; fclose (fp) ;
			}
}

void xgrep (nam, fp) char * nam ; FILE * fp ; {
	char lin [512] ;
	register char * lp ;

	printf ("File %s :\n", nam) ;
	while (fgets (lin, 512, fp) != VZRO)
		for ( lp = lin ; *lp ; ++lp )
			if (patmat (lp, rx)) {
				fputs (lin, stdout) ;
				break ;
			}
}
/*		+-------------------------------------------------------+
 *		|	pattern matching + full blow ...					|
 *		+-------------------------------------------------------+
 */
#undef	DEBUG
int patmat (sp, pp) register char	* sp, * pp ;
{
	register short	sc,	/* Caracter da Cadeia */
			pc;	/* Caracter do Padrao */

	short		found,	/* Encontrou o Char. na lista */
			not;	/* Foi visto um '~' */
#ifdef	DEBUG
	printf ("DBG: str = '%s', pdr = '%s'\n", sp, pp);
#endif	/* DEBUG */
	/*
	 *	O Padrao pode conter '?', '*', '[....]', '~c', '~[....]'.
	 *	O Caracter '\' desfaz a acao especial dos caracteres
	 *	acima. A Comparacao e' do estilo do "sh", mas
	 *	o caracter '/' e' reconhecido por '?' e '*'.
	 *
	 *	Devolve:
	 *	    1 => A Cadeia foi Reconhecida.
	 *	    0 => Nao foi Reconhecida, ou
	 *		 o Padrao contem um erro de Sintaxe.
	 */
	not = 0;
	/*
	 *	Malha Principal de Comparacao.
	 */
	for (/* sem inicializacao */; /* sem teste */; sp++, pp++)
	{
		switch (pc = pp[0])
		{
		    default:
				/*
				 *	O Padrao contem um caracter Normal ...
				 *	( diferente de '?', '*', '[', '~' e '\0' )
				 */
				if (pc == sp[0])
					continue;
				else
					return (0);

		    case '\0':
				/*
				 *	O Padrao Acabou.
				 *	Atualmente implementa um reconhecimento exato
				 *	(ok se a string tambem acabou). idealmente
				 *	deveria retornar TRUE e deixar o teste de
				 *	fim da string p/ o coringa '$' ...
				 */
# define IDEAL
# ifdef IDEAL
				return 1 ;
# else  /* EXACT */
				if (sp[0] == '\0')
					return (1);
				else
					return (0);
# endif /* IDEAL */

		    case '?':
				if (sp[0] == '\0')
					return (0);
				/*
				 *	Simula como se o "coringa" '?' fosse
				 *	igual ao caracter da cadeia.
				 */
				continue;

		    case '*':
				if ((++pp)[0] == '\0')
					return (1);
				/*
				 *	Procura Sufixos em comum.
				 */
				while (sp[0] != '\0')
				{
					if (patmat (sp++, pp))
						return (1);
				}
				return (0);

		    case '\\':
				/*
				 *	Trata o caracter seguinte como normal.
				 */
				pp++;
				if ((pc = pp[0]) == '\0')
					return (0);
				if ((sc = sp[0]) == '\0' || sc != pc)
					return (0);
				continue;

		    case '~':
				pp++;
				if ((pc = pp[0]) == '\0')
					return (0);

				if (pc != '[')
				{
					/*
					 *	Comparacao inversa.
					 */
					if ((sc = sp[0]) == '\0' || sc == pc)
						return (0);
					continue;
				}
				/*
				 *	pp[0] == '['.
				 *	Prepara para [....] inverso.
				 */
				not = 1;

				/* Cai atraves */

		    case '[':
				found = 0;
				if ((sc = sp[0]) == '\0')
					return (0);
				/*
				 *	Analisa a Sequencia '[....]'.
				 */
				while ((pc = (++pp)[0]) != '\0')
				{
					switch (pc)
					{
						default:
						if (pc == sc)
							found = 1;
						continue;

						case '-':
						if (pp[-1] == '[' || pp[1] == ']')
						{
							if (sc == '-')
								found = 1;
						}
						else
						{
							if (pp[-1] <= sc && sc <= pp[1])
								found = 1;
						}
						continue;

						case ']':
						if (found != not)
							goto nextchar;
						else
							return (0);
					}	/* end switch [......] */
				}	/* end while [......] */
		}	/* end switch */
		/*
		 *	A Sequencia [....] terminou inesperadamente,
		 *	ou em todos os casos.
		 */
		return (0);
nextchar:
		not = 0;
	}	/* end malha principal de comparacao */
}	/* end patmat */
# ifdef USE_REGEXP
/*		+-------------------------------------------------------+
 *		|	regular expressions (compile & execute) ...			|
 *		+-------------------------------------------------------+
 */
# include	<stdio.h>
# include	<stdlib.h>
# include	<string.h>

# define	true	1
# define	false	0

# define	global
# define	local	static
# define	reg		register

typedef		char	bool ;

char * re_execute (char *, char *, char *) ;
bool match (char *, char *, char *, short) ;

global	char	*regcmp ();
global	char	*regex ();

local	char	*_end_match;	/* aponta primeiro caracter na linha */
								/* apos a expressao */
global	char	*_loc1;
/*
 *	Tipos de Elementos no Automato
 */
#define  C_UNIQUE	0x01		/* Caracter Normal */
#define  C_SET		0x02		/* Um conjunto de caracteres */
#define  C_ANY		0x03		/* Qualquer caracter */
#define  E_BEGIN	0x04		/* Inicio de uma Expressao */
#define  E_END		0x05		/* Fim de uma Expressao */
#define  E_TABLE	0x06		/* Inicio de uma tabela C_SET */

#define  ELEM(c)	(c & 0x0F)
/*
 *	Atributos para os elementos no Automato
 */
#define  A_FIRST	0x10	/* Ocorrencia do elemento no inicio */
#define  A_LAST		0x20	/*			  no fim */
#define  A_REPEAT	0x40	/* Repeticao zero ou mais vezes */
#define  A_RANGE	0x80	/* Repeticao entre limites */

#define  ATRIB(c)	((c) & 0xF0)
/*
 *	Conjuntos de Caracteres
 */
#define  TBSIZE		(256)
#define  MASK(n)	(1 << (n-1))

#define  INCLUDE(ch, bit)	(set_table[ch] |= MASK(bit))
#define  EXCLUDE(ch, bit)	(set_table[ch] &= ~MASK(bit))
#define  PRESENT(ch, mask)	((set_table[ch] & mask) != 0)
/*
 *	Funcoes Locais:						*
 */
local	bool	match ();	/* Continua a execucao do Automato */
/*
 *	Compila Expressao Regular em um Automato Finito		*
 */
global	char	*
regcmp (expression)
char	*expression;
{
	reg	char	*ep;	/* aponta caracter corrente */
	reg	char	*cp;	/* aponta codigo corrente */
	reg	char	*cq;	/* aponta ultimo codigo */
	reg	char	*cs;	/* aponta inicio do codigo da exp. atual */
	reg	char	*code;	/* Area para o codigo gerado */

	reg	short	ch;

	reg	short	size;	/* tamanho necessario p/ o codigo */
	reg	short	ntabs;	/* No. de tabelas C_SET */
	reg	short	nbits;	/* No. de bits C_SET ainda disponiveis */

	reg	short	nsets;
	reg	char	*set_table;
	/*
	 *	Calcula tamanho necessario p/ o codigo gerado	*
	 */
	size = 3;	/* E_BEGIN, E_END, '\0' */
	ntabs = 0;
	nbits = 0;
	for (ep = &expression[0]; *ep; ep++)
	{
/*
		printf ("caracter: '%c'\n", *ep);
*/
		switch (*ep)
		{
		    case '\\':
			ep++;
			goto case_default;

		    case '^':
			if (ep > expression)
				goto case_default;
			break;

		    case '$':
			if (*(ep+1) != '\0')
				goto case_default;
			break;

		    case '[':
			if (nbits == 0)
			{
				ntabs++;
				nbits = 8;
			}
			nbits--;
			size += 2;
			while (*ep && *ep != ']' && *(ep-1) != '\\')
				ep++;
			if (*ep == '\0')
			{
				fputs ("regcmp: Falta ']'\n", stderr);
				return (VZRO);
			}
			break;

		    case '.':
			size += 1;
			break;

		    case '*':
			if (ep == expression)
				goto case_default;
			break;

		    case '+':
			if (ep == expression)
				size += 2;
			else
				goto case_default;
			break;

		    case_default:
		    default:
			size += 2;
			break;

		}	/* switch (*ep) */

/*
		printf ("Size:%d, Nbits:%d, Ntabs:%d\n\n", size, nbits, ntabs);
*/

	}	/* for (*ep) */

	size += TBSIZE * ntabs;

	/*
	 *	Aloca memoria para o Automato
	 */
	if ((code = malloc (size)) == VZRO)
		return (VZRO);
	/*
	 *	Compilacao					*
	 */
	nsets = 0;
	set_table = VZRO;

	cs = &code[0];

	/*
	 *	Coloca as Tabelas no inicio do Codigo.
	 */
	while (ntabs -- > 0)
	{
		*cs = E_TABLE;
		if (set_table == VZRO)
			set_table = cs +1;
		for (cp = cs +1; cp < cs + TBSIZE +1; cp++)
			*cp = 0;
		cs += TBSIZE +1;
	}

	/*
	 *	Inicia Geracao do Automato.
	 */
	*cs = E_BEGIN;
	cq = VZRO;	/* cq == VZRO => inicio de uma expressao */
	cp = cs +1;

	/*
	 *	Percorre a Expressao Regular e Gera seu Automato correspondente.
	 */
	for (ep = &expression[0]; *ep; ep++)
	{
/*
		printf ("caracter: '%c'\n", *ep);
*/
		switch (*ep)
		{
		    case '\\':
			cq = cp;
			*cp++ = C_UNIQUE;
			*cp++ = *++ep;
			break;

		    case '^':
			if (cq == VZRO)
				*cs |= A_FIRST;
			else
				goto case_normal;
			break;

		    case '$':
			if (*(ep+1) == '\0')
				*cs |= A_LAST;
			else
				goto case_normal;
			break;

		    case '[':
			cq = cp;
			if (nsets == 8)
			{
				set_table += TBSIZE +1;
				nsets = 1;
			}
			else
				nsets++;

			if (*(ep+1) == '^')
				goto case_neg;

			while (*++ep != ']')
			{
				if (*ep != '\\' && *(ep+1) == '-'
				   && *(ep+2) >= *ep
				   && *(ep+2) != ']')
				{
					for (ch = *ep; ch <= *(ep+2); ch++)
						INCLUDE (ch, nsets);
					ep++;
					ep++;
				}
				else
				{
					if (*ep == '\\')
						ep++;
					INCLUDE (*ep, nsets);
				}
			}
			*cp++ = C_SET;
			*cp++ = MASK (nsets);
			break;

		    case_neg:
			for (ch = 0; ch <= 127; ch++)
				INCLUDE (ch, nsets);
			ep++;
			while (*++ep != ']')
			{
				if (*ep != '\\' && *(ep+1) == '-'
				   && *(ep+2) >= *ep
				   && *(ep+2) != ']')
				{
					for (ch = *ep; ch <= *(ep+2); ch++)
						EXCLUDE (ch, nsets);
					ep += 2;
				}
				else
				{
					if (*ep == '\\')
						ep++;
					EXCLUDE (*ep, nsets);
				}
			}
			*cp++ = C_SET;
			*cp++ = MASK (nsets);
			break;

		    case '.':
			cq = cp;
			*cp++ = C_ANY;
			break;

		    case '*':
			if (cq != VZRO && (ATRIB(*cq) & A_REPEAT) == 0)
				*cq |= A_REPEAT;
			else
				goto case_normal;
			break;

		    case '+':
			if (cq != VZRO && (ATRIB(*cq) & A_REPEAT) == 0)
			{
				*cp++ = ELEM(*cq) | A_REPEAT;

				if (ELEM(*cq) == C_ANY)
					cq = cp -1;
				else
				{
					*cp++ = *(cq+1);
					cq = cp -2;
				}
			}
			else
				goto case_normal;
			break;

		case_normal:
		    default:
			cq = cp;
			*cp++ = C_UNIQUE;
			*cp++ = *ep;
			break;

		}	/* switch (*ep) */

	}	/* for (*ep) */

	*cp++ = E_END;
	*cp = '\0';

	return (code);

}	/* end regcmp */
/*
 ****************************************************************
 *	Executa Automato correspondente a uma Expressao Regular	*
 ****************************************************************
 */
local	char	*
re_execute (expr, line, start)
reg char	*expr;		/* Automato da Expressao Regular */
char		*line;		/* Linha de Texto p/ execucao do Automato */
reg char	*start;		/* Inicio da execucao em line */
{
	char	*set_table;
	char	nsets;
	bool	first,
		last;

	reg bool	common_case;
	reg char	first_char;

	/*
	 *	Avanca Tabelas.
	 */
	if (ELEM(*expr) == E_TABLE)
	{
		set_table = expr +1;
		expr = expr + TBSIZE + 1;
		while (ELEM(*expr) == E_TABLE)
			expr += TBSIZE + 1;
		nsets = 8;
	}
	else
	{
		set_table = VZRO;
		nsets = 0;
	}

	/*
	 *	Pequena verificacao do formato do Automato.
	 */
	if (ELEM(*expr) != E_BEGIN)
	{
		fprintf (stderr, "re_exec: Automato invalido\n");
		return (VZRO);
	}

	/*
	 *	Atributos exclusivos da Expressao Mae.
	 */
	first = ATRIB(*expr) & A_FIRST;
	last =  ATRIB(*expr) & A_LAST;

	/*
	 *	Expressao no inicio da linha.
	 */
	if (first)
	{
		if (start != line)
			return (VZRO);

		if (match (expr, line, set_table, nsets))
			if (!last || *_end_match == '\0')
				return (start);

		return (VZRO);
	}

	/*
	 *	Otimizacao.
	 */
	common_case = ELEM (*(expr+1)) == C_UNIQUE
			&& (ATRIB (*(expr+1)) & A_REPEAT) == 0 ;
	first_char = common_case ? *(expr+2) : '\0';

	/*
	 *	Percorre line, a partir de start,
	 *	ate' que o automato possa ser executado
	 *	ou que line termine.
	 */
	for ( ; *start; start++)
	{
		/*
		 *	Otimizacao:
		 */
		if (common_case)
		{
			if ((start = strchr (start, first_char)) == VZRO)
				return (VZRO);
		}

		/*
		 *	Tenta executar o Automato.
		 */
		if (match (expr, start, set_table, nsets))
			if (!last || *_end_match == '\0')
				return (start);
	}

	return (VZRO);

}	/* end regex */

/*
 ****************************************************************
 *	Ponto de Entrada para Execucao do Automato.		*
 ****************************************************************
 */
global	char	*
regex (expr, line, match)
reg	char	*expr, *line, *match;
{
	reg	char	*p;

	_loc1 = re_execute (expr, line, line);

	if (_loc1 != VZRO)
	{
		for (p = _loc1 ; p < _end_match ; p++)
			*match++ = *p;
		*match = '\0';
		return (_end_match);
	}
	else
		return (VZRO);

}	/* end regex */

/*
 ****************************************************************
 *	Verifica a continuacao da execucao do automato.		*
 ****************************************************************
 */
local	bool	
match (ep, lp, set_table, nsets)
reg char	*ep;		/* Automato */
reg char	*lp;		/* Linha de Texto */
char		*set_table;
short		nsets;
{
	reg	char	ch;
	reg	char	*bp;

	/*
	 *	Executa (recursivamente) o Automato a partir de start.
	 */
	for ( ; *ep ; ep++) switch (*ep)
	{
	    case E_BEGIN:
	    case E_BEGIN | A_FIRST:
	    case E_BEGIN | A_FIRST | A_LAST:
	    case E_BEGIN | A_LAST:
		break;

	    case E_END:
		break;

	    case C_UNIQUE:
		if (*lp == *++ep)
			lp++;
		else
			return (false);
		break;

	    case C_UNIQUE | A_REPEAT:
		ch = *++ep;
		bp = lp;
		while (*lp == ch)
			lp++;
		goto case_repeat;

	    case C_SET:
		if (--nsets < 0)
		{
			set_table += TBSIZE +1;
			nsets = 7;
		}
		ch = *++ep;
		if (PRESENT(*lp, ch))
			lp++;
		else
			return (false);
		break;

	    case C_SET | A_REPEAT:
		if (--nsets < 0)
		{
			set_table += TBSIZE +1;
			nsets = 7;
		}
		ch = *++ep;
		bp = lp;
		while (PRESENT(*lp, ch))
			lp++;
		goto case_repeat;

	    case C_ANY:
		if (*lp)
			lp++;
		else
			return (false);
		break;

	    case C_ANY | A_REPEAT:
		bp = lp;
		while (*lp)
			lp++;
		goto case_repeat;

	    case_repeat:
		ep++;
		for ( ; lp >= bp ; lp-- )
			if (match (ep, lp, set_table, nsets))
				return (true);
		return (false);

	    default:
		fprintf (stderr, "re: match: Automato invalido\n");
		return (false);

	}	/* for (*ep)  switch (*ep) */

	/*
	 *	O Automato executou completamente.
	 *	Indica o final da execucao em _end_match.
	 */
	_end_match = lp;
	return (true);

}	/* end match */
# endif /* USE_REGEXP */
# endif /* COMMENT */
/*
 * vi:tabstop=4
 */
