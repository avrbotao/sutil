/************************************************************************
*	+ trix globals ...													*
************************************************************************/

# include <stdio.h>
# include <errno.h>

# ifdef		ANYX
# if defined (FREEBSD) || defined (OPENBSD)
# include	<termios.h>
# define	termio		termios
# else
# include	<termio.h>
# endif
# endif		/* ANYX */

# include "trix.h"
# include "trixchrs.h"
# include "trixcfg.h"
# include "trixtext.h"
# include "trixvdo.h"
# include "trixblue.h"
# include "trixwind.h"
# include "trixkeys.h"
# include "trixwig.h"

# ifdef XTRC
FILE * trcfp ;
# endif /* XTRC */

BYT glast [ GTPSIZ ] = { 192, 196, 196, 0 } ;		/* "@DD" last		*/
BYT geach [ GTPSIZ ] = { 195, 196, 196, 0 } ;		/* "CDD" each		*/
BYT gspac [ GTPSIZ ] = "   " ;						/* "   " gap		*/
BYT gstik [ GTPSIZ ] = { 179, 32,  32,  0 } ;		/* "3  " link		*/

char	tmpbuf		[BUFSIZ] ;	/* gen.	purp. tmp.  buf.			*/
char	xdestdir	[  100 ] ;	/* gen. purp. dest. dir.			*/
char	origwd		[   80 ] ;

char    gtfpn       [   80 ] ;

BYT xfram [20] ;		/* "any time" selectable frame characters ...	*/

BYT dhdvfram [20] = {		/* double line frame ...						*/
# ifdef DOS
	C_DUL, C_DUR, C_DLL, C_DLR,
	C_DUT, C_DDT, C_DLT, C_DRT,
	C_DXT, C_DVL, C_DHL,
# else  /* ANYX */
	0, 0, 0, 0,    0, 0, 0, 0,    0, 0, 0,
# endif /* DOS */
	'\0'
} ;

BYT shsvfram [20] = {		/* single line frame ...						*/
# ifdef DOS
	C_SUL, C_SUR, C_SLL, C_SLR,
	C_SUT, C_SDT, C_SLT, C_SRT,
	C_SXT, C_SVL, C_SHL,
# else  /* ANYX */
	0, 0, 0, 0,    0, 0, 0, 0,    0, 0, 0,
# endif /* DOS */
	'\0'
} ;

BYT shdvfram [20] = {		/* double vertical only frame ...				*/
# ifdef DOS
	C_VUL, C_VUR, C_VLL, C_VLR,
	C_VUT, C_VDT, C_VLT, C_VRT,
	C_VXT, C_VVL, C_VHL,
# else  /* ANYX */
	0, 0, 0, 0,    0, 0, 0, 0,    0, 0, 0,
# endif /* DOS */
	'\0'
} ;

BYT dhsvfram [20] = {		/* double horizontal only frame ...				*/
# ifdef DOS
	C_HUL, C_HUR, C_HLL, C_HLR,
	C_HUT, C_HDT, C_HLT, C_HRT,
	C_HXT, C_HVL, C_HHL,
# else  /* ANYX */
	0, 0, 0, 0,    0, 0, 0, 0,    0, 0, 0,
# endif /* DOS */
	'\0'
} ;

BYT dashfram [20] = {		/* ordinary dashed line frame (-,+,|) ...		*/
	'+', '+', '+', '+',    '+', '+', '+', '+',    '+', '|', '-', ' ',
	'\0'
} ;

BYT * framstyl [] = {   dhdvfram, shsvfram,
                        dhsvfram, shdvfram	/* , dashfram */
					} ;

int ftyx = 0 ;	/* fram typ index */
/* unsigned char * * ftp = framstyl ; */

char * rgxpat ;			/* regular expression (wild card) pattern ...	*/
char * currwd ;
char * pathdr ;
char * tothdr ;
char * curhdr ;
char * cmb1 ;			/* "any time" command menu bar (1st line) ...	*/
char * cmb2 ;			/* "any time" command menu bar (2nd line) ...	*/
char * fmb ;			/* "any time" PF menu bar ...					*/
char * ghyid = NOSTR ;	/* global history id							*/
char * ghelpt = NOSTR ;	/* global help topic							*/
char * xwhy = NOSTR ;

char * * piclst ;
char * * picptr ;

TRXSIZ totdirs = 0L ;								/* tot # of dirs		*/
TRXSIZ totfils = 0L ;								/* tot # of files		*/
TRXSIZ totbyts = 0L ;								/* tot # of bytes		*/

FILDAT * destfilv ;
FILDAT * destmflv ;

DIRDAT * gpan ;									/* global panoramic ptr	*/
DIRDAT * groot ;								/* global root ptr		*/
DIRDAT * destdd ;								/* dest dir 4 mv,cp,ln	*/
DIRDAT * * wablst ;								/* walk about list		*/
DIRDAT * * wabptr ;								/* walk about pointer	*/

TOPDAT * gtop ;							/* global top statistics ptr	*/
TOPDAT * * tops = VZRO (TOPDAT * *) ;	/* array of "roots" (top dirs)	*/

HYDAT *	histlist = (HYDAT *) 0 ;		/* history head list			*/

FILE *		vfp ;						/* vueing file pointer ...		*/

# ifdef   DBG
UNS long memgot = 0 ;
# endif   /* DBG */

UNS gprot ;

int ( * filcmp ) () ;					/* file comparison routine ...	*/

int dflg = KPOINTS ;			/* dots on "k" multiples ...			*/
int eflg = FALSE ;				/* initial sort criterion is extension	*/
int gflg = FALSE ;				/* NO alternate graphic char set ...	*/
int pflg = FALSE ;              /* pause on errors during log ...       */
int qflg = FALSE ;				/* quiet (~verbose) log ...				*/
int sflg = FALSE ;				/* speedy "dir-stru-only" log ...		*/
int Tflg = FALSE ;              /* force "serial" term i/o ...          */
int uflg = FALSE ;              /* ignore eff uid not root ...          */
int nflg = FALSE ;              /* flip full file name display method	*/

int scaleflag = FALSE ;

int ascord = TRUE ;						/* ascending order sorting ...	*/
int finfmt = NAMONLY ;							/* file info format		*/
int pglok = FALSE ;								/* wrap around / scroll	*/
int fwlins = DFL_FWLINS ;			/* file window height in lines			*/
int vlinwid = VIDWID ;			/* line width of video display			*/
int fwlinwid = DFL_FWLINW ;			/* line width of file window			*/
int fwcofs = DFL_FWCOFS ;			/* column offset of file window home	*/
int fwlofs = DFL_FWLOFS ;			/* line offset of file window home		*/
int framtyp = 'f' ;				/* frame style ...						*/
int wpathdr = 20 ;
int wpathnam = 58 ;
int wtothdr = 23 ;
int wcurhdr = 23 ;
int trixtate = 'd' ;			/* trix' state							*/
int xfmb ;				/* "extra" (query) menu bar (dialog box) ...	*/
int topn = 0 , maxvdo = 24 ;
int xerrno ;
int logedest ;					/* destination dir. is or isn't loged	*/
int overmove ;					/* file moved  over existing dest ...	*/
int overcopy ;					/* file copied over existing dest ...	*/
int tothist = 0 ;				/* tot # history heads ...				*/
int curwax = -1 ;				/* current walk about index ...			*/
int logflgs = 0x0000 ;
int	bedvue = FALSE ;
int	lograin = 20 ;				/* log monit display grain ...			*/
int jkey = 0 ;
int bignamjus = FALSE ;			/* FALSE = Left Justify					*/
int gwrd = 0 ;					/* global write result descriptor		*/

HDRINF fixhdrs [] = {
	{ &_lhtotbyt, &_chtotbyt,  5, "Bytes" } ,
	{ &_lhtotfil, &_chtotfil,  5, "Arqs." } ,
	{ &_lhmatbyt, &_chmatbyt,  5, "Bytes" } ,
	{ &_lhmatfil, &_chmatfil,  8, "Arquivos" } ,
	{ &_lhselbyt, &_chselbyt,  5, "Bytes" } ,
	{ &_lhselfil, &_chselfil,  8, "Arquivos" } ,
	{ &_lhdirbyt, &_chdirbyt,  5, "Bytes" } ,
	{ &_lhdirfil, &_chdirfil,  8, "Arquivos" } ,
	{ &_lfamhdr,  &_cfamhdr,   9, "Familia: " } ,
	{ &_lselhdr,  &_cselhdr,  23, "Arquivos Selecionados: " } ,
	{ &_lprohdr,  &_cprohdr,  10, "Protecao: " } ,
	{ &_lwrthdr,  &_cwrthdr,  10, "Gravacao: " } ,
	{ &_lrdthdr,  &_crdthdr,  10, "Leitura:  " } ,
	{ &_lownhdr,  &_cownhdr,   7, "Dono:  " } ,
	{ &_lgrphdr,  &_cgrphdr,   7, "Grupo: " } ,
	{ &_llnkhdr,  &_clnkhdr,  10, "Ligacoes: " } ,
	{ (int *) 0,  (int *) 0,   0, (char *) 0 }
} ;

/*----------------------------------------------------------------------*
 *	+ stuff related 2 disptree() ...									*
 *----------------------------------------------------------------------*/

int gtwlin , gwabinx ;
char * * gtwtopg ;
DIRDAT * * gwabp , * * gwabtop ;

/************************************************************************
*	system-dependant globals (ANYX) ...								*
************************************************************************/

# ifdef   ANYX

int		tfd ;					/* terminal file descriptor ...			*/
int     totown ;
int     totgrp ;
int     cmask ;

USHORT	realuid			;
USHORT	realgid			;
USHORT	effuid			;
USHORT	effgid			;

OWNDAT * ownlist = (OWNDAT *) 0 ;
GRPDAT * grplist = (GRPDAT *) 0 ;

struct termio	orig ;			/* original term ctrl statuses			*/
struct termio	work ;			/* working  term ctrl statuses			*/

char	termid [ 20 ] ;			/* terminal identification (TERM=...)	*/
char	tgetbuf [1024] ;		/* buffer 4 tgetent ...					*/
char	altgcs [ 256 ] ;		/* alternate graphic char set ...		*/

char *	cmbuf ;					/* cursor positioning (ansi)			*/
char *	clbuf ;					/* clear screen 						*/
char *	cebuf ;					/* clear to end-of-line					*/
char *	blbuf ;					/* audio alarm (bell)					*/
char *	sobuf ;					/* begin standout (reverse)				*/
char *	sebuf ;					/* end   standout (reverse)				*/
char *	usbuf ;					/* begin underline						*/
char *	uebuf ;					/* end   underline						*/
char *	mdbuf ;					/* begin highlight						*/
char *	mbbuf ;					/* begin blink							*/
char *	mebuf ;					/* end   highlight or blink				*/
char *	rhbuf ;					/* reverse highlight					*/
char *	rbbuf ;					/* reverse blink						*/
char *	bhbuf ;					/* blink highlght						*/
char *	gsbuf ;					/* start alt graphic char set			*/
char *	gebuf ;					/* end   alt graphic char set			*/
char *	qdbuf ;					/* graphic doubline box chars			*/
char *	qsbuf ;					/* graphic singline box chars			*/
char *	qhbuf ;					/* graphic dbl. horiz. line box chars	*/
char *	qvbuf ;					/* graphic dbl. vert.  line box chars	*/
char *	qxbuf ;					/* graphic extra chars					*/
char *	qybuf ;					/* graphic extra chars # 2              */
char *	cibuf ;					/* cursor invisible ...					*/
char *	cvbuf ;					/* cursor visible ...					*/

/*_______________________________________________________________________
 *	+ d default termcap routines (xenix) don't accept nu cap nams (like
 *	  QD, QS, QX, ...) ! so, while my libtermcap isn't ported, som
 *	  conversions must b mad. & use always variant term nams ...
 *	  (md=GU, QD=GD, QS=GR, QX=GV)
 */

CAPCTL	capbuf [] = {
	{ "cm",		&cmbuf,		 0 	}	,	/* cursor motion (locate)		*/
	{ "cl",		&clbuf,		 1	}	,	/* clear screen					*/
	{ "ce",		&cebuf,		 2	}	,	/* clear to end-of-line			*/
	{ "bl",		&blbuf,		 3	}	,	/* bell (alarm sound)			*/
	{ "so",		&sobuf,		 4	}	,	/* begin standout (reverse)		*/
	{ "se",		&sebuf,		 5	}	,	/* end   standout (reverse)		*/
	{ "us",		&usbuf,		 6	}	,	/* begin underline				*/
	{ "ue",		&uebuf,		 7	}	,	/* end   underline				*/
	{ "mb",		&mbbuf,		 9	}	,	/* begin blink					*/
	{ "me",		&mebuf,		10	}	,	/* end   highlight or blink		*/
	{ "GS",		&gsbuf,		11	}	,	/* start alt graphic char set	*/
	{ "GE",		&gebuf,		12	}	,	/* end   alt graphic char set	*/
	{ "GU",		&mdbuf,		 8	}	,	/* begin highlight				*/
	{ "GD",		&qdbuf,		13	}	,	/* graphic doubline box chars	*/
	{ "GR",		&qsbuf,		14	}	,	/* graphic singline box chars	*/
	{ "GV",		&qxbuf,		15	}	,	/* graphic extra chars			*/
	{ "CF",		&cibuf,		16	}	,	/* cursor invisible				*/
	{ "CO",		&cvbuf,		17	}	,	/* cursor visible				*/
	{ "GH",		&qhbuf,		18	}	,	/* graphic dbl hrz lin box chrs */
	{ "GC",		&qvbuf,		19	}	,	/* graphic dbl vrt lin box chrs */
	{ "G2",		&qybuf,		20	}	,	/* graphic extra chars # 2      */
	{ NOSTR,	VZRO(char **),	0	}
} ;

char * * efon [] = {
	&sebuf,				/*	"\033[m",		normal video (ansi)			*/
	&mdbuf,				/*	"\033[1m",		highlight video (ansi)		*/
	&usbuf,				/*	"\033[4m",		underline (ansi)			*/
	&mbbuf,				/*	"\033[5m",		blink video (ansi) ...		*/
	&sobuf,				/*	"\033[7m",		reverse video (ansi) ...	*/
	&gsbuf,				/*	"\033[11m",		alt graphics char set		*/
	&rhbuf,				/*	"\033[1;7m",	reverse highlight video 	*/
	&bhbuf,				/*	"\033[1;5m",	blink highlight (VEHIBL)	*/
	&rbbuf,				/*	"\033[5;7m",	reverse blink	(VERVBL)	*/
	VZRO (char * *)
} ;

char * * efof [] = {
	&sebuf,				/*	"\033[m",	end	normal video (ansi)			*/
	&mebuf,				/*	"\033[m",	end	highlight video (ansi)		*/
	&uebuf,				/*	"\033[m",	end	underline (ansi)			*/
	&mebuf,				/*	"\033[m",	end	blink video (ansi) ...		*/
	&sebuf,				/*	"\033[m",	end	reverse video (ansi) ...	*/
	&gebuf,				/*	"\033[10m",	end	alt graphics char set		*/
	&sebuf,				/*	"\033[m",	end reverse highlight video		*/
	&sebuf,				/*	"\033[m",	end blink highlight (VEHIBL)	*/
	&sebuf,				/*	"\033[m",	end reverse blink	(VERVBL)	*/
	VZRO (char * *)
} ;

KEYINFO keylst [] = {
	{ "k1",   KF1,      "F1",       NOSTR	} ,
	{ "k2",   KF2,      "F2",       NOSTR	} ,
	{ "k3",   KF3,      "F3",       NOSTR	} ,
	{ "k4",   KF4,      "F4",       NOSTR	} ,
	{ "k5",   KF5,      "F5",       NOSTR	} ,
	{ "k6",   KF6,      "F6",       NOSTR	} ,
	{ "k7",   KF7,      "F7",       NOSTR	} ,
	{ "k8",   KF8,      "F8",       NOSTR	} ,
	{ "k9",   KF9,      "F9",       NOSTR	} ,
	{ "k0",   KF10,     "F10",      NOSTR	} ,
	{ "kh",   KHOME,    "Home",     NOSTR	} ,
	{ "EN",   KEND,     "End",      NOSTR	} ,
	{ "PU",   KPGUP,    "PgUp",     NOSTR	} ,
	{ "PD",   KPGDN,    "PgDn",     NOSTR	} ,
	{ "ku",   KUP,      "Up",       NOSTR	} ,
	{ "kd",   KDOWN,    "Down",     NOSTR	} ,
	{ "kl",   KLEFT,    "Left",     NOSTR	} ,
	{ "kr",   KRIGHT,   "Right",    NOSTR	} ,
	{ NOSTR,  -1,       NOSTR,      NOSTR   }
} ;

int totkeys ;

BYT pc_qd [FRAMAX] = {
201, 187, 200, 188, 203, 202, 204, 185, 206, 186, 205, '?', '\0'
} ;

BYT pc_qs [FRAMAX] = {
218, 191, 192, 217, 194, 193, 195, 180, 197, 179, 196, '?', '\0'
} ;

BYT pc_qh [FRAMAX] = {
213, 184, 212, 190, 209, 207, 198, 181, 216, 179, 205, '\0'
} ;

BYT pc_qv [FRAMAX] = {
214, 183, 211, 189, 210, 208, 199, 182, 215, 186, 196, '\0'
} ;

BYT pc_qx [FRAMAX] = {
223, ' ', 176, 177, 178, 219, 220, 221, 222, 223, '\0'
} ;

BYT pc_qy [50] = {
251, '\0'
} ;

int  pc_ca [] = {
    0x07, 0x0f, 0x02, 0x87, 0x70, 0x07, 0x7e, 0x8f, 0xf0
} ;

# endif   /* ANYX */
/*
 *		|-------------------------------------------------------|
 *		|	 blessings stuff ...						    	|
 *		|-------------------------------------------------------|
 */
int vfd = 0 ;					/* video file descriptor	*/
int vmode ;						/* video mode				*/
int vdotyp = 0 ;				/* video type (tty,vga...)	*/
char * vrbp ;					/* video ram buffer pointer	*/
VSTAT vsbuf ;                   /* video status info buffer */
WWINFO     * stdww  = (WWINFO *) 0 ;
SCRELM far * stdweb = (SCRELM far *) 0 ;
/*
 *		|-------------------------------------------------------|
 *		|	 configurable variables & valid choices ...	    	|
 *		|-------------------------------------------------------|
 */
char * trixpath = (char *) 0 ;
char * editcmd = "vi" ;         /* edit command ...						*/
char * shellcmd = "sh" ;		/* shell command ...					*/
char * printcmd = "lpr" ;	    /* print (spool) command ...			*/
long maxfiles = 5000 ;
int quitconf = TRUE ;			/* confirm b4 quit (yes, no)			*/
int xtabsiz = 8 ;				/* tab size for various modules			*/
int deldays = 5 ;				/* days 2 really del recoverable files	*/
int logmeth = STDLOG ;			/* log method (std, fast, sysV)			*/
int supdir = CURRSUP ;			/* start-up dir (current, home, root)	*/

TXTCOD valog [] = {
	{ &T_STDLOG,	STDLOG	} ,
	{ &T_FASTLOG,	FASTLOG } ,
	{ &T_SYSVLOG,	SYSVLOG } ,
	{ VVZRO,		0 }
} ;

TXTCOD vasup [] = {
	{ &T_CURRENT,	CURRSUP } ,
	{ &T_HOME,		HOMESUP } ,
	{ &T_ROOT,		ROOTSUP } ,
	{ VVZRO,		0 }
} ;

TXTCOD vayes [] = {
	{ &T_YES,		TRUE	} ,
	{ &T_NO,		FALSE	} ,
	{ VVZRO,		0 }
} ;

CFGIT cfglst [] = {
	{ &T_TRIXPATH,  VA(trixpath),	VVZRO,	CI_TXT					} ,
	{ &T_MAXFILES,	&maxfiles,	    VVZRO,	CI_LON					} ,
	{ &T_QUITCONF,	&quitconf,	    vayes,	CI_TXT|CI_COD			} ,
	{ &T_LOGMETH,	&logmeth,	    valog,	CI_TXT|CI_COD			} ,
	{ &T_EDITCMD,	VA(editcmd),    VVZRO,	CI_TXT					} ,
	{ &T_PRINTCMD,	VA(printcmd),	VVZRO,	CI_TXT					} ,
	{ &T_SHELLCMD,	VA(shellcmd),	VVZRO,	CI_TXT					} ,
	{ &T_SUPDIR,	&supdir,	    vasup,	CI_TXT|CI_COD			} ,
	{ &T_TABSIZ,	&xtabsiz,	    VVZRO,	CI_INT					} ,
	{ &T_DELDAYS,	&deldays,	    VVZRO,	CI_INT					} ,
	{ VVZRO,		VVZRO,		    VVZRO,	0						}
} ;

/*----------------------------------------------------------------------*
*	+ ...																*
*----------------------------------------------------------------------*/

ERRINF errdat [] = {

	{ ENOENT  , "Arquivo NAO ENCONTRADO" } ,
	{ EACCES  , "Permissao de acesso NEGADA" } ,

	{ -1      , NOSTR } /* reserved 4 end-of-list ...			*/

} ; /* endof errdat[] ... */

/*----------------------------------------------------------------------*
*	+ ...																*
*----------------------------------------------------------------------*/

# ifdef BIGBAN
#	define AUTHENTIC_BIG
char * * bantxt ;
char * banopt [ MAXBANLIN ] = {
# else
#	define AUTHENTIC_SMALL
char * bantxt [ DFL_BANLINS+1 ] ;
char * banopt [ DFL_BANLINS+1 ] = {
# endif

# ifdef AUTHENTIC_BIG

"                                                                         ",	/* --- */
"                        22 222 22 22 2 2 22 22 222 22                    ",	/*  14 */
"                          222 22 22 22 22 22 22 222                      ",	/*  13 */
"                           222 2 222 2 2 222 2 222                       ",	/*  12 */
"                            2222 2 22 2 22 2 2222                        ",	/*  11 */
"                              222 222 2 222 222                          ",	/*  10 */
"                               555 552 255 555                           ",	/*   9 */
"                                777 55255 777                            ",	/*   8 */
" 999999999999    99999999s     99999 757 99999                           ",	/*   7 */
" 999999999999    9999999999     n9999 7 9999n                            ",	/*   6 */
" nnnn9999nnnn    9999 99999       n999 999n                              ",	/*   5 */
"     9999        99999999n          99999                                ",	/*   4 */
"     9999        9999999s         s9999999s                              ",	/*   3 */
"     9999        9999 9999s     s99999n99999s                            ",	/*   2 */
"     9999        9999  9999    99999n   n99999                           ",	/*   1 */
"                                                                         ",	/* --- */

# endif /* AUTHENTIC_BIG */

# ifdef AUTHENTIC_SMALL

"                                               ",	/*  1 */
"                              222 222   222 222",	/*  2 */
"                               555 552 255 555 ",	/*  3 */
"                                777 55255 777  ",	/*  4 */
" 999999999999    99999999s     99999 757 99999 ",	/*  5 */
" 999999999999    9999999999     n9999 7 9999n  ",	/*  6 */
" nnnn9999nnnn    9999 99999       n999 999n    ",	/*  7 */
"     9999        99999999n          99999      ",	/*  8 */
"     9999        9999999s         s9999999s    ",	/*  9 */
"     9999        9999 9999s     s99999n99999s  ",	/* 10 */
"     9999        9999  9999    99999n   n99999 ",	/* 11 */
"                                               ",	/* 12 */

# endif /* AUTHENTIC_SMALL */

# ifdef ORIGAUTH

"                                                       ",
"                                      222 222   222 222",
"                                       555 552 255 555 ",
"                                        777 55255 777  ",
" 999999999999    99999999s     9999    99999 757 99999 ",
" 999999999999    9999999999    9999     n9999 7 9999n  ",
" nnnn9999nnnn    9999 99999    9999       n999 999n    ",
"     9999        99999999n     9999         99999      ",
"     9999        9999999s      9999       s9999999s    ",
"     9999        9999 9999s    9999     s99999n99999s  ",
"     9999        9999  9999    9999    99999n   n99999 ",
"                                                       ",

# endif /* ORIGAUTH */

# ifdef BUDDY

"                ",
"                ",
"                ",
"       /\\       ",
"      /  \\      ",
"     / OO \\     ",
"     \\ \\/ /     ",
"      \\  /      ",
"       \\/       ",
"                ",
"                ",
"                ",

# endif /* BUDDY */

# ifdef COMMENT

"      /\\/\\      ",
"     / /  \\     ",
"    / / /\\ \\    ",
"   / / /\\ \\ \\   ",
"  / / /  \\ \\ \\  ",
"  \\ \\/ OO \\ \\/  ",
"  /\\ \\ \\/ /\\ \\  ",
"  \\ \\ \\  / / /  ",
"   \\ \\ \\/ / /   ",
"    \\ \\/ / /    ",
"     \\  / /     ",
"      \\/\\/      ",

/* ------------------------- */

"  ______________  ",
" /\\  ___________\\ ",
" \\ \\ \\________  / ",
"  \\ \\ \\    / / /  ",
"   \\ \\ \\  / / /   ",
"    \\ \\ \\/ / /    ",
"     \\ \\/ / /     ",
"      \\  / /      ",
"       \\/_/       ",
"                  ",

# endif /* COMMENT */

 VZRO (char *)

} ;

/***********************************************************************/

int		termrows = 24 ;
int		termcols = 80 ;

int		fastworkflag = 0 ;

char	trixworkpath [4096] ;

/***********************************************************************/

/*
 * vi:tabstop=4
 */
