/* read diskette ... */

# include <stdlib.h>
# include <stdio.h>
# include <ctype.h>
# include <fcntl.h>
# include <dos.h>
# include <io.h>

void main (argc, argv) char * * argv ; {
	char * buf ;
	char * nam ;
	int fd ;
	int drvno ;				/* driver letter / number	*/
	int bysect = 512 ;		/* bytes per sector			*/
	int sectrk ;			/* sectors per track		*/
	int totrk ;				/* total number of tracks	*/
	int totsec ;			/* total number of sectors	*/
	int sectno ;			/* logical sector number	*/
	int trkno ;
	int trksiz ;

	if (argc != 5) {
		printf ("\nuse: rdsk <drv> <sects/trk> <#trks> <file>\n") ;
		return ;
	}
	drvno = toupper (*(*(argv+1))) - 'A' ;
	sectrk = 2 * (atoi (*(argv+2))) ;
	totrk = atoi (*(argv+3)) ;
	nam = *(argv+4) ;
	trksiz = sectrk * bysect ;
	if ((buf = malloc (trksiz)) == NULL) {
		printf ("malloc failed (%d bytes)\n", trksiz) ;
		return ;
	}
	totsec = sectrk * totrk ;
	if ((fd = open (nam, (O_CREAT|O_TRUNC|O_RDWR|O_BINARY))) < 0) {
		printf ("can't create %s\n", nam) ;
		return ;
	}
	trkno = 0 ;
	for ( sectno = 0 ; sectno < totsec ; ++trkno , sectno += sectrk ) {
		printf ("reading track # %2d (sector # %4d) ... ",
				trkno, sectno) ;
		if (absread (drvno, sectrk, sectno, buf) < 0)
			printf ("Error\n") ;
		else
			printf ("OK\r") ;
		write (fd, buf, trksiz) ;
	}
	close (fd) ;
}
