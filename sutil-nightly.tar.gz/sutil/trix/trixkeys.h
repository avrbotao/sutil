
/************************************************************************
*	keyboards ( pc , at , 386 , xenix ( *[ui]x ) , ... )				*
************************************************************************/

# ifdef	 DOS

/*_______________________________________________________________________
 *	should work with pc , at , 386 , & the like ...
 */

# define	KUP			(PCKEY ( 72))	/* "up"							*/
# define	KDOWN		(PCKEY ( 80))	/* "down"						*/
# define	KLEFT		(PCKEY ( 75))	/* "left"						*/
# define	KRIGHT		(PCKEY ( 77))	/* "right"						*/

# define	KPGUP		(PCKEY ( 73))	/* "pgup"						*/
# define	KPGDN		(PCKEY ( 81))	/* "pgdn"						*/

# define	KINS		(PCKEY ( 82))	/* "ins"						*/
# define	KDEL		(PCKEY ( 83))	/* "del"						*/

# define	KHOME		(PCKEY ( 71))	/* "home"						*/
# define	KEND 		(PCKEY ( 79))	/* "end"						*/

# define	KF1			(PCKEY ( 59))	/* F1							*/
# define	KF2			(PCKEY ( 60))	/* F2							*/
# define	KF3			(PCKEY ( 61))	/* F3							*/
# define	KF4			(PCKEY ( 62))	/* F4							*/
# define	KF5			(PCKEY ( 63))	/* F5							*/
# define	KF6			(PCKEY ( 64))	/* F6							*/
# define	KF7			(PCKEY ( 65))	/* F7							*/
# define	KF8			(PCKEY ( 66))	/* F8							*/
# define	KF9			(PCKEY ( 67))	/* F9							*/
# define	KF10		(PCKEY ( 68))	/* F10							*/

# define	CPGUP		(PCKEY (132))	/* ctrl "pgup"					*/
# define	CPGDN		(PCKEY (118))	/* ctrl "pgdn"					*/

# define	ENTER		(PCKEY (256))	/* CR (or LF)					*/
# define	NOPE		(PCKEY (257))	/* 'n' or 'N'					*/
# define	YEAH		(PCKEY (258))	/* 'y', 'Y', 's', 'S'			*/

# ifdef	 COMMENT

ctrl  home   = 119
ctrl  end    = 117

ctrl  left   = 115
ctrl  right  = 116

shift f1 - shift f10   =  84 -  93
ctrl  f1 - ctrl	 f10   =  94 - 103
alt   f1 - alt   f10   = 104 - 113

# endif		/* COMMENT */

# endif		/* DOS */

/*_______________________________________________________________________
 *	unix, xenix, ... : terminfo & curses
 */

# ifdef		ANYX

# ifdef		CURSES

# define	KUP			KEY_UP			/* "up"							*/
# define	KDOWN		KEY_DOWN		/* "down"						*/
# define	KLEFT		KEY_LEFT		/* "left"						*/
# define	KRIGHT		KEY_RIGHT		/* "right"						*/

# define	KPGUP		KEY_PPAGE		/* "pgup"						*/
# define	KPGDN		KEY_NPAGE		/* "pgdn"						*/

# define	KINS		KEY_IC			/* "ins"						*/
# define	KDEL		KEY_DC			/* "del"						*/

# define	KHOME		KEY_HOME		/* "home"						*/
# define	KEND 		KEY_LL			/* "end"						*/

# define	KF1			KEY_F ( 1)		/* F1							*/
# define	KF2			KEY_F ( 2)		/* F2							*/
# define	KF3			KEY_F ( 3)		/* F3							*/
# define	KF4			KEY_F ( 4)		/* F4							*/
# define	KF5			KEY_F ( 5)		/* F5							*/
# define	KF6			KEY_F ( 6)		/* F6							*/
# define	KF7			KEY_F ( 7)		/* F7							*/
# define	KF8			KEY_F ( 8)		/* F8							*/
# define	KF9			KEY_F ( 9)		/* F9							*/
# define	KF10		KEY_F (10)		/* F10							*/

# ifdef		M_TERMCAP

# define	CPGUP		'2'				/* ctrl "pgup" = shift "home"	*/
# define	CPGDN		'8'				/* ctrl "pgdn" = shift "end"	*/

# else		/* M_TERMINFO */

# define	CPGUP		KEY_SHOME		/* ctrl "pgup" = shift "home"	*/
# define	CPGDN		KEY_SEND		/* ctrl "pgdn" = shift "end"	*/

# endif		/* M_TERMCAP */

# define	ENTER		10				/* CR (or LF)					*/
# define	NOPE		'n'				/* 'n' or 'N'					*/
# define	YEAH		'y'				/* 'y', 'Y', 's', 'S'			*/

# else		/* PROPRIETARY ... */

/************************************************************************
 *	unix, xenix, ... : proprietary key processing !
 */

# define	KUP			(ABKEY ( 72))	/* "up"							*/
# define	KDOWN		(ABKEY ( 80))	/* "down"						*/
# define	KLEFT		(ABKEY ( 75))	/* "left"						*/
# define	KRIGHT		(ABKEY ( 77))	/* "right"						*/

# define	KPGUP		(ABKEY ( 73))	/* "pgup"						*/
# define	KPGDN		(ABKEY ( 81))	/* "pgdn"						*/

# define	KINS		(ABKEY ( 82))	/* "ins"						*/
# define	KDEL		(ABKEY ( 83))	/* "del"						*/

# define	KHOME		(ABKEY ( 71))	/* "home"						*/
# define	KEND 		(ABKEY ( 79))	/* "end"						*/

# define	KF1			(ABKEY ( 59))	/* F1							*/
# define	KF2			(ABKEY ( 60))	/* F2							*/
# define	KF3			(ABKEY ( 61))	/* F3							*/
# define	KF4			(ABKEY ( 62))	/* F4							*/
# define	KF5			(ABKEY ( 63))	/* F5							*/
# define	KF6			(ABKEY ( 64))	/* F6							*/
# define	KF7			(ABKEY ( 65))	/* F7							*/
# define	KF8			(ABKEY ( 66))	/* F8							*/
# define	KF9			(ABKEY ( 67))	/* F9							*/
# define	KF10		(ABKEY ( 68))	/* F10							*/

# define	CPGUP		(ABKEY (132))	/* ctrl "pgup"					*/
# define	CPGDN		(ABKEY (118))	/* ctrl "pgdn"					*/

# define	ENTER		(ABKEY (256))	/* CR (or LF)					*/
# define	NOPE		(ABKEY (257))	/* 'n' or 'N'					*/
# define	YEAH		(ABKEY (258))	/* 'y', 'Y', 's', 'S'			*/

# endif		/* CURSES or PROPRIETARY */

# endif		/* ANYX */

int xkbhit (void) ;

/*
 * vi:tabstop=4
 */
