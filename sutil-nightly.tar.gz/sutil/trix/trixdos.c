/************************************************************************
*																		*
*	trixdos.c (dox.c) + dos' random access mass storage interface ...	*
*																		*
************************************************************************/

# ifdef COMMENT

# include	<stdio.h>
# include	<time.h>

# include	"trix_abc.h"

/*_______________________________________________________________________
 *	+ ...
 */

struct dosdirent {

	char	dde_nam [  8 ] ;
	char	dde_ext [  3 ] ;
	char	dde_atr [  1 ] ;
	char	dde_res [ 10 ] ;
	UWORD	dde_tim        ;
	UWORD	dde_dat        ;
	UWORD	dde_clu        ;	/* starting cluster & 1st FAT entry ...	*/
	long	dde_siz        ;
} ;

TYP		struct dosdirent		DOSDIRENT ;
TYP		struct tm				TM ;

struct dosdirinfo {

	char	ddi_nam [ 20 ] ;
	int		ddi_atr        ;
	TM		ddi_dtm        ;	/* date & time ...						*/
	long	ddi_siz        ;
} ;

TYP		struct dosdirinfo		DOSDIRINFO ;

/*_______________________________________________________________________
 *	+ ...
 */

# define	DOS_ARCHIV			0x20
# define	DOS_SUBDIR			0x10
# define	DOS_VOLABL			0x08
# define	DOS_SYSTEM			0x04
# define	DOS_HIDDEN			0x02
# define	DOS_RDONLY			0x01

/*_______________________________________________________________________
 *	+ ...
 */

# define	DOS_ERASED			0xe5
# define	DOS_DOTDIR			0x2e
# define	DOS_QMASK 			0x05
# define	DOS_EODIR 			0x00

/*_______________________________________________________________________
 *	+ ...
 */

# define	DOS_FTSEC(Y)		(Y       & 0x1f)		/* seconds / 2	*/
# define	DOS_FTMIN(Y)		((Y>>5)  & 0x3f)
# define	DOS_FTHOUR(Y)		((Y>>11) & 0x1f)

# define	DOS_FDMDAY(Z)		(Z       & 0x1f)
# define	DOS_FDMON(Z)		((Z>>5)  & 0x0f)
# define	DOS_FDYEAR(Z)		((Z>>9)  & 0x7f)

/*_______________________________________________________________________
 *	+ ...
 */

struct dosbootsec {

	/* dos version 2.0 ...												*/

	BYT		dbs_jmp [  3 ] ;	/* jmp 2 bootstrap routine ...			*/
	BYT		dbs_onv [  8 ] ;	/* OEM name & version # ...				*/
	BYT		dbs_bps [  2 ] ;	/* (word) bytes per sector				*/
	BYT		dbs_sal [  1 ] ;	/* sectors per allocation unit (clustr)	*/
	BYT		dbs_res [  2 ] ;	/* (word) # of reserved sectors			*/
	BYT		dbs_fak [  1 ] ;	/* # of FATs							*/
	BYT		dbs_rde [  2 ] ;	/* (word) # of root directory entries			*/
	BYT		dbs_tos [  2 ] ;	/* (word) total sectors in log. volume	*/
	BYT		dbs_med [  1 ] ;	/* media descriptor (byte)				*/
	BYT		dbs_spf [  2 ] ;	/* (word) sectors per FAT				*/

	/* dos version 3.0 ...												*/

	BYT		dbs_spt [  2 ] ;	/* (word) sectors per track				*/
	BYT		dbs_hdk [  2 ] ;	/* (word) # of heads ...				*/
	BYT		dbs_his [  4 ] ;	/* (long) # of hidden sectors			*/

	/* dos version 4.0 (_his is short on 3.0) ...						*/

	BYT		dbs_tob [  4 ] ;	/* (long) total sects (log vol > 32MB)	*/
	BYT		dbs_pdn [  1 ] ;	/* physical drive # ...					*/
	BYT		dbs_rb1 [  1 ] ;	/* reserved ...							*/
	BYT		dbs_ebs [  1 ] ;	/* extended boot signature (0x29)		*/
	BYT		dbs_vid [  4 ] ;	/* (long) binary volume ID ...			*/
	BYT		dbs_vol [ 11 ] ;	/* volume label ...						*/
	BYT		dbs_rb2 [  8 ] ;	/* reserved ...							*/
	BYT		dbs_bsr [  1 ] ;	/* start of bootstrap routine ...		*/	

} ;

TYP		struct dosbootsec		DOSBOOTSEC ;

/*_______________________________________________________________________
 *	+ dos' media descriptor byte ...
 */

struct dosmedesb {

	BYT		dmd_val ;
	char *	DMD_TXT ;

} ;

TYP		struct dosmedesb		DOSMEDESB ;

DOSMEDESB	dosmeds [] = {

	{ 0xf0 , "3.5\"  , 18 setores , 2 lados"				} ,
	{ 0xf8 , "disco fixo"									} ,
	{ 0xf9 , "5.25\" , 15 setores , 2 lados"				} ,
	{ 0xfc , "5.25\" ,  9 setores , 1 lado"					} ,
	{ 0xfd , "5.25\" ,  9 setores , 2 lados"				} ,
	{ 0xfe , "5.25\" ,  8 setores , 1 lado"					} ,
	{ 0xff , "5.25\" ,  8 setores , 2 lados"				} ,

	{ 0x00 , "media descriptor byte invalido !"			} ,

	{ 0xf9 , "3.5\"  ,  9 setores , 2 lados"				} ,
	{ 0xfd , "8\"    ,  1 lado , densidade simples"			} ,
	{ 0xfe , "8\"    ,  1 lado"								} ,
	{ 0xfe , "8\"    ,  2 lados"							} ,

	{ 0x00 , "media descriptor byte invalido !"			}

} ;

/*_______________________________________________________________________
 *
 *	+ notes on clusters ...
 *
 *	+	if ( tot_clusters < 4087 )
 *			use12bitFAT = TRUE ;
 *
 *	+ reserved cluster (x) : x >= 0xfff0 && x <= 0xfff6
 *	+ last cluster (x)     : x >= 0xfff8 && x <= 0xffff
 *	+ cluster # limits must be anded w/ 0x0fff (12 bit fats)
 *
 *	+ tracking down through a 12-bit FAT ... :
 *
 *		+ read all FAT sectors 2 mem_buf_fat (b4 anything) ...
 *
 *		+ clun = dosdirentbuf.dde_clu ;
 *
 *		+ test if clun is outside volume boundaries ...
 *
 *		+ oddclu = clun & 0x01 ;
 *
 *		+ clun = ( clun * 3 ) / 2 ; $$$ clun <<= 1 ; on 16-bit FATs $$$
 *
 *		+ xclun = * ( (int *) (fatbuf + clun) ) ;
 *
 *		+ if ( oddclu )
 *			xclun >>= 4 ;
 *
 *		+ xclun &= 0x0fff ;
 *
 *		+ if ( DOS_RESCLUS ( xclun ) ) {
 *			no_more_clusters, end_of_file ;
 *		  } else {
 *			nextclus = xclun ;
 *		  }
 *
 *	+ 2 convert cluster # 2 logical sector # ... :
 *
 *		+ ini_sectors =   1 $$$ boot $$$
 *		                + ( no_of_FATs * sectors_per_FAT )
 *		                + ( ( #ofrootdirents * DDESIZ ) / bytspersector ) ;
 *
 *		+ lsn = ( ( clun - 2 ) * sectors_per_cluster ) + ini_sectors ;
 *
 *	+ fixed disk partitions stuff 'll be added only when implementing
 *	  the "quickest log" on dos' [hard] disks ...
 *
 *	+ if (-vflg) list FAT entries 0 & 1 just for the sake of curiosity
 *
 *	+ encode 2 cluster #s into a pair of FAT entries ... :
 *
 *		           +---------+   +---------+
 *		1st clus # | ? 1 2 3 |   | ? 4 5 6 | 2nd clus #
 *		           +---------+   +---------+
 *		               | | |         | | |
 *		               | | | +-----------+
 *		               | | | |       | |
 *		               +-----------+ | |
 *		                 | | |     | | |
 *		                 V V V     V V V
 *		              +---------+---------+
 *		1st FAT entry |  2 3 6  |  1 4 5  | 2nd FAT entry
 *		              +---------+---------+
 *		               \_________________/
 *		                (3-byte FAT pair)
 *_______________________________________________________________________
 */

# define	DOS_FREECLUS		0x0000			/* free cluster ...		*/
# define	DOS_BADCLUS			0x0ff7			/* bad  cluster ...		*/

/*_______________________________________________________________________
 *	+ defines ...
 */

# define	DOS_SECSIZ			   512
# define	DDESIZ				(sizeof (DOSDIRENT))

/*_______________________________________________________________________
 *
 *	+ macros :
 *
 *	+ map cluster # to logical sector # ,
 *	+ last cluster of file/dir (12-bit FAT) ,
 *	+ ...
 */

# define	CN2LSN(X)			(((X-2)*clusect)+inisect)
# define	LASTCLUS(X)			(((X)>=0x0ff8)&&((X)<=0x0fff))

/*_______________________________________________________________________
 *	+ globals ...
 */

int		dfd ;							/* disk file descriptor			*/
int		argk ;
int		vflg ;
int		xsta ;							/* exit status					*/
int		doxcmd ;
int		secsiz ;						/* sector size					*/
int		bytsect ;						/* bytes per sector				*/
int		clusect ;						/* sectors per cluster			*/
int		ressect ;						/* reserved sectors				*/
int		noffats ;						/* # of FATs					*/
int		rootdes ;						/* root directory entries		*/
int		totsect ;						/* total sectors in log. vol.	*/
int		meddesc ;						/* media descriptor byte		*/
int		fatsect ;						/* sectors per FAT				*/
int		trksect ;						/* sectors per track			*/
int		nofhead ;						/* # of heads					*/
int		xtboots ;						/* extended boot signature		*/
int		fatbyts ;						/* FAT size in bytes ...		*/
int		fatotsect ;						/* all FATs' sectors			*/
int		rodirsect ;						/* root directory's sectors		*/
int		inisect ;						/* 1st data sector				*/
int		clubyts ;						/* bytes per cluster			*/
UWORD	atr ;

long	hidsect ;						/* hidden sectors				*/
long	volumid ;						/* binary volume id				*/

char	namok [20] ;

char *	drvn ;							/* drive name					*/
char *	drvid ;							/* drive id						*/
char *	bootsect ;						/* boot sector buffer			*/
char *	fatbuf ;						/* (whole) FAT buffer			*/
char *	clubuf ;						/* single cluster buffer		*/

char * * argp ;							/* argument (parameter) list	*/

char * drvs [] = {
	"a:",	"/dev/fd048",
	"A:",	"/dev/fd096",
	NOSTR,	NOSTR
} ;

/*_______________________________________________________________________
 *	+ prototypes ...
 */

void	enomem		(char *) ;
void	mtob		(char *, int, char *) ;
void	mkxnam		(char *, char *, char *) ;
void	linfos		(DOSDIRENT *) ;
void	dirarg		(char *) ;
void	dirany		(char *, char *, int) ;

int		dmatch	(char *, DOSDIRINFO *) ;

/*_______________________________________________________________________
 *
 *	+ dox machine ...
 *
 *		-v	: verbose
 *		-d	: directory
 *		-r	: read
 *		-w	: write
 *		-l	: list
 *
 *		a:	= 5.25" dd (360 KB)
 *		A:	= 5.25" hd (1.2 MB)
 *		a.	= 3.5"  dd (720 KB)
 *		A.	= 3.5"  hd (1.4 MB)
 */

void main (argc, argv) char * * argv ; {

	/*
	 *	+ locals ...
	 */

	register int	sk ;		/* sector count							*/
	register int	sn ;		/* sector number						*/
	int				grd ;
	char * *		tpp ;
	DOSBOOTSEC *	bpbp ;		/* bios parameter block ptr ...			*/
	DOSDIRINFO		xdibuf ;

	/*
	 *	+ ...
	 */

	if (argc == 1) {
ser :	/* syntax error ... */
		fprintf (stderr, "use : dox <drive:> -dlrw [nome ...]\n") ;
		exit (1) ;
	}

	/*
	 *	+ some initializations ...
	 */

	vflg = 0 ;
	xsta = 0 ;
	doxcmd = 0 ;
	argp = VZRO (char * *) ;
	drvn = VZRO (char *) ;
	drvid = "a:" ;
	secsiz = DOS_SECSIZ ;

	bootsect = malloc (512) ;
	if ( bootsect == VZRO (char *) )
		enomem ("o buffer do setor de boot") ;

	/*
	 *	+ command-line parsing ...
	 */

	while (*++argv) {
		--argc ;
		if (**argv == '-') {
			switch (*((*argv)+1)) {
				case 'v' :	++vflg ; break ;
				case 'd' :
				case 'l' :
				case 'r' :
				case 'w' :	if (doxcmd != 0)
								goto ser ;
							doxcmd = *((*argv)+1) ; break ;
				default  :	goto ser ;
			}
		} else {
			if (drvn == VZRO (char *)) {
				drvn = *argv ;
				continue ;
			}
			if (argp == VZRO (char * *)) {
				argp = argv ;
				argk = argc ;
			}
		}
	}

	/*
	 *	+ achieve disk status & information ... :
	 *	  + open (try) disk special file
	 *	  + load boot sector (bios parameter block)
	 *	    + 1st read a 512-byte sector
	 *	    + if (bytspersector > 512) load the rest ...
	 *	  + (alloc for &) load one whole FAT
	 *	  + what do we do w/ the root dir ???
	 */

	for ( tpp = drvs ; *tpp != VZRO (char *) ; tpp += 2 )
		if (strcmp (*tpp, drvn) == 0) {
			drvid = *(tpp+1) ;
			break ;
		}

	dfd = open (drvid, 2) ;
	if (dfd < 0) {
		fprintf (stderr, "dox: erro ao abrir %s\n", drvid) ;
		exit (2) ;
	}

	grd = read (dfd, bootsect, secsiz) ;
	if (grd != secsiz) {
		fprintf (stderr, "dox: erro ao ler setor de boot\n") ;
		exit (8) ;
	}

	bpbp = (DOSBOOTSEC *) bootsect ;
	mtob (bpbp->dbs_bps, 2, (char *) &bytsect) ;

	if (bytsect > secsiz) {
		bootsect = realloc (bootsect, bytsect) ;
		if ( bootsect == VZRO (char *) )
			enomem ("realocar o buffer do setor de boot") ;
		bpbp = (DOSBOOTSEC *) bootsect ;
		mtob (bpbp->dbs_bps, 2, (char *) &bytsect) ;
		if (lseek (dfd, 0L, 0) < 0L) {
			fprintf (stderr, "dox: erro de seek (%d)\n", 0) ;
			exit (16) ;
		}
		grd = read (dfd, bootsect, bytsect) ;
		if (grd != bytsect) {
			fprintf (stderr, "dox: erro ao reler setor de boot\n") ;
			exit (8) ;
		}
	}

	mtob (bpbp->dbs_bps, 2, (char *) &bytsect) ;
	mtob (bpbp->dbs_sal, 1, (char *) &clusect) ;
	mtob (bpbp->dbs_res, 2, (char *) &ressect) ;
	mtob (bpbp->dbs_fak, 1, (char *) &noffats) ;
	mtob (bpbp->dbs_rde, 2, (char *) &rootdes) ;
	mtob (bpbp->dbs_tos, 2, (char *) &totsect) ;
	mtob (bpbp->dbs_med, 1, (char *) &meddesc) ;
	mtob (bpbp->dbs_spf, 2, (char *) &fatsect) ;
	mtob (bpbp->dbs_spt, 2, (char *) &trksect) ;
	mtob (bpbp->dbs_hdk, 2, (char *) &nofhead) ;
	mtob (bpbp->dbs_his, 4, (char *) &hidsect) ;
	mtob (bpbp->dbs_ebs, 1, (char *) &xtboots) ;
	mtob (bpbp->dbs_vid, 4, (char *) &volumid) ;

	if (vflg) {
		printf ("OEM name & version ........ : \"%8.8s\"\n", bpbp->dbs_onv) ;
		printf ("bytes per sector .......... :  %8d\n", bytsect) ;
		printf ("sectors per cluster ....... :  %8d\n", clusect) ;
		printf ("reserved sectors .......... :  %8d\n", ressect) ;
		printf ("number of FATs ............ :  %8d\n", noffats) ;
		printf ("root directory entries .... :  %8d\n", rootdes) ;
		printf ("total sectors ............. :  %8d\n", totsect) ;
		printf ("media descriptor .......... :  %8x\n", meddesc & 0xff) ;
		printf ("sectors per FAT ........... :  %8d\n", fatsect) ;
		printf ("sectors per track ......... :  %8d\n", trksect) ;
		printf ("number of heads ........... :  %8d\n", nofhead) ;
		printf ("hidden sectors ............ :  %8ld\n", hidsect) ;
		printf ("extended boot signature ... :  %8x\n", xtboots) ;
		printf ("binary volume id .......... :  %8lx\n", volumid) ;
		printf ("volume label .............. : \"%11.11s\"\n", bpbp->dbs_vol) ;
	}

	fatbyts = fatsect * bytsect ;
	fatbuf = malloc (fatbyts) ;
	if ( fatbuf == VZRO (char *) )
		enomem ("o buffer da FAT") ;

	grd = read (dfd, fatbuf, fatbyts) ;
	if (grd != fatbyts) {
		fprintf (stderr, "dox: erro ao ler a FAT\n") ;
		exit (8) ;
	}

	fatotsect = fatsect * noffats ;
	rodirsect = ( rootdes * DDESIZ ) / bytsect ;
	inisect = 1 + fatotsect + rodirsect ;

	clubyts = clusect * bytsect ;
	if ((clubuf = malloc (clubyts)) == VZRO (char *))
		enomem ("o buffer de cluster") ;

	if (vflg) {
		printf ( "FAT sectors ............... :  %8d\n", fatotsect ) ;
		printf ( "root directory sectors .... :  %8d\n", rodirsect ) ;
		printf ( "first data sector ......... :  %8d\n", inisect ) ;
		printf ( "FAT entry # 0 ............. :  %8x\n", getfate (0) ) ;
		printf ( "FAT entry # 1 ............. :  %8x\n", getfate (1) ) ;
	}

	if (doxcmd == 'l') {

	} else if (doxcmd == 'r') {

	} else if (doxcmd == 'w') {

	} else if (doxcmd == 'd') {

		printf ("\n  Nome   Ext Tamanho   Data     Hora   ") ;
		printf ("Atr Clus Status\n") ;
		printf ("-------- --- ------- -------- -------- ") ;
		printf ("--- ---- --------------------\n") ;

		if (*argp == VZRO (char *)) {
			/*
			 *	to do a "dir on root", all we need is to scan
			 *	matching "*.*" (just "*") ...
			 */
# ifdef		COMMENT
			do {
				grd = dmatch ("*", &xdibuf) ;
				if (grd == -1) {
					fprintf (stderr, "nao achei %s\n", "*") ;
					break ;
				}
				linfos (&xdibuf) ;
			} while (grd > 0) ;
# endif		/* COMMENT */
			for ( sk = 0 ; sk < rodirsect ; ++sk ) {
				sn = (1 + fatotsect + sk) ;
				if (dirsn (sn, VZRO (char *)) < 0)
					break ;
			}
		} else {
			/*
			 *	the default method is to call dirget(*argp) for all
			 *	parms... but nicer would it be if a dir???(argp)
			 *	made just one scan on the dir sectors & let the
			 *	matching scan to the (smaller) list of parms. this
			 *	last approach would be much faster but a bit more
			 *	complicated to admin...
			 */
			while (*argp)
				dirarg (*argp++) ;
		}

	} /* endif (cmd == dir) */

	/*
	 *	+ epilog tasks ...
	 */

	close (dfd) ;
	exit (xsta) ;

} /* endof main() ... */

/*_______________________________________________________________________
 *	+ memory to binary (even-odd address glitch walkaround ...)
 */

void mtob (src, siz, dest) char * src , * dest ; {

	switch (siz) {
		case 1 : * ( (int  *) dest ) = * ( (char  *) src ) ; break ;
		case 2 : * ( (int  *) dest ) = * ( (short *) src ) ; break ;
		case 4 : * ( (long *) dest ) = * ( (long  *) src ) ; break ;
	}
}

/*_______________________________________________________________________
 *	+ get FAT entry # ...
 */

int getfate (fn) {

	short tw ;
	int oddfn ;

	if (fn > (totsect / clusect)) {
		fprintf (stderr, "dox: FAT entry # (%d) outside volume !\n", fn) ;
		return (-1) ;
	}

	oddfn = fn & 0x01 ;
	fn = (fn * 3) / 2 ;
	tw = *((short *) (fatbuf+fn)) ;

	if (oddfn)
		tw >>= 4 ;

	tw &= 0x0fff ; /* only 12-bit FATs 4 a while ... */

	return (tw) ;
}

/*_______________________________________________________________________
 *	+ build a filename based on dos' name + extension ...
 */

void mkxnam (dest, nam, ext) char * dest , * nam , * ext ; {

	register char * dp ;
	register char * tp ;
	register int bk ;

	dp = dest ;
	tp = nam ;
	bk = 8 ;

	while ( *tp != ' ' && bk ) {
		*dp++ = *tp++ ;
		--bk ;
	}

	tp = ext ;
	bk = 3 ;

	if (*tp != ' ') {
		*dp++ = '.' ;
		while ( *tp != ' ' && bk ) {
			*dp++ = *tp++ ;
			--bk ;
		}
	}

	*dp = '\0' ;
}

# ifdef		COMMENT

/*_______________________________________________________________________
 *	+ display directory entry info ...
 */

void linfos (dp) DOSDIRINFO * dp ; {

	register int atr = dp->ddi_atr ;

	printf ("%8.8s %3.3s ", dp->ddi_nam, dp->ddi_ext) ;
	printf ("%7ld ", dp->ddi_siz) ;
	printf ("%02d/%02d/%02d %02d:%02d:%02d  %02x ",
			dp->ddi_dtm.tm_mday, dp->ddi_dtm.tm_mon, dp->ddi_dtm.tm_year,
			dp->ddi_dtm.tm_hour, dp->ddi_dtm.tm_min, dp->ddi_dtm.tm_sec,
			atr) ;
	if (atr & DOS_SUBDIR)
		printf ("DIR ") ;
	if (atr & DOS_ARCHIV)
		printf ("ARQ ") ;
	if (atr & DOS_VOLABL)
		printf ("ROT ") ;
	if (atr & DOS_SYSTEM)
		printf ("SYS ") ;
	if (atr & DOS_HIDDEN)
		printf ("HID ") ;
	if (atr & DOS_RDONLY)
		printf ("RDO ") ;
	printf ("\n") ;
}

# endif		/* COMMENT */

/*_______________________________________________________________________
 *	+ display directory entry info ...
 */

void linfos (dp) DOSDIRENT * dp ; {

	atr = dp->dde_atr[0] & 0x00ff ;
	printf ("%8.8s %3.3s ", dp->dde_nam, dp->dde_ext) ;
	printf ("%7ld ", dp->dde_siz) ;
	printf ("%02d/%02d/%02d %02d:%02d:%02d  %02x %4d ",
			DOS_FDMDAY (dp->dde_dat),
			DOS_FDMON  (dp->dde_dat),
			DOS_FDYEAR (dp->dde_dat) + 80,
			DOS_FTHOUR (dp->dde_tim),
			DOS_FTMIN  (dp->dde_tim),
			DOS_FTSEC  (dp->dde_tim) * 2,
			atr, dp->dde_clu ) ;
	if (atr & DOS_SUBDIR)
		printf ("DIR ") ;
	if (atr & DOS_ARCHIV)
		printf ("ARQ ") ;
	if (atr & DOS_VOLABL)
		printf ("ROT ") ;
	if (atr & DOS_SYSTEM)
		printf ("SYS ") ;
	if (atr & DOS_HIDDEN)
		printf ("HID ") ;
	if (atr & DOS_RDONLY)
		printf ("RDO ") ;
	printf ("\n") ;
}

/*_______________________________________________________________________
 *	+ directory list given a sector # ...
 */

int dirsn (sn, fn) char * fn ; {

	int				grd ;
	long			bofs = (long) bytsect * (long) sn ;
	REG				int dx ;		/* directory entry index			*/
	REG				int dk ;		/* directory entry count			*/
	REG	UWORD		nab ;
	REG DOSDIRENT *	dp ;
	int				found ;
	int				really ;
	char			sectbuf [1024] ;

	if (lseek (dfd, bofs, 0) < 0L) {
		fprintf (stderr, "dox: erro de seek (%d)\n", dk) ;
		exit (16) ;
	}
	if ((grd = read (dfd, sectbuf, bytsect)) != bytsect) {
		fprintf (stderr, "dox: erro ao ler diretorio\n") ;
		exit (8) ;
	}
	if (fn == VZRO (char *)) {
		really = TRUE ;
	} else {
		really = FALSE ;
	}
	dp = (DOSDIRENT *) sectbuf ;
	dk = bytsect / DDESIZ ;

	for ( dx = 0 ; dx < dk ; ++dx , ++dp ) {

		nab = dp->dde_nam[0] & 0x00ff ;

		if (nab == DOS_EODIR) {
			if (really == FALSE)
				return (-2) ;
			return (-1) ;
		}
		if (nab == DOS_ERASED) {
			continue ;
		}
		if (nab == DOS_QMASK) {
			dp->dde_nam[0] = '?' ;
		}

		mkxnam (namok, dp->dde_nam, dp->dde_ext) ;

		if (fn != VZRO (char *)) {
			found = FALSE ;
			if (strcmp (namok, fn) == 0) {
				found = TRUE ;
				really = TRUE ;
			}
		} else
			found = TRUE ;

		if (found == FALSE)
			continue ;

		linfos (dp) ;

		if (really == TRUE && fn != VZRO (char *))
			return (0) ;

# ifdef		COMMENT
		if (atr & DOS_SUBDIR) {
			/*
			 *	+ process a dir cluster ...
			 *	+ until the next cluster # == e.o.d.
			 */
			dclun = dp->dde_clu ;
morclu :
			dnxcn = getfate (dclun) ;
			dsn = CN2LSN (dclun) ;
			for ( dsk = 0 ; dsk < clusect ; ++dsk ) {
				if (dirsn (dsn + dsk) < 0)
					break ;
			}
			if (! LASTCLUS (dnxcn)) {
				dclun = dnxcn ;
				goto morclu ;
			}
		} /* endif (entry is subdir) */
# endif		/* COMMENT */

	} /* endof for (dir entries) */

	if (really == FALSE && fn != VZRO (char *))
		return (-2) ;

	return (0) ;
}

/*_______________________________________________________________________
 *	+ dir on arg (enter if dir) ...
 */

void dirarg (argnam) char * argnam ; {

	REG char * tp ;
	REG char * ap ;
	REG char * np ;
	REG int depth ;
	char nambuf [80] ;
	char midbuf [20] ;

	depth = 0 ;
	np = nambuf ;
	ap = argnam ;
rex:
	tp = midbuf ;

	while (*ap != '\0' && *ap != '/') {
		*np++ = *ap ;
		*tp++ = *ap++ ;
	}

	*tp = *np = '\0' ;

	if (*ap == '/') {
		if (ckxdir (nambuf, midbuf, depth) < 0)
			return ;
		++depth ;
		*np++ = '/' ;
		goto rex ;
	} else {
		dirany (nambuf, midbuf, depth) ;
	}
}

/*_______________________________________________________________________
 *	+ chk existence of dir ...
 */

int ckxdir (fnam, snam, depth) char * fnam , * snam ; {

}

/*_______________________________________________________________________
 *	+ dir on file or dir (should enter if dir) ...
 */

void dirany (fnam, snam, depth) char * fnam , * snam ; {

	REG int sk ;
	REG int sn ;
	int grd ;

	if (depth) {

		/* search w/in "normal" dirs ... */

	} else {

		for ( sk = 0 ; sk < rodirsect ; ++sk ) {
			sn = (1 + fatotsect + sk) ;
			if ((grd = dirsn (sn, snam)) < 0) {
				if (grd == -2)
					fprintf (stderr, "dox: %s nao encontrado\n", fnam) ;
				else
					break ;
			}
		} /* endof for (dir sectors) */
	}
}

/*_______________________________________________________________________
 *	+ ...
 */

void enomem (what) char * what ; {

	fprintf (stderr, "dox: faltou memoria para %s\n", what) ;
	exit (4) ;
}

/************************************************************************
*																		*
*	text pattern matching with minimal wildcard treatment				*
*																		*
*	+ when fullblow is on, a buggy dilemma moves in : dir scans don't	*
*	  put an escaping '\' in front of chars like '$' ... so the match	*
*	  craps (& with due reason ...)										*
*																		*
************************************************************************/

# define  FASTSCAN
/*	# define  FULLBLOW	*/

int patmat (t, p) char * t , * p ; {
	REG char * x ;

	for ( ; *p ; ++p ) {
		switch (*p) {
			case '*' :
				x = p + 1 ;
# ifdef   FASTSCAN
				starloop:
					if (*t == *x)
						continue ;
					if (*++t)
						goto starloop ;
				if (*x)
					return (FALSE) ;
				return (TRUE) ;
# else    /* FASTSCAN */
				if (*x == '\0')
					return (FALSE) ;
				while (*t) {
					if (*t == *x)
						break ;
					++t ;
				}
				if (*t == '\0')
					return (FALSE) ;
				else
					continue ;
# endif   /* FASTSCAN */
			case '?' :
				if (*t == '\0')
					return (FALSE) ;
			break ;
# ifdef   FULLBLOW
			case '\\' :
				++p ;
				goto it ;
			case '$' :
				if (*t == '\0')
					return (TRUE) ;
				return (FALSE) ;
# endif   /* FULLBLOW */
			default :
it :
				if (*p != *t)
					return (FALSE) ;
			break ;
		}
		++t ;
	}
	if (*t)
		return (FALSE) ;
	return (TRUE) ;
}

# endif /* COMMENT */

/************************************************************************
*	+ end of trix' dos' stuff ...										*
************************************************************************/

/*
 * vi:tabstop=4
 */
