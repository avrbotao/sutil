/* setrange.c -- parse & setup lists & intervals */

# include "ascii.h"
# include "trix_abc.h"
# include <ctype.h>

int	setrange (str, rbuf, maxent, maxdigs, lowlim, uplim)

char *	str ;
int *	rbuf ;
int	maxent ;
int	maxdigs ;
int	lowlim ;
int	uplim ;

{
	register char * sp = str ;
	register int * rp = rbuf ;
	register int nd = 0 ;
	register int i ;
	register int inno = FALSE ;
	register int colon = FALSE ;
	register int comma = FALSE ;
	register int negno = FALSE ;
	register int tv ;
	char tb[20] ;

	for ( ; ; sp++ ) {

		if (isdigit (*sp)) {
			tb[nd++] = *sp ;

			if (inno) {
				if (nd > maxdigs) {
					return (-1) ;
				}
			} else {
				inno = TRUE ;
			}

			if (comma)
				comma = FALSE ;

		} else if (   *sp == SP || *sp == TAB || *sp == NUL
			   || *sp == COMMA || *sp == COLON ) {

			if (inno) {
				tb[nd] = NUL ;
				tv = atoi (tb) ;

				if (negno) {
					tv = -tv ;
					negno = FALSE ;
				}
				if (colon) {
					for ( i = *(rp-1) + 1 ;
					      i < tv ; i++ ) {

						if (rp -rbuf == maxent) {
							return (-4) ;
						}
						if (i < lowlim || i > uplim) {
							return (-8) ;
						}
						*rp++ = i ;
					}
					colon = FALSE ;
				}
				if (rp - rbuf == maxent) {
					return (-4) ;
				}
				if (tv < lowlim || tv > uplim) {
					return (-8) ;
				}
				*rp++ = tv ;
				nd = 0 ;
				inno = FALSE ;
			} else {
				if (*sp == SP || *sp == TAB) {
					continue ;
				}
			}

			if (*sp == COMMA) {
				if (comma || colon || negno || rp == rbuf) {
					return (-2) ;
				}
				comma = TRUE ;
			}

			if (*sp == COLON) {
				if (comma || colon || negno || rp == rbuf) {
					return (-2) ;
				}
				colon = TRUE ;
			}

			if (*sp == NUL) {
				if (comma || colon || negno || rp == rbuf) {
					return (-2) ;
				}
				break ;
			}

		} else if (*sp == HIFEN) {

			if (inno || negno) {
				return (-2) ;
			}
			if (comma) {
				comma = FALSE ;
			}
			negno = TRUE ;

		} else {
			return (-2) ;
		}
	}
	return (rp - rbuf) ;
}
