/*		 _______________________________________
 *		|										|
 *		|	external pf stuff ...		(avrb)	|
 *		|_______________________________________|
 */

# include <stdio.h>

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

# define	XPF_HEAD		'+'
# define	XPF_VAL 		'='
# define	XPF_CMD 		'$'

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

struct xpf_info {
	int		pi_fn ;
	char *	pi_id ;
	int		pi_flg ;
	int		pi_val ;
	char *	pi_cmd ;
} ;

typedef		struct xpf_info		XPF_INFO ;

struct xpf_ctrl {
	char *		pc_id ;
	int			pc_cnt ;
	XPF_INFO *	pc_pfl ;
} ;

typedef		struct xpf_ctrl		XPF_CTRL ;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

XPF_CTRL * xpf_list = (XPF_CTRL *) 0 ;
int xpfcnt ;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

int xpf_init (nam) char * nam ; {

	FILE * fp ;
	char buf [80] , word [80] ;
	char * wp , * tp ;
	XPF_CTRL * xp ;
	XPF_INFO * ip ;
	int j ;

	int		xpfno ;
	char *	xpfid ;
	int		xpflg ;
	int		xpfval ;
	char *	xpfcmd ;

	/*_______________________________________________________________
	**	open file.xpf ...
	*/

	fp = fopen (nam, "rb") ;

	if (fp == (FILE *) 0) {
		fprintf (stderr, "xpf_init: can't open %s\n", nam) ;
		return -1 ;
	}

	/*_______________________________________________________________
	**	open file.xpf ...
	*/

	while (fgets (buf, 80, fp)) {
		wp = buf ;

		/*___________________________________________________________
		**	skip comments & blank lines ...
		*/

		if (*wp == '#' || *wp == '\n' || *wp == '\r')
			continue ;

		/*___________________________________________________________
		**	grow pf rule head list ...
		*/

		if (*wp == XPF_HEAD) {
			if (xpf_list == (XPF_CTRL *) 0) {
				xp = (XPF_CTRL *) malloc (sizeof (XPF_CTRL)) ;

				if (xp == (XPF_CTRL *) 0) {
nm:					fprintf (stderr, "xpf_init: no memory\n", nam) ;
					return -1 ;
				}
				xpf_list = xp ;
				xpfcnt = 1 ;
			} else {
				j = (xpfcnt + 1) * (sizeof (XPF_CTRL)) ;
				xp = (XPF_CTRL *) realloc (xpf_list, j) ;

				if (xp == (XPF_CTRL *) 0)
					goto nm ;

				xpf_list = xp ;
				xp += xpfcnt++ ;
			}
			sscanf (tp+1, "%s", word) ;
			j = strlen (word) ; 
			tp = malloc (j) ;

			if (tp == (char *) 0)
				goto nm ;

			strcpy (tp, word) ;
			xp->pc_id  = tp ;
			xp->pc_cnt = 0 ;
			xp->pc_pfl = (XPF_INFO *) 0 ;
		}

		/*___________________________________________________________
		**	collect pf # ...
		*/

		rd = sgetword (word, &wp) ;

		if (rd < 0) {
			fprintf (stderr, "xpf_init: no pf # \n") ;
			return -1 ;
		}

		xpfno = atoi (word) ;

		/*___________________________________________________________
		**	collect label text (id) ...
		*/

		rd = sgetword (word, &wp) ;

		if (rd < 0) {
			fprintf (stderr, "xpf_init: no id (F%d)\n", xpfno) ;
			return -1 ;
		}

		j = strlen (word) ;
		tp = malloc (j) ;

		if (tp == (char *) 0)
			goto nm ;

		strcpy (tp, word) ;
		xpfid = tp ;

		/*___________________________________________________________
		**	collect flag ...
		*/

		rd = sgetword (word, &wp) ;

		if (rd < 0) {
			fprintf (stderr, "xpf_init: no flag (F%d)\n", xpfno) ;
			return -1 ;
		}

		xpflg = word[0] ;

		/*___________________________________________________________
		**	collect val or cmd ...
		*/

		rd = sgetword (word, &wp) ;

		if (rd < 0) {
			fprintf (stderr, "xpf_init: no val (F%d)\n", xpfno) ;
			return -1 ;
		}

		if (xpflg == XPF_VAL) {
			xpfval = atoi (word) ;
		} else if (XPFLG == XPF_CMD) {
			j = strlen (word) ;
			tp = malloc (j) ;

			if (tp == (char *) 0)
				goto nm ;

			strcpy (tp, word) ;
			xpfcmd = tp ;
		}

		/*___________________________________________________________
		**	grow pf list ...
		*/

		if (xp->pc_pfl == (XPF_INFO *) 0) {
			ip = (XPF_INFO *) malloc (sizeof (XPF_INFO)) ;

			if (ip == (XPF_INFO *) 0)
				goto nm ;

			xp->pc_pfl = ip ;
			xp->pc_cnt = 1 ;
		} else {
			j = (xp->pc_cnt + 1) * (sizeof (XPF_INFO)) ;
			ip = (XPF_INFO *) realloc (xp->pc_pfl, j) ;

			if (ip == (XPF_INFO *) 0)
				goto nm ;

			xp->pc_pfl = ip ;
			ip += xp->pc_cnt ;
			xp->pc_cnt += 1 ;
		}

		ip->pi_fn  = xpfno ;
		ip->pi_id  = xpfid ;

		if ( (ip->pi_flg = xpflg) == XPF_VAL )
			ip->pi_val = xpfval ;
		else if ( (ip->pi_flg = xpflg) == XPF_CMD )
			ip->pi_cmd = xpfcmd ;
	}

	fclose (fp) ;

	return 0 ;
}
