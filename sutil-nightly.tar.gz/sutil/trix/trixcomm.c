/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixcomm.c + interconnectivity & interoperability	|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */
# ifdef COMMENT
# include	"trix.h"
/*======================================================================*
 *	+ trixcommm (unix-to-unix) ...										*
 *======================================================================*/
void trixcommm () {

}
/*======================================================================*
 *	+ ...																*
 *======================================================================*/
/*	xft  [-vd]  -p  port  -sr  name		*/

# include <sys/types.h>
# include <termio.h>
# include <fcntl.h>
# include <stdio.h>
# include <signal.h>

# define  ACK		'\006'
# define  ETX		'\003'

# define  SACK		"\006"
# define  SNAK		"\025"

# define  MADFLG	"%s: mad flag '-%c'\n"
# define  USAGE		"\nuse:\t%s [-v] -p port -sr name\n\n"
# define  NOPORT	"%s: can't access port %s\n"
# define  BADNAM	"%s: can't access file %s\n"
# define  CANCEL	"%s: %s traped\n"

# define  IFLAGS	(BRKINT | IGNPAR | ISTRIP | IGNCR | ICRNL)
# define  OFLAGS	(OCRNL)
# define  CFLAGS	(B9600 | CS8 | CSTOPB | CREAD | CLOCAL)
# define  LFLAGS	(ISIG | ASCII)

int cfd, verb = 0, dbug = 0, rwob = 0, byk = 0, flag ;
char * what = "?", * port = VZRO , * name = VZRO, * swid = "xft" ;
FILE * tfp ;
struct termio currst, workst ;

int trapint () ;

main (argc, argv) char * * argv ; {

	signal (SIGINT, trapint) ;

	while (*++argv)
		if (**argv == '-')
			switch ( flag = *((*argv)+1) ) {

				case 'v' : verb = 1 ; break ;

				case 'd' : dbug = 1 ; break ;

				case 'p' : port = *++argv ; break ;

				case 's' :
					*what = 'r' ;
					name = *++argv ;
				break ;

				case 'r' :
					*what = 'w' ;
					name = *++argv ;
				break ;

				default : crap (MADFLG, flag) ; break ;
			}
	if (! (name && port))
		crap (USAGE, swid) ;

	if ((cfd = open (port, 2)) < 0)
		crap (NOPORT, port) ;

	if ((tfp = fopen (name, what)) < 0)
		crap (BADNAM, name) ;

	xft () ;
}

xft () {

	sup () ;

	if (*what == 'w')
		rcv () ;
	else
		xmt () ;

	rip () ;
}

sup () {

	ioctl (cfd, TCGETS, &currst) ;
	workst = currst ;

	workst.c_iflag = (IFLAGS) ;
	workst.c_oflag = (OFLAGS) ;
	workst.c_cflag = (CFLAGS) ;
	workst.c_lflag = (LFLAGS) ;
	workst.c_cc[VMIN] = 1 ;
	workst.c_cc[VPAGE] = 0 ;

	ioctl (cfd, TCSETS, &workst) ;
}

xmt () {
	register int byt ;

	while ((byt = fgetc (tfp)) != EOF) {
		++byk ;
		xmtbyt (byt) ;
	}
	xmtbyt (ETX) ;
}

xmtbyt (b) {
	char y, x = b & 0xff ;

	while (write (cfd, &x, 1) != 1)
		iodbg (x, "XB~") ;
	iodbg (x, "XB+") ;

	while (read (cfd, &y, 1) != 1)
		iodbg (y, "RE~") ;
	iodbg (y, "RE+") ;

	if (x != y) {
		while (write (cfd, SNAK, 1) != 1)
			iodbg (y, "XN~") ;
		iodbg (y, "XN+") ;
	} else {
		while (write (cfd, SACK, 1) != 1)
			iodbg (x, "XA~") ;
		iodbg (x, "XA+") ;
	}
}

rcv () {
	register int byt ;

	for ( ++byk ; (byt = rcvbyt ()) != ETX ; ++byk )
		fputc (byt, tfp) ;
}

rcvbyt () {
	char k, x ;

	do {
		while (read (cfd, &x, 1) != 1)
			iodbg (x, "RB~") ;
		iodbg (x, "RB+") ;

		while (write (cfd, &x, 1) != 1)
			iodbg (x, "XE~") ;
		iodbg (x, "XE+") ;

		while (read (cfd, &k, 1) != 1)
			iodbg (x, "RA~") ;
		iodbg (x, "RA+") ;

	} while (k != ACK) ;

	return (x) ;
}

trapint () {

	if (verb)
		crap (CANCEL, "SigINT") ;
	rip () ;
}

crap (msg, dat) char * msg, * dat ; {

	fprintf (stderr, msg, swid, dat) ;
	rip () ;
}

iodbg (v, s) char * s ; {

	if (! dbug)
		return ;
	fprintf (stderr, "#%5d '%02x' %3s ", byk, v, s) ;
	fflush (stderr) ;
}

rip () {

	ioctl (cfd, TCSETS, &currst) ;
	close (cfd) ; fclose (tfp) ;
	exit (31) ;
}
/*======================================================================*
 *	+ ...																*
 *======================================================================*/
/*	xmt	filename	/dev/tty00N	*/

# include <stdio.h>

main (argc, argv) char * * argv ; {
	int fd = open ( *(argv+1) , 0) ;
	int cfd = open ( *(argv+2) , 2 ) ;
	char iobuf [512] ;
	register char * bp ;
	register int iocnt ;
	register int xcnt, bcnt = 0 ;
	char echo ;

	if (fd < 0) {
		fprintf (stderr, "xmt: can't access %s\n", *(argv+1) ) ;
		exit (-1) ;
	}

	if (cfd < 0) {
		fprintf (stderr, "xmt: can't access %s\n", *(argv+2) ) ;
		exit (-1) ;
	}

	while (iocnt = read (fd, iobuf, 512)) {
		if (iocnt < 512)
			iobuf[iocnt++] = 26 ;
		printf ("\n") ;
		for ( bp = iobuf , xcnt = 0 ; xcnt < iocnt ; ++bp , ++xcnt ) {
			if (write (cfd, *bp, 1) != 1) {
				fprintf (stderr, "xmt: write error ") ;
				fprintf (stderr, "(block %d byte %d)\n",
					 bcnt, xcnt) ;
				continue ;
			}
			if (read (cfd, &echo, 1) != 1) {
				fprintf (stderr, "xmt: read ack error ") ;
				fprintf (stderr, "(block %d byte %d)\n",
					 bcnt, xcnt) ;
				continue ;
			}
			if (echo != *bp) {
				fprintf (stderr, "xmt: ack cmp error ") ;
				fprintf (stderr, "(block %d byte %d)\n",
					 bcnt, xcnt) ;
				continue ;
			}
			printf ("byte %5d\r", xcnt) ;
		}
		++bcnt ;
	}
	close (fd) ; close (cfd) ;
}
/*======================================================================*
 *	+ ...																*
 *======================================================================*/
/*	rcv	filename	/dev/tty00N	*/

# include <stdio.h>
# include <signal.h>

int fd, cfd ;

int sigbye () ;

main (argc, argv) char * * argv ; {
	register int xcnt = 0 ;
	char x ;

	fd = creat ( *(argv+1), 0600 ) ;
	cfd = open ( *(argv+2) , 2 ) ;

	if (fd < 0) {
		fprintf (stderr, "rcv: can't create %s\n", *(argv+1) ) ;
		exit (-1) ;
	}

	if (cfd < 0) {
		fprintf (stderr, "rcv: can't access %s\n", *(argv+2) ) ;
		exit (-1) ;
	}

	signal (SIGINT, sigbye) ;

	for ( ; ; ++xcnt ) {

		if (! (xcnt & 0xff))
			printf ("\n") ;

		fflush (stdout) ;

		printf ("byte # %5d\tRD", xcnt) ;

		if ((x = readbyte (cfd)) == -1) {
			printf ("ER\t'%c'%d'\n", x, x) ;
			continue ;
		} else
			printf ("OK\t'%c'%d'\tAK", x, x) ;

		if (write (cfd, &x, 1) != 1) {
			printf ("ER\n") ;
			continue ;
		} else
			printf ("OK\tWT") ;

		if (x == 26)
			break ;

		if (write (fd, &x, 1) != 1) {
			printf ("ER\n") ;
		} else
			printf ("OK\r") ;
	}
	close (fd) ; close (cfd) ;
}

readbyte (chan) {
	char y ;
	int s ;

# ifdef READ
	s = read (chan, &y, 1) ;
# else  READ
	s = y = getkey (chan) ;
# endif READ

	if (s == -1)
		return (-1) ;
	return (y) ;
}

sigbye () {

	close (fd) ; close (cfd) ;
	exit (2) ;
}
/*======================================================================*/
# endif /* COMMENT */
/*
 * vi:tabstop=4
 */
