
/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixwind.c + blessings window package ...			|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre V.R. Botao                       (1991)	|
 *		|_______________________________________________________|
 */

# include <stdio.h>

# ifdef DOS
# include <conio.h>
# include <io.h>
# endif /* DOS */

# include "trix.h"
# include "trixfunc.h"
# include "trixblue.h"
# include "trixwind.h"
# include "trixvdo.h"
# include "trixext.h"
# include "trixchrs.h"
# include	"trixterm.h"

EXT int tfd, vfd, vdotyp, gflg ;
EXT VSTAT vsbuf ;
EXT BYT xfram [] ;
EXT char * vrbp ;

# ifdef ANYX
EXT	char *		clbuf ;
# endif /* ANYX */

# ifdef		HPUX
# define	MAPCONS		0x00
# include	<stropts.h>
# endif		/* HPUX */

# ifdef		CYGWIN
# define	MAPCONS		0x00
int ioctl () ;
# endif		/* CYGWIN */

# ifdef		LINUX
# define	MAPCONS		0x00
# include	<sys/ioctl.h>
# endif		/* LINUX */

# ifdef		SUNX
# define	MAPCONS		0x00
# endif		/* SUNX */

# ifdef		SOLARIS
# define	MAPCONS		0x00
# endif		/* SOLARIS */

# ifdef		SIDIX
# define	MAPCONS		0x00
# endif		/* SIDIX */

# ifdef		SIX
# define	MAPCONS		0x00
# endif		/* SIX */

# ifdef		EDIX
# define	MAPCONS		0x00
# endif		/* EDIX */

# ifdef		AIX
# define	MAPCONS		0x00
# endif		/* AIX */

# ifdef		DIGIX
# define	MAPCONS		0x00
# endif		/* DIGIX */

# if		defined (FREEBSD) || defined (OPENBSD)
# define	MAPCONS		0x00
# endif		/* FREEBSD */

int wrd = 0 ;
int wwqclos ;
char wwqbuf [MAXSCRELM] ; /* SHOULD BE DYN/Y MALLOC'ED !!! */
char * wwqp ;

# define	VS_SCRSIZ	(vsbuf.vs_lins * vsbuf.vs_cols)

/*
 *		O-----------------------------------------------------------O
 *		|	+ the 'blessings' window package by bud		a.r.r.w.f.	|
 *		O-----------------------------------------------------------O
 *		|	+ if serial terminal i/o slows to crap, implement a		|
 *		|	  demand-buffering mechanism & a wwheat() 2 refresh !	|
 *		O-----------------------------------------------------------O
 */
void wwinit () {
	register WWINFO * wwp ;
    register SCRELM * wep ;
	register int x ;
	static SCRELM SE_SPAC = { ' ', WW_NORMAL } ; /* FIX 4 XNX */

# ifdef XTRC
	fprintf (trcfp, "wwinit()\r\n") ;
# endif

	wwp = (WWINFO *) malloc (sizeof (WWINFO)) ;

# ifdef DOS

	if (vstat (vfd, &vsbuf, 0) < 0) {
		printf ("VIDEO STATUS !\n") ;
		return ;
	}

	if (vsbuf.vs_flag & VS_TERM) { /* serial terminal */
		vdotyp = 't' ;
		stdweb = (SCRELM *) calloc (VS_SCRSIZ, sizeof (SCRELM)) ;
	} else { /* monitor */
		vdotyp = 'c' ;
		stdweb = MK_FP (0xb800, 0x0000) ;
	}

# else  /* ANYX */

# ifdef OLDSTYLE

	if (vdotyp == 't') { /* serial terminal */
		stdweb = (SCRELM *) calloc (MAXSCRELM, sizeof (SCRELM)) ;
	} else { /* monitor */
		vfd = open ("/dev/tty", O_WRONLY) ;
		vrbp = (char *) ioctl (vfd, MAPCONS, 0) ;
		ioctl (vfd, SW_VGA80x25, 0) ;
		stdweb = (SCRELM *) vrbp ;
	}

# else  /* VSTAT */

		vfd = open ("/dev/tty", O_RDWR) ;

        if (vstat (vfd, &vsbuf, 0) < 0) {
    	    fprintf (stderr, "\nTRX: VIDEO STATUS !\n") ;
            fflush (stderr) ;
            return ;
    	}

        if (vsbuf.vs_flag & VS_CONS) {
            vdotyp = 'c' ;
    		vrbp = (char *) (long) ioctl (vfd, MAPCONS, 0) ;
    		stdweb = (SCRELM *) vrbp ;
        } else {
            close (vfd) ;
            vdotyp = 't' ;
    		stdweb = (SCRELM *) calloc (VS_SCRSIZ, sizeof (SCRELM)) ;
        }

# endif /* OLDSTYLE */

# endif /* DOS */

	wwp->ww_atr = 0x07 ;
	wwp->ww_lin = wwp->ww_cy = 0 ;
	wwp->ww_col = wwp->ww_cx = 0 ;
    wwp->ww_siz = VS_SCRSIZ ;
	wwp->ww_wid = vsbuf.vs_cols ;
	wwp->ww_hei = vsbuf.vs_lins ;
	wwp->ww_sav = wep = (SCRELM *) malloc (wwp->ww_siz * sizeof (SCRELM)) ;
    if ( wep == (SCRELM *) NULL ) {
  	    fprintf (stderr, "\nTRX: VIDEO BUFFER !\n") ;
        fflush (stderr) ;
        return ;
   	}
	for ( x = 0 ; x < wwp->ww_siz ; ++x )
		if (vdotyp == 't') {
			*wep++ = *(stdweb+x) = SE_SPAC ;
		} else {
			*wep++ = *(stdweb+x) ;
		}
	stdww = wwp ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
void wwend () {
# ifdef WW_RESTORE_SCREEN
    register SCRELM * wep = stdww->ww_sav ;
    register int x ;
# endif /* WW_RESTORE_SCREEN */

# ifdef OLDSTYLE
	ioctl (vfd, SW_VGA80x25, 0) ;
# else  /* VSTAT */
    vstat (vfd, &vsbuf, VS_ORIG) ;
# endif /* OLDSTYLE */

# ifdef WW_RESTORE_SCREEN

# ifdef ANYX
    if (vdotyp == 't') { /* serial terminal */
		free ( (char *) stdweb ) ;
	} else { /* monitor */
    	for ( x = 0 ; x < stdww->ww_siz ; ++x )
	    	*(stdweb+x) = *wep++ ;
		close (vfd) ;
	}
# else  /* DOS */
	for ( x = 0 ; x < stdww->ww_siz ; ++x )
		*(stdweb+x) = *wep++ ;
# endif /* ANYX */

# else  /* WW_CLEAR_SCREEN */

	wweras () ;

# endif /* WW_RESTORE_SCREEN */

	free ( (char*) stdww ) ;
	stdww  = (WWINFO *) 0 ;
	stdweb = (SCRELM *) 0 ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
WWINFO * wwopen (l, c, w, h) int l, c, w, h ; {
	SCRELM far * web = stdweb ;
	SCRELM * wep ;
	WWINFO * wwp ;
	register int x, y ;
	int b = l + h ;
	int r = c + w ;

	if ((wwp = (WWINFO *) malloc (sizeof (WWINFO)))
			== (WWINFO *) 0) {
		printf ("wwopen: malloc !") ;
		return wwp ;
	}

	if ((wep = (SCRELM *) malloc (w * h * sizeof (SCRELM)))
			== (SCRELM *) 0) {
		free ( (char *) wwp ) ;
		printf ("wwopen: malloc !") ;
		return (WWINFO *) 0 ;
	}

	wwp->ww_lin = l ;
	wwp->ww_col = c ;
	wwp->ww_cy = l ;
	wwp->ww_cx = c ;
	wwp->ww_wid = w ;
	wwp->ww_hei = h ;
	wwp->ww_atr = WW_NORMAL /* 0x07 */ ;
	wwp->ww_sav = wep ;

	for ( y = l ; y < b ; ++y )
		for ( x = c ; x < r ; ++x )
			*wep++ = *(web+( y * stdww->ww_wid + x )) ;

	return wwp ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
void wwfill (wwp, v, a) WWINFO * wwp ; int v, a ; {
# ifdef OLD
	register int x, y ;
	SCRELM far * web = stdweb ;
	SCRELM z ;
	int b = wwp->ww_lin + wwp->ww_hei ;
	int r = wwp->ww_col + wwp->ww_wid ;

	z.se_byte = v ; z.se_attr = a ;
	for ( y = wwp->ww_lin ; y < b ; ++y )
		for ( x = wwp->ww_col ; x < r ; ++x ) {
			*(web+( y * stdww->ww_wid + x )) = z ;
			if (vdotyp == 't')
				wwputw (y, x, &z) ;
		}
# else  /* NU */
	register int x, y ;
# ifdef SLOWFILL
	for ( y = 0 ; y < wwp->ww_hei ; ++y )
		for ( x = 0 ; x < wwp->ww_wid ; ++x ) {
			wwgoyx (wwp, y, x) ;
			wwsatr (wwp, a) ;
			wwputc (wwp, v) ;
		}
# else  /* FASTFILL */
	REG int xat = wwp->ww_atr ;

	wwsatr (wwp, a) ;
	for ( y = 0 ; y < wwp->ww_hei ; ++y ) {
		wwgoyx (wwp, y, 0) ;
		for ( x = 0 ; x < wwp->ww_wid ; ++x ) {
			wwputq (wwp, v) ;
		}
	}
	wwsatr (wwp, xat) ;
# endif /* SLOWFILL */

# endif /* OLD */
}

/*
 *									O-------------------------------O
 *									|	erase (blank) a ww ...		|
 *									O-------------------------------O
 */

void wweras ( /* wwp */ ) /* WWINFO * wwp ; */ {
	REG	WWINFO * wwp = stdww ;
		SCRELM far * web = stdweb ;
	REG SCRELM * wep = web /* wwp->ww_sav */ ;
	FIX	SCRELM SE_SPAC = { ' ', WW_NORMAL } ; /* FIX 4 XNX */
	REG int x ;

# ifdef DOS
	clrscr () ;
# else  /* ! DOS */
	VPUTS ( clbuf ) ;
# endif /* DOS */

	for ( x = 0 ; x < wwp->ww_siz ; ++x )
# ifdef COMMENT
		if (vdotyp == 't') {
			*wep++ = *(stdweb+x) = SE_SPAC ;
		} else {
			*wep++ = *(stdweb+x) ;
		}
# else  /* 4 REAL */
		*wep++ = *(stdweb+x) = SE_SPAC ;
# endif /* COMMENT */
}

/*
 *		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */

void wwclos (wwp) WWINFO * wwp ; {
	SCRELM far * web = stdweb ;
	SCRELM * wep = wwp->ww_sav ;
	register int x, y ;
	int b = wwp->ww_lin + wwp->ww_hei ;
	int r = wwp->ww_col + wwp->ww_wid ;
	REG int xatr = stdww->ww_atr ;
	REG int aa = 0 ;

	if (vdotyp == 't') {
		wwqclos = TRUE ;
	}

	for ( y = wwp->ww_lin ; y < b ; ++y ) {
		if (vdotyp == 't') {
			wwqp = wwqbuf ; aa = 0 ;
			wwgoyx (stdww, y, wwp->ww_col) ;
		}
		for ( x = wwp->ww_col ; x < r ; ++x , ++wep ) {
			*(web+( y * stdww->ww_wid + x )) = *wep ;
			if (vdotyp == 't') {
			/*	wwputw (y, x, wep) ; */
				if (wep->se_attr != aa) {
					if (aa == WW_ALTCHRSET)
						wwsatr (stdww, WW_NORMAL) ;
					wwsatr (stdww, wep->se_attr) ;
					aa = wep->se_attr ;
				}
				*wwqp++ = wep->se_byte ;
			}
		}
		if (vdotyp == 't') {
			wwsatr (stdww, WW_NORMAL) ;
			wrd = write (TFD, wwqbuf, (int) (wwqp - wwqbuf)) ;
		}
	}

	if (vdotyp == 't') {
		wwqclos = FALSE ;
		wwsatr (stdww, WW_NORMAL) ;
		wwsatr (stdww, xatr) ;
	}

	free ( (char *) wwp->ww_sav ) ;
	free ( (char *) wwp ) ;
}
/*		|-----------------------------------------------------------|
 *		|	+ also can be accelerated w/ wwgoyx()+wwputq() ...		|
 *		|-----------------------------------------------------------|
 */
void wwputs (wwp, buf) WWINFO * wwp ; char * buf ; {

# ifdef OLD
	SCRELM far * web = stdweb ;
	SCRELM z ;
	register int x, y ;

	z.se_attr = wwp->ww_atr ;
	y = wwp->ww_cy ;
	x = wwp->ww_cx ;
	while (*buf) {
		z.se_byte = *buf ;
		if (vdotyp == 't')
			wwputw (y, x, &z) ;
		*(web+( y * stdww->ww_wid + x )) = z ;
		++buf ; ++x ;
	}
	wwp->ww_cx = x ;
# else  /* NU */
	/* register int x ; */

# ifdef WPUTRC
	fprintf (trcfp, "wwputs() : wwcx=%d\r\n", wwp->ww_cx) ;
# endif

	/* x = wwp->ww_cx ; */
	while (*buf) {
		wwputq (wwp, *buf) ;	/* wwputc */
		++buf ;					/* ++x ; */
	}
	/* wwp->ww_cx = x ; */
# endif /* OLD */
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */

void wwgoyx (wwp, l, c) WWINFO * wwp ; int l, c ; {

# ifdef GYXTRC
	fprintf (trcfp, "wwgoyx() : l=%d c=%d\r\n", l, c) ;
# endif

	wwp->ww_cy = wwp->ww_lin + l ;
	wwp->ww_cx = wwp->ww_col + c ;

	if (vdotyp == 't') {

# ifdef DOS

		gotoxy (1+(wwp->ww_cx), 1+(wwp->ww_cy)) ;

# else  /* ANYX */

		/* gotoxy (wwp->ww_cx, wwp->ww_cy) ; */

		locat (wwp->ww_cy, wwp->ww_cx) ;

# endif /* DOS */

	}
}

/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
void wwsatr (wwp, a) WWINFO * wwp ; int a ; {	/* SET ATTRIBUTE !		*/

# ifdef ANYX

# define	TERMEFFS

    REG UNS char e ;

# endif /* ANYX */

	if (vdotyp == 't') {

# ifdef		TERMEFFS
/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	+ old-style dispat() 4 ttys ...     |
 *		|_______________________________________|
 */
    	EXT char * * efon [] ;
	    EXT char * * efof [] ;
	    REG char * von = * ( efon [ a ] ) ;
	    REG char * vof = * ( efof [ a ] ) ;
			char tb [1024] ;
		REG char * tp = tb ;
		REG int    ts = 0 ;

		if (gflg) {
			if (a == VEAGCS) {
				a = VENORM ;
			}
		}

    	if (von != NOSTR) {
    		while (*von) {
    			*tp++ = *von++ ; ++ts ;
    		}
		}

/* - - - - - - - - - - - - - - - - - - - - - - - -
		if (gflg) {
			vof = NOSTR ;
		} else {
   - - - - - - - - - - - - - - - - - - - - - - - - */
			if ( a == VENORM ) {
				vof = * ( efof [ VEAGCS ] ) ;
			} else {
				vof = NOSTR ;
    		}
/* - - - - - - - - - - - - - - - - - - - - - - - -
		}
   - - - - - - - - - - - - - - - - - - - - - - - - */

    	if (vof != NOSTR) {
    		while (*vof) {
    			*tp++ = *vof++ ; ++ts ;
    		}
		}

		if (wwqclos) {
			memcpy (wwqp, tb, ts) ;
			wwqp += ts ;
		} else {

# ifdef SIDIX

			*tp++ = '\0' ;	VPUTS (tb) ;

# else  /* ! SIDIX */

	    	wrd = write (TFD, tb, ts) ;		/*	VPUTS (tb, ts) ;	*/

# endif /* SIDIX */

		}

# else  /* CONIO-IX */
/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	+ tc's conio.h stuff on *ix ...     |
 *		|_______________________________________|
 */
		switch (a) {
			case WW_NORMAL		:	normvideo () ;	break ;
			case WW_BLINK	 	:	blinkvideo () ;	break ;
			case WW_REVERSE 	:	revvideo () ;	break ;
			case WW_HIGHLIGHT	:	highvideo () ;	break ;
			case WW_UNDERLINE	:	undervideo () ;	break ;
# ifdef ANYX
			case WW_ALTCHRSET	:	agcsvideo () ;  break ;
# endif /* ANYX */
		}
# endif /* TERMEFFS */

	} else {
		/*	_______________________________________________
		 *	vdotyp == monitor
		 */
# ifdef ANYX

		switch (a) {
			case WW_NORMAL		:	e = 0x07 ;      break ;
			case WW_BLINK	 	:	e = 0x87 ;      break ;
			case WW_REVERSE 	:	e = 0x70 ;      break ;
			case WW_HIGHLIGHT	:	e = 0x0f ;      break ;
			case WW_UNDERLINE	:	e = 0x02 ;      break ;
			case WW_ALTCHRSET	:	e = 0x07 ;      break ;
			case WW_REVBLINK    :   e = 0xf0 ;      break ;
            default             :   e = a    ;      break ;
		}

        a = e ;

# else  /* DOS */

		textattr (a) ;

# endif /* ANYX */

    } /* endif monitor vs. terminal */

   	wwp->ww_atr = a ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
void wwcatr (wwp, a) WWINFO * wwp ; int a ; {	/* COMBINE ATTRIBUTE !	*/

	wwp->ww_atr |= a ;
	if (vdotyp == 't') {
		switch (a) {
			case WW_NORMAL		:	normvideo () ;	break ;
			case WW_BLINK	 	:	blinkvideo () ;	break ;
			case WW_REVERSE 	:	revvideo () ;	break ;
			case WW_HIGHLIGHT	:	highvideo () ;	break ;
			case WW_UNDERLINE	:	undervideo () ;	break ;
		}
	} else
		textattr (a) ;
}
/*		O-----------------------------------------------------------O
 *		|	must compatibilize w/ TERMINALS ! (VEAGCS) ...			|
 *		O-----------------------------------------------------------O
 */
void wwfram (wwp, atr) WWINFO * wwp ; int atr ; {
	register int w = wwp->ww_wid - 2 ;
	register int h = wwp->ww_hei - 2 ;
	register int i ;
	register int xat = wwp->ww_atr ;

/*	if (atr != WW_ALTCHRSET)	*/
		atr =  WW_ALTCHRSET ;

	wwsatr (wwp, atr) ;
	wwgoyx (wwp, 0, 0) ;
	wwputq (wwp, UPRLEFT) ;
	for ( i = 0 ; i < w ; ++i )
		wwputq (wwp, HORZBAR) ;
	wwputq (wwp, UPRIGHT) ;

	for ( i = 0 ; i < h ; ++i ) {
		wwgoyx (wwp, 1+i, 0) ;
		wwputq (wwp, VERTBAR) ;
		wwgoyx (wwp, 1+i, w+1) ;
		wwputq (wwp, VERTBAR) ;
	}

	wwgoyx (wwp, h+1, 0) ;
	wwputq (wwp, LWRLEFT) ;
	for ( i = 0 ; i < w ; ++i )
		wwputq (wwp, HORZBAR) ;
	wwputq (wwp, LWRIGHT) ;

	if (vdotyp == 't')
		wwsatr (wwp, WW_NORMAL) ;

	wwsatr (wwp, xat) ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
void wwputc (wwp, c) WWINFO * wwp ; int c ; {
	REG int x, y ;
	REG SCRELM far * web = stdweb ;
	SCRELM z ;
	FIX char b ;

	z.se_attr = wwp->ww_atr ;
	z.se_byte = c ;
	y = wwp->ww_cy ;
	x = wwp->ww_cx ;
	*(web+( y * stdww->ww_wid + x )) = z ;
	if (vdotyp == 't') {
# ifdef DOS
		gotoxy (x+1, y+1) ;
# else  /* ANYX */
		locat (y, x) ;
# endif /* DOS */
		/* putch (c) ; */
		b = c ; wrd = write (TFD, &b, 1) ;
	}
	wwp->ww_cx += 1 ;
}
/*		O-----------------------------------------------------------O
 *		|	...														|
 *		O-----------------------------------------------------------O
 */
void wwputq (wwp, c) WWINFO * wwp ; int c ; {
	REG SCRELM far * web = stdweb ;
	SCRELM z ;
	FIX char b ;

	z.se_attr = wwp->ww_atr ;
	z.se_byte = c ;
	*(web+( wwp->ww_cy * stdww->ww_wid + wwp->ww_cx )) = z ;
	if (vdotyp == 't') {
# ifdef SIDIX /* ? COMMENT ? */
		char bb [2] ;
		bb[0] = c ; bb[1] = '\0' ; VPUTS (bb) ;
# else  /* ! SIDIX */
		/* putch (c) ; */
		b = c ; wrd = write (TFD, &b, 1) ;
# endif /* SIDIX */
	}
	wwp->ww_cx += 1 ;
}
/*		O-----------------------------------------------------------O
 *		|	+ 2 b used (mostly) by wwclos() ...						|
 *		O-----------------------------------------------------------O
 */
void wwputw (l, c, xp) int l, c ; SCRELM * xp ; {
	REG SCRELM far * web = stdweb ;
	REG int ind ;
	REG int xatr = stdww->ww_atr ;
	FIX char b ;

	if (vdotyp == 't') {
# ifdef DOS
		gotoxy (c+1, l+1) ;
# else  /* ANYX */
		locat (l, c) ; /* gotoxy (c, l) ; */
# endif /* DOS */
		wwsatr (stdww, xp->se_attr) ;
		/* putch (xp->se_byte) ; */
		b = xp->se_byte ;
		if (wwqclos) {

		} else
			wrd = write (TFD, &b, 1) ;
		wwsatr (stdww, xatr) ;
	} else {
		ind = l * stdww->ww_wid + c ;
		*(web+ind) = *xp ;
	}
}
/*		O-----------------------------------------------------------O
 *		|	+ dispat() equivalent on blessings ...					|
 *		O-----------------------------------------------------------O
 */
void wwdisp (wwp, lin, col, buf, atr) WWINFO * wwp ; char * buf ; int lin, col, atr ; {
/*	REG int xat = wwp->ww_atr ; */

# ifdef WDITRC
	fprintf (trcfp, "wwdisp() : lin=%d col=%d len=%d\r\n", lin, col, strlen (buf)) ;
# endif

	wwgoyx (wwp, lin, col) ;
	wwsatr (wwp, atr) ;
	wwputs (wwp, buf) ;

	if (atr != WW_NORMAL)
		wwsatr (wwp, /* xat */ WW_NORMAL) ;
}

# ifdef COMMENT
/*		O-----------------------------------------------------------O
 *		|	test drive apparatus ...								|
 *		O-----------------------------------------------------------O
 */
void hfilww (void) ;
void vfilww (void) ;
void rfilww (int) ;
void kfilww (int) ;
void demoww (void) ;
void menuww (void) ;
void clrww  (void) ;

void main (argc, argv) char * * argv ; {
	int k ;

	wwinit () ;

	for ( ; ; ) {
		k = getch () ;
		switch (k) {
			case 'R' :
			case 'r' : rfilww (k) ; break ;
			case 'h' : hfilww () ; break ;
			case 'v' : vfilww () ; break ;
			case 'c' : clrww () ; break ;
			case 'w' : demoww () ; break ;
			case 'm' : menuww () ; break ;
			case 'q' : wwend () ; return ;
			default  : kfilww (k) ; break ;
		}
	}
/*	wwend () ;	*/
}

void hfilww () {
	SCRELM far * web = stdweb ;
	static SCRELM x = { ' ' , 0x07 } ;
	int i ;

	for ( i = 0 ; i < stdww->ww_siz ; ++i ) {
		x.se_attr = x.se_byte = i & 0xff ;
		*web++ = x ;
		if (vdotyp == 't')
			wwputw (i / stdww->ww_wid, i % stdww->ww_wid, &x) ;
	}
}

void vfilww () {
	SCRELM far * web = stdweb ;
	SCRELM x ;
	int ind, lin, col, i = 0 ;

	for ( col = 0 ; col < stdww->ww_wid ; ++col ) {
		for ( lin = 0 ; lin < stdww->ww_hei ; ++lin ) {
			x.se_attr = i & 0x7f ;
			x.se_byte = i++ % stdww->ww_hei + 'a' ;
			ind = lin * stdww->ww_wid + col ;
			*(web+ind) = x ;
			if (vdotyp == 't')
				wwputw (lin, col, &x) ;
		}
	}
}

void clrww () {
	SCRELM far * web = stdweb ;
	static SCRELM x = { ' ' , 0x07 } ;
	int i ;

	for ( i = 0 ; i < stdww->ww_siz ; ++i ) {
		*web++ = x ;
		if (vdotyp == 't')
			wwputw (i / stdww->ww_wid, i % stdww->ww_wid, &x) ;
	}
}

void rfilww (r) {
	SCRELM far * web = stdweb ;
	SCRELM x ;
	int i, l, c, n = MAXSCRELM ;

	if (vdotyp == 't')
		n = MAXSCRELM ;
	for ( i = 0 ; i < n ; ++i ) {
		x.se_byte = rand () & 0xff ;
		if (x.se_byte == 7) x.se_byte = '@' ; /* interesting ... */
		if (r == 'R')
			x.se_attr = rand () & 0xff ;
		else
			x.se_attr = rand () & 0x7f ;
		c = rand () % stdww->ww_wid ;
		l = rand () % stdww->ww_hei ;
		*(web+(l*stdww->ww_wid+c)) = x ;
		if (vdotyp == 't')
			wwputw (l, c, &x) ;
	}
}

void kfilww (k) {
	SCRELM far * web = stdweb ;
	SCRELM x ;
	int i ;

	x.se_byte = k ;

	if (vdotyp == 't')
		x.se_attr = WW_NORMAL ;
	else
		x.se_attr = 0x07 ;
	for ( i = 0 ; i < stdww->ww_siz ; ++i ) {
		*web++ = x ;
		if (vdotyp == 't')
			wwputw (i / stdww->ww_wid, i % stdww->ww_wid, &x) ;
	}
}

void demoww () {
	static int fil , atr ;
	int lin, col, wid, hei, maxw, maxh ;
	WWINFO * wwp ;
	int n = 80 ;
	long k ;

	do {
		/* do */ lin = rand () % 23 ;
		/* while (lin > 22 || lin <= 0) ; */
		/* do */ col = rand () % 79 ;
		/* while (col > 78 || col <= 0) ; */
		maxw = (stdww->ww_wid - 1) - col ;
        maxh = (stdww->ww_hei - 1) - lin ;
		/* do */ hei = 1 + (rand () % maxh) ;
		/* while (hei > maxh || hei <= 0) ; */
		/* do */ wid = 1 + (rand () % maxw) ;
		/* while (wid > maxw || wid <= 0) ; */
		atr = rand () & 0x7f ;
		fil = ( rand () % 94 ) + 32 ;
		wwp = wwopen (lin, col, wid, hei) ;
		wwfill (wwp, fil, atr) ;
		for ( k = 0L ; k < 70000L ; ++k ) ;
		wwclos (wwp) ;
	} while (n-- > 0) ;
}
# endif /* COMMENT */

/*
 * vi:nu tabstop=4
 */
