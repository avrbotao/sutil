/*                	 _______________________________________________
 *  ______________	|												|
 * /\  ___________\	|	TRIX + file system administration utility	|
 * \ \ \________  /	|_______________________________________________|
 *  \ \ \    / / /	|                                               |
 *   \ \ \  / / /	|	comparisons' stuff ...						|
 *    \ \ \/ / /	|_______________________________________________|
 *     \ \/ / /		|												|
 *		\  / /		|	TRIX & its logo are registered trademarks	|
 *		 \/_/		|	of Alexandre Victor Rodrigues Botao (1991)	|
 *					|_______________________________________________|
 */

# include <stdio.h>
# include <string.h>

# include "trixasci.h"
# include "trix.h"
# include "trixstd.h"
# include "trixkeys.h"
# include "trixfunc.h"
# include "trixext.h"
# include "trixtext.h"
# include "trixaloc.h"

EXT		int			( * filcmp ) () ;
EXT		int			ascord ;
EXT		DIRDAT * *	wablst ;
/*	 ___________________________________________________________________
 *	|																	|
 *	|	+ trixord : ...													|
 *	|___________________________________________________________________|
 */
int trixord (who) int who ; {
	REG int ( * tmpcmp ) ()		;	/* tmp comparison routine ptr ...	*/
	REG int grd ;
	REG char * ordtxt ;
	REG char * ordwho ;
	NEW	char tb [80] ;
	NEW	char xb [80] ;

ord :
	if (ascord)
		ordtxt = T_ORDASC ;
	else
		ordtxt = T_ORDESC ;

	if (who == 'o')
		ordwho = T_ORDCUR ;
	else
		ordwho = T_ORDALL ;

	sprintf (tb, T_ORDBAN, ordtxt) ;
	sprintf (xb, T_ORDWHO, ordwho) ;
	grd = askany (xb, tb) ;

	if (grd == ESC)
		return ESC ;

	switch (grd) {

		case 'o' :
		case 'O' :	ascord = ! ascord ; goto ord ;

		case 'n' :
		case 'N' :	tmpcmp = namcmp ; break ;

		case 'e' :
		case 'E' :	tmpcmp = extcmp ; break ;

		case 's' :
		case 'S' :
		case 't' :
		case 'T' :	tmpcmp = sizcmp ; break ;

		case 'c' :
		case 'C' :
		case 'a' :
		case 'A' :
		case 'd' :
		case 'D' :
		case 'm' :
		case 'M' :
		case 'g' :
		case 'G' :	tmpcmp = timcmp ; break ;

# ifdef		ANYX
		case 'l' :
		case 'L' :
		case 'r' :
		case 'R' :	tmpcmp = torcmp ; break ;
# endif		/* ANYX */
		case '?'  :
		case KF1 :	hyxhelp ("ordir") ; goto ord ;
		default	 :	honk () ; goto ord ;
	}
	filcmp = tmpcmp ; return 0 ;
}
/*	 ___________________________________________________________________
 *	|																	|
 *	|	+ trixsort : ...												|
 *	|___________________________________________________________________|
 */
void trixsort () {
	REG DIRDAT * *	wabp = wablst ;
	REG DIRDAT * *	wabe = wabp + (int) (TOTDIRS) ;
	REG DIRDAT *	dp ;

	for ( ; wabp < wabe ; ++wabp ) {
		dp = *wabp ;
		qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
				sizeof (FILDAT *), filcmp ) ;
	}
}
/************************************************************************
* dilcmp + dir lst cmp ...												*
************************************************************************/
int dilcmp (a, b) DIRDAT * * a, * * b ; {
# ifdef   CINL
	REG char * pa = (*a)->dd_nam ;
	REG char * pb = (*b)->dd_nam ;

	for ( ; ; ++pa , ++pb ) {
		if ( *pa != *pb )
			return ( *pa - *pb ) ;
		if ( *pa == NUL )
			return ( 0 ) ;
	}
# else    /* CINL */
	return ( strcmp ( (*a)->dd_nam, (*b)->dd_nam ) ) ;
# endif   /* CINL */
}

/************************************************************************
* namcmp + sort by filename												*
************************************************************************/

int namcmp (a, b) FILDAT * * a, * * b ; {
# ifdef   CINL
	REG char * pa = (*a)->fd_nam ;
	REG char * pb = (*b)->fd_nam ;

	for ( ; ; ++pa , ++pb ) {
		if ( *pa != *pb ) {
			if (ascord) {
				return ( *pa - *pb ) ;
			} else {
				return ( *pb - *pa ) ;
			}
		}
		if ( *pa == NUL ) {
			return 0 ;
		}
	}
# else    /* CINL */
	return ( strcmp ( (*a)->fd_nam, (*b)->fd_nam ) ) ;
# endif   /* CINL */
}

/************************************************************************
* extcmp + sort by extension											*
************************************************************************/

int extcmp (a, b) FILDAT * * a, * * b ; {
	REG int rd ;
	REG char * pa = (*a)->fd_nam ;
	REG char * pb = (*b)->fd_nam ;
	REG char * da = (char *) 0 ;
	REG char * db = (char *) 0 ;

	da = strchr (pa, DOT) ;
	db = strchr (pb, DOT) ;

	if (da && db) {
		rd = strcmp (da, db) ;
		if (rd == 0)
			rd = strcmp (pa, pb) ;
		if (rd == 0)
			return 0 ;
		if (ascord)
			return rd ;
		else
			return -rd ;
	} else if (da || db) {
		if (da != 0)
			rd = 1 ;
		else
			rd = -1 ;
		if (ascord)
			return rd ;
		else
			return -rd ;
	} else {
		rd = strcmp (pa, pb) ;
		if (rd == 0)
			return 0 ;
		if (ascord)
			return rd ;
		else
			return -rd ;
	}
}

/*
 *  |-----------------------------------------------|
 *  |   + histcmp : history head comparison ...     |
 *  |-----------------------------------------------|
 */

int histcmp (a, b) void * a , * b ; {
	REG HYDAT * ya = (HYDAT *) a ;
	REG HYDAT * yb = (HYDAT *) b ;

	return strcmp ( ya->hy_nam , yb->hy_nam ) ;
}

# ifdef ANYX

/*
 *  |-----------------------------------------------|
 *  |   + keycmp + sort by key signature ...        |
 *  |-----------------------------------------------|
 */

int keycmp (a, b) void * a , * b ; {
	register KEYINFO * pa = (KEYINFO *) a ;
	register KEYINFO * pb = (KEYINFO *) b ;

	return strcmp (pa->ki_sig, pb->ki_sig) ;
}

/*
 *  |-----------------------------------------------|
 *  |   + owncmp : owner-id comparison ...          |
 *  |-----------------------------------------------|
 */

int owncmp (a, b) void * a , * b ; {
    REG OWNDAT * oa = (OWNDAT *) a ;
    REG OWNDAT * ob = (OWNDAT *) b ;

    return ( (oa->od_uid) - (ob->od_uid) ) ;
}

/*
 *  |-----------------------------------------------|
 *  |   + grpcmp : group-id comparison ...          |
 *  |-----------------------------------------------|
 */

int grpcmp (a, b) void * a , * b ; {
    REG GRPDAT * ga = (GRPDAT *) a ;
    REG GRPDAT * gb = (GRPDAT *) b ;

    return ( (ga->gd_gid) - (gb->gd_gid) ) ;
}

# endif /* ANYX */

/************************************************************************
* sizcmp + sort by size													*
************************************************************************/

int sizcmp (a, b) FILDAT * * a, * * b ; {
	REG int rd ;
	REG long sa = (*a)->fd_stabuf.STASIZ ;
	REG long sb = (*b)->fd_stabuf.STASIZ ;

	if (sa == sb)
		return 0 ;
	if (sa > sb)
		rd = 1 ;
	else
		rd = -1 ;
	if (ascord)
		return rd ;
	else
		return -rd ;
}

/************************************************************************
* timcmp + sort by last-write-time										*
************************************************************************/

int timcmp (a, b) FILDAT * * a, * * b ; {
	REG int rd ;
	REG long ta = (*a)->fd_stabuf.STATIM ;
	REG long tb = (*b)->fd_stabuf.STATIM ;

	if (ta == tb)
		return 0 ;
	if (ta > tb)
		rd = 1 ;
	else
		rd = -1 ;
	if (ascord)
		return rd ;
	else
		return -rd ;
}

/************************************************************************
* torcmp + sort by last-access(read)-time ... (unixes only)				*
************************************************************************/

# ifdef		ANYX
int torcmp (a, b) FILDAT * * a, * * b ; {
	REG int rd ;
	REG long ta = (*a)->fd_stabuf.STALAR ;
	REG long tb = (*b)->fd_stabuf.STALAR ;

	if (ta == tb)
		return 0 ;
	if (ta > tb)
		rd = 1 ;
	else
		rd = -1 ;
	if (ascord)
		return rd ;
	else
		return -rd ;
}
# endif		/* ANYX */
/************************************************************************
*	text pattern matching with minimal wildcard treatment				*
*																		*
*	+ when fullblow is on, a buggy dilemma moves in : dir scans don't	*
*	  put an escaping '\' in front of chars like '$' ... so the match	*
*	  craps (& with due reason ...)										*
************************************************************************/
/*	# define	DOSPATMAT	*/
/*	# define	FULLBLOW	*/
/*	# define	STUPATMAT	*/ /* stupid pattern match algorythm ... */

# ifdef		STUPATMAT /* stupid method ... */

int patmat (t, p) char * t , * p ; {

	while (*p) {
		switch (*p) {
			case '?' :
				if (*t == '\0')
					return FALSE ;
				++p ; ++t ;
			break ;

			case '\0' :
				if (*t == '\0')
					return TRUE ;
				return FALSE ;

			case '*' :
				if ( *++p == '\0' )
					return TRUE ;
				while (*t != *p) {
					if (*t == '\0')
						return FALSE ;
					++t ;
				}
				++p ; ++t ;
			break ;

			default :
				if ( *t == '\0' || *t != *p )
					return FALSE ;
				++p ; ++t ;
			break ;
		}
	}
	if (*t == '\0')
		return TRUE ;
	return FALSE ;
}

# else  /* METHODS 4 GOOD */

# ifdef DOSPATMAT

int patmat (t, p) char * t , * p ; {

# define  FASTSCAN

	REG char * x ;

	for ( ; *p ; ++p ) {
		switch (*p) {
			case '*' :
				x = p + 1 ;
# ifdef   FASTSCAN
				starloop:
					if (*t == *x) {
						/*
						 *	serious (severe) bug ! fails if any pattern's
						 *	chars occurs w/o the rest matching ...
						 *	this solution (continue) is provisory.
						 *	the right thing to do is to scan the text
						 *	until find the last accurrance of whatever
						 *	comes past the '*' ...
						 */
						continue ;
					}
					if (*++t)
						goto starloop ;
				if (*x)
					return (FALSE) ;
				return (TRUE) ;
# else    /* FASTSCAN */
				if (*x == NUL)
					return (FALSE) ;
				while (*t) {
					if (*t == *x)
						break ;
					++t ;
				}
				if (*t == NUL)
					return (FALSE) ;
				else
					continue ;
# endif   /* FASTSCAN */

			case '?' :
				if (*t == NUL)
					return (FALSE) ;
			break ;

# ifdef   COMMENT
			case '[' :			/* character classes ...				*/
			break ;
# endif   /* COMMENT */

# ifdef   FULLBLOW
			case '\\' :
				++p ;
				goto it ;

			case '$' :
				if (*t == NUL)
					return (TRUE) ;

				return (FALSE) ;
# endif   /* FULLBLOW */

			default :
it :
				if (*p != *t)
					return (FALSE) ;
			break ;
		}
		++t ;
	}
	if (*t)
		return (FALSE) ;
	return (TRUE) ;
}
# else  /* UNIXPATMAT */
/*		+-------------------------------------------------------+
 *		|	pattern matching (unix style) + full blow ...		|
 *		+-------------------------------------------------------+
 */
#undef	DEBUG
int patmat (sp, pp) register char	* sp, * pp ;
{
	register short	sc,	/* Caracter da Cadeia */
			pc;	/* Caracter do Padrao */

	short		found,	/* Encontrou o Char. na lista */
			not;	/* Foi visto um '~' */
#ifdef	DEBUG
	printf ("DBG: str = '%s', pdr = '%s'\n", sp, pp);
#endif	/* DEBUG */
	/*
	 *	O Padrao pode conter '?', '*', '[....]', '~c', '~[....]'.
	 *	O Caracter '\' desfaz a acao especial dos caracteres
	 *	acima. A Comparacao e' do estilo do "sh", mas
	 *	o caracter '/' e' reconhecido por '?' e '*'.
	 *
	 *	Devolve:
	 *	    TRUE  => A Cadeia foi Reconhecida.
	 *	    FALSE => Nao foi Reconhecida, ou
	 *		 o Padrao contem um erro de Sintaxe.
	 */
	not = 0;
	/*
	 *	Malha Principal de Comparacao.
	 */
	for (/* sem inicializacao */; /* sem teste */; sp++, pp++)
	{
		switch (pc = pp[0])
		{
		    default:
				/*
				 *	O Padrao contem um caracter Normal ...
				 *	( diferente de '?', '*', '[', '~' e '\0' )
				 */
				if (pc == sp[0])
					continue;
				else
					return FALSE ;

		    case '\0':
				/*
				 *	O Padrao Acabou.
				 *	Atualmente implementa um reconhecimento exato
				 *	(ok se a string tambem acabou). idealmente
				 *	deveria retornar TRUE e deixar o teste de
				 *	fim da string p/ o coringa '$' ...
				 */
/* # define IDEAL */
# ifdef IDEAL
				return TRUE ;
# else  /* EXACT */
				if (sp[0] == '\0')
					return TRUE ;
				else
					return FALSE ;
# endif /* IDEAL */

		    case '?':
				if (sp[0] == '\0')
					return FALSE ;
				/*
				 *	Simula como se o "coringa" '?' fosse
				 *	igual ao caracter da cadeia.
				 */
				continue;

		    case '*':
				if ((++pp)[0] == '\0')
					return TRUE ;
				/*
				 *	Procura Sufixos em comum.
				 */
				while (sp[0] != '\0')
				{
					if (patmat (sp++, pp))
						return TRUE ;
				}
				return FALSE ;

		    case '\\':
				/*
				 *	Trata o caracter seguinte como normal.
				 */
				pp++;
				if ((pc = pp[0]) == '\0')
					return FALSE ;
				if ((sc = sp[0]) == '\0' || sc != pc)
					return FALSE ;
				continue;

		    case '~':
				pp++;
				if ((pc = pp[0]) == '\0')
					return FALSE ;

				if (pc != '[')
				{
					/*
					 *	Comparacao inversa.
					 */
					if ((sc = sp[0]) == '\0' || sc == pc)
						return FALSE ;
					continue;
				}
				/*
				 *	pp[0] == '['.
				 *	Prepara para [....] inverso.
				 */
				not = 1;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif

				/* Cai atraves */

		    case '[':
				found = 0;
				if ((sc = sp[0]) == '\0')
					return FALSE ;
				/*
				 *	Analisa a Sequencia '[....]'.
				 */
				while ((pc = (++pp)[0]) != '\0')
				{
					switch (pc)
					{
						default:
						if (pc == sc)
							found = 1;
						continue;

						case '-':
						if (pp[-1] == '[' || pp[1] == ']')
						{
							if (sc == '-')
								found = 1;
						}
						else
						{
							if (pp[-1] <= sc && sc <= pp[1])
								found = 1;
						}
						continue;

						case ']':
						if (found != not)
							goto nextchar;
						else
							return FALSE ;
					}	/* end switch [......] */
				}	/* end while [......] */
		}	/* end switch */
		/*
		 *	A Sequencia [....] terminou inesperadamente,
		 *	ou em todos os casos.
		 */
		return FALSE ;
nextchar:
		not = 0;
	}	/* end malha principal de comparacao */
}	/* end patmat */

# endif /* PATMAT (DOS x UNIX) */

# endif /* STUPATMAT */

/************************************************************************
*	inimfl + initialize matching file list ( to *[.*] ) ...				*
*																		*
*	instead of memcpy we could use an "optimizing" function that would	*
*	copy n pointers (moving pointers is faster than moving bytes ...)	*
*	+ the cast b4 fik in calloc must b substituted by a means to aloc	*
*	  the proper # of structs when > 64k (that in memcpy too) ...		*
*																		*
*	+ someone's forgeting the "-f <reg.expr.>" cmd lin parm, that is,	*
*	  this copy below should be a MATCH ! (...)							*
************************************************************************/

void inimfl (dp) DIRDAT * dp ; {

	if (dp->dd_mfl != (FILDAT * *) 0)
		return ;

	if (dp->dd_flg & UNREADIR)
		return ;

	dp->dd_mfl = (FILDAT * *)
					CALLOC ((unsigned)dp->dd_fik, sizeof (FILDAT *)) ;

	if (dp->dd_mfl == (FILDAT * *) 0)
		trixerr (T_FEWMEM, (char *)0, NOWHY, FATAL) ;

	/*_______________________________________________________________
	 *	every time a "Fam :" gets "*[.*]" , we must ...
	 */

	dp->dd_mfk = dp->dd_fik ;
	dp->dd_mfb = dp->dd_fib ;

# ifdef		XENIX

	memcpy ( ( char * ) dp->dd_mfl,
			 ( char * ) dp->dd_fil,
			 ( int ) ( dp->dd_fik * sizeof (FILDAT *) ) ) ;

# else		/* ! XENIX */

	memcpy (dp->dd_mfl, dp->dd_fil,
			((unsigned)dp->dd_fik * sizeof (FILDAT *))) ;

# endif		/* XENIX */

}

/************************************************************************
*																		*
************************************************************************/

/*
 * vi:nu ts=4
 */
