/************************************************************************
* abc 4 trix ...														*
************************************************************************/

/* # define  ABC */

# ifdef   DOS

# include <dir.h>
# include <dos.h>

# else    /* ANYX */

# include <sys/types.h>
# include <sys/stat.h>

#       define  STAT            stat
#       define  LSTAT           lstat
#       define  FSTAT           fstat

# ifdef SUNX
# include	<errno.h>
typedef		long long	_INT64_ ;
# endif

# ifdef AIX
# include	<errno.h>
typedef		long long	_INT64_ ;
# endif

# ifdef HPUX
# include	<errno.h>
typedef		long long	_INT64_ ;
#       undef  STAT
#       undef  LSTAT
#       undef  FSTAT
#       define  STAT            stat64
#       define  LSTAT           lstat64
#       define  FSTAT           fstat64
# endif

# ifdef LINUX
# include	<errno.h>
typedef		long long	_INT64_ ;
# endif

# ifdef		OPENBSD
# include	<errno.h>
typedef		long long	_INT64_ ;
# endif		/* OPENBSD */

# ifdef		FREEBSD
# include	<errno.h>
typedef		long long	_INT64_ ;
# endif		/* FREEBSD */

# ifdef		CYGWIN
# include	<errno.h>
typedef		long long	_INT64_ ;
# endif		/* CYGWIN */

# ifdef		XENIX
# include	<prototypes.h>
# endif		/* XENIX */

# ifdef		SIDIX
# define	void	int
# endif		/* SIDIX */

# ifdef EDIX
# ifdef EXT
# undef EXT
# endif /* EXT */
# endif /* EDIX */

# include "absd.h"

# endif   /* DOS, UNIX, XENIX */

/************************************************************************
* lingo ...																*
************************************************************************/

# define  elif		else if
# define  EVER		;;

# define  HERTZ
# define  MILISECONDS

/************************************************************************
* class & data prototypes ...											*
************************************************************************/

# define  FIX		static
# define  REG		register
# define  EXT		extern
# define  NEW		auto
# define  UNS		unsigned
# define  TYP		typedef

TYP	UNS char	UCHAR  ;
TYP	UNS short	USHORT ;
TYP	UNS short	UWORD  ;
TYP	UNS long	ULONG  ;

TYP	UNS			BIT    ;
TYP	UCHAR		BYT    ;

TYP	char		BOOL   ;	/* boolean, logical ...	*/

TYP	char *		STR ;
TYP	BYT *		ADR ;	/* memory address ...	*/

/************************************************************************
* unix, xenix, ... dependencies											*
************************************************************************/

# ifdef   ANYX

# define  DIRSEP	SLASH

TYP	struct STAT	STABLK ;

# endif   /* ANYX */

/************************************************************************
* dos dependencies														*
************************************************************************/

# ifdef   DOS

# define  DIRSEP	BACKSLASH

TYP	struct ffblk	STABLK ;

# endif   /* DOS */

/************************************************************************
* handy ...																*
************************************************************************/

# undef		TRUE
# undef		FALSE

# define  FALSE		(0)
# define  TRUE		(-1)		/* ( NOT FALSE )		*/

# define  VIDWID	    80
/* # define  BIGLIN	   140 */
# define  BLKSIZ	  4096
# define  GOOD		   (0)
# define  BAD		  (-1)

/* # define  NOTEXT(X)	(X == NOSTR || *X == NUL) */	/* risky ...	*/

/*------------------------------------------------------------------*/

# ifdef LINUX
/* # define VZRO _VZRO_ */
# endif

# undef   VZRO
# define VZRO(X) (X)0

# define  NOFILE	VZRO (FILE *)
# define  NOSTR		VZRO (STR)

/*
 * vi:tabstop=4
 */
