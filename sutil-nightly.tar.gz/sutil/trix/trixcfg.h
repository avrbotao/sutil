/************************************************************************
*	config file definitions (trixcfg.h) ...                             *
************************************************************************/
struct txtcod {
	char * *	tc_txt ;
	int			tc_cod ;
} ;
typedef  struct txtcod  TXTCOD ;

struct cfgit {
	char * *	ci_nam ;	/* identification					*/
	void *		ci_ptr ;	/* address							*/
	void *		ci_opt ;	/* choices or range					*/
	int			ci_flg ;	/* type, validation, ...			*/
} ;
typedef  struct cfgit  CFGIT ;

# define		CI_TXT			0x0001	/* char * *						*/
# define		CI_INT			0x0002	/* int  *						*/
# define		CI_LON			0x0004	/* long *						*/
# define		CI_BOL			0x0008	/* boolean int *				*/
# define		CI_COD			0x0010	/* string means int code ...	*/
# define		CI_DON			0x0020	/* parameter configured ok !	*/
# define		CI_ORD			0x0040	/* choice list is sorted (COD)	*/

# define		VVZRO			(void *) 0

# ifdef     XENIX
# define    VA(X)       (void *) &X
# else      /* GOOD */
# define    VA(X)       &X
# endif     /* XENIX */

# define		STDLOG			1
# define		FASTLOG			9
# define		SYSVLOG			5
# define		CURRSUP			1
# define		HOMESUP			2
# define		ROOTSUP			3

# ifdef ANSI
void    initcfg     ( CFGIT * ) ;
# else  /* OLD! */
void    initcfg     ( ) ;
# endif /* ANSI */
