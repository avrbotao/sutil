/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixren.c + rename files, directories, ...			|
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include	<stdio.h>
# include	<string.h>

# ifdef     ANYX
# include   <unistd.h>
# endif     /* ANYX */

# include	<stdlib.h>

# include	"trix.h"
# include	"trixkeys.h"
# include	"trixfunc.h"
# include	"trixaloc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixasci.h"

# define	HRENFIL		"Renomear Arquivo"		/* PROVISORY !!! */

EXT		char *		ghyid ;
/*	 ___________________________________________________________________
 *	|	+ trixren : rename file ...										|
 *	|___________________________________________________________________|
 */
int trixren (ffp) FILDAT * ffp ; {
	char nunam [40] ;
	char mb [80] ;
	char * xp ;
	int grd ;

# ifdef ANYX

    REG char * pp ;

    pp = ffp->fd_dir->dd_path ;

    if ( access (pp, W_OK) < 0 ) {
		grd = trixerr (T_ENWDIR, pp, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
	}

# endif /* ANYX */

/*
it :
*/
	sprintf (mb, "* Mudar o nome do arquivo \"%s\"", ffp->fd_nam) ;

	ghyid = "fin" ;
	grd = asktxt (mb, T_NUNAM, nunam, 40, 0) ;
	ghyid = NOSTR ;

	if (grd != ENTER)
		return ESC ;

	grd = nunam[0] ;
	if (grd == '\r' || grd == '\n' || grd == '\0')
		return ESC ;

# ifdef DOS
	strupr (nunam) ;
# endif /* DOS */
	strcpy (mb, ffp->fd_path) ;
	xp = strrchr (mb, DIRSEP) ;
	if (xp != (char *) 0) {
		++xp ;
	} else {
		xp = mb ;
	}
	strcpy (xp, nunam) ;
	if ( renfil ( ffp->fd_path , mb ) < 0 ) {
		grd = trixerr (T_ERENFIL, ffp->fd_nam, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
	}
	grd = (int) (xp - mb) ;
	free (ffp->fd_path) ;
	xp = malloc (strlen (mb) + 1) ;
	if (xp == (char *) 0)
		trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
	strcpy (xp, mb) ;
	ffp->fd_path = xp ; ffp->fd_nam = xp + grd ;

	return 0 ;
}
/*	 ___________________________________________________________________
 *	|	+ renfil : portably rename file ...								|
 *	|___________________________________________________________________|
 */
int renfil (old, new) char * old , * new ; {
# ifdef DOS
	return rename (old, new) ;
# else  /* ANYX */
	if (link (old, new) < 0)
		return -1 ;
	if (unlink (old) < 0) {
		unlink (new) ;
		return -1 ;
	}
	return 0 ;
# endif /* DOS */
}
/*	 ___________________________________________________________________
 *	|	+ rendir : rename directory ...									|
 *	|___________________________________________________________________|
 */
# ifdef COMMENT

void main (int, char * *) ;
int mvdir (char *, char *) ;

void main (argc, argv) char * * argv ; {
	char * dest ;
	char * argp ;
	int rd ;

	if (argc < 3) {
		printf ("\007use: mvdir velho novo\n") ;
		return ;
	}

	argp = *(argv+1) ;
	dest = *(argv+2) ;

	if ( ( rd = mvdir ( argp , dest ) ) != 0 )
		printf ("ERROR %02xh !\n", rd) ;
	else
		printf ("OK \n") ;
}

int mvdir (old, new) char * old, * new ; {
	int dosret ;
	union REGS iregs, oregs ;

	iregs.h.ah = 0x56 ;
	iregs.x.dx = (unsigned int) old ;
	iregs.x.di = (unsigned int) new ;

	dosret = intdos (&iregs, &oregs) ;

	if (dosret == 0x12)
		dosret = 0 ;

	return (dosret) ;
}
/*======================================================================*/
# endif /* COMMENT */
