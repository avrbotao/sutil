/*					 _______________________________________________
 *  ______________	|												|
 * /\  ___________\	|	TRIX + file system administration utility	|
 * \ \ \________  /	|_______________________________________________|
 *  \ \ \    / / /	|                                               |
 *   \ \ \  / / /	|	[recursive] log mechanism & strategy ...	|
 *    \ \ \/ / /	|_______________________________________________|
 *     \ \/ / /		|												|
 *		\  / /		|	TRIX & its logo are registered trademarks	|
 *		 \/_/		|	of Alexandre Victor Rodrigues Botao (1991)	|
 *					|_______________________________________________|
 */

# include <stdio.h>
# include <string.h>

# ifdef   DOS
# include <io.h>
# endif   /* DOS */

# include	"trix.h"

# ifdef		ANYX
#	ifdef		SYSVDIR
#		include	<dirent.h>
#	else		/* V7DIR */
#		include	<sys/dir.h>
#	endif		/* SYSVDIR */
#	include <unistd.h>
# endif		/* ANYX */

# include	"trixasci.h"
# include	"trixaloc.h"
# include	"trixstd.h"
# include	"trixblue.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixwig.h"

EXT		int			( * filcmp ) () ;

EXT		int			qflg ;
EXT		int			dflg ;
EXT		int			pflg ;
EXT		int			sflg ;
EXT		int			wpathdr ;
EXT		int			wpathnam ;
EXT		int			logflgs ;
EXT		int			lograin ;

EXT		TRXSIZ		totdirs ;
EXT		TRXSIZ		totfils ;
EXT		TRXSIZ		totbyts ;

void	chkquit (void) ;

# define	SKIPEXCL

# ifdef		SKIPEXCL

char *	exclskiplist [] = {

    "/dev/" ,

# ifdef		LINUX
	"/sys/"						,
	"/sys/fs/cgroup/"			,
	"/run/"						,
	"/run/lock/"				,
	"/run/shm/"					,
	"/run/user/"				,
# endif		/* SOLARIS */

# ifdef		SOLARIS
    "/devices/"					,
	"/system/contract/"			,
	"/etc/mnttab/"				,
	"/etc/svc/volatile/"		,
	"/system/object/"			,
	"/etc/dfs/sharetab/"		,
	"/dev/fd/"					,
	"/var/run/"					,
# endif		/* SOLARIS */

    "/proc/"					,

	NULL
} ;

# endif		/* SKIPEXCL */

/*		    					 ___________________________________
 *			    				|									|
 *				    			|	[recursive] log engine ...		|
 *					    		|___________________________________|
 */

void logtrix (dp) DIRDAT * dp ; {

	REG DIRDAT * tdp ;
	REG DIRDAT * * tdpp = NULL ;
	REG int ns ;
	REG FILDAT * tfp ;
	REG FILDAT * * tfpp ;
	REG char * tp ;
	register int i ;
	REG int tlen ;
	FIX int depth = 0 ;
	NEW STABLK stabuf ;

# ifdef   DOS

	REG char * np = stabuf.ff_name ;
	char wcbuf [ VIDWID ] ;
	REG char * wcfmt = "%s\\*.*" ;

	if (dp->dd_flg & DIROOT) {
		wcfmt = "%s*.*" ;
	}

# endif   /* DOS */

# ifdef   ANYX

#	ifdef	SYSVDIR

	DIR * dip ;
	DIRENT * dep ;
	REG char * np ;

#	else	/* V7DIR */

	/* FIX */ struct direct dirbuf ;
	REG char * np = dirbuf.d_name ;
	int fd ;

#	endif	/* SYSVDIR */

# endif   /* ANYX */

# ifdef XTRC
	if ( dp == VZRO(DIRDAT *) )
		fprintf (trcfp, "logtrix(NULL)\r\n") ;
	else
		fprintf (trcfp, "logtrix(%s)\r\n", dp->dd_path) ;
# endif

	if (dp->dd_depth == -1)
		dp->dd_depth = depth ;

	dp->dd_maxlen = 0 ;

	if (sflg)
		if ( ! (logflgs & LOGCWD) )
			dp->dd_flg |= UNREADIR ;

# ifdef		SKIPEXCL
	for ( i = 0 ; exclskiplist[i] != NULL ; ++i ) {
		tlen = strlen ( exclskiplist[i] ) ;
	    if ( strncmp ( dp->dd_path , exclskiplist[i] , tlen ) == 0 )	/*	SKIPEXCL	*/
    	    goto lkd ;	/*	SKIPEXCL	*/
	}
# endif		/* SKIPEXCL */

# ifdef   ANYX

    if (access (dp->dd_path, R_OK) < 0)
        goto lkd ;

#	ifdef	SYSVDIR

	if ((dip = opendir (dp->dd_path)) == (DIR *) 0) {

#	else	/* V7DIR */

	if ((fd = open (dp->dd_path, 0)) < 0) {

#	endif	/* SYSVDIR */

lkd :
        dp->dd_flg |= LOCKEDIR ;
        if (pflg) {
    		trixerr (T_ACCESS, dp->dd_path, errno, BANAL) ;
		}
		return ;
	}

#	ifdef	SYSVDIR

	while ((dep = readdir (dip)) != (DIRENT *) 0) {

		np = dep->d_name ;

#	else	/* V7DIR */

	while (read (fd, (char *) &dirbuf, sizeof (dirbuf)) > 0) {

		if (dirbuf.d_ino == 0)
			continue ;

#	endif	/* SYSVDIR */

# endif   /* ANYX */

# ifdef   DOS

	sprintf (wcbuf, wcfmt, dp->dd_path) ;

	if (findfirst (wcbuf, &stabuf, FA_BOTH) == -1)
		return ;

	do {

# endif   /* DOS */

		chkquit () ;	/* check for abort log ... */

		if ( *np == DOT ) {
			if ( *(np+1) == NUL ) {
				continue ;
			} else {
				if ( *(np+1) == DOT ) {
					if ( *(np+2) == NUL ) {
						continue ;
					}
				}
			}
		}

# ifdef   BIGTRX
		ns = strlen (dp->dd_path) + 2 + strlen (np) ;
# else    /* OLDTRX */
		ns = strlen (dp->dd_path) + 2 + NAMSIZ ;
# endif   /* BIGTRX x OLDTRX */

		if (NALLOC (tp, ns))
			goto nomem ;
		if (dp->dd_flg & DIROOT)
			strcpy (tp, dp->dd_path) ;
		else
			sprintf (tp, "%s%c", dp->dd_path, DIRSEP) ;

# ifdef   BIGTRX
		strcat (tp, np) ;
# else    /* OLDTRX */
		strncat (tp, np, NAMSIZ) ;
# endif   /* BIGTRX x OLDTRX */

# ifdef   ANYX

		if (STAT (tp, &stabuf) < 0) {
            dp->dd_flg |= LOCKEDIR ;
            if (pflg) {
    			trixerr (T_ACCESS, tp, errno, BANAL) ;
			}
			continue ;
		}

		if ((stabuf.st_mode & S_IFMT) == S_IFDIR) {

# endif   /* ANYX */

# ifdef   DOS

		if (stabuf.ff_attrib & FA_DIREC) {

# endif   /* DOS */

			if (logflgs & LOGCWD)
				continue ;

			if (qflg == FALSE) {
				dispat (_lpath, wpathdr, tp, wpathnam, VENORM) ;
			}
			if ((tdpp = dp->dd_dil) != VZRO (DIRDAT * *)) {
				ns = ((int)(dp->dd_dik) + 1) * sizeof (DIRDAT *) ;
				tdpp = (DIRDAT * *) REALLOC ( (char *) tdpp, ns) ;

				if (tdpp == (DIRDAT * *) 0) {
errealoc :
					trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;
				}
			} else {
				if (FALLOP (tdpp, DIRDAT *)) {
nomem :
					trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
				}
			}
			if (FALLOP (tdp, DIRDAT)) {
				goto nomem ;
			}
			/************************************************************
			**	this seems an appropriate point 2 collect d area used
			**	by dirs (unix only) ...
			*/
			dp->dd_dil = tdpp ;
			tdpp += (int)(dp->dd_dik) ;
			dp->dd_dik += 1 ;
			*tdpp = tdp ;
			tdp->dd_path = tp ;
			tdp->dd_nam = strrchr (tp, DIRSEP) + 1 ;
			tdp->dd_dir = dp ;
			STRUCPY (tdp->dd_stabuf, stabuf) ;
			tdp->dd_flg = 0x0000 ; tdp->dd_depth = -1 ;
			tdp->dd_fib = 0L ;
			tdp->dd_mfb = tdp->dd_tfb = 0L ;
			tdp->dd_fik = tdp->dd_dik = 0L ;
			tdp->dd_mfk = tdp->dd_tfk = 0L ;
			tdp->dd_fil = tdp->dd_mfl = (FILDAT * *) 0 ;
			tdp->dd_dil = (DIRDAT * *) 0 ;
			++totdirs ;
			++depth ;
			logtrix (tdp) ;
			--depth ;

		} else { /* log file */

			if (sflg)
				if ( ! (logflgs & LOGCWD) )
					goto kfb ;

			if ((tfpp = dp->dd_fil) != VZRO (FILDAT * *)) {
				ns = ((int)(dp->dd_fik) + 1) * sizeof (FILDAT *) ;
				tfpp = (FILDAT * *) REALLOC ( (char *) tfpp, ns) ;

				if (tfpp == (FILDAT * *) 0)
					goto errealoc ;
			} else {
				if (FALLOP (tfpp, FILDAT *))
					goto nomem ;
			}

			if (FALLOP (tfp, FILDAT)) {
				goto nomem ;
			}

			dp->dd_fil = tfpp ;
			tfpp += (int)(dp->dd_fik) ;
			tfp->fd_dir = dp ;
			tfp->fd_lix = dp->dd_fik ;
			*tfpp = tfp ;
			tfp->fd_path = tp ;
			tfp->fd_nam = strrchr (tp, DIRSEP) + 1 ;
			STRUCPY (tfp->fd_stabuf, stabuf) ;
			tfp->fd_flg = 0x0000 ;

			if ((tlen = strlen (tfp->fd_nam)) > dp->dd_maxlen)
				dp->dd_maxlen = tlen ;

kfb : /* count files & bytes ... */

			dp->dd_fik += 1 ;
			dp->dd_fib += stabuf.STASIZ ;
/*
 *			|=======================================================|
 *			|	collect global info, verbose out if so ...			|
 *			|=======================================================|
 */
			if (logflgs & LOGCWD)
				continue ;

			totfils += 1L ;
			totbyts += stabuf.STASIZ ;

			if (qflg == FALSE) {
				if ((totfils % lograin) == 0) {
					dispat (_ltotbyt, _ctotbyt, XLTOA (totbyts, 19, dflg), 19, VENORM) ;
					dispat (_ltotfil, _ctotfil, XLTOA (totfils, 15, dflg), 15, VENORM) ;
				}
			}

		} /* endif (dir or file) */

# ifdef   DOS

	} while (findnext (&stabuf) != -1) ; /* scan dir */

# endif   /* DOS */

# ifdef   ANYX

	} /* endof while (scan dir) */

#	ifdef	SYSVDIR

	closedir (dip) ;

#	else	/* V7DIR */

	close (fd) ;

#	endif	/* SYSVDIR */

# endif   /* ANYX */

} /* endof logtree */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	+ re-log current directory (files only) ...	|
 *					|-----------------------------------------------|
 *					|	+ if it's called from w/in filwut(), then	|
 *					|	  must reset filwut()'s ptrs & cnts ...		|
 *					|_______________________________________________|
 */

int logcwd (dp) DIRDAT * dp ; {

	REG FILDAT *	tfp ;
	REG	FILDAT * *	tmlp ;
	REG	FILDAT * *	emlp ;
	REG long		tmx = 0L ;
	REG long		xmfk = 0L ;
	REG	long		xmfb = 0L ;
	REG int			ns , maxns ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	--tots ; free & 0 lists ; 0 counts ; 		|
 *	|_______________________________________________|
 */

# ifdef XTRC
	if ( dp == VZRO(DIRDAT *) )
		fprintf (trcfp, "logcwd(NULL)\r\n") ;
	else
		fprintf (trcfp, "logcwd(%s)\r\n", dp->dd_path) ;
# endif

	TOTFILS -= (dp->dd_fik) ;	TOTBYTS -= (dp->dd_fib) ;
	MATFILS -= (dp->dd_mfk) ;	MATBYTS -= (dp->dd_mfb) ;
	SELFILS -= (dp->dd_tfk) ;	SELBYTS -= (dp->dd_tfb) ;

	if (dp->dd_flg & UNREADIR)
		goto zdi ;

	for ( ns=0, emlp=dp->dd_fil ; ns < dp->dd_fik ; ++ns, ++emlp ) {
		tfp = *emlp ;

		if ( (tfp->fd_path) != (char *) 0 )
			free ( (char *) tfp->fd_path ) ;

		if ( ((char *) tfp) != (char *) 0 )		/* YELLOW ALERT !!!	*/
			free ( (char *) tfp ) ;
	}

	if ( ((char *)(dp->dd_fil)) != (char *) 0 )	/* YELLOW ALERT !!!	*/
		free ( (char *) dp->dd_fil ) ;

	if ( ((char *)(dp->dd_mfl)) != (char *) 0 )	/* YELLOW ALERT !!!	*/
		free ( (char *) dp->dd_mfl ) ;

zdi : /* zero dirdat info */

	dp->dd_fil = dp->dd_mfl = (FILDAT * *) 0 ;
	dp->dd_fik = dp->dd_mfk = dp->dd_tfk = 0L ;
	dp->dd_fib = dp->dd_mfb = dp->dd_tfb = 0L ;
	dp->dd_maxlen = 0 ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	re-log ...									|
 *	|_______________________________________________|
 */
	logflgs |= LOGCWD ;
	logtrix (dp) ;
	logflgs &= ~ (LOGCWD) ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	rebuild mfl & re-match ...					|
 *	|_______________________________________________|
 */
	if (dp->dd_fik <= 0)
		goto igt ;

	dp->dd_mfl = (FILDAT * *) CALLOC ((unsigned)dp->dd_fik,
										sizeof (FILDAT *)) ;

	if (dp->dd_mfl == VZRO (FILDAT * *))
		trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;

	tmlp = dp->dd_mfl ; emlp = dp->dd_fil ; tmx = dp->dd_fik ;
	xmfk = xmfb = 0L ; ns = maxns = 0 ;

	while (tmx--) {
		tfp = *emlp++ ;
		if (patmat (tfp->fd_nam, rgxpat) == TRUE) {
			xmfb += tfp->fd_stabuf.STASIZ ;
			tfp->fd_mix = xmfk ;
			++xmfk ; *tmlp++ = tfp ;
			if ( ( ns = strlen (tfp->fd_nam) ) > maxns)
				maxns = ns ;
		}
	}

	dp->dd_mfk = xmfk ; dp->dd_mfb = xmfb ; dp->dd_maxlen = maxns ;

	qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
			sizeof (FILDAT *), filcmp) ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	++tots ...									|
 *	|_______________________________________________|
 */

igt : /* increment global totals ... */

	TOTFILS += (dp->dd_fik) ;	TOTBYTS += (dp->dd_fib) ;
	MATFILS += (dp->dd_mfk) ;	MATBYTS += (dp->dd_mfb) ;

	if (dp->dd_flg & UNREADIR)
		dp->dd_flg &= ~ (UNREADIR) ;

	return 0 ;

} /* endof logcwd() */

/********************************************************************/
/*
 * vi:nu tabstop=4
 */
