
/*                	 _______________________________________________
 *  ______________	|												|
 * /\  ___________\	|	TRIX + file system administration utility	|
 * \ \ \________  /	|_______________________________________________|
 *  \ \ \    / / /	|                                               |
 *   \ \ \  / / /	|	visual (arts, tricks & effects) interface	|
 *    \ \ \/ / /	|_______________________________________________|
 *     \ \/ / /		|												|
 *		\  / /		|	TRIX & its logo are registered trademarks	|
 *		 \/_/		|	of Alexandre Victor Rodrigues Botao (1991)	|
 *					|_______________________________________________|
 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include	<stdio.h>
# include	<string.h>

# ifdef		DOS

# include	<conio.h>

# endif		/* DOS, UNIX, XENIX */

# include	"trix.h"
# include	"trixblue.h"
# include	"trixchrs.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixwig.h"
# include	"trixterm.h"
# include	"trixwind.h"

# define	CWWID		80-VCBORD

EXT		HDRINF		fixhdrs [ ] ;
EXT		BYT			xfram [ ] ;
EXT		char		altgcs [ ] ;
EXT		char *		bantxt [ ] ;
EXT		char *		banopt [ ] ;
EXT     char *      qdbuf, * qsbuf, * qhbuf, * qvbuf, * qxbuf, * qybuf ;
EXT     char        pc_qd[], pc_qs[], pc_qh[], pc_qv[], pc_qx[], pc_qy[] ;
EXT		char *		clbuf ;
EXT		char *		cebuf ;
EXT		char *		pathdr ;
EXT		char *		tothdr ;
EXT		char *		curhdr ;
EXT		char *		cmb1 ;
EXT		char *		cmb2 ;
EXT		char *		fmb ;
EXT		int			xfmb ;
EXT		int			framtyp ;
EXT		int			wpathdr ;
EXT		int			wpathnam ;
EXT		int			vlinwid ;
EXT		int			wtothdr ;
EXT		int			wcurhdr ;
EXT		int			nflg ;
EXT		int			bignamjus ;
EXT		int			dflg, qflg ;
EXT		int			trixtate ;

EXT char * xctlsrno ; /* [] */
EXT char * xctlname ; /* [] */

/*======================================================================*
*	xbanner + fancy banner ...											*
*======================================================================*/
void xbanner () {

	REG int tl ;
	REG int banlen ;
	REG int bancofs ;

# ifdef XTRC
	fprintf (trcfp, "xbanner()\r\n") ;
# endif

	banlen = strlen (bantxt[0]) ;
	bancofs = /*TWCOFS+*/ ((80 /*TWLINW*/ - banlen)/2) ;

	for ( tl = 0 ; tl < _banlins ; ++tl ) {
	/*
	 *	the ifdef below may seem nuts,
	 *	but as trouble seems 2 stink ahead,
	 *	don't mind 4 just a while ...
	 */
# ifdef ANYX
		dispat (tl+_banlofs, bancofs, bantxt[tl], banlen, VEAGCS) ;
# else  /* DOS */
		dispat (tl+_banlofs, bancofs, bantxt[tl], banlen, VEHILT) ;
# endif /* ANYX */
	}

# ifdef SHOWDEPIN
	putbox (_hlbord, 53, 27, 3) ;
	dispat (_hlbord+1, 55, "Registro DEPIN: 22025-6", 23, VEHILT) ;
# endif

	putbox ( 1,  0, 27, 3) ;
	dispat ( 2,  2, "Tecle ESC para cancelar", 23, VEBLNK) ;
}
/************************************************************************
*	...																	*
************************************************************************/
void initban () {
	REG char * tp ;
	REG int tl ;

# ifdef XTRC
	fprintf (trcfp, "initban()\r\n") ;
# endif

	for ( tl = 0 ; tl < _banlins ; ++tl ) {
		bantxt[tl] = strdup (banopt[tl]) ;
	}

	for ( tl = 0 ; tl < _banlins ; ++tl ) {
		for ( tp = bantxt[tl] ; *tp ; ++tp ) {
            switch (*tp) {
                case ' ' : *tp = C_GSPC ; break ; /* ' ' */
                case '2' : *tp = C_G25P ; break ;
                case '5' : *tp = C_G50P ; break ;
                case '7' : *tp = C_G75P ; break ;
                case '9' : *tp = C_G99P ; break ;
                case 's' : *tp = C_SHBX ; break ;
                case 'w' : *tp = C_WHBX ; break ;
                case 'e' : *tp = C_EHBX ; break ;
                case 'n' : *tp = C_NHBX ; break ;
				default  : *tp = '?' ; break ; 
            }
		}
	}
}
/************************************************************************
*	flipath + flip full pathname header ...								*
************************************************************************/
void flipath (what) int what ; {

	switch (what) {
		case 'd' : pathdr = T_DIREQL ; break ;
		case 'f' : pathdr = T_FILEQL ; break ;
	}
	wpathdr = strlen (pathdr) ;
	wpathnam = vlinwid - wpathdr - 1 ;
}
/************************************************************************
*	fliptot + flip total files & bytes header ...						*
************************************************************************/
void fliptot (what) int what ; {

	switch (what) {
		case 'd' : tothdr = "Total do Diretorio:" ; break ;
		case 'g' : tothdr = "Total Global:" ; break ;
	}
	wtothdr = 23 ;
}
/************************************************************************
*	flipcur + flip current header ...									*
************************************************************************/
void flipcur (what) int what ; {

	switch (what) {
		case 'd' : curhdr = T_CURDIR ; break ;
		case 'f' : curhdr = T_CURFIL ; break ;
	}
	wcurhdr = 23 ;
}
/************************************************************************
*	rescreen () + full screen refresh ...								*
************************************************************************/
void rescreen (dp, fp) DIRDAT * dp ; FILDAT * fp ; {
	REG long tmpflg ;
	REG long dynflg = 0L ;

	tmpflg = RESCREN | UDMNUS ;
	switch (trixtate) {
		case 'd' : dynflg = UDCURD | UDSTATUS ; break ;
		case 'f' : dynflg = UDTREE | UDCURF | UDSTATUS ; break ;
		case 'b' : dynflg = UDCURF | UDSTATUS ; break ;
	}
	frescrn (tmpflg|dynflg, dp, fp) ;
	if (dynflg & UDCURD)
		frescrn (UDTOTS, gpan, VZRO (FILDAT *)) ;
}
/************************************************************************
*	+ refresh screen regions ...										*
************************************************************************/
void frescrn (flgs, dp, fp) ULONG flgs ; DIRDAT * dp ; FILDAT * fp ; {

	register struct hdrinf * tp ;
	register char * tfmb = NULL ;
	static int j , tmplen ;
	/* static int trccnt = 0 ; */
	static char tmptxtbuf [256] ;
	static TRXSIZ tmplon ;
	STABLK * stap ;
	int lenfileql = 0 ;

# ifdef ANYX

    char * xp ;

    OWNDAT   odb ;
    OWNDAT * odp ;
    GRPDAT   gdb ;
    GRPDAT * gdp ;

    EXT int totown , totgrp ;
    EXT OWNDAT * ownlist ;
    EXT GRPDAT * grplist ;

# endif /* ANYX */

# ifdef XTRC
	fprintf (trcfp, "+frescrn(%08lx,%s,%s)\r\n", flgs,
				dp == VZRO (DIRDAT *) ? "NULL" : dp->dd_path,
				fp == VZRO (FILDAT *) ? "NULL" : fp->fd_path) ;
# endif

	if ( nflg )
		lenfileql = strlen (T_FILEQL) ;

	if (flgs & FRESCLR)
		CLRSCR ;

	if (flgs & FRESBAN)
		xbanner () ;

	if (flgs & REFRAME) {
		bigwfram () ;
		flipfram () ;
	}

	if ((flgs & FLOGBOX) && (qflg == FALSE)) {
		putbox (_hlbord, 0, 27, 5) ;
		dispat (_lhtotbyt, _chtotbyt,  "Bytes", 5, VENORM) ;
		dispat (_lhtotfil, _chtotfil,  "Arqs.", 5, VENORM) ;
		dispat (_ltothdr, _ctothdr, tothdr, wtothdr, VENORM) ;
	}

	if (flgs & FSECTRL) {

		/* fprintf(trcfp,"\r\n (%d) sectrl\r\n\r\n", ++trccnt); */
		putbox (_lvrsn-1, _cvrsn-2, _vdocols, 4) ;

		sprintf (tmptxtbuf, "%s %s @ %s / %s", T_TRIX, SWVRSNO, VRSNTIM, OPSYS) ;
		dispat (_lvrsn, _cvrsn, tmptxtbuf, 76, VEHILT) ;

# define T_CRNTXT	"(C) 1990-2015 Alexandre Botao"

# ifdef OLD
	/*	dispat (_crnlofs, _crncofs, T_CRNTXT, 76, VEHILT) ;	*/
# else
		strcpy (tmptxtbuf, T_CRNTXT) ;
		j = strlen (tmptxtbuf) ;
		dispat (_lvrsn, (vlinwid-j-2), tmptxtbuf, j, VEHILT) ;
# endif
	/*	sprintf (tmptxtbuf, "Direito de uso : %-70s", xctlname) ;	*/

		strcpy (tmptxtbuf, xctlname==NOSTR?"Licenca : Demo,Full,Life,Beta":xctlname) ;
		dispat (_snilofs, _snicofs, tmptxtbuf, 76/*_vdocols-4*/, VEHILT) ;

		sprintf (tmptxtbuf, "# {%s}", xctlsrno==NOSTR?"27182818":xctlsrno) ;
		j = strlen (tmptxtbuf) ;
		dispat (_lsrno, (vlinwid-j-2), tmptxtbuf, j, VEHILT) ;
	}

	if (flgs & UPATHDR) {
		dispat (0, 0, pathdr, wpathdr, VENORM) ;
	}

	if (flgs & FIXHDRS) {
		for ( tp = fixhdrs ; tp->hi_lin != (int *) 0 ; ++tp ) {
			dispat (*(tp->hi_lin), *(tp->hi_col),
					tp->hi_txt, tp->hi_len, VENORM) ;
		}
	}

	if (flgs & DYNHDRS) {
		dispat (_ltothdr, _ctothdr, tothdr, wtothdr, VENORM) ;
		dispat (_lcurhdr, _ccurhdr, curhdr, wcurhdr, VENORM) ;
	}

	if (flgs & UDPATH) {
		dispat (_lpath, wpathdr, dp->dd_path, wpathnam, VEHILT) ;
	}

	if (flgs & UDRGXP) {
		dispat (_lrgxpat, _crgxpat, rgxpat, _wrgxpat, VENORM) ;
	}

	if (flgs & UDFILS) {
		dispat (_ltotbyt, _ctotbyt, XLTOA (dp->dd_fib, 19, dflg), 19, VENORM) ;
		dispat (_ltotfil, _ctotfil, XLTOA (dp->dd_fik, 15, dflg), 15, VENORM) ;
	}

	if (flgs & UDMATS) {
		dispat (_lmatbyt, _cmatbyt, XLTOA (dp->dd_mfb, 15, dflg), 15, VENORM) ;
		dispat (_lmatfil, _cmatfil, XLTOA (dp->dd_mfk, 15, dflg), 15, VENORM) ;
	}

	if (flgs & UDSELS) {
		dispat (_lselbyt, _cselbyt, XLTOA (dp->dd_tfb, 15, dflg), 15, VENORM) ;
		dispat (_lselfil, _cselfil, XLTOA (dp->dd_tfk, 15, dflg), 15, VENORM) ;
	}

	if (flgs & UDCURD) {
		dispat (_lcurfib, _ccurfib, XLTOA (dp->dd_fib, 15, dflg), 15, VENORM) ;
		dispat (_lcurfik, _ccurfik, XLTOA (dp->dd_fik, 15, dflg), 15, VENORM) ;
	}

	if (flgs & UDCURF) {
# ifdef BIGTRX
		if ( nflg ) { 
			dispat (_botfilnamlin, 0, T_FILEQL, lenfileql, VEHILT) ;
			dispat (_botfilnamlin, lenfileql, fp->fd_nam, (vlinwid - lenfileql - 1), VEHILT) ;
		} else {
			dispat (_lpath, wpathdr, fp->fd_nam, wpathnam, VEHILT) ;
		}
# endif
		tmplen = strlen (fp->fd_nam) ;
		if ( tmplen > 23 ) {
			if ( bignamjus ) {
				sprintf (tmptxtbuf, "...%20s", ((fp->fd_nam)+(tmplen-20))) ;
			} else {
				sprintf (tmptxtbuf, "%-20.20s...", fp->fd_nam) ; /* default */
			}
		} else {
			sprintf (tmptxtbuf, "%23s", fp->fd_nam) ;
		}
		dispat (_lfilnam, _cfilnam, tmptxtbuf, _wfilnam, VENORM) ;
		tmplon = ( (TRXSIZ) (fp->fd_stabuf.STASIZ) ) ;
		dispat (_lfilsiz, _cfilsiz, XLTOA (tmplon, 15, dflg), 15, VENORM) ;
	}

	if (flgs & CMNUBAR) { /* u/d cmd mnu lins ... */
		dispat (_lcmb1, _ccmb1, cmb1, 80, VENORM) ;
		dispat (_lcmb2, _ccmb2, cmb2, 80, VENORM) ;
	}

	if (flgs & CLRMNUS) {
		locat (_lcmb1, 0) ; CLRTOEOL ;
		locat (_lcmb2, 0) ; CLRTOEOL ;

		switch (xfmb) {
			case 'y' : tfmb = T_YNFMB  ; break ;
			case 'o' : tfmb = T_OKFMB  ; break ;
			case 'a' : tfmb = T_ANYFMB ; break ;
			case 'm' : tfmb = T_FAMFMB ; break ;
			case 'e' : tfmb = T_FERFMB ; break ;
			case 'l' : tfmb = T_LOGFMB ; break ;
		}

		dispat (_lfmb1, _cfmb1, tfmb, 79, VENORM) ;
	}

	if (flgs & FMNUBAR) { /* u/d pf mnu ... */
		dispat (_lfmb1, _cfmb1, fmb, 79, VENORM) ;
	}

	if (flgs & UDTREE) {
		disptree () ;
	}

    if (flgs & UDSTATUS) {
        if (flgs & UDCURF)
            stap = &(fp->fd_stabuf) ;
        else
            stap = &(dp->dd_stabuf) ;
        /*
         *  + display protection bits ...
         */
        dispat (_lprohdr, _cprotxt, trixdm (stap->STAPROT),
                _wprotxt, VENORM) ;
        /*
         *  + display last modification time
         */
# ifdef ANYX
		dispat (_lwrthdr, _cwrtime, trixtm (stap->STATIM), 14, VENORM) ;
# else  /* DOS */
		dispat (_lwrthdr, _cwrtime,
				trixtm ( stap->STADAT, stap->STATIM ) ,
				14, VENORM) ;
# endif /* ANYX */

# ifdef ANYX
        /*
         *  + display last read time
         */
        dispat (_lrdthdr, _crdtime, trixtm (stap->STALAR), 14, VENORM) ;
        /*
         *  + display owner
		 */
        odb.od_uid = stap->STAUID ;

        odp = (OWNDAT *) bsearch ( (void *) &odb,
                                   (void *) ownlist,
                                   (size_t) totown,
                                   (size_t) sizeof (OWNDAT),
                                   owncmp                    ) ;

        if (odp == VZRO (OWNDAT *))
            sprintf (xp = tmptxtbuf, "(%d)", (int)stap->STAUID) ;
        else
            xp = odp->od_nam ;
		dispat (_lownhdr, _cownrid, xp, _wownrid, VENORM) ;
        /*
         *  + display group
         */
        gdb.gd_gid = stap->STAGID ;

        gdp = (GRPDAT *) bsearch ( (void *) &gdb,
                                   (void *) grplist,
                                   (size_t) totgrp,
                                   (size_t) sizeof (GRPDAT),
                                   grpcmp                    ) ;

        if (gdp == VZRO (GRPDAT *))
            sprintf (xp = tmptxtbuf, "(%d)", (int)stap->STAGID) ;
        else
            xp = gdp->gd_nam ;
        dispat (_lgrphdr, _cgrpnam, xp, _wgrpnam, VENORM) ;
        /*
         *  + display links
         */
        sprintf (tmptxtbuf, "%-6d", (int)stap->STALNK) ;
        dispat (_llnkhdr, _clnkcnt, tmptxtbuf, _wlnkcnt, VENORM) ;
# endif /* ANYX */
    }

# ifdef XTRC
	fprintf (trcfp, "-frescrn(%08lx,%s,%s)\r\n", flgs,
				dp == VZRO (DIRDAT *) ? "NULL" : dp->dd_path,
				fp == VZRO (FILDAT *) ? "NULL" : fp->fd_path) ;
# endif

}
/************************************************************************
*																		*
************************************************************************/
void flipcmb (what) int what ; {

	switch (what) {

		case 'd' : /* dir. cmds mnu bars ... */
			cmb1 = T_DIR1CMB ;
			cmb2 = T_DIR2CMB ;
		break ;

		case 'f' : /* file cmds mnu bars ... */
			cmb1 = T_FIL1CMB ;
			cmb2 = T_FIL2CMB ;
		break ;

		case 'b' : /* bit editor cmds mnu bars ... */
			cmb1 = T_BED1CMB ;
			cmb2 = T_BED2CMB ;
		break ;

		case 'v' : /* vur cmds mnu bars ... */
			cmb1 = T_VUE1CMB ;
			cmb2 = T_VUE2CMB ;
		break ;
	}
}
/************************************************************************
*																		*
************************************************************************/
void flipfmb (what) int what ; {

	switch (what) {
		case 'd' : fmb = T_DIRFMB ; break ;
		case 'f' : fmb = T_FILFMB ; break ;
		case 'b' : fmb = T_BEDFMB ; break ;
		case 'h' : fmb = T_HXVFMB ; break ;
		case 'v' : fmb = T_VUEFMB ; break ;
	}
}
/************************************************************************
*																		*
************************************************************************/
void flipfram () {

# ifdef XTRC
	fprintf (trcfp, "flipfram()\r\n") ;
# endif

	if (framtyp == 'f')
		divfram () ;
	else
		wipefram () ;
}
/************************************************************************
*																		*
************************************************************************/
void bigwfram () {
	register int i ;
	BYT buf [512] ;

# ifdef XTRC
	fprintf (trcfp, "bigwfram()\r\n") ;
# endif

	/*___________________________________________________________________
	**	top line ...
	*/
	buf[0]  = UPRLEFT ;
	buf[_vdocols-1] = UPRIGHT ;
	for ( i = 1 ; i < _vdocols-1 ; ++i )
		buf[i] = HORZBAR ;
    buf[_vdocols] = '\0' ;
	dispat (1, 0, (char *) buf, _vdocols, VEAGCS) ;
	/*___________________________________________________________________
	**	ctrl box' top line ...
	*/
	buf[0]  = LEFTEE ;
	buf[_vdocols-1] = RIGHTEE ;
	buf[26] = buf[53] = UPRTEE ;
    buf[_vdocols] = '\0' ;
	dispat (_hlbord, 0, (char *) buf, _vdocols, VEAGCS) ;
	/*___________________________________________________________________
	**	ctrl box' mid line ...
	*/
	buf[26] = buf[53] = PLUSTEE ;
    buf[_vdocols] = '\0' ;
	dispat (_hlbord+4, 0, (char *) buf, _vdocols, VEAGCS) ;
	/*___________________________________________________________________
	**	ctrl box' bottom line ...
	*/
	buf[0]  = LWRLEFT ;
	buf[_vdocols-1] = LWRIGHT ;
	buf[26] = buf[53] = LWRTEE ;
    buf[_vdocols] = '\0' ;
	dispat (_hlbord+8, 0, (char *) buf, _vdocols, VEAGCS) ;
	/*___________________________________________________________________
	**	tree window ...
	*/
	buf[0] = buf[2] = C_GSPC ; buf[3] = '\0' ;
	buf[1] = VERTBAR ;
	for ( i = 2 ; i < _hlbord ; ++i ) {
		dispat (i, 0, (char *) &buf[1], 2, VEAGCS) ;
		dispat (i, _vdocols-2, (char *) buf, 2, VEAGCS) ;
	}
	/*___________________________________________________________________
	**	ctrl box' walls ...
	*/
	for ( i = 0 ; i < 3 ; ++i ) {
		dispat (_hlbord+1+i,  0, (char *) &buf[1], 2, VEAGCS) ;
		dispat (_hlbord+1+i, 25, (char *) buf, 3, VEAGCS) ;
		dispat (_hlbord+1+i, 52, (char *) buf, 3, VEAGCS) ;
		dispat (_hlbord+1+i, /*78*/_vdocols-2, (char *) buf, 2, VEAGCS) ;
	}
	for ( i = 0 ; i < 3 ; ++i ) {
		dispat (_hlbord+5+i,  0, (char *) &buf[1], 2, VEAGCS) ;
		dispat (_hlbord+5+i, 25, (char *) buf, 3, VEAGCS) ;
		dispat (_hlbord+5+i, 52, (char *) buf, 3, VEAGCS) ;
		dispat (_hlbord+5+i, /*78*/_vdocols-2, (char *) buf, 2, VEAGCS) ;
	}
}
/************************************************************************
*																		*
************************************************************************/
void divfram () {
	REG int i ;
	static char buf [20] ;

# ifdef XTRC
	fprintf (trcfp, "divfram() : _vcbord=%d _vdocols=%d\r\n", _vcbord, _vdocols) ;
# endif

	buf[0] = UPRTEE ; buf[1] = '\0' ;
	dispat (1, /*62*/_vcbord, buf, 1, VEAGCS) ;

	buf[0] = buf[2] = C_GSPC ; buf[3] = '\0' ;
	buf[1] = VERTBAR ;
	for ( i = 2 ; i < _hlbord ; ++i )
		dispat (i, /*61*/_vcbord-1, buf, 3, VEAGCS) ;

	buf[0] = LWRTEE ; buf[1] = '\0' ;
	dispat (_hlbord, /*62*/_vcbord, buf, 1, VEAGCS) ;
}
/************************************************************************
*																		*
************************************************************************/
void wipefram () {
	REG int i ;
	static char buf [20] ;

	buf[0] = HORZBAR ; buf[1] = '\0' ;
	dispat (1, /*62*/_vcbord, buf, 1, VEAGCS) ;
	dispat (_hlbord, /*62*/_vcbord, buf, 1, VEAGCS) ;

	buf[0] = buf[1] = buf[2] = C_GSPC ; buf[3] = '\0' ;
	for ( i = 2 ; i < _hlbord ; ++i )
		dispat (i, /*61*/_vcbord-1, buf, 3, VEAGCS) ;
}
/************************************************************************
*																		*
************************************************************************/
void switfram () {						/* switch frame style */
	EXT int ftyx ;
	EXT BYT * framstyl [] ;

	if (++ftyx > 3)
		ftyx = 0 ;

	strcpy ( (char *) xfram, (char *) framstyl[ftyx] ) ;
}
/***********************************************************************/
# ifdef ANYX
void pcharset () { /* load std pc 8-bit alt graphic char set */

    strcpy (qdbuf, pc_qd) ;
    strcpy (qsbuf, pc_qs) ;
    strcpy (qhbuf, pc_qh) ;
    strcpy (qvbuf, pc_qv) ;
    strcpy (qxbuf, pc_qx) ;
    strcpy (qybuf, pc_qy) ;
}
# endif /* ANYX */
/***********************************************************************/
/*
 * vi:nu tabstop=4
 */
