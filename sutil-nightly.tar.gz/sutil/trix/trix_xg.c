main () {

	int x ;
	char b [20] ;

	for (x = 0 ; x < 256 ; ++x)
	{
		if (x == 0x13 || x == 0x93)
			continue ;
		printf  ("'%c' ", ( (x>=32&&x<=126) ? x : '?' )) ;
		printf  ("%3u 0%03o 0x%02x '\033[11m%c\033[10m' \n", x, x, x, x) ;
		gets (b) ;
	}
}
