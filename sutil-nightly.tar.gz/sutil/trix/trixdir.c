
/*
 *	     	 _______________________________________________
 *	      	|												|
 *	       	|	TRIX + file system administration utility	|
 *	  /\    |_______________________________________________|
 *	 /  \   |												|
 *	/ OO \  |	directory window commands interface ...		|
 *	\ \/ /  |_______________________________________________|
 *	 \  /   |												|
 *	  \/    |	TRIX & its logo are registered trademarks	|
 *	       	|	of Alexandre Victor Rodrigues Botao (1991)	|
 *	        |_______________________________________________|
 *
 */

# include	<stdio.h>
# include	<string.h>

# ifdef		ANYX
# include   <unistd.h>
# endif		/* ANYX */

# include	"trixasci.h"
# include	"trix.h"
# include	"trixstd.h"
# include	"trixblue.h"
# include	"trixkeys.h"
# include	"trixfunc.h"
# include	"trixaloc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixmenu.h"
# include	"trixcmd.h"
# include	"trixwig.h"

# ifdef		DOS

# define	VINVIS		0

# else		/* ANYX */

EXT char * * efon [] ;
EXT char * * efof [] ;

# define	VINVIS		( dp->dd_depth * kinvis )

# endif		/* DOS */

EXT		int			nflg ;
EXT		int			( * filcmp ) () ;
EXT		int			topn ;
EXT		int			trixtate, mmval, vdotyp, logedest, curwax ;
EXT     int         cmask ;
EXT     int         jkey ;
EXT		char		origwd [] ;
EXT		char *		currwd ;
EXT		char *		ghelpt ;
EXT		char *		ghyid ;
EXT		char * *	piclst ;
EXT		DIRDAT *    destdd ;
EXT		DIRDAT * *	wablst ;
EXT		MENUCTL		primenu ;
# ifdef BIGTRX
EXT     int         _botfilnamlin ;
# endif
/*
 *	+ disptree() stuff ...
 */
EXT int gtwlin , gwabinx ;
EXT char * * gtwtopg ;
EXT DIRDAT * * gwabp , * * gwabtop ;
/*			 _______________________________________________________
 *			|														|
 *			|	walk about current tree ...							|
 *			|_______________________________________________________|
 */
void wabtrix () {

	REG int k ;
	REG int twlin ;
	REG int wabinx ;
	REG int key = '\0' ;
	REG int grd ;
	REG char * * twtopg ;	/* tree window top of pag	*/
	REG DIRDAT * * wabp ;
	REG DIRDAT * * wabtop ;
	REG DIRDAT * dp ;
	REG char * tp ;
	REG int retot = TRUE ;
		char tb [512] ;

# ifdef		ANYX

	REG int kinvis ;
# ifndef	TREEDRAWW
	FIX int dinvis = 0 ;
# endif		/* ! TREEDRAWW */

# ifdef		TREEDRAWW

	REG int gdlen ;

# else		/* OLDTREEDRAW */

	if (dinvis == 0)
		dinvis = strlen (*(efon[VEAGCS])) + strlen (*(efof[VEAGCS])) ;

# endif		/* ! TREEDRAWW */

# else		/* DOS */

	REG int gdlen ;

# endif		/* ANYX */

# ifdef XTRC
	fprintf (trcfp, "wabtrix()\r\n") ;
# endif

sowt :	/* start-of-wabtrix ...	*/

/*
 *	|-------------------------------------------------------|
 *	|	start working dir ...								|
 *	|-------------------------------------------------------|
 */
	wabp = wablst ;

	if (curwax != -1) {
		wabinx = curwax ;
		goto swx ;
	}

	xerrno = -1 ; isdestin (origwd) ;
	logedest = FALSE ; destdd = VZRO (DIRDAT *) ;

	if (xerrno == -1) {
		twtopg = piclst ; wabinx = twlin = 0 ; wabtop = wabp ;
	} else {
		wabinx = xerrno ; xerrno = 0 ;
swx :
		twlin = wabinx % (_twlins-1) ;
		k = ( wabinx / (_twlins-1) ) * (_twlins-1) ;
		twtopg = piclst + k ; wabtop = wabp + k ;
	}
/*
 *	|-------------------------------------------------------|
 *	|	page refresh ...									|
 *	|-------------------------------------------------------|
 */
repag :
# ifdef BIGTRX
	if ( nflg ) {
		frescrn (UDMNUS|UDRGXP, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
		dispat (_botfilnamlin, 0, NOSTR, _vdocols-1, VENORM) ;
	} else {
		flipath ('d') ;
		frescrn (UPATHDR|UDMNUS|UDRGXP, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	}
# else
	frescrn (UDMNUS|UDRGXP, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
# endif
	for ( k = 0 ; k < _twlins ; ++k ) {
		tp = NOSTR ;
		dp = *wabp ;
# ifndef	DOS
		kinvis = 0 ;
# endif		/* DOS */
		if ( ( (twtopg + k) - piclst ) < (TOTDIRS) ) {
			tp = *(twtopg + k) ;
			dp = *(wabtop + k) ;
# ifndef	DOS
            if (vdotyp == 't')
# ifdef TREEDRAWW
				kinvis = 0 ;
# else  /* OLD */
    			kinvis = dinvis ;
# endif /* TREEDRAWW */
/*          else
                kinvis = 0 ; */
# endif		/* ! DOS */
		}

# ifdef TREEDRAWW

		if (vdotyp == 't') {
			gdlen = dp->dd_depth * GTPLEN ;
# ifdef SAFE
			strcpy (tb, tp) ;
			tb [gdlen] = '\0' ;
			dispat (k+_twlofs, _twcofs, tb, gdlen, VEAGCS) ;
# else  /* FAST */
			if (tp != NOSTR)
				dispat (k+_twlofs, _twcofs, tp, gdlen, VEAGCS) ;
# endif /* SAFE */
			if (tp == NOSTR)
				dispat (k+_twlofs, _twcofs, tp, _twlinw+1+VINVIS, VENORM) ;
			else
				dispat (k+_twlofs, TWCURS, dp->dd_nam, _twlinw+1-gdlen, VENORM) ;
		} else
			dispat (k+_twlofs, _twcofs, tp, _twlinw+1+VINVIS, VENORM) ;

# else  /* OLD */

		dispat (k+_twlofs, _twcofs, tp, _twlinw+1+VINVIS, VENORM) ;

# endif /* TREEDRAWW */

	}
	if (key == KEND)
		goto eopg ;
	for ( ; ; ) {
		dp = *(wabp + wabinx) ;
		currwd = dp->dd_path ;

		if ( TWCURS + NAMSIZ > _twlinw )
			dispat (twlin+_twlofs, _twcofs, dp->dd_nam, NAMSIZ, VEREVS) ;
		else
			dispat (twlin+_twlofs, TWCURS, dp->dd_nam, NAMSIZ, VEREVS) ;
        /*
         *  + u/d status info on screen ...
         */
		frescrn (UDCURD|UDPATH|UDSTATUS, dp, VZRO (FILDAT *)) ;
		/*___________________________________________________________________
		 *	+ these totals on ctrl wdw should be u/d only if anything has
		 *	  been deleted, tagged, of matched ...
		 */

		if (retot) {
			frescrn (UDTOTS, gpan, VZRO (FILDAT *)) ;
			retot = FALSE ;
		}

# ifdef COMMENT
		if (key == TAB && dp->dd_mfk <= 0)
			goto w4k ;
# endif /* COMMENT */

		if (dp->dd_mfk > 0) {		/* something 2 c	*/

			grd = filwut (dp, FWVIEW) ;
# ifdef BIGTRX
			if ( ! nflg ) {
				flipath ('d') ;
				frescrn (UPATHDR, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
			} else {
				dispat (_botfilnamlin, 0, NOSTR, _vdocols-1, VENORM) ;
			}
# endif

		} else {			/* clear fil window	*/

			for ( k = 0 ; k < _fwlins ; ++k ) {
				dispat (k + _fwlofs, _fwcofs, NOSTR, _fwlinw, VENORM) ;
			}

			if (dp->dd_fik > 0) {

				if (dp->dd_flg & UNREADIR) {

					dispat (_fwlofs,   _fwcofs, T_DITHDR, 14, VEHILT) ;
					dispat (_fwlofs+1, _fwcofs, T_UNREAD,  14, VEHILT) ;

				} else {

					dispat (_fwlofs,   _fwcofs, T_DITHDR, 14, VEHILT) ;
					dispat (_fwlofs+1, _fwcofs, T_HAVENO, 14, VEHILT) ;
					dispat (_fwlofs+2, _fwcofs, T_AFILES, 14, VEHILT) ;
					dispat (_fwlofs+3, _fwcofs, T_OFDFAM, 14, VEHILT) ;
					dispat (_fwlofs+4, _fwcofs, rgxpat, 14, VEHILT) ;
				}

			} else if (dp->dd_flg & LOCKEDIR) {

				dispat (_fwlofs,   _fwcofs, T_DITHDR, 14, VEHILT) ;
				dispat (_fwlofs+1, _fwcofs, T_PROTECTED,  14, VEHILT) ;

			} else {

				dispat (_fwlofs,   _fwcofs, T_DITHDR, 14, VEHILT) ;
				dispat (_fwlofs+1, _fwcofs, T_EMPTY,  14, VEHILT) ;
			}
		}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef COMMENT
w4k :
# endif /* COMMENT */
		key = getkey () ;

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

		if ( TWCURS + NAMSIZ > _twlinw )
			dispat (twlin+_twlofs, _twcofs, dp->dd_nam, NAMSIZ, VENORM) ;
		else
			dispat (twlin+_twlofs, TWCURS, dp->dd_nam, NAMSIZ, VENORM) ;

dkyt :	switch (key) {
			/*_______________________________________________________
			 *	...
			 */
			case '\b' :
			case '8':
			case '4' :
			case KLEFT :
			case KUP :
				if (wabinx) {
					--wabinx ;
					if (twlin) {
						--twlin ;
					} else {
						--twtopg ;
						--wabtop ;
						goto repag ;
					}
				}
			break ;
			/*___________________________________________________________
			 *	...
			 */
			case '\r' :
			case '\n' :
			case ' ' :
			case '6':
			case '2' :
			case KRIGHT :
			case KDOWN :
				if (wabinx < ((TOTDIRS) - 1)) {
					++wabinx ;
					if (twlin < (_twlins - 1)) {
						++twlin ;
					} else {
						++twtopg ;
						++wabtop ;
						goto repag ;
					}
				}
			break ;
			/*	 _______________________________________________________
			 *	|														|
			 *	|	+	...												|
			 *	|_______________________________________________________|
			 */
			case CMD_FILWIN : key = TAB ;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			case TAB :
				if (dp->dd_mfk > 0) {
					/*--------------------------------------------------*/
					gtwtopg = twtopg ; gtwlin = twlin ;
					gwabp = wabp ; gwabtop = wabtop ; gwabinx = wabinx ;
					/*--------------------------------------------------*/
					dispat (twlin+_twlofs, TWCURS, dp->dd_nam,
							strlen (dp->dd_nam), VEHILT) ;
					trixtate = 'f' ;
					grd = filwut (dp, FWPLAY) ;
rff :				trixtate = 'd' ;
# ifdef BIGTRX
					if ( ! nflg ) {
						flipath ('d') ;
						frescrn (UPATHDR, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
					} else {
						dispat (_botfilnamlin, 0, NOSTR, _vdocols-1, VENORM) ;
					}
# endif
					retot = TRUE ;
					frescrn (FIXHDRS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
					if (grd == 'b') {
						key = 0 ;
						goto repag ;
					}
					if (dp->dd_mfk <= 0) {		/* nothing 2 c	*/
						key = 0 ;
					}
				}
			break ;
/*			 ___________________________________________________________
 *			|	+ PgUp ...												|
 *			|___________________________________________________________|
 */
			case '9' :
			case KPGUP :
				if ( ((wabtop-wabp)-(_twlins-1)) >= 0 ) {
					twtopg -= (_twlins-1) ; wabtop -= (_twlins-1) ;
					wabinx = (int) (wabtop-wabp) ; twlin = 0 ;
					goto repag ;
				} else
					goto homwb ;
/*			 ___________________________________________________________
 *			|	+ PgDn ...												|
 *			|___________________________________________________________|
 */
			case '3' :
			case KPGDN :
				if ( ((wabtop-wabp)+(_twlins-1)) < ((TOTDIRS)-1) ) {
					twtopg += (_twlins-1) ; wabtop += (_twlins-1) ;
					wabinx = (int) (wabtop-wabp) ; twlin = 0 ;
					goto repag ;
				} else
					goto eopg ;
/*			 ___________________________________________________________
 *			|	+ ^PgUp = start-of-tree ...								|
 *			|___________________________________________________________|
 */
			case '7' :
			case KHOME :
homwb :						wabinx = twlin = 0 ; wabtop = wabp ;
							twtopg = piclst ; goto repag ;
/*			 ___________________________________________________________
 *			|	+ ^PgDn = end-of-tree ...								|
 *			|	  if (more than one page) goto last_page ;				|
 *			|	  goto last_entry_on_(even mid-)screen ;				|
 *			|___________________________________________________________|
 */
			case '1' : key = KEND ;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			case KEND :
				if ( (TOTDIRS) > _twlins ) {
					wabinx = (int)(TOTDIRS) - _twlins ; twlin = 0 ;
					wabtop = wabp + wabinx ; twtopg = piclst + wabinx ;
					goto repag ;
				}
eopg :			k = ((int)(TOTDIRS)-wabinx) - 1 ; wabinx += k ; twlin += k ;
			break ;
			/*___________________________________________________________
			 *	...
			 */
			case '?' :
			case KF1 :
				ghelpt = NOSTR ;
				hyxhelp ("Comandos de Diretorio") ;
			break ;
			/*___________________________________________________________
			 *	+ flip video design ...
			 *	+ possible modes are :
			 *	  + enlarges small file wdw in height (&/or width)
			 *	    (this implies omiting some "current" status info)
			 *	  + closes all statistics & status boxes, showing
			 *		"taller" tree & file wdw
			 */
			case KF4 :
			break ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ trix menus ...										|
 *			|___________________________________________________________|
 */
			case '#' :
			case KF10 :

				dispat (twlin+_twlofs, TWCURS, dp->dd_nam, NAMSIZ, VEREVS) ;

				mmval = -1 ;
				grd = runmenu ( & primenu , -1 , -1 ) ;

				dispat (twlin+_twlofs, TWCURS, dp->dd_nam, NAMSIZ, VENORM) ;

				frescrn (REFRAME, NODID, NOFID) ;

				if (grd == -1)
					break ;

				key = mmval ; mmval = -1 ;
				goto dkyt ;
/*
 *			|-------------------------------------------------------|
 *			|	switch frame style ...								|
 *			|-------------------------------------------------------|
 */
			case CMD_SWFRAM :
			case '+' :
        				switfram () ;
		        		frescrn (REFRAME, NODID, NOFID) ;
						goto repag ;
					/*	break ;	*/
/*			 _______________________________________________________
 *			|														|
 *			|	+ swap & select another subtree (fwd & bwd) ...		|
 *			|_______________________________________________________|
 */
			case CMD_SWTREE :
			case '>' :
			case KF3 :	jkey = '>' ; goto sst ;

			case CMD_SWTREB :
			case '<' :
			case KF5 :	jkey = '<' ;
sst:
						if (topn < 2)
							break ;

						curwax = wabinx ;
						return ;
/*			 _______________________________________________________
 *			|														|
 *			|	+ make (create) a directory under the current one.	|
 *			|_______________________________________________________|
 */
			case CMD_MAKDIR :
			case 'c' :
			case 'C' :
						dispat (twlin+_twlofs, TWCURS, dp->dd_nam, NAMSIZ, VEBLNK) ;

						if (trixmkdir (dp) == -1)
							break ;

						curwax = wabinx ;
						goto sowt ;
/*			 _______________________________________________________
 *			|														|
 *			|	+ remove (delete) the current directory ...			|
 *			|_______________________________________________________|
 */
			case CMD_DELDIR :
			case 'd' :
			case 'D' :
						dispat (twlin+_twlofs, TWCURS, dp->dd_nam, NAMSIZ, VEBLNK) ;

						if (trixrmdir (dp) == -1)
							break ;

						curwax = --wabinx ;
						goto sowt ;
/*			 _______________________________________________________
 *			|														|
 *			|	+ secure (protect) the current directory ...		|
 *			|_______________________________________________________|
 */
			case CMD_SECDIR :
			case 'p' :
			case 'P' :
						dispat (twlin+_twlofs, TWCURS, dp->dd_nam, NAMSIZ, VEBLNK) ;

						proted (NOFID, dp, 'd') ;
						rescreen (dp, VZRO (FILDAT *)) ;
						goto repag ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ Shell ! ...											|
 *			|___________________________________________________________|
 */
			case CMD_XSHELL :
			case '!' :
			case KF2 :
						if (trixshel () == -1)
							break ;

						rescreen (dp, VZRO (FILDAT *)) ;
						goto repag ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ run any o.s. command ...								|
 *			|___________________________________________________________|
 */
			case CMD_EXEFIL :
			case 'x' :
			case 'X' :
						if (trixexec (NOFID) == -1)
							break ;

						rescreen (dp, VZRO (FILDAT *)) ;
						goto repag ;
/*			 _______________________________________________________
 *			|														|
 *			|	+ Log ...											|
 *			|_______________________________________________________|
 */
			case KF8 :
			case CMD_LOGCWD : goto rlwd ;
			case CMD_LOGTRE :
			case 'l' :

				memset (tb, '\0', 68) ;
				ghelpt = "Ler" ;
				ghyid  = "dir" ;
				grd = trixgets (T_LOG, 'l', tb, 68, 0) ;
				ghyid  = NOSTR ;
				ghelpt = NOSTR ;

				if (grd == ESC)
					break ;

				if (grd == KF3) {
/*
 *					|-----------------------------------------------|
 *					|	re-log curr. sub-tree (sub-directories too)	|
 *					|-----------------------------------------------|
 */
				/*	logcwt (dp) ;	*/

				} else if (grd == ENTER) {
/*
 *					|-----------------------------------------------|
 *					|	re-log current directory (files only) ...	|
 *					|-----------------------------------------------|
 */
					if (tb[0] == '\0') {
rlwd :					logcwd (dp) ;
						retot = TRUE ;
						break ;
					}
/*
 *					|-----------------------------------------------|
 *					|	+ log any subtree (checking already loged &	|
 *					|	  u/d'ng tops list) ...						|
 *					|	+ if the intended sub-tree happen 2 b a top	|
 *					|	  already loged, then free stuff b4 ...		|
 *					|-----------------------------------------------|
 */
					if (rootrix (tb) == -1)
						break ;

					curwax = wabinx ;
					frescrn ((FRESCLR|REFRAME|UDHDRS), NODID, NOFID) ;
					return ;
				}
			break ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ Ordenar (change sort criterion) current dir ...		|
 *			|___________________________________________________________|
 */
			case CMD_ORDCUR :
			case 'o' :
						if (trixord ('o') == ESC)
							break ;

						qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
								sizeof (FILDAT *), filcmp) ;
			break ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ Ordenar (change sort criterion) todos os diretorios	|
 *			|___________________________________________________________|
 */
			case CMD_ORDALL :
			case 'O' :
						if (trixord ('O') == ESC)
							break ;

						trixsort () ;
			break ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ family of files : File Specification ...				|
 *			|___________________________________________________________|
 */
			case CMD_FAMRXP :
			case 'f' :
			case 'F' :
						trixfam () ;
						frescrn (UDMATS|UDRGXP, gpan, VZRO (FILDAT *)) ;
			break ;
/*			 _______________________________________________________
 *			|														|
 *			|	+ local (per-"root") panoramic operation ...		|
 *			|_______________________________________________________|
 */
			case CMD_GLOBAL :
			case 'g' :
			case 'G' :
				if (MATFILS <= 0)
					break ;
				gtwtopg = twtopg ; gtwlin = twlin ;
				gwabp = wabp ; gwabtop = wabtop ; gwabinx = wabinx ;
				dispat (twlin+_twlofs, TWCURS, dp->dd_nam,
						strlen (dp->dd_nam), VEHILT) ;
				gpan->dd_fil = (FILDAT * *) CALLOC ((int) (TOTFILS),
												sizeof (FILDAT *)) ;
				gpan->dd_mfl = (FILDAT * *) CALLOC ((int) (TOTFILS),
												sizeof (FILDAT *)) ;
				if ( gpan->dd_fil == VZRO (FILDAT * *) ||
					 gpan->dd_mfl == VZRO (FILDAT * *)    )
						trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
				trixpan (PANFIL|PANMFL) ; trixtate = 'f' ;
				grd = filwut (gpan, (FWPLAY|FWPAN)) ;
# ifdef BIGTRX
				if ( ! nflg ) {
					flipath ('d') ;
					frescrn (UPATHDR, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
				} else {
					dispat (_botfilnamlin, 0, NOSTR, _vdocols-1, VENORM) ;
				}
# endif
# ifdef XENIX
				free ((char *)(gpan->dd_fil)) ;
				free ((char *)(gpan->dd_mfl)) ;
# else  /* ! XENIX */
				free (gpan->dd_fil) ; free (gpan->dd_mfl) ;
# endif /* XENIX */
				goto rff ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			case CMD_QUITOS :
			case 'q' :
			case 'Q' :
			case CTRL_Q :
			case ESC : byechk () ; break ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			default : honk () ; break ;

		} /* endof switch key */

	} /* endof for ever walk */

} /* endof wabtree */

/*			 _______________________________________________________
 *			|														|
 *			|	display a pagefull of the current tree drawing ...	|
 *			|_______________________________________________________|
 */

void disptree () {
	REG int k = 0 ;
	REG int twlin = gtwlin ;
	REG int wabinx = gwabinx ;
	REG char * * twtopg = gtwtopg ;
	REG DIRDAT * * wabp = gwabp ;
	REG DIRDAT * * wabtop = gwabtop ;
	REG DIRDAT * dp ;
	REG char * tp ;
	/*___________________________________________________________________
	 *	+ ...
	 */
# ifdef		ANYX

	REG int kinvis ;
# ifndef	TREEDRAWW
	FIX int dinvis = 0 ;
# endif		/* ! TREEDRAWW */

# ifdef		TREEDRAWW

	REG int gdlen ;

# else		/* OLDTREEDRAW */

	if (dinvis == 0)
		dinvis = strlen (*(efon[VEAGCS])) + strlen (*(efof[VEAGCS])) ;

# endif		/* TREEDRAWW */

# else		/* DOS */

	REG int gdlen ;

# endif		/* ANYX */

	/*___________________________________________________________________
	 *	+ ...
	 */

# ifdef XTRC
	fprintf (trcfp, "disptree()\r\n") ;
# endif

/* repag : */
	for ( k = 0 ; k < _twlins ; ++k ) {
		tp = NOSTR ;
		dp = *wabp ;
# ifndef	DOS
		kinvis = 0 ;
# endif		/* DOS */
		if ( ( (twtopg + k) - piclst ) < (TOTDIRS) ) {
			tp = *(twtopg + k) ;
			dp = *(wabtop + k) ;
# ifndef	DOS
            if (vdotyp == 't')
# ifdef TREEDRAWW
				kinvis = 0 ;
# else  /* OLD */
    			kinvis = dinvis ;
# endif /* TREEDRAWW */
/*          else
                kinvis = 0 ; */
# endif		/* ! DOS */
		}

# ifdef TREEDRAWW

		if (vdotyp == 't') {
			gdlen = dp->dd_depth * GTPLEN ;
# ifdef SAFE
			strcpy (tb, tp) ;
			tb [gdlen] = '\0' ;
			dispat (k+_twlofs, _twcofs, tb, gdlen, VEAGCS) ;
# else  /* FAST */
			if (tp != NOSTR)
				dispat (k+_twlofs, _twcofs, tp, gdlen, VEAGCS) ;
# endif /* SAFE */
			if (tp == NOSTR)
				dispat (k+_twlofs, _twcofs, tp, _twlinw+1+VINVIS, VENORM) ;
			else
				dispat (k+_twlofs, TWCURS, dp->dd_nam, _twlinw+1-gdlen, VENORM) ;
		} else
			dispat (k+_twlofs, _twcofs, tp, _twlinw+1+VINVIS, VENORM) ;

# else  /* OLD */

		dispat (k+_twlofs, _twcofs, tp, _twlinw+1+VINVIS, VENORM) ;

# endif /* TREEDRAWW */

	}
	dp = *(wabp + wabinx) ; tp = dp->dd_nam ; k = strlen (tp) ;
	dispat (twlin+_twlofs, TWCURS, tp, k, VEHILT) ;
}

/*                       ___________________________________________
 *			            |											|
 *			            |	create directory under current 1 ...	|
 *			            |___________________________________________|
 */

EXT		char * *	picptr ;
EXT		DIRDAT * *	wabptr ;

int trixmkdir (dp) DIRDAT * dp ; {
		char nudirnam [512] , tb [512] ;
	REG int ns, grd ;
	REG DIRDAT *	tdp ;
	REG DIRDAT * *	tdpp ;
	REG char * tp ;
		STABLK stabuf ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	request nu dir's name ...							|
 *	|_______________________________________________________|
 */
	sprintf (tb, T_MKDIR, dp->dd_path) ;

	ghyid = "din" ;
	grd = asktxt (tb, T_NUDIRNAM, nudirnam, 40, 0) ;
	ghyid = NOSTR ;

	if (grd != ENTER)
		return -1 ;

	if (strlen (nudirnam) <= 0)
		return -1 ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	call low level mkdir service ; get nu status ...	|
 *	|_______________________________________________________|
 */
	sprintf (tb, "%s%c%s", dp->dd_path, DIRSEP, nudirnam) ;

# ifdef DOS
	strupr (tb) ;
# endif /* DOS */

	if (xmkdir (dp, tb) == -1) {
		return -1 ;
	}

	xstatus (tb, &stabuf) ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	u/d dirdat & all the rest ...						|
 *	|_______________________________________________________|
 */
	if ((tdpp = dp->dd_dil) != VZRO (DIRDAT * *)) {
		ns = ((int)(dp->dd_dik) + 1) * sizeof (DIRDAT *) ;
		tdpp = (DIRDAT * *) REALLOC ( (char *) tdpp, ns) ;

		if (tdpp == (DIRDAT * *) 0) {
rrmd :
			trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;
		}
	} else {
		if (FALLOP (tdpp, DIRDAT *)) {
nmmd :
			trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
		}
	}

	if (FALLOP (tdp, DIRDAT)) {
		goto nmmd ;
	}

	ns = strlen (tb) ;
	tp = malloc (ns + 1) ;

	if (tp == VZRO (char *))
		goto nmmd ;

	strcpy (tp, tb) ;

	dp->dd_dil = tdpp ;
	tdpp += (int)(dp->dd_dik) ;
	dp->dd_dik += 1 ;
	*tdpp = tdp ;
	tdp->dd_path = tp ;
	tdp->dd_nam = strrchr (tp, DIRSEP) + 1 ;
	tdp->dd_dir = dp ;
	STRUCPY (tdp->dd_stabuf, stabuf) ;
	tdp->dd_flg = 0x0000 ; tdp->dd_depth = dp->dd_depth + 1 ;
	tdp->dd_fib = tdp->dd_mfb = tdp->dd_tfb = 0L ;
	tdp->dd_fik = tdp->dd_mfk = tdp->dd_tfk = tdp->dd_dik = 0L ;
	tdp->dd_fil = tdp->dd_mfl = (FILDAT * *) 0 ;
	tdp->dd_dil = (DIRDAT * *) 0 ; tdp->dd_maxlen = 0 ;
	TOTDIRS += 1 ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	re-draw tree in memory ...							|
 *	|_______________________________________________________|
 */
	ns = (int) ( (TOTDIRS) * sizeof (char *) ) ;
	piclst = (char * *)   REALLOC ((char *) piclst, ns) ;
	ns = (int) ( (TOTDIRS) * sizeof (DIRDAT *) ) ;
	wablst = (DIRDAT * *) REALLOC ((char *) wablst, ns) ;

	if (piclst == VZRO (char * *) || wablst == VZRO (DIRDAT * *))
		goto rrmd ;

	gtop->td_pil = picptr = piclst ; gtop->td_wal = wabptr = wablst ;
	*picptr++ = groot->dd_nam ;
	listree (gtop->td_bot) ;
	wablst = gtop->td_wal ; piclst = gtop->td_pil ;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	return 0 ;

} /* endof trixmkdir () */

/*                           _______________________________________
 *			                |										|
 *			                |	portably create a directory ...		|
 *			                |_______________________________________|
 */

int xmkdir (dp, nam) DIRDAT * dp ; char * nam ; {

# ifdef DOS

    if (dp == NODID)
        return -1 ;

	if ( mkdir (nam) < 0 ) {
		trixerr (T_EMKDIR, nam, errno, BANAL) ;
        return -1 ;
    }

# else  /* ANYX */

    char dnam [512] ;
    char pnam [512] ;
    char dotb [512] ;
    char do2b [512] ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	get dir's & parent's name ...   |
 *	|___________________________________|
 */
    strcpy (dnam, nam) ;
    strcpy (pnam, dp->dd_path) ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	chk if father's writable ...    |
 *	|___________________________________|
 */
    if (access (pnam, W_OK) < 0) {
		trixerr (T_ENWDIR, pnam, errno, BANAL) ;
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	create, personalize & protect dir ...    |
 *	|____________________________________________|
 */
    if (mknod (nam, ((S_IFDIR)|((~ cmask) & 0777)), 0) < 0) {
		trixerr (T_EMKDIR, nam, errno, BANAL) ;
        return -1 ;
    }

    if (chown (nam, realuid, realgid) < 0) {
        unlink (nam) ;
		trixerr (T_ESUGID, nam, errno, BANAL) ;
        return -1 ;
    }

# ifdef COMMENT

    if ( chmod ( nam , ((~ cmask) & 0777) ) < 0 ) {
        unlink (nam) ;
		trixerr (T_CHMERR, nam, errno, BANAL) ;
        return -1 ;
    }

# endif /* COMMENT */

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	mk "dir/."          |
 *	|_______________________|
 */
    sprintf (dotb, "%s/.", dnam) ;

    if (link (dnam, dotb) < 0) {
        unlink (nam) ;
		trixerr (T_ECREAT, dotb, errno, BANAL) ;
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	mk "dir/.."         |
 *	|_______________________|
 */
    sprintf (do2b, "%s/..", dnam) ;

    if (link (pnam, do2b) < 0) {
        unlink (dotb) ;
        unlink (nam) ;
		trixerr (T_ECREAT, do2b, errno, BANAL) ;
        return -1 ;
    }

# endif /* DOS */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	return 0 ;

} /* endof xmkdir () */

/*			                     ___________________________________
 *								|									|
 *								|	delete current directory ...	|
 *			                    |___________________________________|
 */

EXT		char * *	picptr ;
EXT		DIRDAT * *	wabptr ;

int trixrmdir (dp) DIRDAT * dp ; {
	REG DIRDAT *	pdp ;			/* parent dirdat ...	*/
	REG DIRDAT *	xdp ;
	REG DIRDAT * *	tdpp ;
	REG	int			ns ;
		char		tb [512] ;
		char		mb [512] ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	non-empty dirs cannot be removed ...	|
 *	|___________________________________________|
 */
	if (dp->dd_fik > 0 || dp->dd_dik > 0) {
		trixerr (T_ENEDIR, dp->dd_nam, NOWHY, BANAL) ;
		return -1 ;
	}
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	never rm curr working dir ...   |
 *	|___________________________________|
 */
	strcpy (tb, dp->dd_path) ;

    if (strcmp (tb, origwd) == 0) {
		trixerr (T_ERMCWD, NOSTR, NOWHY, BANAL) ;
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	PROVISORY BEHAVIOR :                |
 *  |   if it's the last (topmost) dir,     |
 *  |       then deny deletion              |
 *  |   PROPER ACTIONS :                    |
 *  |       reset top & groot pointers,     |
 *  |       --topn, adjust tops'list,       |
 *  |       set flg (or rtn -2) so that     |
 *  |       wabtrix returns 2 the next      |
 *  |       topdat or just ends ...         |
 *	|_______________________________________|
 */
    if (dp->dd_dir == (DIRDAT *) 0) {
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	call low level rmdir service ...	|
 *	|_______________________________________|
 */
	sprintf (mb, T_RMDIR, tb) ;
	ns = askyn (mb, T_RUSURE) ;

	switch (ns) {
		case ENTER :
		case NOPE  : return -1 ;
		case CTRL_Q :
		case ESC   : return ESC ;
		case YEAH  : break ;
	}

	if (xrmdir (dp) == -1) {
		return -1 ;
	}
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	u/d dirdat & all the rest ...	|
 *	|___________________________________|
 */
	xdp = dp ; pdp = xdp->dd_dir ;
	TOTDIRS -= 1 ; pdp->dd_dik -= 1 ;
	free ((char *) xdp->dd_path) ;

	if (pdp->dd_dik >= 1) {
		tdpp = pdp->dd_dil ;
		while (*tdpp != xdp)
			++tdpp ;
		while ((int) (tdpp - (pdp->dd_dil)) < (int) (pdp->dd_dik)) {
			*tdpp = *(tdpp+1) ;
			*(tdpp+1) = NODID ;
			++tdpp ;
		}
	} else {
		free ((char *) (pdp->dd_dil)) ;
		pdp->dd_dil = VZRO (DIRDAT * *) ;
	}
	free ((char *) xdp) ; /* RELEASED UNDER OBSERVATION ! */
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	re-draw tree in memory ...	|
 *	|_______________________________|
 */
	ns = (int) ( (TOTDIRS) * sizeof (char *) ) ;
	piclst = (char * *)   REALLOC ((char *) piclst, ns) ;
	ns = (int) ( (TOTDIRS) * sizeof (DIRDAT *) ) ;
	wablst = (DIRDAT * *) REALLOC ((char *) wablst, ns) ;

	if (piclst == VZRO (char * *) || wablst == VZRO (DIRDAT * *))
		trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;

	gtop->td_pil = picptr = piclst ; gtop->td_wal = wabptr = wablst ;
	*picptr++ = groot->dd_nam ;
	listree (gtop->td_bot) ;
	wablst = gtop->td_wal ; piclst = gtop->td_pil ;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	return 0 ;

} /* endof trixrmdir () */

/*							 _______________________________________
 *							|										|
 *							|	portably delete a directory ...		|
 *							|_______________________________________|
 */

int xrmdir (dp) DIRDAT * dp ; {

# ifdef DOS

	if ( rmdir (dp->dd_path) < 0 ) {
		trixerr (T_ERMDIR, dp->dd_nam, errno, BANAL) ;
        return -1 ;
    }

# else  /* ANYX */

    char dnam [512] ;
    char pnam [512] ;
    char dotb [512] ;
    char do2b [512] ;
	int lrd = 0 ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	get dir's & parent's name ...   |
 *	|___________________________________|
 */
    strcpy (dnam, dp->dd_path) ;
    strcpy (pnam, dp->dd_dir->dd_path) ;
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	chk if father's writable ...    |
 *	|___________________________________|
 */
    if (access (pnam, W_OK) < 0) {
		trixerr (T_ENWDIR, pnam, errno, BANAL) ;
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	chk if dir's writable ...       |
 *	|___________________________________|
 */
    if (access (dnam, W_OK) < 0) {
		trixerr (T_ENWDIR, dnam, errno, BANAL) ;
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	rm "dir/."          |
 *	|_______________________|
 */
    sprintf (dotb, "%s/.", dnam) ;

    if (unlink (dotb) < 0) {
		trixerr (T_CANTRM, dotb, errno, BANAL) ;
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	rm "dir/.."         |
 *	|_______________________|
 */
    sprintf (do2b, "%s/..", dnam) ;

    if (unlink (do2b) < 0) {
        lrd = link (dnam, dotb) ;
		trixerr (T_CANTRM, do2b, errno, BANAL) ;
        return -1 ;
    }
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	rm "dir" itself     |
 *	|_______________________|
 */
    if (unlink (dnam) < 0) {
        lrd = link (dnam, dotb) ;
        lrd = link (pnam, do2b) ;
		trixerr (T_CANTRM, dnam, errno, BANAL) ;
        return -1 ;
    }

	if ( lrd < 0 ) {
		fprintf (stderr, "xrmdir: code %d\r\n", lrd) ;
	}

# endif /* DOS */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	return 0 ;

} /* endof xrmdir () */

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

/*
 * vi:nu tabstop=4
 */
