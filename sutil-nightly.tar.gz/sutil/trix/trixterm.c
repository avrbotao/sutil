
/************************************************************************
*	trixterm + terminal handling general interfaces ...					*
************************************************************************/

# include	<stdio.h>

/* - - - - - - - - - - - - - - - - - - - - - - - - - */

# ifdef		DOS
#	include		<string.h>
#	include		<conio.h>
# endif		/* DOS */

/* - - - - - - - - - - - - - - - - - - - - - - - - - */

# ifdef		ANYX
#	ifndef	CURSES
#		if defined (FREEBSD) || defined (OPENBSD)
#			include	<termios.h>
#			define	termio		termios
#		else
#			include	<termio.h>
#		endif
#	endif	/* CURSES */
# endif		/* ANYX */

# if defined (OPENBSD)
# define TAB3 0x00
# endif /* FREEBSD */

# if defined (FREEBSD) || defined (OPENBSD)
# include <sys/ioctl.h>
# endif /* FREEBSD */

# ifdef EDIX
# include <sys/ioctl.h>
# endif /* EDIX */

# ifdef		CYGWIN
int ioctl () ;
# endif		/* CYGWIN */

/* - - - - - - - - - - - - - - - - - - - - - - - - - */

# include	"trix.h"
# include	"trixstd.h"
# include	"trixfunc.h"
# include	"trixchrs.h"
# include	"trixext.h"
# include	"trixblue.h"
# include	"trixwind.h"
# include	"trixtext.h"
# include	"trixvdo.h"

/*======================================================================*
*	+ unixes dependancies ...											*
*======================================================================*/

# ifdef		ANYX

#	define	ABXTCAP

#	define	FASTVIDIO

#	ifdef		ABXTCAP

#		undef		CAPTRC				/* tcap trace mech.	*/

#		ifdef		ANSI

/* ... judicious prototypes ... */

#		else		/* OLD STYLE */

int		tnamatch	( ) ;
int		padding		( ) ;
int		tgetent		( ) ;
int		tgetflag	( ) ;
int		tgetnum		( ) ;
int		termflag	( ) ;
int		termnum		( ) ;
char *	tskip		( ) ;
char *	tgoto		( ) ;
char *	tgetstr		( ) ;
char *	termstr		( ) ;
char *	termpad		( ) ;
char *	termgoto	( ) ;
void	tputs		( ) ;
void	tdecode		( ) ;

#		endif		/* ANSI */

#	endif		/* ABXTCAP */

#	ifndef	CURSES

EXT		int			tfd, vdotyp ;
EXT		BYT			dhdvfram [ ] ;
EXT		BYT			shsvfram [ ] ;
EXT		BYT			dhsvfram [ ] ;
EXT		BYT			shdvfram [ ] ;
EXT		BYT			dashfram [ ] ;
EXT		char		termid [ ] ;
EXT		char		altgcs [ ] ;
EXT		char		tgetbuf [ ] ;
EXT		char		glast [ ] ;
EXT		char		geach [ ] ;
EXT		char		gspac [ ] ;
EXT		char		gstik [ ] ;
EXT		char *		cmbuf ;
EXT		char *		clbuf ;
EXT		char *		blbuf ;
EXT		char *		qdbuf ;
EXT		char *		qsbuf ;
EXT		char *		qhbuf ;
EXT		char *		qvbuf ;
EXT		char *		qxbuf ;
EXT		char *		qybuf ;
EXT		char *		gsbuf ;
EXT		char *		gebuf ;
EXT		CAPCTL		capbuf [ ] ;
EXT		struct termio	orig ;
EXT		struct termio	work ;
EXT		KEYINFO		keylst [] ;
EXT		int		totkeys ;
EXT     VSTAT   vsbuf ;

#	ifdef		ANSI
int		keycmp ( void * , void * ) ;
#	else		/* OLD STYLE */
int		keycmp ( ) ;
#	endif		/* ANSI */

#	endif		/* CURSES */

# endif		/* ANYX */

/*======================================================================*
*	+ universal dependancies ...										*
*======================================================================*/

EXT		BYT		dhdvfram [] ;
EXT		BYT		xfram [] ;
EXT		int		gflg ;

/************************************************************************
*																		*
*	initialize terminal settings ...									*
*																		*
*	initerm may be called when getting back from a shell ...			*
*																		*
************************************************************************/

void initerm ( ) {

# ifdef ANYX

# ifdef		CURSES

	initscr ( ) ;
	nl ( ) ;

# else		/* HOME_MADE */

	int res ;
	char * tp , * xp ;
	char tb [ 512 ] ;
	REG CAPCTL * cap ;
    REG KEYINFO * kip ;
    int ek = 0 ;

# ifdef XTRC
	fprintf (trcfp, "initerm()\r\n") ;
# endif

	/*___________________________________________________________________
	 *	get term caps ...
	 */
	tp = getenv ("TERM") ;

	if (tp == NOSTR) {
nvt :
		fprintf (stderr, "ERRO ao obter variavel ambiental (TERM) !\n") ;
		exit (0) ;
	}
	if (*tp == '\0')
		goto nvt ;
	strcpy (termid, tp) ;

# ifdef XTRC
	fprintf (trcfp, "TERM=%s\r\n", tp /* termid */ ) ;
# endif

	res = tgetent (tgetbuf, tp /* termid */) ;

	if (res == -1) {
		fprintf (stderr, "ERRO ! arquivo \"term.dat\" inacessivel !\n") ;
		exit (0) ;
	}
	if (res == 0) {
		fprintf (stderr, "ERRO ! terminal \"%s\" nao encontrado em \"%s\" !\n",
				tp /* termid */, "trixterm.dat") ;
		exit (0) ;
	}
	/********************************************************************
	 *	cursor motion , video effects & screen ctrl ...
	 */
	for ( cap = capbuf ; cap->capid ; ++cap ) {

		*(cap->captr) = NOSTR ;
		tp = tb ;
		tp = (char *) tgetstr ( cap->capid , &tp ) ;

		if (tp == NOSTR) {
ncd :
			fprintf (stderr, "**** string \"%s\" nao definida ...\n",
					cap->capid) ;
            ++ek ;
			continue ;
		}
		if (*tp == '\0') 
			goto ncd ;
		res = strlen ( tp ) ;
		*(cap->captr) = malloc ( res + 1 ) ;

		if ( *(cap->captr) == VZRO (char *) ) {
			fprintf (stderr , "**** memoria insuficiente !\n") ;
			exit (0) ;
		}
		strcpy ( *(cap->captr) , tp ) ;
		cap->caplen = res ;

/* # define	DBUGTERMCAP */

# ifdef		DBUGTERMCAP
		fprintf (stderr, "**** term \"%s\" cap \"%s\" : { ",
				termid, cap->capid) ;
		for ( res = 0 ; res < cap->caplen ; ++res )
			if ( *(tp+res) >= 33 && *(tp+res) <= 126 )
				fprintf (stderr, "%c ", *(tp+res)) ;
			else
				fprintf (stderr, "%d ", *(tp+res)) ;
		fprintf (stderr, "}\n") ;
		fflush  (stderr) ;
# endif		/* DBUGTERMCAP */

	}
	/********************************************************************
	 *	keypad strings ...
	 */
	for ( kip = keylst , totkeys = 0 ; kip->ki_nam ; ++kip ) {
		tp = tb ;
		tp = (char *) tgetstr ( kip->ki_cap , &tp ) ;

		if (tp == NOSTR) {
nkd :
			fprintf (stderr, "**** tecla \"%s\" nao definida ...\n",
					kip->ki_nam) ;
            ++ek ;
			continue ;
		}
		if (*tp == '\0') 
			goto nkd ;
		kip->ki_sig = malloc ( strlen (tp) + 1 ) ;

		if ( kip->ki_sig == VZRO (char *) ) {
nmt :		fprintf (stderr , "**** memoria insuficiente !\n") ;
			exit (0) ;
		}
		strcpy ( kip->ki_sig , tp ) ; ++totkeys ;
	}

	qsort ( (char *) keylst, totkeys, KI_SIZ, keycmp) ;

	/********************************************************************
	 *	box & graphic chars ...
	 */

    if (vsbuf.vs_flag & VS_CONS) {
        pcharset () ;               /* load pc char set 4 vdo ram ...   */
	}

	if (qdbuf && qsbuf && qxbuf && qhbuf && qvbuf) {

		if (gflg) {

			if (qdbuf == NOSTR)
				qdbuf = malloc (20) ;
			else
				qdbuf = realloc (qdbuf, 20) ;

			if (qdbuf == NOSTR)
				goto nmt ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			if (qsbuf == NOSTR)
				qsbuf = malloc (20) ;
			else
				qsbuf = realloc (qdbuf, 20) ;

			if (qsbuf == NOSTR)
				goto nmt ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			if (qhbuf == NOSTR)
				qhbuf = malloc (20) ;
			else
				qhbuf = realloc (qdbuf, 20) ;

			if (qhbuf == NOSTR)
				goto nmt ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			if (qxbuf == NOSTR)
				qxbuf = malloc (20) ;
			else
				qxbuf = realloc (qdbuf, 20) ;

			if (qxbuf == NOSTR)
				goto nmt ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			if (qvbuf == NOSTR)
				qvbuf = malloc (20) ;
			else
				qvbuf = realloc (qdbuf, 20) ;

			if (qvbuf == NOSTR)
				goto nmt ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			gsbuf = gebuf = NOSTR ;

			/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */

			strcpy (qdbuf, (char *) dashfram) ;
			strcpy (qsbuf, (char *) dashfram) ;
			strcpy (qhbuf, (char *) dashfram) ;
			strcpy (qvbuf, (char *) dashfram) ;
		}

		strcpy (altgcs, qdbuf) ; strcpy ((char *) dhdvfram, qdbuf) ;
		strcat (altgcs, qsbuf) ; strcpy ((char *) shsvfram, qsbuf) ;
		strcat (altgcs, qxbuf) ;
		strcat (altgcs, qhbuf) ; strcpy ((char *) dhsvfram, qhbuf) ;
		strcat (altgcs, qvbuf) ; strcpy ((char *) shdvfram, qvbuf) ;
        strcat (altgcs, qybuf) ;

	    memcpy (xfram, dhdvfram, FRAMAX) ;

# ifdef ANYX
		if (gflg)
			C_GSPC = ' ' ;
# endif /* ANYX */

	} else {

		fprintf (stderr, "**** Caracteres graficos inacessiveis ...\n") ;
	    memcpy (xfram, dashfram, FRAMAX) ;
	    qsbuf = (char *) dashfram ;
        /*
         *  + must ask 4 continue or quit
         *    (or even get cfg''ed action)
         *    if (continue anyway)
         *      cpy (xfram = dashfram) ;
         *    else
		 *      exit (1) ;
         */
	}
	glast[0] = C_SLL ;
	geach[0] = C_SLT ;
	gstik[0] = C_SVL ;
	gspac[0] = gspac[1] = gspac[2] = gstik[1] = gstik[2] = C_GSPC ;
	glast[1] = glast[2] = geach[1] = geach[2] = C_SHL ;
	glast[3] = geach[3] = gspac[3] = gstik[3] = '\0' ;
/*  ----------------------------------------------------------------    */
    if (ek) {
        printf ("Pressione [Enter] para prosseguir ... ") ;
        xp = fgets (tb, 20, stdin) ;
		if ( xp == NULL ) {
        	printf ("[ctrl]+[D] ? ... ") ;
		}
    }
	/********************************************************************
	 *	+ save & setup term ctl statuses ...
	 */
	TFD = open ("/dev/tty", 2) ;

# if defined (FREEBSD) || defined (OPENBSD)
	if ((res = tcgetattr (TFD, &orig)) == -1)
# else
	if ((res = ioctl (TFD, TCGETA, &orig)) < 0)
# endif
		trixerr (T_NGETERM, NOSTR, NOWHY, FATAL) ;

	STRUCPY (work, orig) ;						/* work = orig ;		*/
	work.c_cc[VMIN] = 1 ;
	work.c_cc[VINTR] = 0x00 ;
	work.c_oflag &= ~ ( OPOST  | TAB3 );			/* TAB3's 4 tputs ...	*/
	work.c_lflag &= ~ ( ICANON | ECHO ) ;
	work.c_iflag &= ~ ( IGNCR  | IXON   | IXANY  | IXOFF  ) ;

# if defined (FREEBSD) || defined (OPENBSD)
	if ((res = tcsetattr (TFD, TCSAFLUSH, &work)) == -1)
# else
	if ((res = ioctl (TFD, TCSETA, &work)) < 0)
# endif
		trixerr (T_NSETERM, NOSTR, NOWHY, FATAL) ;

	hidecursor () ;

# endif		/* CURSES */

# else		/* DOS */

	hidecursor () ;
	memcpy (xfram, dhdvfram, FRAMAX) ;

# endif		/* ANYX */
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	open & ioctls a term ...	|
 *									|_______________________________|
 */

# ifdef		COMMENT /* ANYX */

int openterm () {

	int res ;

	TFD = open ("/dev/tty", 2) ;

	if ((res = ioctl (TFD, TCGETA, &orig)) < 0)
		trixerr (T_NGETERM, NOSTR, NOWHY, FATAL) ;

	STRUCPY (work, orig) ;					/* work = orig ;		*/
	work.c_cc[VMIN] = 1 ;
	work.c_cc[VINTR] = 0x00 ;
	work.c_oflag &= ~ ( OPOST  | TAB3 );	/* TAB3's 4 tputs ...	*/
	work.c_lflag &= ~ ( ICANON | ECHO ) ;
	work.c_iflag &= ~ ( IGNCR  | IXON   | IXANY  | IXOFF  ) ;

	if ((res = ioctl (TFD, TCSETA, &work)) < 0)
		trixerr (T_NSETERM, NOSTR, NOWHY, FATAL) ;
}

# endif		/* ANYX */

/************************************************************************
*																		*
*	reset terminal conditions as of b4 start ...						*
*																		*
*	should (& most probably will) be called b4 a shell ...				*
*																		*
************************************************************************/

void reseterm ( ) {

# ifdef ANYX

# ifdef		CURSES

	endwin ( ) ;

# else		/* ! CURSES */

	int res ;

	showcursor () ;

# if defined (FREEBSD) || defined (OPENBSD)
	if ((res = tcsetattr (TFD, TCSAFLUSH, &orig)) == -1)
# else
	if ((res = ioctl (TFD, TCSETA, &orig)) < 0)
# endif
		trixerr (T_NRETERM, NOSTR, NOWHY, FATAL) ;

	close (TFD) ;						/* not if a sh'll b run ...		*/

# endif		/* CURSES */
# else		/* DOS */
	showcursor () ;
# endif /* ANYX */

}

/************************************************************************
*	+ ...																*
************************************************************************/

void chtermod (what) int what ; {

# ifdef DOS

	if (what == 's')
		showcursor () ;
	else
		hidecursor () ;

# else  /* ANYX */

# ifndef CURSES
	REG struct termio * tp = &work ;
# endif /* ! CURSES */

# ifdef COMMENT
	if (what == 's') {
		showcursor () ;
		tp = &orig ;
	} else
		hidecursor () ;
# endif /* COMMENT */

# ifndef CURSES
	if (what == 's') {
		tp = &orig ;
		showcursor () ;
	}
/*		else
			openterm () ;
*/
# if defined (FREEBSD) || defined (OPENBSD)
	if (tcsetattr (TFD, TCSAFLUSH, tp) == -1)
# else
	if (ioctl (TFD, TCSETA, tp) < 0)
# endif
		trixerr (T_NSETERM, NOSTR, NOWHY, FATAL) ;

	if (what != /* == */ 's')
/*		close (TFD) ;
	else
*/		hidecursor () ;
# else  /* CURSES */

	if (what == 's') {
		showcursor () ;
		/* normalmode () ; */
	} else {
		hidecursor () ;
		/* cbreakmode () ; */
	}

# endif /* ! CURSES */

# endif /* DOS */

}

/************************************************************************
*	locat ...															*
************************************************************************/

# ifdef SIDIX		/* REALLY NEEDED W/ PROP/Y TCAP LIB ???? */
# undef FASTVIDIO	/* SIDIX SHOULDN'T NEED THIS W/ ABXTCAP ... */
# endif /* SIDIX */

void locat (line, column) int line, column ; {				/* ansi ...	*/

# ifdef   ANYX

#	 ifdef		CURSES

	move (line, column) ;

#	 else		/* ! CURSES */

#		 ifdef		FASTVIDIO

	char * tgoto () ;

	REG char * tb ;
	REG int ts = strlen ( tb = tgoto ( cmbuf, column, line ) ) ;

# ifdef LOCTRC
	fprintf (trcfp, "locat(%d,%d)\r\n", line, column) ;
# endif

	gwrd = write (TFD, tb, ts) ;				/*	VPUTS (tb, ts) ;	*/

#		 else		/* DEFAULT */

	tputs ( tgoto ( cmbuf, column, line ) , 0 /* 1 */ , xoutc ) ;

#		 endif		/* FASTVIDIO */

# 		 ifdef		COMMENT

	*(cmbuf + 2) = ((line + 1) / 10) + '0' ;
	*(cmbuf + 3) = ((line + 1) % 10) + '0' ;
	*(cmbuf + 5) = ((column + 1) / 10) + '0' ;
	*(cmbuf + 6) = ((column + 1) % 10) + '0' ;
	VPUTS (cmbuf) ;

#		 endif		/* COMMENT */

#	 endif		/* CURSES */

# endif   /* ANYX */

# ifdef   DOS

#	ifdef TCWAY

	gotoxy ( column + 1 , line + 1 ) ;

#	else  /* MODERN */

	EXT int Tflg ;
	static unsigned oldbp ;

	if (Tflg) {

		char tmpbuf [80] ;

		sprintf (tmpbuf, "\033[%d;%dH", line+1, column+1) ;
		gwrd = write (TFD, tmpbuf, strlen (tmpbuf)) ;	/* strout (tmpbuf, 0) ; */

	} else {

		_DL = column ;
		_DH = line ;
		_AH = 0x02 ; /* SET CURSOR POSITION */
		_BH = 0x00 ;

		_DI = _DI ; /* ???? */
		oldbp = _BP ;
		geninterrupt (0x10) ;
		_BP = oldbp ;

		/* vramline = lin ; */
		/* vramcol  = col ; */
	}

#	endif /* TCWAY */

# endif   /* DOS */

}

/************************************************************************
*	xoutc + output a character (2 b used by tputs ...)					*
************************************************************************/

# ifdef		ANYX

# ifndef	CURSES

int xoutc (x) int x ; {

	char b [4] ;

	b[0] = x ;

	gwrd = write (TFD, &b[0], 1) ;

	return (x) ; /* really needed ? */
}

# endif		/* CURSES */

# endif		/* ANYX */

/************************************************************************
*	dispat + display padded @ y, x w/ attr ...							*
************************************************************************/

void dispat (ylin, xcol, txt, siz, vatr) int ylin, xcol ; char * txt ; int siz, vatr ; {

# ifdef		VDEO

/*_______________________________________________________________________
 *
 *	vrofs = ( ( yl * 50h + xc ) * 2 )
 *	vrofs = ( ( ( yl << 6 ) + ( yl << 4 ) + xc ) << 1 )
 *
 *	meth # 4 : tb = (txt + pad) & atr ; vr = tb
 *	meth # 5 : vr = (txt + pad) & atr ; no tb
 *	meth # 6 : can it b any faster ?
 *_______________________________________________________________________
 */

	NEW char tb [ 512 ] ;

/*_______________________________________________________________________
 *	prologue : sav som regs ...
 */

asm		push	ds ;

/*_______________________________________________________________________
 *	setup 4 tb, atr, ts
 */

asm		les		di, tb ;				/* es:di = tb					*/
asm		mov		ax, vatr ;				/* ax = WORD PTR vatr			*/
asm		mov		ah, al ;				/* ah = atr byt					*/
asm		mov		bl, 0 ;					/* bl = ts = 0					*/

/*_______________________________________________________________________
 *	while (*tb++ = *txt++ & atr) ++ts
 */

asm		lds		si, txt ;				/* ds:si = txt					*/

stwa :									/* stor txt w/ atr				*/

asm		lodsb ;							/* al = *txt++					*/
asm		and		al, al ;				/* if ( al == '\0' )			*/
asm		jz		SHORT padit ;			/*	goto padit					*/
asm		stosw ;							/* *tb++ = ax = *txt & vatr		*/
asm		inc		bl ;					/* ++bl (ts)					*/
asm		jmp		SHORT stwa ;			/* bak 2 eat					*/

/*_______________________________________________________________________
 *	whil (ts < siz) tb = ' ' & atr ...
 */

padit :									/* lets pad'em all ...			*/

asm		mov		al, ' ' ;				/* ax = ' ' & atr				*/

spwa :									/* stor pad w/ atr				*/

asm		cmp		bl, siz ;				/* if ( bl > siz )				*/
asm		ja		SHORT cpvr ;			/*	goto video ram				*/
asm		stosw ;							/* *tb = ax = ' ' & atr			*/
asm		inc		bl ;					/* ++ts							*/
asm		jmp		SHORT spwa ;			/* bak 2 eat					*/

/*_______________________________________________________________________
 *	vid ram ofs = ... (lin, col) = tb , ts
 */

cpvr :									/* cp 2 vid ram					*/

# define  METH2							/* !							*/

# ifdef   METH1							/* ?							*/

asm		mov		cl, 6 ;					/* 1st shft = 64 *				*/
asm		mov		di, ylin ;				/* 2 * by 16					*/
asm		mov		ax, di ;				/* 2 * by 64					*/
asm		shl		ax, cl ;				/* ax = lin * 64 = lin << 6		*/
asm		mov		cl, 4 ;					/* 2nd shft = 16 *				*/
asm		shl		di, cl ;				/* di = lin * 16 = lin << 4		*/
asm		add		di, ax ;				/* di = lin * 80				*/
asm		add		di, xcol ;				/* di += col					*/
asm		shl		di, 1 ;					/* di = lin * 160 + col * 2		*/

# endif   /* METH1 */

# ifdef   METH2

asm		mov		ax, 160d ;				/* ax = byts / lin				*/
asm		mul		WORD PTR ylin ;			/* dx:ax = lin * 160			*/
asm		shl		WORD PTR xcol, 1 ;		/* col *= 2						*/
asm		add		ax, xcol ;				/* ax = y * bpl + x * 2			*/
asm		mov		di, ax ;				/* di = (vro) = ax				*/

# endif   /* METH2 */

# ifdef   METH3

asm		mov		al, 160d ;				/* al = byts / lin				*/
asm     mov		cx, ylin ;				/* cx = lin #					*/
asm		mov		ch, 0 ;					/* low byt only					*/
asm		mul		cl ;					/* ax = al * cl (lin * bpl)		*/
asm		mov		di, xcol ;				/* di = col #					*/
asm		sal		di, 1 ;					/* di *= 2						*/
asm		add		di, ax ;				/* di = y * 160 + x * 2			*/

# endif   /* METH3 */

asm		mov		ax, 0b800h ;			/* ax = vid ram seg				*/
asm		mov		es, ax ;				/* es:di = vid ram seg:ofs		*/
asm		lds		si, tb ;				/* ds:si = tb					*/
asm		mov		cx, siz ;				/* cx = buf siz in byts			*/
asm		cld ;							/* df = 0 : ++					*/
asm		rep		movsw ;					/* whil (cx--) *vr++ = *tb++	*/

/*_______________________________________________________________________
 *	epilogue : pop'em back ...
 */

asm		pop		ds ;

# else    /* ! VDEO */

	NEW BYT tb [ 512 ] ;
	REG BYT * tp = tb ;
	REG int ts = 0 ;

# ifdef   TCWINDOWS

	REG BYT xatr = vatr /* & 0xff */ ;

	if (txt != NOSTR)
		while (*txt) {
			*tp++ = *txt++ ;
			*tp++ = xatr ;
			++ts ;
		}

	while (ts < siz) {
		*tp++ = ' ' ;
		*tp++ = xatr ;
		++ts ;
	}

	puttext (xcol+1, ylin+1, xcol+siz, ylin+1, tb) ;

# else    /* ansi */

# ifdef		CURSES

	if (txt != NOSTR)
		while (*txt) {
			*tp++ = *txt++ ;
			++ts ;
		}

	while (ts < siz) {
		*tp++ = ' ' ;
		++ts ;
	}

	tb [ siz ] = '\0' ;

	attrset (vatr) ;

	mvaddstr (ylin, xcol, tb) ;

	attrset (VENORM) ;

	refresh ( ) ;

# else		/* BRUTE FORCE */

# ifdef STREFF

    	EXT char * * efon [] ;
	    EXT char * * efof [] ;
	    REG char * von = * ( efon [ vatr ] ) ;
	    REG char * vof = * ( efof [ vatr ] ) ;

    	if (von != NOSTR)
    		while (*von) {
    			*tp++ = *von++ ; ++ts ;
    		}

    	if (txt != NOSTR)
    		while (*txt && siz) {
    			*tp++ = *txt++ ; --siz ; ++ts ;
    		}

    	while (siz > 0) {
    		*tp++ = ' ' ; --siz ; ++ts ;
    	}

    	if (vof != NOSTR)
    		while (*vof) {
    			*tp++ = *vof++ ; ++ts ;
    		}

    	locat (ylin, xcol) ;
    	gwrd = write (TFD, tb, ts) ;				/*	VPUTS (tb, ts) ;	*/
    
# else  /* BLESSINGS ! */

        EXT WWINFO * stdww ;
        /* EXT int pc_ca [] ; */
        int xatr ;

/* # define DISTRC */
# ifdef DISTRC
		fprintf (trcfp, "+dispat(%d,%d,[%s],%d,%d)\r\n", ylin, xcol, (txt == NULL) ? "NULL" : txt, siz, vatr) ;
# endif

    	if (txt != NOSTR)
    		while (*txt) {
    			*tp++ = *txt++ ;
                ++ts ;
    		}

    	while (ts < siz) {
    		*tp++ = ' ' ;
            ++ts ;
    	}

    	*tp = tb [ siz ] = '\0' ;

# ifdef COMMENT

        if (vdotyp == 't')
            xatr = vatr ;
        else
            xatr = pc_ca [vatr] ;

# else  /* ! COMMENT */

        xatr = vatr ;

# endif /* COMMENT */

        wwdisp (stdww, ylin, xcol, tb, xatr) ;

/* fprintf (trcfp, "-dispat(%d,%d,[%s],%d,%d)\r\n", ylin, xcol, (txt == NULL) ? "NULL" : txt, siz, vatr) ; */

# endif /* STREFF */

# endif		/* CURSES */

# endif   /* TCWINDOWS */

# endif   /* VDEO */

}

/*
 *						|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *						|	prop/y libtermcap by bud (a.r.r.w.f.)	|
 *						|___________________________________________|
 */

# ifdef		ABXTCAP

# define ENVTERM "TERM"
# define ROWCODE "li"
# define PADCODE "pc"
# define DEFLIN 24

/* extern */ short ospeed = 0 ;
static char PC = { 0 } ;
static int afflines = { DEFLIN } ;
static int delaytab [] = { 0, 2000, 1333, 909, 743, 666, 500, 333, 166, 83, 55, 41, 20, 10, 5, 2 } ;

# define ENVTCAP "TERMCAP"
# define TERMDB "/etc/termcap"
# define TBUFSIZ /* 1024 */ 2048
# define MAP "E\033^^\\\\::n\nr\rt\tb\bf\f"
# define BCCODE "bc"
# define UPCODE "up"

static char * termbase ;
/* static */ char * BC = (char *) 0 /* { 0 } */ ;
/* static */ char * UP = (char *) 0 /* { 0 } */ ;

# ifdef ANSI

/*	...		*/

# else  /* OLD STYLE */

void	tdecode		( ) ;
char *	termpad		( ) ;
char *	termgoto	( ) ;

# endif /* ANSI */

char	trixtermpath [4096] ;

extern	char	trixworkpath [] ;
extern	int		fastworkflag ;

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

/* static */ int tgetent (bp, name) char * bp , * name ; {
	char * s /* = (char *) 0 */ ;
	char buf [TBUFSIZ] ;
	char c ;
/*	char * getenv ( ) ; */
	int fd, n, i ;

	FILE * tfp ;

# undef ORIGINAL

# ifdef ORIGINAL

	if (! (s = getenv (ENVTCAP)) || ! *s) {
		s = TERMDB ;
	} else {
		if (*s != '/') {
			strcpy (bp, s) ;
			return 1 /* ? 0 */ ;
		}
	}

# else  /* MUST WORK */

#	ifdef	FORCEIT

	s = TERMDB ;

#	else  /* POLITE */

	s = getenv (ENVTCAP) ;

	if (! s) {
		if ( fastworkflag ) {
			sprintf (s = trixtermpath, "%s/%s", trixworkpath, "trixterm.dat") ;
		} else {
			s = TERMDB ;
		}
	} else {
		if (*s == '\0') {
			s = TERMDB ;
		} else {
			if (*s != '/') {
				strcpy (bp, s) ;
				return 1 ;
			}
		}
	}

#	endif /* FORCEIT */

# endif /* ORIGINAL */

	tfp = trixfopen ( /* basename(s) */ "trixterm.dat" , "r" ) ;

	if ( tfp == NULL ) {
		fd = open (s, 0) ;
	} else {
		fd = fileno (tfp) ;
	}

	if ( fd < 0 ) {
		fprintf (stderr, "tgetent: erro ao abrir %s\r\n", s) ;
		return (-1) ;
	}
	termbase = bp ;
	for ( s = bp, i = n = 0 ;
	      i != n || (n = read (fd, buf, TBUFSIZ)) > (i = 0) ; ) {
		if ((c = buf[i++]) != '\n' && s < bp + TBUFSIZ) {
			*s++ = c ;
			continue ;
		}
		if (c == '\n' && s > bp && s[-1] == '\\') {
			--s ;
			continue ;
		}
		*s = '\0' ;
		if (tnamatch (name)) {
			if ( tfp == NULL ) {
				close (fd) ;
			} else {
				fclose (tfp) ;
			}
			return (1) ;
		}
		s = bp ;
	}
	if ( tfp == NULL ) {
		close (fd) ;
	} else {
		fclose (tfp) ;
	}
	return (0) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

/* static */ int tnamatch (name) char * name ; {
	char * s , * t ;

	s = termbase ;
	if (*s == '#')
		return (0) ;
	while (1) {
		t = name ;
		while (*t && *s == *t) {
			++s ;
			++t ;
		}
		if (! *t && ! (*s && *s != '|' && *s != ':'))
			return (1) ;
		while (*s && *s != ':' && *s != '|')
			++s ;
		if (! *s || *s == ':')
			return (0) ;
		++s ;
	}
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

/* static */ char * tskip (s) char * s ; {

	while (*s && *s != ':')
		++s ;
	if (*s == ':')
		++s ;
	return (s) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

int tgetflag (id) char * id ; {

	return (termflag (id)) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

int termflag (id) char * id ; {
	char * s ;
	char * tskip ( ) ;

	s = termbase ;
	while (*(s = tskip (s))) {
		if (s[0] == id[0] && s[1] && s[1] == id[1]) {
			if (s[2] == '@') {
				break ;
			} else {
				if (! s[2] || s[2] == ':') {
					return (1) ;
				}
			}
		}
	}
	return (0) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

int tgetnum (id) char * id ; {

	return (termnum (id)) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

int termnum (id) char * id ; {
	char * s ;
	char * tskip ( ) ;
	int base, tot ;

	s = termbase ;
	while (*(s = tskip (s))) {
		if (s[0] == id[0] && s[1] && s[1] == id[1]) {
			if (s[2] == '@') {
				break ;
			} else {
				if (s[2] == '#') {
					base = *(s += 3) == '0' ? 8 : 10 ;
					for ( tot = 0 ; *s >= '0' && *s <= '9' ; ++s ) {
						tot *= base , tot += *s - '0' ;
					}
					return (tot) ;
				}
			}
		}
	}
	return (-1) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

char * tgetstr (id, area) char * id , * * area ; {
	char * s ;
	char * t ;
	char * termstr ( ) ;

	t = s = termstr (id) ;

	if (t == (char *) 0)
		return (char *) 0 ;

	for ( ; *s ; **area = *s++ , ++*area )
		;

	**area = '\0' ; ++*area ;

	return (t) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

char * termstr (id) char * id ; {
	char * s ;
	char buf [TBUFSIZ] ;
	char * tskip ( ) ;
	register int found = 0 ;

	buf[0] = '\0' ;
	s = termbase ;
	while (*(s = tskip (s))) {
		if (s[0] == id[0] && s[1] && s[1] == id[1]) {
			found = 1 ;
			if (s[2] == '@') {
				break ;
			} else {
				if (s[2] == '=') {
					tdecode (s + 3, buf) ;
					break ;
				}
			}
		}
	}
	if (! found)
		return (char *) 0 ;
	if (! (s = malloc ((unsigned) strlen (buf) + 1)))
		return (char *) 0 ;
	strcpy (s, buf) ;
	return (s) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

/* static */ void tdecode (s, buf) char * s , * buf ; {
	char * map ;
	char c ;
	int i ;

	for ( ; (c = *s++) && c != ':' ; *buf++ = c ) {
		if (c == '^') {
			c = *s++ & 037 ;
		} else {
			if (c == '\\') {
				for ( c = *s++ , map = MAP ; *map && *map != c ; map += 2 )
					;
				if (*map) {
					c = map[1] ;
				} else {
					if (c >= '0' && c <= '9') {
						c -= '0' , i = 2 ;
						do {
							c <<= 3, c |= *s++ - '0' ;
						} while (--i && *s >= '0' && *s <= '9') ;
					}
				}
			}
		}
	}
	*buf = '\0' ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

char * tgoto (cm, col, lin) char * cm ; int col, lin ; {
	static int p ;

# ifdef CAPTRC
	fprintf (trcfp, "tgoto (%s) (%d) (%d)\r\n", cm, col, lin) ;
# endif /* CAPTRC */

	p = 20 ;
	return (termgoto (cm, lin, col, &p)) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

/* # define TGTTRC */

char * termgoto (cm, row, col, pn) char * cm ; int row, col, * pn ; {
	static char curbuf1 [/*128 256*/512] ;
	static char curbuf2 [/* 64 128*/256] ;
	static char numbuf [9] ;
	static char padbuf [128] ;
	char * s ;
	char c ;
	int val , flag ;

	if (BC == (char *) 0) {
		BC = termstr (BCCODE) ;
	}

	if (UP == (char *) 0) {
		UP = termstr (UPCODE) ;
	}

	s = curbuf1 , curbuf2[0] = '\0' ;
	flag = 0 , val = row ;
	while ((c = *cm++) != 0) {
		if (c != '%') {
			*s++ = c ;
		} else {
			switch (c = *cm++) {
				case 'd' :
				case '2' :
				case '3' :
# ifdef BIGTRX
					sprintf (numbuf, "%d", val) ;
					strcpy (s, numbuf) ;
					s += strlen (numbuf) ;
# else	/* OLDTRX */
					if (val >= 100 || c == '3') {
						*s++ = val / 100 | '0' , val %= 100 ;
					}
					if (val >= 10 || c != 'd') {
						*s++ = val / 10 | '0' ;
					}
					*s++ = val % 10 | '0' ;
# endif	/* OLDTRX */
					val = (flag = ! flag) ? col : row ;
				break ;

				case '+' :
					val += *cm++ ;
# if defined (__GNUC__) || defined (gcc) || defined (__GCC__) || defined (__gcc__) || defined (GCC)
					__attribute__ ((fallthrough));
# endif

				case '.' :
					if ((! val || val == 4 || val == 10) && (flag || UP)) {
						do {
							strcat (curbuf2, ! flag ? UP : BC ? BC : "\b") ;
						} while (++val == 10) ;
					}
					*s++ = val , val = (flag = ! flag) ? col : row ;
				break ;

				case '>' :
					if (val > *cm++) {
						val += *cm++ ;
					} else {
						++cm ;
					}
				break ;

				case 'r' :	flag = 1 , val = col ; break ;
				case 'i' :	++col , ++row , ++val ; break ;
				case '%' :	*s++ = c ; break ;

				case 'n' :
					col ^= 0140 , row ^= 0140 ;
					val = flag ? col : row ;
				break ;

				case 'B' : val = ((val / 10) << 4) + (val % 10) ; break ;
				case 'D' : val -= (val & 017) << 1 ; break ;
				default : break ;
			} /* eoswitch */
		} /* endif */
# ifdef TGTTRC
		*s = '\0' ;
		fprintf (trcfp, "termgoto(%d,%d) : flag=%d val=%d cb={%s}\r\n", row, col, flag, val, curbuf1+1) ;
# endif
	} /* eowhile */
	*s++ = '\0' ;

# ifdef CAPTRC
	captrc ("cm", curbuf1) ;
# endif /* CAPTRC */

# ifdef OLDPAD

	strcat /* ? cpy ? */ (s, curbuf2) ;
	return (termpad (curbuf1, pn)) ;

# else  /* NOPAD */

# ifdef GTSTRC
	fprintf (trcfp, "termgoto(%d,%d)={ ", row, col) ;
	for ( s = curbuf1 ; *s ; ++s ) {
		if ( *s >= 33 && *s <= 126 ) {
			fprintf (trcfp, "%c ", *s) ;
		} else {
			fprintf (trcfp, "%d ", *s) ;
		}
	}
	fprintf (trcfp, "}\r\n") ;
# endif

	if ( pn == NULL )
		pn = (int *)padbuf ;

	return curbuf1 ;

# endif /* OLDPAD */

}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

char * termpad (s, pn) char * s ; int * pn ; {
	int delay, i ;
	char * t ;
	char * u ;

	delay = ospeed <= 0 || ospeed >= 16 ? 0 : delaytab[ospeed] ;
	i = padding (&s, afflines, delay) ;
	*pn = i + strlen (s) ;
	if (! (u = malloc (1 + (unsigned) *pn))) /* LAB(<1+>...) */
		return (char *) 0 ;
	for ( t = u ; *s ; *t++ = *s++ )
		;
	while (i--)
		*t++ = PC ;
	return (u) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

/* static */ int padding (ps, l, delay) char * * ps ; int l, delay ; {
	int n ;
	char * s ;

	s = *ps ;
	for ( n = 0 ; *s >= '0' && *s <= '9' ; n += *s++ - '0', n *= 10 )
		;
	if (*s == '.') {
		++s ;
		if (*s >= '0' && *s <= '9')
			n += *s++ - '0' ;
		while (*s >= '0' && *s <= '9')
			++s ;
	}
	if (*s == '*')
		++s , n *= l ;
	*ps = s ;
	return (n ? (n + delay / 2) / delay : 0) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	!	...		|
 *													|_______________|
 */

void tputs (cp, afflins, outc) char * cp ; int afflins , (* outc) ( ) ; {
	char * t ;

	if (afflins < 0)
		afflins = -afflins ;

	for ( t = cp ; *t ; (* outc) (*t) , ++t )
		;
}

# endif		/* ABXTCAP */

/*-----------------------------------------------------------------*/

# ifdef		CAPTRC

captrc (txt, buf) char * txt , * buf ; {

	register char * bp ;

	fprintf (trcfp, "** \"%s\" : { ", txt) ;

	for ( bp = buf ; *bp ; ++bp ) {
		if ( *bp >= 33 && *bp <= 126 )
			fprintf (trcfp, "%c ", *bp) ;
		else
			fprintf (trcfp, "%d ", *bp) ;
	}
	fprintf (trcfp, "}\r\n") ;
}

# endif		/* CAPTRC */

/*-----------------------------------------------------------------*/

# ifdef		COMMENT

int terment ( ) {
	char * name ;
	char buf [TBUFSIZ] ;
	char * s ;
	char * getenv ( ) , * malloc ( ) , * termstr ( ) , * tnchktc ( ) ;
	int i, j, k ;

	if (! (name = getenv (ENVTERM)))
		return (-1) ;
	if (! (termbase = malloc (TBUFSIZ)))
		return (-1) ;
	if (tgetent (termbase, name))
		return (-1) ;
	for ( i = 0 ; (j = strlen (termbase)) > i && (name = tnchktc ( )) ;
	      i = j ) {
		if (tgetent (buf, name))
			return (-1) ;
		while (*name != ':')
			--name ;
		for ( s = buf ; *s != ':' ; ++s )
			;
		if (strlen (s) > (k = TBUFSIZ - (name - termbase)))
			s[k] = '\0' ;
		strcpy (name+1, s) ;
	}
	if (j <= i)
		return (-1) ;
	if ((i = termnum (ROWCODE)) != -1)
		afflines = i ;
	if (s = termstr (PADCODE))
		PC = *s, free (s) ;
	BC = termstr (BCCODE) , UP = termstr (UPCODE) ;
	return (0) ;
}

static char * tnchktc ( ) {
	char * s , * t ;

	s = termbase + strlen (termbase) - 2 ;
	while (*--s != ':')
		if (s < termbase)
			return (0) ;
	if (s[1] != 't' || s[2] != 'c')
		return (0) ;
	for ( t = s += 4 ; *t && *t != ':' ; ++t )
		;
	*t = '\0' ;
	return (s) ;
}

# endif		/* COMMENT */

/***********************************************************************/

/*
 * vi:nu tabstop=4
 */
