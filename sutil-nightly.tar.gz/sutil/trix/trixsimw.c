
/*
 *		trix face window simulacrum
 *		cc -D<OS> -o trxsim trxsim.c -lcurses
 */

# if ( ! ( defined (CURSWIOS) || defined (BLESWIOS) ) )
#	error "** must define CURSWIOS or BLESWIOS ."
# endif

# ifdef UBUNTU
#	define	USE_ASM_TIOS
#	define	_USE_CURSES_H_
# endif

# ifdef	CYGWIN
#	define	USE_SYS_TIOS
#	define	_USE_NCURSES_H_
# endif

# ifdef	CURSWIOS
# ifdef	_USE_CURSES_H_
# include	<curses.h>
# endif
# ifdef	_USE_NCURSES_H_
# include	<ncurses/curses.h>
# endif
# define	WINTYP		WINDOW
# define	WIOSMODE	"_CURSWIOS_"
# endif

# ifdef	BLESWIOS
# define	VERNAME			"trxsim"
# define	VERSION			"3.9"
# define	VERCODE			"146"
# define	VERDATE			"2008.09.10"
# define	VERSIGN			"Alexandre Botao"
# define USE_STDIO
# define USE_STDVIF
# define USE_STDWIN
# define USE_STDTYP
# define USE_STDMISC
# define USE_STDKEY
# define USE_STDTERM
# include "abc.h"
# include "stdinfo.h"
# define	WINTYP		WINDES
# define	WIOSMODE	"_BLESWIOS_"
# endif

# include	<signal.h>
# include	<stdlib.h>
# include	<string.h>
# include	<stdio.h>

# ifdef USE_ASM_TIOS
#	include <asm/termios.h>
# endif

# ifdef USE_SYS_TIOS
#	include <sys/termios.h>
# endif

# define	BANNER			"trxsim 3.9 080910 146"
# define	MAXPASS			6 /* 128 */

int			delay = 5 ;
int			pass = 0 ;
int			wsrows = 0 ;
int			wscols = 0 ;

WINTYP *	twp = NULL ;

void trxsimend (int) ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef	CURSWIOS
# define	MOVE(L,C)			move(L,C)
# define	WMOVE(W,L,C)		wmove(W,L,C)
# define	CLEAR()				clear()
# define	WCLEAR(W)			wclear(W)
# define	PAINT()				refresh()
# define	WPAINT(W)			wrefresh(W)
# define	ADDS(S)				addstr(S)
# define	WADDS(W,S)			waddstr(W,S)
# define	MVADDS(L,C,S)		mvaddstr(L,C,S)
# define	MVWADDS(W,L,C,S)	mvwaddstr(W,L,C,S)
# define	WINSET()			initscr()
# define	WINEND()			{endwin();}
# define	WINNEW(H,W,L,C)		newwin(H,W,L,C)
# define	WBOX(W,V,H)			box(W,V,H)
# define	WKILL(W)			delwin(W)
# endif

# ifdef	BLESWIOS
# define	MOVE(L,C)			wgoto(L,C)
# define	WMOVE(W,L,C)		wwgoto(W,L,C)
# define	CLEAR()				wclear()
# define	WCLEAR(W)			wwclear(W)
# define	PAINT()				wflush()
# define	WPAINT(W)			wflush()
# define	ADDS(S)				wputs(S)
# define	WADDS(W,S)			wwputs(W,S)
# define	MVADDS(L,C,S)		wgoto(L,C);wputs(S)
# define	MVWADDS(W,L,C,S)	wwgoto(W,L,C);wwputs(W,S)
# define	WINSET()			(terminit(),winit(),stdwin)
# define	WINEND()			{wend();termend();}
# define	WINNEW(H,W,L,C)		wwopen(L,C,H,W)
# define	WBOX(W,V,H)			wwbox(W,V)
# define	WKILL(W)			wclose(W)
# define	LINES				wsrows /* (wlines()) */
# define	COLS				wscols /* (wcols()) */
# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void getwinsiz () {

	int rd , fd = 1 ;
	struct winsize wsb ;

	rd = ioctl (fd, TIOCGWINSZ, &wsb) ;

	if (rd < 0) {
		perror ("getwsz") ;
		trxsimend (-1) ;
	}

	wsrows = wsb.ws_row ;
	wscols = wsb.ws_col ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void sigwinch (sig) {

	signal (SIGINT, SIG_IGN) ;
	signal (SIGWINCH, sigwinch /*SIG_IGN*/) ;

# ifdef DBG
	WMOVE (trewin, 6, 2) ;
	sprintf (tmpbuf, "sig(%d)", sig) ;
	WADDS (trewin, tmpbuf) ;
	WMOVE (trewin, 7, 2) ;
	sprintf (tmpbuf, "LINES(%d) COLS(%d) wsrows(%d) wscols(%d)", LINES, COLS, wsrows, wscols) ;
	WADDS (trewin, tmpbuf) ;
	WPAINT (trewin) ;
	sleep (delay) ;
# endif

	getwinsiz () ;

# ifdef DBG
	WMOVE (trewin, 8, 2) ;
	sprintf (tmpbuf, "LINES(%d) COLS(%d) wsrows(%d) wscols(%d)", LINES, COLS, wsrows, wscols) ;
	WADDS (trewin, tmpbuf) ;
	WPAINT (trewin) ;
	sleep (delay) ;
# endif

	WINEND () ;
	trxsiminit () ;
	PAINT () ;
}

/*==========================================================================*/
/*																			*/
/*==========================================================================*/

# define	MENUPAIR

char *	t_pathdr = "Path=" ;
char *	t_dirhdr = "Directory=" ;
char *	t_filhdr = "File=" ;

char *	t_files = "Files" ;
char *	t_bytes = "Bytes" ;

char *	t_global = "Global" ;
char *	t_family = "Family=" ;
char *	t_select = "Selected" ;
char *	t_curdir = "Current Directory" ;

char *	t_mode  = "Mode" ;
char *	t_write = "Writ" ;
char *	t_read  = "Read" ;
char *	t_owner = "Owner" ;
char *	t_group = "Group" ;
char *	t_links = "Links" ;

# ifdef MENUPAIR
char *	t_tmenu1a = "Create  Delete  Family" ;
char *	t_tmenu1b = "Global  Load  Order" ;
char *	t_tmenu2a = "Protect  Rename  Select" ;
char *	t_tmenu2b = "TAB=Files  ESC=Quit" ;
char *	t_tmenu3a = "F1=Help  F2=Shell  F3=Swap" ;
char *	t_tmenu3b = "F8=LoadCwd  F10=Menu" ;
# endif /* MENUPAIR */

# ifdef MENUSCAT
char *	t_tmenu1 = "Create Delete Family Global Load Order Protect" ;
char *	t_tmenu2 = "Rename Select TAB=Files ESC=Quit" ;
char *	t_tmenu3 = "F1=Help F2=Shell F3=Swap F8=LoadCwd F10=Menu" ;
# endif /* MENUSCAT */

char *	t_humnum = "ven.^30.xen.yot.zet.exa.pet.ter.gig.meg.kil.htu" ;
char *	t_potnum = "^42.^39.^36.^33.^30.^27.^24.^21.^18.^15.^12._^9._^6._^3._^1" ;
char *	t_dotnum = "123.456.789.123.456.789.123.456.789" ;
char *	t_rawnum = "123456789123456789123456789123456789123456789123456789" ;
char *	t_permsd = "d---rwxr-x---" ;
char *	t_datest = "2006/12/31 17:34:56" ;
char *	t_userid = "username" ;
char *	t_grupid = "groupnam" ;
char *	t_linksd = "12345" ;
char *	t_truler = "12345678901234567890123456789012345678901234567890123456789012345678901234567890" ;

char	tmpbuf [4096] ;

int		l_pathdr , c_pathdr ;
int		l_patnam , c_patnam ;
int		l_dirhdr , c_dirhdr ;
int		l_dirnam , c_dirnam ;
int		l_filhdr , c_filhdr ;
int		l_filnam , c_filnam ;

# ifdef MENUPAIR
int		l_tmenu1 , c_tmenu1a , c_tmenu1b ;
int		l_tmenu2 , c_tmenu2a , c_tmenu2b ;
int		l_tmenu3 , c_tmenu3a , c_tmenu3b ;
# endif /* MENUPAIR */

# ifdef MENUSCAT
int		l_tmenu1 , c_tmenu1 ;
int		l_tmenu2 , c_tmenu2 ;
int		l_tmenu3 , c_tmenu3 ;
# endif /* MENUSCAT */

int		w_sixbox ;
int		numlen ;

int		l_trebox , c_trebox , w_trebox , h_trebox ;
int		l_filbox , c_filbox , w_filbox , h_filbox ;
int		l_totbox , c_totbox , w_totbox , h_totbox ;
int		l_fambox , c_fambox , w_fambox , h_fambox ;
int		l_selbox , c_selbox , w_selbox , h_selbox ;
int		l_curbox , c_curbox , w_curbox , h_curbox ;
int		l_stabox , c_stabox , w_stabox , h_stabox ;
int		l_ownbox , c_ownbox , w_ownbox , h_ownbox ;

WINTYP *	trewin = NULL ;
WINTYP *	filwin = NULL ;
WINTYP *	totwin = NULL ;
WINTYP *	famwin = NULL ;
WINTYP *	selwin = NULL ;
WINTYP *	objwin = NULL ;
WINTYP *	stawin = NULL ;
WINTYP *	ownwin = NULL ;

/*__________________________________________________________________________*/

adaptwin () {

	l_pathdr =  0 ; c_pathdr =  0 ;
	l_dirhdr =  1 ; c_dirhdr =  0 ;
	l_filhdr =  1 ; c_filhdr =  0 ;

# ifdef MENUPAIR
	l_tmenu1 = (LINES - 3) ;	c_tmenu1a =  0 ;	c_tmenu1b = (COLS - strlen(t_tmenu1b)) ;
	l_tmenu2 = (LINES - 2) ;	c_tmenu2a =  0 ;	c_tmenu2b = (COLS - strlen(t_tmenu2b)) ;
	l_tmenu3 = (LINES - 1) ;	c_tmenu3a =  0 ;	c_tmenu3b = (COLS - strlen(t_tmenu3b)) ;
# endif /* MENUPAIR */

# ifdef MENUSCAT
	l_tmenu1 = (LINES - 3) ;	c_tmenu1 =  0 ;
	l_tmenu2 = (LINES - 2) ;	c_tmenu2 =  0 ;
	l_tmenu3 = (LINES - 1) ;	c_tmenu3 =  0 ;
# endif /* MENUSCAT */

	w_sixbox = (COLS / 3) ;
	numlen = w_sixbox - 3 - /* len("files") */ 5 ;

	l_totbox = (LINES - 13) ; c_totbox = 0 ;				w_totbox = w_sixbox ; h_totbox = 5 ;
	l_fambox = (LINES - 13) ; c_fambox = w_sixbox ;			w_fambox = w_sixbox ; h_fambox = 5 ;
	l_selbox = (LINES - 13) ; c_selbox = (2 * w_sixbox) ;	w_selbox = w_sixbox ; h_selbox = 5 ;
	l_curbox = (LINES -  8) ; c_curbox = 0 ;				w_curbox = w_sixbox ; h_curbox = 5 ;
	l_stabox = (LINES -  8) ; c_stabox = w_sixbox ;			w_stabox = w_sixbox ; h_stabox = 5 ;
	l_ownbox = (LINES -  8) ; c_ownbox = (2 * w_sixbox) ;	w_ownbox = w_sixbox ; h_ownbox = 5 ;

	w_filbox = (COLS / 4 /*5*/) ;	h_filbox = (LINES - 15) ; l_filbox = 2 ; c_filbox = (COLS - w_filbox) ;
	w_trebox = (COLS - w_filbox) ;	h_trebox = (LINES - 15) ; l_trebox = 2 ; c_trebox = 0 ;
}

WINTYP * makwin (lin, col, wid, hei) {

	WINTYP * locwin ;

	locwin = WINNEW (hei, wid, lin, col) ;

	if ( locwin == NULL ) {
		fprintf (stderr, "** WINNEW == NULL\r\n") ;
		trxsimend (-99) ;
	}

	WBOX (locwin, 0, 0) ;
	WPAINT (locwin) ;

	return locwin ;
}

chkwin (wp) WINTYP * wp ; {

	if ( wp == NULL )
		return ;

/*
	WCLEAR (wp) ;
	WPAINT (wp) ;
*/
	WKILL (wp) ;
}

/*__________________________________________________________________________*/

curnames () {

	MVWADDS ( twp , l_pathdr , c_pathdr , t_pathdr ) ;
	MVWADDS ( twp , l_dirhdr , c_dirhdr , t_dirhdr ) ;
}

trebox () {

	chkwin (trewin) ;
	trewin = makwin ( l_trebox , c_trebox , w_trebox , h_trebox ) ;
}

filbox () {

	chkwin (filwin) ;
	filwin = makwin ( l_filbox , c_filbox , w_filbox , h_filbox ) ;
}

totbox () {

	chkwin (totwin) ;
	totwin = makwin ( l_totbox , c_totbox , w_totbox , h_totbox ) ;
	MVWADDS (totwin, 1, 1, t_global) ;
	MVWADDS (totwin, 2, w_totbox - 1 - strlen (t_files), t_files) ;
	MVWADDS (totwin, 3, w_totbox - 1 - strlen (t_bytes), t_bytes) ;
	WPAINT (totwin) ;
}

fambox () {

	chkwin (famwin) ;
	famwin = makwin ( l_fambox , c_fambox , w_fambox , h_fambox ) ;
	MVWADDS (famwin, 1, 1, t_family) ;
	MVWADDS (famwin, 2, w_fambox - 1 - strlen (t_files), t_files) ;
	MVWADDS (famwin, 3, w_fambox - 1 - strlen (t_bytes), t_bytes) ;
	WPAINT (famwin) ;
}

selbox () {

	chkwin (selwin) ;
	selwin = makwin ( l_selbox , c_selbox , w_selbox , h_selbox ) ;
	MVWADDS (selwin, 1, 1, t_select) ;
	MVWADDS (selwin, 2, w_selbox - 1 - strlen (t_files), t_files) ;
	MVWADDS (selwin, 3, w_selbox - 1 - strlen (t_bytes), t_bytes) ;
	WPAINT (selwin) ;
}

curbox () {

	chkwin (objwin) ;
	objwin = makwin ( l_curbox , c_curbox , w_curbox , h_curbox ) ;
	MVWADDS (objwin, 1, 1, t_curdir) ;
	MVWADDS (objwin, 2, w_curbox - 1 - strlen (t_files), t_files) ;
	MVWADDS (objwin, 3, w_curbox - 1 - strlen (t_bytes), t_bytes) ;
	WPAINT (objwin) ;
}

stabox () {

	chkwin (stawin) ;
	stawin = makwin ( l_stabox , c_stabox , w_stabox , h_stabox ) ;
	MVWADDS (stawin, 1, 1, t_mode) ;
	MVWADDS (stawin, 2, 1, t_write) ;
	MVWADDS (stawin, 3, 1, t_read) ;
	WPAINT (stawin) ;
}

ownbox () {

	chkwin (ownwin) ;
	ownwin = makwin ( l_ownbox , c_ownbox , w_ownbox , h_ownbox ) ;
	MVWADDS (ownwin, 1, 1, t_owner) ;
	MVWADDS (ownwin, 2, 1, t_group) ;
	MVWADDS (ownwin, 3, 1, t_links) ;
	WPAINT (ownwin) ;
}

# ifdef MENUSCAT
char * menuscat (t) char * t ; {

	int gaplen , gapcnt = 0 ;
	int totspc , nonspc = 0 ;
	char * tp , * bp ;

	for ( tp = t ; *tp ; ++tp ) {
		if ( *tp == ' ' )
			++gapcnt ;
		else
			++nonspc ;
	}

	totspc = (COLS - 1) - nonspc ;
	gaplen = totspc / gapcnt ;

	for ( tp = t , bp = tmpbuf ; *tp ; ++tp ) {
		if ( *tp == ' ' ) {
			memset (bp, ' ', gaplen) ;
			bp += gaplen ;
		} else {
			*bp++ = *tp ;
		}
	}

	*bp = '\0' ;
	return tmpbuf ;
}
# endif /* MENUSCAT */

textmenus () {

# ifdef MENUPAIR
	MVWADDS ( twp , l_tmenu1 , c_tmenu1a , t_tmenu1a ) ;
	MVWADDS ( twp , l_tmenu2 , c_tmenu2a , t_tmenu2a ) ;
	MVWADDS ( twp , l_tmenu3 , c_tmenu3a , t_tmenu3a ) ;
	MVWADDS ( twp , l_tmenu1 , c_tmenu1b , t_tmenu1b ) ;
	MVWADDS ( twp , l_tmenu2 , c_tmenu2b , t_tmenu2b ) ;
	MVWADDS ( twp , l_tmenu3 , c_tmenu3b , t_tmenu3b ) ;
# endif /* MENUPAIR */

# ifdef MENUSCAT
	MVWADDS ( twp , l_tmenu1 , c_tmenu1 , menuscat (t_tmenu1) ) ;
	MVWADDS ( twp , l_tmenu2 , c_tmenu2 , menuscat (t_tmenu2) ) ;
	MVWADDS ( twp , l_tmenu3 , c_tmenu3 , menuscat (t_tmenu3) ) ;
# endif /* MENUSCAT */

}

char * padset ( cnt , fil ) {

	memset ( tmpbuf , fil , cnt ) ;
	tmpbuf[cnt] = '\0' ;
	return tmpbuf ;
}

shownum (wp, np) WINTYP * wp ; char * np ; {

	register char * tp ;
	register char * pp = NULL ;
	register int    ns = strlen (np) ;

	if ( ns > numlen ) {
		tp = np + ( ns - numlen ) ;
	} else {
		tp = np ;
		if ( ns < numlen ) {
			pp = padset ( numlen - ns , '.' ) ;
		}
	}

	WMOVE (wp, 2, 1) ;

	if ( pp != NULL ) {
		WADDS (wp, pp) ;
	}

	WADDS (wp, tp) ;

	WMOVE (wp, 3, 1) ;

	if ( pp != NULL ) {
		WADDS (wp, pp) ;
	}

	WADDS (wp, tp) ;

	WPAINT (wp) ;
}

showvalues () {

	shownum (totwin, t_dotnum) ;
	shownum (famwin, t_rawnum) ;
	shownum (selwin, t_humnum) ;
	shownum (objwin, t_potnum) ;

	MVWADDS (stawin, 1, w_sixbox - strlen (t_permsd) - 1, t_permsd) ;
	MVWADDS (stawin, 2, w_sixbox - strlen (t_datest) - 1, t_datest) ;
	MVWADDS (stawin, 3, w_sixbox - strlen (t_datest) - 1, t_datest) ;
	WPAINT (stawin) ;

	MVWADDS (ownwin, 1, w_sixbox - strlen (t_userid) - 1, t_userid) ;
	MVWADDS (ownwin, 2, w_sixbox - strlen (t_grupid) - 1, t_grupid) ;
	MVWADDS (ownwin, 3, w_sixbox - strlen (t_linksd) - 1, t_linksd) ;
	WPAINT (ownwin) ;
}

/*__________________________________________________________________________*/

initface () {

}

dirface () {

	adaptwin () ;

	CLEAR () ;
	PAINT () ;

	curnames () ;
	trebox () ; filbox () ;
	totbox () ; fambox () ; selbox () ;
	curbox () ; stabox () ; ownbox () ;
	textmenus () ;
	showvalues () ;

	PAINT () ;
	sleep (delay) ;
}

fileface () {

	WMOVE (trewin, 2, 2) ;
	WADDS (trewin, BANNER) ;
	WADDS (trewin, WIOSMODE) ;
	WMOVE (trewin, 4, 2) ;
	sprintf (tmpbuf, "pass(%d) LINES(%d) COLS(%d) wsrows(%d) wscols(%d)", pass, LINES, COLS, wsrows, wscols) ;
	WADDS (trewin, tmpbuf) ;
	WPAINT (trewin) ;
	sleep (delay) ;
}

/*==========================================================================*/
/*																			*/
/*==========================================================================*/

trxsiminit () {

	getwinsiz () ;

	twp = WINSET () ;

	if (twp == NULL) {
		fprintf (stderr, "trxsim: WINSET == NULL\r\n") ;
		return ;
	}

	signal (SIGINT, trxsimend) ;
	/* signal (SIGSEGV, trxsimend) ; */
	signal (SIGWINCH, sigwinch) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

trxsimbody () {

	initface () ;

	dirface () ;

	fileface () ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void trxsimend (sig) {

	signal (SIGINT, SIG_IGN) ;
	/* signal (SIGSEGV, SIG_IGN) ; */
	fprintf (stderr, "LINES(%d) COLS(%d) wsrows(%d) wscols(%d)\r\n", LINES, COLS, wsrows, wscols) ;
	fprintf (stderr, "sig(%d) ", sig) ;
	WINEND () ;
	exit (0) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

trxsim () {

	trxsiminit () ;

	for ( pass = 1 ; pass < MAXPASS ; ++pass )
		trxsimbody () ;

	trxsimend (0) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

main (argc, argv) char * * argv ; {

	puts (BANNER) ;

	trxsim () ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

/*
 * vi:nu tabstop=4
 */
