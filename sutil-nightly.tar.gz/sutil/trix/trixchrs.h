
/************************************************************************
*	frames, borders, alternate char sets ...							*
************************************************************************/

# define	UPRLEFT		xfram[ 0]
# define	UPRIGHT		xfram[ 1]
# define	LWRLEFT		xfram[ 2]
# define	LWRIGHT		xfram[ 3]
# define	UPRTEE		xfram[ 4]
# define	LWRTEE		xfram[ 5]
# define	LEFTEE		xfram[ 6]
# define	RIGHTEE		xfram[ 7]
# define    PLUSTEE		xfram[ 8]
# define    VERTBAR		xfram[ 9]
# define	HORZBAR		xfram[10]

# ifdef		DOS /* ANSI */

# define	C_DUL		   201			/* double upper left			*/
# define	C_DUR		   187			/* double upper right			*/
# define	C_DLL		   200			/* double lower left			*/
# define	C_DLR		   188			/* double lower right			*/
# define	C_DUT		   203			/* double up "T"				*/
# define	C_DDT		   202			/* double down "T"				*/
# define	C_DLT		   204			/* double left "T"				*/
# define	C_DRT		   185			/* double right "T"				*/
# define	C_DXT		   206			/* double cross "T"				*/
# define	C_DVL		   186			/* double vertical line			*/
# define	C_DHL		   205			/* double horizontal line		*/

# define	C_SUL		   218			/* single upper left			*/
# define	C_SUR		   191			/* single upper right			*/
# define	C_SLL		   192			/* single lower left			*/
# define	C_SLR		   217			/* single lower right			*/
# define	C_SUT		   194			/* single up "T"				*/
# define	C_SDT		   193			/* single down "T"				*/
# define	C_SLT		   195			/* single left "T"				*/
# define	C_SRT		   180			/* single right "T"				*/
# define	C_SXT		   197			/* single cross "T"				*/
# define	C_SVL		   179			/* single vertical line			*/
# define	C_SHL		   196			/* single horizontal line		*/

# define	C_HUL		   213			/* dbl.horz. upper left			*/
# define	C_HUR		   184			/* dbl.horz. upper right		*/
# define	C_HLL		   212			/* dbl.horz. lower left			*/
# define	C_HLR		   190			/* dbl.horz. lower right		*/
# define	C_HUT		   209			/* dbl.horz. up "T"				*/
# define	C_HDT		   207			/* dbl.horz. down "T"			*/
# define	C_HLT		   198			/* dbl.horz. left "T"			*/
# define	C_HRT		   181			/* dbl.horz. right "T"			*/
# define	C_HXT		   216			/* dbl.horz. cross "T"			*/
# define	C_HVL		   179			/* dbl.horz. vertical line		*/
# define	C_HHL		   205			/* dbl.horz. horizontal line	*/

# define	C_VUL		   214			/* dbl.vert. upper left			*/
# define	C_VUR		   183			/* dbl.vert. upper right		*/
# define	C_VLL		   211			/* dbl.vert. lower left			*/
# define	C_VLR		   189			/* dbl.vert. lower right		*/
# define	C_VUT		   210			/* dbl.vert. up "T"				*/
# define	C_VDT		   208			/* dbl.vert. down "T"			*/
# define	C_VLT		   199			/* dbl.vert. left "T"			*/
# define	C_VRT		   182			/* dbl.vert. right "T"			*/
# define	C_VXT		   215			/* dbl.vert. cross "T"			*/
# define	C_VVL		   186			/* dbl.vert. vertical line		*/
# define	C_VHL		   196			/* dbl.vert. horizontal line	*/

# define	C_GSPC		   ' '			/* graphic white space			*/
# define	C_ABOX		   223			/* "above" box (or whole box)	*/

# define	C_G25P		   176			/* ...                          */
# define	C_G50P		   177			/* ...                          */
# define	C_G75P		   178			/* ...                          */
# define	C_G99P		   219			/* ...                          */

# define	C_SHBX		   220			/* ...                          */
# define	C_WHBX		   221			/* ...                          */
# define	C_EHBX		   222			/* ...                          */
# define	C_NHBX		   223			/* ...                          */

# define	C_CHECK		   251			/* ...                          */

# else		/* ANYX, ALTCHARSET */

# define	C_DUL		altgcs[  0]		/* double upper left			*/
# define	C_DUR		altgcs[  1]		/* double upper right			*/
# define	C_DLL		altgcs[  2]		/* double lower left			*/
# define	C_DLR		altgcs[  3]		/* double lower right			*/
# define	C_DUT		altgcs[  4]		/* double up "T"				*/
# define	C_DDT		altgcs[  5]		/* double down "T"				*/
# define	C_DLT		altgcs[  6]		/* double left "T"				*/
# define	C_DRT		altgcs[  7]		/* double right "T"				*/
# define	C_DXT		altgcs[  8]		/* double cross "T"				*/
# define	C_DVL		altgcs[  9]		/* double vertical line			*/
# define	C_DHL		altgcs[ 10]		/* double horizontal line		*/
# define	C_DXX		altgcs[ 11]		/* extra reserved ...			*/

# define	C_SUL		altgcs[ 12]		/* single upper left			*/
# define	C_SUR		altgcs[ 13]		/* single upper right			*/
# define	C_SLL		altgcs[ 14]		/* single lower left			*/
# define	C_SLR		altgcs[ 15]		/* single lower right			*/
# define	C_SUT		altgcs[ 16]		/* single up "T"				*/
# define	C_SDT		altgcs[ 17]		/* single down "T"				*/
# define	C_SLT		altgcs[ 18]		/* single left "T"				*/
# define	C_SRT		altgcs[ 19]		/* single right "T"				*/
# define	C_SXT		altgcs[ 20]		/* single cross "T"				*/
# define	C_SVL		altgcs[ 21]		/* single vertical line			*/
# define	C_SHL		altgcs[ 22]		/* single horizontal line		*/
# define	C_SXX		altgcs[ 23]		/* extra reserved ...			*/

# define	C_ABOX		altgcs[ 24]		/* "above small box"			*/
# define	C_GSPC		altgcs[ 25]		/* "graphic white space"		*/

# define	C_G25P		altgcs[ 26]		/* ...							*/
# define	C_G50P		altgcs[ 27]		/* ...							*/
# define	C_G75P		altgcs[ 28]		/* ...							*/
# define	C_G99P		altgcs[ 29]		/* ...							*/

# define	C_SHBX		altgcs[ 30]		/* ...							*/
# define	C_WHBX		altgcs[ 31]		/* ...							*/
# define	C_EHBX		altgcs[ 32]		/* ...							*/
# define	C_NHBX		altgcs[ 33]		/* ...							*/

# define	C_HUL		altgcs[ 34]   	/* dbl.horz. upper left			*/
# define	C_HUR		altgcs[ 35]   	/* dbl.horz. upper right		*/
# define	C_HLL		altgcs[ 36]   	/* dbl.horz. lower left			*/
# define	C_HLR		altgcs[ 37]   	/* dbl.horz. lower right		*/
# define	C_HUT		altgcs[ 38]   	/* dbl.horz. up "T"				*/
# define	C_HDT		altgcs[ 39]   	/* dbl.horz. down "T"			*/
# define	C_HLT		altgcs[ 40]   	/* dbl.horz. left "T"			*/
# define	C_HRT		altgcs[ 41]   	/* dbl.horz. right "T"			*/
# define	C_HXT		altgcs[ 42]   	/* dbl.horz. cross "T"			*/
# define	C_HVL		altgcs[ 43]   	/* dbl.horz. vertical line		*/
# define	C_HHL		altgcs[ 44]   	/* dbl.horz. horizontal line	*/

# define	C_VUL		altgcs[ 45]   	/* dbl.vert. upper left			*/
# define	C_VUR		altgcs[ 46]   	/* dbl.vert. upper right		*/
# define	C_VLL		altgcs[ 47]   	/* dbl.vert. lower left			*/
# define	C_VLR		altgcs[ 48]   	/* dbl.vert. lower right		*/
# define	C_VUT		altgcs[ 49]   	/* dbl.vert. up "T"				*/
# define	C_VDT		altgcs[ 50]   	/* dbl.vert. down "T"			*/
# define	C_VLT		altgcs[ 51]   	/* dbl.vert. left "T"			*/
# define	C_VRT		altgcs[ 52]   	/* dbl.vert. right "T"			*/
# define	C_VXT		altgcs[ 53]   	/* dbl.vert. cross "T"			*/
# define	C_VVL		altgcs[ 54]   	/* dbl.vert. vertical line		*/
# define	C_VHL		altgcs[ 55]   	/* dbl.vert. horizontal line	*/

# define	C_CHECK		altgcs[ 56]		/* ...                          */

# ifdef		COMMENT

# define	TERMID		"79138246+|-@79138246+|-@o "

# define	ED3636		"bSaTdceQ?Rf@79138246+|-@o "

# endif		/* COMMENT */

# endif		/* DOS */

# ifdef	 COMMENT

	180 4   181 5   182 6   183 7   184 8   185 9   186 :   187 ;

	188 <   189 =   190 >   191 ?   192 @   193 A   194 B   195 C

	196 D   197 E   198 F   199 G   200 H   201 I   202 J   203 K

	204 L   205 M   206 N   207 O   208 P   209 Q   210 R   211 S

	212 T   213 U   214 V   215 W   216 X   217 Y   218 Z

# endif   /* COMMENT */

/*
 * vi:tabstop=4
 */
