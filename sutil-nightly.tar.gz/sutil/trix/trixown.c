/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixown.c + ownership (UID, GID) management         |
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# ifdef ANYX

# include	<stdio.h>

# include   <pwd.h>
# include   <grp.h>

# include	<stdlib.h>

# include	"trix.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixaloc.h"
# include	"trixfunc.h"

# endif /* ANYX */

/*  |---------------------------------------------------------------|
 *  |   + ownership inits ...                                       |
 *  |   + the reading of all passwd & group files for optimal       |
 *  |     performance should be optional (memory fugit !) ...       |
 *  |---------------------------------------------------------------|
 */

# ifdef ANYX

EXT int totown , totgrp ;
EXT OWNDAT * ownlist ;
EXT GRPDAT * grplist ;

void initown () {

    REG struct passwd * pwp ;
    REG struct group  * grp ;
    REG OWNDAT *        odp = NULL ;
    REG GRPDAT *        gdp ;
    REG char *          xp ;
    REG int             ns ;

# ifdef XTRC
	fprintf (trcfp, "initown()\r\n") ;
# endif

    /*
     *  + build owner-id array ...
     */
    totown = 0 ;
    setpwent () ;
    while ( ( pwp = getpwent () ) != 0 ) {
		if ((odp = ownlist) != VZRO (OWNDAT *)) {
			ns = (totown + 1) * sizeof (OWNDAT) ;
			odp = (OWNDAT *) REALLOC ( (char *) odp, ns) ;
			if (odp == (OWNDAT *) 0) {
reown : 		trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;
			}
		} else {
			if (FALLOP (odp, OWNDAT)) {
nmown :         trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
			}
		}
        if ((xp = (char *) malloc (strlen (pwp->pw_name) + 1)) == NOSTR)
            goto nmown ;
        ownlist = odp ;
        odp += totown ;
        odp->od_uid = pwp->pw_uid ;
        strcpy (xp, pwp->pw_name) ;
        odp->od_nam = xp ;
        ++totown ;
    }
    endpwent () ;
    /*
     *  + build group-id array ...
     */
    totgrp = 0 ;
    setgrent () ;
    while ( ( grp = getgrent () ) != 0 ) {
		if ((gdp = grplist) != VZRO (GRPDAT *)) {
			ns = (totgrp + 1) * sizeof (GRPDAT) ;
			gdp = (GRPDAT *) REALLOC ( (char *) gdp, ns) ;
			if (gdp == (GRPDAT *) 0)
                goto reown ;
		} else {
			if (FALLOP (gdp, GRPDAT))
                goto nmown ;
		}
        if ((xp = malloc (strlen (grp->gr_name) + 1)) == NOSTR)
            goto nmown ;
        grplist = gdp ;
        gdp += totgrp ;
        gdp->gd_gid = grp->gr_gid ;
        strcpy (xp, grp->gr_name) ;
        gdp->gd_nam = xp ;
        ++totgrp ;
    }
    endgrent () ;
    /*
     *  + sort arrays 4 optimal search speed ...
     */
    qsort ((char *)ownlist, totown, sizeof (OWNDAT), owncmp) ;
    qsort ((char *)grplist, totgrp, sizeof (GRPDAT), grpcmp) ;
}

# endif /* ANYX */

/*= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */
/*
 * vi:tabstop=4
 */
