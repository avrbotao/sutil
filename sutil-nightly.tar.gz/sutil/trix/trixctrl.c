/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	trixctrl + version & serial # , release , piracy, ...	|
 *		|___________________________________________________________|
 */

# include	<time.h>
# include	<ctype.h>
# include	<stdio.h>
# include	<string.h>

# include	"trix.h"
# include	"trixstd.h"
# include	"trixfunc.h"
# include	"trixtext.h"

# ifdef		COMMENT
# include	"trixblue.h"
# include	"trixext.h"
# endif		/* COMMENT */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# define	PRODFOPEN		trixfopen

# include	"trixprod.c"

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	inspect PRODESCR seal ...	|
 *									|_______________________________|
 */

# define	SEALNAME	"trixseal.dat"

char *		xctlsrno = NOSTR ;	/* [20] */
char *		xctlname = NOSTR ;	/* [80] */

PRODESCR	xpdb ;

void initseal () {

	int rd ;
	char tb [20] ;

	rd = initprod (SEALNAME, &xpdb) ;

	if (rd < 0) {
		sprintf (tb, "%d", rd) ;
		trixerr (T_PRODERR, tb, NOWHY, FATAL) ;
		epilog () ;
	}

	xctlsrno = (char *) xpdb.pd_swsrno ;
	xctlname = (char *) xpdb.pd_bignam ;

}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/********************************************************************
*																	*
*	xkryb + crypt bits ...											*
*																	*
*	+ mangle beyond recognition to unauthorized peeping persons ...	*
*	  (scramble in a way dreamed only by those of the inner			*
*	  sanctum. the stuff of spies.)									*
*																	*
********************************************************************/

# ifdef		COMMENT

int xkryb (buf) char * buf ; {

}

# endif		/* COMMENT */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*
 * vi:tabstop=4
 */
