/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	inspect prodescr info ...	|
 *									|_______________________________|
 */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# include	<stdio.h>
# include	<time.h>
# include	<stdlib.h>
# include	<string.h>
# include	<ctype.h>

# ifdef ANSI
# define	OF(X)		X
# else  /* OLD */
# define	OF(X)		()
# endif /* ANSI */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# include	"prodprod.c"

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

void	putfld		OF ( ( int , BYTE * , char * ) ) ;

char * sealname = "prodseal.dat" ;

void main (argc, argv) char * * argv ; {
	int i ;

	printf ("\nProdTest 1.6 (C) Alexandre Botao @ 01/10/92\n\n") ;

	if (argc > 1)
		sealname = *(argv+1) ;

	initseal () ;

	printf ("\n") ;

	srand ((int)time((long*)0));

	for ( i = 0 ; i < 64 ; ++i ) {
		printf ("%4d ",rand()%256);
	}

	printf ("\n") ;
}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

void initseal () {
	PRODESCR xb ;
	int rd ;

	rd = initprod (sealname, &xb) ;

	if (rd < 0) {
		printf ("erro %d ao inspecionar o arquivo de personalizacao !\n", rd) ;
		exit (-1) ;
	}

	putfld (20, xb.pd_prodid, "produto & versao") ;
	putfld (12, xb.pd_swsrno, "numero de serie do produto") ;
	putfld (12, xb.pd_acqdat, "data de fabricacao") ;
	putfld (12, xb.pd_expdat, "data de expiracao") ;
	putfld (70, xb.pd_bignam, "nome completo do cliente") ;
	putfld (20, xb.pd_niknam, "nome abreviado ...") ;
	putfld (30, xb.pd_hwname, "fabricante e modelo") ;
	putfld (12, xb.pd_hwsrno, "numero de serie do h/w") ;
	putfld (12, xb.pd_mputyp, "tipo da mpu") ;
	putfld (30, xb.pd_hopsys, "sistema operacional e versao") ;
	putfld (12, xb.pd_hosrno, "numero de serie do s/o") ;
	putfld (20, xb.pd_siteid, "sitename ou nodename") ;
	putfld (16, xb.pd_xflags, "flags de controle") ;
	putfld (70, xb.pd_adinfo, "informacoes adicionais") ;
}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

void putfld (siz, buf, msg) BYTE * buf ; char * msg ; {

	if (siz <= 0)
		return ;

	printf ("%-30s%s\n", msg, buf) ;
}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
