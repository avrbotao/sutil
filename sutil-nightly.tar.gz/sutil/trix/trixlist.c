# ifdef COMMENT
/************************************************************************
*	pr + print 'em , good ol' unix style ...							*
*																		*
*	those unix flags must be checked for sure,							*
*	and as i don't remember 'em all,									*
*	these here are provisory ...										*
************************************************************************/

# include	<stdio.h>

# include	<io.h>
# include	<dir.h>
# include	<dos.h>

# include	"trix_abc.h"

/************************************************************************
*	data prototypes ...													*
************************************************************************/

struct	epoch	{
	int year ;
	int mon ;
	int day ;
	int hour ;
	int min ;
/*	int sec ;	*/
} ;

TYP		UNS int			UINT ;
TYP		struct ffblk	FFBLK ;
TYP		struct date		SYSDATE ;
TYP		struct time		SYSTIME ;
TYP		struct ftime	FILEPOCH ;
TYP		struct epoch	EPOCH ;

/************************************************************************
*	local definitions ...												*
************************************************************************/

# define	FA_MASK		( FA_ARCH | FA_RDONLY | FA_SYSTEM | FA_HIDDEN )

# define	MININTPC	-32768
# define	LINSIZ		   140

# define	HDRFMT		"\n%02d/%02d/%02d %02d:%02d %s Page %d\n\n"
# define	PIPHDR		"<|>"

/************************************************************************
*	local macros  ...													*
************************************************************************/

# define	DAY			epochdr.day
# define	MON			epochdr.mon
# define	YEAR		epochdr.year
# define	HOUR		epochdr.hour
# define	MIN			epochdr.min

/************************************************************************
*	procedure prototypes ...											*
************************************************************************/

void	pr (char *, FFBLK *) ;
void	tabexp (char *, char *) ;

/************************************************************************
*	globals ... 														*
************************************************************************/

char *	swid = "pr" ;						/* pr + fancy print ...		*/
char *	hdrnam = VZRO (char *) ;

BOOL	hashdr = TRUE ;						/* epoch, name, pag #		*/
BOOL	ffskip = FALSE ;					/* adv pag by ff & ~ lin #	*/

int		pagsiz = 66 ;						/* mostly often ...			*/
int		tabsiz = 0 ;						/* also ...					*/

void	( * whop ) ( char * , FFBLK * ) ;	/* 2 whom it may concern	*/

/************************************************************************
*	entry + [ flags & parameters ] processing ... 						*
************************************************************************/

void main (argc, argv) char * * argv ; {
	REG int tx ;

/* prologue processing */

	whop = pr ;

/* command line scanning & parsing */

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch ( *((*argv)+1) ) {

					case '-' : pr ( NOSTR, VZRO (FFBLK *) ) ; break ;

					case 'h' : hdrnam = *++argv ; break ;

					case 't' : hashdr = FALSE ; break ;

					case 'f' : ffskip = TRUE ; break ;

					case 'l' :
						tx = atoi (*++argv) ;
						if (tx > 9 && tx < 512)
							pagsiz = tx ;
					break ;

					case 'e' :
						tx = atoi (*++argv) ;
						if (tx > 1 && tx < 40)
							tabsiz = tx ;
					break ;

					case '?' :
					default : usag () ; return ;
				}
			} else {
				blowild (*argv) ;
			}
		}
/* intrinsic processing */

	} else {
		pr ( NOSTR, VZRO (FFBLK *) ) ;
	}
/* epilogue processing */

}

/************************************************************************
*	wildcards (dos-style regular expressions) explosion & processing	*
************************************************************************/

void blowild (nam) char * nam ; {
	struct ffblk ffbuf ;
	char fnbuf [ 80 ] ;
	char * fnptr = ffbuf.ff_name ;
	int slasti ;									/* last slash inx	*/
	extern void (*whop) (char *, FFBLK *) ;

	if (findfirst (nam, &ffbuf, FA_MASK) < 0) {
		printf ("\n%s: can't access %s\n", swid, nam) ;
		return ;
	}

	if ((slasti = lastoc (nam, DIRSEP)) >= 0)
		strcpy (fnptr = fnbuf, nam) ;

	do {
		if (fnptr == fnbuf)
			strcpy (fnptr + slasti + 1, ffbuf.ff_name) ;

		( * whop ) ( fnptr , & ffbuf ) ;

	} while (findnext (&ffbuf) >= 0) ;
}

/************************************************************************
* lastoc: last occurrance of a character within a string				*
************************************************************************/

int lastoc (s, c) char * s ; char c ; {
	register char * p = s ;
	register int i = -1 ;

	while (*p) {
		if (*p == c)
			i = p - s ;
		++p ;
	}
	return (i) ;
}

/************************************************************************
*	guess what ...														*
************************************************************************/

void pr (nam, ffbuf) char * nam ; FFBLK * ffbuf ; {
	REG int		lik ;
	REG int		pgk = 1 ;
	REG int		lpp = pagsiz - 4 ;		/* 2 lins / hdr , 2 / margins	*/
	FILE *		fp = stdin ;
	SYSDATE		sysdate ;
	SYSTIME		systime ;
	EPOCH		epochdr ;
	char		outbuf [ LINSIZ ] ;
	char		linbuf [ LINSIZ ] ;
	char *		outptr = linbuf ;

	if (nam) {
		if ((fp = fopen (nam, "r")) == NOFILE) {
			printf ("\n%s: can't access %s\n", swid, nam) ;
			return ;
		}
		if (hdrnam == VZRO (char *))
			hdrnam = nam ;
		YEAR = ( ( ffbuf->ff_fdate >> 9 ) & 0x7f ) + 80 ;
		MON = ( ffbuf->ff_fdate >> 5 ) & 0x0f ;
		DAY = ( ffbuf->ff_fdate ) & 0x1f ;
		HOUR = ( ffbuf->ff_ftime >> 11 ) & 0x1f ;
		MIN = ( ffbuf->ff_ftime >> 5 ) & 0x3f ;
		/*	sec = ffbuf->ff_tsec << 1 ;	*/
	} else {
		if (hdrnam == VZRO (char *))
			hdrnam = PIPHDR ;
		gettime (&systime) ;
		HOUR = systime.ti_hour ;
		MIN = systime.ti_min ;
		/*	sec = systime.ti_sec ;	*/
		getdate (&sysdate) ;
		YEAR = sysdate.da_year ;
		MON = sysdate.da_mon ;
		DAY = sysdate.da_day ;
	}

	lik = 1024 ;

	for (EVER) {

		if ( fgets (linbuf, LINSIZ, fp) == VZRO (char *) )
			break ;

		if (lik > lpp) {
			if (pgk > 1) {
				if (ffskip)
					fputc ('\f', stdout) ;
				else
					fputc ('\n', stdout) ;
			}
			printf (HDRFMT, DAY, MON, YEAR, HOUR, MIN, hdrnam, pgk) ;
			lik = 1 ;
			++pgk ;
		}

		if (tabsiz)
			tabexp (outptr = outbuf, linbuf) ;
		fputs (outptr, stdout) ;
		++lik ;
	}

	if (ffskip)
		fputc ('\f', stdout) ;
	else
		while ( lik++ <= (lpp+1) )
			fputc ('\n', stdout) ;

	fclose (fp) ;
}

/************************************************************************
*	syntax help ...														*
************************************************************************/

void usag () {

	fprintf (stderr,
		"\nuse: %s [-tf] [--] [-h $] [-l #] [-e #] [file ...]\n", swid) ;
}
/*------------------------------------------------------------------*/
# endif /* COMMENT */
/*
 * vi:tabstop=4
 */
