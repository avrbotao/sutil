
/********************************************************************
*	+ trix.h ...													*
*-------------------------------------------------------------------*
*	+ defines		:	trixdefs.h									*
*	+ macros		:	trixmacs.h									*
*	+ structs		:	trixdata.h									*
********************************************************************/

# include <trixvers.h>

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	AUTHENTIC

# ifdef		AUTHENTIC
# define	SWID		"TRX"
# define	SWENVAR		"TRXPATH"
# endif

# ifdef		ORIGAUTH
# define	SWID		"TRIX"
# define	SWENVAR		SWID
# endif

# ifdef		MARKETWARE
# define	SWID		"NORTIX TREE"
# define	SWENVAR		"TRIX"
# endif

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# define	XSAF					/* some boobie traps 4'em ...	*/
# define	CINL					/* some C inline 2 fly ...		*/
# define	NIC						/* such a Nice C ...			*/
# define	BIGTRX					/* big screens, names & sizes	*/

# define	TREEDRAWW

/*
# define	XTRC
*/

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		DOS

/* # pragma	inline	*/				/* some asm 2 fly ...			*/
/* # define	VDEO	*/				/* VideoDisplay Enhanced Output	*/
/* # define	LOFMEM	*/				/* lots of memory 2 play ...	*/

# define	TCWINDOWS				/* i bet VDEO performs better	*/

# endif		/* DOS */

/*_______________________________________________________________________
 *	+ ...
 */

# ifdef		ANYX

# include	<string.h>
# include	<stdlib.h>
# include	<unistd.h>

/* # define		CURSES */

# ifdef		CURSES

#   ifdef TREEDRAWW
#       error "CURSES and TREEDRAWW are mutually exclusive"
#   endif

# include	<curses.h>
/* # include	<term.h> */

# else 		/* ! CURSES */

# define	TRIXKEY

# endif		/* CURSES */

# endif		/* ANYX */

/************************************************************************
*	+ includes ...														*
************************************************************************/

# include	"trix_abc.h"
# include	"trixglob.h"

/************************************************************************
*	local definitions 4 dos ...											*
************************************************************************/

# ifdef	 DOS

# define	OPSYS		"DOS"
# define	TFD			     1
# define	NAMSIZ	        12
# define	FA_TYPE		( FA_ARCH	 | FA_DIREC )	/* | FA_LABEL ?	*/
# define	FA_STATUS	( FA_RDONLY | FA_SYSTEM | FA_HIDDEN )
# define	FA_BOTH		( FA_TYPE	 | FA_STATUS )
# define	FA_MASK		(FA_ARCH | FA_STATUS)
# define	DA_MASK		(FA_DIREC | FA_STATUS)
# define	STADIR		DA_MASK
# define	STASIZ		ff_fsize
# define	STADAT		ff_fdate
# define	STATIM		ff_ftime
# define	STAPROT		ff_attrib
# define	ALLFIL		"*"         /* actually better than "*.*" ...	*/
# define	SYSHELL		"command"

# endif		/* DOS */

/************************************************************************
*	local definitions 4 unix, xenix, 386ix, aix, hp-ux, hitachi-ux,		*
*	edix, sidix, digix, six, e-ix, ...									*
************************************************************************/

# ifdef		UNIX
# define	OPSYS		"UNIX"
# endif		/* UNIX */

# ifdef		SUNX
# define	OPSYS		"SOLARIS"
# define	SIGHANTYP	void
# endif		/* SOLARIS */

# ifdef		SOLARIS
# define	OPSYS		"SOLARIS"
# define	SIGHANTYP	void
# endif		/* SOLARIS */

# ifdef		LINUX
# define	OPSYS		"LINUX"
# define	SIGHANTYP	void
# endif		/* LINUX */

# ifdef		OPENBSD
# define	OPSYS		"OPENBSD"
# define	SIGHANTYP	void
# endif		/* OPENBSD */

# ifdef		FREEBSD
# define	OPSYS		"FREEBSD"
# define	SIGHANTYP	void
# endif		/* FREEBSD */

# ifdef		CYGWIN
# define	OPSYS		"CYGWIN"
# define	SIGHANTYP	void
# endif		/* CYGWIN */

# ifdef		AIX
# define	OPSYS		"AIX"
# define	SIGHANTYP	void
# endif		/* AIX */

# ifdef		HPUX
# define	OPSYS		"HP-UX"
# define	SIGHANTYP	void
# endif		/* HPUX */

# ifdef		XENIX
# define	OPSYS		"XENIX"
# endif		/* XENIX */

# ifdef		EDIX
# define	OPSYS		"EDIX"
typedef		off_t		size_t ;
# define	void		int
# define	F_OK		0
# define	R_OK		0
# define	W_OK		1
# define	X_OK		0x01
# define	SEEK_SET	0
# define	SEEK_CUR	1
# define	SEEK_END	2
# endif		/* EDIX */

# ifdef		SIDIX
# define	OPSYS		"SIDIX"
# define	void		int
# endif		/* SIDIX */

# ifdef		SIX
# define	OPSYS		"SIX"
# endif		/* SIDIX */

# ifdef		DIGIX
# define	OPSYS		"DIGIX"
# endif		/* DIGIX */

# ifdef		ANYX

# define	RAWIO						/* chk who uses & discard ...	*/
# define	NAMSIZ		    14			/* or 16 ? ...					*/
# define	TFD			tfd
# define	STADIR		S_IFDIR
# define	STASIZ		st_size
# define    STAPROT     st_mode
# define	STATIM		st_mtime
# define	STALAR		st_atime
# define	STALNK		st_nlink
# define	STAUID		st_uid
# define	STAGID		st_gid
# define	ALLFIL		"*"
# define	SYSHELL		"sh"

# ifdef		SYSVDIR

TYP		struct dirent	DIRENT ;

# endif		/* SYSVDIR */

# endif		/* ANYX */

# include "absd.h"

/************************************************************************
*	system-independent local definitions ...							*
************************************************************************/

# ifdef BIGTRX
# define	XLTOA(A,B,C)		xlltoa(A,B,C)
typedef		_INT64_				TRXSIZ ;
# else
# define	XLTOA(A,B,C)		xltoa(A,B,C)
typedef		long				TRXSIZ ;
# endif

# define	NODID		( VZRO (DIRDAT *) )
# define	NOFID		( VZRO (FILDAT *) )

# define	MAXSLONG	2147483647		/* max signed long (2^31-1) ...	*/
# define	MAXULONG	4294967295		/* max unsigned long (2^32-1)	*/

# define	GTPSIZ			 4			/* graphic header buffer size	*/
# define	GTPLEN			 3			/* graphic header string length	*/
/* # define	NAMALOC			16 */

# ifdef		MAXPATHLEN
#	undef		MAXPATHLEN
# endif		/* MAXPATHLEN */

# define	MAXPATHLEN	   140

# define	MAXPNL		   512			/* max files' pathname length	*/
# define	TEBSIZ		   512
# define	MASKEY		   256

# define	TWCURS		( dp->dd_depth * GTPLEN + _twcofs )

# define	FWVIEW		0x0001
# define	FWPLAY		0x0002
# define	FWPAN		0x0004			/* panoramic ...				*/
# define	FWGLOB		0x0008			/* global (universal)			*/
# define	FWAVUE		0x0010			/* auto-vue mode ...			*/

# define	PANFIL		0x0001
# define	PANMFL		0x0002

# define	NAMONLY			 0

# define	TAGFLG		0x0001			/* file is tagged (selected)	*/
# define	CONFLG		0x0002			/* confirm (y/n) operations ...	*/

# define	DIROOT		0x0001			/* rootish (slashy) directory	*/
# define	LOCKEDIR	0x0002			/* found protected during log	*/
# define	UNREADIR	0x0004			/* not logged due to -e flg ...	*/

# define	TOTDIRS		gpan->dd_dik
# define	TOTFILS		gpan->dd_fik
# define	TOTBYTS		gpan->dd_fib
# define	MATFILS		gpan->dd_mfk
# define	MATBYTS		gpan->dd_mfb
# define	SELFILS		gpan->dd_tfk
# define	SELBYTS		gpan->dd_tfb

# define	REFRAME		0x00000001L
# define	FIXHDRS		0x00000002L
# define	DYNHDRS		0x00000004L
# define	UPATHDR		0x00000008L
# define	CMNUBAR		0x00000010L
# define	FMNUBAR		0x00000020L
# define	FRESBAN		0x00000040L
# define	UDFILS		0x00000080L
# define	UDMATS		0x00000100L
# define	UDSELS		0x00000200L
# define	UDCURF		0x00000400L
# define	UDCURD		0x00000800L
# define	UDPATH		0x00001000L
# define	UDRGXP		0x00002000L
# define	CLRMNUS		0x00010000L
# define	UDTREE		0x00020000L
# define    UDSTATUS    0x00040000L
# define	FLOGBOX		0x00100000L
# define	FSECTRL		0x00200000L
# define	FRESCLR		0x80000000L

# define	UDMNUS		(CMNUBAR|FMNUBAR)
# define	UDTOTS		(UDFILS|UDMATS|UDSELS)
# define	UDHDRS		(FIXHDRS|DYNHDRS|UPATHDR)
# define	UDINFO		(UDTOTS|UDRGXP|UDPATH)
# define	RESCREN		(FRESCLR|REFRAME|UDHDRS|UDINFO)
# define	REFIRST		(FRESCLR|FRESBAN|FLOGBOX|FSECTRL)

# define	FRAMAX		20				/* max # of border frame chars	*/
# define	KPOINTS		0x08
# define	FATAL		0x01
# define	BANAL		0x00
# define	NOWHY		-1
# define	USEBUF		0x0001
# define	KEEPMNUS	0x0004
# define	LOGCWD		0x0001
# define	MAXBANLIN	128

/************************************************************************
*	+ data prototypes													*
************************************************************************/

TYP		struct fildat	FILDAT ;
TYP		struct dirdat	DIRDAT ;
TYP		struct topdat	TOPDAT ;
TYP		struct hdrinf	HDRINF ;
TYP		struct errinf	ERRINF ;
TYP		struct hydat	HYDAT ;

struct fildat {
	char *		fd_path ;				/* full pathname ...			*/
	char *		fd_nam ;				/* last name					*/
	TRXSIZ		fd_lix ;				/* local total file list index	*/
	TRXSIZ		fd_mix ;				/* local match file list index	*/
	TRXSIZ		fd_gix ;				/* global total file list index	*/
	short		fd_flg ;				/* control flags				*/
	STABLK		fd_stabuf ;				/* status info					*/
	DIRDAT *	fd_dir ;				/* parent directory backlink	*/
} ;

struct dirdat {
	char *		dd_path ;				/* full pathname ...			*/
	char *		dd_nam ;				/* last name					*/
	short		dd_flg ;				/* control flags				*/
	short		dd_depth ;				/* relative depth				*/
	short		dd_maxlen ;				/* max nam len					*/
	TRXSIZ		dd_dik ;				/* dir count					*/
	TRXSIZ		dd_fik ;				/* total file count				*/
	TRXSIZ		dd_mfk ;				/* match file count				*/
	TRXSIZ		dd_tfk ;				/* tagged file count			*/
	TRXSIZ		dd_fib ;				/* total file bytes				*/
	TRXSIZ		dd_mfb ;				/* match file bytes				*/
	TRXSIZ		dd_tfb ;				/* tagged file bytes			*/
	STABLK		dd_stabuf ;				/* status info					*/
	DIRDAT *	dd_dir ;				/* parent directory backlink	*/
	DIRDAT * *	dd_dil ;				/* dir list						*/
	FILDAT * *	dd_fil ;				/* file list					*/
	FILDAT * *	dd_mfl ;				/* match file list				*/
# ifdef COMMENT
	char		dd_rxp [ 20 ] ;			/* regular expression pattern	*/
# endif /* COMMENT */
} ;

struct topdat {
	DIRDAT *	td_pan ;				/* panoramic totals & globals	*/
	DIRDAT *	td_bot ;				/* beginning of the (sub)tree	*/
	DIRDAT * *	td_wal ;				/* walk about list ...			*/
	char * *	td_pil ;				/* tree picture element list	*/
	char		td_rxp [20] ;			/* rgl.expr.pattern/fam. spec.	*/
	int			td_flg ;				/* flags ...					*/
	int			td_wax ;				/* walk about index ...			*/
	int			td_ord ;				/* ascending or descending ...	*/
	int		( * td_cmp ) () ;			/* comparison routine ...		*/
	/* status & statistical fields ...	*/
} ;

struct hdrinf {
	int  * hi_lin ;
	int  * hi_col ;
	int    hi_len ;
	char * hi_txt ;
} ;

struct errinf {
	int    ei_cod ;
	char * ei_why ;
} ;

struct	hydat	{
	char		hy_nam [8] ;	/* head id			*/
	int			hy_cur ;		/* current			*/
	int			hy_tot ;		/* # of				*/
	int			hy_max ;		/* max # of			*/
	char * *	hy_val ;		/* values			*/
} ;

/*----------------------------------------------------------------------*
*	+ unix-dependant data prototypes ...								*
*----------------------------------------------------------------------*/
# ifdef ANYX

TYP			struct	capctl		CAPCTL ;

struct	capctl	{
	char *		capid ;		/* terminal capability identification ...	*/
	char * *	captr ;		/* pointer to buffer ...					*/
	int			caplen ;	/* strlen () ...							*/
} ;

# define	CINVIS		16
# define	CVISIB		17

struct keyinfo {
	char * ki_cap ;		/* trixterm.cap codename	*/
	int    ki_cod ;		/* internal value		*/
	char * ki_nam ;		/* identification		*/
	char * ki_sig ;		/* signature			*/
} ;
typedef   struct keyinfo  KEYINFO ;
# define  KI_SIZ  sizeof (KEYINFO)

struct owndat {
    int     od_uid ;
    char *  od_nam ;
} ;
typedef     struct owndat   OWNDAT ;

struct grpdat {
    int     gd_gid ;
    char *  gd_nam ;
} ;
typedef     struct grpdat   GRPDAT ;

# endif /* ANYX */
/************************************************************************
*	system-dependent local macros (DOS)									*
************************************************************************/

# ifdef		DOS

# define	PCKEY(X)		( MASKEY | ( X ) )
# define	GETKEY(X)	X = /* bioskey (0) & 0xff */ getch ()
# define	CLRSCR		clrscr ()
# define	CLRTOEOL	clreol ()
# define	ECHOKEY(Z)	putch (Z)

# endif		/* DOS */

/************************************************************************
*																		*
*	system-dependent local macros (ANYX)								*
*																		*
*	fut/y ther should b defined a macro 2 ifdef CURSES then chg that	*
*	sprintf(%10d)+dispat(tb,10)... 2 move(...)+printw(...)				*
*																		*
************************************************************************/

# ifdef		ANYX

# ifdef		CURSES

# define	GETKEY(X)		X = getch ()
# define	CLRSCR			clear ()
# define	CLRTOEOL		clreol ()
# define	ECHOKEY(Z)		putc(Z,stdout);fflush(stdout);
# define	VPUTS(X)		fputs(X,stdout);fflush(stdout);

# else		/* PROPRIETARY */

# define	ABKEY(X)		( MASKEY | ( X ) )
# define	VPUTS(X)		tputs (X,0,xoutc)	/* write (TFD, X, Y)	*/

# ifdef TRIXKEY

# ifdef ANSI
int		trixkey ( void ) ;
# else  /* OLDSTYLE */
int		trixkey ( ) ;
# endif /* ANSI */

# define	GETKEY(X)		X = trixkey ()
# define	getkey()		trixkey ()

# else  /* V-1 */

# define	GETKEY(X)		read (TFD, kyb, 1) ; X = *kyb
# define	getkey()		getch()

# endif /* TRIXKEY */

# define    gotoxy(x,y)     locat (y-1, x-1)

# ifdef	OLDWAY
# define	CLRSCR			VPUTS ( clbuf )
# else  /* WWSTYLE */
# define	CLRSCR			wweras ( ) ;
# endif /* OLDWAY */

# define	CLRTOEOL		VPUTS ( cebuf )
# define	ECHOKEY(Z)		cx = Z ; gwrd = write (tfd, &cx, 1)

# endif		/* CURSES */

# endif		/* ANYX */

/************************************************************************
*	system-independent local macros ...									*
************************************************************************/

# define	TAGGED(X)		( ((X)->fd_flg) & TAGFLG )
# define	TAGGIT(X)		( ((X)->fd_flg) |= TAGFLG )
# define	UNTAGT(X)		( ((X)->fd_flg) &= ~TAGFLG )

# ifdef		NIC
# define	STRUCPY(A,B)	A = B
# else		/* NIC */
# define	STRUCPY(A,B)	memcpy (&A, &B, sizeof (A))
# endif		/* NIC */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifndef	_OF_DEFINED_

# define	_OF_DEFINED_

# ifdef		ANSI

# define	OF(X)		X

# else		/* OLD STYLE */

# define	OF(X)		()

# endif		/* ANSI */

# endif		/* ! _OF_DEFINED_ */

/*	typedef		unsigned char	BYTE ;	*/

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/*
 * vi:nu tabstop=4
 */
