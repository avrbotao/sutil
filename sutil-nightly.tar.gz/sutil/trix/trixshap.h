struct vdopoint {
    int vp_lin ;
    int vp_col ;
} ;

TYP     struct vdopoint     VP ;

# define    GOYX(P)         gotoxy (P.vp_col, P.vp_lin) ;

struct trixshap {
    int     ts_vlines ;         /* total # of lines on screen       */
    int     ts_vcols ;          /* total # of cols on screen        */
    int     ts_hlbord ;         /* tree/ctrl wdw horiz. border      */
    int     ts_vcbord ;         /* tree/file wdw vert. border	    */
    int     ts_msglin ;
    VP      ts_twofs ;          /* tree window home offset          */
} ;

TYP     struct trixshap     TRIXSHAP ;

/***********************************************************************/
