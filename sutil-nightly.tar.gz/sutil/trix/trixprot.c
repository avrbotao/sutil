/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixprot.c + protect a file or directory via its    |
 *      |                mode bits ...                          |
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include   <stdio.h>

# ifdef		DOS

# include	<conio.h>
# include	<string.h>

# include	<sys/stat.h>

# endif		/* DOS */

# include	"trix.h"
# include   "trixasci.h"
# include   "trixchrs.h"
# include   "trixkeys.h"
# include   "trixblue.h"
# include   "trixfunc.h"
# include   "trixext.h"
# include   "trixtext.h"
# include   "trixwig.h"
# include   "trixwind.h"

EXT		int		vdotyp ;

/*
 *  |---------------------------|
 *  |   data prototypes ...		|
 *  |---------------------------|
 */

typedef  struct textus  TEXTUS ;

struct textus {
	int tt_lin ;
	int tt_col ;
	char * tt_str ;
} ;

typedef  struct probit  PROBIT ;

struct probit {
	int bb_lin ;
	int bb_col ;
	int bb_val ;
	char * bb_txt ;
	/* char * bb_help ; */
} ;

# ifdef ANYX

/*
 *  |---------------------------|
 *  |   text screen-graphy ...	|
 *  |---------------------------|
 */

TEXTUS bpetxt [] = {
    { 19,  2, "Protecao Atual:" },
    {  3,  2, "Protecao Original:" },

	{  6,  2, "Dono:" } ,
	{ 11,  2, "Grupo:" } ,
	{ 16,  2, "Outro Usuario:" },

	{  4, 35, "Ler" } ,
	{  4, 44, "Gravar" } ,

/*	{  0,  0, SWID } ,	*/

	{ 23,  0, "F1=Ajuda   [Tab]=Avanca   [Espaco]=Troca   [Enter]=Protege   [Esc]=Cancela" } ,

	{ -1, -1, "" }
} ;

TEXTUS fpetxt [] = {
	{  2,  2, "Arquivo:" } ,
	{  4, 54, "Executar" } ,
	{  0, 29, "Editor de Protecao de Arquivos" } ,
	{ -1, -1, "" }
} ;

TEXTUS dpetxt [] = {
	{  2,  2, "Diretorio:" } ,
	{  4, 54, "Pesquisar" } ,
	{  0, 29, "Editor de Protecao de Diretorios" } ,
	{ -1, -1, "" }
} ;

TEXTUS * petxt ;

/*
 *  |---------------------------------------------------|
 *  |   protection bits' places, masks, & meaning ...	|
 *  |---------------------------------------------------|
 */

PROBIT fpebits [] = {
	{  7, 36, 0400, "o dono%spode ler ...                   " } ,
	{  7, 46, 0200, "o dono%spode gravar ...                " } ,
	{  7, 56, 0100, "o dono%spode executar ...              " } ,
	{ 12, 36, 0040, "membros do grupo%spodem ler ...        " } ,
	{ 12, 46, 0020, "membros do grupo%spodem gravar ...     " } ,
	{ 12, 56, 0010, "membros do grupo%spodem executar ...   " } ,
	{ 17, 36, 0004, "outros usuarios%spodem ler ...         " } ,
	{ 17, 46, 0002, "outros usuarios%spodem gravar ...      " } ,
	{ 17, 56, 0001, "outros usuarios%spodem executar ...    " } ,
	{ -1, -1,   -1, "" }
} ;

PROBIT dpebits [] = {
	{  7, 36, 0400, "o dono%spode ler ...                   " } ,
	{  7, 46, 0200, "o dono%spode gravar ...                " } ,
	{  7, 56, 0100, "o dono%spode pesquisar ...             " } ,
	{ 12, 36, 0040, "membros do grupo%spodem ler ...        " } ,
	{ 12, 46, 0020, "membros do grupo%spodem gravar ...     " } ,
	{ 12, 56, 0010, "membros do grupo%spodem pesquisar ..   " } ,
	{ 17, 36, 0004, "outros usuarios%spodem ler ...         " } ,
	{ 17, 46, 0002, "outros usuarios%spodem gravar ...      " } ,
	{ 17, 56, 0001, "outros usuarios%spodem pesquisar ...   " } ,
	{ -1, -1,   -1, "" }
} ;

PROBIT * pebits ;

/*
 *  |-----------------------------------------------|
 *  |   protection bits' blend descriptions ...		|
 *  |-----------------------------------------------|
 */

char * fpecomb [] = {
    "NAO PODE Ler, Gravar e Executar",
    "Pode Executar",
    "Pode Gravar",
    "Pode Gravar e Executar",
    "Pode Ler",
    "Pode Ler e Executar",
    "Pode Ler e Gravar",
    "Pode Ler, Gravar e Executar",
    (char *) 0
} ;

char * dpecomb [] = {
    "NAO PODE Ler, Gravar e Pesquisar",
    "Pode Pesquisar",
    "Pode Gravar",
    "Pode Gravar e Pesquisar",
    "Pode Ler",
    "Pode Ler e Pesquisar",
    "Pode Ler e Gravar",
    "Pode Ler, Gravar e Pesquisar",
    (char *) 0
} ;

char * * pecomb ;

# else	/* DOS */

/*
 *  |---------------------------|
 *  |   text screen-graphy ...	|
 *  |---------------------------|
 */

TEXTUS bpetxt [] = {
    { 19,  2, "Protecao Atual:" },
    {  3,  2, "Protecao Original:" },

	{  6,  2, "Archive" } ,
	{ 11,  2, "Read-Only" } ,
	{ 16,  2, "System" } ,
	{  4, 44, "Hidden" } ,

	{ 23,  0, "F1=Ajuda   [Tab]=Avanca   [Espaco]=Troca   [Enter]=Protege   [Esc]=Cancela" } ,

	{ -1, -1, "" }
} ;

TEXTUS fpetxt [] = {
	{  2,  2, "Arquivo:" } ,
	{  0, 29, "Editor de Protecao de Arquivos" } ,
	{ -1, -1, "" }
} ;

TEXTUS dpetxt [] = {
	{  2,  2, "Diretorio:" } ,
	{  0, 29, "Editor de Protecao de Diretorios" } ,
	{ -1, -1, "" }
} ;

TEXTUS * petxt ;

/*
 *  |---------------------------------------------------|
 *  |   protection bits' places, masks, & meaning ...	|
 *  |---------------------------------------------------|
 */

/*
 *	rdonly	0x01		hidden	0x02		system	0x04
 *	label	0x08		direct	0x10		arch	0x20
 */

PROBIT fpebits [] = {
	{  7, 36, FA_ARCH,   "Arquivo foi acessado          " } ,
	{ 12, 36, FA_RDONLY, "Arquivo NAO pode ser deletado " } ,
	{ 17, 36, FA_SYSTEM, "Arquivo do Sistema            " } ,
	{  7, 46, FA_HIDDEN, "Arquivo OCULTO                " } ,
	{ -1, -1,   -1, "" }
} ;

PROBIT dpebits [] = {
	{  7, 36, FA_ARCH,   "Diretorio foi acessado          " } ,
	{ 12, 36, FA_RDONLY, "Diretorio NAO pode ser deletado " } ,
	{ 17, 36, FA_SYSTEM, "Diretorio do Sistema            " } ,
	{  7, 46, FA_HIDDEN, "Diretorio OCULTO                " } ,
	{ -1, -1,   -1, "" }
} ;

PROBIT * pebits ;

/*
 *  |-----------------------------------------------|
 *  |   protection bits' blend descriptions ...		|
 *  |-----------------------------------------------|
 */

char * fpecomb [] = {
    "000",
    "001",
    "010",
    "011",
    "100",
    "101",
    "110",
    "111",
    (char *) 0
} ;

char * dpecomb [] = {
    "000",
    "001",
    "010",
    "011",
    "100",
    "101",
    "110",
    "111",
    (char *) 0
} ;

char * * pecomb ;

# endif	/* ANYX */

/*
 *							|---------------------------------------|
 *							|   edit protection mode bits ...		|
 *							|---------------------------------------|
 */

int proted (ffp, ddp, wtd) FILDAT * ffp ; DIRDAT * ddp ; int wtd ; {

	register TEXTUS * ttp ;
	register PROBIT * bbp ;
	int i, j, bbk = 0, key ;
	unsigned int xbits ;
	unsigned int obits ;
    FIX BYT pok [2] = { '\0' , '\0' } ;
    FIX BYT pno [2] = { '\0' , '\0' } ;
    REG BYT * pon ;
	char tb [80] ;
	EXT UNS gprot ;
    /* EXT char * clbuf ; */
    EXT char altgcs [] ;

	unsigned int	dofbits ;	/* dir or file mode bits			*/
	char *			dofpath ;	/* dir or file full pathname		*/
	char *			dofalls ;	/* dir or file "all tagged txt"		*/

# ifdef	ANYX

	unsigned int	dofuid = 0 ;	/* dir or file user id				*/
	unsigned int	dofgid = 0 ;	/* dir or file group id				*/

    char * xp ;

    FIX BYT * pbl = (BYT *) "*ugtrwxrwxrwx" ; /* MUST BE IN TRIXTEXT.DAT !!	*/

    OWNDAT   odb ;
    OWNDAT * odp ;
    GRPDAT   gdb ;
    GRPDAT * gdp ;

    EXT int totown , totgrp ;
    EXT OWNDAT * ownlist ;
    EXT GRPDAT * grplist ;

# else  /* DOS, NETS, ... */

	FIX BYT * pbl = (BYT *) "*arsh--------" ;

# endif	/* ANYX */

# ifdef COMMENT
	char * nope = " NAO " ;
	char * yeah = " " ;
	char * pmay ;
# endif /* COMMENT */

    pok [0] = C_CHECK ; pno [0] = C_GSPC ;
	CLRSCR ;

	if (wtd == 'f') {

		if (ffp != NOFID) {

			dofbits = ffp->fd_stabuf.STAPROT ;
			dofpath = ffp->fd_path ;

# ifdef ANYX

			dofuid  = ffp->fd_stabuf.STAUID ;
			dofgid  = ffp->fd_stabuf.STAGID ;

# endif /* ANYX */

			xbits = dofbits ;
			dispat ( 2, 11, dofpath, 68, VEHILT) ;

		} else {

			dofalls = T_ALLSELS ;

			xbits = 0777 | S_IFREG ;
			dispat ( 2, 11, dofalls, 68, VEHILT) ;
		}

	} else { /* wtd == 'd' */

		if (ddp != NODID) {

			dofbits = ddp->dd_stabuf.STAPROT ;
			dofpath = ddp->dd_path ;

# ifdef ANYX

			dofuid  = ddp->dd_stabuf.STAUID ;
			dofgid  = ddp->dd_stabuf.STAGID ;

# endif /* ANYX */

			xbits = dofbits ;
			dispat ( 2, 11, dofpath, 68, VEHILT) ;

		} else {

			dofalls = T_ALLSELS ;

			xbits = 0777 | S_IFREG ;
			dispat ( 2, 11, dofalls, 68, VEHILT) ;
		}
	}

	obits = xbits ;
    dispat ( 3, 21, trixdm (obits), _wprotxt, VENORM) ;
/*
 *	|-------------------------------------------------------|
 *	|	disp text (common 1st, then file's or dir's) ...	|
 *	|-------------------------------------------------------|
 */
	for ( ttp = bpetxt ; ttp->tt_lin >= 0 ; ++ttp ) {
        dispat (ttp->tt_lin, ttp->tt_col, ttp->tt_str,
                strlen (ttp->tt_str), VENORM) ;
	}

	if (wtd == 'f')
		petxt = fpetxt ;
	else
		petxt = dpetxt ;

	for ( ttp = petxt ; ttp->tt_lin >= 0 ; ++ttp ) {
        dispat (ttp->tt_lin, ttp->tt_col, ttp->tt_str,
                strlen (ttp->tt_str), VENORM) ;
	}

	/*-----------------------------------------------------*/

	if (wtd == 'f')
		pebits = fpebits ;
	else
		pebits = dpebits ;

	protboxs () ;

	for ( bbp = pebits ; bbp->bb_lin >= 0 ; ++bbp , ++bbk ) {
		if (xbits & bbp->bb_val) {
			dispat (bbp->bb_lin, bbp->bb_col, (char *) pok, 1, VEAGCS) ;
		}
	}

	if (wtd == 'f')
		pecomb = fpecomb ;
	else
		pecomb = dpecomb ;

# ifdef ANYX

    for ( j = 0 ; j < 3 ; ++j ) {
        i = ( obits >> (j*3) ) & 07 ;
        dispat (pebits[(2-j)*3].bb_lin, 2, *(pecomb+i), 32, VENORM) ;
	}

# else  /* DOS */

# endif /* ANYX */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef ANYX

/*
 *	|-------------------------------|
 *	|   display ownership info ...	|
 *	|-------------------------------|
 */
	if (ffp != NOFID || ddp != NODID) {

		odb.od_uid = dofuid ;

        odp = (OWNDAT *) bsearch ( (void *) &odb,
                                   (void *) ownlist,
                                   (size_t) totown,
                                   (size_t) sizeof (OWNDAT),
                                   owncmp                    ) ;

        if (odp == VZRO (OWNDAT *))
            sprintf (xp = tb, "(%d)", dofuid) ;
        else
            sprintf (xp = tb, "(%s)", odp->od_nam) ;

		dispat (6, 8, xp, 18, VENORM) ;

        gdb.gd_gid = dofgid ;

        gdp = (GRPDAT *) bsearch ( (void *) &gdb,
                                   (void *) grplist,
                                   (size_t) totgrp,
                                   (size_t) sizeof (GRPDAT),
                                   grpcmp                    ) ;

        if (gdp == VZRO (GRPDAT *))
            sprintf (xp = tb, "(%d)", dofgid) ;
        else
            sprintf (xp = tb, "(%s)", gdp->gd_nam) ;

        dispat (11, 9, xp, 18, VENORM) ;
	}

# endif /* ANYX */

/*
 *	|-------------------------------|
 *	|   main interface loop ...		|
 *	|-------------------------------|
 */
	for ( bbp = pebits ; ; ) {

# ifdef COMMENT
/*
 *      |-------------------------------|
 *      |   reflect bit meaning ...		|
 *      |-------------------------------|
 */
		pmay = nope ;

		if (xbits & bbp->bb_val)
			pmay = yeah ;

		sprintf (tb, bbp->bb_txt, pmay) ;
        dispat (21, 10, tb, strlen (tb), VENORM) ;

# endif /* COMMENT */
/*
 *      |-----------------------------------------------|
 *      |   display mode string & highlight curr bit    |
 *      |-----------------------------------------------|
 */
        dispat (19, 18, trixdm (xbits), _wprotxt, VENORM) ;

        j = (int) (bbp - pebits) ; tb[0] = '-' ; tb[1] = '\0' ;

		if (xbits & bbp->bb_val)

# ifdef ANYX

			tb[0] = *(pbl+j+4) ;

        dispat (19, 18+j+4, tb, 1, VEHILT) ;

# else  /* DOS, ... */

			tb[0] = *(pbl+j+1) ;

		dispat (19, 18+j+1, tb, 1, VEHILT) ;

# endif /* ANYX */

/*
 *      |-----------------------------------------------|
 *      |   monitors don't show cursor with ' ' on agcs |
 *      |-----------------------------------------------|
 */
		if (vdotyp != 't') {
       		if (xbits & bbp->bb_val) {
                pon = pok ;
            } else {
				pon = pno ;
            }
			dispat (bbp->bb_lin, bbp->bb_col, (char *) pon, 1, VEAGCS) ;
		}
/*
 *      |---------------------------------------|
 *      |   stay still & get a keystroke ...	|
 *      |---------------------------------------|
 */
		locat (bbp->bb_lin, bbp->bb_col) ;
        showcursor () ;
		key = getkey () ;
        hidecursor () ;

		switch (key) {

			case CTRL_Q :
			case ESC : return ESC ;

			case '+' :
                switfram () ;
                protboxs () ;
            break ;

			case KRIGHT :
			case '6' :
			case KDOWN :
			case '2' :
			case '\t' :
				++bbp ;
				if (bbp->bb_lin < 0)
					bbp = pebits ;
			break ;

			case KLEFT :
			case '4' :
			case KUP :
			case '8' :
            case '\b' :
                if (bbp > pebits)
                    --bbp ;
                else
                    bbp = pebits + (bbk - 1) ;
            break ;

            case '\r' :   /* should we ask (check) 4 sure ? */
            case '\n' :   goto pit ;

            case ' ' :
        		if (xbits & bbp->bb_val) {
                    xbits &= ~ (bbp->bb_val) ; pon = pno ;
                } else {
                    xbits |=   (bbp->bb_val) ; pon = pok ;
                }
				dispat (bbp->bb_lin, bbp->bb_col, (char *) pon, 1, VEAGCS) ;
                i = ( xbits >> ((2-(j/3))*3) ) & 07 ;
                dispat (bbp->bb_lin, 2, *(pecomb+i), 32, VENORM) ;
			break ;

			case '?'  :
			case KF1 :
				hyxhelp ("Editor de Protecao de Arquivos") ;
			break ;

			default : honk () ; break ;
		}
	} /* endof (bit scan) */

pit :

	if ((ffp == NOFID && wtd == 'f') || (ddp == NODID && wtd == 'd')) {
		gprot = xbits ;
		return 0 ;
	}

	return protfil (ffp, xbits, 0, ddp, wtd) ;

} /* endof proted() */

/*
 *								|-----------------------------------|
 *								|   protably protect a file ...		|
 *								|-----------------------------------|
 */

int protfil (ffp, pbits, flgs, ddp, wtd) FILDAT * ffp ; UNS pbits ; DIRDAT * ddp ; int flgs , wtd ; {
    REG int grd ;
	char tb [ 80 ] ;

	char *			dofnam  ;	/* dir or file name (last)			*/

# ifdef ANYX

	char *			dofpath ;	/* dir or file full pathname		*/
	STABLK stabuf ;
	unsigned int	dofuid  ;	/* dir or file user id				*/

# endif /* ANYX */

	if (wtd == 'f') {

		dofnam  = ffp->fd_nam ;

# ifdef ANYX

		dofpath = ffp->fd_path ;
		dofuid  = ffp->fd_stabuf.STAUID ;

# endif /* ANYX */

	} else {

		dofnam  = ddp->dd_nam ;

# ifdef ANYX

		dofpath = ddp->dd_path ;
		dofuid  = ddp->dd_stabuf.STAUID ;

# endif /* ANYX */

	}

# ifdef ANYX

    if (realuid != 0) {
        if (dofuid != realuid) {
            sprintf (tb, T_CHMERR, dofnam) ;
            grd = askok (tb, T_NOTOWNER) ;
            return grd ;
        }
    }

# endif /* ANYX */

	if (flgs & CONFLG) {	/* confirm protection flag */
it :
		sprintf (tb, T_CONPROT, dofnam, trixdm (pbits)) ;
		grd = askyn (tb, T_RUSURE) ;

		switch (grd) {
			case ENTER :
			case NOPE  : return -1 ;
			case CTRL_Q :
			case ESC   : return ESC ;
			case YEAH  : break ;
			case KF1   : hyxhelp ("protfil") ; goto it ;
		}
	}

# ifdef ANYX

	if (chmod (dofpath, pbits & 0777) < 0) {
		grd = trixerr (T_CHMERR, dofnam, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
    }

/*	dofbits = pbits ;	*/

    xstatus (dofpath, &stabuf) ;

	if (wtd == 'f') {
		STRUCPY (ffp->fd_stabuf, stabuf) ;
	} else {
		STRUCPY (ddp->dd_stabuf, stabuf) ;
	}

# else  /* DOS */

	/* ... */

# endif /* ANYX */

	return 0 ;
}

/*
 *											|-----------------------|
 *	.	.	.	.	.	.	.	.	.	.	|   redraw frames ...	|
 *											|-----------------------|
 */

void protboxs () {
	register PROBIT * bbp ;

	putbox (1, 0, 80, 20) ;

	for ( bbp = pebits ; bbp->bb_lin >= 0 ; ++bbp ) {
		putbox (bbp->bb_lin - 1, bbp->bb_col - 2, 5, 3) ;
	}
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/*
 * vi:nu ts=4
 */
