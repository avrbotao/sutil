/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixhist.c + command response history management.	|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include	<stdio.h>
# include	<string.h>

# ifdef DOS
#	include	<conio.h>
# endif /* DOS */

# include	"trix.h"
# include	"trixstd.h"
# include	"trixfunc.h"
# include	"trixkeys.h"
# include	"trixaloc.h"
# include	"trixtext.h"
# include	"trixext.h"
# include	"trixasci.h"

EXT		HYDAT *		histlist ;
EXT		int			tothist ;

char yfnam [80] ;
/*
 *		|-------------------------------------------------------|
 *      |   hist file's pathname must be cfg'abl ...            |
 *      |-------------------------------------------------------|
 */
void inithist () {
	REG	HYDAT * ylp ;
	REG char * * tcpp ;
	REG char * tp ;
	REG int j ;
		FILE * yfp ;
		char yfb [TEBSIZ] ;
		char tyid [20] ;
		int tytot, tymax ;

# ifdef XTRC
	fprintf (trcfp, "inithist()\r\n") ;
# endif

# ifdef ANYX
    sprintf (yfnam, "%s/.trix/", getenv ("HOME")) ;
# else  /* DOS */
	strcpy (yfnam, "\\trix\\") ;
# endif /* ANYX */

    strcat (yfnam, "trixhist.dat") ;
    yfp = fopen (yfnam, "r") ;

	if (yfp == (FILE *) 0) {
    	yfp = fopen (yfnam, "w") ;
		if (yfp == (FILE *) 0) {
			fprintf (stderr, "Trix : Erro ao processar arquivo de historico (%s) !\n", yfnam) ;
		} else {
			fclose (yfp) ;
		}
		return ;
	}

	while (fgets (yfb, TEBSIZ, yfp) != (char *) 0) {
		if (yfb[0] != '+') {
hfe :		fprintf (stderr,
				"Trix : Controle Invalido no Arquivo de Historico\n") ;
			fclose (yfp) ;
			return ;
		}
		j = sscanf (&yfb[1], "%s %d %d", tyid, &tytot, &tymax) ;

		if (j != 3 || tytot <= 0 || tymax <= 0 || tytot > tymax)
			goto hfe ;

		if ((ylp = histlist) != VZRO (HYDAT *)) {
			j = (tothist + 1) * sizeof (HYDAT) ;
			ylp = (HYDAT *) REALLOC ( (char *) ylp, j ) ;
			if (ylp == (HYDAT *) 0) {
/* rehst : */	trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;
			}
		} else {
			if (FALLOP (ylp, HYDAT)) {
nmhst :         trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
			}
		}

		tcpp = (char * *) calloc (tymax, sizeof (char *)) ;

		if (tcpp == (char * *) 0)
			goto nmhst ;

		histlist = ylp ;
		ylp += tothist ;
		strcpy (ylp->hy_nam, tyid) ;
		ylp->hy_tot = tytot ;
		ylp->hy_max = tymax ;
		ylp->hy_cur = 0 ;
		ylp->hy_val = tcpp ;
		++tothist ;

		for ( j = 0 ; j < tytot ; ++j ) {

			tp = fgets (yfb, TEBSIZ, yfp) ;

			if (tp == (char *) 0) {
				fprintf (stderr,
					"TRIX : Arquivo de Historico Incompleto.\n") ;
				--tothist ;
				fclose (yfp) ;
				return ;
			}

			strend (yfb, "\r\n") ;
			tp = malloc (strlen (yfb) + 1) ;

			if (tp == (char *) 0)
				goto nmhst ;

			strcpy (tp, yfb) ;
			*(tcpp + j) = tp ;
		}
	}

	qsort ((char *)histlist, tothist, sizeof (HYDAT), histcmp) ;

	fclose (yfp) ;
}
/*      |-------------------------------------------------------|
 *      |   + must capture SIGBUS, SIGSEGV, ... in order to		|
 *		|	  save history (in epilog() !)						|
 *      |-------------------------------------------------------|
 */
void endhist () {
	REG	HYDAT * ylp = histlist ;
	REG char * * tcpp ;
	REG int j, k ;
		FILE * yfp = fopen (yfnam, "w") ;

	if (yfp == (FILE *) 0) {
		fprintf (stderr,
			"Trix : Erro ao abrir arquivo de historico (%s) !\n",
			yfnam) ;
		return ;
	}

	for ( k = 0 ; k < tothist ; ++k, ++ylp ) {
		fprintf (yfp, "+ %s %d %d\n", ylp->hy_nam,
			ylp->hy_tot, ylp->hy_max) ;
		tcpp = ylp->hy_val ;
		for ( j = 0 ; j < ylp->hy_tot ; ++j )
			fprintf (yfp, "%s\n", *(tcpp+j)) ;
	}

	fclose (yfp) ;

# ifdef ANYX

    if (effuid == 0) {
		if (chown (yfnam, realuid, realgid) < 0) {
        	unlink (yfnam) ;
			trixerr (T_ESUGID, yfnam, errno, BANAL) ;
        	return ;
    	}
	}

# endif /* ANYX */

} /* endof endhist () */

/*
 *		|-------------------------------------------------------|
 *      |   ...                                                 |
 *      |-------------------------------------------------------|
 */

char * trixhist (what, cmd) char * what ; int cmd ; {
	REG	HYDAT * yp ;
	REG	char * vp = NULL ;
		HYDAT yb ;

	if (tothist == 0 || histlist == (HYDAT *) 0)
		return (char *) 0 ;	/* MUST CREATE IT ALL FROM SCRATCH ! */

	strcpy (yb.hy_nam, what) ;

	yp = (HYDAT *) bsearch ( (void *) &yb,
							 (void *) histlist,
							 (size_t) tothist,
							 (size_t) sizeof (HYDAT),
							 histcmp                   ) ;

	if (yp == VZRO (HYDAT *))
		return (char *) 0 ;

	if (cmd == KUP || cmd == CTRL_E) {

		yp->hy_cur += 1 ;

		if (yp->hy_cur >= yp->hy_tot)
			yp->hy_cur = 0 ;

		vp = *((yp->hy_val)+(yp->hy_cur)) ;

	} else if (cmd == KDOWN || cmd == CTRL_X) {

		yp->hy_cur -= 1 ;

		if (yp->hy_cur < 0)
			yp->hy_cur = yp->hy_tot - 1 ;

		vp = *((yp->hy_val)+(yp->hy_cur)) ;

	}

	return vp ;
}
/*
 *		|-------------------------------------------------------|
 *      |   ...                                                 |
 *      |-------------------------------------------------------|
 */
void addhist (what, txt) char * what , * txt ; {
	REG	HYDAT * 	yp ;
	REG	char *		vp ;
	REG char * *	tcpp ;
	REG	int			j ;
		HYDAT yb ;

/*
 *	|---------------------------------------------------|
 *	|	+ 1st chk 4 empty hst lst & bld 1 ...			|
 *	|---------------------------------------------------|
 */
	if (tothist > 0 && histlist != (HYDAT *) 0)
		goto tvh ;

	yp = (HYDAT *) malloc (sizeof (HYDAT)) ;

	if (yp == (HYDAT *) 0) {
nmah :	trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
	}

	strcpy (yp->hy_nam, what) ; yp->hy_val = (char * *) 0 ;
	yp->hy_tot = yp->hy_cur = 0 ; yp->hy_max = 30 ;

	tothist = 1 ; histlist = yp ;
/*
 *	|---------------------------------------------------|
 *	|	+ if virgin head, realloc & grow hst lst ...	|
 *	|---------------------------------------------------|
 */
tvh :
	strcpy (yb.hy_nam, what) ;

	yp = (HYDAT *) bsearch ( (void *) &yb,
							 (void *) histlist,
							 (size_t) tothist,
							 (size_t) sizeof (HYDAT),
							 histcmp                   ) ;

	if (yp != VZRO (HYDAT *))
		goto atl ;

	yp = histlist ;
	j = (tothist + 1) * sizeof (HYDAT) ;
	yp = (HYDAT *) REALLOC ( (char *) yp, j ) ;

	if (yp == (HYDAT *) 0)
		trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;

	histlist = yp ;
	yp += tothist ;
	strcpy (yp->hy_nam, what) ; yp->hy_val = (char * *) 0 ;
	yp->hy_tot = yp->hy_cur = 0 ; yp->hy_max = 30 ;
	++tothist ;
/*
 *	|---------------------------------------------------|
 *	|	+ add txt 2 val lst :							|
 *	|		+ chk 4 empty val lst ...					|
 *	|---------------------------------------------------|
 */
atl :
	vp = malloc (strlen (txt)+1) ;

	if (vp == (char *) 0)
		goto nmah ;

	strcpy (vp, txt) ;

	if (yp->hy_tot > 0)
		goto trv ;

	tcpp = (char * *) calloc (yp->hy_max, sizeof (char *)) ;

	if (tcpp == (char * *) 0)
		goto nmah ;

	*tcpp = vp ;
	yp->hy_tot = 1 ; yp->hy_cur = 0 ;
	yp->hy_val = tcpp ;
	return ;
/*
 *	|---------------------------------------------------|
 *	|	+ add txt 2 val lst :							|
 *	|		+ chk if already in val lst ...             |
 *	|---------------------------------------------------|
 */
trv :
	for (	j = 0 , tcpp = yp->hy_val ;
			j < yp->hy_tot ; ++j , ++tcpp ) {
		if (strcmp (*tcpp, txt) == 0)
			return ;
	}
/*
 *	|---------------------------------------------------|
 *	|	+ add txt 2 val lst :							|
 *	|		+ shft all back if tot >= max               |
 *	|---------------------------------------------------|
 */
	if (yp->hy_tot >= yp->hy_max) {
		yp->hy_tot -= 1 ;
		tcpp = yp->hy_val ;
		j = 0 ;
		while ( j < yp->hy_tot ) {
			*(tcpp) = *(tcpp+1) ;
			++j ; ++tcpp ;
		}
	}
/*
 *	|---------------------------------------------------|
 *	|	+ add txt 2 val lst :							|
 *	|		+ schieBlich !								|
 *	|---------------------------------------------------|
 */
	*((yp->hy_val)+(yp->hy_tot)) = vp ;
	yp->hy_tot += 1 ;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/*
 * vi:nu tabstop=4
 */
