/************************************************************************
* control codes								*
************************************************************************/

# define  CTRL_A	 1
# define  CTRL_B	 2
# define  CTRL_C	 3
# define  CTRL_D	 4
# define  CTRL_E	 5
# define  CTRL_F	 6
# define  CTRL_G	 7
# define  CTRL_H	 8
# define  CTRL_I	 9
# define  CTRL_J	10
# define  CTRL_K	11
# define  CTRL_L	12
# define  CTRL_M	13
# define  CTRL_N	14
# define  CTRL_O	15
# define  CTRL_P	16
# define  CTRL_Q	17
# define  CTRL_R	18
# define  CTRL_S	19
# define  CTRL_T	20
# define  CTRL_U	21
# define  CTRL_V	22
# define  CTRL_W	23
# define  CTRL_X	24
# define  CTRL_Y	25
# define  CTRL_Z	26

/************************************************************************
* synonym control codes & more ...					*
************************************************************************/

/* # define  BS		'\b' */
# define  TAB		'\t'
/* # define  NL		'\n' */
# define  FF		'\f'
# define  VT		'\v'
/* # define  CR		'\r' */
# define  DEL		 127

# define  NUL		0x00
# define  SOH		0x01
# define  STX		0x02
# define  ETX		0x03
# define  EOT		0x04
# define  ENQ		0x05
# define  ACK		0x06
# define  BEL		0x07

# ifdef		COMMENT

# define  HT		0x09
# define  LF		0x0a
# define  SO		0x0e
# define  SI		0x0f

# endif		/* COMMENT */

# define  DLE		0x10
# define  DC1		0x11
# define  DC2		0x12
# define  DC3		0x13
# define  DC4		0x14
# define  NAK		0x15
# define  SYN		0x16
# define  ETB		0x17
# define  CAN		0x18
/* # define  EM		0x19 */
# define  SUB		0x1a
# define  ESC		0x1b

# ifdef		COMMENT

# define  FS		0x1c
# define  GS		0x1d
# define  RS		0x1e
/* # define  US		0x1f */

# endif		/* COMMENT */

/************************************************************************
* numbers								*
************************************************************************/

# define  ZERO		 '0'
# define  NINE		 '9'

/************************************************************************
* punctuation & others							*
************************************************************************/

# ifdef		COMMENT

# define  SP		 ' '
# define  AT		 '@'

# endif		/* COMMENT */

# define  DOT		 '.'
# define  ASTERISK	 '*'
# define  COLON		 ':'
# define  COMMA		 ','
# define  NUMBER	 '#'
# define  VANE		 '"'
# define  MINUS		 '-'
# define  PLUS		 '+'
# define  SLASH		 '/'
# define  BACKSLASH	'\\'
# define  UNDERSCORE	 '_'
# define  CARET		 '^'
# define  TILDE		 '~'

# define  L_BK		 '['		/* left bracket			*/

/************************************************************************
* ... 									*
************************************************************************/
