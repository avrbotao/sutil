/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixsort.c + proprietary better-than-quick sort 4	|
 *		|				 long arrays ...						|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# include	<stdio.h>
# include	"trix.h"

# ifdef COMMENT

void xsort (...) {

}

# endif /* COMMENT */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
