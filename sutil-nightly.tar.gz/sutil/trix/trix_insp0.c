/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixcfg.c + dynamic configuration file management   |
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include <stdio.h>
# include <ctype.h>
# include <string.h>

# include "trix.h"
# include "trixstd.h"
# include "trixcfg.h"
# include "trixfunc.h"

# undef		DBG

/*
 *		|-------------------------------------------------------|
 *		|	...                     							|
 *		|-------------------------------------------------------|
 */

# ifdef ANSI

int cfgcmp (void *, void *) ;
int codcmp (void *, void *) ;

# else  /* OLD */

int cfgcmp ( ) ;
int codcmp ( ) ;

# endif /* ANSI */

int cfgcmp (a, b) void * a , * b ; {

	return strcmp ( * ( ( (CFGIT *) a ) -> ci_nam ) ,
					* ( ( (CFGIT *) b ) -> ci_nam )   ) ;
}

int codcmp (a, b) void * a , * b ; {

	return strcmp ( * ( ( (TXTCOD *) a ) -> tc_txt ) ,
					* ( ( (TXTCOD *) b ) -> tc_txt )   ) ;
}
/*
 *		|-------------------------------------------------------|
 *		|	...                                                 |
 *		|-------------------------------------------------------|
 */

char cnbuf [40] , tnbuf [40] ;
char * cnp , * tnp ;

static  CFGIT   cfgtst = { &cnp, VNULL, VNULL, 0 } ;
static  TXTCOD  tctst  = { &tnp, 0 } ;

void initcfg (cfgbuf) CFGIT * cfgbuf ; {
	register CFGIT * cip ;
	char * cfgfil = "trixconf.dat" ;
	FILE * tfp = trixfopen (cfgfil, "r") ;
	char cflbuf [TEBSIZ] , txbuf [TEBSIZ] , cnbuf [20] ;
	register char * clp , * txp ;
# ifdef DBG
	int tmpint ;
	long tmplon ;
	char * tmpptr ;
# endif /* DBG */
	int newint ;
	long newlon ;
	char * newptr ;
	register int nopt ;
	register TXTCOD * tcp ;
	REG int cfgtot = 0 ;

	if (tfp == (FILE *) 0) {
		fprintf (stderr,
			"Trix : Erro ao abrir arquivo de configuracao (%s) !\n",
			cfgfil) ;
		exit (-1) ;
	}

	for ( cip = cfgbuf ; cip->ci_nam != VNULL ; ++cip , ++cfgtot )
		;

	qsort ((char *)cfgbuf, cfgtot, sizeof (CFGIT), cfgcmp) ;

	while (fgets (cflbuf, TEBSIZ, tfp) != (char *) 0) {
		clp = cflbuf ; txp = txbuf ; cnp = cnbuf ;

		if (*clp == '#' || *clp == '\n' || *clp == '\r')
			continue ;

		while (isspace (*clp))
			++clp ;

		while (! isspace (*clp))
			*cnp++ = *clp++ ;

		*cnp = '\0' ; cnp = cnbuf ;

		cip = (CFGIT *) bsearch (
							(void *) &cfgtst , (void *) cfgbuf  ,
							(size_t) cfgtot , (size_t) sizeof (CFGIT) ,
							cfgcmp
						) ;

		if (cip == (CFGIT *) 0) {
			fprintf (stderr,
				"Trix : Erro no arquivo de configuracao !\n") ;
			fprintf (stderr,
				"-----> parametro \"%s\" desconhecido ...\n",
				cnbuf) ;
			fputs (cflbuf, stderr) ; continue ;
		}

		while (isspace (*clp))
			++clp ;

		if (*clp == '"') {
			while (*++clp != '"') {
				if (*clp == '\0' || *clp == '\n' || *clp == '\r') {
					fprintf (stderr,
						"Trix : Erro no arquivo de configuracao !\n") ;
					fprintf (stderr,
						"-----> texto sem \"fecha-aspas\" ...\n") ;
					fputs (cflbuf, stderr) ; continue ;
				}
				if (*clp == '\\') {
						switch (*++clp) {
							case '"'  :
							case '\\' : *txp++ = *clp ; break ;
						}
				} else
					*txp++ = *clp ;
			}
		} else {
			while (*clp != '\n' && *clp != '\0' && *clp != '\r') {
				if (*clp == '\\') {
						switch (*++clp) {
							case '"'  :
							case '\\' : *txp++ = *clp ; break ;
						}
				} else
					*txp++ = *clp ;
				++clp ;
			}
		}
		*txp++ = '\0' ;
		txp = malloc ( (int) (txp - txbuf) ) ;
		if (txp == (char *) 0) {
			fprintf (stderr,
				"Trix : Memoria insuficiente para configuracao !\n") ;
			exit (-1) ;
		}

		if (cip->ci_flg & CI_DON) {
			fprintf (stderr,
				"Trix : Parametro \"%s\" redefinido ...\n", cnbuf) ;
		}

		if (cip->ci_flg & CI_INT) {

			newint = atoi (txbuf) ;
# ifdef DBG
			tmpint = *( (int *) cip->ci_ptr ) ;
			printf ("int  \"%s\" = %d alias %d\n",
					cnbuf, tmpint, newint) ;
# endif /* DBG */
			*( (int *) cip->ci_ptr ) = newint ;

		} else if (cip->ci_flg & CI_LON) {

			newlon = atol (txbuf) ;
# ifdef DBG
			tmplon = *( (long *) cip->ci_ptr ) ;
			printf ("long \"%s\" = (%ld) alias (%ld)\n",
					cnbuf, tmplon, newlon) ;
# endif /* DBG */
			*( (long *) cip->ci_ptr ) = newlon ;

		} else if (cip->ci_flg & CI_TXT) {

			if (cip->ci_flg & CI_COD) {
				newptr = txbuf ;
# ifdef DBG
				tmpint = *( (int *) cip->ci_ptr ) ;
				printf ("code \"%s\" = \"%d\" alias \"%s\"\n",
						cnbuf, tmpint, newptr) ;
# endif /* DBG */
				if (! (cip->ci_flg & CI_ORD)) {
					tcp = (TXTCOD *) cip->ci_opt ; nopt = 0 ;

					while (tcp->tc_txt != VNULL) {
						++tcp ; ++nopt ;
					}

					qsort ( cip->ci_opt , nopt,
							sizeof (TXTCOD), codcmp ) ;

					cip->ci_flg |= CI_ORD ;
				}
				strcpy (tnbuf, newptr) ; tnp = tnbuf ;
				tcp = (TXTCOD *) bsearch (
									(void *) &tctst			 ,
									(void *) cip->ci_opt	 ,
									(size_t) nopt			 ,
									(size_t) sizeof (TXTCOD) ,
									codcmp
								 ) ;
				if (tcp == (TXTCOD *) 0) {
					fprintf (stderr,
						"Trix : Erro no arquivo de configuracao !\n") ;
					fprintf (stderr,
						"-----> codigo \"%s\" desconhecido ...\n",
						tnbuf) ;
					fputs (cflbuf, stderr) ; continue ;
				} else {
					*( (int *) cip->ci_ptr ) = tcp->tc_cod ;
				}
			} else {
				newptr = txbuf ;
# ifdef DBG
				tmpptr = *( (char * *) cip->ci_ptr ) ;
				printf ("text \"%s\" = \"%s\" alias \"%s\"\n",
						cnbuf, tmpptr, newptr) ;
# endif /* DBG */
				strcpy (txp, txbuf) ;
				*( (char * *) cip->ci_ptr ) = txp ;
			}
		}

		cip->ci_flg |= CI_DON ;
	}
	fclose (tfp) ;
}
# ifdef COMMENT
/*
 *		|-------------------------------------------------------|
 *		|	test pgm ...										|
 *		|-------------------------------------------------------|
 */
void main () {

	initxt () ;
	initcfg (cfglst) ;

	printf ("trixpath = (%s)\n",  trixpath) ;
	printf ("editcmd  = (%s)\n",  editcmd) ;
	printf ("shellcmd = (%s)\n",  shellcmd) ;
	printf ("printcmd = (%s)\n",  printcmd) ;
	printf ("maxfiles = (%ld)\n", maxfiles) ;
	printf ("quitconf = (%d)\n",  quitconf) ;
	printf ("xtabsiz  = (%d)\n",  xtabsiz) ;
	printf ("logmeth  = (%d)\n",  logmeth) ;
	printf ("supdir   = (%d)\n",  supdir) ;
}
# endif /* COMMENT */
/*----------------------------------------------------------------------*/
