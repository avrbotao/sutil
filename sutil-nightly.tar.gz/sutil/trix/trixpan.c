/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixpan.c + panoramic (global) pre-processing ...	|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */
# include	<stdio.h>
# include	<string.h>

# include	"trix.h"
# include	"trixstd.h"
# include	"trixext.h"

EXT		int			( * filcmp ) () ;
EXT		DIRDAT * *	wablst ;
/*	 ___________________________________________________________________
 *	|																	|
 *	|	+ ...															|
 *	|___________________________________________________________________|
 */
void trixpan (panflg) int panflg ; {
	REG	FILDAT * *	panfil ;			/* movable ptr 2 gpan->fil		*/
	REG	FILDAT * *	panmfl ;			/* idem , mfl					*/
	REG	FILDAT * *	tmpfil ;
	REG	FILDAT * *	tmpmfl ;
	REG FILDAT *	tfp ;
	REG DIRDAT * *	wabp = wablst ;
	REG DIRDAT * *	wabe = wabp + (int) (TOTDIRS) ;
	REG DIRDAT *	dp ;
	REG long		tmpfix , tmpfik , tmpmfx , tmpmfk , panfix = 0L ;
	REG int			ns , maxns ;

	panfil = gpan->dd_fil ; panmfl = gpan->dd_mfl ; ns = maxns = 0 ;
	for ( ; wabp < wabe ; ++wabp ) {
		dp = *wabp ;

		if (dp->dd_flg & UNREADIR)
			continue ;

		if (panflg & PANFIL) {
			tmpfil = dp->dd_fil ; tmpfik = dp->dd_fik ;
			for ( tmpfix = 0L ; tmpfix < tmpfik ; ++tmpfix, ++panfix ) {
				tfp = *tmpfil++ ; *panfil++ = tfp ;
				tfp->fd_gix = panfix ;
			}
		}

		if (panflg & PANMFL) {
			tmpmfl = dp->dd_mfl ; tmpmfk = dp->dd_mfk ;
			for ( tmpmfx = 0L ; tmpmfx < tmpmfk ; ++tmpmfx ) {
				tfp = *tmpmfl++ ; *panmfl++ = tfp ;
				tfp->fd_mix = tmpmfx ;
				if ( ( ns = strlen (tfp->fd_nam) ) > maxns)
					maxns = ns ;
			}
		}
	}
	if (panflg & PANMFL) {
		gpan->dd_maxlen = maxns ;
		qsort ( (char *)(gpan->dd_mfl), (int)(MATFILS),
				sizeof tfp, filcmp ) ;
	}
}
/************************************************************************/
/*
 * vi:nu ts=4
 */
