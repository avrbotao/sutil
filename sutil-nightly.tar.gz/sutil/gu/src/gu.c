/*
 *	gu	general usage		botao		2015
 */

#define _XOPEN_SOURCE 500
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

# define	DFL_NVAL	32

int allflag = 0;

intmax_t fbyt = 0;
intmax_t dbyt = 0;
intmax_t obyt = 0;
intmax_t tbyt = 0;

intmax_t fcnt = 0;
intmax_t dcnt = 0;
intmax_t ocnt = 0;
intmax_t tcnt = 0;

static int display_info(const char *fpath, const struct stat *sb, int tflag, struct FTW *ftwbuf) {
	char tyc = '\0';
	intmax_t siz = 0;
#if 0
	printf("%-3s %2d %18jd %s %d %s\n",
	       (tflag == FTW_D) ? "d" : (tflag == FTW_DNR) ? "dnr" :
	       (tflag == FTW_DP) ? "dp" : (tflag == FTW_F) ? "f" :
	       (tflag == FTW_NS) ? "ns" : (tflag == FTW_SL) ? "sl" :
	       (tflag == FTW_SLN) ? "sln" : "???",
	       ftwbuf->level, (intmax_t) sb->st_size,
	       fpath, ftwbuf->base, fpath + ftwbuf->base);
#endif
	siz = (intmax_t) sb->st_size;
	if (tflag == FTW_F) {
		tyc = 'f'; ++fcnt; fbyt += siz;
	} else {
		if (tflag == FTW_D) {
			tyc = 'd'; ++dcnt; dbyt += siz;
		} else { /* others */
			tyc = 'o'; ++ocnt; obyt += siz;
		}
	}
	if (allflag) {
		printf("%c %25jd %s\n", tyc, siz, fpath);
	}
	return 0;		/* To tell nftw() to continue */
}

int aflag = 0 ;
int bflag = 0 ;
int cflag = 0 ;
int dflag = 0 ;
int gflag = 0 ;
int hflag = 0 ;
int kflag = 0 ;
int mflag = 0 ;
int nflag = 0 ;
int pflag = 0 ;
int sflag = 0 ;
int tflag = 0 ;
int vflag = 0 ;

int nftw_flags = 0;

int nval = DFL_NVAL ;

char * parm = NULL ;

int main ( int argc , char * * argv ) {
	if (--argc) {
		while (*++argv) {
nxtarg:
			if (**argv == '-') {
				while ( *(++(*argv)) ) {
					switch ( **argv ) {
						case 'a' : ++allflag ; break ;
						case 'b' : ++bflag ; break ;
						case 'c' : ++cflag ; break ;
						case 'd' : ++dflag ; break ;
						case 'g' : ++gflag ; break ;
						case 'h' : ++hflag ; break ;
						case 'k' : ++kflag ; break ;
						case 'm' : ++mflag ; break ;
						case 'n' : ++nflag ; ++argv ;
							if ( *argv == NULL ) {
								nval = DFL_NVAL ; goto eoargs ;
							} else {
								nval = atoi (*argv) ; goto nxtarg ;
							}
						break ;
						case 'p' : ++pflag ; break ;
						case 's' : ++sflag ; break ;
						case 't' : ++tflag ; break ;
						case 'v' : ++vflag ; break ;
						case '?' :
						default  : printf ( "invalid flag '%c'\n", **argv ) ;
					}
				}
			} else {
				printf ("parm %s\n", *argv) ;
				parm = *argv ;
			}
		}
	} else {
		printf ("%s\n", "bare") ;
	}
eoargs:
	if (aflag) { printf ( "flag '%c'\n", 'a' ) ; }
	if (bflag) { printf ( "flag '%c'\n", 'b' ) ; }
	if (cflag) { printf ( "flag '%c'\n", 'c' ) ; }
	if (dflag) { printf ( "flag '%c'\n", 'd' ) ; }
	if (gflag) { printf ( "flag '%c'\n", 'g' ) ; }
	if (hflag) { printf ( "flag '%c'\n", 'h' ) ; }
	if (kflag) { printf ( "flag '%c'\n", 'k' ) ; }
	if (mflag) { printf ( "flag '%c'\n", 'm' ) ; }
	if (nflag) { printf ( "flag '%c' nval %d\n", 'n' , nval ) ; }
	if (pflag) { printf ( "flag '%c'\n", 'p' ) ; }
	if (sflag) { printf ( "flag '%c'\n", 's' ) ; }
	if (tflag) { printf ( "flag '%c'\n", 't' ) ; }
	if (vflag) { printf ( "flag '%c'\n", 'v' ) ; }

	/* nftw_flags = ( FTW_MOUNT | FTW_PHYS ) ; */

	if (dflag) { nftw_flags |= FTW_DEPTH; }
	if (mflag) { nftw_flags |= FTW_MOUNT; }
	if (pflag) { nftw_flags |= FTW_PHYS; }

	if (nftw((parm == NULL) ? "." : parm, display_info, nval, nftw_flags) == -1) {
		perror("nftw");
		exit(EXIT_FAILURE);
	}

	tbyt = fbyt + dbyt + obyt;
	tcnt = fcnt + dcnt + ocnt;

# if 0
	printf("%c %25jd %s\n", ' ', fcnt, "files ");
	printf("%c %25jd %s\n", ' ', dcnt, "dirs  ");
	printf("%c %25jd %s\n", ' ', ocnt, "others");
	printf("%c %25jd %s\n", ' ', tcnt, "total ");

	printf("%c %25jd %s\n", ' ', fbyt, "file  bytes");
	printf("%c %25jd %s\n", ' ', dbyt, "dir   bytes");
	printf("%c %25jd %s\n", ' ', obyt, "other bytes");
	printf("%c %25jd %s\n", ' ', tbyt, "total bytes");
# else
	printf ( "%25jd bytes in %25jd dirs\n"   , dbyt , dcnt ) ;
	printf ( "%25jd bytes in %25jd files\n"  , fbyt , fcnt ) ;
	printf ( "%25jd bytes in %25jd others\n" , obyt , ocnt ) ;
	printf ( "%25jd bytes in %25jd totals\n" , tbyt , tcnt ) ;
# endif

	exit(EXIT_SUCCESS);
}
/*
 * vi:nu ts=4
 */
