/*
 *	version.h
 */

# ifndef _VERSION_H_

# define _VERSION_H_

extern const char * gu_program_string ;
extern const char * gu_version_string ;
extern const char * gu_release_string ;
extern const char * gu_relogio_string ;
extern const char * gu_summary_string ;
extern const char * gu_taglist_string ;
extern const char * gu_license_string ;
extern const char * gu_creator_string ;
extern const char * gu_contact_string ;
extern const char * gu_builder_string ;
extern const char * gu_compile_string ;

	/*  legacy  */

# define	SWNAME		gu_program_string
# define	SWVERS		gu_version_string
# define	SWDATE		gu_release_string
# define	SWTIME		gu_relogio_string
# define	SWDESC		gu_summary_string
# define	SWTAGS		gu_taglist_string
# define	SWCOPY		gu_license_string
# define	SWAUTH		gu_creator_string
# define	SWMAIL		gu_contact_string
# define	SWBLDR		gu_builder_string
# define	SWCOMP		gu_compile_string

# define	SWFORG		" " /* deprecated */

# endif /* _VERSION_H_ */

/*
 * vi:nu ts=8
 */
