
char * program_string = "qcy" ;
char * summary_string = "quick cypher" ;
char * version_string = "0.0.28" ;
char * release_string = "2015-03-04" ;
char * waltime_string = "14:20:43" ;
char * taglist_string = "quick,fast,cypher,encription,decription,criptography" ;
char * license_string = "GPLv3" ;
char * creator_string = "alexandre botao" ;
char * contact_string = "alexandre@botao.org" ;

/*
 * vi:nu ts=4
 */
