
# ifndef _BYTESWAP_H_
# define _BYTESWAP_H_

# include "configure.h"
# include "astdint.h"

int isbigend ( ) ;
int islilend ( ) ;

uint64_t swap_uint64 ( uint64_t ) ;

# ifndef __GNUC__
/* FIXME: configure to check for inline */
# define inline
# endif /* ! __GNUC__ */

# endif /* _BYTESWAP_H_ */

/*
 * vi:nu ts=4
 */
