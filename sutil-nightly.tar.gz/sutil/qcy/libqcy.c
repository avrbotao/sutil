
# include "configure.h"

# include "libxd6.h"
# include "libqcy.h"

int keylen8 = KEYLENQ ;

uint64_t qcykey [KEYLENQ] ;

unsigned char * qcybuf = NULL ;

void qcymask ( passtxt ) char * passtxt ; {

# if defined (QCYBIG) || defined (BUG)
	int i ;
# endif

	unsigned char * digp ;

	digp = MDString ( passtxt ) ;

	memcpy ( qcykey , digp , 16 ) ;
	qcykey[2] = ~qcykey[0] ;
	qcykey[3] = ~qcykey[1] ;

# ifdef QCYBIG
	if ( isbigend () ) {
		for ( i = 0 ; i < keylen8 ; ++i ) {
			qcykey[i] = swap_uint64 ( qcykey[i] ) ;
		}
	}
# endif

# ifdef BUG
	char * digs ;
	digs = MDHex ( digp , 16 ) ;
	for ( i = 0 ; i < keylen8 ; ++i ) {
		printf ( "key[%d]=<%016llx> " , i , (long long) qcykey[i] ) ;
	}
	printf ( "pass=<%s> hex=<%32s> \n" , passtxt, digs ) ;
# endif /* BUG */

}

void qcymem ( buf , siz ) unsigned char buf [ ] ; size_t siz ; {
	register size_t i ;
	register size_t n ;
	register unsigned char * kp ;
	register uint64_t * bp ;

	if ( siz % UINT64SIZE ) {
		for ( i = 0 , kp = (unsigned char *) qcykey ; i < siz ; ++i ) {
			buf [i] ^= kp [i % KEYLENB] ;
		}
	} else {
		for ( n = siz / UINT64SIZE , i = 0 , bp = (uint64_t *) buf ; i < n ; ++i ) {
			bp [i] ^= qcykey [i % KEYLENQ] ;
		}
	}
}

void qcyfile ( srcname , dstname , passtxt ) char * srcname , * dstname , * passtxt ; {

	FILE * sfp , * dfp ;
	off_t qcyoff ;
	size_t got ;
	size_t wot ;

	if ( qcybuf == NULL ) {
		qcybuf = (unsigned char *) malloc ( QCYBUFSIZ ) ;
		if ( qcybuf == NULL ) {
			fprintf ( stderr , "malloc (%s) failed\n" , "io buffer" ) ;
			return ;
		}
	}

	if ( srcname == NULL )
		sfp = stdin ;
	else
		sfp = fopen ( srcname , "rb" ) ;

	if ( sfp == NULL ) {
		fprintf ( stderr , "open (%s) failed\n" , srcname ) ;
		return ;
	}

	if ( dstname == NULL )
		dfp = stdout ;
	else
		dfp = fopen ( dstname , "wb" ) ;

	if ( dfp == NULL ) {
		fprintf ( stderr , "open (%s) failed\n" , dstname ) ;
		if ( sfp != stdin ) {
			fclose ( sfp ) ;
		}
		return ;
	}

	qcymask ( passtxt ) ;

	for ( qcyoff = 0 ; ! feof ( sfp ) ; qcyoff += got ) {
		got = fread ( qcybuf , 1 , QCYBUFSIZ , sfp ) ;
		if ( ferror ( sfp ) ) {
			fprintf ( stderr , "fread (%d@%lld) failed\n" , QCYBUFSIZ , (long long) qcyoff ) ;
			break ;
		}
		qcymem ( qcybuf , got ) ;
		wot = fwrite ( qcybuf , 1 , got , dfp ) ;
		if ( ferror ( dfp ) || wot != got ) {
			fprintf ( stderr , "fwrite (%d@%lld) failed\n" , (int) got , (long long) qcyoff ) ;
			break ;
		}
	}

	if ( sfp != stdin )
		fclose ( sfp ) ;

	if ( dfp != stdout )
		fclose ( dfp ) ;
}

/*
 * vi:nu ts=4
 */
