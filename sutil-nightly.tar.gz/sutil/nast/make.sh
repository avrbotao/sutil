cc -DNASRV -o snast nast.c
cc -DNACLI -o cnast nast.c
