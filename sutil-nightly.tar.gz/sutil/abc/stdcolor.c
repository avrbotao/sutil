
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDIO
# define	USE_FCNTL

# define	USE_STDSTR
# define	USE_STDVIF
# define	USE_STDTERM
# define	USE_STDCOLOR
# define	USE_STDLOGIC

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

							/*		a n s i		v r a m			*/
char * _colornames [] = {	/*		i b g r		i b g r			*/

	"BLACK",				/*	 0	0 0 0 0		0 0 0 0		 0	*/
	"RED",  				/*	 1	0 0 0 1		0 1 0 0		 4	*/
	"GREEN",				/*	 2	0 0 1 0		0 0 1 0		 2	*/
	"BROWN",				/*	 3	0 0 1 1		0 1 1 0		 6	*/
	"BLUE", 				/*	 4	0 1 0 0		0 0 0 1		 1	*/
	"MAGENTA",				/*	 5	0 1 0 1		0 1 0 1		 5	*/
	"CYAN", 				/*	 6	0 1 1 0		0 0 1 1		 3	*/
	"LIGHTGRAY",			/*	 7	0 1 1 1		0 1 1 1		 7	*/
	"GRAY", 				/*	 8	1 0 0 0		1 0 0 0		 8	*/
	"LIGHTRED",  			/*	 9	1 0 0 1		1 1 0 0		12	*/
	"LIGHTGREEN",			/*	10	1 0 1 0		1 0 1 0		10	*/
	"YELLOW",				/*	11	1 0 1 1		1 1 1 0		14	*/
	"LIGHTBLUE", 			/*	12	1 1 0 0		1 0 0 1		 9	*/
	"LIGHTMAGENTA",			/*	13	1 1 0 1		1 1 0 1		13	*/
	"LIGHTCYAN", 			/*	14	1 1 1 0		1 0 1 1		11	*/
	"WHITE",				/*	15	1 1 1 1		1 1 1 1		15	*/

	NULL
} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int		_ansicolors [] = {  0,  1,  2,  3,  4,  5,  6,  7,
							8,  9, 10, 11, 12, 13, 14, 15  } ;

int		_vramcolors [] = {  0,  4,  2,  6,  1,  5,  3,  7,
							8, 12, 10, 14,  9, 13, 11, 15  } ;

int *	_colorbits = _ansicolors ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void initcolor (int ntfg, int ntbg, int rvfg, int rvbg) {

	if (monochrome) {
		forenorm = _WHITE ;
		backnorm = _BLACK ;
		forerev  = _BLACK ;
		backrev  = _WHITE ;
	} else if (monopaper) {
		forenorm = _BLACK ;
		backnorm = _WHITE ;
		forerev  = _WHITE ;
		backrev  = _BLACK ;
	} else {
		forenorm = ntfg ;
		backnorm = ntbg ;
		forerev  = rvfg ;
		backrev  = rvbg ;
	}

	colorvideo ( forenorm , backnorm ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void endcolor () {

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void termcolor (int fore, int back) {

	if ( ! colorok )
		return ;

	switch (colortype) {
		case CT_ANSI	: ansicolor (fore, back) ;		break ;
		case CT_XENIX	: xenixcolor (fore, back) ;		break ;
		default			: ansicolor (fore, back) ;		break ;
	}

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void ansicolor (int fore, int back) {

	char tmpbuf [40] ;

# ifdef ORIGCODE

	if ( (fore & 0x0f) < 8 )
		sprintf (tmpbuf, "\033[%dm", 30 + (fore & 0x07)) ;
	else
		sprintf (tmpbuf, "\033[%d;1m", 30 + (fore & 0x07)) ;

	strout (tmpbuf, 0) ;

	if ( (back & 0x0f) < 8 )
		sprintf (tmpbuf, "\033[%dm", 40 + (back & 0x07)) ;
	else
		sprintf (tmpbuf, "\033[%d;1m", 40 + (back & 0x07)) ;

# else

	sprintf (tmpbuf, "\033[3%d;4%dm", (fore & 0x07), (back & 0x07)) ;

# endif

	strout (tmpbuf, 0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xenixcolor (int fore, int back) {

	char tmpbuf [40] ;

	sprintf (tmpbuf, "\033[=%dF", fore & 0x0f) ;
	strout (tmpbuf, 0) ;

	sprintf (tmpbuf, "\033[=%dG", back & 0x0f) ;
	strout (tmpbuf, 0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int colorcode (cn) char * cn ; {

	int res = -1 ;
	int x ;

	for ( x = 0 ; x < TOTCOLORS ; ++x ) {
		if ( stricmp (cn, _colornames[x]) == 0 ) {
			res = _COLOR ( x ) ;
			break ;
		}
	}

	return res ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int checkcolor (cn) char * cn ; {

	if ( colorcode (cn) == -1 )
		return FALSE ;

	return TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef COMMENT

LS_COLORS='no=00:fi=00:di=01;34:ln=01;36:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arj=01;31:*.taz=01;31:*.lzh=01;31:*.zip=01;31:*.z=01;31:*.Z=01;31:*.gz=01;31:*.bz2=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.jpg=01;35:*.jpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.mpg=01;35:*.mpeg=01;35:*.avi=01;35:*.fli=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.ogg=01;35:*.mp3=01;35:*.wav=01;35:*.bat=01;32:*.cmd=01;32:*.h=00;35:*.txt=00;36:*.xar=00;31:*.xgz=00;31:*.xbz=00;31:*.cfg=00;32:*.c=00;33:*.cpp=00;32:*.java=01;33:*.hpp=33;44:*.lst=30;46:*.conf=36;44:*.schema=34;46:*.exe=01;32:*.bsh=01;32:*.sh=01;32:*.pl=01;32'

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:tabstop=4
 */

