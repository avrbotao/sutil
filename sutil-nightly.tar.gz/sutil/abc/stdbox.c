
/*		 _______________________________________________________________
 *		|																|
 *		|	stdbox.c						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# define	USE_SYSTYPES
# define	USE_STDIO

# define	USE_STDSTR
# define	USE_STDASC
# define	USE_STDBOX
# define	USE_STDVIF
# define	USE_STDWIN
# define	USE_STDCMD
# define	USE_STDTYP
# define	USE_STRLIST
# define	USE_STDMISC
# define	USE_STDLOGIC

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef WIN32
#	define DOS
# endif

# ifdef DOS

char box_ul = SUL ;
char box_ur = SUR ;
char box_ll = SLL ;
char box_lr = SLR ;
char box_ut = SUT ;
char box_dt = SDT ;
char box_lt = SLT ;
char box_rt = SRT ;
char box_xt = SXT ;
char box_vl = SVL ;
char box_hl = SHL ;

# else  /* ANYX */

char box_ul = TUL ;
char box_ur = TUR ;
char box_ll = TLL ;
char box_lr = TLR ;
char box_ut = TUT ;
char box_dt = TDT ;
char box_lt = TLT ;
char box_rt = TRT ;
char box_xt = TXT ;
char box_vl = TVL ;
char box_hl = THL ;

# endif /* DOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int initbox () {

# ifdef ANYX

	extern char * asbuf , * aebuf , * acbuf ;

	/* check "as" , "ae" , "ac" */

	if ( asbuf == NULL || aebuf == NULL || acbuf == NULL )
		return 0 ;

	/* fill box_chars */

	loadbox (&box_ul, XUL) ;
	loadbox (&box_ur, XUR) ;
	loadbox (&box_ll, XLL) ;
	loadbox (&box_lr, XLR) ;
	loadbox (&box_ut, XUT) ;
	loadbox (&box_dt, XDT) ;
	loadbox (&box_lt, XLT) ;
	loadbox (&box_rt, XRT) ;
	loadbox (&box_xt, XXT) ;
	loadbox (&box_vl, XVL) ;
	loadbox (&box_hl, XHL) ;

# endif

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef ANYX

void loadbox (bcp, bix) int bix ; char * bcp ; {

	extern char * acbuf ;
	register char * acp ;

	acp = strchr ( acbuf , bix ) ;

	if ( acp != NULL )
		*bcp = *(acp+1) ;
}

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int getbox (tit, lin, col, buf, siz, wid) int lin, col, siz, wid ; char * tit , * buf ; {

	WINDES * twp ;
	int rd ;

	twp = wopen (lin, col, 3, wid+4) ;
	wclear () ;
	wbox (tit) ;

	rd = gled (lin+1, col+2, buf, siz, wid) ;

	wclose (twp) ;
	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void border (int inilin, int inicol, int width, int height) {

	register char * tp ;
	register int j ;
	char tb [4096] ;

	width -= 2 ;
	height -= 2 ;

/* top border */

	tp = tb ;
	*tp++ = box_ul ;

	for ( j = width ; j ; j-- )
		*tp++ = box_hl ;

	*tp++ = box_ur ;
	*tp = NUL ;

	cursorat (inilin, inicol) ;
	strout (tb, 0) ;

/* side borders */

	tp = tb ;
	*tp++ = box_vl ;
	*tp = NUL ;

	for ( j = 1 ; j <= height ; ++j ) {
		cursorat (inilin+j, inicol) ;
		strout (tb, 0) ;
		cursorat (inilin+j, inicol+width+1) ;
		strout (tb, 0) ;
	}

/* bottom border */

	tp = tb ;
	*tp++ = box_ll ;

	for ( j = width ; j ; j-- )
		*tp++ = box_hl ;

	*tp++ = box_lr ;
	*tp = NUL ;

	cursorat (inilin+height+1, inicol) ;
	strout (tb, 0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	ECHOPTR(X)		strout (X, 1)
# define	ECHOVAL(X)		ec = X ; strout (&ec, 1)

int gled (inilin, inicol, txtbuf, bufsiz, winsiz) char * txtbuf ; int inilin, inicol, bufsiz, winsiz ; {

	REG	char *	tp ;
	REG	char *	bp ;
	REG	int		txtlen ;
	REG	int		txtcol ;
	REG	int		key, y ;
	REG	int		leftoff = 0 ;
	REG	int		redisp = FALSE ;
	REG	int		retval = 0 ;
	REG int		templistflag ;
				char	ec ;
	static		int		insert = TRUE ;

top:

	bp = txtbuf ;

	if ( *bp != NUL ) {
		txtcol = txtlen = strlen (txtbuf) ;
	} else {
		txtcol = txtlen = 0 ;
	}

	bp += txtcol ;

	if (txtcol >= winsiz) {
		leftoff = txtcol - winsiz + 1 ;
		txtcol = winsiz - 1 ;
	}

	memset (txtbuf+txtlen, NUL, bufsiz-txtlen) ;
	redisp = TRUE ;

	for ( EVER ) {

		if (redisp) {
			cursorat (inilin, inicol) ;
			reversevideo () ;
			strout ( strpad (txtbuf+leftoff, winsiz, SPC) , winsiz ) ;
			redisp = FALSE ;
		}

		cursorat (inilin, inicol+txtcol) ;
		key = readcmd () ;

		if (key == XC_NEWLINE) {
			if ( txtlen > 0 /* && ( currstrlist () != NULL ) */ ) {
				feedstrlist (txtbuf) ;
			}
			break ;
		}

		if (key == XC_HELP) {
								/* activate a helping hand ... */
			continue ;
		}

		if (key == XC_ESC) {

			if (txtlen == 0) {
				retval = ESC ;
				break ;
			}

			memset (txtbuf, NUL, bufsiz) ;
			leftoff = 0 ;
			goto top ;

		} else if (key == XC_HOMELINE) {

			txtcol = leftoff = 0 ;
			bp = txtbuf ;
			redisp = TRUE ;

		} else if (key == XC_ENDOFLINE) {

			txtcol = txtlen ;
			bp = txtbuf + txtlen ;

			if (txtcol >= winsiz) {
				leftoff = txtcol - winsiz + 1 ;
				txtcol = winsiz - 1 ;
				redisp = TRUE ;
			}

		} else if (key == XC_MOVERIGHT) {

			if (bp < txtbuf + txtlen) {
				++bp ;
				if (txtcol < winsiz - 1) {
					++txtcol ;
				} else {
					++leftoff ;
					redisp = TRUE ;
				}
			}

		} else if (key == XC_MOVELEFT) {

			if (bp > txtbuf) {
				--bp ;
				if (txtcol > 0) {
					--txtcol ;
				} else {
					if ( leftoff > 0 ) {
						--leftoff ;
						redisp = TRUE ;
					}
				}
			}

		} else if (key == XC_VIEWDIR) {				/*	F3	*/

# ifdef OLD
			tp = dirpick (".") ;	/* simple */
# else
			tp = dirwalk (NULL) ;
# endif

			if ( tp != NULL ) {

				strcpy (txtbuf, tp) ;
				txtlen = strlen (txtbuf) ;
				feedstrlist (txtbuf) ;

				break ;
			}

		} else if (key == XC_VIEWLIST) {			/*	F4	*/

			templistflag = modestrlist (LM_GET, 0) ;

			if (templistflag & LM_STACK) {
				modestrlist (LM_OFF, LM_STACK) ;
				sortstrlist () ;
			}

			tp = viewstrlist (NULL) ;

			if (templistflag & LM_STACK) {
				modestrlist (LM_ON, LM_STACK) ;
				sortstrlist () ;
			}

			if ( tp != NULL ) {

				strcpy (txtbuf, tp) ;
				txtlen = strlen (txtbuf) ;
				feedstrlist (txtbuf) ;

				break ;
			}

		} else if (key == XC_VIEWSTACK) {			/*	F5	*/

			templistflag = modestrlist (LM_GET, 0) ;

			if ( ! (templistflag & LM_STACK) ) {
				modestrlist (LM_ON, LM_STACK) ;
				sortstrlist () ;
			}

			tp = viewstrlist (NULL) ;

			if ( ! (templistflag & LM_STACK) ) {
				modestrlist (LM_OFF, LM_STACK) ;
				sortstrlist () ;
			}

			if ( tp != NULL ) {

				strcpy (txtbuf, tp) ;
				txtlen = strlen (txtbuf) ;
				feedstrlist (txtbuf) ;

				break ;
			}

		} else if (key == XC_MOVEUP) {

			if ( prevstrlist (txtbuf) != NULL )
				goto top ;

		} else if (key == XC_MOVEDOWN) {

			if ( nextstrlist (txtbuf) != NULL )
				goto top ;

		} else if (key == XC_POPINSERT) {

# ifdef LATER
			popinsert () ;
# else  /* BETTER */
			if (insert)
				insert = FALSE ;
			else
				insert = TRUE ;
	/* must reflect insert state somehow (cursor size ?) */
# endif

		} else if (key == XC_DELCHAR) {

			if (*bp != NUL) {
                --txtlen ; goto updeol ;
            }

		} else if (key == XC_BACKSPACE) {

			if (bp > txtbuf) {
				--bp ; --txtcol ; --txtlen ;
				cursorat (inilin, inicol+txtcol) ;
updeol :
				for ( y = txtcol , tp = bp+1 ; *tp ; ++tp )
					*(tp-1) = *tp ;

				redisp = TRUE ;
				*(tp-1) = NUL ;
			}

		} else if (key >= SPC && key <= '~') {

			if (insert) {

				if ( txtlen == (bufsiz - 1) )
					goto oddkey ;

				if (bp >= txtbuf + txtlen)
					goto addkey ;

				for ( tp = bp ; key != NUL ; ++tp ) {
					y = *tp ;
					*tp = key ;
					key = y ;
				}

				++txtlen ; ++bp ;
				*(bp+txtlen) = NUL ;
				redisp = TRUE ;

				if ( txtcol < winsiz - 1 ) {
					++txtcol ;
				} else {
					++leftoff ;
				}

			} else {
addkey :
				ECHOVAL (key) ;
				*bp++ = key ;

				if ( txtcol < winsiz - 1 ) {
					++txtcol ;
				} else {
					++leftoff ;
					redisp = TRUE ;
				}

				if (bp >= txtbuf + txtlen)
					++txtlen ;
			}

		} else {	/* default : ... */
oddkey :
			honk () ;
			continue ;
		}

		if ( (int) (bp - txtbuf) == (bufsiz - 1) )
			goto oddkey ;
	}

	*(bp+txtlen) = NUL ;
	normalvideo () ;
	return retval ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:tabstop=4
 */

