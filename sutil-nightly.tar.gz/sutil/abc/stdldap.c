
/*
 *
 *	  /\		 _______________________________________________
 *	 /  \		|						|
 *	/ OO \		|	stdldap.c	       ldap stuff ...	|
 *	\ \/ /		|	(c) 1998-2003	alexandre v. r. botao	|
 *	 \  /		|_______________________________________________|
 *	  \/
 *
 */

# ifdef LABIX

#	define	USE_STDIO
#	define	USE_STDLDAP

#	include	"abc.h"

# else /* PLAIN */

# include  <stdio.h>

# include  "stdldap.h"

# endif /* LABIX */

/*	--	--	--	--	--	--	--	--	*/
