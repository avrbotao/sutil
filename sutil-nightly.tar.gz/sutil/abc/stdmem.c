
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdmem.c				 memory mgmt & tricks	|
 *		\ \/ /		|	(c) 1998-2004			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define	USE_CTYPE
# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDLOGIC
# define	USE_STDMEM
# define	USE_STDSTR

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long		_reqmem = 0L ;			/* requested memory bytes			*/
long		_taxmem = 0L ;			/* used control memory bytes		*/
long		_topmem = 0L ;			/* maximum memory bytes				*/
long		_fremem = 0L ;			/* available memory bytes			*/

long		_malcnt = 0L ;			/* xmalloc()'s						*/
long		_calcnt = 0L ;			/* xmcalloc()'s						*/
long		_reacnt = 0L ;			/* xmrealloc()'s					*/
long		_frecnt = 0L ;			/* xmfree()'s						*/

unsigned	_totmem = 0 ;			/* items on memory control area		*/
unsigned	_inxmem = 0 ;			/* index to memory control area		*/
unsigned	_reumem = 0 ;			/* reusable (freed) entries			*/

MEMCTL *	_ctlmem = NULL ;		/* memory control area				*/

MEMINFO		_xmib ;					/* memory information buffer		*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	MC_BUFCNT			512 /* 1024 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int xminit () {

	register MEMCTL * tmp ;

	if ( _ctlmem != NULL )
		return -1 ;

	tmp = ( MEMCTL * ) calloc ( MC_BUFCNT , MEMCTLSIZ ) ;

	if ( tmp == NULL )
		return -1 ;

	if ( _topmem == 0L )
		xmlimit ( -1L ) ;

	_ctlmem = tmp ;
	_totmem = MC_BUFCNT ;
	_taxmem = MC_BUFCNT * MEMCTLSIZ ;
	_fremem = _topmem - _taxmem ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int xmgrow () {

	register MEMCTL * tmp ;
	register unsigned newsiz ;

	if ( _ctlmem == NULL )
		return -1 ;

	newsiz = ( _totmem + MC_BUFCNT ) * MEMCTLSIZ ;

	tmp = ( MEMCTL * ) realloc ( (char *) _ctlmem , newsiz ) ;

	if ( tmp == NULL )
		return -1 ;

	_ctlmem = tmp ;

	memset ( (char *) _ctlmem + ( _totmem * MEMCTLSIZ ) , 0x00 , MC_BUFCNT * MEMCTLSIZ ) ;

	_totmem += MC_BUFCNT ;
	_taxmem += MC_BUFCNT * MEMCTLSIZ ;
	_fremem -= MC_BUFCNT * MEMCTLSIZ ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int xmfree ( ptr ) char * ptr ; {

	register MEMCTL * tmp ;

	if ( ( tmp = xmfind ( ptr ) ) == NULL )
		return -1 ;

	free ( ptr ) ;

	_fremem += tmp->mc_siz ;
	_reqmem -= tmp->mc_siz ;
	_reumem++ ;

	tmp->mc_siz = 0 ;
	tmp->mc_ptr = NULL ;

	_frecnt++ ;
	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xmalloc ( size ) unsigned size ; {

	register MEMCTL * tmp ;
	register char * ptr ;

	if ( size == 0 )
		return NULL ;

	if ( ( ptr = malloc ( size ) ) == NULL )
		return NULL ;

	if ( _ctlmem == NULL )
		xminit () ;

	if ( _reumem > 0 ) {

		if ( ( tmp = xmfind ( NULL ) ) == NULL ) {	/* THIS SHOULD		*/
			free ( ptr ) ;
			return NULL ;							/* NEVER HAPPEN !!! */
		} else {
			_reumem-- ;
			_inxmem-- ;
		}

	} else {

		if ( _inxmem >= _totmem )
			if ( xmgrow () != 0 ) {
				free ( ptr ) ;
				return NULL ;
			}

		tmp = _ctlmem + _inxmem ;
	}

	tmp->mc_ptr = ptr ;
	tmp->mc_siz = size ;

	_reqmem += size ;
	_fremem -= size ;
	_inxmem++ ;

	_malcnt++ ;
	return ptr ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xmcalloc ( nelem , elsize ) unsigned nelem , elsize ; {

	register unsigned size = nelem * elsize ;
	register char * ptr = xmalloc ( size ) ;

	if ( ptr == NULL )
		return NULL ;

	memset ( ptr , 0x00 , size ) ;
	_calcnt++ ;
	return ptr ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xmrealloc ( ptr , size ) char * ptr ; unsigned size ; {

	register char * np ;
	register MEMCTL * tmp ;

	if ( ( tmp = xmfind ( ptr ) ) == NULL )
		return NULL ;

	if ( ptr == NULL )
		return xmalloc ( size ) ;
	else if ( size == 0 ) {
		xmfree ( ptr ) ;
		return NULL ;
	}

	if ( size == tmp->mc_siz )
		return ptr ;

	if ( ( np = xmalloc ( size ) ) == NULL )
		return NULL ;

	memcpy ( np , ptr , size < tmp->mc_siz ? size : tmp->mc_siz ) ;

	xmfree ( ptr ) ;

	_reacnt++ ;
	return np ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long xmused () {

	return _reqmem ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long xmctrl () {

	return _taxmem ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long xmavail () {

	return _fremem ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long xmlimit ( lim ) long lim ; {

	if ( lim == -1L )
		return _topmem = memlimit () ;

	if ( lim == -2L )
		return memlimit () ;

	if ( lim == 0L )
		return _topmem ;

	return _topmem = lim ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

MEMINFO * xminfo () {

	_xmib.mi_req = _reqmem ;
	_xmib.mi_tax = _taxmem ;
	_xmib.mi_top = _topmem ;
	_xmib.mi_fre = _fremem ;

	_xmib.mi_tot = _totmem ;
	_xmib.mi_cnt = _inxmem - _reumem ;
	_xmib.mi_reu = _reumem ;

	_xmib.mi_kma = _malcnt ;
	_xmib.mi_kca = _calcnt ;
	_xmib.mi_kre = _reacnt ;
	_xmib.mi_kfr = _frecnt ;

	return & _xmib ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xmdump ( title ) char * title ; {

	MEMINFO * mip = xminfo () ;

	fprintf (stderr, "\r\n xmdump start ...... %s \r\n", title) ;

	fprintf (stderr, " requested bytes ... %12ld \r\n", mip->mi_req) ;
	fprintf (stderr, " imposed bytes ..... %12ld \r\n", mip->mi_tax) ;
	fprintf (stderr, " maximum bytes ..... %12ld \r\n", mip->mi_top) ;
	fprintf (stderr, " free bytes ........ %12ld \r\n", mip->mi_fre) ;

	fprintf (stderr, " total entries ..... %12u \r\n",  mip->mi_tot) ;
	fprintf (stderr, " active entries .... %12u \r\n",  mip->mi_cnt) ;
	fprintf (stderr, " freed entries ..... %12u \r\n",  mip->mi_reu) ;

	fprintf (stderr, " # of malloc's ..... %12ld \r\n", mip->mi_kma) ;
	fprintf (stderr, " # of calloc's ..... %12ld \r\n", mip->mi_kca) ;
	fprintf (stderr, " # of realloc's .... %12ld \r\n", mip->mi_kre) ;
	fprintf (stderr, " # of free's ....... %12ld \r\n", mip->mi_kma) ;

	fprintf (stderr, " xmdump end ........ %s \r\n", title) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

MEMCTL * xmfind ( ptr ) char * ptr ; {

	register MEMCTL * tmp = _ctlmem ;
	register unsigned int j ;
	register int found = FALSE ;

	if ( tmp == NULL )
		return NULL ;

	for ( j = 0 ; j < _inxmem ; ++j , ++tmp )
		if ( tmp->mc_ptr == ptr ) {
			found = TRUE ;
			break ;
		}

	if ( found )
		return tmp ;

	return NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long memlimit () {

# ifdef DOS
	return coreleft () ;
# endif

# ifdef WIN32

	MEMORYSTATUS memstabuf ;

	GlobalMemoryStatus (&memstabuf) ;

	return memstabuf.dwAvailVirtual ;

# endif

# ifdef ANYX

#	ifdef RLIMIT_DATA

	static unsigned long rdcur = 0L ;
	static unsigned long rdmax = 0L ;
	int res ;
	struct rlimit rlb ;

	res   = getrlimit ( RLIMIT_DATA , & rlb ) ;
	rdcur = rlb.rlim_cur ;
	rdmax = rlb.rlim_max ;
	
	return ( res ? (long) res : (long) rdmax ? (long) rdmax : (long) rdcur ) ;

#	else

	return ulimit ( GETRAMLIM ) ;

#	endif

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long memleft () {
	register char * tp /* , * wp */ ;
	register unsigned kshift , kcount , bcount ;
	register long lastok ;
	register long totleft = 0L ;
	register int pinx = 0 ;
	char * pvec [32] ;

	for ( ; ; ) {
		lastok = 0L ;
		for ( kshift = 1 ; kshift < 31 ; ++kshift ) {
			kcount = 1 << kshift ;
			bcount = kcount << 10 ;
			tp = (char *) malloc (bcount) ;
			if (tp == NULL) {
				break ;
			} else {
				lastok = bcount ;
				free (tp) ;
			}
		}
		if (lastok == 0L)
			break ;
		pvec[pinx++] = (char *) malloc ( (unsigned) lastok ) ;
		totleft += lastok ;
	}
	while (--pinx >= 0)
		free (pvec[pinx]) ;
	return totleft ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef NOMEMICMP

int memicmp (a, b, n) char * a , * b ; int n ; {

	register char * pa = a , * pb = b ;
	register int x ;

	while (n--) {
		x = toupper ((int) *pa) - toupper ((int) *pb) ;
		if (x)
			return x ;
		++pa ; ++pb ;
	}

	return 0 ;
}

# endif /* NOMEMICMP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef COMMENT

# include <windows.h>

# define DIV 1024 /* 1048576 */

char * divisor = "K" ; /* "M" */

#define WIDTH 7

void main (int argc, char *argv[]) {

	MEMORYSTATUS memstabuf ;

	GlobalMemoryStatus (&memstabuf) ;

	printf ("MemoryStatus %ld bytes \n", memstabuf.dwLength) ;
	printf ("It should be %d \n", sizeof (memstabuf)) ;
	printf ("%ld %% of memory in use \n", memstabuf.dwMemoryLoad) ;
	printf ("%*ld total %sB phys mem    \n", WIDTH, memstabuf.dwTotalPhys/DIV, divisor) ;
	printf ("%*ld free  %sB phys mem    \n", WIDTH, memstabuf.dwAvailPhys/DIV, divisor) ;
	printf ("%*ld total %sB paging file \n", WIDTH, memstabuf.dwTotalPageFile/DIV, divisor) ;
	printf ("%*ld free  %sB paging file \n", WIDTH, memstabuf.dwAvailPageFile/DIV, divisor) ;
	printf ("%*lx total %sB virtual mem \n", WIDTH, memstabuf.dwTotalVirtual/DIV, divisor) ;
	printf ("%*lx free  %sB virtual mem \n", WIDTH, memstabuf.dwAvailVirtual/DIV, divisor) ;
}

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu ts=4
 */
