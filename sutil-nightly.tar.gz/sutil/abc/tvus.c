
# include <stdio.h>

# include "tvus.h"

long long diftod (tvp1, tvp2) struct timeval * tvp1, * tvp2 ; {

# ifdef ORIG
	long long sec1, sec2, usec1, usec2, d ;

	sec1 = tvp1->tv_sec ;
	sec2 = tvp2->tv_sec ;
	usec1 = tvp1->tv_usec ;
	usec2 = tvp2->tv_usec ;

	d = (1000000 * (sec2 - sec1)) + (usec2 - usec1) ;

	return d ;
# else
	struct timeval tv3 ;

	tv3.tv_sec = tvp2->tv_sec - tvp1->tv_sec ;
	tv3.tv_usec = tvp2->tv_usec - tvp1->tv_usec ;
	if (tv3.tv_usec < 0) {
		--tv3.tv_sec ;
		tv3.tv_usec += 1000000 ;
	}
	return (long long) ( ( 1000000 * tv3.tv_sec ) + tv3.tv_usec ) ;
# endif

}

char * fmtus (t) long long t ; {

	long long u, s, m, h ;
	static char b [64] ;

	u = t % 1000000 ;
	s = t / 1000000 ;
	m = s / 60 ;
	h = m / 60 ;

	sprintf (b, "%02lld:%02lld:%02lld:%06lld", h, m, s, u) ;

	return b ;
}

