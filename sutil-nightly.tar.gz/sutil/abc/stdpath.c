
/*		 _______________________________________________________________
 *		|																|
 *		|	stdpath.c					(c) 1996-2015 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_SYSTYPES

# define	USE_STDPATH
# define	USE_STDDIR
# define	USE_STDTYP
# define	USE_STDMISC
# define	USE_STDMEM
# define	USE_STDSTR
# define	USE_UNISTD

# include	"abc.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

DIRDES * setpathent (name) char * name ; {

	return OpenPath (name) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * getpathsel (pathdesptr, flags) DIRDES * pathdesptr ; int flags ; {

	register DIRENT * dep ;
	register char * np ;

try :

	if ( ( dep = ReadPath (pathdesptr) ) != NULL ) {
		np = dep->d_name ;

		if ( flags & DS_NODOTDIRS )
			if ( dotdir ( np ) )
				goto try ;

		return np ;
	} else
		return NULL ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * getpathent (pathdesptr) DIRDES * pathdesptr ; {

	register DIRENT * dep ;

try :

	if ( ( dep = ReadPath (pathdesptr) ) != NULL ) {

		if ( dotdir ( dep->d_name ) )
			goto try ;

		return dep->d_name ;
	} else
		return NULL ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int endpathent (pathdesptr) DIRDES * pathdesptr ; {

	return ClosePath (pathdesptr) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

DIRDES * OpenPath (name) char * name ; {

# ifdef DOS

	DIRDES * ddp ;
	int rd ;
	char tb [1024] ;

	/* alloc a DIRDES */

	ddp = (DIRDES *) xmalloc ( sizeof (DIRDES) ) ;

	if ( ddp == NULL )
		return ddp ;

	/* name exists ? is a path ? */

	rd = findfirst (name, &(ddp->ffdat), FA_DIREC) ;

	if (rd != 0) {		/* no */
		xmfree ( (char *) ddp ) ;
		return NULL ;
	}

	sprintf (tb, "%s\\*.*", name) ;

	ddp->pathct = findfirst (tb, &(ddp->ffdat), FA_MASK) ;

	return ddp ;		/* yes */

# endif /* DOS */

# ifdef WIN32

	DIRDES * ddp ;
	long hndl ;
	char tb [1024] ;

	/* alloc a DIRDES */

	ddp = (DIRDES *) xmalloc ( sizeof (DIRDES) ) ;

	if ( ddp == NULL )
		return ddp ;

	/* name exists ? */

	hndl = _findfirsti64 (name, &(ddp->ffdat)) ;

	if ( hndl == -1 ) { /* no */
		xmfree ( (char *) ddp ) ;
		return NULL ;
	}

	/* is a path ? */

	if ( ddp->ffdat.attrib & _A_SUBDIR ) { /* yes */

		/* prep 4 scan */

		sprintf (tb, "%s\\*.*", name) ;

		ddp->pathct = 0 ;
		ddp->hndl = _findfirsti64 (tb, &(ddp->ffdat)) ;

		return ddp ;

	} else { /* no */

		xmfree ( (char *) ddp ) ;
		return NULL ;

	}

# endif /* WIN32 */

# ifdef	ANYX

#	ifdef V7DIR

#	else  /* SYS V DIR */

	return OpenDir (name) ;

#	endif /* V7 DIR */

# endif /* ANYX */

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

DIRENT * ReadPath (pathdesptr) DIRDES * pathdesptr ; {

# ifdef DOS

	int rd ;

	if (pathdesptr->pathct == -1) { /* empty path */

		return NULL ;

	} else {

		if (pathdesptr->pathct == 0) { /* start 4 non-empty */

			pathdesptr->pathct += 1 ;
			return pathdesptr ;

		} else {

			rd = findnext (&(pathdesptr->ffdat)) ;

			if (rd != 0)
				return NULL ;

			pathdesptr->pathct += 1 ;
			return pathdesptr ;

		}

	}

# endif /* DOS */

# ifdef WIN32

	int rd ;

	if (pathdesptr->hndl == -1) { /* empty path */

		return NULL ;

	} else {

		if (pathdesptr->pathct == 0) { /* start 4 non-empty */

			pathdesptr->pathct += 1 ;
			return pathdesptr ;

		} else {

			rd = _findnexti64 (pathdesptr->hndl, &(pathdesptr->ffdat)) ;

			if (rd != 0)
				return NULL ;

			pathdesptr->pathct += 1 ;
			return pathdesptr ;

		}

	}

# endif /* WIN32 */

# ifdef ANYX

#	ifdef V7DIR

#	else  /* SYS V DIR */

	return (DIRENT *) ReadDir (pathdesptr) ;

#	endif /* V7 DIR */

# endif /* ANYX */

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int ClosePath (pathdesptr) DIRDES * pathdesptr ; {

# ifdef DOS

	xmfree ( (char *) pathdesptr ) ;

	return 0 ;

# endif /* DOS */

# ifdef WIN32

	xmfree ( (char *) pathdesptr ) ;

	return 0 ;

# endif /* WIN32 */

# ifdef ANYX

#	ifdef V7DIR

#	else  /* SYS V DIR */

	return CloseDir (pathdesptr) ;

#	endif /* V7 DIR */

# endif /* ANYX */

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef DOS
# include	<io.h>
# endif

char makpthdirnam [1024] ;

int makepath (nam) char * nam ; {

	register char * np ;
	register char * dp ;
	register char * ep ;

	if ( (ep = strrchr (nam, DIRSEP)) == NULL )
		return 0 ;

	if ( strcmp (nam, "/") == 0 )
		return 0 ;

	np = nam ;
	dp = makpthdirnam ;

	if ( *np == DIRSEP )
		*dp++ = *np++ ;

	for ( ; ; ) {

		while (np != ep && *np != DIRSEP)
			*dp++ = *np++ ;

		*dp = '\0' ;

		if ( access (makpthdirnam, 0) == -1 ) {
			if ( makedir (makpthdirnam) < 0 ) {
				return -1 /* xalert(...) */ ;
			}
		}

		if (np == ep)
			return 0 ;
		else
			*dp++ = *np++ ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

/*
 * vi:nu tabstop=4
 */
