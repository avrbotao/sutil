
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdhash.c						hashing stuff	|
 *		\ \/ /		|	(c) 2000				alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define MD5C

# ifdef LABIX

#	define	USE_STDIO
#	define	USE_STDHASH
#	include	"abc.h"

# else /* PLAIN */

# include  <stdio.h>
# include  "stdhash.h"

# endif /* LABIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef RMD160A

/********************************************************************\
 *
 *      FILE:     rmd160.c
 *
 *      CONTENTS: A sample C-implementation of the RIPEMD-160
 *                hash-function.
 *      TARGET:   any computer with an ANSI C compiler
 *
 *      AUTHOR:   Antoon Bosselaers, ESAT-COSIC
 *      DATE:     1 March 1996
 *      VERSION:  1.0
 *
 *      Copyright (c) Katholieke Universiteit Leuven
 *      1996, All Rights Reserved
 *
 *  Conditions for use of the RIPEMD-160 Software
 *
 *  The RIPEMD-160 software is freely available for use under the terms and
 *  conditions described hereunder, which shall be deemed to be accepted by
 *  any user of the software and applicable on any use of the software:
 * 
 *  1. K.U.Leuven Department of Electrical Engineering-ESAT/COSIC shall for
 *     all purposes be considered the owner of the RIPEMD-160 software and of
 *     all copyright, trade secret, patent or other intellectual property
 *     rights therein.
 *  2. The RIPEMD-160 software is provided on an "as is" basis without
 *     warranty of any sort, express or implied. K.U.Leuven makes no
 *     representation that the use of the software will not infringe any
 *     patent or proprietary right of third parties. User will indemnify
 *     K.U.Leuven and hold K.U.Leuven harmless from any claims or liabilities
 *     which may arise as a result of its use of the software. In no
 *     circumstances K.U.Leuven R&D will be held liable for any deficiency,
 *     fault or other mishappening with regard to the use or performance of
 *     the software.
 *  3. User agrees to give due credit to K.U.Leuven in scientific publications 
 *     or communications in relation with the use of the RIPEMD-160 software 
 *     as follows: RIPEMD-160 software written by Antoon Bosselaers, 
 *     available at http://www.esat.kuleuven.ac.be/~cosicart/ps/AB-9601/.
 *
\********************************************************************/

/*  header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rmd160.h"      

/********************************************************************/

void MDinit(dword *MDbuf)
{
   MDbuf[0] = 0x67452301UL;
   MDbuf[1] = 0xefcdab89UL;
   MDbuf[2] = 0x98badcfeUL;
   MDbuf[3] = 0x10325476UL;
   MDbuf[4] = 0xc3d2e1f0UL;

   return;
}

/********************************************************************/

void compress(dword *MDbuf, dword *X)
{
   dword aa = MDbuf[0],  bb = MDbuf[1],  cc = MDbuf[2],
         dd = MDbuf[3],  ee = MDbuf[4];
   dword aaa = MDbuf[0], bbb = MDbuf[1], ccc = MDbuf[2],
         ddd = MDbuf[3], eee = MDbuf[4];

   /* round 1 */
   FF(aa, bb, cc, dd, ee, X[ 0], 11);
   FF(ee, aa, bb, cc, dd, X[ 1], 14);
   FF(dd, ee, aa, bb, cc, X[ 2], 15);
   FF(cc, dd, ee, aa, bb, X[ 3], 12);
   FF(bb, cc, dd, ee, aa, X[ 4],  5);
   FF(aa, bb, cc, dd, ee, X[ 5],  8);
   FF(ee, aa, bb, cc, dd, X[ 6],  7);
   FF(dd, ee, aa, bb, cc, X[ 7],  9);
   FF(cc, dd, ee, aa, bb, X[ 8], 11);
   FF(bb, cc, dd, ee, aa, X[ 9], 13);
   FF(aa, bb, cc, dd, ee, X[10], 14);
   FF(ee, aa, bb, cc, dd, X[11], 15);
   FF(dd, ee, aa, bb, cc, X[12],  6);
   FF(cc, dd, ee, aa, bb, X[13],  7);
   FF(bb, cc, dd, ee, aa, X[14],  9);
   FF(aa, bb, cc, dd, ee, X[15],  8);
                             
   /* round 2 */
   GG(ee, aa, bb, cc, dd, X[ 7],  7);
   GG(dd, ee, aa, bb, cc, X[ 4],  6);
   GG(cc, dd, ee, aa, bb, X[13],  8);
   GG(bb, cc, dd, ee, aa, X[ 1], 13);
   GG(aa, bb, cc, dd, ee, X[10], 11);
   GG(ee, aa, bb, cc, dd, X[ 6],  9);
   GG(dd, ee, aa, bb, cc, X[15],  7);
   GG(cc, dd, ee, aa, bb, X[ 3], 15);
   GG(bb, cc, dd, ee, aa, X[12],  7);
   GG(aa, bb, cc, dd, ee, X[ 0], 12);
   GG(ee, aa, bb, cc, dd, X[ 9], 15);
   GG(dd, ee, aa, bb, cc, X[ 5],  9);
   GG(cc, dd, ee, aa, bb, X[ 2], 11);
   GG(bb, cc, dd, ee, aa, X[14],  7);
   GG(aa, bb, cc, dd, ee, X[11], 13);
   GG(ee, aa, bb, cc, dd, X[ 8], 12);

   /* round 3 */
   HH(dd, ee, aa, bb, cc, X[ 3], 11);
   HH(cc, dd, ee, aa, bb, X[10], 13);
   HH(bb, cc, dd, ee, aa, X[14],  6);
   HH(aa, bb, cc, dd, ee, X[ 4],  7);
   HH(ee, aa, bb, cc, dd, X[ 9], 14);
   HH(dd, ee, aa, bb, cc, X[15],  9);
   HH(cc, dd, ee, aa, bb, X[ 8], 13);
   HH(bb, cc, dd, ee, aa, X[ 1], 15);
   HH(aa, bb, cc, dd, ee, X[ 2], 14);
   HH(ee, aa, bb, cc, dd, X[ 7],  8);
   HH(dd, ee, aa, bb, cc, X[ 0], 13);
   HH(cc, dd, ee, aa, bb, X[ 6],  6);
   HH(bb, cc, dd, ee, aa, X[13],  5);
   HH(aa, bb, cc, dd, ee, X[11], 12);
   HH(ee, aa, bb, cc, dd, X[ 5],  7);
   HH(dd, ee, aa, bb, cc, X[12],  5);

   /* round 4 */
   II(cc, dd, ee, aa, bb, X[ 1], 11);
   II(bb, cc, dd, ee, aa, X[ 9], 12);
   II(aa, bb, cc, dd, ee, X[11], 14);
   II(ee, aa, bb, cc, dd, X[10], 15);
   II(dd, ee, aa, bb, cc, X[ 0], 14);
   II(cc, dd, ee, aa, bb, X[ 8], 15);
   II(bb, cc, dd, ee, aa, X[12],  9);
   II(aa, bb, cc, dd, ee, X[ 4],  8);
   II(ee, aa, bb, cc, dd, X[13],  9);
   II(dd, ee, aa, bb, cc, X[ 3], 14);
   II(cc, dd, ee, aa, bb, X[ 7],  5);
   II(bb, cc, dd, ee, aa, X[15],  6);
   II(aa, bb, cc, dd, ee, X[14],  8);
   II(ee, aa, bb, cc, dd, X[ 5],  6);
   II(dd, ee, aa, bb, cc, X[ 6],  5);
   II(cc, dd, ee, aa, bb, X[ 2], 12);

   /* round 5 */
   JJ(bb, cc, dd, ee, aa, X[ 4],  9);
   JJ(aa, bb, cc, dd, ee, X[ 0], 15);
   JJ(ee, aa, bb, cc, dd, X[ 5],  5);
   JJ(dd, ee, aa, bb, cc, X[ 9], 11);
   JJ(cc, dd, ee, aa, bb, X[ 7],  6);
   JJ(bb, cc, dd, ee, aa, X[12],  8);
   JJ(aa, bb, cc, dd, ee, X[ 2], 13);
   JJ(ee, aa, bb, cc, dd, X[10], 12);
   JJ(dd, ee, aa, bb, cc, X[14],  5);
   JJ(cc, dd, ee, aa, bb, X[ 1], 12);
   JJ(bb, cc, dd, ee, aa, X[ 3], 13);
   JJ(aa, bb, cc, dd, ee, X[ 8], 14);
   JJ(ee, aa, bb, cc, dd, X[11], 11);
   JJ(dd, ee, aa, bb, cc, X[ 6],  8);
   JJ(cc, dd, ee, aa, bb, X[15],  5);
   JJ(bb, cc, dd, ee, aa, X[13],  6);

   /* parallel round 1 */
   JJJ(aaa, bbb, ccc, ddd, eee, X[ 5],  8);
   JJJ(eee, aaa, bbb, ccc, ddd, X[14],  9);
   JJJ(ddd, eee, aaa, bbb, ccc, X[ 7],  9);
   JJJ(ccc, ddd, eee, aaa, bbb, X[ 0], 11);
   JJJ(bbb, ccc, ddd, eee, aaa, X[ 9], 13);
   JJJ(aaa, bbb, ccc, ddd, eee, X[ 2], 15);
   JJJ(eee, aaa, bbb, ccc, ddd, X[11], 15);
   JJJ(ddd, eee, aaa, bbb, ccc, X[ 4],  5);
   JJJ(ccc, ddd, eee, aaa, bbb, X[13],  7);
   JJJ(bbb, ccc, ddd, eee, aaa, X[ 6],  7);
   JJJ(aaa, bbb, ccc, ddd, eee, X[15],  8);
   JJJ(eee, aaa, bbb, ccc, ddd, X[ 8], 11);
   JJJ(ddd, eee, aaa, bbb, ccc, X[ 1], 14);
   JJJ(ccc, ddd, eee, aaa, bbb, X[10], 14);
   JJJ(bbb, ccc, ddd, eee, aaa, X[ 3], 12);
   JJJ(aaa, bbb, ccc, ddd, eee, X[12],  6);

   /* parallel round 2 */
   III(eee, aaa, bbb, ccc, ddd, X[ 6],  9); 
   III(ddd, eee, aaa, bbb, ccc, X[11], 13);
   III(ccc, ddd, eee, aaa, bbb, X[ 3], 15);
   III(bbb, ccc, ddd, eee, aaa, X[ 7],  7);
   III(aaa, bbb, ccc, ddd, eee, X[ 0], 12);
   III(eee, aaa, bbb, ccc, ddd, X[13],  8);
   III(ddd, eee, aaa, bbb, ccc, X[ 5],  9);
   III(ccc, ddd, eee, aaa, bbb, X[10], 11);
   III(bbb, ccc, ddd, eee, aaa, X[14],  7);
   III(aaa, bbb, ccc, ddd, eee, X[15],  7);
   III(eee, aaa, bbb, ccc, ddd, X[ 8], 12);
   III(ddd, eee, aaa, bbb, ccc, X[12],  7);
   III(ccc, ddd, eee, aaa, bbb, X[ 4],  6);
   III(bbb, ccc, ddd, eee, aaa, X[ 9], 15);
   III(aaa, bbb, ccc, ddd, eee, X[ 1], 13);
   III(eee, aaa, bbb, ccc, ddd, X[ 2], 11);

   /* parallel round 3 */
   HHH(ddd, eee, aaa, bbb, ccc, X[15],  9);
   HHH(ccc, ddd, eee, aaa, bbb, X[ 5],  7);
   HHH(bbb, ccc, ddd, eee, aaa, X[ 1], 15);
   HHH(aaa, bbb, ccc, ddd, eee, X[ 3], 11);
   HHH(eee, aaa, bbb, ccc, ddd, X[ 7],  8);
   HHH(ddd, eee, aaa, bbb, ccc, X[14],  6);
   HHH(ccc, ddd, eee, aaa, bbb, X[ 6],  6);
   HHH(bbb, ccc, ddd, eee, aaa, X[ 9], 14);
   HHH(aaa, bbb, ccc, ddd, eee, X[11], 12);
   HHH(eee, aaa, bbb, ccc, ddd, X[ 8], 13);
   HHH(ddd, eee, aaa, bbb, ccc, X[12],  5);
   HHH(ccc, ddd, eee, aaa, bbb, X[ 2], 14);
   HHH(bbb, ccc, ddd, eee, aaa, X[10], 13);
   HHH(aaa, bbb, ccc, ddd, eee, X[ 0], 13);
   HHH(eee, aaa, bbb, ccc, ddd, X[ 4],  7);
   HHH(ddd, eee, aaa, bbb, ccc, X[13],  5);

   /* parallel round 4 */   
   GGG(ccc, ddd, eee, aaa, bbb, X[ 8], 15);
   GGG(bbb, ccc, ddd, eee, aaa, X[ 6],  5);
   GGG(aaa, bbb, ccc, ddd, eee, X[ 4],  8);
   GGG(eee, aaa, bbb, ccc, ddd, X[ 1], 11);
   GGG(ddd, eee, aaa, bbb, ccc, X[ 3], 14);
   GGG(ccc, ddd, eee, aaa, bbb, X[11], 14);
   GGG(bbb, ccc, ddd, eee, aaa, X[15],  6);
   GGG(aaa, bbb, ccc, ddd, eee, X[ 0], 14);
   GGG(eee, aaa, bbb, ccc, ddd, X[ 5],  6);
   GGG(ddd, eee, aaa, bbb, ccc, X[12],  9);
   GGG(ccc, ddd, eee, aaa, bbb, X[ 2], 12);
   GGG(bbb, ccc, ddd, eee, aaa, X[13],  9);
   GGG(aaa, bbb, ccc, ddd, eee, X[ 9], 12);
   GGG(eee, aaa, bbb, ccc, ddd, X[ 7],  5);
   GGG(ddd, eee, aaa, bbb, ccc, X[10], 15);
   GGG(ccc, ddd, eee, aaa, bbb, X[14],  8);

   /* parallel round 5 */
   FFF(bbb, ccc, ddd, eee, aaa, X[12] ,  8);
   FFF(aaa, bbb, ccc, ddd, eee, X[15] ,  5);
   FFF(eee, aaa, bbb, ccc, ddd, X[10] , 12);
   FFF(ddd, eee, aaa, bbb, ccc, X[ 4] ,  9);
   FFF(ccc, ddd, eee, aaa, bbb, X[ 1] , 12);
   FFF(bbb, ccc, ddd, eee, aaa, X[ 5] ,  5);
   FFF(aaa, bbb, ccc, ddd, eee, X[ 8] , 14);
   FFF(eee, aaa, bbb, ccc, ddd, X[ 7] ,  6);
   FFF(ddd, eee, aaa, bbb, ccc, X[ 6] ,  8);
   FFF(ccc, ddd, eee, aaa, bbb, X[ 2] , 13);
   FFF(bbb, ccc, ddd, eee, aaa, X[13] ,  6);
   FFF(aaa, bbb, ccc, ddd, eee, X[14] ,  5);
   FFF(eee, aaa, bbb, ccc, ddd, X[ 0] , 15);
   FFF(ddd, eee, aaa, bbb, ccc, X[ 3] , 13);
   FFF(ccc, ddd, eee, aaa, bbb, X[ 9] , 11);
   FFF(bbb, ccc, ddd, eee, aaa, X[11] , 11);

   /* combine results */
   ddd += cc + MDbuf[1];               /* final result for MDbuf[0] */
   MDbuf[1] = MDbuf[2] + dd + eee;
   MDbuf[2] = MDbuf[3] + ee + aaa;
   MDbuf[3] = MDbuf[4] + aa + bbb;
   MDbuf[4] = MDbuf[0] + bb + ccc;
   MDbuf[0] = ddd;

   return;
}

/********************************************************************/

void MDfinish(dword *MDbuf, byte *strptr, dword lswlen, dword mswlen)
{
   unsigned int i;                                 /* counter       */
   dword        X[16];                             /* message words */

   memset(X, 0, 16*sizeof(dword));

   /* put bytes from strptr into X */
   for (i=0; i<(lswlen&63); i++) {
      /* byte i goes into word X[i div 4] at pos.  8*(i mod 4)  */
      X[i>>2] ^= (dword) *strptr++ << (8 * (i&3));
   }

   /* append the bit m_n == 1 */
   X[(lswlen>>2)&15] ^= (dword)1 << (8*(lswlen&3) + 7);

   if ((lswlen & 63) > 55) {
      /* length goes to next block */
      compress(MDbuf, X);
      memset(X, 0, 16*sizeof(dword));
   }

   /* append length in bits*/
   X[14] = lswlen << 3;
   X[15] = (lswlen >> 29) | (mswlen << 3);
   compress(MDbuf, X);

   return;
}

/************************ end of file rmd160.c **********************/

# endif /* RMD160A */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef RMD128A

/********************************************************************\
 *
 *      FILE:     rmd128.c
 *
 *      CONTENTS: A sample C-implementation of the RIPEMD-128
 *                hash-function. This function is a plug-in substitute 
 *                for RIPEMD. A 160-bit hash result is obtained using
 *                RIPEMD-160.
 *      TARGET:   any computer with an ANSI C compiler
 *
 *      AUTHOR:   Antoon Bosselaers, ESAT-COSIC
 *      DATE:     1 March 1996
 *      VERSION:  1.0
 *
 *      Copyright (c) Katholieke Universiteit Leuven
 *      1996, All Rights Reserved
 *
 *  Conditions for use of the RIPEMD-160 Software
 *
 *  The RIPEMD-160 software is freely available for use under the terms and
 *  conditions described hereunder, which shall be deemed to be accepted by
 *  any user of the software and applicable on any use of the software:
 * 
 *  1. K.U.Leuven Department of Electrical Engineering-ESAT/COSIC shall for
 *     all purposes be considered the owner of the RIPEMD-160 software and of
 *     all copyright, trade secret, patent or other intellectual property
 *     rights therein.
 *  2. The RIPEMD-160 software is provided on an "as is" basis without
 *     warranty of any sort, express or implied. K.U.Leuven makes no
 *     representation that the use of the software will not infringe any
 *     patent or proprietary right of third parties. User will indemnify
 *     K.U.Leuven and hold K.U.Leuven harmless from any claims or liabilities
 *     which may arise as a result of its use of the software. In no
 *     circumstances K.U.Leuven R&D will be held liable for any deficiency,
 *     fault or other mishappening with regard to the use or performance of
 *     the software.
 *  3. User agrees to give due credit to K.U.Leuven in scientific publications 
 *     or communications in relation with the use of the RIPEMD-160 software 
 *     as follows: RIPEMD-160 software written by Antoon Bosselaers, 
 *     available at http://www.esat.kuleuven.ac.be/~cosicart/ps/AB-9601/.
 *
\********************************************************************/

/*  header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rmd128.h"      

/********************************************************************/

void MDinit(dword *MDbuf)
{
   MDbuf[0] = 0x67452301UL;
   MDbuf[1] = 0xefcdab89UL;
   MDbuf[2] = 0x98badcfeUL;
   MDbuf[3] = 0x10325476UL;

   return;
}

/********************************************************************/

void compress(dword *MDbuf, dword *X)
{
   dword aa = MDbuf[0],  bb = MDbuf[1],  cc = MDbuf[2],  dd = MDbuf[3];
   dword aaa = MDbuf[0], bbb = MDbuf[1], ccc = MDbuf[2], ddd = MDbuf[3];

   /* round 1 */
   FF(aa, bb, cc, dd, X[ 0], 11);
   FF(dd, aa, bb, cc, X[ 1], 14);
   FF(cc, dd, aa, bb, X[ 2], 15);
   FF(bb, cc, dd, aa, X[ 3], 12);
   FF(aa, bb, cc, dd, X[ 4],  5);
   FF(dd, aa, bb, cc, X[ 5],  8);
   FF(cc, dd, aa, bb, X[ 6],  7);
   FF(bb, cc, dd, aa, X[ 7],  9);
   FF(aa, bb, cc, dd, X[ 8], 11);
   FF(dd, aa, bb, cc, X[ 9], 13);
   FF(cc, dd, aa, bb, X[10], 14);
   FF(bb, cc, dd, aa, X[11], 15);
   FF(aa, bb, cc, dd, X[12],  6);
   FF(dd, aa, bb, cc, X[13],  7);
   FF(cc, dd, aa, bb, X[14],  9);
   FF(bb, cc, dd, aa, X[15],  8);
                             
   /* round 2 */
   GG(aa, bb, cc, dd, X[ 7],  7);
   GG(dd, aa, bb, cc, X[ 4],  6);
   GG(cc, dd, aa, bb, X[13],  8);
   GG(bb, cc, dd, aa, X[ 1], 13);
   GG(aa, bb, cc, dd, X[10], 11);
   GG(dd, aa, bb, cc, X[ 6],  9);
   GG(cc, dd, aa, bb, X[15],  7);
   GG(bb, cc, dd, aa, X[ 3], 15);
   GG(aa, bb, cc, dd, X[12],  7);
   GG(dd, aa, bb, cc, X[ 0], 12);
   GG(cc, dd, aa, bb, X[ 9], 15);
   GG(bb, cc, dd, aa, X[ 5],  9);
   GG(aa, bb, cc, dd, X[ 2], 11);
   GG(dd, aa, bb, cc, X[14],  7);
   GG(cc, dd, aa, bb, X[11], 13);
   GG(bb, cc, dd, aa, X[ 8], 12);

   /* round 3 */
   HH(aa, bb, cc, dd, X[ 3], 11);
   HH(dd, aa, bb, cc, X[10], 13);
   HH(cc, dd, aa, bb, X[14],  6);
   HH(bb, cc, dd, aa, X[ 4],  7);
   HH(aa, bb, cc, dd, X[ 9], 14);
   HH(dd, aa, bb, cc, X[15],  9);
   HH(cc, dd, aa, bb, X[ 8], 13);
   HH(bb, cc, dd, aa, X[ 1], 15);
   HH(aa, bb, cc, dd, X[ 2], 14);
   HH(dd, aa, bb, cc, X[ 7],  8);
   HH(cc, dd, aa, bb, X[ 0], 13);
   HH(bb, cc, dd, aa, X[ 6],  6);
   HH(aa, bb, cc, dd, X[13],  5);
   HH(dd, aa, bb, cc, X[11], 12);
   HH(cc, dd, aa, bb, X[ 5],  7);
   HH(bb, cc, dd, aa, X[12],  5);

   /* round 4 */
   II(aa, bb, cc, dd, X[ 1], 11);
   II(dd, aa, bb, cc, X[ 9], 12);
   II(cc, dd, aa, bb, X[11], 14);
   II(bb, cc, dd, aa, X[10], 15);
   II(aa, bb, cc, dd, X[ 0], 14);
   II(dd, aa, bb, cc, X[ 8], 15);
   II(cc, dd, aa, bb, X[12],  9);
   II(bb, cc, dd, aa, X[ 4],  8);
   II(aa, bb, cc, dd, X[13],  9);
   II(dd, aa, bb, cc, X[ 3], 14);
   II(cc, dd, aa, bb, X[ 7],  5);
   II(bb, cc, dd, aa, X[15],  6);
   II(aa, bb, cc, dd, X[14],  8);
   II(dd, aa, bb, cc, X[ 5],  6);
   II(cc, dd, aa, bb, X[ 6],  5);
   II(bb, cc, dd, aa, X[ 2], 12);

   /* parallel round 1 */
   III(aaa, bbb, ccc, ddd, X[ 5],  8); 
   III(ddd, aaa, bbb, ccc, X[14],  9);
   III(ccc, ddd, aaa, bbb, X[ 7],  9);
   III(bbb, ccc, ddd, aaa, X[ 0], 11);
   III(aaa, bbb, ccc, ddd, X[ 9], 13);
   III(ddd, aaa, bbb, ccc, X[ 2], 15);
   III(ccc, ddd, aaa, bbb, X[11], 15);
   III(bbb, ccc, ddd, aaa, X[ 4],  5);
   III(aaa, bbb, ccc, ddd, X[13],  7);
   III(ddd, aaa, bbb, ccc, X[ 6],  7);
   III(ccc, ddd, aaa, bbb, X[15],  8);
   III(bbb, ccc, ddd, aaa, X[ 8], 11);
   III(aaa, bbb, ccc, ddd, X[ 1], 14);
   III(ddd, aaa, bbb, ccc, X[10], 14);
   III(ccc, ddd, aaa, bbb, X[ 3], 12);
   III(bbb, ccc, ddd, aaa, X[12],  6);

   /* parallel round 2 */
   HHH(aaa, bbb, ccc, ddd, X[ 6],  9);
   HHH(ddd, aaa, bbb, ccc, X[11], 13);
   HHH(ccc, ddd, aaa, bbb, X[ 3], 15);
   HHH(bbb, ccc, ddd, aaa, X[ 7],  7);
   HHH(aaa, bbb, ccc, ddd, X[ 0], 12);
   HHH(ddd, aaa, bbb, ccc, X[13],  8);
   HHH(ccc, ddd, aaa, bbb, X[ 5],  9);
   HHH(bbb, ccc, ddd, aaa, X[10], 11);
   HHH(aaa, bbb, ccc, ddd, X[14],  7);
   HHH(ddd, aaa, bbb, ccc, X[15],  7);
   HHH(ccc, ddd, aaa, bbb, X[ 8], 12);
   HHH(bbb, ccc, ddd, aaa, X[12],  7);
   HHH(aaa, bbb, ccc, ddd, X[ 4],  6);
   HHH(ddd, aaa, bbb, ccc, X[ 9], 15);
   HHH(ccc, ddd, aaa, bbb, X[ 1], 13);
   HHH(bbb, ccc, ddd, aaa, X[ 2], 11);

   /* parallel round 3 */   
   GGG(aaa, bbb, ccc, ddd, X[15],  9);
   GGG(ddd, aaa, bbb, ccc, X[ 5],  7);
   GGG(ccc, ddd, aaa, bbb, X[ 1], 15);
   GGG(bbb, ccc, ddd, aaa, X[ 3], 11);
   GGG(aaa, bbb, ccc, ddd, X[ 7],  8);
   GGG(ddd, aaa, bbb, ccc, X[14],  6);
   GGG(ccc, ddd, aaa, bbb, X[ 6],  6);
   GGG(bbb, ccc, ddd, aaa, X[ 9], 14);
   GGG(aaa, bbb, ccc, ddd, X[11], 12);
   GGG(ddd, aaa, bbb, ccc, X[ 8], 13);
   GGG(ccc, ddd, aaa, bbb, X[12],  5);
   GGG(bbb, ccc, ddd, aaa, X[ 2], 14);
   GGG(aaa, bbb, ccc, ddd, X[10], 13);
   GGG(ddd, aaa, bbb, ccc, X[ 0], 13);
   GGG(ccc, ddd, aaa, bbb, X[ 4],  7);
   GGG(bbb, ccc, ddd, aaa, X[13],  5);

   /* parallel round 4 */
   FFF(aaa, bbb, ccc, ddd, X[ 8], 15);
   FFF(ddd, aaa, bbb, ccc, X[ 6],  5);
   FFF(ccc, ddd, aaa, bbb, X[ 4],  8);
   FFF(bbb, ccc, ddd, aaa, X[ 1], 11);
   FFF(aaa, bbb, ccc, ddd, X[ 3], 14);
   FFF(ddd, aaa, bbb, ccc, X[11], 14);
   FFF(ccc, ddd, aaa, bbb, X[15],  6);
   FFF(bbb, ccc, ddd, aaa, X[ 0], 14);
   FFF(aaa, bbb, ccc, ddd, X[ 5],  6);
   FFF(ddd, aaa, bbb, ccc, X[12],  9);
   FFF(ccc, ddd, aaa, bbb, X[ 2], 12);
   FFF(bbb, ccc, ddd, aaa, X[13],  9);
   FFF(aaa, bbb, ccc, ddd, X[ 9], 12);
   FFF(ddd, aaa, bbb, ccc, X[ 7],  5);
   FFF(ccc, ddd, aaa, bbb, X[10], 15);
   FFF(bbb, ccc, ddd, aaa, X[14],  8);

   /* combine results */
   ddd += cc + MDbuf[1];               /* final result for MDbuf[0] */
   MDbuf[1] = MDbuf[2] + dd + aaa;
   MDbuf[2] = MDbuf[3] + aa + bbb;
   MDbuf[3] = MDbuf[0] + bb + ccc;
   MDbuf[0] = ddd;

   return;
}

/********************************************************************/

void MDfinish(dword *MDbuf, byte *strptr, dword lswlen, dword mswlen)
{
   unsigned int i;                                 /* counter       */
   dword        X[16];                             /* message words */

   memset(X, 0, 16*sizeof(dword));

   /* put bytes from strptr into X */
   for (i=0; i<(lswlen&63); i++) {
      /* byte i goes into word X[i div 4] at pos.  8*(i mod 4)  */
      X[i>>2] ^= (dword) *strptr++ << (8 * (i&3));
   }

   /* append the bit m_n == 1 */
   X[(lswlen>>2)&15] ^= (dword)1 << (8*(lswlen&3) + 7);

   if ((lswlen & 63) > 55) {
      /* length goes to next block */
      compress(MDbuf, X);
      memset(X, 0, 16*sizeof(dword));
   }

   /* append length in bits*/
   X[14] = lswlen << 3;
   X[15] = (lswlen >> 29) | (mswlen << 3);
   compress(MDbuf, X);

   return;
}

/************************ end of file rmd128.c **********************/

# endif /* RMD128A */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef RMD160B

/* ripemd.c - Implementation of the RIPE-MD Hash Algorithm
 *
 * Copyright (C) 2000, Nikos Mavroyanopoulos
 * This implementation is placed under the public domain.
 *
 * Based on the SHA-1 implementation by A.M. Kuchling
 *
 * Here are the quotes of the original SHA-1 implementation: 
 */
 
/* Copyright (C) 1995, A.M. Kuchling
 * Adapted to pike and some cleanup by Niels M�ller.
 *
 * Based on SHA code originally posted to sci.crypt by Peter Gutmann
 * in message <30ajo5$oe8@ccu2.auckland.ac.nz>.
 * Modified to test for endianness on creation of SHA objects by AMK.
 * Also, the original specification of SHA was found to have a weakness
 * by NSA/NIST.  This code implements the fixed version of SHA.
 */

/* The RIPEMD block size and message digest sizes, in bytes */
 
#define RIPEMD_DATASIZE    64
#define RIPEMD_DATALEN     16
#define RIPEMD_DIGESTSIZE  20
#define RIPEMD_DIGESTLEN    5
/* The structure for storing RIPEMD info */
 
typedef struct ripemd_ctx {
  word32 digest[RIPEMD_DIGESTLEN];  /* Message digest */
  word32 count_l, count_h;       /* 64-bit block count */
  word8 block[RIPEMD_DATASIZE];     /* RIPEMD data buffer */
  int index;                             /* index into buffer */
} RIPEMD_CTX;
 
void ripemd_init(struct ripemd_ctx *ctx);
void ripemd_update(struct ripemd_ctx *ctx, word8 *buffer, word32 len);
void ripemd_final(struct ripemd_ctx *ctx);
void ripemd_digest(struct ripemd_ctx *ctx, word8 *s);
void ripemd_copy(struct ripemd_ctx *dest, struct ripemd_ctx *src);              


/* 32-bit rotate left - kludged with shifts */
#define ROTL(n,X)  (((X)<<(n))|((X)>>(32-(n))))

#define f0(x,y,z)  (x^y^z)
#define f16(x,y,z) ((x&y)|((~x) & z))
#define f32(x,y,z) ((x|~(y))^z)
#define f48(x,y,z) ((x&z)|(y&(~z)))
#define f64(x,y,z) (x^(y|(~z)))

#define K0  0x00000000
#define K1  0x5A827999
#define K2  0x6ED9EBA1
#define K3  0x8F1BBCDC
#define K4  0xA953FD4E

#define KK0 0x50A28BE6
#define KK1 0x5C4DD124
#define KK2 0x6D703EF3
#define KK3 0x7A6D76E9
#define KK4 0x00000000

#define h0init 0x67452301
#define h1init 0xEFCDAB89
#define h2init 0x98BADCFE
#define h3init 0x10325476
#define h4init 0xC3D2E1F0

void ripemd_copy(struct ripemd_ctx *dest, struct ripemd_ctx *src)
{
        int i;

        dest->count_l = src->count_l;
        dest->count_h = src->count_h;
        for (i = 0; i < RIPEMD_DIGESTLEN; i++)
                dest->digest[i] = src->digest[i];
        for (i = 0; i < src->index; i++)
                dest->block[i] = src->block[i];
        dest->index = src->index;
}


/* Initialize the RIPEMD values */

void ripemd_init(struct ripemd_ctx *ctx)
{
        /* Set the h-vars to their initial values */
        ctx->digest[0] = h0init;
        ctx->digest[1] = h1init;
        ctx->digest[2] = h2init;
        ctx->digest[3] = h3init;
        ctx->digest[4] = h4init;

        /* Initialize bit count */
        ctx->count_l = ctx->count_h = 0;

        /* Initialize buffer */
        ctx->index = 0;
}

#define subRound(a, b, c, d, e, f, k, r, data) \
    ( a = ROTL( r, a + f(b,c,d) + data + k) + e, c = ROTL(10, c) )

static void ripemd_transform(struct ripemd_ctx *ctx, word32 * data)
{
        word32 A, B, C, D, E;   /* Local vars */
        word32 AA, BB, CC, DD, EE;      /* Local vars */
        word32 T, t;

        /* Set up first buffer and local data buffer */
        A = ctx->digest[0];
        B = ctx->digest[1];
        C = ctx->digest[2];
        D = ctx->digest[3];
        E = ctx->digest[4];

/* j=0...15 */
        subRound(A, B, C, D, E, f0, K0, 11, data[0]);
        subRound(E, A, B, C, D, f0, K0, 14, data[1]);
        subRound(D, E, A, B, C, f0, K0, 15, data[2]);
        subRound(C, D, E, A, B, f0, K0, 12, data[3]);
        subRound(B, C, D, E, A, f0, K0, 5, data[4]);
        subRound(A, B, C, D, E, f0, K0, 8, data[5]);
        subRound(E, A, B, C, D, f0, K0, 7, data[6]);
        subRound(D, E, A, B, C, f0, K0, 9, data[7]);
        subRound(C, D, E, A, B, f0, K0, 11, data[8]);
        subRound(B, C, D, E, A, f0, K0, 13, data[9]);
        subRound(A, B, C, D, E, f0, K0, 14, data[10]);
        subRound(E, A, B, C, D, f0, K0, 15, data[11]);
        subRound(D, E, A, B, C, f0, K0, 6, data[12]);
        subRound(C, D, E, A, B, f0, K0, 7, data[13]);
        subRound(B, C, D, E, A, f0, K0, 9, data[14]);
        subRound(A, B, C, D, E, f0, K0, 8, data[15]);

/* j=16...31 */
        subRound(E, A, B, C, D, f16, K1, 7, data[7]);
        subRound(D, E, A, B, C, f16, K1, 6, data[4]);
        subRound(C, D, E, A, B, f16, K1, 8, data[13]);
        subRound(B, C, D, E, A, f16, K1, 13, data[1]);
        subRound(A, B, C, D, E, f16, K1, 11, data[10]);
        subRound(E, A, B, C, D, f16, K1, 9, data[6]);
        subRound(D, E, A, B, C, f16, K1, 7, data[15]);
        subRound(C, D, E, A, B, f16, K1, 15, data[3]);
        subRound(B, C, D, E, A, f16, K1, 7, data[12]);
        subRound(A, B, C, D, E, f16, K1, 12, data[0]);
        subRound(E, A, B, C, D, f16, K1, 15, data[9]);
        subRound(D, E, A, B, C, f16, K1, 9, data[5]);
        subRound(C, D, E, A, B, f16, K1, 11, data[2]);
        subRound(B, C, D, E, A, f16, K1, 7, data[14]);
        subRound(A, B, C, D, E, f16, K1, 13, data[11]);
        subRound(E, A, B, C, D, f16, K1, 12, data[8]);

/* j=32...47 */
        subRound(D, E, A, B, C, f32, K2, 11, data[3]);
        subRound(C, D, E, A, B, f32, K2, 13, data[10]);
        subRound(B, C, D, E, A, f32, K2, 6, data[14]);
        subRound(A, B, C, D, E, f32, K2, 7, data[4]);
        subRound(E, A, B, C, D, f32, K2, 14, data[9]);
        subRound(D, E, A, B, C, f32, K2, 9, data[15]);
        subRound(C, D, E, A, B, f32, K2, 13, data[8]);
        subRound(B, C, D, E, A, f32, K2, 15, data[1]);
        subRound(A, B, C, D, E, f32, K2, 14, data[2]);
        subRound(E, A, B, C, D, f32, K2, 8, data[7]);
        subRound(D, E, A, B, C, f32, K2, 13, data[0]);
        subRound(C, D, E, A, B, f32, K2, 6, data[6]);
        subRound(B, C, D, E, A, f32, K2, 5, data[13]);
        subRound(A, B, C, D, E, f32, K2, 12, data[11]);
        subRound(E, A, B, C, D, f32, K2, 7, data[5]);
        subRound(D, E, A, B, C, f32, K2, 5, data[12]);

/* j=48...63 */
        subRound(C, D, E, A, B, f48, K3, 11, data[1]);
        subRound(B, C, D, E, A, f48, K3, 12, data[9]);
        subRound(A, B, C, D, E, f48, K3, 14, data[11]);
        subRound(E, A, B, C, D, f48, K3, 15, data[10]);
        subRound(D, E, A, B, C, f48, K3, 14, data[0]);
        subRound(C, D, E, A, B, f48, K3, 15, data[8]);
        subRound(B, C, D, E, A, f48, K3, 9, data[12]);
        subRound(A, B, C, D, E, f48, K3, 8, data[4]);
        subRound(E, A, B, C, D, f48, K3, 9, data[13]);
        subRound(D, E, A, B, C, f48, K3, 14, data[3]);
        subRound(C, D, E, A, B, f48, K3, 5, data[7]);
        subRound(B, C, D, E, A, f48, K3, 6, data[15]);
        subRound(A, B, C, D, E, f48, K3, 8, data[14]);
        subRound(E, A, B, C, D, f48, K3, 6, data[5]);
        subRound(D, E, A, B, C, f48, K3, 5, data[6]);
        subRound(C, D, E, A, B, f48, K3, 12, data[2]);

/* j=64...79 */
        subRound(B, C, D, E, A, f64, K4, 9, data[4]);
        subRound(A, B, C, D, E, f64, K4, 15, data[0]);
        subRound(E, A, B, C, D, f64, K4, 5, data[5]);
        subRound(D, E, A, B, C, f64, K4, 11, data[9]);
        subRound(C, D, E, A, B, f64, K4, 6, data[7]);
        subRound(B, C, D, E, A, f64, K4, 8, data[12]);
        subRound(A, B, C, D, E, f64, K4, 13, data[2]);
        subRound(E, A, B, C, D, f64, K4, 12, data[10]);
        subRound(D, E, A, B, C, f64, K4, 5, data[14]);
        subRound(C, D, E, A, B, f64, K4, 12, data[1]);
        subRound(B, C, D, E, A, f64, K4, 13, data[3]);
        subRound(A, B, C, D, E, f64, K4, 14, data[8]);
        subRound(E, A, B, C, D, f64, K4, 11, data[11]);
        subRound(D, E, A, B, C, f64, K4, 8, data[6]);
        subRound(C, D, E, A, B, f64, K4, 5, data[15]);
        subRound(B, C, D, E, A, f64, K4, 6, data[13]);

        AA = A;
        BB = B;
        CC = C;
        DD = D;
        EE = E;

/* ' */
        A = ctx->digest[0];
        B = ctx->digest[1];
        C = ctx->digest[2];
        D = ctx->digest[3];
        E = ctx->digest[4];

/* j=0...15 */
        subRound(A, B, C, D, E, f64, KK0, 8, data[5]);
        subRound(E, A, B, C, D, f64, KK0, 9, data[14]);
        subRound(D, E, A, B, C, f64, KK0, 9, data[7]);
        subRound(C, D, E, A, B, f64, KK0, 11, data[0]);
        subRound(B, C, D, E, A, f64, KK0, 13, data[9]);
        subRound(A, B, C, D, E, f64, KK0, 15, data[2]);
        subRound(E, A, B, C, D, f64, KK0, 15, data[11]);
        subRound(D, E, A, B, C, f64, KK0, 5, data[4]);
        subRound(C, D, E, A, B, f64, KK0, 7, data[13]);
        subRound(B, C, D, E, A, f64, KK0, 7, data[6]);
        subRound(A, B, C, D, E, f64, KK0, 8, data[15]);
        subRound(E, A, B, C, D, f64, KK0, 11, data[8]);
        subRound(D, E, A, B, C, f64, KK0, 14, data[1]);
        subRound(C, D, E, A, B, f64, KK0, 14, data[10]);
        subRound(B, C, D, E, A, f64, KK0, 12, data[3]);
        subRound(A, B, C, D, E, f64, KK0, 6, data[12]);

/* j=16...31 */
        subRound(E, A, B, C, D, f48, KK1, 9, data[6]);
        subRound(D, E, A, B, C, f48, KK1, 13, data[11]);
        subRound(C, D, E, A, B, f48, KK1, 15, data[3]);
        subRound(B, C, D, E, A, f48, KK1, 7, data[7]);
        subRound(A, B, C, D, E, f48, KK1, 12, data[0]);
        subRound(E, A, B, C, D, f48, KK1, 8, data[13]);
        subRound(D, E, A, B, C, f48, KK1, 9, data[5]);
        subRound(C, D, E, A, B, f48, KK1, 11, data[10]);
        subRound(B, C, D, E, A, f48, KK1, 7, data[14]);
        subRound(A, B, C, D, E, f48, KK1, 7, data[15]);
        subRound(E, A, B, C, D, f48, KK1, 12, data[8]);
        subRound(D, E, A, B, C, f48, KK1, 7, data[12]);
        subRound(C, D, E, A, B, f48, KK1, 6, data[4]);
        subRound(B, C, D, E, A, f48, KK1, 15, data[9]);
        subRound(A, B, C, D, E, f48, KK1, 13, data[1]);
        subRound(E, A, B, C, D, f48, KK1, 11, data[2]);

/* j=32...47 */
        subRound(D, E, A, B, C, f32, KK2, 9, data[15]);
        subRound(C, D, E, A, B, f32, KK2, 7, data[5]);
        subRound(B, C, D, E, A, f32, KK2, 15, data[1]);
        subRound(A, B, C, D, E, f32, KK2, 11, data[3]);
        subRound(E, A, B, C, D, f32, KK2, 8, data[7]);
        subRound(D, E, A, B, C, f32, KK2, 6, data[14]);
        subRound(C, D, E, A, B, f32, KK2, 6, data[6]);
        subRound(B, C, D, E, A, f32, KK2, 14, data[9]);
        subRound(A, B, C, D, E, f32, KK2, 12, data[11]);
        subRound(E, A, B, C, D, f32, KK2, 13, data[8]);
        subRound(D, E, A, B, C, f32, KK2, 5, data[12]);
        subRound(C, D, E, A, B, f32, KK2, 14, data[2]);
        subRound(B, C, D, E, A, f32, KK2, 13, data[10]);
        subRound(A, B, C, D, E, f32, KK2, 13, data[0]);
        subRound(E, A, B, C, D, f32, KK2, 7, data[4]);
        subRound(D, E, A, B, C, f32, KK2, 5, data[13]);

/* j=48...63 */
        subRound(C, D, E, A, B, f16, KK3, 15, data[8]);
        subRound(B, C, D, E, A, f16, KK3, 5, data[6]);
        subRound(A, B, C, D, E, f16, KK3, 8, data[4]);
        subRound(E, A, B, C, D, f16, KK3, 11, data[1]);
        subRound(D, E, A, B, C, f16, KK3, 14, data[3]);
        subRound(C, D, E, A, B, f16, KK3, 14, data[11]);
        subRound(B, C, D, E, A, f16, KK3, 6, data[15]);
        subRound(A, B, C, D, E, f16, KK3, 14, data[0]);
        subRound(E, A, B, C, D, f16, KK3, 6, data[5]);
        subRound(D, E, A, B, C, f16, KK3, 9, data[12]);
        subRound(C, D, E, A, B, f16, KK3, 12, data[2]);
        subRound(B, C, D, E, A, f16, KK3, 9, data[13]);
        subRound(A, B, C, D, E, f16, KK3, 12, data[9]);
        subRound(E, A, B, C, D, f16, KK3, 5, data[7]);
        subRound(D, E, A, B, C, f16, KK3, 15, data[10]);
        subRound(C, D, E, A, B, f16, KK3, 8, data[14]);

/* j=64...79 */
        subRound(B, C, D, E, A, f0, KK4, 8, data[12]);
        subRound(A, B, C, D, E, f0, KK4, 5, data[15]);
        subRound(E, A, B, C, D, f0, KK4, 12, data[10]);
        subRound(D, E, A, B, C, f0, KK4, 9, data[4]);
        subRound(C, D, E, A, B, f0, KK4, 12, data[1]);
        subRound(B, C, D, E, A, f0, KK4, 5, data[5]);
        subRound(A, B, C, D, E, f0, KK4, 14, data[8]);
        subRound(E, A, B, C, D, f0, KK4, 6, data[7]);
        subRound(D, E, A, B, C, f0, KK4, 8, data[6]);
        subRound(C, D, E, A, B, f0, KK4, 13, data[2]);
        subRound(B, C, D, E, A, f0, KK4, 6, data[13]);
        subRound(A, B, C, D, E, f0, KK4, 5, data[14]);
        subRound(E, A, B, C, D, f0, KK4, 15, data[0]);
        subRound(D, E, A, B, C, f0, KK4, 13, data[3]);
        subRound(C, D, E, A, B, f0, KK4, 11, data[9]);
        subRound(B, C, D, E, A, f0, KK4, 11, data[11]);

        T = ctx->digest[1] + D + CC;
        ctx->digest[1] = ctx->digest[2] + E + DD;
        ctx->digest[2] = ctx->digest[3] + A + EE;
        ctx->digest[3] = ctx->digest[4] + B + AA;
        ctx->digest[4] = ctx->digest[0] + C + BB;
        ctx->digest[0] = T;
}

#if 1

#ifndef EXTRACT_UCHAR
#define EXTRACT_UCHAR(p)  (*(word8 *)(p))
#endif

#define STRING2INT(s) ((((((EXTRACT_UCHAR(s+3) << 8)    \
                         | EXTRACT_UCHAR(s+2)) << 8)  \
                         | EXTRACT_UCHAR(s+1)) << 8)  \
                         | EXTRACT_UCHAR(s))
#else
word32 STRING2INT(word8 * s)
{
        word32 r;
        int i;

        for (i = 0, r = 0; i < 4; i++)
                r = (r << 8) | s[3-i];
        return r;
}
#endif

static void ripemd_block(struct ripemd_ctx *ctx, word8 * block)
{
        word32 data[RIPEMD_DATALEN];
        int i;

        /* Update block count */
        if (!++ctx->count_l)
                ++ctx->count_h;

        /* Endian independent conversion */
        for (i = 0; i < RIPEMD_DATALEN; i++, block += 4)
                data[i] = STRING2INT(block);

        ripemd_transform(ctx, data);
}

void ripemd_update(struct ripemd_ctx *ctx, word8 * buffer, word32 len)
{
        if (ctx->index) {       /* Try to fill partial block */
                unsigned left = RIPEMD_DATASIZE - ctx->index;
                if (len < left) {
                        memmove(ctx->block + ctx->index, buffer, len);
                        ctx->index += len;
                        return; /* Finished */
                } else {
                        memmove(ctx->block + ctx->index, buffer, left);
                        ripemd_block(ctx, ctx->block);
                        buffer += left;
                        len -= left;
                }
        }
        while (len >= RIPEMD_DATASIZE) {
                ripemd_block(ctx, buffer);
                buffer += RIPEMD_DATASIZE;
                len -= RIPEMD_DATASIZE;
        }
        if ((ctx->index = len))
                /* This assignment is intended */
                /* Buffer leftovers */
                memmove(ctx->block, buffer, len);
}

/* Final wrapup - pad to RIPEMD_DATASIZE-byte boundary with the bit pattern
   1 0* (64-bit count of bits processed, MSB-first) */

void ripemd_final(struct ripemd_ctx *ctx)
{
        word32 data[RIPEMD_DATALEN];
        int i;
        int words;

        i = ctx->index;
        /* Set the first char of padding to 0x80.  This is safe since there is
           always at least one byte free */
        ctx->block[i++] = 0x80;

        /* Fill rest of word */
        for (; i & 3; i++)
                ctx->block[i] = 0;

        /* i is now a multiple of the word size 4 */
        words = i >> 2;
        for (i = 0; i < words; i++)
                data[i] = STRING2INT(ctx->block + 4 * i);

        if (words > (RIPEMD_DATALEN - 2)) {
			/* No room for length in this block. 
				Process it and pad with another one */
                for (i = words; i < RIPEMD_DATALEN; i++)
                        data[i] = 0;
                ripemd_transform(ctx, data);
                for (i = 0; i < (RIPEMD_DATALEN - 2); i++)
                        data[i] = 0;
        } else
                for (i = words; i < RIPEMD_DATALEN - 2; i++)
                        data[i] = 0;
        /* Theres 512 = 2^9 bits in one block */
        data[RIPEMD_DATALEN - 1] =
            (ctx->count_h << 9) | (ctx->count_l >> 23);
        data[RIPEMD_DATALEN - 2] = (ctx->count_l << 9) | (ctx->index << 3);
        ripemd_transform(ctx, data);
}

void ripemd_digest(struct ripemd_ctx *ctx, word8 * s)
{
        int i;

        for (i = 0; i < RIPEMD_DIGESTLEN; i++) {
                *s++ = ctx->digest[i];
                *s++ = 0xff & (ctx->digest[i] >> 8);
                *s++ = 0xff & (ctx->digest[i] >> 16);
                *s++ = 0xff & ctx->digest[i] >> 24;
        }

}

# endif /* RMD160B */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef RMD160W

/******************************************************************************/
/*                                                                            */
/*  Functions for arithmetic and number theory with large integers in C       */
/*  Software supplement to the book "Cryptography in C and C++"               */
/*  by Michael Welschenbach, published by Apress Berkeley CA, 2001            */
/*                                                                            */
/*  Module ripemd.c         Revision: 19.12.2000                              */
/*                                                                            */
/*  Copyright (C) 1998-2001 by Michael Welschenbach                           */
/*  Copyright (C) 1998-2001 by Springer-Verlag Berlin, Heidelberg             */
/*  Copyright (C) 2001      by Apress L.P., Berkeley, CA                      */
/*                                                                            */
/*  All Rights Reserved                                                       */
/*                                                                            */
/*  The software may be used for noncommercial purposes and may be altered,   */
/*  as long as the following conditions are accepted without any              */
/*  qualification:                                                            */
/*                                                                            */
/*  (1) All changes to the sources must be identified in such a way that the  */
/*      changed software cannot be misinterpreted as the original software.   */
/*                                                                            */
/*  (2) The statements of copyright may not removed or altered.               */
/*                                                                            */
/*  (3) The following DISCLAIMER is accepted:                                 */
/*                                                                            */
/*  DISCLAIMER:                                                               */
/*                                                                            */
/*  There is no warranty for the software contained on this CD-ROM, to the    */
/*  extent permitted by applicable law. The copyright holders provide the     */
/*  software `as is' without warranty of any kind, either expressed or        */
/*  implied, including, but not limited to, the implied warranty of fitness   */
/*  for a particular purpose. The entire risk as to the quality and           */
/*  performance of the program is with you.                                   */
/*                                                                            */
/*  In no event unless required by applicable law or agreed to in writing     */
/*  will the copyright holders, or any of the individual authors named in     */
/*  the source files, be liable to you for damages, including any general,    */
/*  special, incidental or consequential damages arising out of any use of    */
/*  the software or out of inability to use the software (including but not   */
/*  limited to any financial losses, loss of data or data being rendered      */
/*  inaccurate or losses sustained by you or by third parties as a result of  */
/*  a failure of the software to operate with any other programs), even if    */
/*  such holder or other party has been advised of the possibility of such    */
/*  damages.                                                                  */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <string.h>
#include "flint.h"
#include "ripemd.h"

/* Prototypes of local functions */

static void appetize (ULONG *);
static void swallow (ULONG *, ULONG *);
static void digest (ULONG *, UCHAR *, ULONG[]);

/* Macros */

/* Rotation, simulation of assembler instruction for barrel shifting */
#define ROL(X, N)   (((X) << (N)) | ((X) >> (32-(N))))

/* RIPEMD specific chaining of intermediate values in rounds */
#define CHAIN(A, B, C, D, E, X, S) { \
          (A) = (E); (E) = (D); (D) = ROL((C), 10); (C) = (B); \
          (B) = ROL((X), (S)) + (A); \
        }

/* Conversion of an array of type UCHAR into a value of type ULONG */
#if defined LITTLE_ENDIAN
#define UC2UL(ucptr)  *(unsigned long *)((ucptr))
#else
#define UC2UL(ucptr) \
          (((unsigned long) *((ucptr)+3) << 24) | \
           ((unsigned long) *((ucptr)+2) << 16) | \
           ((unsigned long) *((ucptr)+1) <<  8) | \
           ((unsigned long) *(ucptr)))
#endif

/* Addition of a single-digit number b to a double-digit number represented   */
/* by an array (a[1],a[0]). A carry in a[0]+=b will be handled by increasing  */
/* a[1]                                                                       */
#define ADDC(a, b) { \
          if (((a)[0] + (b)) < (a)[0]) {(a)[1]++;} \
          (a)[0] += (b); \
        }

/*****************************************************************************/
/* RIPEMD-160 API                                                            */
/*****************************************************************************/

/******************************************************************************/
/*                                                                            */
/*  Function:   Hashing of a message of length byte in a single step          */
/*  Syntax:     UCHAR *ripemd160 (UCHAR *clear, ULONG length);                */
/*  Input:      UCHAR *clear (Pointer to message block)                       */
/*              ULONG length (Length of message block)                        */
/*  Output:     -                                                             */
/*  Returns:    UCHAR * (Pointer to hash value)                               */
/*                                                                            */
/******************************************************************************/
UCHAR * __FLINT_API
ripemd160 (UCHAR *clear, ULONG length)
{
  RMDSTAT hws;

  ripeinit (&hws);
  return (ripefinish (&hws, clear, length));
}

/******************************************************************************/
/* Functions for blockwise hashing a message in several steps                 */
/* Procedure: Initialization with ripeinit                                    */
/*            Hashing of block1, block2,... ,blockn with function ripehash    */
/*            Finish operation with function ripefinish                       */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/*  Function:   Initialization of RIPEMD 160 function                         */
/*  Syntax:     int ripeinit (RMDSTAT *hws);                                  */
/*  Input:      RMDSTAT *hws (RIPEMD status buffer)                           */
/*  Output:     -                                                             */
/*  Returns:    -                                                             */
/*                                                                            */
/******************************************************************************/
void __FLINT_API
ripeinit (RMDSTAT *hws)
{
  appetize (hws->stomach);
  hws->total[0] = 0;
  hws->total[1] = 0;
}

/******************************************************************************/
/*                                                                            */
/*  Function:   Hashing of a message block                                    */
/*  Syntax:     int ripehash (RMDSTAT *hws, UCHAR *clear, ULONG length);      */
/*  Input:      RMDSTAT *hws (RIPEMD status buffer)                           */
/*              UCHAR *clear (Pointer to message block)                       */
/*              ULONG length (Length of message block i bytes = 0 mod 64)     */
/*  Output:     -                                                             */
/*  Returns:    E_CLINT_OK if everything is O.K.                              */
/*              E_CLINT_RMD if length != 0 mod 64                             */
/*                                                                            */
/******************************************************************************/
int __FLINT_API
ripehash (RMDSTAT *hws, UCHAR *clear, ULONG length)
{
  ULONG   ULBlock[16];    /* message block holding 16 values of type ULONG  */
  ULONG   noofblocks;     /* Number of blocks of 16 ULONG-vyluse            */
  ULONG   i, j;           /* Counter                                        */

  /* If incomplete 64 byte block exists... */
  if (length & 63)
    {
      return E_CLINT_RMD; /* ...return error code  */
    }

  /* Number of 64 byte message blocks in clear */
  noofblocks = length >> 6;

  /* Process 64 byte message blocks in clear */
  for (i = 0; i < noofblocks; i++)
    {
        for (j = 0; j < 16; j++)
          {
            ULBlock[j] = UC2UL (clear);
            clear += 4;
          }

        swallow (hws->stomach, ULBlock);
    }

  /* Add length of message in clear to hws->total */
  ADDC (hws->total, length);

  return E_CLINT_OK;
}

/******************************************************************************/
/*                                                                            */
/*  Function:   Finish hash function RIPEMD 160                               */
/*  Syntax:     int ripefinish (RMDSTAT *hws, UCHAR *clear, ULONG length);    */
/*  Input:      RMDSTAT *hws (RIPEMD status buffer)                           */
/*              UCHAR *clear (Pointer to the last message block               */
/*              ULONG length (Length of message block in bytes)               */
/*  Output:     -                                                             */
/*  Returns:    UCHAR * (Pointer to hash value)                               */
/*                                                                            */
/******************************************************************************/
UCHAR * __FLINT_API
ripefinish (RMDSTAT *hws, UCHAR *clear, ULONG length)
{
  unsigned i;
  static UCHAR ripemd[RMDVER >> 3];

  /* Number of bytes in complete blocks */
  ULONG blength = (length >> 6) << 6;

  /* Process complete blocks in clear */
  ripehash (hws, clear, blength);

  /* Add length of message in clear to hws->total */
  ADDC (hws->total,length - blength);

  /* Process last incomplete block with padding and length of message */
  digest (hws->stomach, clear + blength, hws->total);

  for (i = 0; i < (RMDVER >> 3); i += 4)
    {
      ripemd[i]   = (UCHAR)hws->stomach[i>>2];
      ripemd[i+1] = (UCHAR)(hws->stomach[i>>2] >>  8); /*lint !e661 !e662 */
      ripemd[i+2] = (UCHAR)(hws->stomach[i>>2] >> 16); /*lint !e661 !e662 */
      ripemd[i+3] = (UCHAR)(hws->stomach[i>>2] >> 24); /*lint !e661 !e662 */
    }

  return (UCHAR *)ripemd;
}

/******************************************************************************/
/* RIPEMD-160 kernel functions                                                */
/******************************************************************************/

/* Choice of message words... */
static const int
r1[] = { 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15,
         7,  4, 13,  1, 10,  6, 15,  3, 12,  0,  9,  5,  2, 14, 11,  8,
         3, 10, 14,  4,  9, 15,  8,  1,  2,  7,  0,  6, 13, 11,  5, 12,
         1,  9, 11, 10,  0,  8, 12,  4, 13,  3,  7, 15, 14,  5,  6,  2,
         4,  0,  5,  9,  7, 12,  2, 10, 14,  1,  3,  8, 11,  6, 15, 13};

/* ... for parallel rounds */
static const int
r2[] = { 5, 14,  7,  0,  9,  2, 11,  4, 13,  6, 15,  8,  1, 10,  3, 12,
         6, 11,  3,  7,  0, 13,  5, 10, 14, 15,  8, 12,  4,  9,  1,  2,
        15,  5,  1,  3,  7, 14,  6,  9, 11,  8, 12,  2, 10,  0,  4, 13,
         8,  6,  4,  1,  3, 11, 15,  0,  5, 12,  2, 13,  9,  7, 10, 14,
        12, 15, 10,  4,  1,  5,  8,  7,  6,  2, 13, 14,  0,  3,  9, 11};

/* Length of rotations... */
static const int
s1[] = {11, 14, 15, 12,  5,  8,  7,  9, 11, 13, 14, 15,  6,  7,  9,  8,
         7,  6,  8, 13, 11,  9,  7, 15,  7, 12, 15,  9, 11,  7, 13, 12,
        11, 13,  6,  7, 14,  9, 13, 15, 14,  8, 13,  6,  5, 12,  7,  5,
        11, 12, 14, 15, 14, 15,  9,  8,  9, 14,  5,  6,  8,  6,  5, 12,
         9, 15,  5, 11,  6,  8, 13, 12,  5, 12, 13, 14, 11,  8,  5,  6};

/* ... for parallel rounds */
static const int
s2[] = { 8,  9,  9, 11, 13, 15, 15,  5,  7,  7,  8, 11, 14, 14, 12,  6,
         9, 13, 15,  7, 12,  8,  9, 11,  7,  7, 12,  7,  6, 15, 13, 11,
         9,  7, 15, 11,  8,  6,  6, 14, 12, 13,  5, 14, 13, 13,  7,  5,
        15,  5,  8, 11, 14, 14,  6, 14,  6,  9, 12,  9, 12,  5, 15,  8,
         8,  5, 12,  9, 12,  5, 14,  6,  8, 13,  6,  5, 15, 13, 11, 11};

static void
appetize (ULONG *stomach)
{
  stomach[0] = 0x67452301UL;
  stomach[1] = 0xefcdab89UL;
  stomach[2] = 0x98badcfeUL;
  stomach[3] = 0x10325476UL;
  stomach[4] = 0xc3d2e1f0UL;

  return;
}

static void
swallow (ULONG *stomach, ULONG *ULBlock)
{
  int i, rol;
  ULONG x;

  ULONG a1 = stomach[0];
  ULONG b1 = stomach[1];
  ULONG c1 = stomach[2];
  ULONG d1 = stomach[3];
  ULONG e1 = stomach[4];

  ULONG a2 = stomach[0];
  ULONG b2 = stomach[1];
  ULONG c2 = stomach[2];
  ULONG d2 = stomach[3];
  ULONG e2 = stomach[4];

  /*lint -e123 Don't complain about "Macros ... defined with arguments" */

  /* Rounds and parallel rounds 0-15 */
  for (i = 0; i < 16; i++)
    {
      rol = s1[i];
      x = a1 + (b1 ^ c1 ^ d1) + ULBlock[i];
      CHAIN (a1, b1, c1, d1, e1, x, rol);

      rol = s2[i];
      x = a2 + (b2 ^ (c2 | ~d2)) + ULBlock[r2[i]] + 0x50a28BE6UL;
      CHAIN (a2, b2, c2, d2, e2, x, rol);
    }

  /* Rounds and parallel rounds 16-31 */
  for (i = 16; i < 32; i++)
    {
      rol = s1[i];
      x = a1 + (d1 ^ (b1 & (c1 ^ d1))) + ULBlock[r1[i]] + 0x5A827999UL;
      CHAIN (a1, b1, c1, d1, e1, x, rol);

      rol = s2[i];
      x = a2 + (c2 ^ (d2 & (b2 ^ c2))) + ULBlock[r2[i]] + 0x5C4Dd124UL;
      CHAIN (a2, b2, c2, d2, e2, x, rol);
    }

  /* Rounds and parallel rounds 32-47 */
  for (i = 32; i < 48; i++)
    {
      rol = s1[i];
      x = a1 + ((b1 | ~c1) ^ d1) + ULBlock[r1[i]] + 0x6ED9EBA1UL;
      CHAIN (a1, b1, c1, d1, e1, x, rol);

      rol = s2[i];
      x = a2 + ((b2 | ~c2) ^ d2) + ULBlock[r2[i]] + 0x6D703EF3UL;
      CHAIN (a2, b2, c2, d2, e2, x, rol);
    }

  /* Rounds and parallel rounds 48-63 */
  for (i = 48; i < 64; i++)
    {
      rol = s1[i];
      x = a1 + (c1 ^ (d1 & (b1 ^ c1))) + ULBlock[r1[i]] + 0x8F1BBCDCUL;
      CHAIN (a1, b1, c1, d1, e1, x, rol);

      rol = s2[i];
      x = a2 + (d2 ^ (b2 & (c2 ^ d2))) + ULBlock[r2[i]] + 0x7A6D76E9UL;
      CHAIN (a2, b2, c2, d2, e2, x, rol);
    }

  /* Rounds and parallel rounds 64-79 */
  for (i = 64; i < 80; i++)
    {
      rol = s1[i];
      x = a1 + (b1 ^ (c1 | ~d1)) + ULBlock[r1[i]] + 0xA953FD4EUL;
      CHAIN (a1, b1, c1, d1, e1, x, rol);

      rol = s2[i];
      x = a2 + (b2 ^ c2 ^ d2) + ULBlock[r2[i]];
      CHAIN (a2, b2, c2, d2, e2, x, rol);
    }

  /* Result in stomach */
  d2 += c1 + stomach[1];
  stomach[1] = stomach[2] + d1 + e2;
  stomach[2] = stomach[3] + e1 + a2;
  stomach[3] = stomach[4] + a1 + b2;
  stomach[4] = stomach[0] + b1 + c2;
  stomach[0] = d2;

  return;
}

static void
digest (ULONG *stomach, UCHAR *clear, ULONG total[])
{
  ULONG i,j, rest;
  ULONG ULBlock[16];

  memset (ULBlock, 0, sizeof (ULONG) << 4);

  rest = total[0] & 0x3f;

  /* Insert ULONGs into ULBlock */
  for (i = 0; i < (rest >> 2); i++)
    {
      ULBlock[i] = UC2UL (clear);
      clear += 4;
    }

  /* Remaining UCHARs go into ULBLock. Invariant: 0 <= i <= 15 */
  for (j = i << 2; j < rest; j++)
    {
      ULBlock[i] |= (ULONG)*clear++ << ((j & 3) << 3);
    }

  /* Append 0x80 to ULBlock: At least one byte is still free */
  ULBlock[i] |= (ULONG)0x80 << ((j & 3) << 3);

  if (rest > 55) /* No space left for appending the message length (8 Byte), */
    {            /* therefore store length into the following block          */
      swallow (stomach, ULBlock);
      memset (ULBlock, 0, sizeof (ULONG) << 4);
    }

  /* Append message length in bit */
  ULBlock[14] = total[0] << 3;
  ULBlock[15] = (total[0] >> 29) | (total[1] << 3);
  swallow (stomach, ULBlock);

  return;
}

# endif /* RMD160W */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef SHA1A

/* Hash a single 512-bit block. This is the core of the algorithm. */

void SHA1Transform(unsigned long state[5], unsigned char buffer[64])
{
unsigned long a, b, c, d, e;
typedef union {
    unsigned char c[64];
    unsigned long l[16];
} CHAR64LONG16;
CHAR64LONG16* block;
#ifdef SHA1HANDSOFF
static unsigned char workspace[64];
    block = (CHAR64LONG16*)workspace;
    memcpy(block, buffer, 64);
#else
    block = (CHAR64LONG16*)buffer;
#endif
    /* Copy context->state[] to working vars */
    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
    e = state[4];
    /* 4 rounds of 20 operations each. Loop unrolled. */
    R0(a,b,c,d,e, 0); R0(e,a,b,c,d, 1); R0(d,e,a,b,c, 2); R0(c,d,e,a,b, 3);
    R0(b,c,d,e,a, 4); R0(a,b,c,d,e, 5); R0(e,a,b,c,d, 6); R0(d,e,a,b,c, 7);
    R0(c,d,e,a,b, 8); R0(b,c,d,e,a, 9); R0(a,b,c,d,e,10); R0(e,a,b,c,d,11);
    R0(d,e,a,b,c,12); R0(c,d,e,a,b,13); R0(b,c,d,e,a,14); R0(a,b,c,d,e,15);
    R1(e,a,b,c,d,16); R1(d,e,a,b,c,17); R1(c,d,e,a,b,18); R1(b,c,d,e,a,19);
    R2(a,b,c,d,e,20); R2(e,a,b,c,d,21); R2(d,e,a,b,c,22); R2(c,d,e,a,b,23);
    R2(b,c,d,e,a,24); R2(a,b,c,d,e,25); R2(e,a,b,c,d,26); R2(d,e,a,b,c,27);
    R2(c,d,e,a,b,28); R2(b,c,d,e,a,29); R2(a,b,c,d,e,30); R2(e,a,b,c,d,31);
    R2(d,e,a,b,c,32); R2(c,d,e,a,b,33); R2(b,c,d,e,a,34); R2(a,b,c,d,e,35);
    R2(e,a,b,c,d,36); R2(d,e,a,b,c,37); R2(c,d,e,a,b,38); R2(b,c,d,e,a,39);
    R3(a,b,c,d,e,40); R3(e,a,b,c,d,41); R3(d,e,a,b,c,42); R3(c,d,e,a,b,43);
    R3(b,c,d,e,a,44); R3(a,b,c,d,e,45); R3(e,a,b,c,d,46); R3(d,e,a,b,c,47);
    R3(c,d,e,a,b,48); R3(b,c,d,e,a,49); R3(a,b,c,d,e,50); R3(e,a,b,c,d,51);
    R3(d,e,a,b,c,52); R3(c,d,e,a,b,53); R3(b,c,d,e,a,54); R3(a,b,c,d,e,55);
    R3(e,a,b,c,d,56); R3(d,e,a,b,c,57); R3(c,d,e,a,b,58); R3(b,c,d,e,a,59);
    R4(a,b,c,d,e,60); R4(e,a,b,c,d,61); R4(d,e,a,b,c,62); R4(c,d,e,a,b,63);
    R4(b,c,d,e,a,64); R4(a,b,c,d,e,65); R4(e,a,b,c,d,66); R4(d,e,a,b,c,67);
    R4(c,d,e,a,b,68); R4(b,c,d,e,a,69); R4(a,b,c,d,e,70); R4(e,a,b,c,d,71);
    R4(d,e,a,b,c,72); R4(c,d,e,a,b,73); R4(b,c,d,e,a,74); R4(a,b,c,d,e,75);
    R4(e,a,b,c,d,76); R4(d,e,a,b,c,77); R4(c,d,e,a,b,78); R4(b,c,d,e,a,79);
    /* Add the working vars back into context.state[] */
    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    /* Wipe variables */
    a = b = c = d = e = 0;
}

/* SHA1Init - Initialize new context */

void SHA1Init(SHA1_CTX* context)
{
    /* SHA1 initialization constants */
    context->state[0] = 0x67452301;
    context->state[1] = 0xEFCDAB89;
    context->state[2] = 0x98BADCFE;
    context->state[3] = 0x10325476;
    context->state[4] = 0xC3D2E1F0;
    context->count[0] = context->count[1] = 0;
}

/* Run your data through this. */

void SHA1Update(SHA1_CTX* context, unsigned char* data, unsigned int len)
{
unsigned int i, j;

    j = (context->count[0] >> 3) & 63;
    if ((context->count[0] += len << 3) < (len << 3)) context->count[1]++;
    context->count[1] += (len >> 29);
    if ((j + len) > 63) {
        memcpy(&context->buffer[j], data, (i = 64-j));
        SHA1Transform(context->state, context->buffer);
        for ( ; i + 63 < len; i += 64) {
            SHA1Transform(context->state, &data[i]);
        }
        j = 0;
    }
    else i = 0;
    memcpy(&context->buffer[j], &data[i], len - i);
}

/* Add padding and return the message digest. */

void SHA1Final(unsigned char digest[20], SHA1_CTX* context)
{
unsigned long i, j;
unsigned char finalcount[8];

    for (i = 0; i < 8; i++) {
        finalcount[i] = (unsigned char)((context->count[(i >= 4 ? 0 : 1)]
         >> ((3-(i & 3)) * 8) ) & 255);  /* Endian independent */
    }
    SHA1Update(context, (unsigned char *)"\200", 1);
    while ((context->count[0] & 504) != 448) {
        SHA1Update(context, (unsigned char *)"\0", 1);
    }
    SHA1Update(context, finalcount, 8);  /* Should cause a SHA1Transform() */
    for (i = 0; i < 20; i++) {
        digest[i] = (unsigned char)
         ((context->state[i>>2] >> ((3-(i & 3)) * 8) ) & 255);
    }
    /* Wipe variables */
    i = j = 0;
    memset(context->buffer, 0, 64);
    memset(context->state, 0, 20);
    memset(context->count, 0, 8);
    memset(&finalcount, 0, 8);
#ifdef SHA1HANDSOFF  /* make SHA1Transform overwrite it's own static vars */
    SHA1Transform(context->state, context->buffer);
#endif
}

# endif /* SHA1A */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef MD5P

/*
  Copyright (C) 1999 Aladdin Enterprises.  All rights reserved.

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

  L. Peter Deutsch
  ghost@aladdin.com

 */
/*$Id: md5.c,v 1.3 2001/01/08 23:04:07 lukeh Exp $ */
/*
  Independent implementation of MD5 (RFC 1321).

  This code implements the MD5 Algorithm defined in RFC 1321.
  It is derived directly from the text of the RFC and not from the
  reference implementation.

  The original and principal author of md5.c is L. Peter Deutsch
  <ghost@aladdin.com>.  Other authors are noted in the change history
  that follows (in reverse chronological order):

  1999-11-04 lpd Edited comments slightly for automatic TOC extraction.
  1999-10-18 lpd Fixed typo in header comment (ansi2knr rather than md5).
  1999-05-03 lpd Original version.
 */

#include "md5.h"
#include <string.h>

#ifdef TEST
/*
 * Compile with -DTEST to create a self-contained executable test program.
 * The test program should print out the same values as given in section
 * A.5 of RFC 1321, reproduced below.
 */
main () {

    static const char *const test[7] = {
	"", /*d41d8cd98f00b204e9800998ecf8427e*/
	"a", /*0cc175b9c0f1b6a831c399e269772661*/
	"abc", /*900150983cd24fb0d6963f7d28e17f72*/
	"message digest", /*f96b697d7cb7938d525a2f31aaf161d0*/
	"abcdefghijklmnopqrstuvwxyz", /*c3fcd3d76192e4007dfb496cca67e13b*/
	"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
				/*d174ab98d277d9f5a5611c2c9f419d9f*/
	"12345678901234567890123456789012345678901234567890123456789012345678901234567890" /*57edf4a22be3c955ac49da2e2107b67a*/
    };
    int i;

    for (i = 0; i < 7; ++i) {
	md5_state_t state;
	md5_byte_t digest[16];
	int di;

	md5_init(&state);
	md5_append(&state, (const md5_byte_t *)test[i], strlen(test[i]));
	md5_finish(&state, digest);
	printf("MD5 (\"%s\") = ", test[i]);
	for (di = 0; di < 16; ++di)
	    printf("%02x", digest[di]);
	printf("\n");
    }
    return 0;
}
#endif /* TEST */

/*
 * For reference, here is the program that computed the T values.
 */

#if 0
#include <math.h>
main () {
    int i;
    for (i = 1; i <= 64; ++i) {
	unsigned long v = (unsigned long)(4294967296.0 * fabs(sin((double)i)));
	printf("#define T%d 0x%08lx\n", i, v);
    }
    return 0;
}
#endif

/*
 * End of T computation program.
 */

#define T1 0xd76aa478
#define T2 0xe8c7b756
#define T3 0x242070db
#define T4 0xc1bdceee
#define T5 0xf57c0faf
#define T6 0x4787c62a
#define T7 0xa8304613
#define T8 0xfd469501
#define T9 0x698098d8
#define T10 0x8b44f7af
#define T11 0xffff5bb1
#define T12 0x895cd7be
#define T13 0x6b901122
#define T14 0xfd987193
#define T15 0xa679438e
#define T16 0x49b40821
#define T17 0xf61e2562
#define T18 0xc040b340
#define T19 0x265e5a51
#define T20 0xe9b6c7aa
#define T21 0xd62f105d
#define T22 0x02441453
#define T23 0xd8a1e681
#define T24 0xe7d3fbc8
#define T25 0x21e1cde6
#define T26 0xc33707d6
#define T27 0xf4d50d87
#define T28 0x455a14ed
#define T29 0xa9e3e905
#define T30 0xfcefa3f8
#define T31 0x676f02d9
#define T32 0x8d2a4c8a
#define T33 0xfffa3942
#define T34 0x8771f681
#define T35 0x6d9d6122
#define T36 0xfde5380c
#define T37 0xa4beea44
#define T38 0x4bdecfa9
#define T39 0xf6bb4b60
#define T40 0xbebfbc70
#define T41 0x289b7ec6
#define T42 0xeaa127fa
#define T43 0xd4ef3085
#define T44 0x04881d05
#define T45 0xd9d4d039
#define T46 0xe6db99e5
#define T47 0x1fa27cf8
#define T48 0xc4ac5665
#define T49 0xf4292244
#define T50 0x432aff97
#define T51 0xab9423a7
#define T52 0xfc93a039
#define T53 0x655b59c3
#define T54 0x8f0ccc92
#define T55 0xffeff47d
#define T56 0x85845dd1
#define T57 0x6fa87e4f
#define T58 0xfe2ce6e0
#define T59 0xa3014314
#define T60 0x4e0811a1
#define T61 0xf7537e82
#define T62 0xbd3af235
#define T63 0x2ad7d2bb
#define T64 0xeb86d391

static void
md5_process(md5_state_t *pms, const md5_byte_t *data /*[64]*/)
{
    md5_word_t
	a = pms->abcd[0], b = pms->abcd[1],
	c = pms->abcd[2], d = pms->abcd[3];
    md5_word_t t;

#ifndef ARCH_IS_BIG_ENDIAN
# define ARCH_IS_BIG_ENDIAN 1	/* slower, default implementation */
#endif
#if ARCH_IS_BIG_ENDIAN

    /*
     * On big-endian machines, we must arrange the bytes in the right
     * order.  (This also works on machines of unknown byte order.)
     */
    md5_word_t X[16];
    const md5_byte_t *xp = data;
    int i;

    for (i = 0; i < 16; ++i, xp += 4)
	X[i] = xp[0] + (xp[1] << 8) + (xp[2] << 16) + (xp[3] << 24);

#else  /* !ARCH_IS_BIG_ENDIAN */

    /*
     * On little-endian machines, we can process properly aligned data
     * without copying it.
     */
    md5_word_t xbuf[16];
    const md5_word_t *X;

    if (!((data - (const md5_byte_t *)0) & 3)) {
	/* data are properly aligned */
	X = (const md5_word_t *)data;
    } else {
	/* not aligned */
	memcpy(xbuf, data, 64);
	X = xbuf;
    }
#endif

#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32 - (n))))

    /* Round 1. */
    /* Let [abcd k s i] denote the operation
       a = b + ((a + F(b,c,d) + X[k] + T[i]) <<< s). */
#define F(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define SET(a, b, c, d, k, s, Ti)\
  t = a + F(b,c,d) + X[k] + Ti;\
  a = ROTATE_LEFT(t, s) + b
    /* Do the following 16 operations. */
    SET(a, b, c, d,  0,  7,  T1);
    SET(d, a, b, c,  1, 12,  T2);
    SET(c, d, a, b,  2, 17,  T3);
    SET(b, c, d, a,  3, 22,  T4);
    SET(a, b, c, d,  4,  7,  T5);
    SET(d, a, b, c,  5, 12,  T6);
    SET(c, d, a, b,  6, 17,  T7);
    SET(b, c, d, a,  7, 22,  T8);
    SET(a, b, c, d,  8,  7,  T9);
    SET(d, a, b, c,  9, 12, T10);
    SET(c, d, a, b, 10, 17, T11);
    SET(b, c, d, a, 11, 22, T12);
    SET(a, b, c, d, 12,  7, T13);
    SET(d, a, b, c, 13, 12, T14);
    SET(c, d, a, b, 14, 17, T15);
    SET(b, c, d, a, 15, 22, T16);
#undef SET

     /* Round 2. */
     /* Let [abcd k s i] denote the operation
          a = b + ((a + G(b,c,d) + X[k] + T[i]) <<< s). */
#define G(x, y, z) (((x) & (z)) | ((y) & ~(z)))
#define SET(a, b, c, d, k, s, Ti)\
  t = a + G(b,c,d) + X[k] + Ti;\
  a = ROTATE_LEFT(t, s) + b
     /* Do the following 16 operations. */
    SET(a, b, c, d,  1,  5, T17);
    SET(d, a, b, c,  6,  9, T18);
    SET(c, d, a, b, 11, 14, T19);
    SET(b, c, d, a,  0, 20, T20);
    SET(a, b, c, d,  5,  5, T21);
    SET(d, a, b, c, 10,  9, T22);
    SET(c, d, a, b, 15, 14, T23);
    SET(b, c, d, a,  4, 20, T24);
    SET(a, b, c, d,  9,  5, T25);
    SET(d, a, b, c, 14,  9, T26);
    SET(c, d, a, b,  3, 14, T27);
    SET(b, c, d, a,  8, 20, T28);
    SET(a, b, c, d, 13,  5, T29);
    SET(d, a, b, c,  2,  9, T30);
    SET(c, d, a, b,  7, 14, T31);
    SET(b, c, d, a, 12, 20, T32);
#undef SET

     /* Round 3. */
     /* Let [abcd k s t] denote the operation
          a = b + ((a + H(b,c,d) + X[k] + T[i]) <<< s). */
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define SET(a, b, c, d, k, s, Ti)\
  t = a + H(b,c,d) + X[k] + Ti;\
  a = ROTATE_LEFT(t, s) + b
     /* Do the following 16 operations. */
    SET(a, b, c, d,  5,  4, T33);
    SET(d, a, b, c,  8, 11, T34);
    SET(c, d, a, b, 11, 16, T35);
    SET(b, c, d, a, 14, 23, T36);
    SET(a, b, c, d,  1,  4, T37);
    SET(d, a, b, c,  4, 11, T38);
    SET(c, d, a, b,  7, 16, T39);
    SET(b, c, d, a, 10, 23, T40);
    SET(a, b, c, d, 13,  4, T41);
    SET(d, a, b, c,  0, 11, T42);
    SET(c, d, a, b,  3, 16, T43);
    SET(b, c, d, a,  6, 23, T44);
    SET(a, b, c, d,  9,  4, T45);
    SET(d, a, b, c, 12, 11, T46);
    SET(c, d, a, b, 15, 16, T47);
    SET(b, c, d, a,  2, 23, T48);
#undef SET

     /* Round 4. */
     /* Let [abcd k s t] denote the operation
          a = b + ((a + I(b,c,d) + X[k] + T[i]) <<< s). */
#define I(x, y, z) ((y) ^ ((x) | ~(z)))
#define SET(a, b, c, d, k, s, Ti)\
  t = a + I(b,c,d) + X[k] + Ti;\
  a = ROTATE_LEFT(t, s) + b
     /* Do the following 16 operations. */
    SET(a, b, c, d,  0,  6, T49);
    SET(d, a, b, c,  7, 10, T50);
    SET(c, d, a, b, 14, 15, T51);
    SET(b, c, d, a,  5, 21, T52);
    SET(a, b, c, d, 12,  6, T53);
    SET(d, a, b, c,  3, 10, T54);
    SET(c, d, a, b, 10, 15, T55);
    SET(b, c, d, a,  1, 21, T56);
    SET(a, b, c, d,  8,  6, T57);
    SET(d, a, b, c, 15, 10, T58);
    SET(c, d, a, b,  6, 15, T59);
    SET(b, c, d, a, 13, 21, T60);
    SET(a, b, c, d,  4,  6, T61);
    SET(d, a, b, c, 11, 10, T62);
    SET(c, d, a, b,  2, 15, T63);
    SET(b, c, d, a,  9, 21, T64);
#undef SET

     /* Then perform the following additions. (That is increment each
        of the four registers by the value it had before this block
        was started.) */
    pms->abcd[0] += a;
    pms->abcd[1] += b;
    pms->abcd[2] += c;
    pms->abcd[3] += d;
}

void
md5_init(md5_state_t *pms)
{
    pms->count[0] = pms->count[1] = 0;
    pms->abcd[0] = 0x67452301;
    pms->abcd[1] = 0xefcdab89;
    pms->abcd[2] = 0x98badcfe;
    pms->abcd[3] = 0x10325476;
}

void
md5_append(md5_state_t *pms, const md5_byte_t *data, int nbytes)
{
    const md5_byte_t *p = data;
    int left = nbytes;
    int offset = (pms->count[0] >> 3) & 63;
    md5_word_t nbits = (md5_word_t)(nbytes << 3);

    if (nbytes <= 0)
	return;

    /* Update the message length. */
    pms->count[1] += nbytes >> 29;
    pms->count[0] += nbits;
    if (pms->count[0] < nbits)
	pms->count[1]++;

    /* Process an initial partial block. */
    if (offset) {
	int copy = (offset + nbytes > 64 ? 64 - offset : nbytes);

	memcpy(pms->buf + offset, p, copy);
	if (offset + copy < 64)
	    return;
	p += copy;
	left -= copy;
	md5_process(pms, pms->buf);
    }

    /* Process full blocks. */
    for (; left >= 64; p += 64, left -= 64)
	md5_process(pms, p);

    /* Process a final partial block. */
    if (left)
	memcpy(pms->buf, p, left);
}

void
md5_finish(md5_state_t *pms, md5_byte_t digest[16])
{
    static const md5_byte_t pad[64] = {
	0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    md5_byte_t data[8];
    int i;

    /* Save the length before padding. */
    for (i = 0; i < 8; ++i)
	data[i] = (md5_byte_t)(pms->count[i >> 2] >> ((i & 3) << 3));
    /* Pad to 56 bytes mod 64. */
    md5_append(pms, pad, ((55 - (pms->count[0] >> 3)) & 63) + 1);
    /* Append the length. */
    md5_append(pms, data, 8);
    for (i = 0; i < 16; ++i)
	digest[i] = (md5_byte_t)(pms->abcd[i >> 2] >> ((i & 3) << 3));
}

# endif /* MD5P */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef MD5C

/* MD5C.C - RSA Data Security, Inc., MD5 message-digest algorithm */

/* Copyright (C) 1991-2, RSA Data Security, Inc. Created 1991. All
rights reserved.

License to copy and use this software is granted provided that it
is identified as the "RSA Data Security, Inc. MD5 Message-Digest
Algorithm" in all material mentioning or referencing this software
or this function.

License is also granted to make and use derivative works provided
that such works are identified as "derived from the RSA Data
Security, Inc. MD5 Message-Digest Algorithm" in all material
mentioning or referencing the derived work.

RSA Data Security, Inc. makes no representations concerning either
the merchantability of this software or the suitability of this
software for any particular purpose. It is provided "as is"
without express or implied warranty of any kind.

These notices must be retained in any copies of any part of this
documentation and/or software.
 */

/*
 *	#include "global.h"
 *	#include "md5.h"
 */

/* Constants for MD5Transform routine.
 */
#define S11 7
#define S12 12
#define S13 17
#define S14 22
#define S21 5
#define S22 9
#define S23 14
#define S24 20
#define S31 4
#define S32 11
#define S33 16
#define S34 23
#define S41 6
#define S42 10
#define S43 15
#define S44 21

static void MD5Transform PROTO_LIST ((UINT4 [4], unsigned char [64]));
static void Encode PROTO_LIST
  ((unsigned char *, UINT4 *, unsigned int));
static void Decode PROTO_LIST
  ((UINT4 *, unsigned char *, unsigned int));
static void MD5_memcpy PROTO_LIST ((POINTER, POINTER, unsigned int));
static void MD5_memset PROTO_LIST ((POINTER, int, unsigned int));

static unsigned char PADDING[64] = {
  0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/* F, G, H and I are basic MD5 functions.
 */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))

/* ROTATE_LEFT rotates x left n bits.
 */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/* FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4.
Rotation is separate from addition to prevent recomputation.
 */
#define FF(a, b, c, d, x, s, ac) { \
 (a) += F ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define GG(a, b, c, d, x, s, ac) { \
 (a) += G ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define HH(a, b, c, d, x, s, ac) { \
 (a) += H ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define II(a, b, c, d, x, s, ac) { \
 (a) += I ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }

/* MD5 initialization. Begins an MD5 operation, writing a new context.
 */
void MD5Init (context) MD5_CTX *context; {
  context->count[0] = context->count[1] = 0;
  /* Load magic initialization constants.
*/
  context->state[0] = 0x67452301;
  context->state[1] = 0xefcdab89;
  context->state[2] = 0x98badcfe;
  context->state[3] = 0x10325476;
}

/* MD5 block update operation. Continues an MD5 message-digest
  operation, processing another message block, and updating the
  context.
 */
void MD5Update (context, input, inputLen)
MD5_CTX *context;                                        /* context */
unsigned char *input;                                /* input block */
unsigned int inputLen;                     /* length of input block */
{
  unsigned int i, index, partLen;

  /* Compute number of bytes mod 64 */
  index = (unsigned int)((context->count[0] >> 3) & 0x3F);

  /* Update number of bits */
  if ((context->count[0] += ((UINT4)inputLen << 3))
   < ((UINT4)inputLen << 3))
 context->count[1]++;
  context->count[1] += ((UINT4)inputLen >> 29);

  partLen = 64 - index;

  /* Transform as many times as possible.
*/
  if (inputLen >= partLen) {
 MD5_memcpy
   ((POINTER)&context->buffer[index], (POINTER)input, partLen);
 MD5Transform (context->state, context->buffer);

 for (i = partLen; i + 63 < inputLen; i += 64)
   MD5Transform (context->state, &input[i]);

 index = 0;
  }
  else
 i = 0;

  /* Buffer remaining input */
  MD5_memcpy
 ((POINTER)&context->buffer[index], (POINTER)&input[i],
  inputLen-i);
}

/* MD5 finalization. Ends an MD5 message-digest operation, writing the
  the message digest and zeroizing the context.
 */
void MD5Final (digest, context)
unsigned char digest[16];                         /* message digest */
MD5_CTX *context;                                       /* context */
{
  unsigned char bits[8];
  unsigned int index, padLen;

  /* Save number of bits */
  Encode (bits, context->count, 8);

  /* Pad out to 56 mod 64.
*/
  index = (unsigned int)((context->count[0] >> 3) & 0x3f);
  padLen = (index < 56) ? (56 - index) : (120 - index);
  MD5Update (context, PADDING, padLen);

  /* Append length (before padding) */
  MD5Update (context, bits, 8);
  /* Store state in digest */
  Encode (digest, context->state, 16);

  /* Zeroize sensitive information.
*/
  MD5_memset ((POINTER)context, 0, sizeof (*context));
}

/* MD5 basic transformation. Transforms state based on block.
 */
static void MD5Transform (state, block)
UINT4 state[4];
unsigned char block[64];
{
  UINT4 a = state[0], b = state[1], c = state[2], d = state[3], x[16];

  Decode (x, block, 64);

  /* Round 1 */
  FF (a, b, c, d, x[ 0], S11, 0xd76aa478); /* 1 */
  FF (d, a, b, c, x[ 1], S12, 0xe8c7b756); /* 2 */
  FF (c, d, a, b, x[ 2], S13, 0x242070db); /* 3 */
  FF (b, c, d, a, x[ 3], S14, 0xc1bdceee); /* 4 */
  FF (a, b, c, d, x[ 4], S11, 0xf57c0faf); /* 5 */
  FF (d, a, b, c, x[ 5], S12, 0x4787c62a); /* 6 */
  FF (c, d, a, b, x[ 6], S13, 0xa8304613); /* 7 */
  FF (b, c, d, a, x[ 7], S14, 0xfd469501); /* 8 */
  FF (a, b, c, d, x[ 8], S11, 0x698098d8); /* 9 */
  FF (d, a, b, c, x[ 9], S12, 0x8b44f7af); /* 10 */
  FF (c, d, a, b, x[10], S13, 0xffff5bb1); /* 11 */
  FF (b, c, d, a, x[11], S14, 0x895cd7be); /* 12 */
  FF (a, b, c, d, x[12], S11, 0x6b901122); /* 13 */
  FF (d, a, b, c, x[13], S12, 0xfd987193); /* 14 */
  FF (c, d, a, b, x[14], S13, 0xa679438e); /* 15 */
  FF (b, c, d, a, x[15], S14, 0x49b40821); /* 16 */

 /* Round 2 */
  GG (a, b, c, d, x[ 1], S21, 0xf61e2562); /* 17 */
  GG (d, a, b, c, x[ 6], S22, 0xc040b340); /* 18 */
  GG (c, d, a, b, x[11], S23, 0x265e5a51); /* 19 */
  GG (b, c, d, a, x[ 0], S24, 0xe9b6c7aa); /* 20 */
  GG (a, b, c, d, x[ 5], S21, 0xd62f105d); /* 21 */
  GG (d, a, b, c, x[10], S22,  0x2441453); /* 22 */
  GG (c, d, a, b, x[15], S23, 0xd8a1e681); /* 23 */
  GG (b, c, d, a, x[ 4], S24, 0xe7d3fbc8); /* 24 */
  GG (a, b, c, d, x[ 9], S21, 0x21e1cde6); /* 25 */
  GG (d, a, b, c, x[14], S22, 0xc33707d6); /* 26 */
  GG (c, d, a, b, x[ 3], S23, 0xf4d50d87); /* 27 */
  GG (b, c, d, a, x[ 8], S24, 0x455a14ed); /* 28 */
  GG (a, b, c, d, x[13], S21, 0xa9e3e905); /* 29 */
  GG (d, a, b, c, x[ 2], S22, 0xfcefa3f8); /* 30 */
  GG (c, d, a, b, x[ 7], S23, 0x676f02d9); /* 31 */
  GG (b, c, d, a, x[12], S24, 0x8d2a4c8a); /* 32 */

  /* Round 3 */
  HH (a, b, c, d, x[ 5], S31, 0xfffa3942); /* 33 */
  HH (d, a, b, c, x[ 8], S32, 0x8771f681); /* 34 */
  HH (c, d, a, b, x[11], S33, 0x6d9d6122); /* 35 */
  HH (b, c, d, a, x[14], S34, 0xfde5380c); /* 36 */
  HH (a, b, c, d, x[ 1], S31, 0xa4beea44); /* 37 */
  HH (d, a, b, c, x[ 4], S32, 0x4bdecfa9); /* 38 */
  HH (c, d, a, b, x[ 7], S33, 0xf6bb4b60); /* 39 */
  HH (b, c, d, a, x[10], S34, 0xbebfbc70); /* 40 */
  HH (a, b, c, d, x[13], S31, 0x289b7ec6); /* 41 */
  HH (d, a, b, c, x[ 0], S32, 0xeaa127fa); /* 42 */
  HH (c, d, a, b, x[ 3], S33, 0xd4ef3085); /* 43 */
  HH (b, c, d, a, x[ 6], S34,  0x4881d05); /* 44 */
  HH (a, b, c, d, x[ 9], S31, 0xd9d4d039); /* 45 */
  HH (d, a, b, c, x[12], S32, 0xe6db99e5); /* 46 */
  HH (c, d, a, b, x[15], S33, 0x1fa27cf8); /* 47 */
  HH (b, c, d, a, x[ 2], S34, 0xc4ac5665); /* 48 */

  /* Round 4 */
  II (a, b, c, d, x[ 0], S41, 0xf4292244); /* 49 */
  II (d, a, b, c, x[ 7], S42, 0x432aff97); /* 50 */
  II (c, d, a, b, x[14], S43, 0xab9423a7); /* 51 */
  II (b, c, d, a, x[ 5], S44, 0xfc93a039); /* 52 */
  II (a, b, c, d, x[12], S41, 0x655b59c3); /* 53 */
  II (d, a, b, c, x[ 3], S42, 0x8f0ccc92); /* 54 */
  II (c, d, a, b, x[10], S43, 0xffeff47d); /* 55 */
  II (b, c, d, a, x[ 1], S44, 0x85845dd1); /* 56 */
  II (a, b, c, d, x[ 8], S41, 0x6fa87e4f); /* 57 */
  II (d, a, b, c, x[15], S42, 0xfe2ce6e0); /* 58 */
  II (c, d, a, b, x[ 6], S43, 0xa3014314); /* 59 */
  II (b, c, d, a, x[13], S44, 0x4e0811a1); /* 60 */
  II (a, b, c, d, x[ 4], S41, 0xf7537e82); /* 61 */
  II (d, a, b, c, x[11], S42, 0xbd3af235); /* 62 */
  II (c, d, a, b, x[ 2], S43, 0x2ad7d2bb); /* 63 */
  II (b, c, d, a, x[ 9], S44, 0xeb86d391); /* 64 */

  state[0] += a;
  state[1] += b;
  state[2] += c;
  state[3] += d;

  /* Zeroize sensitive information.
*/
  MD5_memset ((POINTER)x, 0, sizeof (x));
}

/* Encodes input (UINT4) into output (unsigned char). Assumes len is
  a multiple of 4.
 */
static void Encode (output, input, len)
unsigned char *output;
UINT4 *input;
unsigned int len;
{
  unsigned int i, j;

  for (i = 0, j = 0; j < len; i++, j += 4) {
 output[j] = (unsigned char)(input[i] & 0xff);
 output[j+1] = (unsigned char)((input[i] >> 8) & 0xff);
 output[j+2] = (unsigned char)((input[i] >> 16) & 0xff);
 output[j+3] = (unsigned char)((input[i] >> 24) & 0xff);
  }
}

/* Decodes input (unsigned char) into output (UINT4). Assumes len is
  a multiple of 4.
 */
static void Decode (output, input, len)
UINT4 *output;
unsigned char *input;
unsigned int len;
{
  unsigned int i, j;

  for (i = 0, j = 0; j < len; i++, j += 4)
 output[i] = ((UINT4)input[j]) | (((UINT4)input[j+1]) << 8) |
   (((UINT4)input[j+2]) << 16) | (((UINT4)input[j+3]) << 24);
}

/* Note: Replace "for loop" with standard memcpy if possible.
 */

static void MD5_memcpy (output, input, len)
POINTER output;
POINTER input;
unsigned int len;
{
  unsigned int i;

  for (i = 0; i < len; i++)
 output[i] = input[i];
}

/* Note: Replace "for loop" with standard memset if possible.
 */
static void MD5_memset (output, value, len)
POINTER output;
int value;
unsigned int len;
{
  unsigned int i;

  for (i = 0; i < len; i++)
 ((char *)output)[i] = (char)value;
}

# endif /* MD5C */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef HAVAL1

/*
 *  haval.c:  specifies the routines in the HAVAL (V.1) hashing library.
 *
 *      HAVAL is a one-way hashing algorithm with the following
 *      collision-resistant property:
 *             It is computationally infeasible to find two or more
 *             messages that are hashed into the same fingerprint.
 *      
 *  Reference:
 *       Y. Zheng, J. Pieprzyk and J. Seberry:
 *       ``HAVAL --- a one-way hashing algorithm with variable
 *       length of output'', Advances in Cryptology --- AUSCRYPT'92,
 *       Lecture Notes in Computer Science,  Vol.718, pp.83-104, 
 *       Springer-Verlag, 1993.
 *
 *  Descriptions:
 *      -  haval_string:      hash a string
 *      -  haval_file:        hash a file
 *      -  haval_stdin:       filter -- hash input from the stdin device
 *      -  haval_hash:        hash a string of specified length
 *                            (Haval_hash is used in conjunction with
 *                             haval_start & haval_end.)
 *      -  haval_hash_block:  hash a 32-word block
 *      -  haval_start:       initialization
 *      -  haval_end:         finalization
 *
 *  Author:     Yuliang Zheng
 *              School of Computing and Information Technology
 *              Monash University
 *              McMahons Road, Frankston 3199, Australia
 *              Email: yzheng@fcit.monash.edu.au
 *              URL:   http://www-pscit.fcit.monash.edu.au:/~yuliang/
 *              Voice: +61 3 9904 4196
 *              Fax  : +61 3 9904 4124
 *
 *  Date:
 *              First release: June  1993
 *
 *              Revised:       April 1996
 *                       Major changes:
 *                       1. added    #include <string.h>
 *                       2. deleted  #include <memory.h>
 *                       3. appended 'L' to all 32-bit constants
 *
 *                       Many thanks to Ross Williams (ross@rocksoft.com)
 *                       for his invaluable comments on the previous
 *                       version of the code.
 *
 *              Revised:       April 1997
 *                       Corrected the first byte in padding[128]
 *                       (from 0x80 to 0x01).
 *
 *                       Thanks go to Paulo Barreto (pbarreto@uninet.com.br)
 *                       who detected the padding error while implementing
 *                       HAVAL independently.
 *
 *      Copyright (C) 1997 by Yuliang Zheng.  All rights reserved. 
 *      This program may not be sold or used as inducement to sell
 *      a  product without the  written  permission of the author.
 */

#include <stdio.h>
#include <string.h>

#include "stdhaval.h"

#define VERSION    1                         /* current version number */

void haval_string (char *, unsigned char *); /* hash a string */
int  haval_file (char *, unsigned char *);   /* hash a file */
void haval_stdin (void);                     /* hash input from stdin */
void haval_start (haval_state *);            /* initialization */
void haval_hash (haval_state *,
        unsigned char *, unsigned int);      /* updating routine */
void haval_end (haval_state *, unsigned char *); /* finalization */
void haval_hash_block (haval_state *);       /* hash a 32-word block */
static void haval_tailor (haval_state *);    /* folding the last output */

static unsigned char padding[128] = {        /* constants for padding */
0x01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

#define f_1(x6, x5, x4, x3, x2, x1, x0)          \
           ((x1) & ((x0) ^ (x4)) ^ (x2) & (x5) ^ \
            (x3) & (x6) ^ (x0))

#define f_2(x6, x5, x4, x3, x2, x1, x0)                         \
           ((x2) & ((x1) & ~(x3) ^ (x4) & (x5) ^ (x6) ^ (x0)) ^ \
            (x4) & ((x1) ^ (x5)) ^ (x3) & (x5) ^ (x0)) 

#define f_3(x6, x5, x4, x3, x2, x1, x0)          \
           ((x3) & ((x1) & (x2) ^ (x6) ^ (x0)) ^ \
            (x1) & (x4) ^ (x2) & (x5) ^ (x0))

#define f_4(x6, x5, x4, x3, x2, x1, x0)                                 \
           ((x4) & ((x5) & ~(x2) ^ (x3) & ~(x6) ^ (x1) ^ (x6) ^ (x0)) ^ \
            (x3) & ((x1) & (x2) ^ (x5) ^ (x6)) ^                        \
            (x2) & (x6) ^ (x0))

#define f_5(x6, x5, x4, x3, x2, x1, x0)             \
           ((x0) & ((x1) & (x2) & (x3) ^ ~(x5)) ^   \
            (x1) & (x4) ^ (x2) & (x5) ^ (x3) & (x6))

/*
 * Permutations phi_{i,j}, i=3,4,5, j=1,...,i.
 *
 * PASS = 3:
 *               6 5 4 3 2 1 0
 *               | | | | | | | (replaced by)
 *  phi_{3,1}:   1 0 3 5 6 2 4
 *  phi_{3,2}:   4 2 1 0 5 3 6
 *  phi_{3,3}:   6 1 2 3 4 5 0
 *
 * PASS = 4:
 *               6 5 4 3 2 1 0
 *               | | | | | | | (replaced by)
 *  phi_{4,1}:   2 6 1 4 5 3 0
 *  phi_{4,2}:   3 5 2 0 1 6 4
 *  phi_{4,3}:   1 4 3 6 0 2 5
 *  phi_{4,4}:   6 4 0 5 2 1 3
 *
 * PASS = 5:
 *               6 5 4 3 2 1 0
 *               | | | | | | | (replaced by)
 *  phi_{5,1}:   3 4 1 0 5 2 6
 *  phi_{5,2}:   6 2 1 0 3 4 5
 *  phi_{5,3}:   2 6 0 4 3 1 5
 *  phi_{5,4}:   1 5 3 2 0 4 6
 *  phi_{5,5}:   2 5 0 6 4 3 1
 */

#if   PASS == 3
#define Fphi_1(x6, x5, x4, x3, x2, x1, x0) \
           f_1(x1, x0, x3, x5, x6, x2, x4)
#elif PASS == 4
#define Fphi_1(x6, x5, x4, x3, x2, x1, x0) \
           f_1(x2, x6, x1, x4, x5, x3, x0)
#else 
#define Fphi_1(x6, x5, x4, x3, x2, x1, x0) \
           f_1(x3, x4, x1, x0, x5, x2, x6)
#endif

#if   PASS == 3
#define Fphi_2(x6, x5, x4, x3, x2, x1, x0) \
           f_2(x4, x2, x1, x0, x5, x3, x6)
#elif PASS == 4
#define Fphi_2(x6, x5, x4, x3, x2, x1, x0) \
           f_2(x3, x5, x2, x0, x1, x6, x4)
#else 
#define Fphi_2(x6, x5, x4, x3, x2, x1, x0) \
           f_2(x6, x2, x1, x0, x3, x4, x5)
#endif

#if   PASS == 3
#define Fphi_3(x6, x5, x4, x3, x2, x1, x0) \
           f_3(x6, x1, x2, x3, x4, x5, x0)
#elif PASS == 4
#define Fphi_3(x6, x5, x4, x3, x2, x1, x0) \
           f_3(x1, x4, x3, x6, x0, x2, x5)
#else 
#define Fphi_3(x6, x5, x4, x3, x2, x1, x0) \
           f_3(x2, x6, x0, x4, x3, x1, x5)
#endif

#if   PASS == 4
#define Fphi_4(x6, x5, x4, x3, x2, x1, x0) \
           f_4(x6, x4, x0, x5, x2, x1, x3)
#else 
#define Fphi_4(x6, x5, x4, x3, x2, x1, x0) \
            f_4(x1, x5, x3, x2, x0, x4, x6)
#endif

#define Fphi_5(x6, x5, x4, x3, x2, x1, x0) \
           f_5(x2, x5, x0, x6, x4, x3, x1)

#define rotate_right(x, n) (((x) >> (n)) | ((x) << (32-(n))))

#define FF_1(x7, x6, x5, x4, x3, x2, x1, x0, w) {                        \
      register haval_word temp = Fphi_1(x6, x5, x4, x3, x2, x1, x0);     \
      (x7) = rotate_right(temp, 7) + rotate_right((x7), 11) + (w);       \
      }

#define FF_2(x7, x6, x5, x4, x3, x2, x1, x0, w, c) {                      \
      register haval_word temp = Fphi_2(x6, x5, x4, x3, x2, x1, x0);      \
      (x7) = rotate_right(temp, 7) + rotate_right((x7), 11) + (w) + (c);  \
      }

#define FF_3(x7, x6, x5, x4, x3, x2, x1, x0, w, c) {                      \
      register haval_word temp = Fphi_3(x6, x5, x4, x3, x2, x1, x0);      \
      (x7) = rotate_right(temp, 7) + rotate_right((x7), 11) + (w) + (c);  \
      }

#define FF_4(x7, x6, x5, x4, x3, x2, x1, x0, w, c) {                      \
      register haval_word temp = Fphi_4(x6, x5, x4, x3, x2, x1, x0);      \
      (x7) = rotate_right(temp, 7) + rotate_right((x7), 11) + (w) + (c);  \
      }

#define FF_5(x7, x6, x5, x4, x3, x2, x1, x0, w, c) {                      \
      register haval_word temp = Fphi_5(x6, x5, x4, x3, x2, x1, x0);      \
      (x7) = rotate_right(temp, 7) + rotate_right((x7), 11) + (w) + (c);  \
      }

/*
 * translate every four characters into a word.
 * assume the number of characters is a multiple of four.
 */
#define ch2uint(string, word, slen) {      \
  unsigned char *sp = string;              \
  haval_word    *wp = word;                \
  while (sp < (string) + (slen)) {         \
    *wp++ =  (haval_word)*sp            |  \
            ((haval_word)*(sp+1) <<  8) |  \
            ((haval_word)*(sp+2) << 16) |  \
            ((haval_word)*(sp+3) << 24);   \
    sp += 4;                               \
  }                                        \
}

/* translate each word into four characters */
#define uint2ch(word, string, wlen) {              \
  haval_word    *wp = word;                        \
  unsigned char *sp = string;                      \
  while (wp < (word) + (wlen)) {                   \
    *(sp++) = (unsigned char)( *wp        & 0xFF); \
    *(sp++) = (unsigned char)((*wp >>  8) & 0xFF); \
    *(sp++) = (unsigned char)((*wp >> 16) & 0xFF); \
    *(sp++) = (unsigned char)((*wp >> 24) & 0xFF); \
    wp++;                                          \
  }                                                \
}


/* hash a string */
void haval_string (char *string, unsigned char *fingerprint)
{
  haval_state   state;
  unsigned int  len = strlen (string);

  haval_start (&state);
  haval_hash (&state, (unsigned char *)string, len);
  haval_end (&state, fingerprint);
}

/* hash a file */
int haval_file (char *file_name, unsigned char *fingerprint)
{
  FILE          *file;
  haval_state   state;
  int           len;
  unsigned char buffer[1024];

  if ((file = fopen (file_name, "rb")) == NULL){
    return (1);                                    /* fail */
  } else {
    haval_start (&state);
    while (len = fread (buffer, 1, 1024, file)) {
      haval_hash (&state, buffer, len);
    }
    fclose (file);
    haval_end (&state, fingerprint);
    return (0);                                    /* success */
 }
}

/* hash input from stdin */
void haval_stdin (void)
{
  haval_state   state;
  int           i, len;
  unsigned char buffer[32],
                fingerprint[FPTLEN >> 3];

  haval_start (&state);
  while (len = fread (buffer, 1, 32, stdin)) {
    haval_hash (&state, buffer, len);
  }
  haval_end (&state, fingerprint);
  
  for (i = 0; i < FPTLEN >> 3; i++) {
    putchar(fingerprint[i]);
  }
}

/* initialization */
void haval_start (haval_state *state)
{
    state->count[0]       = state->count[1] = 0;   /* clear count */
    state->fingerprint[0] = 0x243F6A88L;           /* initial fingerprint */
    state->fingerprint[1] = 0x85A308D3L;
    state->fingerprint[2] = 0x13198A2EL;
    state->fingerprint[3] = 0x03707344L;
    state->fingerprint[4] = 0xA4093822L;
    state->fingerprint[5] = 0x299F31D0L;
    state->fingerprint[6] = 0x082EFA98L;
    state->fingerprint[7] = 0xEC4E6C89L;
}

/*
 * hash a string of specified length.
 * to be used in conjunction with haval_start and haval_end.
 */
void haval_hash (haval_state *state,
                 unsigned char *str, unsigned int str_len)
{
  unsigned int i,
           rmd_len,
           fill_len;

  /* calculate the number of bytes in the remainder */
  rmd_len  = (unsigned int)((state->count[0] >> 3) & 0x7F);
  fill_len = 128 - rmd_len;

  /* update the number of bits */
  if ((state->count[0] +=  (haval_word)str_len << 3)
                        < ((haval_word)str_len << 3)) {
     state->count[1]++;
  }
  state->count[1] += (haval_word)str_len >> 29;

#ifdef LITTLE_ENDIAN

  /* hash as many blocks as possible */
  if (rmd_len + str_len >= 128) {
    memcpy (((unsigned char *)state->block)+rmd_len, str, fill_len);
    haval_hash_block (state);
    for (i = fill_len; i + 127 < str_len; i += 128){
      memcpy ((unsigned char *)state->block, str+i, 128);
      haval_hash_block (state);
    }
    rmd_len = 0;
  } else {
    i = 0;
  }
  memcpy (((unsigned char *)state->block)+rmd_len, str+i, str_len-i);

#else

  /* hash as many blocks as possible */
  if (rmd_len + str_len >= 128) {
    memcpy (&state->remainder[rmd_len], str, fill_len);
    ch2uint(state->remainder, state->block, 128);
    haval_hash_block (state);
    for (i = fill_len; i + 127 < str_len; i += 128){
      memcpy (state->remainder, str+i, 128);
      ch2uint(state->remainder, state->block, 128);
      haval_hash_block (state);
    }
    rmd_len = 0;
  } else {
    i = 0;
  }
  /* save the remaining input chars */
  memcpy (&state->remainder[rmd_len], str+i, str_len-i);

#endif
}

/* finalization */
void haval_end (haval_state *state, unsigned char *final_fpt)
{
  unsigned char tail[10];
  unsigned int  rmd_len, pad_len;

  /*
   * save the version number, the number of passes, the fingerprint 
   * length and the number of bits in the unpadded message.
   */
  tail[0] = (unsigned char)(((FPTLEN  & 0x3) << 6) |
                            ((PASS    & 0x7) << 3) |
                             (VERSION & 0x7));
  tail[1] = (unsigned char)((FPTLEN >> 2) & 0xFF);
  uint2ch (state->count, &tail[2], 2);

  /* pad out to 118 mod 128 */
  rmd_len = (unsigned int)((state->count[0] >> 3) & 0x7f);
  pad_len = (rmd_len < 118) ? (118 - rmd_len) : (246 - rmd_len);
  haval_hash (state, padding, pad_len);

  /*
   * append the version number, the number of passes,
   * the fingerprint length and the number of bits
   */
  haval_hash (state, tail, 10);

  /* tailor the last output */
  haval_tailor(state);

  /* translate and save the final fingerprint */
  uint2ch (state->fingerprint, final_fpt, FPTLEN >> 5);

  /* clear the state information */
  memset ((unsigned char *)state, 0, sizeof (*state));
}

/* hash a 32-word block */
void haval_hash_block (haval_state *state)
{
  register haval_word t0 = state->fingerprint[0],    /* make use of */
                      t1 = state->fingerprint[1],    /* internal registers */
                      t2 = state->fingerprint[2],
                      t3 = state->fingerprint[3],
                      t4 = state->fingerprint[4],
                      t5 = state->fingerprint[5],
                      t6 = state->fingerprint[6],
                      t7 = state->fingerprint[7],
                      *w = state->block;

  /* Pass 1 */
  FF_1(t7, t6, t5, t4, t3, t2, t1, t0, *(w   ));
  FF_1(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 1));
  FF_1(t5, t4, t3, t2, t1, t0, t7, t6, *(w+ 2));
  FF_1(t4, t3, t2, t1, t0, t7, t6, t5, *(w+ 3));
  FF_1(t3, t2, t1, t0, t7, t6, t5, t4, *(w+ 4));
  FF_1(t2, t1, t0, t7, t6, t5, t4, t3, *(w+ 5));
  FF_1(t1, t0, t7, t6, t5, t4, t3, t2, *(w+ 6));
  FF_1(t0, t7, t6, t5, t4, t3, t2, t1, *(w+ 7));

  FF_1(t7, t6, t5, t4, t3, t2, t1, t0, *(w+ 8));
  FF_1(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 9));
  FF_1(t5, t4, t3, t2, t1, t0, t7, t6, *(w+10));
  FF_1(t4, t3, t2, t1, t0, t7, t6, t5, *(w+11));
  FF_1(t3, t2, t1, t0, t7, t6, t5, t4, *(w+12));
  FF_1(t2, t1, t0, t7, t6, t5, t4, t3, *(w+13));
  FF_1(t1, t0, t7, t6, t5, t4, t3, t2, *(w+14));
  FF_1(t0, t7, t6, t5, t4, t3, t2, t1, *(w+15));

  FF_1(t7, t6, t5, t4, t3, t2, t1, t0, *(w+16));
  FF_1(t6, t5, t4, t3, t2, t1, t0, t7, *(w+17));
  FF_1(t5, t4, t3, t2, t1, t0, t7, t6, *(w+18));
  FF_1(t4, t3, t2, t1, t0, t7, t6, t5, *(w+19));
  FF_1(t3, t2, t1, t0, t7, t6, t5, t4, *(w+20));
  FF_1(t2, t1, t0, t7, t6, t5, t4, t3, *(w+21));
  FF_1(t1, t0, t7, t6, t5, t4, t3, t2, *(w+22));
  FF_1(t0, t7, t6, t5, t4, t3, t2, t1, *(w+23));

  FF_1(t7, t6, t5, t4, t3, t2, t1, t0, *(w+24));
  FF_1(t6, t5, t4, t3, t2, t1, t0, t7, *(w+25));
  FF_1(t5, t4, t3, t2, t1, t0, t7, t6, *(w+26));
  FF_1(t4, t3, t2, t1, t0, t7, t6, t5, *(w+27));
  FF_1(t3, t2, t1, t0, t7, t6, t5, t4, *(w+28));
  FF_1(t2, t1, t0, t7, t6, t5, t4, t3, *(w+29));
  FF_1(t1, t0, t7, t6, t5, t4, t3, t2, *(w+30));
  FF_1(t0, t7, t6, t5, t4, t3, t2, t1, *(w+31));

  /* Pass 2 */
  FF_2(t7, t6, t5, t4, t3, t2, t1, t0, *(w+ 5), 0x452821E6L);
  FF_2(t6, t5, t4, t3, t2, t1, t0, t7, *(w+14), 0x38D01377L);
  FF_2(t5, t4, t3, t2, t1, t0, t7, t6, *(w+26), 0xBE5466CFL);
  FF_2(t4, t3, t2, t1, t0, t7, t6, t5, *(w+18), 0x34E90C6CL);
  FF_2(t3, t2, t1, t0, t7, t6, t5, t4, *(w+11), 0xC0AC29B7L);
  FF_2(t2, t1, t0, t7, t6, t5, t4, t3, *(w+28), 0xC97C50DDL);
  FF_2(t1, t0, t7, t6, t5, t4, t3, t2, *(w+ 7), 0x3F84D5B5L);
  FF_2(t0, t7, t6, t5, t4, t3, t2, t1, *(w+16), 0xB5470917L);

  FF_2(t7, t6, t5, t4, t3, t2, t1, t0, *(w   ), 0x9216D5D9L);
  FF_2(t6, t5, t4, t3, t2, t1, t0, t7, *(w+23), 0x8979FB1BL);
  FF_2(t5, t4, t3, t2, t1, t0, t7, t6, *(w+20), 0xD1310BA6L);
  FF_2(t4, t3, t2, t1, t0, t7, t6, t5, *(w+22), 0x98DFB5ACL);
  FF_2(t3, t2, t1, t0, t7, t6, t5, t4, *(w+ 1), 0x2FFD72DBL);
  FF_2(t2, t1, t0, t7, t6, t5, t4, t3, *(w+10), 0xD01ADFB7L);
  FF_2(t1, t0, t7, t6, t5, t4, t3, t2, *(w+ 4), 0xB8E1AFEDL);
  FF_2(t0, t7, t6, t5, t4, t3, t2, t1, *(w+ 8), 0x6A267E96L);

  FF_2(t7, t6, t5, t4, t3, t2, t1, t0, *(w+30), 0xBA7C9045L);
  FF_2(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 3), 0xF12C7F99L);
  FF_2(t5, t4, t3, t2, t1, t0, t7, t6, *(w+21), 0x24A19947L);
  FF_2(t4, t3, t2, t1, t0, t7, t6, t5, *(w+ 9), 0xB3916CF7L);
  FF_2(t3, t2, t1, t0, t7, t6, t5, t4, *(w+17), 0x0801F2E2L);
  FF_2(t2, t1, t0, t7, t6, t5, t4, t3, *(w+24), 0x858EFC16L);
  FF_2(t1, t0, t7, t6, t5, t4, t3, t2, *(w+29), 0x636920D8L);
  FF_2(t0, t7, t6, t5, t4, t3, t2, t1, *(w+ 6), 0x71574E69L);

  FF_2(t7, t6, t5, t4, t3, t2, t1, t0, *(w+19), 0xA458FEA3L);
  FF_2(t6, t5, t4, t3, t2, t1, t0, t7, *(w+12), 0xF4933D7EL);
  FF_2(t5, t4, t3, t2, t1, t0, t7, t6, *(w+15), 0x0D95748FL);
  FF_2(t4, t3, t2, t1, t0, t7, t6, t5, *(w+13), 0x728EB658L);
  FF_2(t3, t2, t1, t0, t7, t6, t5, t4, *(w+ 2), 0x718BCD58L);
  FF_2(t2, t1, t0, t7, t6, t5, t4, t3, *(w+25), 0x82154AEEL);
  FF_2(t1, t0, t7, t6, t5, t4, t3, t2, *(w+31), 0x7B54A41DL);
  FF_2(t0, t7, t6, t5, t4, t3, t2, t1, *(w+27), 0xC25A59B5L);

  /* Pass 3 */
  FF_3(t7, t6, t5, t4, t3, t2, t1, t0, *(w+19), 0x9C30D539L);
  FF_3(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 9), 0x2AF26013L);
  FF_3(t5, t4, t3, t2, t1, t0, t7, t6, *(w+ 4), 0xC5D1B023L);
  FF_3(t4, t3, t2, t1, t0, t7, t6, t5, *(w+20), 0x286085F0L);
  FF_3(t3, t2, t1, t0, t7, t6, t5, t4, *(w+28), 0xCA417918L);
  FF_3(t2, t1, t0, t7, t6, t5, t4, t3, *(w+17), 0xB8DB38EFL);
  FF_3(t1, t0, t7, t6, t5, t4, t3, t2, *(w+ 8), 0x8E79DCB0L);
  FF_3(t0, t7, t6, t5, t4, t3, t2, t1, *(w+22), 0x603A180EL);

  FF_3(t7, t6, t5, t4, t3, t2, t1, t0, *(w+29), 0x6C9E0E8BL);
  FF_3(t6, t5, t4, t3, t2, t1, t0, t7, *(w+14), 0xB01E8A3EL);
  FF_3(t5, t4, t3, t2, t1, t0, t7, t6, *(w+25), 0xD71577C1L);
  FF_3(t4, t3, t2, t1, t0, t7, t6, t5, *(w+12), 0xBD314B27L);
  FF_3(t3, t2, t1, t0, t7, t6, t5, t4, *(w+24), 0x78AF2FDAL);
  FF_3(t2, t1, t0, t7, t6, t5, t4, t3, *(w+30), 0x55605C60L);
  FF_3(t1, t0, t7, t6, t5, t4, t3, t2, *(w+16), 0xE65525F3L);
  FF_3(t0, t7, t6, t5, t4, t3, t2, t1, *(w+26), 0xAA55AB94L);

  FF_3(t7, t6, t5, t4, t3, t2, t1, t0, *(w+31), 0x57489862L);
  FF_3(t6, t5, t4, t3, t2, t1, t0, t7, *(w+15), 0x63E81440L);
  FF_3(t5, t4, t3, t2, t1, t0, t7, t6, *(w+ 7), 0x55CA396AL);
  FF_3(t4, t3, t2, t1, t0, t7, t6, t5, *(w+ 3), 0x2AAB10B6L);
  FF_3(t3, t2, t1, t0, t7, t6, t5, t4, *(w+ 1), 0xB4CC5C34L);
  FF_3(t2, t1, t0, t7, t6, t5, t4, t3, *(w   ), 0x1141E8CEL);
  FF_3(t1, t0, t7, t6, t5, t4, t3, t2, *(w+18), 0xA15486AFL);
  FF_3(t0, t7, t6, t5, t4, t3, t2, t1, *(w+27), 0x7C72E993L);

  FF_3(t7, t6, t5, t4, t3, t2, t1, t0, *(w+13), 0xB3EE1411L);
  FF_3(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 6), 0x636FBC2AL);
  FF_3(t5, t4, t3, t2, t1, t0, t7, t6, *(w+21), 0x2BA9C55DL);
  FF_3(t4, t3, t2, t1, t0, t7, t6, t5, *(w+10), 0x741831F6L);
  FF_3(t3, t2, t1, t0, t7, t6, t5, t4, *(w+23), 0xCE5C3E16L);
  FF_3(t2, t1, t0, t7, t6, t5, t4, t3, *(w+11), 0x9B87931EL);
  FF_3(t1, t0, t7, t6, t5, t4, t3, t2, *(w+ 5), 0xAFD6BA33L);
  FF_3(t0, t7, t6, t5, t4, t3, t2, t1, *(w+ 2), 0x6C24CF5CL);

#if PASS >= 4
  /* Pass 4. executed only when PASS =4 or 5 */
  FF_4(t7, t6, t5, t4, t3, t2, t1, t0, *(w+24), 0x7A325381L);
  FF_4(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 4), 0x28958677L);
  FF_4(t5, t4, t3, t2, t1, t0, t7, t6, *(w   ), 0x3B8F4898L);
  FF_4(t4, t3, t2, t1, t0, t7, t6, t5, *(w+14), 0x6B4BB9AFL);
  FF_4(t3, t2, t1, t0, t7, t6, t5, t4, *(w+ 2), 0xC4BFE81BL);
  FF_4(t2, t1, t0, t7, t6, t5, t4, t3, *(w+ 7), 0x66282193L);
  FF_4(t1, t0, t7, t6, t5, t4, t3, t2, *(w+28), 0x61D809CCL);
  FF_4(t0, t7, t6, t5, t4, t3, t2, t1, *(w+23), 0xFB21A991L);

  FF_4(t7, t6, t5, t4, t3, t2, t1, t0, *(w+26), 0x487CAC60L);
  FF_4(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 6), 0x5DEC8032L);
  FF_4(t5, t4, t3, t2, t1, t0, t7, t6, *(w+30), 0xEF845D5DL);
  FF_4(t4, t3, t2, t1, t0, t7, t6, t5, *(w+20), 0xE98575B1L);
  FF_4(t3, t2, t1, t0, t7, t6, t5, t4, *(w+18), 0xDC262302L);
  FF_4(t2, t1, t0, t7, t6, t5, t4, t3, *(w+25), 0xEB651B88L);
  FF_4(t1, t0, t7, t6, t5, t4, t3, t2, *(w+19), 0x23893E81L);
  FF_4(t0, t7, t6, t5, t4, t3, t2, t1, *(w+ 3), 0xD396ACC5L);

  FF_4(t7, t6, t5, t4, t3, t2, t1, t0, *(w+22), 0x0F6D6FF3L);
  FF_4(t6, t5, t4, t3, t2, t1, t0, t7, *(w+11), 0x83F44239L);
  FF_4(t5, t4, t3, t2, t1, t0, t7, t6, *(w+31), 0x2E0B4482L);
  FF_4(t4, t3, t2, t1, t0, t7, t6, t5, *(w+21), 0xA4842004L);
  FF_4(t3, t2, t1, t0, t7, t6, t5, t4, *(w+ 8), 0x69C8F04AL);
  FF_4(t2, t1, t0, t7, t6, t5, t4, t3, *(w+27), 0x9E1F9B5EL);
  FF_4(t1, t0, t7, t6, t5, t4, t3, t2, *(w+12), 0x21C66842L);
  FF_4(t0, t7, t6, t5, t4, t3, t2, t1, *(w+ 9), 0xF6E96C9AL);

  FF_4(t7, t6, t5, t4, t3, t2, t1, t0, *(w+ 1), 0x670C9C61L);
  FF_4(t6, t5, t4, t3, t2, t1, t0, t7, *(w+29), 0xABD388F0L);
  FF_4(t5, t4, t3, t2, t1, t0, t7, t6, *(w+ 5), 0x6A51A0D2L);
  FF_4(t4, t3, t2, t1, t0, t7, t6, t5, *(w+15), 0xD8542F68L);
  FF_4(t3, t2, t1, t0, t7, t6, t5, t4, *(w+17), 0x960FA728L);
  FF_4(t2, t1, t0, t7, t6, t5, t4, t3, *(w+10), 0xAB5133A3L);
  FF_4(t1, t0, t7, t6, t5, t4, t3, t2, *(w+16), 0x6EEF0B6CL);
  FF_4(t0, t7, t6, t5, t4, t3, t2, t1, *(w+13), 0x137A3BE4L);
#endif

#if PASS == 5
  /* Pass 5. executed only when PASS = 5 */
  FF_5(t7, t6, t5, t4, t3, t2, t1, t0, *(w+27), 0xBA3BF050L);
  FF_5(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 3), 0x7EFB2A98L);
  FF_5(t5, t4, t3, t2, t1, t0, t7, t6, *(w+21), 0xA1F1651DL);
  FF_5(t4, t3, t2, t1, t0, t7, t6, t5, *(w+26), 0x39AF0176L);
  FF_5(t3, t2, t1, t0, t7, t6, t5, t4, *(w+17), 0x66CA593EL);
  FF_5(t2, t1, t0, t7, t6, t5, t4, t3, *(w+11), 0x82430E88L);
  FF_5(t1, t0, t7, t6, t5, t4, t3, t2, *(w+20), 0x8CEE8619L);
  FF_5(t0, t7, t6, t5, t4, t3, t2, t1, *(w+29), 0x456F9FB4L);

  FF_5(t7, t6, t5, t4, t3, t2, t1, t0, *(w+19), 0x7D84A5C3L);
  FF_5(t6, t5, t4, t3, t2, t1, t0, t7, *(w   ), 0x3B8B5EBEL);
  FF_5(t5, t4, t3, t2, t1, t0, t7, t6, *(w+12), 0xE06F75D8L);
  FF_5(t4, t3, t2, t1, t0, t7, t6, t5, *(w+ 7), 0x85C12073L);
  FF_5(t3, t2, t1, t0, t7, t6, t5, t4, *(w+13), 0x401A449FL);
  FF_5(t2, t1, t0, t7, t6, t5, t4, t3, *(w+ 8), 0x56C16AA6L);
  FF_5(t1, t0, t7, t6, t5, t4, t3, t2, *(w+31), 0x4ED3AA62L);
  FF_5(t0, t7, t6, t5, t4, t3, t2, t1, *(w+10), 0x363F7706L);

  FF_5(t7, t6, t5, t4, t3, t2, t1, t0, *(w+ 5), 0x1BFEDF72L);
  FF_5(t6, t5, t4, t3, t2, t1, t0, t7, *(w+ 9), 0x429B023DL);
  FF_5(t5, t4, t3, t2, t1, t0, t7, t6, *(w+14), 0x37D0D724L);
  FF_5(t4, t3, t2, t1, t0, t7, t6, t5, *(w+30), 0xD00A1248L);
  FF_5(t3, t2, t1, t0, t7, t6, t5, t4, *(w+18), 0xDB0FEAD3L);
  FF_5(t2, t1, t0, t7, t6, t5, t4, t3, *(w+ 6), 0x49F1C09BL);
  FF_5(t1, t0, t7, t6, t5, t4, t3, t2, *(w+28), 0x075372C9L);
  FF_5(t0, t7, t6, t5, t4, t3, t2, t1, *(w+24), 0x80991B7BL);

  FF_5(t7, t6, t5, t4, t3, t2, t1, t0, *(w+ 2), 0x25D479D8L);
  FF_5(t6, t5, t4, t3, t2, t1, t0, t7, *(w+23), 0xF6E8DEF7L);
  FF_5(t5, t4, t3, t2, t1, t0, t7, t6, *(w+16), 0xE3FE501AL);
  FF_5(t4, t3, t2, t1, t0, t7, t6, t5, *(w+22), 0xB6794C3BL);
  FF_5(t3, t2, t1, t0, t7, t6, t5, t4, *(w+ 4), 0x976CE0BDL);
  FF_5(t2, t1, t0, t7, t6, t5, t4, t3, *(w+ 1), 0x04C006BAL);
  FF_5(t1, t0, t7, t6, t5, t4, t3, t2, *(w+25), 0xC1A94FB6L);
  FF_5(t0, t7, t6, t5, t4, t3, t2, t1, *(w+15), 0x409F60C4L);
#endif

  state->fingerprint[0] += t0;
  state->fingerprint[1] += t1;
  state->fingerprint[2] += t2;
  state->fingerprint[3] += t3;
  state->fingerprint[4] += t4;
  state->fingerprint[5] += t5;
  state->fingerprint[6] += t6;
  state->fingerprint[7] += t7;
}

/* tailor the last output */
static void haval_tailor (haval_state *state)
{
  haval_word temp;

#if FPTLEN == 128
  temp = (state->fingerprint[7] & 0x000000FFL) | 
         (state->fingerprint[6] & 0xFF000000L) | 
         (state->fingerprint[5] & 0x00FF0000L) | 
         (state->fingerprint[4] & 0x0000FF00L);
  state->fingerprint[0] += rotate_right(temp,  8);

  temp = (state->fingerprint[7] & 0x0000FF00L) | 
         (state->fingerprint[6] & 0x000000FFL) | 
         (state->fingerprint[5] & 0xFF000000L) | 
         (state->fingerprint[4] & 0x00FF0000L);
  state->fingerprint[1] += rotate_right(temp, 16);

  temp  = (state->fingerprint[7] & 0x00FF0000L) | 
          (state->fingerprint[6] & 0x0000FF00L) | 
          (state->fingerprint[5] & 0x000000FFL) | 
          (state->fingerprint[4] & 0xFF000000L);
  state->fingerprint[2] += rotate_right(temp, 24);

  temp = (state->fingerprint[7] & 0xFF000000L) | 
         (state->fingerprint[6] & 0x00FF0000L) | 
         (state->fingerprint[5] & 0x0000FF00L) | 
         (state->fingerprint[4] & 0x000000FFL);
  state->fingerprint[3] += temp;

#elif FPTLEN == 160
  temp = (state->fingerprint[7] &  (haval_word)0x3F) | 
         (state->fingerprint[6] & ((haval_word)0x7F << 25)) |  
         (state->fingerprint[5] & ((haval_word)0x3F << 19));
  state->fingerprint[0] += rotate_right(temp, 19);

  temp = (state->fingerprint[7] & ((haval_word)0x3F <<  6)) | 
         (state->fingerprint[6] &  (haval_word)0x3F) |  
         (state->fingerprint[5] & ((haval_word)0x7F << 25));
  state->fingerprint[1] += rotate_right(temp, 25);

  temp = (state->fingerprint[7] & ((haval_word)0x7F << 12)) | 
         (state->fingerprint[6] & ((haval_word)0x3F <<  6)) |  
         (state->fingerprint[5] &  (haval_word)0x3F);
  state->fingerprint[2] += temp;

  temp = (state->fingerprint[7] & ((haval_word)0x3F << 19)) | 
         (state->fingerprint[6] & ((haval_word)0x7F << 12)) |  
         (state->fingerprint[5] & ((haval_word)0x3F <<  6));
  state->fingerprint[3] += temp >> 6; 

  temp = (state->fingerprint[7] & ((haval_word)0x7F << 25)) | 
         (state->fingerprint[6] & ((haval_word)0x3F << 19)) |  
         (state->fingerprint[5] & ((haval_word)0x7F << 12));
  state->fingerprint[4] += temp >> 12;

#elif FPTLEN == 192
  temp = (state->fingerprint[7] &  (haval_word)0x1F) | 
         (state->fingerprint[6] & ((haval_word)0x3F << 26));
  state->fingerprint[0] += rotate_right(temp, 26);

  temp = (state->fingerprint[7] & ((haval_word)0x1F <<  5)) | 
         (state->fingerprint[6] &  (haval_word)0x1F);
  state->fingerprint[1] += temp;

  temp = (state->fingerprint[7] & ((haval_word)0x3F << 10)) | 
         (state->fingerprint[6] & ((haval_word)0x1F <<  5));
  state->fingerprint[2] += temp >> 5;

  temp = (state->fingerprint[7] & ((haval_word)0x1F << 16)) | 
         (state->fingerprint[6] & ((haval_word)0x3F << 10));
  state->fingerprint[3] += temp >> 10;

  temp = (state->fingerprint[7] & ((haval_word)0x1F << 21)) | 
         (state->fingerprint[6] & ((haval_word)0x1F << 16));
  state->fingerprint[4] += temp >> 16;

  temp = (state->fingerprint[7] & ((haval_word)0x3F << 26)) | 
         (state->fingerprint[6] & ((haval_word)0x1F << 21));
  state->fingerprint[5] += temp >> 21;

#elif FPTLEN == 224
  state->fingerprint[0] += (state->fingerprint[7] >> 27) & 0x1F;
  state->fingerprint[1] += (state->fingerprint[7] >> 22) & 0x1F;
  state->fingerprint[2] += (state->fingerprint[7] >> 18) & 0x0F;
  state->fingerprint[3] += (state->fingerprint[7] >> 13) & 0x1F;
  state->fingerprint[4] += (state->fingerprint[7] >>  9) & 0x0F;
  state->fingerprint[5] += (state->fingerprint[7] >>  4) & 0x1F;
  state->fingerprint[6] +=  state->fingerprint[7]        & 0x0F;
#endif
}

# ifdef COMMENT

/*****************************************************************************/

        HAVAL (V.1) CERTIFICATION DATA 
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

PASS=3, FPTLEN=128:
HAVAL("") = C68F39913F901F3DDF44C707357A7D70

PASS=3, FPTLEN=160:
HAVAL("a") = 4DA08F514A7275DBC4CECE4A347385983983A830

PASS=4, FPTLEN=192:
HAVAL("HAVAL") = 0C1396D7772689C46773F3DAACA4EFA982ADBFB2F1467EEA

PASS=4, FPTLEN=224:
HAVAL("0123456789") = BEBD7816F09BAEECF8903B1B9BC672D9FA428E462BA699F814841529

PASS=5, FPTLEN=256:
HAVAL("abcdefghijklmnopqrstuvwxyz")
      = C9C7D8AFA159FD9E965CB83FF5EE6F58AEDA352C0EFF005548153A61551C38EE
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = B45CB6E62F2B1320E4F8F1B0B273D45ADD47C321FD23999DCF403AC37636D963

/*****************************************************************************/

	file "pi.frac" (must end w/ newline) :

243F6A8885A308D313198A2E03707344A4093822299F31D0082EFA98EC4E6C89452821E638D01377BE5466CF34E90C6CC0AC29B7C97C50DD3F84D5B5B54709179216D5D98979FB1BD1310BA698DFB5AC2FFD72DBD01ADFB7B8E1AFED6A267E96BA7C9045F12C7F9924A19947B3916CF70801F2E2858EFC16636920D871574E69A458FEA3F4933D7E0D95748F728EB658718BCD5882154AEE7B54A41DC25A59B5

/*****************************************************************************/

HAVAL certification data (PASS=3, FPTLEN=128):
HAVAL("") = C68F39913F901F3DDF44C707357A7D70
HAVAL("a") = 0CD40739683E15F01CA5DBCEEF4059F1
HAVAL("HAVAL") = DC1F3C893D17CC4EDD9AE94AF76A0AF0
HAVAL("0123456789") = D4BE2164EF387D9F4D46EA8EFB180CF5
HAVAL("abcdefghijklmnopqrstuvwxyz") = DC502247FB3EB8376109EDA32D361D82
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = DE5EB3F7D9EB08FAE7A07D68E3047EC6
HAVAL(File pi.frac) = 78DF3722C78E040D22A63355500803F8

HAVAL certification data (PASS=3, FPTLEN=160):
HAVAL("") = D353C3AE22A25401D257643836D7231A9A95F953
HAVAL("a") = 4DA08F514A7275DBC4CECE4A347385983983A830
HAVAL("HAVAL") = 8822BC6F3E694E73798920C77CE3245120DD8214
HAVAL("0123456789") = BE68981EB3EBD3F6748B081EE5D4E1818F9BA86C
HAVAL("abcdefghijklmnopqrstuvwxyz") = EBA9FA6050F24C07C29D1834A60900EA4E32E61B
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 97DC988D97CAAE757BE7523C4E8D4EA63007A4B9
HAVAL(File pi.frac) = A3A5D4AE1BADFB2435ECC4CAB92B012DB24874C1

HAVAL certification data (PASS=3, FPTLEN=192):
HAVAL("") = E9C48D7903EAF2A91C5B350151EFCB175C0FC82DE2289A4E
HAVAL("a") = B359C8835647F5697472431C142731FF6E2CDDCACC4F6E08
HAVAL("HAVAL") = 8DA26DDAB4317B392B22B638998FE65B0FBE4610D345CF89
HAVAL("0123456789") = DE561F6D818A760D65BDD2823ABE79CDD97E6CFA4021B0C8
HAVAL("abcdefghijklmnopqrstuvwxyz") = A25E1456E6863E7D7C74017BB3E098E086AD4BE0580D7056
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = DEF6653091E3005B43A61681014A066CD189009D00856EE7
HAVAL(File pi.frac) = 8E7A13CB0D4D6FEE34976E81392DC71E747B9B49638F7A17

HAVAL certification data (PASS=3, FPTLEN=224):
HAVAL("") = C5AAE9D47BFFCAAF84A8C6E7CCACD60A0DD1932BE7B1A192B9214B6D
HAVAL("a") = 731814BA5605C59B673E4CAAE4AD28EEB515B3ABC2B198336794E17B
HAVAL("HAVAL") = AD33E0596C575D7175E9F72361CA767C89E46E2609D88E719EE69AAA
HAVAL("0123456789") = EE345C97A58190BF0F38BF7CE890231AA5FCF9862BF8E7BEBBF76789
HAVAL("abcdefghijklmnopqrstuvwxyz") = 06AE38EBC43DB58BD6B1D477C7B4E01B85A1E7B19B0BD088E33B58D1
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 939F7ED7801C1CE4B32BC74A4056EEE6081C999ED246907ADBA880A7
HAVAL(File pi.frac) = C5C22E1A463BDD61823B68B0BD04E75ED41189D60F91628354D88913

HAVAL certification data (PASS=3, FPTLEN=256):
HAVAL("") = 4F6938531F0BC8991F62DA7BBD6F7DE3FAD44562B8C6F4EBF146D5B4E46F7C17
HAVAL("a") = 47C838FBB4081D9525A0FF9B1E2C05A98F625714E72DB289010374E27DB021D8
HAVAL("HAVAL") = 91850C6487C9829E791FC5B58E98E372F3063256BB7D313A93F1F83B426AEDCC
HAVAL("0123456789") = 63238D99C02BE18C3C5DB7CCE8432F51329012C228CCC17EF048A5D0FD22D4AE
HAVAL("abcdefghijklmnopqrstuvwxyz") = 72FAD4BDE1DA8C8332FB60561A780E7F504F21547B98686824FC33FC796AFA76
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 899397D96489281E9E76D5E65ABAB751F312E06C06C07C9C1D42ABD31BB6A404
HAVAL(File pi.frac) = DC2E548796DDA1BD4D575B2249BFBC59BE2902B1DA045F88891DEB43369D0CFD

HAVAL certification data (PASS=4, FPTLEN=128):
HAVAL("") = EE6BBF4D6A46A679B3A856C88538BB98
HAVAL("a") = 5CD07F03330C3B5020B29BA75911E17D
HAVAL("HAVAL") = 958195D3DAC591030EAA0292A37A0CF2
HAVAL("0123456789") = 2215D3702A80025C858062C53D76CBE5
HAVAL("abcdefghijklmnopqrstuvwxyz") = B2A73B99775FFB17CD8781B85EC66221
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = CAD57C0563BDA208D66BB89EB922E2A2
HAVAL(File pi.frac) = 10A3B1BAA6C34BDD72CA03D9855BEE19

HAVAL certification data (PASS=4, FPTLEN=160):
HAVAL("") = 1D33AAE1BE4146DBAACA0B6E70D7A11F10801525
HAVAL("a") = E0A5BE29627332034D4DD8A910A1A0E6FE04084D
HAVAL("HAVAL") = 221BA4DD206172F12C2EBA3295FDE08D25B2F982
HAVAL("0123456789") = E387C743D14DF304CE5C7A552F4C19CA9B8E741C
HAVAL("abcdefghijklmnopqrstuvwxyz") = 1C7884AF86D11AC120FE5DF75CEE792D2DFA48EF
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 148334AAD24B658BDC946C521CDD2B1256608C7B
HAVAL(File pi.frac) = 2983B32D6B0B76498BD6D94966BBF1A16D87DA13

HAVAL certification data (PASS=4, FPTLEN=192):
HAVAL("") = 4A8372945AFA55C7DEAD800311272523CA19D42EA47B72DA
HAVAL("a") = 856C19F86214EA9A8A2F0C4B758B973CCE72A2D8FF55505C
HAVAL("HAVAL") = 0C1396D7772689C46773F3DAACA4EFA982ADBFB2F1467EEA
HAVAL("0123456789") = C3A5420BB9D7D82A168F6624E954AAA9CDC69FB0F67D785E
HAVAL("abcdefghijklmnopqrstuvwxyz") = 2E2E581D725E799FDA1948C75E85A28CFE1CF0C6324A1ADA
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = E5C9F81AE0B31FC8780FC37CB63BB4EC96496F79A9B58344
HAVAL(File pi.frac) = 7714262AD7D5E7ACE5F38E2F5AA16DBD61788E0F950C4DB8

HAVAL certification data (PASS=4, FPTLEN=224):
HAVAL("") = 3E56243275B3B81561750550E36FCD676AD2F5DD9E15F2E89E6ED78E
HAVAL("a") = 742F1DBEEAF17F74960558B44F08AA98BDC7D967E6C0AB8F799B3AC1
HAVAL("HAVAL") = 85538FFC06F3B1C693C792C49175639666F1DDE227DA8BD000C1E6B4
HAVAL("0123456789") = BEBD7816F09BAEECF8903B1B9BC672D9FA428E462BA699F814841529
HAVAL("abcdefghijklmnopqrstuvwxyz") = A0AC696CDB2030FA67F6CC1D14613B1962A7B69B4378A9A1B9738796
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 3E63C95727E0CD85D42034191314401E42AB9063A94772647E3E8E0F
HAVAL(File pi.frac) = 2491A1689A35DFE63C4B4F6810E676133F44412C5ADC959478DDB9F8

HAVAL certification data (PASS=4, FPTLEN=256):
HAVAL("") = C92B2E23091E80E375DADCE26982482D197B1A2521BE82DA819F8CA2C579B99B
HAVAL("a") = E686D2394A49B44D306ECE295CF9021553221DB132B36CC0FF5B593D39295899
HAVAL("HAVAL") = E20643CFA66F5BE2145D13ED09C2FF622B3F0DA426A693FA3B3E529CA89E0D3C
HAVAL("0123456789") = ACE5D6E5B155F7C9159F6280327B07CBD4FF54143DC333F0582E9BCEB895C05D
HAVAL("abcdefghijklmnopqrstuvwxyz") = 124F6EB645DC407637F8F719CC31250089C89903BF1DB8FAC21EA4614DF4E99A
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 46A3A1DFE867EDE652425CCD7FE8006537EAD26372251686BEA286DA152DC35A
HAVAL(File pi.frac) = E8162C7F8A83FF15549CD84B991333A5B3851A0FC600B513B25B69EC17B58AFC

HAVAL certification data (PASS=5, FPTLEN=128):
HAVAL("") = 184B8482A0C050DCA54B59C7F05BF5DD
HAVAL("a") = F23FBE704BE8494BFA7A7FB4F8AB09E5
HAVAL("HAVAL") = C97990F4FCC8FBA76AF935C405995355
HAVAL("0123456789") = 466FDCD81C3477CAC6A31FFA1C999CA8
HAVAL("abcdefghijklmnopqrstuvwxyz") = 0EFFF71D7D14344CBA1F4B25F924A693
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 4B27D04DDB516BDCDFEB96EB8C7C8E90
HAVAL(File pi.frac) = 7BCF71603BA4B06DA1807B3553A32A9D

HAVAL certification data (PASS=5, FPTLEN=160):
HAVAL("") = 255158CFC1EED1A7BE7C55DDD64D9790415B933B
HAVAL("a") = F5147DF7ABC5E3C81B031268927C2B5761B5A2B5
HAVAL("HAVAL") = 7730CA184CEA2272E88571A7D533E035F33B1096
HAVAL("0123456789") = 41CC7C1267E88CEF0BB93697D0B6C8AFE59061E6
HAVAL("abcdefghijklmnopqrstuvwxyz") = 917836A9D27EED42D406F6002E7D11A0F87C404C
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 6DDBDE98EA1C4F8C7F360FB9163C7C952680AA70
HAVAL(File pi.frac) = 6B20574F400699BE71CBFDBD9FEE4BB922FEDF8C

HAVAL certification data (PASS=5, FPTLEN=192):
HAVAL("") = 4839D0626F95935E17EE2FC4509387BBE2CC46CB382FFE85
HAVAL("a") = 5FFA3B3548A6E2CFC06B7908CEB5263595DF67CF9C4B9341
HAVAL("HAVAL") = 794A896D1780B76E2767CC4011BAD8885D5CE6BD835A71B8
HAVAL("0123456789") = A0B635746E6CFFFFD4B4A503620FEF1040C6C0C5C326476E
HAVAL("abcdefghijklmnopqrstuvwxyz") = 85F1F1C0ECA04330CF2DE5C8C83CF85A611B696F793284DE
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = D651C8AC45C9050810D9FD64FC919909900C4664BE0336D0
HAVAL(File pi.frac) = 4F656849D05EFC42EAF3C603DB4435DDCED1985297070A47

HAVAL certification data (PASS=5, FPTLEN=224):
HAVAL("") = 4A0513C032754F5582A758D35917AC9ADF3854219B39E3AC77D1837E
HAVAL("a") = 67B3CB8D4068E3641FA4F156E03B52978B421947328BFB9168C7655D
HAVAL("HAVAL") = 9D7AE77B8C5C8C1C0BA854EBE3B2673C4163CFD304AD7CD527CE0C82
HAVAL("0123456789") = 59836D19269135BC815F37B2AEB15F894B5435F2C698D57716760F2B
HAVAL("abcdefghijklmnopqrstuvwxyz") = 1B360ACFF7806502B5D40C71D237CC0C40343D2000AE2F65CF487C94
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = 180AED7F988266016719F60148BA2C9B4F5EC3B9758960FC735DF274
HAVAL(File pi.frac) = 76A6D848358C9883BB28CA358A34558CD13FD9EC5DFDF7DBBCBF629B

HAVAL certification data (PASS=5, FPTLEN=256):
HAVAL("") = BE417BB4DD5CFB76C7126F4F8EEB1553A449039307B1A3CD451DBFDC0FBBE330
HAVAL("a") = DE8FD5EE72A5E4265AF0A756F4E1A1F65C9B2B2F47CF17ECF0D1B88679A3E22F
HAVAL("HAVAL") = 153D2C81CD3C24249AB7CD476934287AF845AF37F53F51F5C7E2BE99BA28443F
HAVAL("0123456789") = 357E2032774ABBF5F04D5F1DEC665112EA03B23E6E00425D0DF75EA155813126
HAVAL("abcdefghijklmnopqrstuvwxyz") = C9C7D8AFA159FD9E965CB83FF5EE6F58AEDA352C0EFF005548153A61551C38EE
HAVAL("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
      = B45CB6E62F2B1320E4F8F1B0B273D45ADD47C321FD23999DCF403AC37636D963
HAVAL(File pi.frac) = AABF0B45AC4A4E84268F50ABCC3EF3806BCC9860EA6A92425F537C46A957963A

/*****************************************************************************/

# endif /* COMMENT */

# endif /* HAVAL1 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu ts=4
 */
