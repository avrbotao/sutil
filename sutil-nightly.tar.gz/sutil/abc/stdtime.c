
/*		 _______________________________________________________________
 *		|																|
 *		|	stdtime.c						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifdef LABIX

#	define	USE_STDIO
#	define	USE_STDTYP
#	define	USE_STDMATH
#	define	USE_STDTIME
#	include	"abc.h"

# else /* PLAIN */

# include  <stdio.h>
# include  <time.h>
# include  "stdmath.h"
# include  "stdtime.h"

# endif /* LABIX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef GCDTIMES

# include <sys/time.h>

BINT diftod (tvp1, tvp2) struct timeval * tvp1, * tvp2 ; {

	BINT sec1, sec2, usec1, usec2, d ;

	sec1 = tvp1->tv_sec ;
	sec2 = tvp2->tv_sec ;
	usec1 = tvp1->tv_usec ;
	usec2 = tvp2->tv_usec ;

	d = (1000000 * (sec2 - sec1)) + (usec2 - usec1) ;

	return d ;
}

char * fmtus (t) BINT t ; {

	BINT u, s, m, h ;
	static char b [64] ;

	u = t % 1000000 ;
	s = t / 1000000 ;
	m = s / 60 ;
	h = m / 60 ;

	sprintf (b, "%02lld:%02lld:%02lld:%06lld", h, m, s, u) ;

	return b ;
}

# endif /* GCDTIMES */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef CHRON_TIME			/* using time()				*/

time_t	gc1time, gc2time, gcdtime ;

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock() - wraps around after 2147 secs		*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * monport [] = {
	"jan" , "fev" , "mar" , "abr" , "mai" , "jun" ,
	"jul" , "ago" , "set" , "out" , "nov" , "dez" ,
	NULL
} ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void setchron (int flg) {		/* start chronometer		*/

# ifdef CHRON_TIME			/* using time()				*/

	if (flg & CF_TIME) {
		time (&gc1time) ;
	}

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock()			*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

}

void endchron (int flg) {		/* stop chronometer			*/

# ifdef CHRON_TIME			/* using time()				*/

	if (flg & CF_TIME) {
		time (&gc2time) ;
	}

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock()			*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

}

void difchron (int flg) {		/* eval chronometer			*/

# ifdef CHRON_TIME			/* using time()				*/

	if (flg & CF_TIME) {
		gcdtime = gc2time - gc1time ;
	}

# endif /* CHRON_TIME */

# ifdef CHRON_FTIM			/* using ftime()			*/

# endif /* CHRON_FTIM */

# ifdef CHRON_CLOK			/* using clock()			*/

# endif /* CHRON_CLOK */

# ifdef CHRON_GTOD			/* using gettimeofday()		*/

# endif /* CHRON_GTOD */

# ifdef CHRON_GHRT			/* using gethrtime()		*/

# endif /* CHRON_GHRT */

# ifdef CHRON_GRUS			/* using getrusage()		*/

# endif /* CHRON_GRUS */

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# if defined ( AIX ) || defined ( BSD )
# define	TLOC        time_t
# else
# define	TLOC        long
# endif

char * strtime (tloc) TLOC tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%02d:%02d:%02d" ,

				tp->tm_hour , tp->tm_min , tp->tm_sec ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * strhourmin (tloc) TLOC tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%02d:%02d" , tp->tm_hour , tp->tm_min ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * strdate (tloc) TLOC tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%4d/%02d/%02d" ,

				tp->tm_year + 1900 , tp->tm_mon + 1 , tp->tm_mday ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * strdaymon (tloc) TLOC tloc ; {

	static char buf [16] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%02d/%3s" , tp->tm_mday , monport[tp->tm_mon] ) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * timestamp (tloc) TLOC tloc ; {

	static char buf [64] ;
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	sprintf ( buf , "%4d.%02d.%02d+%02d:%02d:%02d" ,

				tp->tm_year + 1900 , tp->tm_mon + 1 , tp->tm_mday ,
				tp->tm_hour , tp->tm_min , tp->tm_sec				) ;

	return buf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void timechop (tloc, yearp, monp, dayp, hourp, minp, secp)
TLOC tloc ; int * yearp, * monp, * dayp, * hourp, * minp, * secp ;
{
	register struct tm * tp ;

	tp = localtime ( &tloc ) ;

	*dayp  = tp->tm_mday ;
	*monp  = tp->tm_mon + 1 ;
	*yearp = tp->tm_year + 1900 ;

	*hourp = tp->tm_hour ;
	*minp  = tp->tm_min ;
	*secp  = tp->tm_sec ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	SECONDS		* 1L
# define	MINUTES		* 60L
# define	HOURS		* 3600L
# define	DAYS		* 86400L
# define	MONTHS		* 2592000L
# define	YEARS		* 31536000L

long maketime (int year, int mon, int day, int hour, int min, int sec, int adj) {

	TLOC tloc = 0x00 ;

	if (adj) {
# ifdef TZADJ
		time (&tloc) ;
		tloc = localtime (&tloc) -> tm_tzadj ;
# endif /* TZADJ */
	}

	tloc += (year>1970?year-1970:year-70) YEARS ;
	tloc += (mon-1)  MONTHS ;
	tloc += (day-1)  DAYS ;
	tloc +=  hour    HOURS ;
	tloc +=  min     MINUTES ;
	tloc +=  sec     SECONDS ;

	return tloc ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
