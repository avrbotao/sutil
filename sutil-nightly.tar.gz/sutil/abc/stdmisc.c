
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdmisc.c					 miscellany stuff	|
 *		\ \/ /		|	(c) 1995-2006			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# ifdef LABIX

# define	USE_MATH
# define	USE_STDIO
# define	USE_CTYPE
# define	USE_UNISTD
# define	USE_SYSTYPES

# define	USE_STDTYP
# define	USE_STDASC
# define	USE_STDSTR
# define	USE_STDDIR
# define	USE_STDMISC
# define	USE_STDTIME
# define	USE_STDSTAT
# define	USE_STDLOGIC

# include	"abc.h"

# else /* PLAIN */

# include  <math.h>
# include  <time.h>
# include  <stdio.h>
# include  <ctype.h>
# include  <string.h>
# include  <unistd.h>

# include  <sys/types.h>
# include  <sys/stat.h>

# include  "abc.h"

# include  "stdasc.h"
# include  "stdtyp.h"
# include  "stdlogic.h"
# include  "stdmisc.h"

# endif /* LABIX */

char * strhms (ULONG) ;
char * lltokmgtpe (sbit64) ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# define	SETKMG(X)	kmg[3] = X ; kmg[4] = '\0' ;

char * ltokmg (x) long x ; {

	static char kmg [64] ;
	static char kc = 'K' , mc = 'M' , gc = 'G' , sc = ' ' ;
	double bval, kval, mval, gval ;

	bval = x ;

	if (bval < 1000) {
		sprintf (kmg, "%3d", (int) bval) ; SETKMG(sc) ;
		return kmg ;
	}

	kval = bval / 1024.0 ;

# ifdef DEBUG
	printf ("--> b %.9f k %.9f \n", bval, kval) ;
# endif

	if ( kval < 10.0 ) {
		sprintf (kmg, "%11.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	if ( kval < 1000.0 ) {
		sprintf (kmg, "%13.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	mval = bval / 1048576.0 ;

# ifdef DEBUG
	printf ("--> b %.9f m %.9f \n", bval, mval) ;
# endif

	if ( mval < 10.0 ) {
		sprintf (kmg, "%11.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	if ( mval < 1000.0 ) {
		sprintf (kmg, "%13.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	gval = bval / 1073741824.0 ;

# ifdef DEBUG
	printf ("--> b %.9f g %.9f \n", bval, gval) ;
# endif

	if ( gval < 10.0 ) {
		sprintf (kmg, "%11.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	if ( gval < 1000.0 ) {
		sprintf (kmg, "%13.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	return "????" ;
}

# ifdef NOLLTO

char * lltokmgtpe (x) sbit64 x ; {

	static char kmg [64] ;
	static char kc = 'K' , mc = 'M' , gc = 'G' , sc = ' ' ;
	static char tc = 'T' , pc = 'P' , ec = 'E' ;
	double bval, kval, mval, gval ;
	double       tval, pval, eval ;

	bval = x ;

	if (bval < 1000) {
		sprintf (kmg, "%3d", (int) bval) ; SETKMG(sc) ;
		return kmg ;
	}

	kval = bval / 1024.0 ;

# ifdef DEBUG
	printf ("--> b %.9f k %.9f \n", bval, kval) ;
# endif

	if ( kval < 10.0 ) {
		sprintf (kmg, "%11.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	if ( kval < 1000.0 ) {
		sprintf (kmg, "%13.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	mval = bval / 1048576.0 ;

# ifdef DEBUG
	printf ("--> b %.9f m %.9f \n", bval, mval) ;
# endif

	if ( mval < 10.0 ) {
		sprintf (kmg, "%11.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	if ( mval < 1000.0 ) {
		sprintf (kmg, "%13.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	gval = bval / 1073741824.0 ;

# ifdef DEBUG
	printf ("--> b %.9f g %.9f \n", bval, gval) ;
# endif

	if ( gval < 10.0 ) {
		sprintf (kmg, "%11.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	if ( gval < 1000.0 ) {
		sprintf (kmg, "%13.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	tval = bval / 1099511627776.0 ;

# ifdef DEBUG
	printf ("--> b %.9f t %.9f \n", bval, tval) ;
# endif

	if ( tval < 10.0 ) {
		sprintf (kmg, "%11.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	if ( tval < 1000.0 ) {
		sprintf (kmg, "%13.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	pval = bval / 1125899906842624.0 ;

# ifdef DEBUG
	printf ("--> b %.9f p %.9f \n", bval, pval) ;
# endif

	if ( pval < 10.0 ) {
		sprintf (kmg, "%11.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	if ( pval < 1000.0 ) {
		sprintf (kmg, "%13.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	eval = bval / 1152921504606846976.0 ;

# ifdef DEBUG
	printf ("--> b %.9f e %.9f \n", bval, eval) ;
# endif

	if ( eval < 10.0 ) {
		sprintf (kmg, "%11.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	if ( eval < 1000.0 ) {
		sprintf (kmg, "%13.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	return "????" ;
}

# endif /* NOLLTO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef NOSTRHMS

char * strhms (secs) ULONG secs ; {

	static char hms [32] ;
	ULONG n = secs ;
	int h, m, s ;

	if ( n == 0 )
		return "00:00:00" ;

	if ( ( h = n / 3600 ) > 0 )
		n -= h * 3600 ;

	if ( ( m = n / 60 ) > 0 )
		n -= m * 60 ;

	s = n ;

	sprintf (hms, "%02d:%02d:%02d", h, m, s) ;

	return hms ;
}

# endif /* NOSTRHMS */

/*----------------------------------------------------------------------*/
/*	ptrel : percent, time, rate & estimated left (u = [BKMG])			*/
/*	NNNu (PPP%) of TTTu in HH:MM:SS @ YYYu/s (HH:MM:SS left)			*/
/*	NNNu (PPP%) of TTTu in HH:MM:SS @ YYYu/s >>>>|||||| (HH:MM:SS left)	*/
/*----------------------------------------------------------------------*/

# define	BARYET		'|'
# define	BARPOK		'>'

int ptrel (sof, tot, flg) ULONG sof, tot, flg ; {

			ULONG	etl ;					/*	estimated time left		*/
			ULONG	dt, rt ;
	static	char	barbuf [16] ;
	static	time_t	t0 , tl ;
			time_t	tx ;
			int		pok , barlen = 10 , barpok , /* i, */ mtbs ;

	if ( sof == 0 ) {
		time (&t0) ;
		tl = t0 ;
		memset (barbuf, (int) BARYET, barlen) ;
		barbuf[barlen] = '\0' ;
# ifdef DEBUG
		printf (" 000  (  0%%) of %s in 00:00:00 @ ??? /s |||||||||| (??:??:?? left)\n",
				ltokmg (tot)) ;
# endif /* DEBUG */
		return 0 ;
	}

	time (&tx) ;

	mtbs = flg & 0x007f ;

	if ( mtbs <= 0 )
		mtbs = 1 ;

	if ( tx - tl < mtbs )
		return 0 ;

	dt = tx - t0 ;
	pok = ((double) sof * 100) / (double) tot ;
	barpok = ( barlen * pok ) / 100 ;
	memset (barbuf, (int) BARPOK, barpok) ;
	rt = sof / dt ;
	etl = (tot - sof) / rt ;
	tl = tx ;

	printf (" %s (%3d%%) of", ltokmg (sof), pok) ;
	printf (" %s in %s @", ltokmg (tot), strhms (dt)) ;
	printf (" %s/s %s (%s left) \r", ltokmg (rt), barbuf, strhms (etl)) ;
	fflush (stdout) ;

	if ( flg & PTE_NEWL )
		printf ("\n") ;

	return 0 ;
}

int ptrel64 (sof, tot, flg) sbit64 sof, tot ; ULONG flg ; {

			ULONG	etl ;					/*	estimated time left		*/
			ULONG	dt ;
			sbit64	rt ;
	static	char	barbuf [16] ;
	static	time_t	t0 , tl ;
			time_t	tx ;
			int		pok , barlen = 10 , barpok , /* i, */ mtbs ;

	if ( sof == 0 ) {
		time (&t0) ;
		tl = t0 ;
		memset (barbuf, (int) BARYET, barlen) ;
		barbuf[barlen] = '\0' ;
# ifdef DEBUG
		printf (" 000  (  0%%) of %s in 00:00:00 @ ??? /s |||||||||| (??:??:?? left)\n",
				lltokmgtpe (tot)) ;
# endif /* DEBUG */
		return 0 ;
	}

	time (&tx) ;

	mtbs = flg & 0x007f ;

	if ( mtbs <= 0 )
		mtbs = 3 ;

	if ( tx - tl < mtbs ) /* min secs between samples */
		return 0 ;

	dt = tx - t0 ;
	pok = (sof * 100) / tot ;
	barpok = ( barlen * pok ) / 100 ;
	memset (barbuf, (int) BARPOK, barpok) ;
	rt = sof / dt ;
	etl = (tot - sof) / rt ;
	tl = tx ;

	printf (" %s (%3d%%) of", lltokmgtpe (sof), pok) ;
	printf (" %s in %s @", lltokmgtpe (tot), strhms (dt)) ;
	printf (" %s/s %s (%s left) \r", lltokmgtpe (rt), barbuf, strhms (etl)) ;
	fflush (stdout) ;

	if ( flg & PTE_NEWL )
		printf ("\n") ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int strcount (s, c) char * s ; int c ; {

	int k ;
	char * p ;

	for ( k = 0 , p = s ; *p ; ++p ) {
		if ( *p == c )
			++k ;
	}

	return k ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void trimeol (s, l) char * s ; int l ; {

	int n ;

	for ( n = l ; n >= l - 2 ; --n )
		if ( s[n] == '\n' || s[n] == '\r' )
			s[n] = '\0' ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

/* index of the last occurrance of a char w/in a str */

int lastoc (s, c) char * s ; int c ; {

	register char * p = s ;
	register int i = -1 ;

	while (*p) {
		if (*p == c)
			i = (int) (p - s) ;		/* i = p - s ; */
		++p ;
	}

	return i ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * lastname (name) char * name ; {

	register char * tp ;

	tp = strrchr (name, DIRSEP) ;

	if (tp == NULL)
		return name ;

	if (*(tp+1) == NUL)
		return name ;
	else
		return tp + 1 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

STR bintos (buf) STR buf ; {

	FIX char war [512] ;
	REG STR bp = buf ;
	REG STR wp = war ;

	for ( ; *bp ; ++bp )
		if (*bp > ' ' && *bp <= '~')
			*wp++ = *bp ;
		else {
			switch (*bp) {
				case BS  : sprintf (wp, "\\b") ; wp += 2 ; break ;
				case FF  : sprintf (wp, "\\f") ; wp += 2 ; break ;
				case NL  : sprintf (wp, "\\n") ; wp += 2 ; break ;
				case CR  : sprintf (wp, "\\r") ; wp += 2 ; break ;
				case TAB : sprintf (wp, "\\t") ; wp += 2 ; break ;
				default  : sprintf (wp, "\\%03o", *bp) ; wp += 4 ; break ;
			}
		}
	*wp = NUL ;
	return (war) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

STR stobin (buf) STR buf ; {

	REG STR  mp = buf ;
	REG STR  rp = mp ;
	REG char od ;
	REG char nd ;

	while (*mp) {
		if (*mp == BACKSLASH)
			switch (*++mp) {
				case 'a' : *rp = BEL  ; break ;
				case 'b' : *rp = BS   ; break ;
				case 'e' : *rp = ESC  ; break ;
				case 'f' : *rp = FF   ; break ;
				case 'n' : *rp = NL   ; break ;
				case 'r' : *rp = CR   ; break ;
				case 's' : *rp = SPC  ; break ;
				case 't' : *rp = TAB  ; break ;
				case 'v' : *rp = VT   ; break ;
				case '"' : *rp = VANE ; break ;
				default :
					if (isupper ((int) *mp)) {
						*rp = *mp - AT ;
					} else if (isdigit ((int) *mp)) {
						for ( od = 0 , nd = 1 ; isdigit ((int) *mp) && nd <= 3 ;
						      ++mp , ++nd )
							od = (od << 3) + (*mp - '0') ;
						*rp = od ;
						--mp ;
					} else
						*rp = *mp ;
				break ;
			}
		else
			*rp = *mp ;
		++mp ; ++rp ;
	}
	*rp = NUL ;
	return (buf) ;
}

/*				 _______________________________________________________
 *				|														|
 *				|	xlltoa + long long to ascii conversion ...			|
 *				|_______________________________________________________|
 */

# define	MAXWID		128

char * xlltoa (val, wid, flg) sbit64 val ; int wid, flg ; {

	static char buf [MAXWID] = { '+' } ;
	register char * bp = buf + ( MAXWID - 1 ) ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}

/*	memset ( buf , NUL , MAXWID ) ; */

	do {
		if (flg & 0x08) {
			if ( (tk % 4) == 0 ) {
				*--bp = DOT ;
				++tk ;
			}
		}
		*--bp = '0' + (char) (val % 10) ;
		++tk ;
		if (tk >= wid)
			break ;
	} while ((val /= 10) > 0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}

	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	if (flg & 0x01) {
		while ( *bp == ' ' ) {
			++bp ;
		}
	}
	return bp ;
}

/*				 _______________________________________________________
 *				|														|
 *				|	xltoa + extra-fancy long to ascii conversion ...	|
 *				|_______________________________________________________|
 */

char * xltoa (val, wid, flg) long val ; int wid, flg ; {

	static char buf [MAXWID] = { '+' } ;
	register char * bp = buf + ( MAXWID - 1 ) ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}

/*	memset ( buf , NUL , MAXWID ) ; */

	do {
		if (flg & 0x08) {
			if ( (tk % 4) == 0 ) {
				*--bp = DOT ;
				++tk ;
			}
		}
		*--bp = '0' + (char) (val % 10) ;
		++tk ;
		if (tk >= wid)
			break ;
	} while ((val /= 10) > 0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}

	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

# ifdef COMMENT

# include <stdio.h>
# include <stdlib.h>

char * xltoa (long, int, int) ;

int main (argc, argv) int argc ; char * * argv ; {
	long x ;

	if (argc == 1) {
		printf ("use: xltoa long ...\n") ;
		return ;
	}

	printf (" 123456789000...   111.222.333.444  ") ;
	printf (" 123456789000...   111.222.333.444\n") ;

	while (*++argv) {
		x = atol (*argv) ;
		printf ( "|%15.15s| ", xltoa (x, 15, 0x00) ) ;
		printf ( "|%15.15s| |%15ld| (%s) \n",
				xltoa (x, 15, 0x08) , x , xltoa (x, 15, 0x08) ) ;
	}
}

# endif /* COMMENT */

/*______________________________________________________________________
 |																		|
 |	xdtoa + extra-fancy double to ascii conversion ...					|
 |______________________________________________________________________|
 */

# ifdef COMMENT

char * xdtoa (val, wid, flg) double val ; int wid, flg ; {
	static char buf [24] = { '+' } ;
	register char * bp = buf + 20 ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/
	double dblten = (double) 10 ;

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}

	do {
		if (flg & 0x08) {
			if ( (tk % 4) == 0 ) {
				*--bp = DOT ;
				++tk ;
			}
		}
		*--bp = '0' + (int) fmod (val, dblten) ;
		++tk ;
		if ((tk-1) >= wid)
			break ;
		val /= dblten ;
		if (val < 1000000000.0) {
			if ((long) val <= 0)
				break ;
		}
	} while (val > (double)0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}

	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

# endif /* COMMENT */

# ifdef COMMENT

# include <stdio.h>
# include <stdlib.h>

char * xdtoa (double, int, int) ;

int main (argc, argv) int argc ; char * * argv ; {
	double x ;

	if (argc == 1) {
		printf ("use: xdtoa double ...\n") ;
		return ;
	}

	printf (" 111222333444555   111.222.333.444\n") ;

	while (*++argv) {
		x = atof (*argv) ;
		printf ( "|%15.15s| ", xdtoa (x, 15, 0x00) ) ;
		printf ( "|%15.15s| %15.0lf\n", xdtoa (x, 15, 0x08) , x) ;
	}
}

# endif /* COMMENT */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

/*
 *		check if name is "." or ".."
 */

int dotdir (name) char * name ; {

	register int tj ;
	register char * tp = name ;

	tj = lastoc (name, DIRSEP) ;

	if (tj >= 0)
		tp += (tj+1) ;

	if ( *tp == DOT )
		if ( *(tp+1) == NUL )
			return TRUE ;
		else
			if ( *(tp+1) == DOT )
				if ( *(tp+2) == NUL )
					return TRUE ;
				else
					return FALSE ;
			else
				return FALSE ;
	else
		return FALSE ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int makedir (name) char * name ; {

# ifdef POSIX_MKDIR
	return mkdir (name, 0777) ;
# endif /* POSIX_MKDIR */

# ifdef SH_MKDIR
	char tb [512] ;

	sprintf (tb, "mkdir %s", name) ;
	return system (tb) ;
# endif /* SH_MKDIR */

# ifdef C_MKDIR
	return mkdir (name) ;
# endif /* C_MKDIR */

}

/************************************************************************
*	expand tabs 2 spaces (to, from, siz) ...							*
************************************************************************/

char * tabexp (expbuf, tabuf, tabsiz) char * expbuf , * tabuf ; int tabsiz ; {
	register char * tp = tabuf ;
	register int ts = tabsiz ;
	register char * ep = expbuf ;

	do {
		if (*tp != '\t') {
			*ep++ = *tp ;
			if (--ts == 0)
				ts = tabsiz ;
		} else {
			while (ts--)
				*ep++ = ' ' ;
			ts = tabsiz ;
		}
	} while (*tp++) ;

	return expbuf ;
}

/************************************************************************
*	tab expansion in static buffer ...									*
************************************************************************/

char * exptab (tabuf, tabsiz) char * tabuf ; int tabsiz ; {

	static char expbuf [512] ;
	register char * tp = tabuf ;
	register int ts = tabsiz ;
	register char * ep = expbuf ;

	do {
# ifdef COMMENT
		if (((ep+ts) - expbuf) > 512) {
			*ep = NUL ;
			break ;
		}
# endif
		if (*tp != '\t') {
			*ep++ = *tp ;
			if (--ts == 0)
				ts = tabsiz ;
		} else {
			while (ts--)
				*ep++ = ' ' ;
			ts = tabsiz ;
		}
	} while (*tp++) ;

	return expbuf ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

ULONG blkstokb (blks, bsiz) ULONG blks , bsiz ; {

	ULONG kbs ;

	if ( bsiz > 1024 ) {
		kbs = blks * ( bsiz / 1024 ) ;
	} else if ( bsiz == 1024 ) {
		kbs = blks ;
	} else if ( bsiz == 512 ) {
		kbs = blks >> 1 ;
	} else {
		kbs = ( blks * bsiz ) >> 10 ;
	}

	return kbs ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef COMMENT

char * itostr (int x) {

	static char s[32] ;

	sprintf (s, "%d", x) ;

	return s ;
}

# endif

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history ..............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v rls   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
