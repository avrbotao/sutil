
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDIO
# define	USE_UNISTD

# define	USE_STDASC
# define	USE_STDCAP
# define	USE_STDVIF
# define	USE_STDLOGIC
# define	USE_STDCOLOR

# include	"abc.h"

#ifdef CYGWIN
# include <ncurses/term.h>
#else
#if defined (SOLARIS) || defined (AIX)
# include <curses.h>
#endif
# include <term.h>
#endif

#if defined (SOLARIS) 
int byteout (char) ;
#endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef WIN32

# endif

# ifdef BCC55

# define MK_FP(S1,S2)	( ( S1 << 16 ) | S2 )

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef DOS

int			honkfreq = 500 /* HERTZ       */ ; 
int			honktime = 100 /* MILISECONDS */ ;

int far *	videoram = MK_FP (0xb800, 0x0000) ;
int			vramline = 0 ;
int			vramcol  = 0 ;

# define	VIDEORAM	(videoram+((vramline*linesize)+vramcol))

# endif /* DOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int			attrbyte = 0x0700 ;	/* _BGFG (backnorm, forenorm) << 8	*/

int			forenorm ;			/* foreground normal  text		*/
int			backnorm ;			/* background normal  text		*/

int			forerev  ;			/* foreground reverse text		*/
int			backrev  ;			/* background reverse text		*/

int			foreacs  ;			/* foreground graphic text		*/
int			backacs  ;			/* background graphic text		*/

int			monochrome = FALSE ;
int			monopaper  = FALSE ;

int			linesize = 80 /* DFL_LINESIZE */ ;
int			pagesize = 24 /* DFL_PAGESIZE */ ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef ANYX

extern	char *		cmbuf ;			/* cursor positioning (ansi)	*/
extern	char *		clbuf ;			/* clear screen 				*/
extern	char *		cebuf ;			/* clear to end-of-line			*/
extern	char *		sobuf ;			/* begin standout (reverse)		*/
extern	char *		sebuf ;			/* end   standout (reverse)		*/
extern	char *		usbuf ;			/* begin underline				*/
extern	char *		uebuf ;			/* end   underline				*/
extern	char *		mdbuf ;			/* begin highlight				*/
extern	char *		mbbuf ;			/* begin blink					*/
extern	char *		mebuf ;			/* end   highlight or blink		*/
extern	char *		blbuf ;			/* audible alarm bell ...		*/
extern	char *		ksbuf ;			/* begin "keypad xmit" mode		*/

# endif /* ANYX */

extern	int			terminal , colorok ;

extern	int			vfd /* = -1 */ ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void strout (buff, size) char * buff ; int size ; {

	register	char *	tp ;
				int		rd = 0 ;

	if (size <= 0) {
		for ( tp = buff ; *tp ; ++tp )	/* inline strlen() 4 speed ...	*/
			;
		size = (int) (tp - buff) ;
	}

	if (terminal)
		rd += write (vfd, buff, size) ;
	else {

# ifdef DOS

		register int far * vp = VIDEORAM ;

		vramcol += size ;

		for ( tp = buff ; size-- ; ++tp )
			*vp++ = (attrbyte | (*tp & 0x00ff)) ;

# endif /* DOS */

# ifdef WIN32

	/*	cputs (buff) ;	*/

		for ( tp = buff ; size-- ; ++tp )
			putch (*tp & 0x00ff) ;

# endif /* WIN32 */

# ifdef	ANYX

		rd += write (1, buff, size) ;

# endif /* ANYX */

	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void cursorat (int lin, int col) {

# ifdef DOS

	static unsigned oldbp ;

	if (terminal) {

		char tmpbuf [80] ;

		sprintf (tmpbuf, "\033[%d;%dH", lin+1, col+1) ;
		strout (tmpbuf, 0) ;

	} else {

		_DL = col ;
		_DH = lin ;
		_AH = 0x02 ; /* SET CURSOR POSITION */
		_BH = 0x00 ;

		_DI = _DI ; /* ???? */
		oldbp = _BP ;
		geninterrupt (0x10) ;
		_BP = oldbp ;

		vramline = lin ;
		vramcol  = col ;
	}

# endif /* DOS */

# ifdef WIN32

	HANDLE hso = GetStdHandle (STD_OUTPUT_HANDLE) ;
	COORD coord ;

	coord.X = col ;
	coord.Y = lin ;

	SetConsoleCursorPosition (hso, coord) ;

# endif /* WIN32 */

# ifdef ANYX

	tputs ( tgoto ( cmbuf, col, lin ) , 0 , byteout ) ;
	byteflush () ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void clearline () {

# ifdef DOS

	if (terminal)
		strout ("\033[K", 3) ;
	else {
		register int far * vp = VIDEORAM ;
		register int size = linesize - vramcol ;
		register int vspc = attrbyte | SPC ;

		while (size--)
			*vp++ = vspc ;
	}

# endif /* DOS */

# ifdef WIN32

		strout ("\033[K", 3) ; /* PIG! */

# endif /* WIN32 */

# ifdef ANYX

	tputs ( cebuf , 0 , byteout ) ;
	byteflush () ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void clearscreen () {

# ifdef DOS

	if (terminal)
		strout ("\033[H\033[J", 6) ;
	else {
		register int far * vp = videoram ;
		register int size = (pagesize + 2) * linesize ;
		register int vspc = attrbyte | SPC ;

		while (size--)
			*vp++ = vspc ;
	}

# endif /* DOS */

# ifdef WIN32

	system ("cls") ; /* PIG! */

# endif /* WIN32 */

# ifdef ANYX

	tputs ( clbuf , 0 , byteout ) ;
	byteflush () ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void normalvideo () {

# ifdef DOS

	if (terminal)
		if (monochrome)
			strout ("\033[0m", 4) ;
		else if (monopaper)
			strout ("\033[7m", 4) ;
		else
			termcolor (forenorm, backnorm) ;
	else
		attrbyte = _BGFG (backnorm, forenorm) << 8 ;

# endif /* DOS */

# ifdef WIN32

# endif /* WIN32 */

# ifdef ANYX

	if (monopaper) {
		putcap ( sobuf ) ;
	} else if (colorok) {
		termcolor (forenorm, backnorm) ;
	} else {
		putcap ( mebuf ) ;
	}

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void reversevideo () {

# ifdef DOS

	if (terminal)
		if (monochrome)
			strout ("\033[7m", 4) ;
		else if (monopaper)
			strout ("\033[0m", 4) ;
		else
			termcolor (forerev, backrev) ;
	else
		attrbyte = _BGFG (backrev, forerev) << 8 ;

# endif /* DOS */

# ifdef WIN32

# endif /* WIN32 */

# ifdef ANYX

	if (monopaper) {
		putcap ( mebuf ) ;
	} else if (colorok) {
		termcolor (forerev, backrev) ;
	} else {
		putcap ( sobuf ) ;
	}

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blinkvideo () {

# ifdef DOS

	if (terminal)
		if (monochrome || monopaper)
			strout ("\033[5m", 4) ;
		else {
			/* SET TERM BLINK ON */
			termcolor (forenorm, backnorm) ;
		}
	else
		attrbyte = 0x8000 | ( _BGFG (backnorm, forenorm) << 8 ) ;

# endif /* DOS */

# ifdef ANYX

	tputs ( mbbuf , 0 , byteout ) ;
	byteflush () ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void boldvideo () {

# ifdef DOS

	if (terminal)
		if (monochrome || monopaper)
			strout ("\033[1m", 4) ;
		else
			termcolor (forenorm, backnorm) ;
	else
		attrbyte = _BGFG (backnorm, forenorm) << 8 ;

# endif /* DOS */

# ifdef WIN32

# endif /* WIN32 */

# ifdef ANYX

	tputs ( mdbuf , 0 , byteout ) ;
	byteflush () ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void altchrset () {

# ifdef DOS

	if (terminal)
		if (monochrome)
			strout ("\033[0m", 4) ;
		else if (monopaper)
			strout ("\033[7m", 4) ;
		else
			termcolor (forenorm, backnorm) ;
	else
		attrbyte = _BGFG (backnorm, forenorm) << 8 ;

# endif /* DOS */

# ifdef WIN32

# endif /* WIN32 */

# ifdef ANYX

	extern char * asbuf ;

	putcap ( asbuf ) ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void dflchrset () {

# ifdef DOS

	if (terminal)
		if (monochrome)
			strout ("\033[0m", 4) ;
		else if (monopaper)
			strout ("\033[7m", 4) ;
		else
			termcolor (forenorm, backnorm) ;
	else
		attrbyte = _BGFG (backnorm, forenorm) << 8 ;

# endif /* DOS */

# ifdef WIN32

# endif /* WIN32 */

# ifdef ANYX

	extern char * aebuf ;

	putcap ( aebuf ) ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void colorvideo (int fore, int back) {

	if ( terminal ) {
		termcolor (fore, back) ;
	} else {
		attrbyte = _BGFG (back, fore) << 8 ;
	}

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef BCC55

delay (int howlong) {

}

sound (int freq) {

		strout ("\007", 1) ; /* PIG! */
}

nosound () {

		strout ("\007", 1) ; /* PIG! */
}

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void honk () {

# ifdef DOS

	if (terminal)
		strout ("\007", 1) ;
	else {
		sound (honkfreq) ;
		delay (honktime) ;
		nosound () ;
	}

# endif /* DOS */

# ifdef WIN32

		strout ("\007", 1) ; /* PIG! */

# endif /* WIN32 */

# ifdef ANYX

	tputs ( blbuf , 0 , byteout ) ;
	byteflush () ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:tabstop=4
 */
