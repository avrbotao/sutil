
/*		 _______________________________________________________________
 *		|																|
 *		|	stdrex.c					(c) 1998-2003 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifdef LABIX

# define	USE_STDIO

# define	USE_STDREX

# include	"abc.h"

# else /* PLAIN */

# include  <stdio.h>

# include  "abc.h"

# include  "stdrex.h"

# endif /* LABIX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef GNUREX
regex_t _rebuf_vrex_ ;
regmatch_t _rmbuf_vrex_ ;
# endif /* GNUREX */

# ifdef OLDREX
char * _reptr_vrex_ ;
char _maret_vrex_ [32] ;
# endif /* OLDREX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * vrexinit (re) char * re ; {

# ifdef GNUREX
	regcomp ( &_rebuf_vrex_, re, REG_NOSUB | REG_EXTENDED ) ;
	return (char *) &_rebuf_vrex_ ;
# endif /* GNUREX */

# ifdef OLDREX
	_reptr_vrex_ = regcmp ( re, (char *) 0 ) ;
	return (char *) _reptr_vrex_ ;
# endif /* OLDREX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int vrexmatch ( vrxp , subj ) char * vrxp , * subj ; {

# ifdef GNUREX
		if ( regexec ( (regex_t *) vrxp , subj , 0 , &_rmbuf_vrex_ , 0 ) == 0 )
			return 1 ;
		else
			return 0 ;
# endif /* GNUREX */

# ifdef OLDREX
		if ( regex ( (char *) vrxp , subj , _maret_vrex_ ) != NULL )
			return 1 ;
		else
			return 0 ;
# endif /* OLDREX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int vrexfree ( vrxp ) char * vrxp ; {

# ifdef GNUREX
	regfree ( (regex_t *) vrxp ) ;
# endif /* GNUREX */

# ifdef OLDREX
	free ( (char *) vrxp ) ;
# endif /* OLDREX */

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:tabstop=4
 */
