
/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	stdlog.c					(c) 1996-2003 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# define	USE_SYSTYPES
# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDTYP
# define	USE_STDLOG
# define	USE_STDMEM
/*
# define	USE_STDTIME
*/

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

FILE *	logfp = NULL ;

char *	logrec = NULL ;

int		logflags = 0x0000 ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int setlogent (logfilename) char * logfilename ; {

	logfp = fopen (logfilename, "w") ;

	if (logfp == NULL)
		return -1 ;

	logrec = (char *) xmalloc (LOGRECSIZ) ;

	if (logrec == NULL) {
		fclose (logfp) ;
		logfp = NULL ;
		return -2 ;
	}

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int	setlogopt (int flags) {

	return logflags |= flags ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int putlogent (first) char * first ; {

	REG char * * sp = &first ;
	REG char *   bp = logrec ;
	REG char *   tp ;

	for ( ; *sp ; ++sp )
		for ( tp = *sp ; *tp ; *bp++ = *tp++ )
			;

	*bp = '\0' ;

	fprintf (logfp, "%s\n", logrec) ;

	if (logflags & COMMITLOG)
		fflush (logfp) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void endlogent () {

	if (logfp != NULL)
		fclose (logfp) ;

	if (logrec != NULL)
		xmfree (logrec) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# include <time.h>

char * logstamp () {

# if defined ( AIX ) || defined ( BSD )
	time_t	tloc ;
# else
	long	tloc ;
# endif
	struct	tm * tp ;
	static	char tsbuf [32] ;

	time (&tloc) ;
	tp = localtime (&tloc) ;

	sprintf (tsbuf, "%04d/%02d/%02d+%02d:%02d:%02d",
		tp->tm_year + 1900, tp->tm_mon + 1, tp->tm_mday,
		tp->tm_hour, tp->tm_min, tp->tm_sec) ;

	return tsbuf ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef VARARGS1
#	include	<varargs.h>
# endif /* VARARGS1 */

# ifdef VARARGS1

void errmsg (type, format, va_alist) char * format ; va_dcl {

	va_list		args ;

	if ( type == CHKPT )
		if ( debugflag )
			fprintf (stderr, "DEBUG: ") ;
		else
			return ;

	if ( type == FATAL )
		fprintf (stderr, "FATAL: ") ;

	va_start (args) ;
	_doprnt (format, args, stderr) ;
	va_end (args) ;

	if (type == FATAL)
		exit (1) ;
}

# endif /* VARARGS1 */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef VARARGSX

void errmsg (type, fmt) char * fmt ; {

	register	char *	sp = fmt ;
	register	char *	pp = (char *) &fmt ;

				char    vc ;
				long	vl ;
				int     vi ;
				short   vs ;
# ifdef XFP_FMT
				float   vf ;
				double  vd ;
# endif
				char *  va ;

	if ( type == CHKPT )
		if ( debugflag )
			fprintf (stderr, "CKPT: ") ;
		else
			return ;

	if ( type == FATAL )
		fprintf (stderr, "FATAL: ") ;

	pp += sizeof (char *) ;

	while ( *sp ) {

		if ( *sp == '%' ) {

			switch ( *++sp ) {

				case 'c' :
					vc = (char) *((int *) pp) ;
					pp += sizeof (int) ;
					fprintf (stderr, "%c", vc) ;
				break ;

				case 'd' :
					vi = (int) *((int *) pp) ;
					pp += sizeof (int) ;
					fprintf (stderr, "%d", vi) ;
				break ;

				case 'D' :
					vl = (long) *((long *) pp) ;
					pp += sizeof (long) ;
					fprintf (stderr, "%ld", vl) ;
				break ;

				case 'h' :
					vs = (short) *((int *) pp) ;
					pp += sizeof (int) ;
					fprintf (stderr, "%d", vs) ;
				break ;

# ifdef XFP_FMT

				case 'f' :
					vf = (float) *((double *) pp) ;
					pp += sizeof (double) ;
					fprintf (stderr, "%g", vf) ;
				break ;

				case 'F' :
					vd = (double) *((double *) pp) ;
					pp += sizeof (double) ;
					fprintf (stderr, "%lf", vd) ;
				break ;

# endif /* XFP_FMT */

				case 's' :
					va = (char *) *((char **) pp) ;
					if ( va == NULL )
						va = "<NULL>" ;
					pp += sizeof (char *) ;
					fprintf (stderr, "%s", va) ;
				break ;

			} /* e-o-switch (*++sp) */

		} else /* *sp != '%' */ {

			fprintf (stderr, "%c", *sp) ;
		}

		sp++ ;

	} /* e-o-while (*sp) */

	if (type == FATAL)
		exit (1) ;
}

# endif /* VARARGSX */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/
