
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_FCNTL
# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDLOGIC
# define	USE_STDTYP
# define	USE_STDTIO
# define	USE_STDMSG
# define	USE_STDSTR

# include	"abc.h"

int			vfd = -1 ;
int			modeisok ;

# ifdef ANYX

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

TERMIO		origterm ;
TERMIO		workterm ;

# ifdef USE_TERMIOS
int tcgetattr(int fd, struct termios *termios_p);
int tcsetattr(int fd, int optional_actions, const struct termios *termios_p);
# endif /* USE_TERMIOS */

# if defined ( FreeBSD )
# include <sys/ioctl.h>
# else
int ioctl(int d, int request, ...);
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int initmode () {

	register int j ;
	int rd = 0 ;

	modeisok = FALSE ;

	vfd = open ("/dev/tty", 2) ;

	if (vfd < 0)
		return XE_CANT_OPEN_TTY ;

# ifdef USE_TERMIOS

	if ( tcgetattr (vfd, &origterm) < 0 )
		return XE_CANT_GET_TERM_ATTR ;

# else  /* TERMIO */

	if (ioctl (vfd, TCGETA, &origterm) < 0)
		return XE_CANT_GET_TERM_ATTR ;

# endif /* USE_TERMIOS */

	memcpy ( (STR) &workterm, (STR) &origterm, sizeof (TERMIO) ) ;

	for ( j = 0 ; j < C_CC_SIZE ; ++j )
		workterm.c_cc[j] = 0x00 ;

# ifdef ORIGCODE

	workterm.c_cc[VMIN]  = 1 ;
	workterm.c_oflag &= ~ ( OPOST  | TAB3 ) ;
	workterm.c_lflag &= ~ ( ICANON | ECHO | ISIG ) ;
	workterm.c_iflag &= ~ ( IGNCR  | IXON | IXANY | IXOFF ) ;

# else  /* FULLCODE */

    workterm.c_cc[VMIN] = 1 ;
    workterm.c_cc[VTIME] = 0 ;

# ifdef COMMENT
    workterm.c_cc[VSTART] = 0 ;
    workterm.c_cc[VSTOP] = 0 ;
# endif

    workterm.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|INLCR|IGNCR|ICRNL|IXON/*|IXANY|IXOFF*/) ;
    workterm.c_oflag &= ~(OPOST/*|OXTABS*/) ;
    workterm.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN) ;

	workterm.c_iflag &= ~ISTRIP ;
	workterm.c_cflag &= ~(CSIZE|PARENB) ;
	workterm.c_cflag |= CS8 ;

# endif /* ORIGCODE */

	rd += resetmode (&workterm) ;

	modeisok = TRUE ;

	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int origmode () {

	return resetmode (&origterm) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int workmode () {

	return resetmode (&workterm) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int resetmode (termbits) TERMIO * termbits ; {

# ifdef USE_TERMIOS

	if ( tcsetattr (vfd, TCSANOW, termbits) < 0)
		return XE_CANT_SET_TERM_ATTR ;

# else  /* TERMIO */

	if (ioctl (vfd, TCSETA, termbits) < 0)
		return XE_CANT_SET_TERM_ATTR ;

# endif /* USE_TERMIO */

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* ANYX */

void getscrsiz (rowsp, colsp) int * rowsp , * colsp ; {

# ifdef DOS

	char far * _rowp = MK_FP (0x0040, 0x0084) ;
	int  far * _colp = MK_FP (0x0040, 0x004a) ;
	int _rows, _cols ;

	_rows = (*_rowp) + 1 ;
	_cols = (unsigned char) *_colp ;

	*rowsp = _rows ;
	*colsp = _cols ;

# endif /* DOS */

# ifdef WIN32

# endif /* WIN32 */

# ifdef ANYX

	REG char * tp ;
	struct winsize wsb ;
	int rd ;

	/* first, try out ioctl () ... */

	rd = ioctl (1, TIOCGWINSZ, &wsb) ;

	if (rd == 0) {
		*rowsp = wsb.ws_row ;
		*colsp = wsb.ws_col ;
		return ;
	}

	/* otherwise check out env vars ... */

	tp = getenv ("LINES") ;

	if (tp == NULL)
		*rowsp = 24 ;
	else
		*rowsp = atoi (tp) ;

	tp = getenv ("COLUMNS") ;

	if (tp == NULL)
		*colsp = 80 ;
	else
		*colsp = atoi (tp) ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
