
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdclish.c		 command-line interface shell	|
 *		\ \/ /		|	(c) 2001				alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDLOGIC
# define	USE_STDCLISH

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long		clish = 0L ;			/* placeholder						*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	CLISH				512 /* 1024 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void loadclish ( cifunc , ciword ) CIFUNC cifunc ; char * ciword ; {

	define CIFUNC a la signal ...
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int initclish (envp) char * * envp ; {

	/* standard clish */

	loadclish ( ci_help,	"?"											) ;
	loadclish ( ci_shell,	"!"											) ;

	loadclish ( ci_about,	"about"										) ;
	loadclish ( ci_bye,		"bye"										) ;
	loadclish ( ci_debug,	"debug"										) ;
	loadclish ( ci_env,		"env"										) ;
	loadclish ( ci_bye,		"exit"										) ;
	loadclish ( ci_help,	"help"										) ;
	loadclish ( ci_prompt,	"prompt"									) ;
	loadclish ( ci_shell,	"shell"										) ;
	loadclish ( ci_status,	"status"									) ;
	loadclish ( ci_verbose,	"verbose"									) ;
	loadclish ( ci_quit,	"quit"										) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

