
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDLOGIC
# define	USE_STDASC
# define	USE_STDKEY
# define	USE_STDCMD
# define	USE_STDVIF

# include	"abc.h"

int		kbdreflect = FALSE ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int readcmd () {

	register int key ;
	register int cmd ;

	key = readkey () ;

	if (key >= SPC && key <= '~')
		return key ;

	switch (key) {

		case C_LEFT  :
		case CTRL_A  : cmd = XC_PREVWORD ; break ;

		case K_PGDN  :
		case CTRL_C  : cmd = XC_PAGEDOWN ; break ;

		case K_RIGHT :
		case CTRL_D  : cmd = XC_MOVERIGHT ; break ;

		case K_UP    :
		case CTRL_E  : cmd = XC_MOVEUP ; break ;

		case C_RIGHT :
		case CTRL_F  : cmd = XC_NEXTWORD ; break ;

		case 127	 : /* ascii DEL */
		case K_DEL   :
		case CTRL_G  : cmd = XC_DELCHAR ; break ;

		case CTRL_H  : cmd = XC_BACKSPACE ; break ;

		case CTRL_I  : cmd = XC_TAB ; break ;

		case CTRL_J  : cmd = XC_NEWLINE ; break ;

		case CTRL_K  :

			if (kbdreflect) {
				cursorat (0, 0) ;
				strout ("^K", 2) ;
			}

			key = readkey () ;

			if (kbdreflect) {
				cursorat (0, 0) ;
				reversevideo () ;
				strout ("  ", 2) ;
				normalvideo () ;
			}

			switch (key) {

				case 'a' :
				case 'A' :
				case CTRL_A : cmd = XC_SAVEAS ; break ;

				case 'b' :
				case 'B' :
				case CTRL_B : cmd = XC_BLOCKSTART ; break ;

				case 'c' :
				case 'C' :
				case CTRL_C : cmd = XC_BLOCKCOPY ; break ;

				case 'd' :
				case 'D' :
				case CTRL_D : cmd = XC_SAVEEDIT ; break ;

				case 'e' :
				case 'E' :
				case CTRL_E : cmd = XC_QUITEDIT ; break ;

				case 'h' :
				case 'H' :
				case CTRL_H : cmd = XC_BLOCKHIDE ; break ;

				case 'i' :
				case 'I' :
				case CTRL_I : cmd = XC_BLOCKPASTE ; break ;

				case 'k' :
				case 'K' :
				case CTRL_K : cmd = XC_BLOCKEND ; break ;

				case 'l' :
				case 'L' :
				case CTRL_L : cmd = XC_BLOCKLINE ;	break ;

				case 'o' :
				case 'O' :
				case CTRL_O : cmd = XC_BLOCKSAVE ;	break ;

				case 'n' :
				case 'N' :
				case CTRL_N : cmd = XC_QUITNEXT ; break ;

				case 'q' :
				case 'Q' :
				case CTRL_Q : cmd = XC_QUITEXIT ; break ;

				case 'r' :
				case 'R' :
				case CTRL_R : cmd = XC_BLOCKREAD ; break ;

				case 's' :
				case 'S' :
				case CTRL_S : cmd = XC_SAVECONT ; break ;

				case 't' :
				case 'T' :
				case CTRL_T : cmd = XC_BLOCKWORD ; break ;

				case 'v' :
				case 'V' :
				case CTRL_V : cmd = XC_BLOCKMOVE ; break ;

				case 'w' :
				case 'W' :
				case CTRL_W : cmd = XC_BLOCKWRITE ; break ;

				case 'x' :
				case 'X' :
				case CTRL_X : cmd = XC_SAVEEXIT ; break ;

				case 'y' :
				case 'Y' :
				case CTRL_Y : cmd = XC_BLOCKDEL ; break ;

				case 'z' :
				case 'Z' :
				case CTRL_Z : cmd = XC_QUITSWAP ; break ;

				case '1' : cmd = XC_HELP ; break ;
				case '2' : cmd = XC_SAVECONT ; break ;
				case '3' : cmd = XC_QUITEDIT ; break ;

				case '4' : cmd = XC_FINDTEXT ; break ;
				case '5' : cmd = XC_FINDNEXT ; break ;

				case '6' : cmd = XC_BLOCKLINE	;	break ;
				case '7' : cmd = XC_BLOCKSTART	;	break ;
				case '8' : cmd = XC_BLOCKEND		;	break ;

				case '0' : cmd = XC_QUITEXIT ; break ;

				case '-' : cmd = XC_FORECOLOR ; break ;
				case '=' : cmd = XC_BACKCOLOR ; break ;

				case ESC :
				default : cmd = XC_BAD ; break ;
			}

		break ;

		case CTRL_L : cmd = XC_FINDNEXT ; break ;

		case CTRL_M : cmd = XC_NEWLINE ; break ;

		case CTRL_O :

			if (kbdreflect) {
				cursorat (0, 0) ;
				strout ("^O", 2) ;
			}

			key = readkey () ;

			if (kbdreflect) {
				cursorat (0, 0) ;
				reversevideo () ;
				strout ("  ", 2) ;
				normalvideo () ;
			}

			switch (key) {

				case 'c' :
				case 'C' :
				case CTRL_C : cmd = XC_WHICHCOL ; break ;

				case 'd' :
				case 'D' :
				case CTRL_D : cmd = XC_DUPLINE ; break ;

				case 'g' :
				case 'G' :
				case CTRL_G : cmd = XC_PAGSIZE ; break ;

				case 'h' :
				case 'H' :
				case CTRL_H : cmd = XC_HELP ; break ;

				case 'i' :
				case 'I' :
				case CTRL_I : cmd = XC_INFO ; break ;

				case 'l' :
				case 'L' :
				case CTRL_L : cmd = XC_RELOADIT ; break ;

				case 'o' :
				case 'O' :
				case CTRL_O : cmd = XC_POPOPTIMIO ; break ;

				case 'p' :
				case 'P' :
				case CTRL_P : cmd = XC_REFRESH ; break ;

				case 'r' :
				case 'R' :
				case CTRL_R : cmd = XC_POPSCROLL ; break ;

				case 's' :
				case 'S' :
				case CTRL_S : cmd = XC_SHELL ; break ;

				case 't' :
				case 'T' :
				case CTRL_T : cmd = XC_TABSIZE ; break ;

				case 'w' :
				case 'W' :
				case CTRL_W : cmd = XC_PAGWID ; break ;

				case 'x' :
				case 'X' :
				case CTRL_X : cmd = XC_RUNCMD ; break ;

				case ESC :
				default : cmd = XC_BAD ; break ;
			}

		break ;

		case CTRL_Q :

			if (kbdreflect) {
				cursorat (0, 0) ;
				strout ("^Q", 2) ;
			}

			key = readkey () ;

			if (kbdreflect) {
				cursorat (0, 0) ;
				reversevideo () ;
				strout ("  ", 2) ;
				normalvideo () ;
			}

			switch (key) {

				case 'a' :
				case 'A' :
				case CTRL_A : cmd = XC_CHANGETEXT ; break ;

				case 'b' :
				case 'B' :
				case CTRL_B : cmd = XC_FINDSTART ; break ;

				case 'c' :
				case 'C' :
				case CTRL_C : cmd = XC_LASTPAGE ; break ;

				case 'd' :
				case 'D' :
				case CTRL_D : cmd = XC_ENDOFLINE ; break ;

				case 'e' :
				case 'E' :
				case CTRL_E : cmd = XC_PAGETOP ; break ;

				case 'f' :
				case 'F' :
				case CTRL_F : cmd = XC_FINDTEXT ; break ;

				case 'g' :
				case 'G' :
				case CTRL_G : cmd = XC_JOINLINE ; break ;

				case 'k' :
				case 'K' :
				case CTRL_K : cmd = XC_FINDEND ; break ;

				case 'l' :
				case 'L' :
				case CTRL_L : cmd = XC_GOTOLINE ; break ;

				case 'p' :
				case 'P' :
				case CTRL_P : cmd = XC_POPEXACT ; break ;

				case 'r' :
				case 'R' :
				case CTRL_R : cmd = XC_FIRSTPAGE ; break ;

				case 's' :
				case 'S' :
				case CTRL_S : cmd = XC_HOMELINE ; break ;

				case 'u' :
				case 'U' :
				case CTRL_U : cmd = XC_POPCASE ; break ;

				case 'x' :
				case 'X' :
				case CTRL_X : cmd = XC_PAGEBASE ; break ;

				case 'y' :
				case 'Y' :
				case CTRL_Y : cmd = XC_DELRIGHT ; break ;

				case ESC :
				default : cmd = XC_BAD ; break ;
			}

		break ;

		case K_PGUP :
		case CTRL_R : cmd = XC_PAGEUP ; break ;

		case K_LEFT :
		case CTRL_S : cmd = XC_MOVELEFT ; break ;

		case CTRL_T : cmd = XC_DELWORD ; break ;

# ifdef COMMENT
		case CTRL_U : /* cmd = XC_UNDO */ ; break ;
# endif /* COMMENT */

		case K_INS  :
		case CTRL_V : cmd = XC_POPINSERT ; break ;

		case C_DOWN :
		case CTRL_W : cmd = XC_ROLLDOWN ; break ;

		case K_DOWN :
		case CTRL_X : cmd = XC_MOVEDOWN ; break ;

		case CTRL_Y : cmd = XC_DELLINE ; break ;

		case C_UP	:
		case CTRL_Z : cmd = XC_ROLLUP ; break ;

		case K_END  : cmd = XC_ENDOFLINE ; break ;
		case K_HOME : cmd = XC_HOMELINE ; break ;

		case K_F1   : cmd = XC_HELP ; break ;
		case K_F2   : cmd = XC_SAVECONT ; break ;
		case K_F3	: cmd = XC_QUITEDIT ; break ;

		case K_F4	: cmd = XC_FINDTEXT ; break ;
		case K_F5	: cmd = XC_FINDNEXT ; break ;

		case K_F6	: cmd = XC_BLOCKLINE	;	break ;
		case K_F7	: cmd = XC_BLOCKSTART	;	break ;
		case K_F8	: cmd = XC_BLOCKEND		;	break ;

		case K_F9	: cmd = XC_RUNCMD		;	break ;

		case K_F10	: cmd = XC_QUITEXIT ; break ;

		case K_F11	: cmd = XC_SHELL ; break ;

		case K_F12	: cmd = XC_INFO ; break ;

		case S_F9	: cmd = XC_FORECOLOR ; break ;
		case S_F10	: cmd = XC_BACKCOLOR ; break ;

		case C_HOME : cmd = XC_PAGETOP  ; break ;
		case C_END  : cmd = XC_PAGEBASE ; break ;

		case C_PGUP : cmd = XC_FIRSTPAGE ; break ;
		case C_PGDN : cmd = XC_LASTPAGE  ; break ;

		case ESC : cmd = XC_ESC ; break ;

		default : cmd = XC_BAD ; break ;
	}

	return cmd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

