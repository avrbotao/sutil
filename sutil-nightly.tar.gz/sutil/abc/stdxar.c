
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdxar.c				 portable archive i/f	|
 *		\ \/ /		|	(c) 1998-2006			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define	USE_STDIO
# define	USE_STDLIB

# define	USE_SYSTYPES

# define	USE_STDLOGIC
# define	USE_STDMEM
# define	USE_STDTYP
# define	USE_STDSTR
# define	USE_STDASC
# define	USE_STDTIME
# define	USE_STDSTAT
# define	USE_STDMISC
# define	USE_STDXAR
# define	USE_STRLIST

# include	"abc.h"

# include	"signab.h"

# ifdef		DOS
#	include	<io.h>
# endif

# ifdef AIX
# include <unistd.h>
# endif

# ifdef HPUX
# include <unistd.h>
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char		tmphdr [MAXHDRLEN] ;
char *		hdrfld [MAXHDRFLD] ;

long		xarglops = 0x00000000L ;

STRLISTCTRL *	xarpats = NULL ;

	/********************************************************************/
	/*		friendly (no bull) interface ...							*/
	/********************************************************************/

XAR * setxarent	(name) char * name ; {

	register XAR * txp = NULL ;

	/* if exists (name.xar) then xaropen (RW) else (NEW) */

	txp = xaropen (name, XAR_RW) ;

	return txp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int endxarent (xd) XAR * xd ; {

	return xarclose (xd) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int setxaropt (opts) char * opts ; {

	register char * tp ;

	if (opts == NULL)
		return -1 ;

	for ( tp = opts ; *tp ; ++tp )
		switch (*tp) {
			case 'e' : xaroption (XAR_STDERR) ; break ;
			case 'o' : xaroption (XAR_STDOUT) ; break ;
			case 'v' : xaroption (XAR_VERBOSE) ; break ;
		}

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

XARENT * getxarent (xd) XAR * xd ; {

	register XARENT * xep ;

	xep = xarscan (xd) ;

	return xep;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void lstxarent (xep) XARENT * xep ; {

	xarshow (xep) ;
}

	/********************************************************************/
	/*		classic (full blown) interface ...							*/
	/********************************************************************/

XAR * xaropen (name, mode) char * name ; long mode ; {

	register XAR * txp = NULL ;
	char * actxar = NULL , * newxar = NULL , * tmpnam ;
	int tmptyp ;
	FILE * ifp = NULL , * ofp = NULL ;

	tmpnam = chkxarnam ( name , &tmptyp ) ;

	if ( mode & XAR_READ ) {

		actxar = strclone ( tmpnam ) ;

		if ( ( ifp = fopen (actxar, "rb") ) == NULL ) {

			if ( ( mode & XAR_OP ) != XAR_ADD ) {
				xarerror ("xaropen: can't open %s\n", actxar) ;
				goto mess ;
			} else {
				mode &= ~ XAR_READ ;
				mode |=   XAR_NEW ;
			}
		}
	}

	if ( mode & ( XAR_WRITE | XAR_NEW ) ) {

		newxar = strclone ( xarname (name, NEWEXT) ) ;

		if ( ( ofp = fopen (newxar, "wb") ) == NULL ) {
			xarerror ("xaropen: can't create %s\n", actxar) ;
			goto mess ;
		}
	}

	txp = NEW (XAR) ;

	if ( txp == NULL )
		goto mess ;

	txp->xd_name = strclone (name) ;
	txp->xd_actx = actxar ;
	txp->xd_newx = newxar ;
	txp->xd_ifpx = ifp ;
	txp->xd_ofpx = ofp ;
	txp->xd_ctrl = mode ;
	txp->xd_type = tmptyp ;
	txp->xd_tent = txp->xd_used = 0 ;
	txp->xd_usiz = 0L ;

	if ( xarglops != 0L )
		txp->xd_ctrl |= xarglops ;

	return txp ;

mess :

	if (actxar)
		xmfree (actxar) ;

	if (newxar)
		xmfree (newxar) ;

	if (txp)
		xmfree ( (char *) txp ) ;

	if (ifp)
		fclose (ifp) ;

	if (ofp)
		fclose (ofp) ;

	return NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int xarclose (xd) XAR * xd ; {

	if (xd == NULL)
		return -1 ;

	xmfree (xd->xd_name) ;
	xmfree (xd->xd_actx) ;
	xmfree (xd->xd_newx) ;

	if (xd->xd_ifpx)
		fclose (xd->xd_ifpx) ;

	if (xd->xd_ofpx)
		fclose (xd->xd_ofpx) ;

	xmfree ( (char *) xd ) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

XARENT * xarscan (xd) XAR * xd ; {

	register	XARENT *	xep ;
	register	char *		hp ;
	register	FILE *		ifp ;
				long		thofs , tdofs ;
				int			hdrtyp , fldcnt ;

	if (xd == NULL)
		return NULL ;

	ifp = xd->xd_ifpx ;

	thofs = ftell (ifp) ;

	if ( fgets (tmphdr, MAXHDRLEN, ifp) == NULL )
		return NULL ;

	if ( ( hdrtyp = chkxarhdr (tmphdr) ) == MADHDR )
		return NULL ;

	hp = strclone ( stripeol ( tmphdr ) ) ;

	/* alloc xar entry */

	xep = NEW (XARENT) ;

	if ( xep == NULL )
		goto mess2 ;

	tdofs = ftell (ifp) ;

	/* fill xar entry */

	if ( hdrtyp & SPCHDR ) {

		strchg (hp, HDRFLDSEP, '%') ;
		struniq (hp, SPC) ;
		strchg (hp, SPC, HDRFLDSEP) ;
	}

	fldcnt = strclip (hp, hdrfld, HDRFLDSEP) ;

	if ( fldcnt <= 0 )
		goto mess2 ;

	clrxarent (xep) ;

	if ( hdrtyp & KINHDR ) {

		xep->xe_osiz = atol ( hdrfld [1] ) ;
		xep->xe_name = strclone ( hdrfld [7] ) ;

	} else if ( hdrtyp & KITHDR ) {

		xep->xe_osiz = atol ( hdrfld [1] ) ;
		xep->xe_mtim = atol ( hdrfld [2] ) ;
		xep->xe_name = strclone ( hdrfld [7] ) ;

	} else if ( hdrtyp & XARHDR ) {

		xep->xe_osiz = atol ( hdrfld [1] ) ;
		xep->xe_mtim = atol ( hdrfld [2] ) ;
		xep->xe_mode = atol ( hdrfld [4] ) ;
		xep->xe_fcrc = atol ( hdrfld [5] ) ;
		xep->xe_name = strclone ( hdrfld [7] ) ;

	} else if ( hdrtyp & TARHDR ) {

	} else if ( hdrtyp & CPIOHDR ) {

	} else if ( hdrtyp & ZABHDR ) {

	} else {

		xmfree ( (char *) xep ) ;
		return NULL ;
	}

	xep->xe_hofs = thofs ;
	xep->xe_dofs = tdofs ;

	/*
	 *		must check 4 packed data b4 seek too long ...
	 */

	if ( xd->xd_ctrl & XAR_VIEW )
		fseek (ifp, xep->xe_osiz, SEEK_CUR) ;

	/* done 4 good | bad */

	if ( xarglops != 0L )
		xep->xe_ctrl |= xarglops ;

	goto ok1 ;

mess2 :

	if (xep)
		xmfree ( (char *) xep ) ;

ok1 :

	if (hp)
		xmfree (hp) ;

	return xep;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xarshow (xep) XARENT * xep ; {

	if ( ! ( xep->xe_ctrl & XAR_STDOUT ) )
		return ;

# ifdef DEBUG
	printf ("xarshow: xep  = %08.8lx \r\n", (long) xep) ;
	printf ("xarshow: mode = %012.12lo \r\n", (long) xep->xe_mode) ;
	printf ("xarshow: size = %ld \r\n", (long) xep->xe_osiz) ;
	printf ("xarshow: name = %s \r\n", xep->xe_name) ;
# endif

	if ( xep->xe_ctrl & XAR_VERBOSE ) {
		printf ("%s ",		strmodes (xep->xe_mode)) ;
		printf ("%08lx ",	xep->xe_fcrc) ;
		printf ("%s ",		strdate (xep->xe_mtim)) ;
		printf ("%s ",		strtime (xep->xe_mtim)) ;
		printf ("%9ld ",	xep->xe_osiz) ;
		printf ("%s \n",	xep->xe_name) ;
	} else {
		printf ("%06lo ",	(xep->xe_mode)) ;
		printf ("%s ",		strdaymon (xep->xe_mtim)) ;
		printf ("%s ",		strhourmin (xep->xe_mtim)) ;
# ifdef ORIG
		printf ("%7ld ",	xep->xe_osiz) ;
# else
		printf ("%s ",		ltokmg (xep->xe_osiz)) ;
# endif
		printf ("%s \n",	xep->xe_name) ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xaroption (lopt) long lopt ; {

	xarglops |= lopt ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int xarload (xd) XAR * xd ; {

	return xd == NULL ? 0 : -1 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xarheads (xd) XAR * xd ; {

	if ( ! ( xd->xd_ctrl & XAR_STDOUT ) )
		return ;

	if ( xd->xd_ctrl & XAR_VERBOSE ) {
		printf ("  acesso    crc-32     data      hora    tamanho   nome \n") ;
		printf ("========== ======== ========== ======== ========= ============== \n") ;
	} else {
# ifdef ORIG
		printf ("acesso  data   hora tamanho  nome \n") ;
		printf ("====== ====== ===== ======= ============== \n") ;
# else
		printf ("acesso  data   hora tam.  nome \n") ;
		printf ("====== ====== ===== ==== ============== \n") ;
# endif
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xartails (xd) XAR * xd ; {

	if ( ! ( xd->xd_ctrl & XAR_STDOUT ) )
		return ;

	if ( xd->xd_ctrl & XAR_VERBOSE ) {
		printf ("========== ======== ========== ======== ========= ============== \n") ;
		printf ("                                        %9ld %d \n", xd->xd_usiz, xd->xd_used) ;
	} else {
# ifdef ORIG
		printf ("====== ====== ===== ======= ============== \n") ;
		printf ("                    %7ld %d \n", xd->xd_usiz, xd->xd_used) ;
# else
		printf ("====== ====== ===== ==== ============== \n") ;
		printf ("                    %s %d \n", ltokmg (xd->xd_usiz), xd->xd_used) ;
# endif
	}
}

	/********************************************************************/
	/*		support (elementary) stuff ...								*/
	/********************************************************************/

void xarerror (msg, arg) char * msg , * arg ; {

	if ( ! (xarglops & XAR_STDERR) )
		return ;

	fprintf (stderr, msg, arg) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xarprint (msg, arg) char * msg , * arg ; {

	if ( ! (xarglops & XAR_STDOUT) )
		return ;

	fprintf (stdout, msg, arg) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void clrxarent (xep) XARENT * xep ; {

	memset ( (char *) xep , 0x00 , XARENTSIZ ) ;
	xep->xe_name = NULL ;
	xep->xe_nick = NULL ;
	xep->xe_usrn = NULL ;
	xep->xe_grpn = NULL ;
	xep->xe_pswd = NULL ;
	xep->xe_comm = NULL ;
	xep->xe_nosn = NULL ;
	xep->xe_nosv = NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int chkxarhdr (hdrbuf) char * hdrbuf ; {

	if ( strncmp ( hdrbuf , OL_SIGNAB , OL_SIGNABLEN ) == 0 ) {

		if ( strstr ( hdrbuf , " dmy hms " ) != NULL )

			return KINHDR | SPCHDR ;

		else if ( strstr ( hdrbuf , " atr crc etc " ) != NULL )

			return KITHDR | SPCHDR ;

		else

			return XARHDR | SPCHDR ;
	}

	if ( strncmp ( hdrbuf , SZ_SIGNAB , SZ_SIGNABLEN ) == 0 )

		return ZABHDR ;

	return MADHDR ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * chkxarnam (name, type) char * name ; int * type ; {

	register char * np ;

	if ( access ( (np = xarname (name, KINEXT)) , 0 ) == 0 )

		*type = XT_KIN ;

	else if ( access ( (np = xarname (name, XAREXT)) , 0 ) == 0 )

		*type = XT_XAR ;

/*	else if ( ZAB, TAR, CPIO, ZIP, etc ... )	*/

	else if ( access ( (np = name) , 0 ) == 0 )

		*type = XT_UNKNOWN ; /* MUST TRY to "file" IT !!! */

	else

		*type = XT_NONE ;

	return np ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xarname (name, ext) char * name , * ext ; {

	static char namebuff [256] ;
	register char * tp ;

	if ( ext == NULL )
		return name ;

	strcpy (namebuff, name) ;

	if ( ( tp = strrchr ( namebuff , DOT ) ) == NULL )
		strcat (namebuff, ext) ;
	else
		strcpy (tp, ext) ;

	return namebuff ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xarpatterns (slcp) STRLISTCTRL * slcp ; {

	xarpats = slcp ;
}

	/********************************************************************/
	/*		macro (complex) processing ...								*/
	/********************************************************************/

int xarmatch (xep) XARENT * xep ; {

	STRLISTCTRL * tslcp ;
	int rd = FALSE ;

	if (xarpats == NULL)
		return TRUE ;

	tslcp = currstrlist () ;
	pickstrlist (xarpats) ;

	if ( matchstrlist (xep->xe_name) != -1 )
		rd = TRUE ;

	pickstrlist (tslcp) ;
	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int xarlist (name) char * name ; {

	register XAR * txp ;
	register XARENT * xep ;

	if ( ( txp = xaropen (name, XAR_VIEW) ) == NULL )
		return -1 ;

	xarheads (txp) ;

	while ( ( xep = xarscan (txp) ) != NULL )
		if ( xarmatch (xep) ) {
			xarshow (xep) ;
			txp->xd_used += 1 ;
			txp->xd_usiz += xep->xe_osiz ;
		}

	xartails (txp) ;

	xarclose (txp) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
