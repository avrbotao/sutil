
# include <stdio.h>
# include <stdlib.h>

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

struct		alloctl {
	void *	ac_ptr ;
	size_t	ac_siz ;
	int		ac_flg ;
} ;

typedef		struct alloctl		ALLOCTL ;

int64_t		_memuse_ = 0 ;
int64_t		_memadm_ = 0 ;
int64_t		_memtot_ = 0 ;

int64_t		_malcnt_ = 0 ;
int64_t		_calcnt_ = 0 ;
int64_t		_ralcnt_ = 0 ;
int64_t		_frecnt_ = 0 ;

ALLOCTL *	aclst = NULL ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void *	_malloc_	( size_t ) ;
void *	_calloc_	( size_t , size_t ) ;
void *	_realloc_	( void * , size_t ) ;
void	_free_		( void * ) ;

void	_dumpalloc_	( char * ) ;
void	_initalloc_	( ) ;
void	_growalloc_	( ) ;
void	_findalloc_	( ) ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void *	_malloc_	( siz ) size_t siz ; {

	void *	rp ;

	rp = malloc ( siz ) ;

	if ( rp != NULL ) {
		_memuse_ += siz ;
		_memtot_ += siz ;
		++_malcnt_ ;
	}

	return rp ;
}

void *	_calloc_	( nel , siz ) size_t nel , siz ; {

	void *	rp ;

	rp = calloc ( nel , siz ) ;

	if ( rp != NULL ) {
		_memuse_ += ( nel * siz ) ;
		_memtot_ += ( nel * siz ) ;
		++_calcnt_ ;
	}

	return rp ;
}

void *	_realloc_	( ptr , siz ) void * ptr ; size_t siz ; {

	void *	rp ;

	rp = realloc ( ptr , siz ) ;

	if ( rp != NULL ) {
		++_ralcnt_ ;
	}

	return rp ;
}

void	_free_		( ptr ) void * ptr ; {

	if ( ptr != NULL ) {
		/* update memuse */
		++_frecnt_ ;
		free (ptr) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void _dumpalloc_ (txt) char * txt ; {

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

