
/*		 _______________________________________________________________
 *		|																|
 *		|	stdtable.c					(c) 1998-2013 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# include <stdio.h>

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int makestbl ( name ) char * name ; {
	int rd = -1 ;	/* result-/table- descriptor */

	if ( name == NULL )
		return rd ;

	rd = 0 ;

	return rd ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

/*
 * vi:nu tabstop=4
 */
