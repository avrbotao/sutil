
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDIO
# define	USE_SYSTYPES

# define	USE_STDSTR
# define	USE_STRLIST
# define	USE_STDDIR
# define	USE_STDTYP
# define	USE_STDMISC

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * dirpick (dirname) char * dirname ; {

	register DIRDES * ddp ;
	register DIRENT * dep ;
	register STRLISTCTRL * slcp , * tslcp ;
	register char * tp ;
	static char nb [512] ;

	if ( ( ddp = OpenDir (dirname) ) == NULL )
		return NULL ;

	if ( ( slcp = makestrlist ("dpck", DFL_MAXSTRLSTSIZ) ) == NULL ) {
		CloseDir (ddp) ;
		return NULL ;
	}

	tslcp = currstrlist () ;
	pickstrlist (slcp) ;
	modestrlist (LM_ON, LM_MAP) ;

	while ( (dep = ReadDir (ddp)) != NULL ) {
# ifdef DEBUG
		fprintf (stderr, "dirpick(%s): d_name=[%s]\r\n", dirname, dep->d_name) ;
		fflush (stderr) ;
# endif
		feedstrlist (dep->d_name) ;
	}

	CloseDir (ddp) ;

	tp = viewstrlist ("Pick") ; /* should be "(dirname)" */

	if (tp != NULL) {
		strcpy (nb, tp) ;
		tp = nb ;
	}

	freestrlist (slcp) ;
	pickstrlist (tslcp) ;
	return tp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

