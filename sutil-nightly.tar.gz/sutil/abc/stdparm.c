
/*		 _______________________________________________________________
 *		|																|
 *		|	stdparm.c						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# define	USE_ERRNO
# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDSTR
# define	USE_STDAPP
# define	USE_STDLIC
# define	USE_STDASC
# define	USE_STDTYP
# define	USE_STDMEM
# define	USE_STDMISC
# define	USE_STDTIME
# define	USE_STDPARM
# define	USE_STDLOGIC
# define	USE_STDMATCH

# include	"abc.h"

/*________________________________________________________________________
*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

extern		char *		swid ;
extern		int			flagbits ;
extern		PARMINFO	parminfo [] ;

int			argk ;
int			totparms ;
int			currparm ;
int			firsttime ;
int			sortargsflag = FALSE ;

char * *	argp = (char * *) 0 ;
char * *	parmlist ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void setargent (argc, argv) int argc ; char * * argv ; {

# if defined (DOS) || defined (WIN32)

	argk = 0 ;

	while (argc--)
		blowild (*argv++) ;

#	ifdef SORTPARMS

	qsort (argp+1, argk-1, sizeof (char *), parmcmp) ;

#	endif /* SORTPARMS */

# else	/* ANYX */

	argk = argc ; argp = argv ;

# endif	/* DOS */

	totparms = 0 ;
	currparm = 0 ;
	parmlist = NULL ;
	firsttime = TRUE ;
	sortargsflag = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void parseargs () {

	if (--argk) {
		while (*++argp)
			if (**argp == '-')
				parseflags (*argp) ;
			else
				putargent (*argp) ;
		if ( totparms == 0 )
			noparms () ;
	} else {
		noparms () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void parseflags (str) char * str ; {

	register char * tp = str ;
	register PARMINFO * pip ;
	register int found ;

	while (*++tp) {
		for ( found = FALSE, pip = parminfo ; pip->pi_chr != NUL ; ++pip ) {
			if ( pip->pi_chr == *tp ) {
				if ( pip->pi_flg & PI_SETBIT )
					*(pip->pi_var) |= pip->pi_val ;
				if ( pip->pi_flg & PI_SETVAL )
					*(pip->pi_var) = pip->pi_val ;
				if ( pip->pi_flg & PI_SETBUF )
					strcpy ( pip->pi_ptr , *++argp ) ;
				if ( pip->pi_flg & PI_SETNUM )
					*(pip->pi_var) = atoi (*++argp) ;
				found = TRUE ; /* break ; DON'T UNCOMMENT THIS !!! */
			}
		}
		if ( ! found ) {
# ifdef DEBUG
			fprintf (stderr, "flag (%c) unknown \r\n", *tp) ;
# endif
			flagbits |= PI_SYNTAXBIT ;
		}
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void parsebits () {

	if (flagbits & PI_VERSIONBIT)
		verban () ;

	if (flagbits & PI_LICENSEBIT)
		blicshow () ;

	if (flagbits & PI_ENVIRONBIT)
		sysenv () ;

	if (flagbits & PI_SYNTAXBIT)
		cmdsyn () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void endargent () {

	/* xmfree(all stuff) */
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * getargent () {

	if (firsttime) {
		if (sortargsflag)
			if (totparms > 1)
				qsort ( (STR) parmlist, totparms, sizeof (char *), parmcmp) ;
		firsttime = FALSE ;
	}

	if ( parmlist == NULL )
		return NULL ;

	if ( *(parmlist + currparm) == NULL ) {
		currparm = 0 ;
		return NULL ;
	}

	return *(parmlist + currparm++) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * getargpos (int pos) {

	if (firsttime) {
		if (sortargsflag)
			if (totparms > 1)
				qsort ( (STR) parmlist, totparms, sizeof (char *), parmcmp) ;
		firsttime = FALSE ;
	}

	if ( pos < 0 || pos >= totparms )
		return NULL ;

	return *(parmlist + pos) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void putargent (str) char * str ; {

	register char * * tpp ;
	register char *   tp ;

	tp = (char *) xmalloc (1 + strlen (str)) ;

	if (tp == (char *) 0) {
nm:		fprintf (stderr, "%s: no memory ...\n", swid) ;
		exit (1) ;
	}

	if (parmlist == NULL)
		tpp = (char * *) xmalloc (2 * sizeof (char *)) ;
	else
		tpp = (char * *) xmrealloc ( (STR) parmlist, (2+totparms) * sizeof (char *)) ;

	if (tpp == (char * *) 0)
		goto nm ;

	strcpy (tp, str) ;
	parmlist = tpp ;
	*(parmlist+totparms) = tp ;
	++totparms ;
	*(parmlist+totparms) = NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# if defined (TC3) || defined (WIN32)

int parmcmp (a, b) const void * a , * b ; {

	register char * * pa , * * pb ;

	pa = (char * *) a ;
	pb = (char * *) b ;

	return strcmp (*pa, *pb) ;
}

# else

int parmcmp (a, b) char * * a , * * b ; {

	return strcmp (*a, *b) ;
}

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef WIN32

void blowild (nam) char * nam ; {

	struct _finddatai64_t fd64buff ;
	long hndl ;
	char fnbuf [ 80 ] ;
	char * fnptr = fd64buff.name ;
	int slasti ;								/* last slash inx	*/

	if ( isaregexp (nam) == FALSE ) {
		argrow (nam) ;
		return ;
	}

	if ((hndl = _findfirsti64 (nam, &fd64buff)) < 0) {
		argrow (nam) ;
		return ;
	}

	if ((slasti = lastoc (nam, '\\')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;
	else if ((slasti = lastoc (nam, ':')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;

	do {

		if (fnptr == fnbuf)
			strcpy (fnptr + slasti + 1, fd64buff.name) ;

		argrow ( fnptr ) ; /* , & ffbuf */

	} while (_findnexti64 (hndl, &fd64buff) == 0) ;
}

# endif /* WIN32 */

# ifdef DOS

void blowild (nam) char * nam ; {

	struct ffblk ffbuf ;
	char fnbuf [ 80 ] ;
	char * fnptr = ffbuf.ff_name ;
	int slasti ;								/* last slash inx	*/

# ifdef OLD

	if ( strchr (nam, '*') == NULL && strchr (nam, '?') == NULL ) {

# else  /* NEW */

	if ( isaregexp (nam) == FALSE ) {

# endif /* OLD x NEW */

		argrow (nam) ;
		return ;
	}

	if (findfirst (nam, &ffbuf, FA_MASK) < 0) {
		argrow (nam) ;
		return ;
	}

	if ((slasti = lastoc (nam, '\\')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;
	else if ((slasti = lastoc (nam, ':')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;

	do {

		if (fnptr == fnbuf)
			strcpy (fnptr + slasti + 1, ffbuf.ff_name) ;

		argrow ( fnptr ) ; /* , & ffbuf */

	} while (findnext (&ffbuf) >= 0) ;
}

# endif /* DOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# if defined (DOS) || defined (WIN32)

void argrow (str) char * str ; {
	register char * * tpp ;
	register char *   tp ;

	tp = (char *) xmalloc (1 + strlen (str)) ;

	if (tp == (char *) 0) {
nm:		fprintf (stderr, "%s: no memory ...\n", swid) ;
		exit (1) ;
	}

	if (argp == (char * *) 0)
		tpp = (char * *) xmalloc (2 * sizeof (char *)) ;
	else
		tpp = (char * *) xmrealloc ( (char *) argp, (2+argk) * sizeof (char *)) ;

	if (tpp == (char * *) 0)
		goto nm ;

	strcpy (tp, str) ;
	argp = tpp ;
	*(argp+argk) = tp ;
	++argk ;
	*(argp+argk) = NULL ;
}

# endif		/* DOS || WIN32 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef ANYX

#	include <sys/utsname.h>

struct utsname utsbuf ;

# endif

void sysenv () {

# if defined ( AIX ) || defined ( BSD )
        time_t  			tloc ;
# else
	long				tloc ;
# endif
	REG		struct tm *	tp ;
	REG		int			day, mon, year, hour, min, sec ;
			int			rd = 0 ;

/*	printf ( "\n" ) ;	*/

# ifdef ANYX

	if ( uname (&utsbuf) != -1 ) {
		if ( flagbits & PI_DEBUGBIT ) {
			printf (" sysname : %s \n", utsbuf.sysname) ;
			printf (" version : %s \n", utsbuf.version) ;
			printf (" release : %s \n", utsbuf.release) ;
			printf (" boxname : %s \n", utsbuf.nodename) ;
			printf (" machine : %s \n", utsbuf.machine) ;
			printf (" daytime :") ;
		} else {
			printf (" %s %s %s %s %s", utsbuf.sysname,
					utsbuf.version, utsbuf.release,
					utsbuf.nodename, utsbuf.machine ) ;
		}
	} else {
		rd = system ("uname -a") ;
	}

		if ( rd < 0 )
			return ;

	/*	rd = system ("id") ;  */

# else  /* DOS */

	system ("ver") ;

# endif /* ANYX */

	time ( &tloc ) ;
	tp = localtime ( &tloc ) ;

	day  = tp->tm_mday ;
	mon  = tp->tm_mon + 1 ;
	year = tp->tm_year + 1900 ;

	hour = tp->tm_hour ;
	min  = tp->tm_min ;
	sec  = tp->tm_sec ;

	printf ( " %04d.%02d.%02d %02d:%02d:%02d",
			year, mon, day, hour, min, sec) ;

	printf ( " \n" ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

extern	char *	swid ;

int xalert (typ, act, txt, val) char * act , * txt ; int typ , val ; {

	register int errcod = errno ;
	static char tb [256] , mb [256] ;

	if ( act == NULL )
		act = "processar" ;

	sprintf ( tb , "%s (ERRO ao %s " , swid , act ) ;

	if ( txt != NULL )
		strcat ( tb , txt ) ;

	if (val == 0)
		sprintf (mb, "%s) ", tb) ;
	else
		sprintf (mb, "%s%d) ", tb, val) ;

	perror (mb) ;

	if ( typ == XA_FATAL )
		epilogue () ;

	return errcod ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	command line syntax help ...	|
 *		|___________________________________|
 */

extern char * syntxt [] ;

void cmdsyn () {

	register int j ;

	for ( j = 0 ; syntxt[j] ; ++j )
		fprintf (stderr, "%s", syntxt[j]) ;

	epilogue () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu ts=4
 */
