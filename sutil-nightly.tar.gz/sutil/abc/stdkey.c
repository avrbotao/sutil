
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDIO
# define	USE_FCNTL

# define	USE_STDTYP
# define	USE_STDKEY
# define	USE_STDTIO
# define	USE_STDMEM
# define	USE_STDMSG
# define	USE_STDASC
# define	USE_STDSTR
# define	USE_STDLIB
# define	USE_STDTERM
# define	USE_STDLOGIC

# include	"abc.h"

# ifdef HPUX
# include <unistd.h>
# endif

char *tgetstr(char *id, char **area);

# if defined ( FreeBSD )
# include <sys/ioctl.h>
# else
int ioctl(int d, int request, ...);
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef ANYX

KEYINFO keylist [] = {

# ifdef OLD_KEYNAMES

	{ "k1",   K_F1,      "F1",       NULL	} ,
	{ "k2",   K_F2,      "F2",       NULL	} ,
	{ "k3",   K_F3,      "F3",       NULL	} ,
	{ "k4",   K_F4,      "F4",       NULL	} ,
	{ "k5",   K_F5,      "F5",       NULL	} ,
	{ "k6",   K_F6,      "F6",       NULL	} ,
	{ "k7",   K_F7,      "F7",       NULL	} ,
	{ "k8",   K_F8,      "F8",       NULL	} ,
	{ "k9",   K_F9,      "F9",       NULL	} ,
	{ "k0",   K_F10,     "F10",      NULL	} ,
	{ "F11",  K_F11,     "F11",      NULL	} ,
	{ "F12",  K_F12,     "F12",      NULL	} ,
	{ "ho",   K_HOME,    "Home",     NULL	} ,
	{ "EN",   K_END,     "End",      NULL	} ,
	{ "PU",   K_PGUP,    "PgUp",     NULL	} ,
	{ "PD",   K_PGDN,    "PgDn",     NULL	} ,
	{ "al",   K_INS,     "Ins",      NULL	} ,
	{ "dc",   K_DEL,     "Del",      NULL	} ,
	{ "ku",   K_UP,      "Up",       NULL	} ,
	{ "kd",   K_DOWN,    "Down",     NULL	} ,
	{ "kl",   K_LEFT,    "Left",     NULL	} ,
	{ "kr",   K_RIGHT,   "Right",    NULL	} ,

# else  /* NEW_KEYNAMES */

	{ "k1",   K_F1,      "F1",       NULL	} ,
	{ "k2",   K_F2,      "F2",       NULL	} ,
	{ "k3",   K_F3,      "F3",       NULL	} ,
	{ "k4",   K_F4,      "F4",       NULL	} ,
	{ "k5",   K_F5,      "F5",       NULL	} ,
	{ "k6",   K_F6,      "F6",       NULL	} ,
	{ "k7",   K_F7,      "F7",       NULL	} ,
	{ "k8",   K_F8,      "F8",       NULL	} ,
	{ "k9",   K_F9,      "F9",       NULL	} ,
	{ "k0",   K_F10,     "F10",      NULL	} ,
	{ "F11",  K_F11,     "F11",      NULL	} ,
	{ "F12",  K_F12,     "F12",      NULL	} ,
	{ "kh",   K_HOME,    "Home",     NULL	} ,
	{ "EN",   K_END,     "End",      NULL	} ,
	{ "kP",   K_PGUP,    "PgUp",     NULL	} ,
	{ "kN",   K_PGDN,    "PgDn",     NULL	} ,
	{ "kI",   K_INS,     "Ins",      NULL	} ,
	{ "kD",   K_DEL,     "Del",      NULL	} ,
	{ "ku",   K_UP,      "Up",       NULL	} ,
	{ "kd",   K_DOWN,    "Down",     NULL	} ,
	{ "kl",   K_LEFT,    "Left",     NULL	} ,
	{ "kr",   K_RIGHT,   "Right",    NULL	} ,

# endif /* OLD_KEYNAMES */

	{ NULL,   -1,        NULL,       NULL   }
} ;

int			totkeys = 0 ;
int			keysarok ;
int			currkeyinfo = 0 ;

extern int	vfd ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int setkeyent () {

	return currkeyinfo = 0 ;
}

int endkeyent () {

	return currkeyinfo = 0 ;
}

KEYINFO * getkeyent () {

	if (currkeyinfo >= totkeys)
		return NULL ;

	return &keylist[currkeyinfo++] ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int keycmp (a, b) void * a , * b ; {

	REG KEYINFO * pa = (KEYINFO *) a ;
	REG KEYINFO * pb = (KEYINFO *) b ;

	return strcmp (pa->ki_sign, pb->ki_sign) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void sortkeys () {

	qsort ( (char *) keylist, totkeys, KI_SIZE, keycmp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int loadkey (name, sign, skflag) char * name , * sign ; int skflag ; {

		char *		tp ;
	REG	KEYINFO *	kip ;
	REG	int			tmplen , found ;

	if ( name == NULL || sign == NULL )
		return -1 ;

	if ( ( tmplen = 1 + strlen (sign) ) <= 1 )
		return -2 ;

	for ( found = FALSE , kip = keylist ; kip->ki_name ; ++kip )
		if ( strcmp ( kip->ki_name , name ) == 0 ) {
			found = TRUE ;
			break ;
		}

	if ( ! found )
		return -4 ;

	if ( kip->ki_sign != NULL )
# ifdef COMMENT
		return -5 ;
# else
	/*	if ( strncmp (kip->ki_sign, KEY_FAKE, 4) == 0 )  */
			xmfree (kip->ki_sign) ;
# endif

	tp = (char *) xmalloc ( tmplen ) ;

	if ( tp == NULL )
		return -6 ;

	strcpy ( kip->ki_sign , sign ) ;

	if (skflag)
		sortkeys () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int repairkey (keynam) char * keynam ; {

	char keysig [32] ;
	int j ;

	if ( ( j = loadinfo (keynam, keysig) ) != 0 )
		return -1 ;

	if ( ( j = loadkey (keynam, keysig, FALSE) ) != 0 )
		return -2 ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void fixkeys (int fixflags) {

	char keynam [16] ;
	register KEYINFO * kip ;

	setkeyent () ;

	while ( ( kip = getkeyent () ) != NULL ) {

		strcpy (keynam, kip->ki_name) ;

# ifdef DEBUG
		printf ("fixkeys: key = (%s) sig = (%s) \r\n", keynam, bintos (kip->ki_sign)) ;
# endif /* DEBUG */

		if ( ! (fixflags & KF_FORCE) )
			if ( strncmp (kip->ki_sign, KEY_FAKE, 4) != 0 )
				continue ;

		repairkey (keynam) ;

# ifdef DEBUG
		printf ("fixkeys: repairkey(%s) = %d \r\n", keynam, rd) ;
# endif /* DEBUG */

	}

	endkeyent () ;

	sortkeys () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int initkeys () {

				char		tb [200] ;
				char *		tp ;
	REG	KEYINFO *	kip ;
	REG	int			tmplen ;

	keysarok = FALSE ;

	for ( kip = keylist , totkeys = 0 ; kip->ki_name ; ++kip ) {

		++totkeys ;
		sprintf (tb, KEY_FAKE, totkeys) ;
		kip->ki_sign = (char *) xmalloc ( 1 + strlen (tb) ) ;
		strcpy (kip->ki_sign, tb) ;
		tp = tb ;
		tp = (char *) tgetstr ( kip->ki_id , &tp ) ;

		if (tp == NULL) { /* undefined key */
# ifdef DEBUG
			printf ("*** key (%s) undocumented \r\n", kip->ki_id) ;
# endif
			continue ;
		} else if (*tp == NUL) { /* empty definition */
# ifdef DEBUG
			printf ("*** key (%s) empty \r\n", kip->ki_id) ;
# endif
			continue ;
		}

# ifdef DEBUG
		printf ("initkeys: key (%s %s) sig (%s) \r\n", kip->ki_id, kip->ki_name, bintos (tp)) ;
# endif /* DEBUG */

		tmplen = strlen (tp) + 1 ;
		xmfree (kip->ki_sign) ;
		kip->ki_sign = (char *) xmalloc ( tmplen ) ;

		if ( kip->ki_sign == NULL )
			return XE_NO_MEMORY ;

		strcpy ( kip->ki_sign , tp ) ;
	}

	sortkeys () ;

	keysarok = TRUE ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int anyxkey (int keyflags) {

	static		char		b [ 20 ] ;
				KEYINFO		k ;
				int			fc_ant ;
	REG	int			i = 0 ;
	REG	char *		p = b ;
	REG	int			r ;
	REG	KEYINFO *	x ;
				int			rd ;
	static		int			nu = 0 ;
	static		char *		pu = NULL ;

	if (keyflags & KF_BURST) {
		if (nu-- > 0) {
			return *++pu ;
		} else {
			nu = 0 ;
		}
	} else {
		nu = 0 ;
	}

	r = read (vfd, p+i, 1) ;

	if (r <= 0)
		return -1 ;

	if (*(p+i) == 27) { /* ESC : get more chars ... */

# ifdef READ_DELAY

		rd = fc_ant = fcntl (vfd, F_GETFL, 0) ;

		if (rd == -1)
			return XE_CANT_FCNTL_GETFL ;

		rd = fcntl (vfd, F_SETFL, fc_ant | O_NDELAY | O_NONBLOCK) ;

		if (rd == -1)
			return XE_CANT_FCNTL_SETFL_NDELAY ;

# endif /* READ_DELAY */

gmc :			/* get more chars ... */

# ifdef READ_COUNT

		rd = ioctl (vfd, FIONREAD, &fc_ant) ;

		if (rd < 0)
			fc_ant = 0 ; /* return XE_CANT_IOCTL_FIONREAD ; */

		if ( fc_ant == 0 ) {
			r = 0 ;
			goto teoc ;
		}

# endif /* READ_COUNT */

		++i ;
		r = read (vfd, p+i, 1) ;

# ifdef READ_COUNT
teoc:			/* test end-of-chars (key-burst) */
# endif /* READ_COUNT */

		if (r == 0) {

# ifdef READ_DELAY

			rd = fcntl (vfd, F_SETFL, fc_ant) ; --i ;

			if (rd == -1)
				return XE_CANT_FCNTL_SETFL_REST ;

# endif /* READ_DELAY */

			if ( i > 0 ) {

				b[i+1] = NUL ; k.ki_sign = b ;

				x = (KEYINFO *)
					bsearch ( (void *) & k,
						  (void *) keylist,
						  (size_t) totkeys,
						  (size_t) KI_SIZE,
						  keycmp             ) ;

				if (x == (KEYINFO *) 0) {
					if (keyflags & KF_BURST) {
						nu = i ;
						pu = b ;
						return *pu ;
					} else { /* RTN_NOKEY */
						return -1 ;
					}
				}

# ifdef DEBUG
				printf ("--> key (%s) = (%s) \r\n", x->ki_id, x->ki_name) ;
# endif

				return x->ki_code ;
			}
			return *(p+i) ;
		}
		if (r < 0)
			return -1 ;
		goto gmc ;
	}

	return *(p+i) ;

} /* endof anyxkey() */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * keysign (name) char * name ; {

	REG	KEYINFO *	kip ;
	REG	int			found = FALSE ;

	for ( kip = keylist ; kip->ki_name ; ++kip )
		if ( strcmp (kip->ki_name, name) == 0 ) {
			found = TRUE ;
			break ;
		}

	if (found)
		return kip->ki_sign ;
	else
		return "NOKEY" ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xkeyname (int code) {

	REG	KEYINFO *	kip ;
	REG	int			found = FALSE ;

	for ( kip = keylist ; kip->ki_name ; ++kip )
		if ( kip->ki_code == code ) {
			found = TRUE ;
			break ;
		}

	if (found)
		return kip->ki_name ;
	else
		return "?" ;
}

# endif /* ANYX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int readkey () {

# ifdef DOS
					int key = getch () ;

					if (key == 0)
						key = V_KEY ( getch () ) ;

					return key ;
# endif /* DOS */

# ifdef WIN32
					int key = getch () ;

					if (key == 0)
						key = V_KEY ( getch () ) ;

					return key ;
# endif /* WIN32 */

# ifdef	ANYX
					return anyxkey (0x0000) ;
# endif	/* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
