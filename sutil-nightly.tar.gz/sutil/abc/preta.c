
# include <time.h>
# include <stdio.h>
# include <string.h>
# include <unistd.h>

/*__________________________________________________________________________*/

# define	SETKMG(X)	kmg[3] = X ; kmg[4] = '\0' ;

typedef		unsigned long	ULONG ;
typedef		long long	sbit64 ;

char * lltokmgtpe (x) sbit64 x ; {

	static char kmg [64] ;
	static char kc = 'K' , mc = 'M' , gc = 'G' , sc = ' ' ;
	static char tc = 'T' , pc = 'P' , ec = 'E' ;
	double bval, kval, mval, gval ;
	double       tval, pval, eval ;

	bval = x ;

	if (bval < 1000) {
		sprintf (kmg, "%3d", (int) bval) ; SETKMG(sc) ;
		return kmg ;
	}

	kval = bval / 1024.0 ;

	if ( kval < 10.0 ) {
		sprintf (kmg, "%11.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	if ( kval < 1000.0 ) {
		sprintf (kmg, "%13.9f", kval) ; SETKMG(kc) ;
		return kmg ;
	}

	mval = bval / 1048576.0 ;

	if ( mval < 10.0 ) {
		sprintf (kmg, "%11.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	if ( mval < 1000.0 ) {
		sprintf (kmg, "%13.9f", mval) ; SETKMG(mc) ;
		return kmg ;
	}

	gval = bval / 1073741824.0 ;

	if ( gval < 10.0 ) {
		sprintf (kmg, "%11.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	if ( gval < 1000.0 ) {
		sprintf (kmg, "%13.9f", gval) ; SETKMG(gc) ;
		return kmg ;
	}

	tval = bval / 1099511627776.0 ;

	if ( tval < 10.0 ) {
		sprintf (kmg, "%11.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	if ( tval < 1000.0 ) {
		sprintf (kmg, "%13.9f", tval) ; SETKMG(tc) ;
		return kmg ;
	}

	pval = bval / 1125899906842624.0 ;

	if ( pval < 10.0 ) {
		sprintf (kmg, "%11.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	if ( pval < 1000.0 ) {
		sprintf (kmg, "%13.9f", pval) ; SETKMG(pc) ;
		return kmg ;
	}

	eval = bval / 1152921504606846976.0 ;

	if ( eval < 10.0 ) {
		sprintf (kmg, "%11.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	if ( eval < 1000.0 ) {
		sprintf (kmg, "%13.9f", eval) ; SETKMG(ec) ;
		return kmg ;
	}

	return "????" ;
}

char * strhms (secs) ULONG secs ; {

	static char hms [32] ;
	ULONG n = secs ;
	int h, m, s ;

	if ( n == 0 )
		return "00:00:00" ;

	if ( ( h = n / 3600 ) > 0 )
		n -= h * 3600 ;

	if ( ( m = n / 60 ) > 0 )
		n -= m * 60 ;

	s = n ;

	sprintf (hms, "%02d:%02d:%02d", h, m, s) ;

	return hms ;
}

/*______________________________________________________________________*/
/*  ptrel : percent, time, rate & estimated left (u = [BKMG])		*/
/*  NNNu (PPP%) of TTTu in HH:MM:SS @ YYYu/s (HH:MM:SS left)		*/
/*  NNNu (PPP%) of TTTu in HH:MM:SS @ YYYu/s >>>>|||||| (HH:MM:SS left)	*/
/*______________________________________________________________________*/

# define	NEWPRETA

# include "preta.h"

# ifdef NEWPRETA
void waketa (int) ;
void waketa (arg) int arg ; {
	signal (SIGALRM, waketa) ;
	preta ( (off_t *)NULL , (off_t *)NULL , (long) ( PTE_WAKE | ( arg & 0x7f ) ) ) ;
}
# endif  /* NEWPRETA */

# ifdef NEWPRETA

int preta (psof, ptot, flg) off_t * psof , * ptot ; long flg ; {
		sbit64		sof = 0 , tot = 0 ;
	static	off_t *		xsof ;
	static	off_t *		xtot ;

# else  /* ! NEWPRETA */

int preta (sof, tot, flg) sbit64 sof, tot ; long flg ; {

# endif /* NEWPRETA */

		ULONG		etl ;			/* estimated time left	*/
		ULONG		dt ;
		sbit64		rt ;
	static	char		barbuf [16] ;
	static	time_t		t0 ;
# ifndef NEWPRETA
	static	time_t		tl ;
# endif
	static	int		mtbs = 0 ;
	static	int		yawns = 0 ;
		time_t		tx ;
		int		pok , barlen = 10 , barpok ;

# ifdef NEWPRETA

	if ( flg & PTE_DONE ) {
		if ( yawns == 0 )
			return 0 ;
	}

	if ( flg & PTE_INIT ) {
		xsof = psof ;
		xtot = ptot ;
		sof = *xsof ;
		tot = *xtot ;
		signal (SIGALRM, waketa) ;
		mtbs = flg & 0x007f ;
		if ( mtbs <= 0 || mtbs >= 60 )
			mtbs = 3 ;
		alarm (mtbs) ;
		time (&t0) ;
		/* tl = t0 ; */
		memset (barbuf, (int) BARYET, barlen) ;
		barbuf[barlen] = '\0' ;
		return 0 ;
	}

# else  /* ! NEWPRETA */

	if ( sof == 0 ) {
		mtbs = flg & 0x007f ;
		if ( mtbs <= 0 )
			mtbs = 2 ;
		time (&t0) ;
		tl = t0 ;
		memset (barbuf, (int) BARYET, barlen) ;
		barbuf[barlen] = '\0' ;
		return 0 ;
	}

# endif  /* NEWPRETA */

	time (&tx) ;

# ifdef NEWPRETA
	if ( flg & ( PTE_WAKE | PTE_DONE ) ) {
		sof = *xsof ;
		tot = *xtot ;
	}
	if ( flg & PTE_WAKE ) {
		alarm (mtbs) ;
		++yawns ;
	}
# else  /* ! NEWPRETA */
	if ( tx - tl < mtbs ) /* min secs between samples */
		if ( ! ( flg & PTE_DONE ) )
			return 0 ;
# endif  /* NEWPRETA */

	dt = tx - t0 ;
	pok = (sof * 100) / tot ;
	barpok = ( barlen * pok ) / 100 ;
	memset (barbuf, (int) BARPOK, barpok) ;
	rt = sof / dt ;
	etl = (tot - sof) / rt ;
# ifndef NEWPRETA
	tl = tx ;
# endif

	printf (" %s (%3d%%) of", lltokmgtpe (sof), pok) ;
	printf (" %s in %s @", lltokmgtpe (tot), strhms (dt)) ;
	printf (" %s/s %s (%s left)", lltokmgtpe (rt), barbuf, strhms (etl)) ;
# ifdef GPB
	printf (" %4.2f", (float) sof / (float) tot /* (float) pok / 100.0 */) ; 
# endif
	printf (" \r") ;
	fflush (stdout) ;

	if ( flg & PTE_DONE ) {
		alarm (0) ;
		signal (SIGALRM, SIG_DFL) ;
		if ( flg & PTE_NEWL ) {
			printf ("\n") ;
		} else {
				/* _NNNu (PPP%) of TTTu in HH:MM:SS @ YYYu/s >>>>|||||| (HH:MM:SS left)	*/
			printf ("\r                                                                    \r") ;
			fflush (stdout) ;
		}
		mtbs = yawns = 0 ;
		return 0 ;
	}

	if ( flg & PTE_NEWL )
		printf ("\n") ;

	return 0 ;
}

/*__________________________________________________________________________*/

/*
 * vi:nu ts=8
 */
