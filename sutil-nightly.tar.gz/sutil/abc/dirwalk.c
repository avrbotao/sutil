
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDIO
# define	USE_SYSTYPES
# define	USE_UNISTD

# define	USE_STDSTR
# define	USE_STRLIST
# define	USE_STDLOGIC
# define	USE_STDSTAT
# define	USE_STDDIR
# define	USE_STDTYP
# define	USE_STDMISC

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

static char prevname [256] ;
static char origname [256] ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * dirwalk (dirname) char * dirname ; {

	register char * tp ;
	static char cwdnam [128] ;
	static char tmpnam [256] ;
	static char newnam [256] ;
	static int  atfirst = TRUE ;

	if ( getcwd (cwdnam, 128) == NULL )
		return NULL ;

	if (atfirst) {
		strcpy (prevname, cwdnam) ;
		strcpy (origname, cwdnam) ;
		atfirst = FALSE ;
	}

	if ( dirname == NULL )
		strcpy (tmpnam, prevname) ;
	else
		strcpy (tmpnam, dirname) ;

	for ( ; ; ) {

		if ( chdir (tmpnam) )
			return NULL ;

		if ( getcwd (tmpnam, 128) == NULL )
			return NULL ;

		tp = dirview (tmpnam) ;

		if ( tp == NULL )
			break ;

		if ( *tp != DIRSEP ) {
			sprintf (newnam, "%s%c%s", tmpnam, DIRSEP, tp) ;
			tp = newnam ;
			break ;
		}

		sprintf (newnam, "%s%s", tmpnam, tp) ;
		strcpy (tmpnam, newnam) ;
	}

	strcpy (prevname, tmpnam) ;

	if ( chdir (cwdnam) == 0 )
		return tp ;
	else
		return NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * dirview (dirname) char * dirname ; {

	register DIRDES * ddp ;
	register STRLISTCTRL * slcp , * tslcp ;
	register char * tp ;
	static char nb [512] ;

	if ( ( ddp = setdirent (dirname) ) == NULL )
		return NULL ;

	if ( ( slcp = makestrlist ("dwlk", DFL_MAXSTRLSTSIZ) ) == NULL ) {
		enddirent (ddp) ;
		return NULL ;
	}

	tslcp = currstrlist () ;
	pickstrlist (slcp) ;
	modestrlist (LM_ON, LM_MAP) ;

	sprintf (nb, "%c..", DIRSEP) ;
	feedstrlist (nb) ;

	while ( ( tp = getdirent (ddp) ) != NULL ) {
		if ( filetype (tp) == T_DIR ) {
			sprintf (nb, "%c%s", DIRSEP, tp) ;
			feedstrlist (nb) ;
		} else
			feedstrlist (tp) ;
	}

	enddirent (ddp) ;

	tp = viewstrlist ("Walk") ; /* should be "[dirname]" ... */

	if (tp != NULL) {
		strcpy (nb, tp) ;
		tp = nb ;
	}

	freestrlist (slcp) ;
	pickstrlist (tslcp) ;
	return tp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

