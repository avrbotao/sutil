
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   libpha     parallel hash alternative library   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This file is part of 'PHALANX' (the parallel hash alternative)      |
 |  as released by Alexandre Botao <botao.org> ;                        |
 |                                                                      |
 |  'PHA' is Free and Open Source software (FOSS). This means you can   |
 |  redistribute it and/or modify it under the terms of the GNU General |
 |  Public License as published by the Free Software Foundation, either |
 |  version 3 of the License, or (at your option) any later version.    |
 |                                                                      |
 |  'PHA' is distributed in the hope that it will be useful,            |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License	|
 |  along with 'PHA'.  If not, see <http://www.gnu.org/licenses/>, or   |
 |  write to the Free Software Foundation, Inc.,                        |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

#ifndef _LIBPHA_H_

#define _LIBPHA_H_

# include <sys/types.h>

# define	MAXOCT			16

extern int monkzflag ;

extern int singleflag ;
extern int dominoflag ;

extern size_t phamaxsiz ;
extern int phabufsiz ;

extern int octcount ;

int sievespice () ;
int pharng () ;

void sievewid () ;
void phareseed () ;

unsigned long long * xomd64buff () ;
unsigned long long * xomd64file () ;

void phanote () ;
void phadump () ;

int phaisdir () ;

char * graftname () ;

void monkz () ;

#endif  /* _LIBPHA_H_ */

