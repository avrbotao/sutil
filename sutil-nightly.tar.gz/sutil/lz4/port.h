
# ifndef __PORT_H__

# define __PORT_H__

# ifdef __CYGWIN__

#	ifndef _O_BINARY
#		define	_O_BINARY	O_BINARY
#	endif

#	define __NO__FILENO__

#	ifdef __NO__FILENO__
#		define		_fileno(X)	fileno(X)
#	endif

# endif /* __CYGWIN__ */

# endif /* __PORT_H__ */
