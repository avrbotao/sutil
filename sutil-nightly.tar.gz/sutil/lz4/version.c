
char * program_string = "lz4" ;
char * summary_string = "lz4 compression driver" ;
char * version_string = "1.2.7" ;
char * release_string = "2015-08-24" ;
char * waltime_string = "13:16:00" ;
char * taglist_string = "lz4,compression,driver" ;
char * license_string = "GPLv3" ;
char * creator_string = "alexandre botao" ;
char * contact_string = "alexandre@botao.org" ;

/*
 * vi:nu ts=4
 */
