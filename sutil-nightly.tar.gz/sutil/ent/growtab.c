
# include <stdio.h>
# include <stdlib.h>

# include "growtab.h"

static		int		incrsize = BASESIZE ;

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

void growtab (
				char * * *		tableptr	,
				int *			tablesiz	,
				int				elemsize	,
				int				pilesize	,
				int				growflag
) {
	register	int				i			;
	register	int				tmpsiz		;
	register	char * *		tmptab		;
	register	char *			tmprec		;

	tmptab = *tableptr ;
	tmpsiz = *tablesiz ;

	if ( growflag & BINARYGROW ) {
		if ( tmpsiz == 0 ) {
			incrsize = pilesize ;
		} else {
			incrsize = ( tmpsiz < MAXBUNCH ? tmpsiz : MAXBUNCH ) ;
		}
	} else {					/* BUNCHGROW */
		incrsize = pilesize ;
	}

	tmpsiz += incrsize ;

	if ( growflag & VERBOSEGROW ) {
		fprintf (stderr, "growtab=(%d)\r\n", tmpsiz) ;
	}

	if ( tmptab == NULL ) {
		tmptab = (char * *) malloc ( tmpsiz * sizeof(char *) ) ;
	} else {
		tmptab = (char * *) realloc ( tmptab , tmpsiz * sizeof(char *) ) ;
	} 

	if ( tmptab == NULL ) {
		fprintf (stderr, "** no memory for table **\n");
		exit (EXIT_FAILURE) ;
	}

	*tableptr = tmptab ;

	for ( i = 0 , tmptab = (*tableptr) + *tablesiz ; i < incrsize ; ++i ) {
		tmprec = (char *) malloc ( elemsize ) ;

		if ( tmprec == NULL ) {
			fprintf (stderr, "** no memory for entry **\n");
			exit (EXIT_FAILURE) ;
		}

		*(tmptab+i) = tmprec ;
	}

	*tablesiz = tmpsiz ;
}

/*
 * vi:nu ts=4
 */
