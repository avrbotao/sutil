
# define	MAXBUNCH			131072
# define	BASESIZE			  1024

# define	VERBOSEGROW		0x00000001
# define	BINARYGROW		0x00000002
# define	BUNCHGROW		0x00000004

void	growtab ( char * * * tableptr , int * tablesiz , int elemsize , int pilesize , int growflag ) ;

/*
 * vi:nu ts=4
 */

