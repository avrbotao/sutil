
int	flagbits = 0x0000 ;

char * swid = VERNAME ;

char * verinf [] = { VERNAME, VERSION, VERCODE, VERDATE, OPSYS, VERSIGN } ;

char * optinf [] = {

	CTYPE		,
	ERRNO		,
	FCNTL		,
	MATH		,

	STDIO		,
	STDLIB		,

	SYSTYPES	,

	STDAPP		,
	STDASC		,
	STDBOX		,
	STDBUG		,
	STDCAP		,
	STDCMD		,
	STDCOLOR	,
	STDCRC		,
	STDDIR		,
	STDKEY		,
	STDLIC		,
	STDLIST		,
	STDLOG		,
	STDLOGIC	,
	STDMATCH	,
	STDMEM		,
	STDMISC		,
	STDMSG		,
	STDNET		,
	STDPARM		,
	STDSIG		,
	STDSTAT		,
	STDSTR		,
	STDTERM		,
	STDTIME		,
	STDTIO		,
	STDTYP		,
	STDVIF		,
	STDWIN		,
	STDXFS		,
	STDXAR		,

	NULL
} ;

