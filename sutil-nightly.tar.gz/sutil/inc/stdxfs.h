
/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	stdxfs.h		(c) 1994-2003 Alexandre Botao	|
 *	|_______________________________________________________________|
 */

# ifndef _STDXFS_H

# define _STDXFS_H

# include <sys/types.h>

/*	--	--	--	--	--	--	--	--	*/

# ifdef MSVC

struct w32mntent {
	char * mnt_device ;
	char * mnt_mountp ;
	char * mnt_fstype ;
	char * mnt_options ;
} ;

typedef		struct w32mntent	MOUNTENTRY ;

# define	MNT_DEV				mnt_device
# define	MNT_PATH			mnt_mountp
# define	MNT_TYPE			mnt_fstype
# define	MNT_OPTS			mnt_options

struct w32statvfs {

	long	f_bsize ;

# ifdef HASFRSIZE
	long	f_frsize ;
# endif /* HASFRSIZE */

	long	f_blocks ;
	long	f_bfree ;
	long	f_bavail ;
	long	f_files ;
	long	f_ffree ;

} ;

typedef		struct w32statvfs	FSYSSTATUS ;

typedef		long			fsblkcnt_t ;
typedef		long			fsfilcnt_t ;

# endif /* MSVC */

/*	--	--	--	--	--	--	--	--	*/

# ifdef CYGWIN

# define	USE_STATFS
/* # define	HASFRSIZE */

# include	<mntent.h>			/* getmntent ()		*/
typedef		struct mntent	MOUNTENTRY ;

# ifdef USE_STATVFS
# include	<sys/statvfs.h>			/* statvfs ()		*/
typedef		struct statvfs	FSYSSTATUS ;
# endif /* USE_STATVFS */

# ifdef USE_STATFS
# include	<sys/vfs.h>			/* statfs ()		*/
typedef		struct statfs	FSYSSTATUS ;
# endif /* USE_STATFS */

# define	MOUNT_TABLE	MOUNTED		/* "/etc/mtab"		*/

# define	MNT_DEV				mnt_fsname
# define	MNT_PATH			mnt_dir
# define	MNT_TYPE			mnt_type
# define	MNT_OPTS			mnt_opts

# ifdef LEGACYG
typedef		long			fsblkcnt_t ;
typedef		long			fsfilcnt_t ;
# endif /* LEGACYG */

# endif /* CYGWIN */

/*	--	--	--	--	--	--	--	--	*/

# ifdef AIX

# define	USE_STATVFS
# define	HASFRSIZE

# include	<mntent.h>			/* getmntent ()		*/
typedef		struct mntent	MOUNTENTRY ;

# ifdef USE_STATVFS
# include	<sys/statvfs.h>			/* statvfs ()		*/
typedef		struct statvfs	FSYSSTATUS ;
# endif /* USE_STATVFS */

# ifdef USE_STATFS
# include	<sys/vfs.h>			/* statfs ()		*/
typedef		struct statfs	FSYSSTATUS ;
# endif /* USE_STATFS */

# define	MOUNT_TABLE	MOUNTED		/* "/etc/mtab"		*/

# define	MNT_DEV				mnt_fsname
# define	MNT_PATH			mnt_dir
# define	MNT_TYPE			mnt_type
# define	MNT_OPTS			mnt_opts

# endif /* AIX */

/*	--	--	--	--	--	--	--	--	*/

# ifdef BSD

# define	USE_STATVFS
# define	HASFRSIZE

struct mntent {
	char *		mnt_fsname ;
	char *		mnt_dir ;
	int		mnt_type ;
	int		mnt_opts ;
} ;

typedef		struct mntent	MOUNTENTRY ;

# ifdef USE_STATVFS
# include	<sys/statvfs.h>			/* statvfs ()		*/
typedef		struct statvfs	FSYSSTATUS ;
# endif /* USE_STATVFS */

# ifdef USE_STATFS
# include	<sys/vfs.h>			/* statfs ()		*/
typedef		struct statfs	FSYSSTATUS ;
# endif /* USE_STATFS */

# define	MOUNT_TABLE	MOUNTED		/* "/etc/mtab"		*/

# define	MNT_DEV				mnt_fsname
# define	MNT_PATH			mnt_dir
# define	MNT_TYPE			mnt_type
# define	MNT_OPTS			mnt_opts

# endif /* BSD */

/*	--	--	--	--	--	--	--	--	*/

# ifdef HPUX

# define	USE_STATVFS
# define	HASFRSIZE

# include	<mntent.h>			/* getmntent ()		*/
typedef		struct mntent	MOUNTENTRY ;

# ifdef USE_STATVFS
# include	<sys/statvfs.h>			/* statvfs ()		*/
typedef		struct statvfs	FSYSSTATUS ;
# endif /* USE_STATVFS */

# ifdef USE_STATFS
# include	<sys/vfs.h>			/* statfs ()		*/
typedef		struct statfs	FSYSSTATUS ;
# endif /* USE_STATFS */

# define	MOUNT_TABLE	MOUNTED		/* "/etc/mtab"		*/

# define	MNT_DEV				mnt_fsname
# define	MNT_PATH			mnt_dir
# define	MNT_TYPE			mnt_type
# define	MNT_OPTS			mnt_opts

# endif /* HPUX */

/*	--	--	--	--	--	--	--	--	*/

# ifdef LINUX

# define	USE_STATVFS
# define	HASFRSIZE

# include	<mntent.h>			/* getmntent ()		*/
typedef		struct mntent	MOUNTENTRY ;

# ifdef USE_STATVFS
# include	<sys/statvfs.h>			/* statvfs ()		*/
typedef		struct statvfs	FSYSSTATUS ;
# endif /* USE_STATVFS */

# ifdef USE_STATFS
# include	<sys/vfs.h>			/* statfs ()		*/
typedef		struct statfs	FSYSSTATUS ;
# endif /* USE_STATFS */

# define	MOUNT_TABLE	MOUNTED		/* "/etc/mtab"		*/

# define	MNT_DEV				mnt_fsname
# define	MNT_PATH			mnt_dir
# define	MNT_TYPE			mnt_type
# define	MNT_OPTS			mnt_opts

# endif /* LINUX */

/*	--	--	--	--	--	--	--	--	*/

# ifdef SOLARIS

# define	HASFRSIZE

# include	<sys/mnttab.h>			/* getmntent ()		*/
# include	<sys/mntent.h>
typedef		struct mnttab	MOUNTENTRY ;

# include	<sys/statvfs.h>			/* statvfs ()		*/
typedef		struct statvfs	FSYSSTATUS ;

# define	MOUNT_TABLE	MNTTAB		/* "/etc/mnttab"	*/

# define	MNT_DEV				mnt_special
# define	MNT_PATH			mnt_mountp
# define	MNT_TYPE			mnt_fstype
# define	MNT_OPTS			mnt_mntopts

# endif /* SOLARIS */

/*	--	--	--	--	--	--	--	--	*/

struct xfsdat {
						/* system */
	MOUNTENTRY *	xfs_mntent ;
	FSYSSTATUS *	xfs_status ;
						/* mntent */
	char *		xfs_device ;
	char *		xfs_path ;
	char *		xfs_type ;
	char *		xfs_options ;
						/* fsstat */
	u_long		xfs_block_size ;
	u_long		xfs_alt_blksiz ;

	fsblkcnt_t	xfs_tot_blocks ;
	fsblkcnt_t	xfs_free_blocks ;
	fsblkcnt_t	xfs_avail_blocks ;

	fsfilcnt_t	xfs_tot_files ;
	fsfilcnt_t	xfs_free_files ;
						/* proper */
	off_t		xfs_tot_bytes ;
	off_t		xfs_free_bytes ;
	off_t		xfs_used_bytes ;
	off_t		xfs_avail_bytes ;

	off_t		xfs_used_files ;

	int		xfs_capacity ;
	int		xfs_ino_perc ;
} ;

typedef		struct xfsdat		XFSDAT ;

/*	--	--	--	--	--	--	--	--	*/

# endif /* _STDXFS_H */

/*
 * vi:nu ts=4
 */

