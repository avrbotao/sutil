
/*		 _______________________________________________________________
 *		|																|
 *		|	stdstat.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDSTAT_H

# define _STDSTAT_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include	<sys/stat.h>

# if defined(HPUX) || defined(SOLARIS) || defined(AIX) || defined(LINUX)
# define	atime	 actime     /* access time */
# define	mtime	 modtime    /* modification time */
# endif

struct		utmbuf		{
	time_t	atime ;
	time_t	mtime ;
} ;

typedef		struct utmbuf	UTMBUF ;

typedef		struct stat		STABUF ;

# define	STABUFSIZ		(sizeof(STABUF))

# define	T_FILE			'f'
# define	T_DIR			'd'
# define	T_BLK			'b'
# define	T_CHR			'c'
# define	T_FIFO			'p'
# define	T_LINK			'l'
# define	T_SOCK			's'
# define	T_NONE			'?'

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STABUF *	statof			OF ( ( char * )					) ;
STABUF *	laststat		OF ( ( void )					) ;

int			typeof			OF ( ( STABUF * )				) ;
long		bytesof			OF ( ( STABUF * )				) ;
long		timeof			OF ( ( STABUF * )				) ;

int			filetype		OF ( ( char * )					) ;
long		filesize		OF ( ( char * )					) ;
long		filetime		OF ( ( char * )					) ;

char *		strmodes			OF ( ( long /* mode_t */ )		) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDSTAT_H */

