
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdtty								tty stuff	|
 *		\ \/ /		|	(c) 1995-2012			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

#ifndef _STDTTY_H_

#define _STDTTY_H_

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

#include "configure.h"

#include <sys/ioctl.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>
#include <stdlib.h>

#include <errno.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include <termios.h>

# ifdef HPUX
# ifndef _XOPEN_SOURCE_EXTENDED
# define	_XOPEN_SOURCE_EXTENDED
# endif
# endif /* HPUX */

#include <curses.h>

#ifdef _HAS_TERMCAP_H_
#include <termcap.h>
#endif /* _HAS_TERMCAP_H_ */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# ifdef CYGWIN
# include <term.h>
# include <sys/termios.h>
# define	TTY_KEY_HIT
# define	FIONREAD	TIOCINQ
# endif /* CYGWIN */

# ifdef SOLARIS
typedef struct termio SGTTY;
# include <term.h>
# define	TTY_KEY_INQ
# define	FIONREAD	FIORDCHK
# endif /* SOLARIS */

# ifdef LINUX
# include <term.h>
# define	TTY_KEY_INQ
# endif /* LINUX */

# ifdef HPUX
# include <term.h>
# endif /* HPUX */

# ifdef BSD
# include <term.h>
# endif /* BSD */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	KEY_PADS		901
# define	KEY_PADE		902

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct	tty_key_data	{
	char *	tcap ;			/*	termcap name		*/
	int		code ;			/*	numeric code		*/
	char *	name ;			/*	label / name		*/
	char *	buff ;			/*	signature bytes		*/
} ;

typedef		struct  tty_key_data		TTY_KEY_DATA ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int					tty_cbreak		( void	  )		;
int					tty_raw			( void	  )		;
int					tty_reset		( void	  )		;
void				tty_atexit		( void	  )		;
struct termios *	tty_getoldattr	( void	  )		;
int					tty_getchar		( void	  )		;
int					tty_getkey		( void	  )		;
int					tty_key_queue	( int key )		;
char *				tty_key_label	( int key )		;
void				tty_key_init	( void	  )		;

/*____________________________________________________________________________
*/

#endif  /* _STDTTY_H_ */

/*
 * vi:nu tabstop=4
 */

