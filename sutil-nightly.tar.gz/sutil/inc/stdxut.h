
/*		 _______________________________________________________________
 *		|																|
 *		|	stdxut.h					(c) 1998-2020 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDXUT_H

# define _STDXUT_H

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

# define	POSIX_MKDIR

# define	DFL_CURRPATHMODE	0755
# define	MAKEPATHBUFFSIZE	4096

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

int		createdir  (char *, int) ;
int		createpath (char *, int) ;

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

# endif /* _STDXUT_H */

/*
 *	vi:nu tabstop=4
 */
