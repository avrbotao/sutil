
/*		 _______________________________________________________________
 *		|																|
 *		|	stdmisc.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDMISC_H

# define _STDMISC_H

/* typedef		unsigned long		ULONG ; */

# ifdef TC2
#		include	<mem.h>
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef _LARGEFILE_SOURCE
# define XLFS64
# endif

# ifdef XLFS64

#	define		KMGTPE(X)		lltokmgtpe(X)

# else  /* XSFS32 */

#	define		KMGTPE(X)		ltokmg(X)

# endif /* XLFS64 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	PTE_DATE	0x00000100
# define	PTE_TIME	0x00000200
# define	PTE_DONE	0x00000400
# define	PTE_PCOK	0x00000400
# define	PTE_TODO	0x00001000
# define	PTE_ELAP	0x00002000
# define	PTE_RATE	0x00004000
# define	PTE_PBAR	0x00010000
# define	PTE_ETTC	0x00020000
# define	PTE_NEWL	0x00040000

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *			abspath		OF ( (char *)								) ;
char *			bintos		OF ( (char *)								) ;
char *			dirpick		OF ( (char *)								) ;
char *			dirscan		OF ( (char *, char *)						) ;
char *			dirview		OF ( (char *)								) ;
char *			dirwalk		OF ( (char *)								) ;
char *			itostr		OF ( (int)									) ;
char *			lastname	OF ( (char *)								) ;
char *			scanview	OF ( (char *, char *)						) ;
char *			stobin		OF ( (char *)								) ;
char *			exptab		OF ( (char *, int)							) ;
char *			xltoa		OF ( (long, int, int)						) ;
char *			xlltoa		OF ( (sbit64, int, int)						) ;

char *			ltokmg		OF ( (long)									) ;
char *			lltokmgtpe	OF ( (sbit64)								) ;

int				ptrel		OF ( (ULONG, ULONG, ULONG)					) ;
int				ptrel64		OF ( (sbit64, sbit64, ULONG)				) ;

int				dotdir		OF ( (char *)								) ;
int				lastoc		OF ( (char *, int)							) ;
int				strcount	OF ( (char *, int)							) ;
int				makedir		OF ( (char *)								) ;
int				makepath	OF ( (char *)								) ;

ULONG			blkstokb	OF ( (ULONG, ULONG)							) ;

void			verban		OF ( ( void )								) ;

void			trimeol		OF ( (char *, int)							) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDMISC_H */

/*
 * vi:tabstop=4
 */
