
/*		 _______________________________________________________________
 *		|																|
 *		|	stdbox.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDBOX_H

# define _STDBOX_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	XUL		   'l'			/* upper left  corner			*/
# define	XUR		   'k'			/* upper right corner			*/
# define	XLL		   'm'			/* lower left  corner			*/
# define	XLR		   'j'			/* lower right corner			*/
# define	XUT		   'w'			/* up (top) "T"					*/
# define	XDT		   'v'			/* down (bottom) "T"			*/
# define	XLT		   't'			/* left "T"						*/
# define	XRT		   'u'			/* right "T"					*/
# define	XXT		   'n'			/* cross (plus) "T"				*/
# define	XVL		   'x'			/* vertical line				*/
# define	XHL		   'q'			/* horizontal line				*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef COMMENT

							3 9 7 1 5 h 4 6 2 8 v (keypad)

							j k l m n q t u v w x (vt100+)
	(glyph)
							: : : : : : : : : : :
	lower right corner .....: : : : : : : : : : :
							  : : : : : : : : : :
	upper right corner .......: : : : : : : : : :
							    : : : : : : : : :
	upper left corner ..........: : : : : : : : :
							      : : : : : : : :
	lower left corner ............: : : : : : : :
							        : : : : : : :
	plus (cross) ...................: : : : : : :
							          : : : : : :
	horizontal line ..................: : : : : :
							            : : : : :
	left tee ...........................: : : : :
							              : : : :
	right tee ............................: : : :
							                : : :
	bottom tee .............................: : :
											  : :
	top tee ..................................: :
												:
	vertical line ..............................:

# endif /* COMMENT */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int			initbox		OF ( (void)										) ;

void		border		OF ( (int, int, int, int)						) ;
void		loadbox		OF ( (char *, int)								) ;

int			getbox		OF ( (char *, int, int, char *, int, int)		) ;

int			gled		OF ( (int, int, char *, int, int)				) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

extern char box_ul ;
extern char box_ur ;
extern char box_ll ;
extern char box_lr ;
extern char box_ut ;
extern char box_dt ;
extern char box_lt ;
extern char box_rt ;
extern char box_xt ;
extern char box_vl ;
extern char box_hl ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	TUL		   '+'			/* tty upper left				*/
# define	TUR		   '+'			/* tty upper right				*/
# define	TLL		   '+'			/* tty lower left				*/
# define	TLR		   '+'			/* tty lower right 				*/
# define	TUT		   '+'			/* tty up "T"					*/
# define	TDT		   '+'			/* tty donw "T"					*/
# define	TLT		   '+'			/* tty left "T"					*/
# define	TRT		   '+'			/* tty right "T"				*/
# define	TXT		   '+'			/* tty cross "T"				*/
# define	TVL		   '|'			/* tty vertical line			*/
# define	THL		   '-'			/* tty horizontal line			*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	DUL		   201			/* double upper left			*/
# define	DUR		   187			/* double upper right			*/
# define	DLL		   200			/* double lower left			*/
# define	DLR		   188			/* double lower right 			*/
# define	DUT		   203			/* double up "T"				*/
# define	DDT		   202			/* double donw "T"				*/
# define	DLT		   204			/* double left "T"				*/
# define	DRT		   185			/* double right "T"				*/
# define	DXT		   206			/* double cross "T"				*/
# define	DVL		   186			/* double vertical line			*/
# define	DHL		   205			/* double horizontal line		*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	SUL		   218			/* single upper left			*/
# define	SUR		   191			/* single upper right			*/
# define	SLL		   192			/* single lower left			*/
# define	SLR		   217			/* single lower right			*/
# define	SUT		   194			/* single up "T"				*/
# define	SDT		   193			/* single down "T"				*/
# define	SLT		   195			/* single left "T"				*/
# define	SRT		   180			/* single right "T"				*/
# define	SXT		   197			/* single cross "T"				*/
# define	SVL		   179			/* single vertical line			*/
# define	SHL		   196			/* single horizontal line		*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	HUL		   213			/* dbl.horz. upper left			*/
# define	HUR		   184			/* dbl.horz. upper right		*/
# define	HLL		   212			/* dbl.horz. lower left			*/
# define	HLR		   190			/* dbl.horz. lower right		*/
# define	HUT		   209			/* dbl.horz. up "T"				*/
# define	HDT		   207			/* dbl.horz. down "T"			*/
# define	HLT		   198			/* dbl.horz. left "T"			*/
# define	HRT		   181			/* dbl.horz. right "T"			*/
# define	HXT		   216			/* dbl.horz. cross "T"			*/
# define	HVL		   179			/* dbl.horz. vertical line		*/
# define	HHL		   205			/* dbl.horz. horizontal line	*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	VUL		   214			/* dbl.vert. upper left			*/
# define	VUR		   183			/* dbl.vert. upper right		*/
# define	VLL		   211			/* dbl.vert. lower left			*/
# define	VLR		   189			/* dbl.vert. lower right		*/
# define	VUT		   210			/* dbl.vert. up "T"				*/
# define	VDT		   208			/* dbl.vert. down "T"			*/
# define	VLT		   199			/* dbl.vert. left "T"			*/
# define	VRT		   182			/* dbl.vert. right "T"			*/
# define	VXT		   215			/* dbl.vert. cross "T"			*/
# define	VVL		   186			/* dbl.vert. vertical line		*/
# define	VHL		   196			/* dbl.vert. horizontal line	*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	GSPC	   ' '			/* graphic white space			*/
# define	ABOX	   223			/* "above" box (or whole box)	*/

# define	G25P	   176			/* ...                          */
# define	G50P	   177			/* ...                          */
# define	G75P	   178			/* ...                          */
# define	G99P	   219			/* ...                          */

# define	SHBX	   220			/* ...                          */
# define	WHBX	   221			/* ...                          */
# define	EHBX	   222			/* ...                          */
# define	NHBX	   223			/* ...                          */

# define	CHECK	   251			/* ...                          */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef   COMMENT

	180 �   181 �   182 �   183 �   184 �   185 �   186 �   187 �

	188 �   189 �   190 �   191 �   192 �   193 �   194 �   195 �

	196 �   197 �   198 �   199 �   200 �   201 �   202 �   203 �

	204 �   205 �   206 �   207 �   208 �   209 �   210 �   211 �

	212 �   213 �   214 �   215 �   216 �   217 �   218 �

# endif   /* COMMENT */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDBOX_H */

/*
 * vi:tabstop=4
 */
