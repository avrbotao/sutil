
/*		 _______________________________________________________________
 *		|																|
 *		|	stdkey.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDKEY_H

# define _STDKEY_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef TC2
# include <conio.h>
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef MSVC
# include <conio.h>
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	KEYBIT			  4096

# define	V_KEY(X)		( KEYBIT | ( X ) )

# define	K_UP			(V_KEY ( 72))	/* "up"					*/
# define	K_DOWN			(V_KEY ( 80))	/* "down"				*/
# define	K_LEFT			(V_KEY ( 75))	/* "left"				*/
# define	K_RIGHT			(V_KEY ( 77))	/* "right"				*/

# define	K_PGUP			(V_KEY ( 73))	/* "pgup"				*/
# define	K_PGDN			(V_KEY ( 81))	/* "pgdn"				*/

# define	K_HOME			(V_KEY ( 71))	/* "home"				*/
# define	K_END 			(V_KEY ( 79))	/* "end"				*/

# define	K_INS			(V_KEY ( 82))	/* "ins"				*/
# define	K_DEL			(V_KEY ( 83))	/* "del"				*/

# define	K_F1			(V_KEY ( 59))	/* F1					*/
# define	K_F2			(V_KEY ( 60))	/* F2					*/
# define	K_F3			(V_KEY ( 61))	/* F3					*/
# define	K_F4			(V_KEY ( 62))	/* F4					*/
# define	K_F5			(V_KEY ( 63))	/* F5					*/
# define	K_F6			(V_KEY ( 64))	/* F6					*/
# define	K_F7			(V_KEY ( 65))	/* F7					*/
# define	K_F8			(V_KEY ( 66))	/* F8					*/
# define	K_F9			(V_KEY ( 67))	/* F9					*/
# define	K_F10			(V_KEY ( 68))	/* F10					*/
# define	K_F11			(V_KEY (133))	/* F11					*/
# define	K_F12			(V_KEY (134))	/* F12					*/

# define	S_F7			(V_KEY ( 90))	/* shift F7				*/
# define	S_F8			(V_KEY ( 91))	/* shift F8				*/
# define	S_F9			(V_KEY ( 92))	/* shift F9				*/
# define	S_F10			(V_KEY ( 93))	/* shift F10			*/

# define	C_UP			(V_KEY (141))	/* ctrl "up"			*/
# define	C_DOWN			(V_KEY (145))	/* ctrl "down"			*/
# define	C_LEFT			(V_KEY (115))	/* ctrl "left"			*/
# define	C_RIGHT			(V_KEY (116))	/* ctrl "right"			*/

# define	C_PGUP			(V_KEY (132))	/* ctrl "pgup"			*/
# define	C_PGDN			(V_KEY (118))	/* ctrl "pgdn"			*/

# define	C_HOME			(V_KEY (119))	/* ctrl "home"			*/
# define	C_END			(V_KEY (117))	/* ctrl "end"			*/

# ifdef COMMENT

shift f1 --> shift f10   =  84 -->  93
ctrl  f1 --> ctrl  f10   =  94 --> 103
alt   f1 --> alt   f10   = 104 --> 113

# endif /* COMMENT */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

struct keyinfo {
	char *	ki_id   ;		/* termcap codename			*/
	int		ki_code ;		/* internal value			*/
	char *	ki_name ;		/* identification			*/
	char *	ki_sign ;		/* signature				*/
} ;

typedef		struct	keyinfo		KEYINFO ;

# define	KI_SIZE				sizeof (KEYINFO)

# define	KF_BURST			0x0001
# define	KF_FORCE			0x0002

# define	KEY_FAKE			"\033~~~%d~"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *		xkeyname			OF ( ( int )							) ;
char *		keysign				OF ( ( char * )							) ;

void		fixkeys				OF ( ( int )							) ;
void		sortkeys			OF ( ( void )							) ;
int			readkey				OF ( ( void )							) ;
int			anyxkey				OF ( ( int )							) ;
int			repairkey			OF ( ( char * )							) ;
int			loadkey				OF ( ( char * , char * , int )			) ;

int			setkeyent			OF ( ( void )							) ;
KEYINFO *	getkeyent			OF ( ( void )							) ;
int			endkeyent			OF ( ( void )							) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDKEY_H */

/*
 * vi:nu ts=4
 */
