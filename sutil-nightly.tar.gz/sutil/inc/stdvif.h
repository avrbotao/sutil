
/*		 _______________________________________________________________
 *		|																|
 *		|	stdvif.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDVIF_H

# define _STDVIF_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef MSVC

# include	<windows.h>
# include	<dos.h>
# include	<io.h>
# include	<conio.h>

# endif /* MSVC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef TC2

# include	<dos.h>
# include	<io.h>

# endif /* TC2 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void	strout  		OF ( (char *, int)		) ;
void	cursorat  		OF ( (int, int)			) ;

void	clearline		OF ( (void)				) ;
void	clearscreen		OF ( (void)				) ;

void	altchrset		OF ( (void)				) ;
void	dflchrset		OF ( (void)				) ;

void	reversevideo	OF ( (void)				) ;
void	normalvideo		OF ( (void)				) ;
void	blinkvideo		OF ( (void)				) ;
void	boldvideo		OF ( (void)				) ;
void	colorvideo		OF ( (int, int)			) ;

void	honk			OF ( (void)				) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDVIF_H */

