/*		 _______________________________________________________________
 *		|																|
 *		|	stdcap.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDCAP_H

# define _STDCAP_H

# ifdef ANYX

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	KEYPADXMIT

# define	ENVTERMCAP		"TERMCAP"		/* MUST start with "/"		*/

struct capinfo {
	char *		cap_id ;	/* terminal capability identification	*/
	char * *	cap_ptr ;	/* pointer to buffer ...				*/
	int			cap_len ;	/* strlen () ...						*/
} ;

typedef		struct	capinfo		CAPINFO ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef SOLARIS
/*
int			byteout			OF ( (char)								) ;
*/
int			byteout			(char) ;
char * tgoto ( char * cap , int col , int row ) ;
# else
int			byteout			OF ( (int)								) ;
# endif
int			readcaps		OF ( (void)								) ;
void		endcaps			OF ( (void)								) ;
void		putcap			OF ( (char *)							) ;
void		byteflush		OF ( (void)								) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* ANYX */

char *		termname		OF ( (void)								) ;

# endif /* _STDCAP_H */

/*
 * vi:nu ts=4
 */
