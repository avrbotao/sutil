
# ifndef _LOGDMP_H_

# define _LOGDMP_H_

# ifdef LOGDMPDBG

# include <stdio.h>

/* extern FILE * stdlog ; */
# define	stdlog		stderr

# define	logdmpint(T,I)	fprintf(stdlog,"%s=(%d)\r\n",T,I);
# define	logdmpstr(T,S)	fprintf(stdlog,"%s=(%s)\r\n",T,(S==NULL)?"NULL":S);

# else

# define	logdmpint(T,I)
# define	logdmpstr(T,S)

# endif

# endif /* _LOGDMP_H_ */

