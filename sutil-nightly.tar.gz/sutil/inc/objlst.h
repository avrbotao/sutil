
/*		 _______________________________________________________________
 *		|																|
 *		|	objlst.h					(c) 1996-2008 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _OBJLST_H

# define _OBJLST_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# if ! ( defined (VPTRCHAR) || defined (VPTRVOID) )
#	error	"must define VPTR{CHAR|VOID}"
# endif

# ifdef		VPTRCHAR
#	define	VPTR	char
# endif		/* VPTRCHAR */

# ifdef		VPTRVOID
#	define	VPTR	void
# endif		/* VPTRVOID */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

struct	objlstelm {
	long		ole_pos ;
	VPTR *		ole_ptr ;
} ;

typedef		struct objlstelm		OBJLSTELM ;

struct	objlstctl	{
	char *		olc_nam ;		/*	obj lst id							*/
	long		olc_max ;		/*	max entries (phys.len)				*/
	long		olc_tot ;		/*	used entries (log.len)				*/
	long		olc_cur ;		/*	current entry						*/
	long		olc_inx ;		/*	insertion point						*/
	long		olc_flg ;		/*	mode bits							*/
	OBJLSTELM *	olc_vec ;		/*	the lst itself						*/
} ;

typedef		struct objlstctl		OBJLSTCTL ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	OBJLSTHDRMRK		'\004'

# define	OBJLSTELMSIZ		(sizeof(OBJLSTELM))
# define	OBJLSTCTLSIZ		(sizeof(OBJLSTCTL))

# define	OLM_GET				0x8000
# define	OLM_SET				0x4000
# define	OLM_ON				0x2000
# define	OLM_OFF				0x1000

# define	OLM_SORT			0x0001		/* OFF = unsorted			*/
# define	OLM_ASCEND			0x0002		/* OFF = DESCENDING			*/
# define	OLM_STACK			0x0004		/* pos , descending			*/
# define	OLM_QUEUE			0x0008		/* pos , ascending			*/

# define	OLM_UNIQ			0x0010		/* OFF = DUPLICATED			*/
# define	OLM_WRAP			0x0020		/* OFF = AUTO_EXPAND		*/
# define	OLM_VONLY			0x0040		/* OFF = PICKABLE			*/
# define	OLM_SAVE			0x0080		/* OFF = NOTSAVEABLE		*/

# define	OLM_RAW				0x0100		/* OFF = COOKED				*/
# define	OLM_TAB				0x0200		/* EXPAND TABS to spaces	*/
# define	OLM_MAP				0x0400		/* map NON-printable chrs	*/

# ifdef NOWRAP

# define	OLM_DEFAULT			(OLM_RAW|OLM_SORT|OLM_ASCEND|OLM_UNIQ)

# define	DFL_MAXOBJLSTSIZ		0

# else  /* WRAP */

# define	OLM_DEFAULT			(OLM_RAW|OLM_SORT|OLM_ASCEND|OLM_UNIQ|OLM_WRAP)

# define	DFL_MAXOBJLSTSIZ	 4096

# endif /* NOWRAP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

OBJLSTCTL *	alocobjlst		ARGLST ( ( char * , int )					) ;
OBJLSTCTL *	makeobjlst		ARGLST ( ( char * , int )					) ;
OBJLSTCTL *	currobjlst		ARGLST ( ( void )							) ;
void		freeobjlst		ARGLST ( ( OBJLSTCTL * )					) ;

int			pickobjlst		ARGLST ( ( OBJLSTCTL * )					) ;
int			modeobjlst		ARGLST ( ( int , int )						) ;
int			sortobjlst		ARGLST ( ( void )							) ;

int			fputobjlst		ARGLST ( ( FILE * , OBJLSTCTL * )			) ;
int			fgetobjlst		ARGLST ( ( FILE * , OBJLSTCTL * * )			) ;
int			saveobjlst		ARGLST ( ( char * )							) ;
int			loadobjlst		ARGLST ( ( char * )							) ;
int			feedobjlst		ARGLST ( ( char * )							) ;
int			killobjlst		ARGLST ( ( int )							) ;

char *		viewobjvect		ARGLST ( ( char * * , char * )				) ;
char *		viewobjfile		ARGLST ( ( char * , char * )				) ;
char *		viewobjlst		ARGLST ( ( char * )							) ;

char *		peekobjlst		ARGLST ( ( char * , int )					) ;
char *		prevobjlst		ARGLST ( ( char * )							) ;
char *		nextobjlst		ARGLST ( ( char * )							) ;
int			findobjlst		ARGLST ( ( char * )							) ;
int			matchobjlst		ARGLST ( ( char * )							) ;

# ifdef TC3
#	ifdef BCC55
int			compobjlst		ARGLST ( ( OBJLSTELM * , OBJLSTELM * )		) ;
#	else
int			compobjlst		ARGLST ( ( const void * , const void * )	) ;
#	endif
# else
#	ifdef OLD
int			compobjlst		ARGLST ( ( char * * , char * * )			) ;
#	else
int			compobjlst		ARGLST ( ( OBJLSTELM * , OBJLSTELM * )		) ;
#	endif
# endif

void		dispnorm		ARGLST ( ( char * )							) ;
void		disprev			ARGLST ( ( char * )							) ;
char *		prepout			ARGLST ( ( int , char * )					) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _OBJLST_H */

/*
 * vi:nu ts=4
 */
