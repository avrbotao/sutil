
# ifndef NONET

/*		 _______________________________________________________________
 *		|																|
 *		|	stdnet.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDNET_H

# define _STDNET_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include	<sys/types.h>
# include	<fcntl.h>

# include	<sys/socket.h>
# include	<netinet/in.h>
# include	<netdb.h>

# ifdef USE_TLI
#	include	<tiuser.h>
# endif

# include	<varargs.h>

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

extern	int		errno ;

# ifdef	NOERRLIST
extern	char *	sys_errlist [] ;
# endif

extern	int		t_errno ;
extern	char *	t_errlist [] ;

u_long	inet_addr () ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifndef	INADDR_NONE
# define	INADDR_NONE			0xffffffff
# endif		/* INADDR_NONE */

# define	TCPSVC				0x0001
# define	UDPSVC				0x0002

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDNET_H */

# endif /* NONET */

/*
 * vi:tabstop=4
 */
