
void		noparms		OF ( ( void )								) ;

void		prologue	OF ( ( void )								) ;
void		drudgery	OF ( ( void )								) ;
void		epilogue	OF ( ( void )								) ;

void		cmdsyn		OF ( ( void )								) ;
void		sysenv		OF ( ( void )								) ;
void		lisopt		OF ( ( void )								) ;

int			xalert		OF ( (int, char *, char *, int)				) ;

