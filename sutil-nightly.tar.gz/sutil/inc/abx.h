
# ifndef _ABX_H

# define _ABX_H

/*	 _______________________________
 *	|____operating_stystem__________|
 */

# if	defined (__CYGWIN__)
typedef		__int64_t	sbit64 ;
typedef		__uint64_t	ubit64 ;
typedef		unsigned long	ulong ;
# define	NSECXTIM
# endif

# if	defined (_AIX)
typedef		int64_t		sbit64 ;
typedef		uint64_t	ubit64 ;
# define	NSECSPAR
# define	UNKENDIAN
# endif

# if	defined (__hpux)
typedef		int64_t		sbit64 ;
typedef		uint64_t	ubit64 ;
# define	UNKENDIAN
# endif

# if	defined (linux) || defined (__linux)
typedef		int64_t		sbit64 ;
typedef		u_int64_t	ubit64 ;
# endif

# if	defined (sun)
typedef		longlong_t	sbit64 ;
typedef		uint64_t	ubit64 ;
# define	NSECXTIM
# define	BIGENDIAN
# endif

# if	defined (__aux)
# define	UNKENDIAN
# endif

# if	defined (__dgux)
# define	UNKENDIAN
# endif

# if	defined (sgi) || defined (__sgi)
# define	UNKENDIAN
# endif

# if	defined (SYSV)
# define	UNKENDIAN
# endif

# if	defined (__SVR4)
# define	UNKENDIAN
# endif

# if	defined (CRAY)
# define	UNKENDIAN
# endif

# if	defined (__convex)
# define	UNKENDIAN
# endif

# if	defined (unix) || defined (__unix) || defined (__unix__)
# define	UNKENDIAN
# endif

# if	defined (bsdi)
# define	GENBSD
# endif

# if	defined (__FreeBSD__)
typedef		__int64_t	sbit64 ;
typedef		__uint64_t	ubit64 ;
# define	GENBSD
# endif

# if	defined (__OpenBSD__)
typedef		__int64_t	sbit64 ;
typedef		__uint64_t	ubit64 ;
# define	GENBSD
# endif

# if	defined (__NetBSD__)
# define	GENBSD
# endif

# if	defined (_BSD)
# define	UNKENDIAN
# endif

# if	defined (__MSDOS__)
# define	LITENDIAN
# endif

/*	 _______________________________
 *	|____processor_type_____________|
 */

# if	defined (sparc) || defined (__sparc) || defined (__sparc__) 
# define	BIGENDIAN
# endif

# if	defined (__ppc__)
# define	BIGENDIAN
# endif

# if	defined (__ppc64__)
# define	BIGENDIAN
# endif

# if	defined (__alpha)
# define	LITENDIAN
# endif

# if	defined (__ultrix)
# define	LITENDIAN
# endif

# if	defined (__ia32)
# define	LITENDIAN
# endif

# if	defined (__ia64) || defined (__ia64__) || defined (__x86_64__)
# define	LITENDIAN
# endif

# if	defined (i386) || defined (__i386) || defined (__x86)
# define	LITENDIAN
# endif

# if	defined (__s390x__)
# define	BIGENDIAN
# endif

# if	defined (cray)
# define	BIGENDIAN
# endif

/*	 _______________________________
 *	|____compiler_type______________|
 */

# if	defined (__GNUC__)
#	define	LITENDIAN
# endif

# if	defined (MSVC) || defined (_MSC_VER)
typedef		__int64		sbit64 ;
#	define	LITENDIAN
# endif

# if	defined (_M_IX86)
#	define	LITENDIAN
# endif

# if	defined (__INTEL_COMPILER)
#	define	LITENDIAN
# endif

# if	defined (__STDC__)
#	define	LITENDIAN
# endif

/*	 _______________________________
 *	|____miscellaneous______________|
 */

# if	defined (_POSIX_SOURCE)
#	define	UNKENDIAN
# endif

# if	(_FILE_OFFSET_BITS == 64) && defined (_LARGEFILE_SOURCE)
#	define	XLFS64
# endif

# include "absd.h"

/*	__	__	__	__	__	__	__	__	*/

/*
 * hp-ux 11.11
 * -D__hp9000s800 -D__hppa -D__hpux -D__unix -D_ILP32 –e
 * -D_PA_RISC2_0 -D_HPUX_SOURCE -D__STDC_EXT__
 *
 * solaris8
 * gcc version 2.95.3 20010315 (release)
 * /usr/local/lib/gcc-lib/sparc-sun-solaris2.8/2.95.3/cpp0 -lang-c -v -D__GNUC__=2 -D__GNUC_MINOR__=95
 * -Dsparc -Dsun -Dunix -D__svr4__ -D__SVR4 -D__sparc__ -D__sun__ -D__unix__
 * -D__svr4__ -D__SVR4 -D__sparc -D__sun -D__unix
 * -Asystem(unix) -Asystem(svr4) -D__GCC_NEW_VARARGS__
 * -Acpu(sparc) -Amachine(sparc)
 *
 */

# endif /* _ABX_H */

