
/*		 _______________________________________________________________
 *		|																|
 *		|	stdcompr.h						 (c) 2000 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDCOMPR_H

# define _STDCOMPR_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef LZRW1COMPR

/* fca (fast compression algorithm) lzrw1 (timestamp=19910528144250) */

#define   FLAG_Copied         0x80
#define   FLAG_Compress       0x40
#define   TRUE                1
#define   FALSE               0
typedef   signed char         byte;
typedef   signed short        word;
typedef   unsigned char       ubyte;
typedef   unsigned short      uword;
typedef   unsigned long       ulong;
typedef   unsigned char       bool;

#define   OurIdentifier  0xa5b6c7d8

# endif /* LZRW1COMPR */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDCOMPR_H */
