
/*		 _______________________________________________________________
 *		|																|
 *		|	stdmem.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDMEM_H

# define _STDMEM_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef ANYX

#	ifdef	GETRLIMIT
#		include <sys/time.h>
#		include <sys/resource.h>
#		include <unistd.h>
#	endif

#	ifdef	SYSULIMIT
#		include <sys/ulimit.h>
#	endif

#	ifdef	ULIMIT
#		include <ulimit.h>
#	endif

# ifdef UL_GMEMLIM
#	define	GETRAMLIM		UL_GMEMLIM
# endif

# ifdef GET_DATALIM
#	define	GETRAMLIM		GET_DATALIM
# endif

# ifdef GETRLIMIT
#	define	GETRAMLIM		RLIMIT_DATA
# endif

# endif /* ANYX */

# ifdef	TC2

#	include	<alloc.h>

# endif /* TC2 */

# ifdef	MSVC

# include <windows.h>

# endif /* MSVC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

struct	memctl	{

	char *		mc_ptr ;
	unsigned	mc_siz ;
} ;

typedef		struct memctl		MEMCTL ;

# define	MEMCTLSIZ			( sizeof ( MEMCTL ) )

struct	meminfo	{

	long		mi_req ;				/* requested bytes				*/
	long		mi_tax ;				/* extra control bytes			*/
	long		mi_top ;				/* maximum usable bytes			*/
	long		mi_fre ;				/* available bytes				*/
	unsigned	mi_tot ;				/* total memory blocks			*/
	unsigned	mi_cnt ;				/* active memory blocks			*/
	unsigned	mi_reu ;				/* freed up memory blocks		*/
	long		mi_kma ;				/* xmalloc()'s					*/
	long		mi_kca ;				/* xmcalloc()'s					*/
	long		mi_kre ;				/* xmrealloc()'s				*/
	long		mi_kfr ;				/* xmfree()'s					*/
} ;

typedef		struct meminfo		MEMINFO ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *			xmalloc		OF ( ( unsigned )							) ;
char *			xmcalloc	OF ( ( unsigned , unsigned )				) ;
char *			xmrealloc	OF ( ( char * , unsigned )					) ;

int				xmfree		OF ( ( char * )								) ;
int				xminit		OF ( ( void )								) ;
int				xmgrow		OF ( ( void )								) ;

long			xmused		OF ( ( void )								) ;
long			xmctrl		OF ( ( void )								) ;
long			xmavail		OF ( ( void )								) ;
long			xmlimit		OF ( ( long )								) ;

long			memlimit	OF ( ( void )								) ;
long			memleft		OF ( ( void )								) ;

void			xmdump		OF ( ( char * )								) ;

MEMCTL *		xmfind		OF ( ( char * )								) ;

MEMINFO *		xminfo		OF ( ( void )								) ;

# ifdef NOMEMICMP
int				memicmp		OF ( ( char * , char * , int )				) ;
# endif /* NOMEMICMP */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	NEW(T)				(T *) xmalloc ( sizeof (T) )

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDMEM_H */

/*
 * vi:ts=4
 */
