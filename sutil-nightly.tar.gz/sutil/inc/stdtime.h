
/*		 _______________________________________________________________
 *		|																|
 *		|	stdtime.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDTIME_H

# define _STDTIME_H

# include <time.h>
# include <utime.h>

# define	CF_TIME		0x0001

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

typedef		struct timespec		TIMESPEC ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *			strtime		OF ( (long)									) ;
char *			strhourmin	OF ( (long)									) ;
char *			strdate		OF ( (long)									) ;
char *			strdaymon	OF ( (long)									) ;
char *			timestamp	OF ( (long)									) ;

long			maketime	OF ( (int, int, int, int, int, int, int)	) ;

void			timechop	OF ( ( long, int *, int *, int *,
										 int *, int *, int * )			) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDTIME_H */

/*
 * vi:tabstop=4
 */
