
/*		 _______________________________________________________________
 *		|																|
 *		|	stdsig.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDSIG_H

# define _STDSIG_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include <signal.h>

# ifdef SIGVOID

#	define	SIGTYP			void

# else

#	define	SIGTYP			int

# endif

typedef		SIGTYP			(*SIGFUN)() ;

struct	sigctrl {

	int		sc_cod ;
	SIGFUN	sc_fun ;
} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDSIG_H */

