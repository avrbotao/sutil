
/*
 *                   _______________________________________________
 *		  /\        |												|
 *		 /  \       |	 xar			  some archiving utility	|
 *		/ OO \      |_______________________________________________|
 *		\ \/ /      |												|
 *		 \  /       |	 (c) 1991-2006     alexandre v. r. botao	|
 *		  \/        |_______________________________________________|
 *
 */

# define	VERNAME			"xar"
# define	VERSION			"1.6"
# define	VERCODE			"673"
# define	VERDATE			"2009.05.20"
# define	VERSIGN			"Alexandre Botao"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDIO
# define	USE_STDLIB

# define	USE_SYSTYPES

# define	USE_STDAPP
# define	USE_STDPARM
# define	USE_STDTIME
# define	USE_STDSTR
# define	USE_STDMATCH
# define	USE_STDSTAT
# define	USE_STDCRC
# define	USE_STDASC
# define	USE_STDMEM
# define	USE_STDTYP
# define	USE_STDFILE
# define	USE_STDMISC
# define	USE_STDLOGIC

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef TC2
#	include <dir.h>
#	include <dos.h>
#	include <io.h>
# endif /* TC2 */

# ifdef MSVC
#	include <io.h>
# endif /* MSVC */

# ifdef	ANYX
#	include <ctype.h>
#	ifdef	SYSVDIR
#		include	<dirent.h>
#	else	/* V7DIR */
#		include	<sys/dir.h>
#	endif	/* SYSVDIR */
#	include <unistd.h>
# endif	/* ANYX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	elif			else if

# define	BAD				-1

# define	NOSTR			NULL			/* ((char *) 0)	*/
# define	NOFILE			((FILE *) 0)

# ifndef	SEEK_CUR
# define	SEEK_CUR	1
# endif		/* ! SEEK_CUR */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	data prototypes ...		|
 *	|___________________________|
 */

# ifdef		SYSVDIR

# ifdef SYSVDIRBUG
		struct xdirent {
			ino_t	d_ino ;
			off_t	f_off ;
			char	d_name[1] ;
		} ;
		typedef		struct xdirent	DIRENT ;
# else
		typedef		struct dirent	DIRENT ;
# endif

# endif		/* SYSVDIR */

struct  filinf  {

# ifdef ANYX
	ULONG fi_tim ;
# endif /* ANYX */
	ULONG fi_mod ;
	ULONG fi_siz ;
} ;

TYP		struct filinf	FILINF ;

# ifdef TC2

TYP		struct ffblk	STABLK ;
/* TYP		struct ffblk	FFBLK ; */
TYP		int				mode_t ;

# endif /* TC2 */

# ifdef	ANYX

TYP		struct stat		STABLK ;

# endif /* ANYX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef   XARBIN

struct  xarhdr  {	/* 128 byts	*/
	char	kh_cod [8] ;
	ULONG	kh_siz ;
	ULONG	kh_tim ;
	char	kh_atr [8] ;
	ULONG	kh_crc ;
	char	kh_etc [8] ;
	char	kh_nam [ 128 - 24 - 12 ] ;
} ;

# endif   /* XARBIN */

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	definitions ...		|
 *	|_______________________|
 */

# define  XARBUFSIZ		0x4000 /* (16KB)  4096 */

/* # define  FA_MASK		( FA_ARCH | FA_DIREC | FA_RDONLY | FA_SYSTEM | FA_HIDDEN ) */

# define  MAXHDRLEN		  2048
# define  MAXRAWC		  1024
# define  MAXFLST		  4096
# define  NHDRSLC		     8
# define  NAMSIZ		    80

# define  MAGICS		"@$#!&~^"

# define  HDRFMT		"%s %12ld %12ld acs %12ld %12ld etc %s\r\n"

# define  NAMFMT		"%s.%s"

# define  XAREXT		"xar"
# define  OLDEXT		"olk"
# define  NEWEXT		"nuk"

# define  FEWMEM		"memoria insuficiente"
# define  MADHDR		"header inconsistente"

# define  NOREAD		"ERRO de leitura"
# define  NOWRIT		"ERRO de gravacao"
# define  ERENAM		"ERRO ao renomear"
# define  DELERR		"ERRO ao deletar"
# define  STATER		"ERRO ao verificar"
# define  CANTAC		"ERRO ao acessar"
# define  CANTAP		"ERRO ao acrescentar"
# define  CANCRE		"ERRO ao criar"
# define  NFINKN		"ERRO ao procurar"
# define  TOCHER		"ERRO ao atualizar data"
# define  CMODER		"ERRO ao restaurar atributos"

# define  CREATN		"    criando"
# define  SRCHIN		"pesquisando"
# define  ADDING		"adicionando"
# define  UPDING		"atualizando"
# define  DELING		"  deletando"
# define  EXTING		"  extraindo"
# define  SKPING		"    pulando"
# define  KEPING		"   mantendo"
# define  CHKING		"verificando"
# define  BALING		"balanceando"

# define  ADDXAR		'a'
# define  UPDXAR		'u'
# define  VUEXAR		'v'
# define  DELXAR		'd'
# define  XTRXAR		'x'

# define  XAR_EQUALIZE	'e'
# define  XAR_FRESHEN	'f'
# define  XAR_CHECK		't'
# define  XAR_BALANCE	'b'

# define  USABLE		'+'
# define  USEDOK		'~'

# define  FATAL			-1
# define  BANAL			FALSE
# define  OK			(1)
# define  FAIL			(-1)

# define  HDRCOD		*(hdrslc +  0)
# define  HDRSIZ		*(hdrslc +  1)
# define  HDRTIM		*(hdrslc +  2)		/* unix-style time stamp	*/
# define  HDRACS		*(hdrslc +  3)		/* access code ...			*/
# define  HDRATR		*(hdrslc +  4)
# define  HDRCRC		*(hdrslc +  5)
# define  HDRETC		*(hdrslc +  6)
# define  HDRNAM		*(hdrslc +  7)

# define  FINTIM		((*(finlst+twin))->fi_tim)

# define  HDRTIB		(atol(HDRTIM))
# define  HDRMOD		(atol(HDRATR))

/* # define  HDRC32		(atol(HDRCRC)) */

# define  XARDFLCOL		"\033[m"

/*
 *		local macros ...
 */

# define  MARKOK(P)		useflg [ P ] = USEDOK
# define  UNUSED(P)		( useflg [ P ] == USABLE )

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	function prototypes ...		|
 *	|_______________________________|
 */

void	xar			OF ( ( void ) ) ;
void	putmsg		OF ( ( char * , char * , int ) ) ;
void	blowlst		OF ( ( void ) ) ;
void	wildexp		OF ( ( char * ) ) ;

# ifdef TC2

void	savnam		OF ( ( char * , FFBLK * ) ) ;

# else  /* ANYX */

void	savnam		OF ( ( char * , STABLK * ) ) ;
void	blowdir		OF ( ( char * ) ) ;

# endif /* TC2 */

void	epilog		OF ( ( int ) ) ;
void	hdrstuf		OF ( ( void ) ) ;
void	usag		OF ( ( void ) ) ;

char *	xsctim		OF ( ( ULONG ) ) ;

int		belongs		OF ( ( char * , char * * ) ) ;
int		badnam		OF ( ( char * ) ) ;

void	prologue	OF ( ( void )				) ;

char *	xsmode		OF ( ( ULONG )				) ;

void	getepoch	OF ( ( FILE * )				) ;
void	setepoch	OF ( ( FILE * )				) ;

void	blowdir		OF ( ( char * )				) ;

void	xarcopy		OF ( (FILE *, FILE *, ULONG, int)				) ;

char *	xarlsc		OF ( ( char * ) ) ;

/*
 *	|~~~~~~~~~~~~~~~~~~~|
 *	|	globals ...		|
 *	|___________________|
 */

# include "stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-abcdefilnoprtuvxELV?] xarfile [filespec ...] \n",
	"\n",

	"  -a : adicionar \n",
	"  -b : balancear \n",
	"  -c : criar diretorios ao extrair \n",
	"  -d : deletar \n",
	"  -e : equalizar \n",
	"  -f : atualizar \n",
	"  -i : atualizar incondicionalmente \n",
	"  -l : listar status (detalhado) \n",
	"  -n : listar nomes \n",
	"  -o : sobrepor ao extrair \n",
	"  -p : pesquisar diretorios recursivamente \n",
	"  -r : filtrar CR ao extrair \n",
	"  -t : testar integridade \n",
	"  -u : atualizar e adicionar \n",
	"  -v : listar status (resumido) \n",
	"  -x : extrair \n",

# include "stdflag.h"

	NULL

} ;

PARMINFO	parminfo [] = {

# include "deflbits.h"

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xarpath = NOSTR ;
char * useflg = NOSTR ;							/* use flags 4 paths	*/

char * hdrslc [ NHDRSLC ] = { NOSTR } ;			/* header slices ...	*/
char * rawlst [ MAXRAWC ] = { NOSTR } ;			/* raw wildcars 2 blow	*/
char * foolst [ MAXFLST ] = { NOSTR } ;			/* cooked pathnames ...	*/

char * * uselst = rawlst ;

char hdrname [1024] ;

char hdrlin [ MAXHDRLEN ] ;
char actxar [ NAMSIZ ] ;
char oldxar [ NAMSIZ ] ;
char newxar [ NAMSIZ ] ;

char op = ADDXAR ;								/* defaults 2 u/d ...	*/

int copyflags = COPYBIN ;

int rawfk = 0 ;
int pathk = 0 ;
int allflg = FALSE ;
int xardok = TRUE ;
int chkupd = TRUE ;
int twin ;
int slck ;											/* slice count		*/
int hdrlen ;
int touched = FALSE ;
int kutok ;
int pedcnt = 0 ;								/* # files processed	*/
int outhdr = 0 ;

int cflag = 0 ;
int eflag = 0 ;
int iflag = 0 ;
int nflag = 0 ;
int oflag = 0 ;
int rflag = 0 ;
int vflag = 0 ;
int tflag = 0 ;

ULONG hdrcrc ;
ULONG filcrc ;

long hdrofs ;
long cpyofs ;

int procrc ;

ULONG filmod ;
ULONG hdrmod ;
ULONG hdrsib ;										/* siz (byts)		*/
ULONG filsib ;
ULONG hdrtib ;										/* tim (bin)		*/
ULONG nxhofs ;
ULONG pedsiz = 0L ;								/* # bytes processed	*/

void ( * whop ) OF ( ( char * , STABLK * ) ) ;

FILE * sfp = NOFILE ;
FILE * tfp = NOFILE ;
FILE * xfp = NOFILE ;

FILINF * finlst [ MAXFLST ] ;	/* should b xmrealloc'ed dyn/y ...		*/

# ifdef TC2

struct ftime		xftp ;

/* extern */ unsigned _stklen = 16384 ;

# else  /* ANYX */

struct stat			xarstat ;

UTMBUF				xarutim ;

# endif /* TC2 */

char * months [] = {
	"jan" , "fev" , "mar" , "abr" , "mai" , "jun" ,
	"jul" , "ago" , "set" , "out" , "nov" , "dez" ,
	NULL
} ;

char xarlscbuf [2048] ;
char xarsetcol [32] = XARDFLCOL ;
char xarendcol [32] = XARDFLCOL ;

/************************************************************************
*	entry + [ flags & parameters ] processing ...						*
************************************************************************/

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch ( *((*argv)+1) ) {

					case 'r' : copyflags = COPYASC ; break ;

				/*	case 'B' : copyflags = COPYBIN ; break ;	*/

					case 'c' : ++cflag ; break ;

					case 'i' : ++iflag ; break ;

					case UPDXAR : break ;			/* default is u/d	*/
					case ADDXAR : chkupd = FALSE ;
					case VUEXAR :
					case XTRXAR :
					case DELXAR :

					case XAR_FRESHEN :
					case XAR_CHECK :
					case XAR_BALANCE :
							op = *((*argv)+1) ;
							break ;

					case XAR_EQUALIZE :

							++eflag ;
							op = XTRXAR ;
							break ;

					case 'l' :

							++vflag ;
							op = VUEXAR ;
							break ;

					case 'n' :

							++nflag ;
							op = VUEXAR ;
							break ;

					case 'o' : ++oflag ; break ;

					case 'p' : ++rflag ; break ;

					case '?' :
					default : usag () ;
				}
			} else {
				if (xarpath == NOSTR)
					xarpath = *argv ;
				else
					*(rawlst + rawfk++) = *argv ;
			}
		}

/* intrinsic processing */

		*(rawlst + rawfk) = NOSTR ;
	} else {
		usag () ;
	}

	if ( xarpath == NOSTR ) {
		usag () ;
	}

	prologue () ;

	xar () ;

/* epilogue processing */

	epilog (0) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	SETBIT (flagbits, PI_SYNTAXBIT) ;
}

/************************************************************************
*	expand wildcards from one list into another & collect status		*
************************************************************************/

void blowlst () {
	REG char * * raw = rawlst ;

	whop = savnam ;

	while (*raw) {
		wildexp (*raw) ;
		++raw ;
	}
	foolst [ pathk ] = NOSTR ;
	* ( finlst + pathk ) = (FILINF *) 0 ;
}

/************************************************************************
*	wildcards (dos-style regular expressions) explosion & processing	*
************************************************************************/

void wildexp (nam) char * nam ; {

# ifdef TC2

	struct ffblk ffbuf ;
	char fnbuf [ 1024 ] ;
	char * fnptr = ffbuf.ff_name ;
	int slasti ;

	if (findfirst (nam, &ffbuf, FA_MASK) < 0) {
		printf ("\n%s: can't access %s\n", swid, nam) ;
		return ;
	}

	if ((slasti = lastoc (nam, DIRSEP)) >= 0)
		strcpy (fnptr = fnbuf, nam) ;

	do {
		if ( dotdir (ffbuf.ff_name) )
			continue ;

		if (fnptr == fnbuf)
			strcpy (fnptr + slasti + 1, ffbuf.ff_name) ;

		if (ffbuf.ff_attrib & FA_DIREC) {
			if (rflag)
				blowdir (fnptr) ;
		} else if (ffbuf.ff_attrib & FA_ARCH)
			( * whop ) ( fnptr , & ffbuf ) ;

	} while (findnext (&ffbuf) >= 0) ;

# else  /* ANYX */

	STABLK stabuf ;

	if ( (rawfk == 1) && (*nam == '*') && (*(nam+1) == '\0') ) {
		blowdir (".") ;
		return ;
	}

	if (stat (nam, &stabuf) < 0) {
		putmsg (STATER, nam, BANAL) ;
		return ;
	}

	if ( (stabuf.st_mode & S_IFMT) == S_IFREG )
		( * whop ) ( nam , & stabuf ) ;
	else if ( (stabuf.st_mode & S_IFMT) == S_IFDIR )
		blowdir (nam) ;

# endif /* TC2 */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blowdir (nam) char * nam ; {

# ifdef TC2

	char tb [512] ;
	struct ffblk ffbuf ;
	char fnbuf [512] ;
	char * fnptr = ffbuf.ff_name ;
	int slasti ;

	sprintf (tb, "%s\\*.*", nam) ;

	if (findfirst (tb, &ffbuf, FA_MASK) < 0)
		return ;

	if ((slasti = lastoc (tb, DIRSEP)) >= 0)
		strcpy (fnptr = fnbuf, tb) ;
	else if ((slasti = lastoc (tb, ':')) >= 0)
		strcpy (fnptr = fnbuf, tb) ;

	do {
		if ( dotdir (ffbuf.ff_name) )
			continue ;

		if (fnptr == fnbuf)
			strcpy (fnptr + slasti + 1, ffbuf.ff_name) ;

		if (ffbuf.ff_attrib & FA_DIREC) {
			if (rflag)
				blowdir (fnptr) ;
		} else if (ffbuf.ff_attrib & FA_ARCH)
			( * whop ) ( fnptr , & ffbuf ) ;

	} while (findnext (&ffbuf) >= 0) ;

# else  /* ANYX */

#	ifdef	SYSVDIR

	DIR * dip ;
	DIRENT * dep ;

#	else	/* V7DIR */

	int dfd ;
	struct direct dirbuf ;

#	endif	/* SYSVDIR */

	struct stat   stabuf ;
	char enam	[ 1024 ] ;

#	ifdef	SYSVDIR

	if ((dip = opendir (nam)) == (DIR *) 0) {

#	else	/* V7DIR */

	if ((dfd = open (nam, 0)) < 0) {

#	endif	/* SYSVDIR */

		putmsg (CANTAC, nam, BANAL) ;
		return ;
	}

#	ifdef	SYSVDIR

	while ((dep = readdir (dip)) != (DIRENT *) 0) {

		if ( dotdir (dep->d_name) )
			continue ;

		sprintf (enam, "%s/%s", nam, dep->d_name) ;

#	else	/* V7DIR */

	while (read (dfd, (char *) &dirbuf, sizeof (dirbuf)) > 0) {

		if (dirbuf.d_ino == 0)
			continue ;

		if ( dotdir (dirbuf.d_name) )
			continue ;

		sprintf (enam, "%s/%.14s", nam, dirbuf.d_name) ;

#	endif	/* SYSVDIR */

		if (stat (enam, &stabuf) < 0) {
			putmsg (STATER, enam, BANAL) ;
		} else {
			if ( (stabuf.st_mode & S_IFMT) == S_IFDIR ) {
				if ( rflag )
					blowdir (enam) ;
				else
					continue ;
			} else if ( (stabuf.st_mode & S_IFMT) == S_IFREG ) {
				( * whop ) ( enam , & stabuf ) ;
			} else
				continue ;
		}

	} /* endof while (read dir) */

#	ifdef	SYSVDIR

	closedir (dip) ;

#	else	/* V7DIR */

	close (dfd) ;

#	endif	/* SYSVDIR */

# endif /* TC2 */

} /* endof blowdir() */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void putmsg (msg, arg, why) char * msg , * arg ; int why ; {

	if (why == FATAL || why == BANAL)
		fprintf (stdout, "%s: %s %s\n", swid, msg, arg) ;
	elif (why == CR || why == SPC)
		printf ("%s %s%c", msg, arg, why) ;
	else
		printf ("%s %s\n", msg, arg) ;

	if (why == FATAL)
		epilog (FATAL) ;
}

/************************************************************************
* syntax help ...														*
************************************************************************/

void usag () {

	verban () ;

	fprintf (stdout, "use : xar [-abcdefilnoprtuvx?] xarfile [ filespec ... ]\n\n") ;
	fprintf (stdout, " -a : adicionar \n") ;
	fprintf (stdout, " -b : balancear \n") ;
	fprintf (stdout, " -c : criar diretorios ao extrair \n") ;
	fprintf (stdout, " -d : deletar \n") ;
	fprintf (stdout, " -e : equalizar \n") ;
	fprintf (stdout, " -f : atualizar \n") ;
	fprintf (stdout, " -i : atualizar incondicionalmente \n") ;
	fprintf (stdout, " -l : listar status (detalhado) \n") ;
	fprintf (stdout, " -n : listar nomes \n") ;
	fprintf (stdout, " -o : sobrepor ao extrair \n") ;
	fprintf (stdout, " -p : pesquisar diretorios recursivamente \n") ;
	fprintf (stdout, " -r : filtrar CR ao extrair \n") ;
	fprintf (stdout, " -t : testar integridade \n") ;
	fprintf (stdout, " -u : atualizar e adicionar \n") ;
	fprintf (stdout, " -v : listar status (resumido) \n") ;
	fprintf (stdout, " -x : extrair \n") ;
	fprintf (stdout, " -? : informar a sintaxe \n") ;
	exit (0) ;
}

/************************************************************************
* xar machine ...														*
************************************************************************/

void xar () {

	struct stat stabuf ;
	char resp [20] ;

	sprintf (actxar, NAMFMT, xarpath, XAREXT) ;

	if ((sfp = fopen (actxar, "rb")) == NOFILE)
		if (op != ADDXAR)
			putmsg (CANTAC, actxar, FATAL) ;

	getepoch (sfp) ;

	if (op == ADDXAR || op == DELXAR 
		|| op == XAR_FRESHEN || op == XAR_CHECK) {
		sprintf (newxar, NAMFMT, xarpath, NEWEXT) ;
		if ((tfp = fopen (newxar, "wb")) == NOFILE)
			putmsg (CANCRE, newxar, FATAL) ;
	}

	if (rawfk == 0) {
		if (	op == VUEXAR
			 || op == XTRXAR
			 || op == XAR_FRESHEN 
			 || op == XAR_CHECK
			 || op == XAR_BALANCE ) {
			allflg = TRUE ;
		} elif (chkupd) {
# ifdef   TC2
		*(rawlst + rawfk++) = "*.*" ;
		*(rawlst + rawfk  ) = NOSTR ;
# else    /* ANYX */
		*(rawlst + rawfk++) = "*" ;
		*(rawlst + rawfk  ) = NOSTR ;
# endif   /* TC2 */
			goto bum ;
		} else {
			usag () ;
		}
	} elif (op == ADDXAR) {
bum :
		blowlst () ;
		uselst = foolst ;
	} else {
		pathk = rawfk ;
	}

	if (pathk) {

		if ( ( useflg = (char *) xmalloc ( pathk ) ) == (char *) 0 )
			putmsg (FEWMEM, NOSTR, FATAL) ;

		for ( twin = 0 ; twin < pathk ; useflg [ twin++ ] = USABLE )
			;
	}

	if (sfp == NOFILE) {
		putmsg (CREATN, actxar, OK) ;
		printf ("\n") ;
		goto apndem ;
	} elif (op == ADDXAR || op == DELXAR || op == XAR_FRESHEN)
		putmsg (UPDING, actxar, OK) ;
	elif (op == XAR_CHECK)
		putmsg (CHKING, actxar, OK) ;
	elif (op == XAR_BALANCE)
		putmsg (BALING, actxar, OK) ;
	else if (! nflag)
		putmsg (SRCHIN, actxar, OK) ;

	if (! nflag)
		printf ("\n") ;

	for (EVER) {						/* xar automaton	*/

		if (fgets (hdrlin, MAXHDRLEN, sfp) == NOSTR)
			break ;

		stripeol (hdrlin) ;

		if ((slck = strchop (hdrlin, hdrslc)) != NHDRSLC) {
			putmsg (MADHDR, NOSTR, FATAL) ;
		}

		filcrc = hdrcrc = atol (HDRCRC) ;

		hdrsib = atol (HDRSIZ) ;
		hdrmod = HDRMOD ;
		hdrtib = HDRTIB ;
		nxhofs = hdrsib ;

		if ( allflg || ((twin = belongs (HDRNAM, uselst)) != FAIL) ) {

			if ( ! allflg )
				MARKOK (twin) ;

			switch (op) {

				case XAR_CHECK :
					filcrc = 0L ;
					++pedcnt ;
					goto samfil ;
					/* break ; */

				case XAR_BALANCE :
					if (stat (HDRNAM, &stabuf) != 0) {
						putmsg (CANTAC, HDRNAM, BANAL) ;
						goto nxthdr ;
					}

					strcpy (hdrname, HDRNAM) ;
					putmsg (BALING, strpad (hdrname, 20, '_'), SPC) ;
					filcrc = crcfile (hdrname, 0) ;

					if (filcrc == hdrcrc) {
						printf ("OK  \r") ;
						fflush (stdout) ;
					} else
						printf ("ERRO\n") ;

					++pedcnt ;
					goto nxthdr ;
				/* break ; */

				case XAR_FRESHEN :
				case ADDXAR :

					if ((xfp = fopen (HDRNAM, "rb")) == NOFILE) {
						/* if (chkupd == FALSE) */
						if (op == ADDXAR)
							putmsg (CANTAC, HDRNAM, BANAL) ;
						goto samfil ;
					} else {
						fstat (fileno (xfp), &stabuf) ;
						if (chkupd && ! iflag) {
							if (hdrtib >= (ULONG)stabuf.st_mtime) {
								fclose (xfp) ;
								goto samfil ;
							}
						}
						putmsg (UPDING, HDRNAM, OK) ;
						hdrtib = stabuf.st_mtime ;
# ifdef ANYX
						hdrmod = stabuf.st_mode ;
# else  /* TC2 */
						/* u/d dos attributes on its own hdr-fld */
# endif /* ANYX */
						filsib = stabuf.st_size ;
						strcpy (hdrname, HDRNAM) ;

						hdrstuf () ;
						hdrofs = ftell (tfp) ;
						fputs (hdrlin, tfp) ;
						procrc = TRUE ;
						xarcopy (tfp, xfp, filsib, copyflags | COPYCRC) ;
						cpyofs = ftell (tfp) ;
						fseek (tfp, hdrofs, SEEK_SET) ;
						hdrstuf () ;
						fputs (hdrlin, tfp) ;
						fseek (tfp, cpyofs, SEEK_SET) ;

						++pedcnt ;
						touched = TRUE ;
						goto nxthdr ;
					}

				/* break ; */

				case VUEXAR :

					if ( outhdr++ == 0 ) {
						if (vflag) {
							printf ("  acesso    tamanho     data      hora      crc   nome\n") ;
							printf ("---------- --------- ---------- -------- -------- ----------\n") ;
						} else if (! nflag) {
							printf ("acesso  tamanho   data  hora  nome\n") ;
							printf ("------ --------- ------ ----- ----------\n") ;
						}
					}

					if (vflag)
						printf ("%s %9s %s %08lx %s\n", xsmode (hdrmod), HDRSIZ,
								xsctim (hdrtib), hdrcrc, xarlsc (HDRNAM)) ;
					else if (nflag)
						printf ("%s\n", HDRNAM) ;
					else
						printf ("%s %9s %s %s\n", xsmode (hdrmod), HDRSIZ,
								xsctim (hdrtib), xarlsc (HDRNAM)) ;

					++pedcnt ;
					pedsiz += atol (HDRSIZ) ;
					goto nxthdr ;

				case DELXAR :

					putmsg (DELING, HDRNAM, OK) ;
					++pedcnt ;
					touched = TRUE ;
nxthdr :
					if (xfp)
						fclose (xfp) ;

					fseek (sfp, nxhofs, SEEK_CUR) ;

				break ;

				case XTRXAR :

					if (eflag) {
						if (stat (HDRNAM, &stabuf) != 0)
							goto nxthdr ;
						if (hdrtib <= (ULONG)stabuf.st_mtime)
							goto nxthdr ;
						oflag = 1 ;
					}

					if (! oflag) {
						if (access (HDRNAM, 0) == 0) {
							printf ("* arquivo %s ja' existe. sobrepoe (s/n) ? ", HDRNAM) ;
							if ( fgets (resp, 20, stdin) == NULL )
								goto nxthdr ;
							if (resp[0] == 'N' || resp[0] == 'n')
								goto nxthdr ;
						}
					}

					if (cflag)
						if (makepath (HDRNAM) < 0) {
							putmsg (CANCRE, HDRNAM /* dirnam */, BANAL) ;
							goto nxthdr ;
						}

					if ((xfp = fopen (HDRNAM, "wb")) == NOFILE) {
						putmsg (CANCRE, HDRNAM, BANAL) ;
						goto nxthdr ;
					} else {
						putmsg (EXTING, HDRNAM, OK) ;
						procrc = FALSE ;
						xarcopy (xfp, sfp, hdrsib, copyflags) ;
						++pedcnt ;

						/*_______________________________________________
						 * tc's setftime() touches to time()
						 * if st_size < 512 ... (? & utime() ?) ...
						 */

						fclose (xfp) ;

						if ( touchfile (HDRNAM, hdrtib) < 0 )	/* set file time */
# ifdef TC2
							putmsg (TOCHER, *(uselst+twin), BANAL) ;
# else  /* ANYX */
							putmsg (TOCHER, HDRNAM, BANAL) ;
# endif /* no reason for this distinction ! */

# ifdef ANYX
						if ( chmod (HDRNAM, (mode_t) hdrmod) != 0 )
							putmsg (TOCHER, HDRNAM, BANAL) ;
# else  /* TC2 */
						/* apply dos attributes ... */
# endif /* ANYX */
					}

				break ;
			}
		} else {
			switch (op) {
				case ADDXAR :
				case XAR_FRESHEN :
				case XAR_CHECK :
				case DELXAR :
samfil :
					/*	putmsg (KEPING, HDRNAM, CR) ;	*/
					strcpy (hdrname, HDRNAM) ;
					sprintf (hdrlin, HDRFMT, MAGICS, hdrsib,
							 hdrtib, hdrmod, hdrcrc, hdrname) ;

					if (op == XAR_CHECK && filcrc == 0L) {
						procrc = TRUE ;
						putmsg (CHKING, strpad (hdrname, 20, '_'), SPC) ;
					} else
						procrc = FALSE ;
					fputs (hdrlin, tfp) ;
					xarcopy (tfp, sfp, hdrsib, procrc ? copyflags | COPYCRC : copyflags) ;
					if (op == XAR_CHECK && procrc) {
						if (filcrc == hdrcrc) {
							printf ("OK  \r") ;
							fflush (stdout) ;
						} else
							printf ("ERRO\n") ;
					}

				break ;

				case VUEXAR :
				case XTRXAR :
				case XAR_BALANCE :
					/*	putmsg (SKPING, HDRNAM, CR) ;	*/
					fseek (sfp, nxhofs, SEEK_CUR) ;
				break ;
			}
		} /* endif ... */
	} /* endof 4 ever ... */

apndem :										/* append 'em			*/

	for ( twin = 0 ; twin < pathk ; ++twin ) {
		if ( UNUSED ( twin ) )
			switch (op) {
				case ADDXAR :
					if (badnam (*(uselst+twin)))
						continue ;
					if ((xfp = fopen (*(uselst+twin), "rb")) == NOFILE) {
						putmsg (CANTAP, *(uselst+twin), BANAL) ;
						break ;
					}
					putmsg (ADDING, *(uselst+twin), OK) ;
					fstat (fileno (xfp), &stabuf) ;
					hdrtib = stabuf.st_mtime ;
# ifdef ANYX
					hdrmod = stabuf.st_mode ;
# else  /* TC2 */
					/* u/d dos attributes on its own hdr-fld */
# endif /* ANYX */
					filsib = finlst [twin] -> fi_siz ;
					strcpy ( hdrname, * ( uselst + twin ) ) ;
					hdrstuf () ;
					hdrofs = ftell (tfp) ;
					fputs (hdrlin, tfp) ;
					procrc = TRUE ;
					xarcopy (tfp, xfp, filsib, copyflags | COPYCRC) ;
					cpyofs = ftell (tfp) ;
					fseek (tfp, hdrofs, SEEK_SET) ;
					hdrstuf () ;
					fputs (hdrlin, tfp) ;
					fseek (tfp, cpyofs, SEEK_SET) ;
					touched = TRUE ;
					++pedcnt ;
					fclose (xfp) ;
				break ;

				case DELXAR :
				case VUEXAR :
				case XTRXAR :
/* badboy : */
					putmsg (NFINKN, *(uselst+twin), BANAL) ;
				break ;
			}
	} /* endof for (rest of files to append) */

	if (pedcnt > 0) {
		switch (op) {

			case VUEXAR :
				if (vflag) {
					printf ("           ---------                              ----------\n") ;
					printf ("           %9ld                              %d\n", pedsiz, pedcnt) ;
				} else if (! nflag) {
					printf ("       ---------              ----------\n") ;
					printf ("       %9ld              %d\n", pedsiz, pedcnt) ;
				}
			break ;

			case ADDXAR :
			case DELXAR :
			case XTRXAR :
			case XAR_FRESHEN :
			case XAR_CHECK :
			case XAR_BALANCE :
				printf ("            --------------------\n") ;
				printf ("            %d\n", pedcnt) ;
			break ;
		}
	}
}

/************************************************************************
*	epilogue tasks														*
************************************************************************/

void epilog (int exist) {

	if (exist == FATAL)
		xardok = FALSE ;

	if (sfp)
		fclose (sfp) ;

	if (tfp) {
		if (touched == FALSE) {
			fflush (tfp) ;
			setepoch (tfp) ;
		}
		fclose (tfp) ;
	}

	if (op == ADDXAR || op == DELXAR 
		|| op == XAR_FRESHEN || op == XAR_CHECK) {
		if (xardok) {
			if (sfp) {
				sprintf (oldxar, NAMFMT, xarpath, OLDEXT) ;
				if (renfile (actxar, oldxar) == BAD)
					putmsg (ERENAM, actxar, BANAL) ;
				elif (renfile (newxar, actxar) == BAD)
					putmsg (ERENAM, newxar, BANAL) ;
				elif (unlink (oldxar) == BAD)
					putmsg (DELERR, oldxar, BANAL) ;
			} else {
				if (renfile (newxar, actxar) == BAD)
					putmsg (ERENAM, newxar, BANAL) ;
			}
		} else {
			if (unlink (newxar) == BAD)
				putmsg (DELERR, newxar, BANAL) ;
		}
	}

	exit (exist) ;
}

/************************************************************************
*	feed (expanded) full pathname & status lists ...					*
*																		*
*	ff_fdate = ((year - 1980) * 512) + (mon * 32) + day					*
*	ff_ftime = (hour * 2048) + (min * 32) + (sec/2)						*
************************************************************************/

# ifdef TC2
void savnam (nam, ffp) char * nam ; FFBLK * ffp ; {
# else  /* ANYX */
void savnam (nam, sbp) char * nam ; STABLK * sbp ; {
# endif /* TC2 */
	REG char * tp ;
	REG FILINF * ip ;

# ifdef   COMMENT
	struct date xds ;
	struct time xts ;
# endif   /* COMMENT */

	if ( ( tp = (char *) xmalloc ( strlen (nam) + 1 ) ) == (char *) 0 )
		putmsg (FEWMEM, NOSTR, FATAL) ;

# ifdef TC2
	strcpy ( tp , strlwr ( nam ) ) ;
	strchg ( tp , '\\' , '/' ) ;
# else  /* ANYX */
	strcpy ( tp , nam ) ;
# endif /* TC2 */

	foolst [ pathk ] = tp ;

	if ( ( tp = (char *) xmalloc ( sizeof (FILINF) ) ) == (char *) 0 )
		putmsg (FEWMEM, NOSTR, FATAL) ;

	ip = (FILINF *) tp ;

# ifdef   TC2

# ifdef   COMMENT

	xds.da_year = ((ffp->ff_fdate) >>  9) & 0x7f ;
	xds.da_mon  = ((ffp->ff_fdate) >>  5) & 0x0f ;
	xds.da_day  =  (ffp->ff_fdate)        & 0x1f ;

	xts.ti_hour = ((ffp->ff_ftime) >> 11) & 0x1f ;
	xts.ti_min  = ((ffp->ff_ftime) >>  5) & 0x3f ;
	xts.ti_sec  =  (ffp->ff_ftime)        & 0x1f ;

	ip->fi_tim = dostounix (&xds, &xts) ;

# endif   /* COMMENT */

	ip->fi_siz = ffp->ff_fsize ; /* stap->STASIZ */

# else    /* ANYX */

	ip->fi_tim = sbp->st_mtime ;
	ip->fi_siz = sbp->st_size ;

# endif   /* TC2 */

	* ( finlst + pathk ) = ip ;

	++pathk ;
}

/************************************************************************
*	test if text matches some of a list of patterns ...					*
************************************************************************/

int belongs (txt, patl) char * txt , * * patl ; {
	REG int patk = 0 ;

	while (*patl) {
		if (patmat (txt, *patl))
			return (patk) ;
		++patl ;
		++patk ;
	}
	return (-1) ;
}

/************************************************************************
*	stuff header ...													*
************************************************************************/

void hdrstuf () {

# ifdef TC2
	/* strchg (hdrname, '\\', '/') ; */
# endif /* TC2 */

	sprintf  (	hdrlin, HDRFMT, MAGICS,
				filsib, hdrtib, hdrmod & 0x0000ffffL, filcrc, hdrname) ;
}

/************************************************************************
*	check 4 bad names ...												*
************************************************************************/

int badnam (nam) char * nam ; {

	if ( strstr (nam, ".NUK") )
		return (TRUE) ;

	if ( strstr (nam, ".nuk") )
		return (TRUE) ;

	if ( strcmp (nam, actxar) == 0 )
		return (TRUE) ;

	if ( strstr (nam, actxar) )
		return (TRUE) ;

	return (FALSE) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xsctim (t) ULONG t ; {

	static char tb [20] ;
	struct tm * tp ;

	tp = localtime ( (time_t *) &t ) ;

	if (vflag)
# ifdef PRE2K
		sprintf (tb, "%02d %3s %02d %02d:%02d:%02d",
				 tp->tm_mday, months[tp->tm_mon], tp->tm_year,
				 tp->tm_hour, tp->tm_min, tp->tm_sec) ;
# else /* Y2K */
		sprintf (tb, "%04d/%02d/%02d %02d:%02d:%02d",
				 1900+tp->tm_year, 1+tp->tm_mon, tp->tm_mday,
				 tp->tm_hour, tp->tm_min, tp->tm_sec) ;
# endif
	else
		sprintf (tb, "%02d %3s %02d:%02d",
				 tp->tm_mday, months[tp->tm_mon],
				 tp->tm_hour, tp->tm_min) ;

	return tb ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xsmode (t) ULONG t ; {

	REG	int		j ;
	static		char tb [20] ;
				char type ;
				char *	mp = "rwxrwxrwx" ;

	if (vflag) {

		switch ( (unsigned) t & S_IFMT ) {
			case S_IFREG : type = '-' ; break ;
			case S_IFDIR : type = 'd' ; break ;
			case S_IFCHR : type = 'c' ; break ;
			case S_IFBLK : type = 'b' ; break ;
			case S_IFIFO : type = 'f' ; break ;
			default :      type = '?' ; break ;
		}

		tb [ 0] = type ;

		for ( j = 1 ; j < 10 ; ++j ) {

			if ( t & (0x01 << (j-1)) )
				tb[10-j] = *(mp+(9-j)) ;
			else
				tb[10-j] = '-' ;
		}

		tb [10] = '\0' ;

	} else

		sprintf (tb, "%6lo", t) ;

	return tb ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void getepoch (fp) FILE * fp ; {

	if (fp == NOFILE) {
		kutok = FALSE ; return ;
	}

# ifdef TC2

	getftime (fileno (fp), &xftp) ;

# else  /* ANYX */

	if (fstat (fileno (fp), &xarstat) < 0) {
		putmsg (STATER, actxar, BANAL) ;
		kutok = FALSE ;
	} else {
		xarutim.atime = xarstat.st_atime ;
		xarutim.mtime = xarstat.st_mtime ;
		kutok = TRUE ;
	}

# endif /* TC2 */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void setepoch (fp) FILE * fp ; {

# ifdef TC2

	setftime (fileno (fp), &xftp) ;

# else  /* ANYX */

	if (fp == NULL)
		return ;

	if (kutok) {
		if (utime (newxar, (struct utimbuf *) &xarutim) == -1) {
			putmsg (TOCHER, newxar, BANAL) ;
		}
	}

# endif /* TC2 */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xarlsc (nam) char * nam ; {

	char * tp ;
	char pat [16] ;
	char hue [16] ;
	static char res [1024] ;
	char * pp , * hp , * ep ;

	if ( strcmp (xarlscbuf, "nocolor") == 0 )
		return nam ;

	if ( ( ep = strrchr (nam, '.') ) == NULL ) {
		return nam ;
	}

	strcpy ( xarsetcol , XARDFLCOL ) ;
	strcpy ( xarendcol , XARDFLCOL ) ;

	for ( tp = xarlscbuf ; *tp ; ) {
		for ( pp = pat ; *tp && ( *tp != '=' ) ; *pp++ = *tp++ ) {
			;
		}
		*pp = '\0' ;
		if ( *tp ) {
			++tp ;
		}
		for ( hp = hue ; *tp && ( *tp != ':' ) ; *hp++ = *tp++ ) {
			;
		}
		*hp = '\0' ;
		if ( *tp ) {
			++tp ;
		}
		if ( pat[0] == '*' ) {
			/* if ( strstr (nam, &pat[1]) ) { */
			if ( strcmp (ep, &pat[1]) == 0 ) {
				sprintf (xarsetcol, "\033[%sm", hue) ;
				break ;
			}
		}
	}

	sprintf (res, "%s%s%s", xarsetcol, nam, xarendcol) ;

	return res ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xarcopy (tofp, fromfp, size, flags) FILE * tofp, * fromfp ; ULONG size ; int flags ; {

	register int rd ;
	extern ULONG copycrc ;

	rd = fcopy (tofp, fromfp, size, flags) ;

	switch (rd) {
		case -1 : putmsg (FEWMEM, NOSTR, FATAL) ; break ;
		case -2 : putmsg (NOREAD, NOSTR, FATAL) ; break ;
		case -3 : putmsg (NOWRIT, "(binaria)", FATAL) ; break ;
		case -4 : putmsg (NOWRIT, "(convertida)", FATAL) ; break ;
	}

	if (procrc)
		filcrc = copycrc ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef FORCECOLOR

char * LS_COLORS="no=00:fi=00:di=01;34:ln=01;36:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arj=01;31:*.taz=01;31:*.lzh=01;31:*.zip=01;31:*.z=01;31:*.Z=01;31:*.gz=01;31:*.bz2=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.jpg=01;35:*.jpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.mpg=01;35:*.mpeg=01;35:*.avi=01;35:*.fli=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.ogg=01;35:*.mp3=01;35:*.wav=01;35:*.bat=01;32:*.cmd=01;32:*.h=00;35:*.txt=00;36:*.xar=00;31:*.xgz=00;31:*.xbz=00;31:*.cfg=36;44:*.cpp=00;32:*.java=01;33:*.hpp=33;44:*.lst=30;46:*.conf=36;44:*.schema=34;46:*.exe=01;32:*.bsh=01;32:*.sh=01;32:*.awk=37;42:*.pl=37;42:*.tbz=01;31:*.c=00;33:*.htm=34;43:*.html=30;43:*.xml=34;42:*.JPG=01;35:*.ico=01;35:*.ksh=01;32:*.csh=01;32:*.bash=01;32:*.csv=30;42:*.dat=01;36:*.log=01;36:*.cnf=36;44:*.o=30;41:*.tmp=30;41:*.s=01;33:*.l=30;46:*.asm=01;33" ;

# endif

void prologue () {

	char * tp ;

	if (nflag)
		return ;

	verban () ;

	crcsetflag (CRC_IGNORECR) ;

	if ( ( tp = getenv ("LS_COLORS") ) == NULL ) {
		tp = "nocolor" ;
	}

	strcpy (xarlscbuf, tp) ;
}

/*		 ___________________________________________________________
 *		|															|
 *		|  release    version   history								|
 *		|___________________________________________________________|
 *		|															|
 *		| 00 dec 15   1.6 653	-e(qualize)							|
 *		|															|
 *		| 97 jul 02   1.6 612   port to abx(lib)					|
 *		|															|
 *		| 96 may 20   1.5 538   crc-32 support						|
 *		|___________________________________________________________|
 *		|															|
 *		|	+ dos attribute (get, store, view, set on extr.)		|
 *		|	+ anyx owner & group (get, store, view, set on extr.)	|
 *		|	+ compression (flag, hdr, view, method)					|
 *		|	+ dynamically rename existing extracted names			|
 *		|	+ map weird names locally (ex.: "a.out.h" on dos)		|
 *		|	+ sorted listings, password encryption (-s)				|
 *		|	+ filespec exclusion (ex.: -e "*.exe")					|
 *		|___________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
