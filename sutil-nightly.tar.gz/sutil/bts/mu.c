
/*
 *	mu	0.0.19	2015-01-30	bud
 */

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <dirent.h>

# include <sys/types.h>
# include <sys/stat.h>

# define	PATHSIZE	8192

int				allflag		= 0 ;
int				errorflag	= 0 ;
int				fallflag	= 1 ;
int				helpflag	= 0 ;
int				treeflag	= 0 ;

int				grd			= 0 ;
int				lastone		= 0 ;

int64_t			muk			= 0 ;

/*________________________________________________________________________
*/

void showname (name, deep) char * name ; int deep ; {

# define	VSIZ	5 /* 4 ? */
# define	VLEN	3

	static		char			vlast [VSIZ] = "\\--" ;
	static		char			veach [VSIZ] = "+--" ;
	static		char			vstik [VSIZ] = "|  " ;
	static		char			vspac [VSIZ] = "   " ;
	static		char			vbuf  [4096] = { '\0' } ;
				char *			vpref ;

	*(vbuf+(deep*VLEN)) = '\0' ;

	if (*vbuf)
		printf ("%s", vbuf) ;

	if ( lastone ) {
		strcat (vbuf, vspac) ;
		vpref = vlast ;
	} else {
		strcat (vbuf, vstik) ;
		vpref = veach ;
	}

	if (deep)
		printf ("%s", vpref) ;
	else
		printf ("%s", vspac) ;

	printf ("%s\n", name) ;
}

/*________________________________________________________________________
*/

off_t mu (stem, leaf) char * stem , * leaf ; {

	static		int				depth		= 0 ;
	register	int				rd			;
				off_t			itemsize	;
				off_t			stemsize	= 0 ;
				long			dloc		;
				struct stat		stabuf		;
				struct dirent *	dep			;
				DIR *			dip			;
				char *			np			;
				char			pathbuff [ PATHSIZE ] ;

	if ( stem == NULL ) {
		strcpy ( pathbuff , leaf ) ;
	} else {
		sprintf ( pathbuff , "%s/%s" , stem , leaf ) ;
	} ++muk ;

	if ( ( rd = lstat ( pathbuff , &stabuf ) ) != 0 ) {
		fprintf ( stderr , "* stat(%s)=<%d>\n" , pathbuff , rd ) ;
		return -1 ;
	}

	itemsize = (long long) stabuf.st_size ;

	switch ( stabuf.st_mode & S_IFMT ) {

		case S_IFDIR :

			if ( fallflag ) {
				printf ( "%c %15lld %4d " , 'd' , itemsize , depth ) ;
# ifdef ORIG
				for ( rd = 0 ; rd < depth ; ++rd ) {
					printf ("   ") ;
				}
				printf ( "%s\n" , leaf ) ;
# else
				showname ( leaf , depth ) ;
# endif
			}

			if ( ( dip = opendir ( pathbuff ) ) == NULL ) {
				fprintf ( stderr , "* opendir(%s)=<fail>\n" , pathbuff ) ;
			} else {
				stemsize = itemsize ;
				while ( ( dep = readdir (dip) ) != NULL ) {
					np = dep->d_name ;
					if ( *np == '.' ) {
						if ( *(np+1) == '\0' ) {
							continue ;
						} else if ( *(np+1) == '.' && *(np+2) == '\0' ) {
							continue ;
						}
					}
					dloc = telldir ( dip ) ;
					if ( readdir ( dip ) == NULL ) {
						lastone = 1 ;
					} else {
						lastone = 0 ;
					}
					seekdir ( dip , dloc ) ;
					++depth ;
					if ( ( itemsize = mu ( pathbuff , np ) ) > 0 ) {
						stemsize += itemsize ;
					}
					--depth ;
				}
				closedir (dip) ;
			}

			if ( treeflag ) {
				printf ( "%c %15lld %4d " , 'd' , stemsize , depth ) ;
				for ( rd = 0 ; rd < depth ; ++rd ) {
					printf ("   ") ;
				}
# ifdef ORIG
				printf ( "%s\n" , leaf ) ;
# else
				showname ( leaf , depth ) ;
# endif
			}

		break ;

		case S_IFREG :

			if ( fallflag ) {
				if ( allflag ) {
					printf ( "%c %15lld %4d " , '-' , itemsize , depth ) ;
					for ( rd = 0 ; rd < depth ; ++rd ) {
						printf ("   ") ;
					}
					printf ( "%s\n" , leaf ) ;
				}
			}

			stemsize = itemsize ;

			if ( fallflag ) {
				if ( allflag ) {
					printf ( "%c %15lld %4d " , '-' , stemsize , depth ) ;
					for ( rd = 0 ; rd < depth ; ++rd ) {
						printf ("   ") ;
					}
					printf ( "%s\n" , leaf ) ;
				}
			}

		break ;
	}

	return stemsize ;
}

void usage () {
	fprintf ( stderr , "* use : mu [options]\n" ) ;
	exit ( errorflag ) ;
}

int main (argc, argv) int argc ; char * argv [ ] ; {

	if ( --argc ) {
		while ( *++argv ) {
			if ( **argv == '-' ) {
				if ( 0 == strcmp ( *argv , "-?" ) ) {
					++helpflag ;
				} else if ( 0 == strcmp ( *argv , "-a" ) ) {
					++allflag ;
				} else if ( 0 == strcmp ( *argv , "-F" ) ) {
					++fallflag ; treeflag = 0 ;
				} else if ( 0 == strcmp ( *argv , "-h" ) ) {
					++helpflag ;
				} else if ( 0 == strcmp ( *argv , "-T" ) ) {
					++treeflag ; fallflag = 0 ;
				} else {
					++errorflag ;
				}
			} else {
				mu ( NULL , *argv ) ;
			}
		}
		if ( helpflag || errorflag ) {
			usage () ;
		}
		if ( muk == 0 ) {
			mu ( NULL , "." ) ;
		}
	} else {
		mu ( NULL , "." ) ;
	}

	return grd ;
} 

/*
 * vi:nu ts=4
 */
