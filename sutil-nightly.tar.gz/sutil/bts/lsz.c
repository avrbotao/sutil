
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	lsz							  line size stats	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1998-2006			alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"lsz"
# define	VERSION			"1.2"
# define	VERCODE			"251"
# define	VERDATE			"2006.03.30"
# define	VERSIGN			"Alexandre Botao"

/*		 _______________________________________________________________
 *		|																|
 *		|	includes & operational definitions ...						|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_SYSTYPES

# define	USE_STDASC
# define	USE_STDAPP
# define	USE_STDPARM
# define	USE_STDLOGIC

# define	USE_STDTYP
# define	USE_STDDIR
# define	USE_STDMISC
# define	USE_STDSTAT

# include	"abc.h"

/*________________________________________________________________________
*/
#ifdef OpenBSD
#	define	strcat(D,S)		strlcat(D,S,sizeof(D))
#	define	strcpy(D,S)		strlcpy(D,S,sizeof(D))
# endif
/*________________________________________________________________________
*/

/*		 _______________________________________________________________
 *		|																|
 *		|	application-specific definitions & data prototypes ...		|
 *		|_______________________________________________________________|
 */

# define	SERNUMB			12345

/*		 _______________________________________________________________
 *		|																|
 *		|	global variables ...										|
 *		|_______________________________________________________________|
 */

int			progressflag = FALSE ;
int			recurseflag = FALSE ;
int			stdinflag = FALSE ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include "stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-rELPV?] [filespec ...] \n",
	"\n",

	"  -P : progresso percentual \n",
	"  -r : pesquisa recursiva \n",

# include "stdflag.h"

	NULL

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

PARMINFO	parminfo [] = {

	{ 'P',	&progressflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'r',	&recurseflag,	NULL,		PI_SETVAL,		TRUE			} ,

# include "deflbits.h"

} ;

/*		 _______________________________________________________________
 *		|																|
 *		|	function prototypes ...										|
 *		|_______________________________________________________________|
 */

int			procany			OF ( (char *)							) ;
int			procdir			OF ( (char *)							) ;
int			procfile		OF ( (char *)							) ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	main, prologue, epilogue, parms	...							|
 *		|_______________________________________________________________|
 */

int main (argc, argv) int argc ; char * * argv ; {

	setargent (argc, argv) ;

	parseargs () ;

	prologue () ;

	drudgery () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	parsebits () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	endargent () ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	stdinflag = TRUE ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	the application itself ...									|
 *		|_______________________________________________________________|
 */

void drudgery () {

	register char * nxtarg ;

	if ( stdinflag && progressflag ) {
			fprintf (stderr, "lsz: '--' e '-P' sao mutuamente exclusivas \n") ;
			return ;
	}

	if (stdinflag)
		procfile (NULL) ;
	else
		while ( ( nxtarg = getargent () ) != NULL )
			procany ( nxtarg ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procany (name) char * name ; {

	int		tof ;

	if ( ( tof = filetype (name) ) == T_NONE )
		return xalert (XA_BANAL, "acessar", name, 0) ;

	if ( tof == T_DIR && recurseflag )
		return procdir (name) ;
	else
		return procfile (name) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procdir (name) char * name ; {

	register char * np ;
	register DIRDES * ddp ;
	char nb [256] ;

	if ( ( ddp = setdirent (name) ) == NULL )
		return xalert (XA_BANAL, "acessar diretorio", name, 0) ;

	while ( ( np = getdirent (ddp) ) != NULL ) {
		sprintf (nb, "%s%c%s", name, DIRSEP, np) ;
		procany (nb) ;
	}

	return enddirent (ddp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procfile (name) char * name ; {

	register long	maxlen = -1L , minlen = 9999999L , avglen = 0L ,
					linlen = 0L , lincnt = 0L , totlen = 0L ;
	FILE * fp = stdin ;
	int xb = 0 , last = 0 ;
	static int first = TRUE ;
	long fsz = 0L ;
	STABUF * fst ;

	if (stdinflag)
		name = "stdin" ;
	else
		if ( (fp = fopen (name, "rb")) == NULL ) {
			fprintf (stderr, "lsz: erro ao abrir %s\n", name) ;
			return -1 ;
		}

	if (progressflag) {
		fst = statof (name) ;
		fsz = bytesof (fst) ;
		ptrel (0L, fsz, 0L) ;
	}

	if (first) {
		printf (" tamanho  linhas  menor  media  maior  arquivo \n") ;
		printf ("--------- ------- ------ ------ ------ ---------------\n") ;
		first = FALSE ;
	}

	while ( (xb = getc (fp)) != EOF ) {

		++linlen ;
		last = xb ;

		if (xb == NL) {

			if (linlen > maxlen)
				maxlen = linlen ;

			if (linlen < minlen)
				minlen = linlen ;

			++lincnt ;
			totlen += linlen ;
			linlen = 0L ;
		}

		if (progressflag) {
			ptrel (totlen, fsz, 0L) ;
		}
	}

	if (last != NL) {
		if (linlen > maxlen)
			maxlen = linlen ;

		if (linlen < minlen)
			minlen = linlen ;

		++lincnt ;
		totlen += linlen ;
	}

	avglen = totlen / lincnt ;

	printf ("%9ld %7ld ", totlen, lincnt) ;
	printf ("%6ld %6ld %6ld ", minlen, avglen, maxlen) ;
	printf ("%s\n", name) ;

	if (fp != stdin)
		fclose (fp) ;

	return 0 ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history...............................	|
 *		|			 		   											|
 *		|  00 03 22   1.2 248   release									|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

/*
 * vi:tabstop=4
 */
