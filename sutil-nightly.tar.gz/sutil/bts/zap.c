
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	zap									  a wiper	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1997				alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"zap"
# define	VERSION			"2.3"
# define	VERCODE			"348"
# define	VERDATE			"2000.06.14"
# define	VERSIGN			"Alexandre Botao"

/*		 _______________________________________________________________
 *		|																|
 *		|	includes & operational definitions ...						|
 *		|_______________________________________________________________|
 */

# ifdef DOS
#	include <io.h>
# endif

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_UNISTD

# define	USE_SYSTYPES

# define	USE_STDASC
# define	USE_STDAPP
# define	USE_STDPARM
# define	USE_STDLOGIC

# define	USE_STDDIR
# define	USE_STDTYP
# define	USE_STDMISC
# define	USE_STDSTAT
# define	USE_STDFILE

# include	"abc.h"

/*________________________________________________________________________
*/
#ifdef OpenBSD
#	define	strcat(D,S)		strlcat(D,S,sizeof(D))
#	define	strcpy(D,S)		strlcpy(D,S,sizeof(D))
# endif
/*________________________________________________________________________
*/

/*		 _______________________________________________________________
 *		|																|
 *		|	application-specific definitions & data prototypes ...		|
 *		|_______________________________________________________________|
 */

# define	DFL_WIPESIZE		  4096
# define	DFL_WIPEVALUE		  0xab

/*		 _______________________________________________________________
 *		|																|
 *		|	global variables ...										|
 *		|_______________________________________________________________|
 */

int			wipesize = DFL_WIPESIZE ;
int			wipevalue = DFL_WIPEVALUE ;

int			confirmflag = TRUE ;
int			forceflag = FALSE ;
int			fakeflag = FALSE ;
int			litflag = FALSE ;
int			recurseflag = FALSE ;
int			verboseflag = TRUE ;
int			wipeflag = FALSE ;

char *		wbuf ;

char		litname [256] ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include	"stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-e nome] [-ifnqrvwELV?] [pathname ...] \n",
	"\n",

	"  -e : deleta arquivo com nome \"especial\" \n",
	"  -i : confirma antes de deletar \n",
	"  -f : deleta arquivos \"protegidos\" \n",
	"  -n : apenas lista arquivos SEM deletar \n",
	"  -q : trabalha silenciosamente \n",
	"  -r : deleta diretorios recursivamente \n",
	"  -v : mostra acompanhamento (default) \n",
	"  -w : anula o conteudo antes de deletar \n",

# include "stdflag.h"

	NULL

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

PARMINFO	parminfo [] = {

	{ 'e',	&litflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'e',	NULL,			litname,	PI_SETBUF,		0				} ,
	{ 'i',	&confirmflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'f',	&forceflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'n',	&fakeflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'q',	&verboseflag,	NULL,		PI_SETVAL,		FALSE			} ,
	{ 'r',	&recurseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'v',	&verboseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'w',	&wipeflag,		NULL,		PI_SETVAL,		TRUE			} ,

# include "deflbits.h"

} ;

/*		 _______________________________________________________________
 *		|																|
 *		|	function prototypes ...										|
 *		|_______________________________________________________________|
 */

int			zapany		OF ( (char *)									) ;
int			zapdir		OF ( (char *)									) ;
int			zapfile		OF ( (char *)									) ;

int			confirm		OF ( (char *)									) ;
int			force		OF ( (char *)									) ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	main, prologue, epilogue, parms	...							|
 *		|_______________________________________________________________|
 */

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	setargent (argc, argv) ;

	parseargs () ;

	prologue () ;

	drudgery () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	parsebits () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	endargent () ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	if ( ! litflag )
		SETBIT (flagbits, PI_SYNTAXBIT) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	the application itself ...									|
 *		|_______________________________________________________________|
 */

void drudgery () {

	register char * nxtarg ;

	if (litflag)
		zapany (litname) ;

	while ( ( nxtarg = getargent () ) != NULL )
		zapany ( nxtarg ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int zapany (name) char * name ; {

	int		tof ;

	if ( ( tof = filetype (name) ) == T_NONE )
		return xalert (XA_BANAL, "acessar", name, 0) ;

	if ( tof == T_DIR && recurseflag )
		return zapdir (name) ;
	else
		return zapfile (name) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int zapdir (name) char * name ; {

	register char * np ;
	register DIRDES * ddp ;
	char nb [256] ;

	if ( dotdir ( name ) )
		return 0 ;

	if ( ( ddp = setdirent (name) ) == NULL )
		return xalert (XA_BANAL, "acessar diretorio", name, 0) ;

	while ( ( np = getdirent (ddp) ) != NULL ) {
		sprintf (nb, "%s%c%s", name, DIRSEP, np) ;
		zapany (nb) ;
	}

	enddirent (ddp) ;

	if (fakeflag) {
		printf ("+ preservando %s \n", name) ;
		return 0 ;
	}

	if (confirmflag)
		if ( ! confirm (name) )
			return 0 ;

	if (verboseflag) {
		printf ("+ deletando %s \r", name) ;
		fflush (stdout) ;
	}

	sprintf (nb, "rmdir %s", name) ;

	if ( system (nb) != 0 )
		return xalert (XA_BANAL, "deletar", name, 0) ;

	if (verboseflag)
		printf ("\n") ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int zapfile (name) char * name ; {

	register int rd ;

	if (fakeflag) {
		printf ("+ preservando %s \n", name) ;
		return 0 ;
	}

	if (confirmflag)
		if ( ! confirm (name) )
			return 0 ;

	if (forceflag)
		if (force (name) == -1)
			return xalert (XA_BANAL, "desproteger", name, 0) ;

	if (wipeflag) {
		if (verboseflag) {
			printf ("+ limpando! %s \r", name) ;
			fflush (stdout) ;
		}
		if ( ( rd = wipefile (name, wipesize, wipevalue) ) != 0 )
			return rd ;
	}

	if (verboseflag) {
		printf ("+ deletando %s \r", name) ;
		fflush (stdout) ;
	}

	if (unlink (name) < 0)
		return xalert (XA_BANAL, "deletar", name, 0) ;

	if (verboseflag)
		printf ("\n") ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int confirm (name) char * name ; {

	int what ;
	char resp [20] ;

	printf ("deletar %s ? ", name) ;

	if ( fgets (resp, 20, stdin) == NULL )
		return FALSE ;

	switch (resp[0]) {
		case 'S' :
		case 's' :
		case 'Y' :
		case 'y' : what = TRUE ; break ;

		case 'N' :
		case 'n' :

		default  : what = FALSE ; break ;
	}

	return what ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int force (nam) char * nam ; {

# ifdef DOS

	int attr ;

	attr = _chmod (nam, 0) ;
	attr &= ~ ( FA_RDONLY | FA_SYSTEM | FA_HIDDEN ) ;
	attr = _chmod (nam, 1, attr) ;
	return attr ;

# else  /* ANYX */

	return nam == NULL ? -1 : 0 ;

# endif /* DOS */

}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history...............................	|
 *		|			 		   											|
 *		|  97 06 24   2.3 314   zap ! ported 2 abx ...					|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + force (-f) flag on ANYX									|
 *		|  + user-given (-x) wipevalue & (-b #) wipebuffsize ...		|
 *		|  + exclusion list ( -e "filespec ..." ) using match()			|
 *		|  + must warn against WIPE if NLINKS > 1 (unless -f)			|
 *		|_______________________________________________________________|
 */

/*
 * vi:tabstop=4
 */
