
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	bal							  balance objects	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1997-2019			alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"bal"
# define	VERSION			"1.4"
# define	VERCODE			"418"
# define	VERDATE			"2021.03.09"
# define	VERSIGN			"Alexandre Botao"

/*		 _______________________________________________________________
 *		|																|
 *		|	includes & operational definitions ...						|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO
# define	USE_STDLIB

# define	USE_SYSTYPES

# define	USE_STDASC
# define	USE_STDAPP
# define	USE_STDPARM
# define	USE_STDPATH
# define	USE_STDLOGIC
# define	USE_STDMATCH

# define	USE_STDSTR
# define	USE_STDTYP
# define	USE_STDDIR
# define	USE_STDMISC
# define	USE_STDMEM
# define	USE_STDSTAT
# define	USE_STDTIME

# define	USE_UNISTD

# define	USE_ABX

/*
#ifdef HOUX
# include "abcs.h"
# include "bud.h"
#endif
*/

# include	"abc.h"

/*________________________________________________________________________
*/

/*		 _______________________________________________________________
 *		|																|
 *		|	application-specific definitions & data prototypes ...		|
 *		|_______________________________________________________________|
 */

# define	BUFFSIZE		1048576	/* 4194304 */
# define	FASTSIZE		   4096
# define	NAMESIZE		   4096

# define	MAXCHOWNERR		      3
# define	MAXCHMODERR		      3
# define	MAXTOUCHERR		      3

# define	BALSCRIPT		"balupdt.sh"

/*		 _______________________________________________________________
 *		|																|
 *		|	global variables ...										|
 *		|_______________________________________________________________|
 */

# ifdef DOS

unsigned	_stklen  = 16384 /* 8192 */ ;

# endif /* DOS */

int			anytypeflag = FALSE ;
int			fastcompflag = FALSE ;
int			fas2compflag = FALSE ;
int			fas3compflag = FALSE ;
int			mockrunflag = FALSE ;
int			newonlyflag = FALSE ;
int			recurseflag = FALSE ;
int			refreshflag = FALSE ;
int			scriptflag = FALSE ;
int			twowayflag = FALSE ;
int			updateflag = FALSE ;
int			updatedest = FALSE ;
int			updateorig = FALSE ;
int			verboseflag = FALSE ;
int			totsizeflag = FALSE ;
int			fixtimeflag = FALSE ;
int			fixfatflag = FALSE ;	/* undocumented */
int			progressflag = FALSE ;	/* undocumented */
int			diffflag = FALSE ;
int			humanflag = FALSE ;
int			dotkflag = FALSE ;
int			moveflag = FALSE ;
int			lslflag = FALSE ;
int			matchflag = FALSE ;

int			chownerrorcount = 0 ;
int			chmoderrorcount = 0 ;
int			toucherrorcount = 0 ;

int		altbufsiz = 0 ;
int		numops = 0 ;
int		maxops = 0 ;

char	patbuf [128] ;
char	lsopts [128] ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include "stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-b size] [-defosuvELNV?] arq1 arq2 \n\n",
	"  ou : ", VERNAME, " [-b size] [-deforsuvELNV?] dir1 dir2 \n\n",
	"  ou : ", VERNAME, " [-b size] [-defosuvELNV?] arq1 ... arqN dir \n\n",

	"  -b size : tamanho do buffer \n",
	"  -d      : atualiza destino \n",
	"  -e      : compara data de gravacao \n",
	"  -f      : compara rapidamente o inicio dos arquivos \n",
	"  -2      : compara rapidamente o inicio e o fim dos arquivos \n",
	"  -F      : compara rapidamente o inicio, o meio e o fim dos arquivos \n",
	"  -h      : formato numerico 'humano' \n",
	"  -k      : mostra '.' (ponto) de milhar numeral \n",
	"  -l      : roda um 'ls -l' nos arquivos diferentes \n",
	"  -L opts : flags adicionais do 'ls' \n",
	"  -m      : move ao inves de copiar \n",
	"  -M rexp : filtra pela expressão regular <rexp> \n",
	"  -n      : atualiza apenas arquivos novos \n",
	"  -N      : informa sem atualizar \n",
	"  -o      : atualiza origem \n",
	"  -P      : mostra acompanhamento de progresso \n",
	"  -r      : pesquisa diretorios recursivamente \n",
	"  -s      : gera um shell script para atualizar \n",
	"  -T      : atualiza timestamps \n",
	"  -u      : atualiza o mais velho \n",
	"  -v      : mostra inclusive os arquivos iguais \n",
	"  -x nops : faz no maximo <nops> operacoes \n",
	"  -y      : roda um 'diff' nos arquivos diferentes \n",
	"  -z      : informa total de bytes transferidos \n",

# include "stdflag.h"

	NULL
} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

PARMINFO	parminfo [] = {

	{ 'b',	&altbufsiz,		NULL,		PI_SETNUM,		0				} ,
	{ 'd',	&updatedest,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'e',	&refreshflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'f',	&fastcompflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ '2',	&fas2compflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'F',	&fas3compflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'h',	&humanflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'k',	&dotkflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'l',	&lslflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'L',	NULL,			lsopts,		PI_SETBUF,		0				} ,
	{ 'm',	&moveflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'M',	&matchflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'M',	NULL,			patbuf,		PI_SETBUF,		0				} ,
	{ 'n',	&newonlyflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'N',	&mockrunflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'o',	&updateorig,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'P',	&progressflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'r',	&recurseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 's',	&scriptflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'T',	&fixtimeflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'u',	&updateflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'v',	&verboseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'x',	&maxops,		NULL,		PI_SETNUM,		0				} ,
	{ 'y',	&diffflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'z',	&totsizeflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ '%',	&fixfatflag,	NULL,		PI_SETVAL,		TRUE			} ,

# include "deflbits.h"

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *	curarg ;

char *	cmdsbuff ;
char *	destpath ;
char *	origbuff ;
char *	destbuff ;

int		origlen ;

int		buffsize = BUFFSIZE ;
int		fastsize = FASTSIZE ;
int		namesize = NAMESIZE ;

int		srd ;

sbit64	totsizes = 0 ;
sbit64	newsizes = 0 ;
sbit64	updsizes = 0 ;

sbit64	totfiles = 0 ;
sbit64	newfiles = 0 ;
sbit64	updfiles = 0 ;

FILE *	bsfp = NULL ;

mode_t	orig_mod ;

uid_t	orig_uid ;
gid_t	orig_gid ;

time_t	orig_atime ;
time_t	orig_mtime ;

struct utimbuf	orig_utim ;

/*		 _______________________________________________________________
 *		|																|
 *		|	function prototypes ...										|
 *		|_______________________________________________________________|
 */

void	baldir		OF ( ( char * , char * )			) ;
void	baleqv		OF ( ( char * , char * )			) ;
void	balfil		OF ( ( char * , char * )			) ;
int		balcmp		OF ( ( char * , char * )			) ;
int		balcop		OF ( ( char * , char * )			) ;
int		balown		OF ( ( char * )						) ;
int		baltim		OF ( ( char * )						) ;

void	chkhlp		OF ( ( void )						) ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	main, prologue, epilogue, parms	...							|
 *		|_______________________________________________________________|
 */

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	setargent (argc, argv) ;

	parseargs () ;

	prologue () ;

	drudgery () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	parsebits () ;

	sortargsflag = FALSE ;

	if ( altbufsiz > 0 )
		buffsize = altbufsiz ;

	if ( ( origbuff = (char *) xmalloc (buffsize) ) == NULL ) {
		fprintf (stderr, "bal: no memory for buffer 1 \n") ;
		exit (2) ;
	}

	if ( ( destbuff = (char *) xmalloc (buffsize) ) == NULL ) {
		fprintf (stderr, "bal: no memory for buffer 2 \n") ;
		exit (2) ;
	}

	if ( ( destpath = (char *) xmalloc (namesize) ) == NULL ) {
		fprintf (stderr, "bal: no memory for buffer 3 \n") ;
		exit (2) ;
	}

	if ( ( cmdsbuff = (char *) xmalloc (namesize<<1) ) == NULL ) {
		fprintf (stderr, "bal: no memory for buffer 4 \n") ;
		exit (2) ;
	}

	strcpy ( lsopts , "-rt" ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	endargent () ;

	if ( totsizeflag ) {
		if ( totsizes || newsizes || updsizes ) {
			fprintf ( stdout, "\n%-20s: ", curarg) ;
			if ( dotkflag ) {
				fprintf ( stdout, "total %15s bytes ", xlltoa ( (long long)totsizes, 20, 0x09 ) ) ;
					fprintf ( stdout, "on %s files = ", xlltoa ( (long long)totfiles, 20, 0x09 ) ) ;
				fprintf ( stdout, "new %s bytes ", xlltoa ( (long long)newsizes, 20, 0x09 ) ) ;
					fprintf ( stdout, "on %s files + ", xlltoa ( (long long)newfiles, 20, 0x09 ) ) ;
				fprintf ( stdout, "updated %s bytes ", xlltoa ( (long long)updsizes, 20, 0x09 ) ) ;
					fprintf ( stdout, "on %s files.", xlltoa ( (long long)updfiles, 20, 0x09 ) ) ;
			} else if ( humanflag ) {
				fprintf ( stdout, "total %15s bytes ", lltokmgtpe ( (long long)totsizes ) ) ;
					fprintf ( stdout, "on %s files = ", lltokmgtpe ( (long long)totfiles ) ) ;
				fprintf ( stdout, "new %s bytes  ", lltokmgtpe ( (long long)newsizes ) ) ;
					fprintf ( stdout, "on %s files + ", lltokmgtpe ( (long long)newfiles ) ) ;
				fprintf ( stdout, "updated %s bytes ", lltokmgtpe ( (long long)updsizes ) ) ;
					fprintf ( stdout, "on %s files.", lltokmgtpe ( (long long)updfiles ) ) ;
			} else {
				fprintf ( stdout, "total %15lld bytes on %lld files = new %lld bytes on %lld files + updated %lld bytes on %lld files.",
									(long long)totsizes, (long long)totfiles,
										(long long)newsizes, (long long)newfiles,
											(long long)updsizes, (long long)updfiles
				) ;
			}
			fprintf ( stdout, "\n") ;
		} else {
			fprintf ( stdout, "\n%s: nothing changed \n", curarg) ;
		}
	}

	if ( scriptflag && ( bsfp != NULL ) )
		fclose ( bsfp ) ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	SETBIT (flagbits, PI_SYNTAXBIT) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void chkhlp () {

	if ( ! ( flagbits & PI_SYNTAXBIT ) )
		cmdsyn () ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	the application itself ...									|
 *		|_______________________________________________________________|
 */

void drudgery () {

	register char * origin , * target ;
	register int typ1, typ2 , j ;

	if (totparms < 2) {
		fprintf (stderr, "bal: too few parameters \n") ;
		chkhlp () ;
		return ;
	}

	if ( mockrunflag && scriptflag ) {
		fprintf (stderr, "bal: -N and -s are mutually exclusive \n") ;
		chkhlp () ;
		return ;
	}

	if ( updatedest && updateorig ) {
mxer:
		fprintf (stderr, "bal: -d , -o and -u are mutually exclusive \n") ;
		chkhlp () ;
		return ;
	}

	if ( updatedest && updateflag )
		goto mxer ;

	if ( updateorig && updateflag )
		goto mxer ;

	if ( scriptflag ) {
		if ( ( bsfp = fopen (BALSCRIPT, "wb") ) == NULL ) {
			fprintf (stderr, "bal: can't create script file \n") ;
			return ;
		}
	}

	if (totparms == 2) {

		/* file-pair, dir-pair, or file-to-dir balance */

		origin = getargent () ;
		target = getargent () ;
		typ1   = filetype (origin) ;
		typ2   = filetype (target) ;

		if ( typ1 == 'd' && typ2 == 'd' ) {			/* dir pair */

			if (recurseflag)
				origlen = strlen (origin) ;

			curarg = origin ;

			if ( matchflag ) {
				printf ("match=\"%s\" ", patbuf) ;
			}

			/* scan origfil, destfil for double quotes and escape them all */
			printf ("origin=\"%s\" target=\"%s\"\n\n", origin, target) ;

			baldir (origin, target) ;

		} else if ( typ1 == 'f' && typ2 == 'f' ) {	/* file pair */

			balfil (origin, target) ;

		} else if ( typ1 == 'f' && typ2 == 'd' ) {	/* file to dir */

			baleqv (origin, target) ;

		} else {

			fprintf (stderr, "bal: incompatible file types (%c,%c)\n", typ1, typ2) ;
			chkhlp () ;
			return ;
		}

	} else {

		/* many-files-to-dir balance */

		j = totparms - 1 ;
		target = getargpos (j) ;
		typ2   = filetype (target) ;

		if ( typ2 != 'd' ) {
			fprintf (stderr, "bal: last name is not a dir \n") ;
			chkhlp () ;
			return ;
		}

		while (j--) {
			origin = getargent () ;
			typ1   = filetype (origin) ;

			if ( typ1 == 'f' )
				baleqv (origin, target) ;
			else
				printf ( "bal: can't access file %s\n", origin ) ;
		}
	}
}

int flipstate = '\0' ;

void flipline (what) char what ; {
	if ( what == 'y' ) {
		flipstate = what ;
/*
		printf ("skipped\n") ;
*/
	} else {
		if ( what == 'n' ) {
			if ( flipstate == 'y' ) {
				flipstate = what ;
				printf ("\n") ;
/*
			} else {
				printf ("passed\n") ;
*/
			}
		}
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	balance two directories ...									|
 *		|_______________________________________________________________|
 */

void baldir (origdir, destdir) char * origdir , * destdir ; {

	register char * np ;
	register DIRDES * ddp ;
	register DIRENT * dep ;
	char	 origpath [1024] ;
	int		 mrd ;

	ddp = OpenDir (origdir) ;

	if ( ddp == NULL ) {
		fprintf (stderr, "bal: can't open %s\n", origdir) ;
		return ;
	}

	while ( (dep = ReadDir (ddp)) != NULL ) {

		np = dep->d_name ;

		if ( dotdir (np) ) {
			continue ;
		}

		sprintf (origpath, "%s%c%s", origdir, DIRSEP, np) ;

		if ( filetype ( origpath ) == T_DIR ) {
			if ( recurseflag ) {
				baldir (origpath, destdir) ;
			} else {
				if ( matchflag ) {
					mrd = patmat ( np , patbuf ) ;
					if ( mrd == FALSE ) {
						continue ;
					}
				}
				baleqv (origpath, destdir) ;		/* assert ! */
			}
		} else {
			if ( matchflag ) {
				mrd = patmat ( np , patbuf ) ;
				if ( mrd == FALSE ) {
					continue ;
				}
			}
			baleqv (origpath, destdir) ;
		}
	}

	CloseDir (ddp) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	balance a file to its equivalent on a dir ...				|
 *		|_______________________________________________________________|
 */

void baleqv (origfil, destdir) char * origfil , * destdir ; {

	if (recurseflag)
		sprintf (destpath, "%s%c%s", destdir, DIRSEP, origfil+origlen+1) ;
	else
		sprintf (destpath, "%s%c%s", destdir, DIRSEP, lastname (origfil)) ;

	balfil (origfil, destpath) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	balance two files ...										|
 *		|_______________________________________________________________|
 */

void balfil (origfil, destfil) char * origfil , * destfil ; {

	STABUF * stap ;
	sbit64   siz1 = 0 , siz2 = 0 ;
	ULONG    tim1 = 0 , tim2 = 0 ;
	int      typ1 = 0 /* , typ2 = 0 */ ;
	int      sig = 0 ;
	int			rd ;

	if ( ( stap = statof (origfil) ) == NULL ) {
		printf ("? %-30s \n", origfil) ;
		return ;
	}

	siz1 = stap->st_size ;
	tim1 = orig_utim.modtime = orig_mtime = stap->st_mtime ;
	typ1 = typeof (stap) ;
	orig_utim.actime = orig_atime = stap->st_atime ;
	orig_uid = stap->st_uid ;
	orig_gid = stap->st_gid ;
	orig_mod = stap->st_mode ;

	if ( typ1 != T_FILE )
		if ( ! anytypeflag ) {
			if (verboseflag)
				printf ("! %-30s \n", origfil) ;
			return ;
		}

	if ( ( stap = statof (destfil) ) == NULL ) {

		flipline ('n') ;
		printf ("  %-30s  -? %lld %-30s \n", " ", (long long)siz1, destfil) ;

		if ( totsizeflag ) {
			totsizes += siz1 ;
			newsizes += siz1 ;
			totfiles += 1 ;
			newfiles += 1 ;
		}

		if ( updatedest || updateflag ) {

			balcop (origfil, destfil) ;
		}

		return ;
	}

	if ( newonlyflag ) {
		return ;
	}

	siz2 = stap->st_size ;
	tim2 = stap->st_mtime ;

	if ( refreshflag ) {

		if ( tim1 == tim2 ) {
			if (verboseflag)
				printf ("  %-30s =   %-30s \n", origfil, destfil) ;
			return ;
		}

		if ( tim1 > tim2 ) {
			printf ("\n") ; flipline ('y') ;
			sig = '>' ;
			printf ("  %-30s %c   %-30s\n", origfil, sig, destfil) ;
			if (verboseflag || fixfatflag) {
				printf ("  %-30s %c ", timestamp (tim1), sig) ;
				printf ("  %-30s\n\n", timestamp (tim2)) ;
			}
			if ( lslflag ) {
				/* scan origfil, destfil for double quotes and escape them all */
				sprintf (cmdsbuff, "ls -ld %s \"%s\" \"%s\"", lsopts, origfil, destfil) ;
				puts (cmdsbuff) ;
				srd = system (cmdsbuff) ;
			}
			if ( diffflag ) {
				/* scan origfil, destfil for double quotes and escape them all */
				sprintf (cmdsbuff, "diff \"%s\" \"%s\"", origfil, destfil) ;
				puts (cmdsbuff) ;
				srd = system (cmdsbuff) ;
			}
			if (fixfatflag) {
				rd = balcmp (origfil, destfil) ;
				if ( rd == 0 ) { /* content match , timestamp mismatch */
					printf ("  %-30s =   %-30s\n\n", origfil, destfil) ;
					baltim (destfil) ;
				} else if ( rd == 1 ) {
					printf ("  %-30s #   %-30s\n\n", origfil, destfil) ;
					balcop (origfil, destfil) ;
				}
				return ;
			}
			if ( totsizeflag ) {
				totsizes += siz1 /* ( siz1 - siz2 ) */ ;
				updsizes += siz1 /* ( siz1 - siz2 ) */ ;
				totfiles += 1 ;
				updfiles += 1 ;
			}
			if ( updatedest )
				balcop (origfil, destfil) ;
		}

# ifdef TWOWAY
		if ( tim1 < tim2 )
			balcop (destfil, origfil) ;
# endif /* TWOWAY */

		return ;
	}

	if ( siz1 == siz2 ) {
		switch ( balcmp (origfil, destfil) ) {
			case  0 :
				if (verboseflag)
					printf ("  %-30s =   %-30s \n", origfil, destfil) ;
				if (fixtimeflag) {
					if ( tim1 != tim2 ) {
						if ( verboseflag ) {
							printf ("  %-30s %c ", timestamp (tim1), '#') ;
							printf ("  %-30s\n\n", timestamp (tim2)) ;
						}
						baltim (destfil) ;
					}
				}
			break ;
			case  1 :
				printf ("\n") ; flipline ('y') ;
				printf ("  %-30s #   %-30s \n", origfil, destfil) ; sig = '#' ;
				if ( lslflag ) {
					/* scan origfil, destfil for double quotes and escape them all */
#if 0
					sprintf (cmdsbuff, "ls -ld \"%s\" \"%s\"", origfil, destfil) ;
#endif
					sprintf (cmdsbuff, "ls -ld %s \"%s\" \"%s\"", lsopts, origfil, destfil) ;
					puts (cmdsbuff) ;
					srd = system (cmdsbuff) ;
				}
				if ( diffflag ) {
					/* scan origfil, destfil for double quotes and escape them all */
					sprintf (cmdsbuff, "diff \"%s\" \"%s\"", origfil, destfil) ;
					puts (cmdsbuff) ;
					srd = system (cmdsbuff) ;
				}
			break ;
			case -1 : printf ("? %-30s \n", origfil) ; break ;
			case -2 : printf ("  %-30s   ? %lld %-30s \n", " ", (long long)siz1, destfil) ; break ;
		}
	} else {
		printf ("\n") ;
		if ( siz1 > siz2 ) {
			sig = '>' ;
		} else {
			sig = '<' ;
		}

		printf ("  %-30s %c   %-30s\n", origfil, sig, destfil) ;

		if ( lslflag ) {
			/* FIXME: scan origfil, destfil for double quotes and escape them all */
#if 0
			sprintf (cmdsbuff, "ls -ld \"%s\" \"%s\"", origfil, destfil) ;
#endif
			sprintf (cmdsbuff, "ls -ld %s \"%s\" \"%s\"", lsopts, origfil, destfil) ;
			puts (cmdsbuff) ;
			srd = system (cmdsbuff) ;
		}
		if ( diffflag ) {
			/* FIXME: scan origfil, destfil for double quotes and escape them all */
			sprintf (cmdsbuff, "diff \"%s\" \"%s\"", origfil, destfil) ;
			puts (cmdsbuff) ;
			srd = system (cmdsbuff) ;
		}

	}

	if ( sig != 0 ) {
		if ( totsizeflag ) {
			totsizes += siz1 /* ( siz1 - siz2 ) */ ;
			updsizes += siz1 /* ( siz1 - siz2 ) */ ;
			totfiles += 1 ;
			updfiles += 1 ;
		}
		if ( updatedest )
			balcop (origfil, destfil) ;
		if ( updateorig )
			balcop (destfil, origfil) ;
		if ( updateflag ) {
			if ( tim1 > tim2 )
				balcop (origfil, destfil) ;
			if ( tim1 < tim2 )
				balcop (destfil, origfil) ;
		}
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	compare two files ...										|
 *		|_______________________________________________________________|
 */

int balcmp (origfil, destfil) char * origfil , * destfil ; {

	sbit64 filesize = 0, bytesread, byte2read, iobytes = 0 ;
	register int bytes2cmp = buffsize ;
	register FILE * fp1 , * fp2 ;

	if ( ( fp1 = fopen (origfil, "rb") ) == NULL ) {
		return -1 ;
	}

	if ( ( fp2 = fopen (destfil, "rb") ) == NULL ) {
		fclose (fp1) ;
		return -2 ;
	}

	if ( fastcompflag || fas2compflag || fas3compflag )
		bytes2cmp = fastsize ;

	if ( progressflag ) {
		filesize = bytesof ( statof (origfil) ) ;
		ptrel64 (iobytes, filesize, 0) ;
	}

	while ( ( bytesread = byte2read = fread (origbuff, 1, bytes2cmp, fp1) ) > 0 ) {

		if ( byte2read != (sbit64)fread (destbuff, 1, bytesread, fp2) )
			return -3 ;

		if ( progressflag ) {
			iobytes += bytesread ;
			ptrel64 (iobytes, filesize, 0) ;
		}

		if ( memcmp (origbuff, destbuff, bytesread) ) {
			bytesread = 1 ;
			goto eoc ;
		}

		if ( fastcompflag )
			break ;
	}

	bytesread = 0 ;

eoc :

	fclose (fp1) ;
	fclose (fp2) ;

	return bytesread ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	chmod destfile ...											|
 *		|_______________________________________________________________|
 */

int balmod (destfil) char * destfil ; {

	if ( chmoderrorcount > MAXCHMODERR )
		return -1 ;

	if ( chmod ( destfil , orig_mod ) != 0 ) {
		fprintf (stderr, "bal: can't chmod <%s>\n", destfil) ;
		++chmoderrorcount ;
		return -1 ;
	}

	return 0 ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	chown destfile ...											|
 *		|_______________________________________________________________|
 */

int balown (destfil) char * destfil ; {

	if ( chownerrorcount > MAXCHOWNERR )
		return -1 ;

	if ( chown ( destfil , orig_uid , orig_gid ) != 0 ) {
		fprintf (stderr, "bal: can't chown <%s>\n", destfil) ;
		++chownerrorcount ;
		return -1 ;
	}

	return 0 ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	touch destfile ...											|
 *		|_______________________________________________________________|
 */

int baltim (destfil) char * destfil ; {

	if ( toucherrorcount > MAXTOUCHERR )
		return -1 ;

	if ( utime ( destfil , &orig_utim ) != 0 ) {
		fprintf (stderr, "bal: can't utime <%s>\n", destfil) ;
		++toucherrorcount ;
		return -1 ;
	}

	return 0 ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	copy (or move) files ...									|
 *		|_______________________________________________________________|
 */

int balcop (origfil, destfil) char * origfil , * destfil ; {

# define MANUALCONFIGCOPY
# ifdef  MANUALCONFIGCOPY
# define HARDCOPY /* SYSCOPY */
# endif

	if ( moveflag ) {
		sprintf (cmdsbuff, "mv \"%s\" \"%s\"", origfil, destfil) ;
	} else {
		sprintf (cmdsbuff, "cp -p \"%s\" \"%s\"", origfil, destfil) ;
	}

	if ( scriptflag ) {
		fprintf (bsfp, "%s\n", cmdsbuff) ;
		return 0 ;
	}

# ifdef SYSCOPY

	if ( mockrunflag )
		printf ("%s\n", cmdsbuff) ;
	else
		system (cmdsbuff) ;

	return 0 ;

# endif /* SYSCOPY */

# ifdef HARDCOPY

	sbit64 filesize = 0, bytesread, iobytes = 0 ;
	register FILE * fp1 , * fp2 ;

	if ( mockrunflag ) {
		printf ("copying <%s> to <%s>\n", origfil, destfil) ;
		return 0 ;
	}

	if ( ( fp1 = fopen (origfil, "rb") ) == NULL ) {
		fprintf (stderr, "bal: can't open <%s>\n", origfil) ;
		return -1 ;
	}

	if ( makepath (destfil) < 0 ) {
		fprintf (stderr, "bal: can't make path to <%s>\n", destfil) ;
		fclose (fp1) ;
		return -2 ;
	}

	if ( ( fp2 = fopen (destfil, "wb") ) == NULL ) {
		fprintf (stderr, "bal: can't create <%s>\n", destfil) ;
		fclose (fp1) ;
		return -3 ;
	}

	if ( progressflag ) {
		filesize = bytesof ( statof (origfil) ) ;
		ptrel64 (iobytes, filesize, 0) ;
	}

	while ( ( bytesread = fread (origbuff, 1, buffsize, fp1) ) > 0 ) {
		fwrite (origbuff, 1, bytesread, fp2) ;
		if ( progressflag ) {
			iobytes += bytesread ;
			ptrel64 (iobytes, filesize, 0) ;
		}
	}

	fclose (fp1) ;
	fclose (fp2) ;

	baltim (destfil) ;
	balmod (destfil) ;
	balown (destfil) ;

	if ( maxops > 0 ) {
		++numops ;
		if ( numops > maxops ) {
			epilogue () ;
		}
	}

	return bytesread ;

# endif /* HARDCOPY */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
