
/*
 *          |          _                    |~~~~~~~~~~~~~~~~~~~~~~~|
 *          |\       _/ \_                  |    Alexandre Botao    |
 *          | \_    /_    \_                |     www.botao.org     |
 *          \   \__/  \__   \               |   +55-11-98244-UNIX   |
 *           \_    \__/  \_  \              |   +55-11-9933-LINUX   |
 *             \_   _/     \ |              |     botao@unix.net    |
 *               \_/        \|              |  alexandre@botao.org  |
 *                           |              |_______________________|
 */

# define	SWNAME			"fsu"
# define	SWVERS			"1.0.16"
# define	SWFORG			"$"						/*	"$" = stable	*/
# define	SWDATE			"2015/03/22"
# define	SWDESC			"filesystem usage"
# define	SWTAGS			"depth,directory,disk,level,filesystem,usage"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	fsu							file system usage	|
 *		\ \/ /		|	(c) 2014-2015			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define	_XOPEN_SOURCE	500

# include	<ftw.h>
# include	<stdio.h>
# include	<stdlib.h>
# include	<string.h>
# include	<signal.h>
# include	<unistd.h>

# include	<sys/types.h>
# include	<sys/stat.h>

# include	<sys/time.h>
# include	<sys/resource.h>

/*_____________________________________________________________________
 |                                                                     |
 |  This code is provided by the author(s) on an "AS IS" basis.        |
 |                                                                     |
 |  This code is free software: you can redistribute it and/or modify  |
 |  it under the terms of the GNU General Public License as published  |
 |  by the Free Software Foundation, either version 3 of the License,  |
 |  or (at your option) any later version.                             |
 |                                                                     |
 |  This code is distributed in the hope that it will be useful,       |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of     |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.               |
 |  See the GNU General Public License for more details.               |
 |                                                                     |
 |  You should have received a copy of the GNU General Public License  |
 |  along with this code. If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                    |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.           |
 |_____________________________________________________________________|
 */

# include	"configure.h"
# include	"params.h"

# include	"argent.h"
# include	"getmount.h"

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

typedef		struct rlimit		RLIMITBUF ;

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

int				allflag			= 0 ;
int				bigflag			= 0 ;
int				depthflag		= 0 ;
int				dumpflag		= 0 ;
int				errorsflag		= 0 ;
int				followflag		= 0 ;
int				helpflag		= 0 ;
int				cramflag		= 0 ;
int				mountflag		= 0 ;
int				reportflag		= 0 ;
int				summaryflag		= 0 ;
int				syntaxflag		= 0 ;
int				totalflag		= 0 ;
int				treeflag		= 0 ;
int				verboseflag		= 0 ;
int				versionflag		= 0 ;

int				ftwflags		= 0 ;

int maxftwdepth = 128 ;

int limdepth = 1 ;

off_t	dirsiz ;
off_t	filsiz ;
off_t	othsiz ;

off_t	dircnt ;
off_t	filcnt ;
off_t	othcnt ;

off_t	totdirsiz = 0 ;
off_t	totfilsiz = 0 ;
off_t	totothsiz = 0 ;

off_t	totdircnt = 0 ;
off_t	totfilcnt = 0 ;
off_t	totothcnt = 0 ;

int		fscnt = 0 ;

RLIMITBUF		rlimbuf ;

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

static int display_info(const char *fpath, const struct stat *sb, int tflag, struct FTW *ftwbuf) {
	char * tdesc ;
	off_t  asize ;
	asize = sb->st_size ;
	switch ( tflag ) {
		case FTW_D   : tdesc = "d"   ; ++dircnt ; dirsiz += asize ; break ;
		case FTW_F   : tdesc = "f"   ; ++filcnt ; filsiz += asize ; break ;
		case FTW_NS  : tdesc = "ns"  ; ++othcnt ; othsiz += asize ; break ;
		case FTW_DNR : tdesc = "dnr" ; ++othcnt ; othsiz += asize ; break ;
		case FTW_SLN : tdesc = "sln" ; ++othcnt ; othsiz += asize ; break ;
		case FTW_DP  : tdesc = "dp"  ; ++othcnt ; othsiz += asize ; break ;
		case FTW_SL  : tdesc = "l"   ; ++othcnt ; othsiz += asize ; break ;
		default      : tdesc = "???" ; ++othcnt ; othsiz += asize ; break ;
	}
	if ( tflag == FTW_D || allflag ) {
		if ( ftwbuf->level <= limdepth ) {
			printf("%-3s %3d %2d %7lld   %-40s %d %s\n", tdesc, tflag, 
				ftwbuf->level, (long long) asize,
				fpath, ftwbuf->base, fpath + ftwbuf->base);
		}
	}
	return 0;
}

int fsu ( path , flag ) char * path ; int flag ; {

	int		rd ;
	char * mntpath ;

	mntpath = getmount ( path ) ;

	dirsiz = filsiz = othsiz = 0;
	dircnt = filcnt = othcnt = 0;

	rd = nftw ( mntpath, display_info, maxftwdepth, flag );

	if ( rd == 0 ) {
		printf ( "%15lld in %9lld %s on %s\n" , (long long) dirsiz , (long long) dircnt , "dirs " , mntpath ) ;
		printf ( "%15lld in %9lld %s on %s\n" , (long long) filsiz , (long long) filcnt , "files" , mntpath ) ;
		printf ( "%15lld in %9lld %s on %s\n" , (long long) othsiz , (long long) othcnt , "other" , mntpath ) ;
	}

	return rd ;
}

void setdepth (tval) char * tval ; {
	int ival ;

	if ( tval == NULL || *tval == '\0' )
		return ;

	ival = atoi ( tval ) ;

	if ( ival < 0 || ival > maxftwdepth )
		return ;

	limdepth = ival ;
}

/*____________________________________________________________________________
*/

void prog_work (void) {

	register char * eacharg ;

	setargent () ;

	while ( ( eacharg = getargent () ) != NULL ) {

		if ( EXIT_SUCCESS == fsu ( eacharg , ftwflags ) ) {

			totdirsiz += dirsiz ;	totdircnt += dircnt ;
			totfilsiz += filsiz ;	totfilcnt += filcnt ;
			totothsiz += othsiz ;	totothcnt += othcnt ;

			++fscnt ;
		}
	}

	endargent () ;

	if ( fscnt > 1 ) {
		printf ( "%15lld in %9lld %s on %s\n" , (long long) totdirsiz , (long long) totdircnt , "dirs " , "total" ) ;
		printf ( "%15lld in %9lld %s on %s\n" , (long long) totfilsiz , (long long) totfilcnt , "files" , "total" ) ;
		printf ( "%15lld in %9lld %s on %s\n" , (long long) totothsiz , (long long) totothcnt , "other" , "total" ) ;
	}
}

void prog_init (void) {

	if ( getrlimit(RLIMIT_NOFILE, &rlimbuf) == -1 ) {
		perror("getrlimit") ;
	} else {
		maxftwdepth = rlimbuf.rlim_cur ;
	}

	if ( depthflag )
		ftwflags |= FTW_DEPTH;
	if ( followflag )
		ftwflags |= FTW_PHYS;
	if ( mountflag )
		ftwflags |= FTW_MOUNT;
}

void prog_avow (void) {
}

int prog_end (void) {
	return EXIT_SUCCESS;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int main (
				int		argc ,
				char	* argv []
) {
	register	int		i ;

	/* parse args */

	while ( EOF != ( i = getopt (argc, argv, "ad:DehL:lmMrstTvV?") ) )
		switch (i) {
			case 'a' : ++allflag ;					break ;
			case 'd' : addargent (optarg) ;			break ;
			case 'D' : ++depthflag ;				break ;
			case 'e' : ++errorsflag ;				break ;
			case 'h' : ++helpflag ;					break ;
			case 'l' : ++followflag ;				break ;
			case 'L' : setdepth (optarg) ;			break ;
			case 'm' : ++mountflag ;				break ;
			case 'M' : ++cramflag ;					break ;
			case 'r' : ++reportflag ;				break ;
			case 's' : ++summaryflag ;				break ;
			case 't' : ++totalflag ;				break ;
			case 'T' : ++treeflag ;					break ;
			case 'v' : ++verboseflag ;				break ;
			case 'V' : ++versionflag ;				break ;
			case '?' : ++helpflag ;					break ;
			default  : ++syntaxflag ;				break ;
		}

	prog_avow () ;							/*	enforce semantics	*/

	if ( optind < argc )						/*	unchecked args	*/
		while (optind < argc)
			addargent (argv[optind++]) ;

	if ( totargent () == 0 )					/*	defaults here	*/
		addargent (".") ;

	prog_init () ;									/*	prep stuff	*/

	prog_work () ;									/*	just ...	*/

	return prog_end () ;								/*	enough	*/
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

/*
 * vi:nu ts=4
 */
