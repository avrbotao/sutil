#include <dirent.h>
main(){
           DIR *dirp;
	int n=0;
           struct dirent *dp;
           dirp = opendir(".");
           while ((dp = readdir(dirp)) != NULL) {
		printf ("%12d %s\n", n++, dp->d_name);
           }
           (void) closedir(dirp);
}
