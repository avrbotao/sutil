
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   vpwx            verify passwd cross-platform   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'SAUL' (the 'support and administration for     |
 | unix and linux' tool) as released by Alexandre Botao <botao.org> ;   |
 |                                                                      |
 | 'SAUL' is Free and Open Source software (FOSS). This means you can   |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'SAUL' is distributed in the hope that it will be useful,            |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'SAUL'.  If not, see <http://www.gnu.org/licenses/>, or   |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <syslog.h>

/*_______________________________________________________________________
*/

# define	PWXVERS		"1.2.8"

/*_______________________________________________________________________
*/

# define	PWXGOOD		0x00
# define	PWXFAIL		1
# define	PWXVOID		2

# define	LOKFAIL		3
# define	UNLOKER		4

# define	STATERR		5
# define	OPENERR		6
# define	CLOSERR		7

# define	RESETOK		8
# define	RESETER		9

# define	MISSHAD		10
# define	SEEKERR		11
# define	PWXLOCK		12
# define	PWXDENY		13

/*_______________________________________________________________________
*/

struct	pwxrec	{
	int		sysloglev ;
	char *	syslogtag ;
	char *	syslogtxt ;
} ;

typedef		struct pwxrec		PWXREC ;

/*_______________________________________________________________________
*/

PWXREC	pwxinfo [] = {
	{ LOG_INFO		,	"info"	,	"authenticatedok"	} ,
	{ LOG_ERR		,	"err"	,	"unauthenticated"	} ,
	{ LOG_WARNING	,	"warn"	,	"boguscredential"	/*	"unrecognizedata"	*/	} ,
	{ LOG_ERR		,	"err"	,	"lockmalfunction"	} ,
	{ LOG_ERR		,	"err"	,	"unlockhasfailed"	} ,
	{ LOG_ERR		,	"err"	,	"statmalfunction"	} ,
	{ LOG_ERR		,	"err"	,	"openmalfunction"	} ,
	{ LOG_ERR		,	"err"	,	"closedisastrous"	} ,
	{ LOG_INFO		,	"info"	,	"resetsuccessful"	} ,
	{ LOG_ERR		,	"err"	,	"resetdisastrous"	} ,
	{ LOG_ERR		,	"err"	,	"missedshadowrec"	} ,
	{ LOG_ERR		,	"err"	,	"seekmalfunction"	} ,
	{ LOG_ERR		,	"err"	,	"accountislocked"	} ,
	{ LOG_ERR		,	"err"	,	"mustberoottorun"	} ,
	{ -1			,	"bug"	,	"internalfailure"	}
} ;

char *	username = "undefineduser"		;
char *	password = "undefinedpass"		;
char *	passcryp = "undefinedcryp"		;
char *	passcomp = "undefinedcomp"		;
char *	iaddress = "undefinedipv4addr"	;
char *	syslogid = "undefinedsyloid"	;

int		syslogfac = LOG_LOCAL5 ;

int		resetflag = 0 ;

/*_____________________________________________________________________
**																	   **
**	vpwx															   **
**_____________________________________________________________________**
*/

void dispwx ( pwxwhat ) int pwxwhat ; {

	openlog ( syslogid , LOG_NDELAY , syslogfac ) ;

	syslog (
		syslogfac | pwxinfo[pwxwhat].sysloglev ,
		"auth: %s: %s@%s %s\n" ,
		pwxinfo[pwxwhat].syslogtag ,
		username ,
		iaddress ,
		pwxinfo[pwxwhat].syslogtxt
	) ;

	closelog ( ) ;

	printf ( "%s\n" , pwxinfo[pwxwhat].syslogtxt ) ;
}

/*_______________________________________________________________________
*/

# ifdef CYG_VPWX

# define TRAD_VPWX

# endif

/*_______________________________________________________________________
*/

# ifdef LNX_VPWX

/* cc -DLNX_VPWX -lcrypt */

#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <shadow.h>

#define _GNU_SOURCE
#include <crypt.h>

int vpwx ( login , password ) char * login , * password ; {

	struct passwd * pw ;
	struct spwd * sp ;
	struct stat stabuf ;
	FILE * shadfp ;
	fpos_t shadof ;
	char * encrypted , * correct ;
	int    found , ercnt ;

	pw = getpwnam (login) ;
	endpwent () ;

	if ( pw == NULL ) {
		dispwx ( PWXVOID ) ;
	} else {
		sp = getspnam (pw->pw_name) ;
		endspent () ;
/* validate sp, pw, crypt, etc... */
		if ( sp == NULL ) {
			correct = pw->pw_passwd ;
		} else {
			correct = sp->sp_pwdp ;
			if ( *correct == '!' ) {
				dispwx ( PWXLOCK ) ;
				return -1 ;
			}
		}
		encrypted = crypt ( password, correct ) ;
		if ( resetflag ) {
# ifdef		_PATH_SHADOW
#	define	VPWX_SHADOW		_PATH_SHADOW
# else
#	define	VPWX_SHADOW		"/etc/shadow"
# endif
			if ( stat ( VPWX_SHADOW , &stabuf ) == 0 ) {
# ifdef UNSAFE
				printf("shad(%s),size(%ld),mode(%lo)\n",VPWX_SHADOW,(long)stabuf.st_size,(long)stabuf.st_mode);
# endif
				if ( 0 == lckpwdf () ) {
					if ( ( shadfp = fopen ( VPWX_SHADOW , "r+" ) ) == NULL ) {
						dispwx ( OPENERR ) ;
					} else {
						found = ercnt = 0 ;
						if ( 0 != fgetpos ( shadfp , &shadof ) ) {
							dispwx ( SEEKERR ) ; ++ercnt ;
						}
						while ( ( sp = fgetspent ( shadfp ) ) != NULL ) {
							if ( 0 == strcmp ( sp->sp_namp , pw->pw_name ) ) {
								found = 1 ;
								break ;
							}
							if ( 0 != fgetpos ( shadfp , &shadof ) ) {
								dispwx ( SEEKERR ) ; ++ercnt ;
							}
						}
						if ( ! found ) {
							dispwx ( MISSHAD ) ;
						} else {
							if ( ercnt == fsetpos ( shadfp , &shadof ) ) {
								sp->sp_pwdp = strdup ( encrypted ) ;
								if ( putspent ( sp , shadfp ) == 0 ) {
									dispwx ( RESETOK ) ;
								} else {
									dispwx ( RESETER ) ;
								}
							} else {
								dispwx ( SEEKERR ) ;
							}
						}
						if ( fclose ( shadfp ) != 0 ) {
							dispwx ( CLOSERR ) ;
						}
					}
					if ( 0 != ulckpwdf () ) {
						dispwx ( UNLOKER ) ;
					}
				} else {
					dispwx ( LOKFAIL ) ;
				}
			} else {
				dispwx ( STATERR ) ;
			}
		} else {
			if ( strcmp ( encrypted, correct ) ) {
				dispwx ( PWXFAIL ) ;
			} else {
				dispwx ( PWXGOOD ) ;
			}
		}
	}

	return 0 ;
}

# endif /* LNX_VPWX */

/*_______________________________________________________________________
*/

# ifdef TRAD_VPWX

/* cc -DTRAD_VPWX -lcrypt */

#include <pwd.h>

# ifdef CYG_VPWX
# include <crypt.h>
# endif

char * crypt () ;

int vpwx ( login , password ) char * login , * password ; {

	struct passwd *user;

	if ((user= getpwnam(login)) == NULL)
		printf("No such user\n");
	else if (!strcmp(user->pw_passwd, crypt(password, user->pw_passwd)))
		printf("Password correct\n");
	else
		printf("Password incorrect\n");

}

# endif /* TRAD_VPWX */

/*_______________________________________________________________________
*/

# ifdef SOL_VPWX

#include <shadow.h>

int vpwx ( login , password ) char * login , * password ; {

	struct spwd *user;

	if ((user= getspnam(login)) == NULL) {
		printf("No such user\n");
	} else {
		if (!strcmp(user->sp_pwdp, crypt(password, user->sp_pwdp))) {
			printf("Password correct\n");
		}
	} else {
		printf("Password incorrect\n");
	}

}

# endif /* SOL_VPWX */

/*_______________________________________________________________________
*/

# ifdef AIX_VPWX

#include <userpw.h>

int vpwx ( login , password ) char * login , * password ; {

	struct userpw *user;

	if ((user= getuserpw(login)) == NULL)
		printf("No such user\n");
	else if (!strcmp(user->upw_passwd, crypt(password, user->upw_passwd)))
		printf("Password correct\n");
	else
		printf("Password incorrect\n");

}

# endif /* AIX_VPWX */

/*_______________________________________________________________________
*/

# ifdef HPUX_VPWX

/* cc -DHPUX_VPWX -DHPUX_PROT -lsec */

#include <sys/types.h>
#include <hpsecurity.h>

# ifdef HPUX_PROT
#include <prot.h>
#define  GETXPWNAM	getprpwnam
struct pr_passwd *user;
# endif

# ifdef HPUX_SPWD
#include <pwd.h>
#define  GETXPWNAM	getspwnam
struct s_passwd *user;
# endif

int vpwx ( login , password ) char * login , * password ; {

	if ( ( user = GETXPWNAM (login) ) == NULL ) {
		dispwx ( PWXVOID ) ;
	} else {
		if ( resetflag ) {
			passcryp = bigcrypt ( password, user->ufld.fd_encrypt ) ;
			strcpy ( user->ufld.fd_encrypt , passcryp ) ;
			if ( putprpwnam ( login , user ) == 0 ) {
				dispwx ( PWXFAIL ) ;
			} else {
				dispwx ( PWXGOOD ) ;
			}
		} else {
			if ( strcmp ( passcomp = user->ufld.fd_encrypt, passcryp = bigcrypt ( password, user->ufld.fd_encrypt ) ) ) {
				dispwx ( PWXFAIL ) ;
			} else {
				dispwx ( PWXGOOD ) ;
			}
		}
	}

	return 0 ;
}

# endif /* HPUX_VPWX */

/*_______________________________________________________________________
*/

char * pwfetch ( what ) char what ; {

	char * prompt = NULL ;
	char * envvar = NULL ;
	char * result = NULL ;

	switch ( what ) {
		case 'u' :
			prompt = "username: " ;
			envvar = "VUSER" ;
		break ;
		case 'p' :
			prompt = "password: " ;
			envvar = "VPASS" ;
		break ;
		case 'a' :
			prompt = "iaddress: " ;
			envvar = "VADDR" ;
		break ;
		case 'i' :
			prompt = "syslogid: " ;
			envvar = "VSLID" ;
		break ;
	}

	result = getenv ( envvar ) ;

	if ( result != NULL && *result != '\0' ) {
		return strdup ( result ) ;
	} else {
		result = strdup ( getpass ( prompt ) ) ;
	}

	return result ;
}

/*_______________________________________________________________________
*/

# define	STRICTCK	0x00
# define	GENTLECK	0x01

void vpwidck (cktyp) int cktyp ; {
	uid_t myruid, myeuid ;
	gid_t myrgid, myegid ;

	myruid = getuid  () ;
	myeuid = geteuid () ;
	myrgid = getgid  () ;
	myegid = getegid () ;

	if ( cktyp == STRICTCK ) {
		if ( myeuid != 0 ) {
			dispwx ( PWXDENY ) ;
			exit (1) ;
		}
	}

# ifdef UNSAFE
	printf ("ruid=(%ld),euid=(%ld),ruid=(%ld),euid=(%ld)\n", (long)myruid, (long)myeuid, (long)myrgid, (long)myegid) ;
# endif
}

void vpwfet () {
	vpwidck (STRICTCK) ;
	username = pwfetch ( 'u' ) ;
	password = pwfetch ( 'p' ) ;
	iaddress = pwfetch ( 'a' ) ;
	syslogid = pwfetch ( 'i' ) ;
}

/*_______________________________________________________________________
*/

int main ( argc , argv ) int argc ; char * * argv ; {

	int		code = 0 ;

	if ( argc == 1 ) {
		vpwfet () ;
		vpwx ( username , password ) ;
	} else {
		if ( 0 == strcmp ( *(argv+1) , "--version" ) ) {
			vpwidck (GENTLECK) ;
			printf ("%s\n", PWXVERS) ;
		} else if ( 0 == strcmp ( *(argv+1) , "--reset" ) ) {
			resetflag = 1 ;
			vpwfet () ;
			vpwx ( username , password ) ;
		}
	}

# ifdef UNSAFE
	fprintf ( stderr , "user(%s) pass(%s) cryp(%s) comp(%s) addr(%s) sylo(%s)\n" , username , password , passcryp , passcomp , iaddress , syslogid ) ;
# endif

	return code ;
}

/*_______________________________________________________________________
** vi:nu ts=4
*/

