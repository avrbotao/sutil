
# ifndef    _XACL_H_

# define    _XACL_H_

#include <stdio.h>
#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include <acl/libacl.h>
#include <sys/acl.h>

#include <pwd.h>
#include <grp.h>

#define errExit(msg)    do { perror(msg); exit(EXIT_FAILURE); } while (0)

#define fatal(msg)      do { fprintf(stderr, "%s\n", msg); exit(EXIT_FAILURE); } while (0)

char *userNameFromId(uid_t uid);

uid_t userIdFromName(const char *name);

char *groupNameFromId(gid_t gid);

gid_t groupIdFromName(const char *name);

# endif  /* _XACL_H_ */

/*
 * vi:nu
 */
