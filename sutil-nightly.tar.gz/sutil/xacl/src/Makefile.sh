cc -DXACLGET -DXACLSET -o xacl xacl.c -lacl
