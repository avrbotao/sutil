
/*
 *	qcy	quick cypher
 */

# include <limits.h>
# include <stdlib.h>
# include <string.h>
# include <stdio.h>

# include "configure.h"

# include "libxd6.h"
# include "libqcy.h"

# define ASK_MAX 3

# define CRIT 0
# define WARN 1

int grd = 0 ;

int errorflag = 0 ;
int helpflag = 0 ;
int passflag = 0 ;
int ttyflag = 0 ;

int qcycount = 0 ;

int asktimes = 0 ;
int askmax = ASK_MAX ;

char argpass [PATH_MAX] ;

char * outname = NULL ;

char * mesghead [] = { "crit" , "warn" , NULL } ;

void trimeol ( s ) char * s ; {
	register char * p ;

	for ( p = s ; *p != '\0' ; ++p )
		if ( *p == '\n' || *p == '\r' )
			*p = '\0' ;
}

void qcmesg (typ, buf) int typ ; char * buf ; {

	fprintf ( stderr , "*** %s : %s \n" , mesghead[typ] , buf ) ;
	if ( typ == CRIT )
		exit (1) ;
}

char * askpass () {

	static	char tempass [PATH_MAX] ;
			char chkpass [PATH_MAX] ;

	FILE * ifp = stdin ;

	int ttyok = 0 ;

	if ( asktimes == askmax ) {
		qcmesg (CRIT, "too many failures") ;
	} else {
		++asktimes ;
	}

	if ( ttyflag && ! ttyok ) {
		ifp = fopen ( "/dev/tty" , "r" ) ;
		if ( ifp == NULL ) {
			qcmesg (CRIT, "open tty failed") ;
		} else {
			ttyok = 1 ;
		}
	}

	printf ( "pass:") ;
	if ( fgets ( tempass , PATH_MAX , ifp ) == NULL ) {
		return NULL ;
	} else {
		printf ( "conf:") ;
		if ( fgets ( chkpass , PATH_MAX , ifp ) == NULL ) {
			return NULL ;
		} else {
			if ( 0 != strcmp ( tempass , chkpass ) ) {
				qcmesg (WARN, "mismatch") ;
				return NULL ;
			} else {
				return tempass ;
			}
		}
	}
}

void savepass ( s ) char * s ; {

	if ( s == NULL || *s == '\0' ) {
		qcmesg (WARN, "improper password") ;
		return ;
	} else {
		strncpy ( argpass , s , PATH_MAX - 1 ) ;
		argpass [ PATH_MAX - 1 ] = '\0' ;
		++passflag ;
	}
}

void filepass ( s ) char * s ; {
	static	char tempass [PATH_MAX] ;

	FILE * ifp = NULL ;

		ifp = fopen ( s , "r" ) ;

		if ( ifp == NULL ) {
			qcmesg (CRIT, "open pass file failed") ;
		}

		if ( fgets ( tempass , PATH_MAX , ifp ) == NULL ) {
			qcmesg (CRIT, "read pass file failed") ;
		}

		savepass ( tempass ) ;

		fclose (ifp) ;
}

void usage () {
	printf ("use: qcy [options]\n") ;
	printf ("  -o outputfile\n") ;
	printf ("  -P passwordfile\n") ;
	printf ("  -p password\n") ;
	printf ("  -t                  read password from tty\n") ;
	exit (1) ;
}

void qcy ( name ) char * name ; {

	if ( helpflag ) {
		usage () ;
	}

	while ( ! passflag ) {
		savepass ( askpass () ) ;
	}

	trimeol ( argpass ) ;

	++qcycount ;

	qcyfile ( name , outname , argpass ) ;
}

char * bigarg ( s ) char * s ; {
	register char * p ;

	p = strchr ( s , '=' ) ;
	if ( p == NULL )
		return NULL ;
	else
		return p + 1 ;
}

int main (argc, argv) int argc ; char * * argv ; {

	if ( argc == 1 ) {
		qcy ( NULL ) ;
	} else {
		while ( *++argv ) {
				if ( 0 == strcmp ( *argv , "-?" )	||
					 0 == strcmp ( *argv , "-h" )			) {
					++helpflag ;
			} else
				if ( 0 == strcmp ( *argv , "-o" )			) {
					outname = strdup ( *++argv ) ;
			} else
				if ( 0 == strcmp ( *argv , "-P" )			) {
					filepass ( *++argv ) ;
			} else
				if ( 0 == strcmp ( *argv , "-p" )			) {
					savepass ( *++argv ) ;
			} else
				if ( 0 == strcmp ( *argv , "-t" )		) {
					++ttyflag ;
			} else
				if ( 0 == strcmp ( *argv , "--help" )		) {
					++helpflag ;
			} else
				if ( NULL != strstr ( *argv , "--output" )	) {
					outname = strdup ( *++argv ) ;
			} else
				if ( NULL != strstr ( *argv , "--password" )	) {
					savepass ( bigarg ( *argv ) ) ;
			} else {
				qcy ( *argv ) ;
			}
		}
	}

	if ( qcycount == 0 ) {
		qcy ( NULL ) ;
	}

	return grd ;
}

/*
 * vi:nu ts=4
 */
