
# ifndef _QCY_H_
# define _QCY_H_

# include <stdlib.h>

# include "byteswap.h"

# define	UINT64SIZE	(sizeof(uint64_t))

# define	KEYLENQ		4
# define	KEYLENB		32

# define	QCYBUFSIZ	1048576

void qcyfile ( char * ,  char * ,  char * ) ;

# endif /* _QCY_H_ */

/*
 * vi:nu ts=4
 */
