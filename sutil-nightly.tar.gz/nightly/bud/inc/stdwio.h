
# include <stdio.h>

# define WIOBUFFSIZE	1024

int fgetword ( char * , FILE * ) ;
int fputword ( char * , int , FILE * ) ;

