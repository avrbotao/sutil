
/*		 _______________________________________________________________
 *		|																|
 *		|	stdtyp.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDTYP_H

# define _STDTYP_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	FIX			static
# define	REG			register
# define	EXT			extern
/* # define	NEW			auto */
# define	UNS			unsigned
# define	TYP			typedef

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifndef _ABX_H

# if	defined (__OpenBSD__) || defined (OpenBSD) 
typedef		__uint64_t	ubit64 ;
typedef		__int64_t	sbit64 ;
# endif

# if	defined (__FreeBSD__) || defined (FreeBSD) 
typedef		__uint64_t	ubit64 ;
typedef		__int64_t	sbit64 ;
# endif

# ifdef _AIX
typedef		int64_t		sbit64 ;
typedef         uint64_t        ubit64 ;
# endif

# ifdef __hpux
typedef		int64_t		sbit64 ;
typedef         uint64_t        ubit64 ;
# endif

# ifdef linux
typedef		/* int64_t */ long long int		sbit64 ;
typedef		unsigned long long int	ubit64 ;
# endif

# ifdef __CYGWIN__
typedef		long long int			sbit64 ;
typedef		unsigned long long int	ubit64 ;
# endif

# ifdef sun
typedef		longlong_t	sbit64 ;
typedef         uint64_t        ubit64 ;
# endif

# ifdef MSVC
typedef		__int64		sbit64 ;
typedef		unsigned long	u_long ;
# endif

# ifdef BCC55
typedef		__int64		sbit64 ;
/* typedef		unsigned long	u_long ; */
# endif

# endif /* ! _ABX_H */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

TYP		UNS char		UCHAR ;
TYP		UNS short		USHORT ;
TYP		UNS int			UINT ;
#ifndef ULONG
TYP		UNS long		ULONG ;
#endif

TYP		UNS				BIT ;
TYP		UCHAR			BYTE ;
TYP		USHORT			WORD ;
TYP		ULONG			DWORD ;

TYP		int				BOOL ;

TYP		char *			STR ;
TYP		char *			PTR ;
TYP		BYTE *			ADDR ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	KBYTE		* 1024
# define	KBYTES		* 1024

# define	MBYTE		* 1048576
# define	MBYTES		* 1048576

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDTYP_H */

/*
 * vi:tabstop=4
 */
