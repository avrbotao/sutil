
/*	 _______________________________________________________________
 *	|								|
 *	|	stdmath.h		 (c) 1998 Alexandre Botao	|
 *	|_______________________________________________________________|
 */

# ifndef _STDMATH_H

# define _STDMATH_H

/*	--	--	--	--	--	--	--	--	*/

typedef		sbit64		BINT ;

/*	--	--	--	--	--	--	--	--	*/

BINT		gcd2 (BINT, BINT) ;
BINT		modexp (BINT, BINT, BINT) ;
BINT		modinv (BINT, BINT) ;

/*	--	--	--	--	--	--	--	--	*/

# endif /* _STDMATH_H */
