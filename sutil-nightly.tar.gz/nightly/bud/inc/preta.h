
# include <signal.h>

# define	PTE_DATE	0x00000100
# define	PTE_TIME	0x00000200
# define	PTE_DONE	0x00000400
/*
# define	PTE_PCOK	0x00000[84]00
*/
# define	PTE_TODO	0x00001000
# define	PTE_ELAP	0x00002000
# define	PTE_RATE	0x00004000
# define	PTE_PBAR	0x00010000
# define	PTE_ETTC	0x00020000
# define	PTE_NEWL	0x00040000
# define	PTE_WAKE	0x08000000
# define	PTE_INIT	0x04000000

# define	BARYET		'|'
# define	BARPOK		'>'

# ifdef NEWPRETA
int preta (off_t *, off_t *, long) ;
# else  /* ! NEWPRETA */
int preta (long long, long long, long) ;
# endif /* NEWPRETA */

