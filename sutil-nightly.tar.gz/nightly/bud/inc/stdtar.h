
/*		 _______________________________________________________________
 *		|																|
 *		|	stdtar.h						 (c) 1999 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDTAR_H

# define _STDTAR_H

		/*==================================================*/
		/*	tar header block : posix 1003.1 (1990)			*/
		/*==================================================*/

struct	posixtarhdr {
									/* offset */
	char	pth_name   [100] ;		/*		0 */
	char	pth_mode     [8] ;		/*	  100 */
	char	pth_uid      [8] ;		/*	  108 */
	char	pth_gid      [8] ;		/*	  116 */
	char	pth_size    [12] ;		/*	  124 */
	char	pth_mtime   [12] ;		/*	  136 */
	char	pth_chksum   [8] ;		/*	  148 */
	char	pth_type     [1] ;		/*	  156 */
	char	pth_link   [100] ;		/*	  157 */
	char	pth_magic    [6] ;		/*	  257 */
	char	pth_version  [2] ;		/*	  263 */
	char	pth_uname   [32] ;		/*	  265 */
	char	pth_gname   [32] ;		/*	  297 */
	char	pth_major    [8] ;		/*	  329 */
	char	pth_minor    [8] ;		/*	  337 */
	char	pth_prefix [155] ;		/*	  345 */
									/*	  500 */
} ;

		/*==================================================*/
		/*	defines											*/
		/*==================================================*/

# define	V7TAR			'7'
# define	GNUTAR			'g'
# define	POSIXTAR		'p'

# ifdef NO_TAR_H

#	define	TMAGIC   "ustar"        /* ustar + nul			*/
#	define	TMAGLEN  6
#	define	TVERSION "00"           /* 00 (no nul)			*/
#	define	TVERSLEN 2

	/* type */

#	define	REGTYPE  '0'            /* regular file */
#	define	AREGTYPE '\0'           /* regular file */
#	define	LNKTYPE  '1'            /* link */
#	define	SYMTYPE  '2'            /* reserved */
#	define	CHRTYPE  '3'            /* character special */
#	define	BLKTYPE  '4'            /* block special */
#	define	DIRTYPE  '5'            /* directory */
#	define	FIFOTYPE '6'            /* FIFO special */
#	define	CONTTYPE '7'            /* reserved */

	/* mode */

#	define	TSUID    04000          /* set UID on execution */
#	define	TSGID    02000          /* set GID on execution */
#	define	TSVTX    01000          /* reserved */

	/* access */

#	define	TUREAD   00400          /* read by owner */
#	define	TUWRITE  00200          /* write by owner */
#	define	TUEXEC   00100          /* execute/search by owner */
#	define	TGREAD   00040          /* read by group */
#	define	TGWRITE  00020          /* write by group */
#	define	TGEXEC   00010          /* execute/search by group */
#	define	TOREAD   00004          /* read by other */
#	define	TOWRITE  00002          /* write by other */
#	define	TOEXEC   00001          /* execute/search by other */

# else

#	include	<tar.h>

# endif /* NO_TAR_H */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDTAR_H */

