
/*		 _______________________________________________________________
 *		|																|
 *		|	stdcmd.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDCMD_H

# define _STDCMD_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	XC_SAVECONT		  1001		/*	^K^S	F2					*/
# define	XC_SAVEEDIT		  1002		/*	^K^D						*/
# define	XC_SAVEEXIT		  1003		/*	^K^X						*/
# define	XC_QUITNEXT		  1004		/*	^K^N						*/
# define	XC_QUITEDIT		  1005		/*	^K^E	F3					*/
# define	XC_QUITEXIT		  1006		/*	^K^Q	F10					*/
# define	XC_SAVEAS		  1007		/*	^K^A						*/
# define	XC_QUITSWAP		  1008		/*	^K^Z						*/

# define	XC_PAGEDOWN		  1011		/*	^C		PgDn				*/
# define	XC_PAGEUP		  1012		/*	^R		PgUp				*/
# define	XC_FIRSTPAGE	  1013		/*	^Q^R	^PgUp				*/
# define	XC_LASTPAGE		  1014		/*	^Q^C	^PgDn				*/

# define	XC_MOVERIGHT	  1021		/*	^D		-->					*/
# define	XC_MOVELEFT		  1022		/*	^S		<--					*/
# define	XC_MOVEDOWN		  1023		/*	^X		Down				*/
# define	XC_MOVEUP  		  1024		/*	^E		Up					*/

# define	XC_PREVWORD		  1025		/*	^A		^Left				*/
# define	XC_NEXTWORD		  1026		/*	^F		^Right				*/

# define	XC_HOMELINE		  1031		/*	^Q^S	Home				*/
# define	XC_ENDOFLINE	  1032		/*	^Q^D	End					*/
# define	XC_PAGETOP		  1033		/*	^Q^E	^Home				*/
# define	XC_PAGEBASE		  1034		/*	^Q^X	^End				*/

# define	XC_DELCHAR		  1041		/*	^G		Del					*/
# define	XC_DELLINE		  1042		/*	^Y							*/
# define	XC_DELWORD		  1043		/*	^T							*/
# define	XC_DELRIGHT		  1044		/*	^Q^Y						*/

# define	XC_ROLLUP		  1051		/*	^Z							*/
# define	XC_ROLLDOWN		  1052		/*	^W							*/

# define	XC_POPINSERT	  1101		/*	^V		Ins					*/
# define	XC_POPINDENT	  1102		/*	^Q^I						*/
# define	XC_POPEXACT		  1103		/*	^Q^P						*/
# define	XC_POPCASE		  1104		/*	^Q^U						*/

# define	XC_BLOCKSTART	  1201		/*	^K^B	F7					*/
# define	XC_BLOCKEND 	  1202		/*	^K^K	F8					*/
# define	XC_BLOCKWORD	  1203		/*	^K^T						*/
# define	XC_BLOCKLINE	  1204		/*	^K^L	F6					*/
# define	XC_BLOCKHIDE	  1205		/*	^K^H						*/
# define	XC_BLOCKCOPY	  1206		/*	^K^C						*/
# define	XC_BLOCKMOVE 	  1207		/*	^K^V						*/
# define	XC_BLOCKDEL  	  1208		/*	^K^Y						*/
# define	XC_BLOCKREAD 	  1209		/*	^K^R						*/
# define	XC_BLOCKWRITE	  1210		/*	^K^W						*/
# define	XC_BLOCKSAVE	  1211		/*	^K^O						*/
# define	XC_BLOCKPASTE	  1212		/*	^K^I						*/

# define	XC_FINDSTART	  1221		/*	^Q^B						*/
# define	XC_FINDEND		  1222		/*	^Q^K						*/

# define	XC_FINDTEXT		  1301		/*	^Q^F	F4					*/
# define	XC_FINDNEXT		  1302		/*	^L		F5					*/
# define	XC_CHANGETEXT	  1303		/*	^Q^A						*/

# define	XC_HELP			  1401		/*	^O^H	F1					*/
# define	XC_INFO			  1402		/*	^O^I						*/

# define	XC_TABSIZE		  1501		/*	^O^T	Alt Tab				*/
# define	XC_SHELL		  1502		/*	^O^S						*/
# define	XC_REFRESH		  1503		/*	^O^P						*/
# define	XC_RELOADIT		  1504		/*	^O^L						*/
# define	XC_WHICHCOL		  1505		/*	^O^C						*/
# define	XC_DUPLINE		  1506		/*	^O^D						*/
# define	XC_POPOPTIMIO	  1507		/*	^O^O						*/
# define	XC_POPSCROLL	  1508		/*	^O^R						*/
# define	XC_PAGSIZE		  1509		/*	^O^G						*/
# define	XC_PAGWID		  1510		/*	^O^W						*/
# define	XC_RUNCMD		  1511		/*	^O^X						*/

# define	XC_GOTOLINE		  1531		/*	^Q^L						*/
# define	XC_LASTLINE		  1532		/*	^Q^P						*/
# define	XC_UNDOLINE		  1533		/*	^Q^U						*/

# define	XC_NEWLINE		  1601		/*	^M		Enter				*/
# define	XC_OPENLINE		  1602		/*	^N							*/
# define	XC_JOINLINE		  1603		/*	^Q^G						*/

# define	XC_TAB			  1611		/*	^I		Tab					*/
# define	XC_BACKTAB		  1612		/*	Shift^I	Shift Tab			*/
# define	XC_BACKSPACE	  1613		/*	^H		Bs					*/

# define	XC_FORECOLOR	  1951		/*	  		Shift_F9			*/
# define	XC_BACKCOLOR	  1952		/*	  		Shift_F10			*/

# define	XC_ESC			  1998		/*			Esc					*/
# define	XC_BAD			  1999		/*	^?							*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	XC_VIEWDIR		XC_QUITEDIT	/*	F3							*/
# define	XC_VIEWLIST		XC_FINDTEXT	/*	F4							*/
# define	XC_VIEWSTACK	XC_FINDNEXT	/*	F5							*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int				readcmd		OF ( (void)									) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDCMD_H */

