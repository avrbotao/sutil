
/*		 _______________________________________________________________
 *		|																|
 *		|	stdlogic.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDLOGIC_H

# define _STDLOGIC_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	XOR(A,B)	( ( (! (A)) && (B) ) || ( (! (B)) && (A) ) )

# define	SETBIT(V,B)		V |= B

# ifndef	FALSE
#	define	FALSE		(0)
# endif  /* FALSE */

# ifndef	TRUE
# define	TRUE		(-1)
# endif  /* TRUE */

# define	AND			&&
# define	OR			||
# define	NOT			!

# define	EQL			==
# define	NEQ			!=
# define	LEQ			<=
# define	GEQ			>=
# define	LST			<
# define	GRT			>

# define	EQ			==
# define	NE			!=
# define	LE			<=
# define	GE			>=
# define	LT			<
# define	GT			>

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDLOGIC_H */

