
/*		 _______________________________________________________________
 *		|																|
 *		|	stdfile.h						 (c) 2000 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDFILE_H

# define _STDFILE_H

/* # include "fnvx.h" */

extern ubit64 gcrc64r ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int				fcopy		OF ( (FILE *, FILE *, ULONG, int)			) ;
int				copyfile	OF ( (char *, char *, int)					) ;
ULONG			crcfile		OF ( (char *, int)							) ;
ubit64			crc64file	OF ( (char *, int)							) ;
int				renfile		OF ( (char *, char *)						) ;
int				touchfile	OF ( (char *, ULONG)						) ;
int				wipefile	OF ( (char *, int, int)						) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDFILE_H */

/*
 * vi:tabstop=4
 */
