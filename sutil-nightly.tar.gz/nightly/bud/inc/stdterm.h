/*		 _______________________________________________________________
 *		|																|
 *		|	stdterm.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDTERM_H

# define _STDTERM_H

extern int terminal , termisok , colorok , colortype ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int		terminit	OF ( ( void )							) ;
int		termend		OF ( ( void )							) ;
int		initmode	OF ( ( void )							) ;
int		initcaps	OF ( ( void )							) ;
int		initkeys	OF ( ( void )							) ;
int		readkeys	OF ( ( void )							) ;

int		loadinfo	OF ( ( char * , char * )				) ;
int		saveinfo	OF ( ( char * , char * )				) ;
int		initinfo	OF ( ( void )							) ;
int		endinfo		OF ( ( void )							) ;
void	freeinfo	OF ( ( void )							) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDTERM_H */

/*
 * vi:ts=4
 */
