	"\n",
	"  -E : informa o ambiente \n",
	"  -L : informa a licenca \n",
	"  -V : informa a versao \n",
	"  -? : informa a sintaxe \n\n",

