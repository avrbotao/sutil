
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdstr.c						string tricks	|
 *		\ \/ /		|	(c) 1998				alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# include "configure.h"

# ifdef AIX71
#include <sys/types.h>
typedef uint_t          rid_t;          /* role ID */
# endif /* AIX71 */

# ifdef LABIX

# define	USE_MATH
# define	USE_ERRNO
# define	USE_CTYPE
# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDASC
# define	USE_STDMEM
# define	USE_STDSTR

# include	"abc.h"

# else /* PLAIN */

# include	"abc.h"

# include  <math.h>
# include  <ctype.h>
# include  <stdio.h>
# include  <errno.h>
# include  <stdlib.h>

# include  "stdasc.h"
# include  "stdmem.h"
# include  "stdstr.h"

# endif /* LABIX */

/*		 ___________________________________________________________________
 *		|																	|
 *		|	flip case IN PLACE ! ...										|
 *		|___________________________________________________________________|
 */

void lowstr (buf) char * buf ; {

	register char * bp ;

	for ( bp = buf ; *bp ; ++bp )
		if (*bp >= 'A' && *bp <= 'Z')
			*bp += ' ' ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void uprstr (buf) char * buf ; {

	register char * bp ;

	for ( bp = buf ; *bp ; ++bp )
		if (*bp >= 'a' && *bp <= 'z')
			*bp -= ' ' ;
}

/*		 ___________________________________________________________________
 *		|																	|
 *		|	flip case ON STATIC BUFFER ! ...								|
 *		|___________________________________________________________________|
 */

# ifdef ANYX

char * strlwr (buf) char * buf ; {

	static char new [ 512 ] ;
	register char * bp ;
	register char * np = new ;

	for ( bp = buf ; *bp ; ++bp, ++np )
		if (*bp >= 'A' && *bp <= 'Z')
			*np = *bp + ' ' ;
		else
			*np = *bp ;

	*np = '\0' ;
	return new ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * strupr (buf) char * buf ; {

	static char new [ 512 ] ;
	register char * bp ;
	register char * np = new ;

	for ( bp = buf ; *bp ; ++bp, ++np )
		if (*bp >= 'a' && *bp <= 'z')
			*np = *bp - ' ' ;
		else
			*np = *bp ;

	*np = '\0' ;
	return new ;
}

# endif /* ANYX */

/*		 ___________________________________________________________________
 *		|																	|
 *		|	replace chars IN PLACE ...										|
 *		|___________________________________________________________________|
 */

void strchg (buf, from, to) char * buf ; int from , to ; {

	register char * bp = buf ;

	for ( ; *bp ; ++bp )
		if (*bp == from)
			*bp = to ;
}

void strnchg (buf, from, to, siz) char * buf ; int from , to , siz ; {

	register char * bp = buf ;

	for ( ; siz-- > 0 ; ++bp )
		if (*bp == from)
			*bp = to ;
}

/*		 ___________________________________________________________________
 *		|																	|
 *		|	slice a (nul-ended) string of (blank-or-tab-separated) tokens	|
 *		|___________________________________________________________________|
 */

int strchop (tp, ap) char * tp , * * ap ; {

	register int sk = 0 ;

	for (EVER) {

		while (*tp == ' ' || *tp == '\t')
			++tp ;

		if ( *tp == '\0' /* || *tp == '\n' || *tp == '\r' */ )
			break ;

		*ap++ = tp ; ++sk ;

		while ( *tp && *tp != ' ' && *tp != '\t' /* &~=CR|LF */ )
			++tp ;

		if (*tp)
			*tp++ = '\0' ;
	}

	return sk ;
}

/*		 ___________________________________________________________________
 *		|																	|
 *		|	padding ( in place & on static ) ...							|
 *		|___________________________________________________________________|
 */

void padstr (buf, len, byt) char * buf ; int len , byt ; {

	register int    sz = len ;
	register char * bp = buf ;

	while (*bp != NUL && sz > 0) {
		--sz ;
		++bp ;
	}

	while (sz-- > 0)
		*bp++ = byt ;

	*bp = NUL ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * strpad (buf, len, byt) char * buf ; int len , byt ; {

	static char tb [512] ;
	register int    sz = len ;
	register char * bp = buf ;
	register char * tp = tb ;

	while (*bp != NUL && sz > 0) {
		--sz ;
		*tp++ = *bp++ ;
	}

	while (sz-- > 0)
		*tp++ = byt ;

	*tp = NUL ;
	return tb ;
}

/*		 ___________________________________________________________________
 *		|																	|
 *		|	...																|
 *		|___________________________________________________________________|
 */

int strfmt (buf, fmt) char * buf , * fmt ; {

	register	char *	sp = fmt ;
	register	char *	pp = (char *) &fmt ;
	register	char *	bp = buf ;

				char    vc ;
				long	vl ;
				int     vi ;
				short   vs ;
# ifdef XFP_FMT
				float   vf ;
				double  vd ;
# endif
				char *  va ;

	pp += sizeof (char *) ;

	while ( *sp ) {

		if ( *sp == '%' ) {

			switch ( *++sp ) {

				case 'c' :
					vc = (char) *((int *) pp) ;
					pp += sizeof (int) ;
# ifdef DEBUG
					printf ("char=='%c'\n", vc) ;
# endif
					*bp++ = vc ;
				break ;

				case 'd' :
					vi = (int) *((int *) pp) ;
					pp += sizeof (int) ;
# ifdef DEBUG
					printf ("int==(%d)\n", vi) ;
# endif
					sprintf (bp, "%d", vi) ;
					while (*bp)
						++bp ;
				break ;

				case 'D' :
					vl = (long) *((long *) pp) ;
					pp += sizeof (long) ;
# ifdef DEBUG
					printf ("long==(%ld)\n", vl) ;
# endif
					sprintf (bp, "%ld", vl) ;
					while (*bp)
						++bp ;
				break ;

				case 'h' :
					vs = (short) *((int *) pp) ;
					pp += sizeof (int) ;
# ifdef DEBUG
					printf ("short==(%d)\n", vs) ;
# endif
					sprintf (bp, "%d", vs) ;
					while (*bp)
						++bp ;
				break ;

# ifdef XFP_FMT

				case 'f' :
					vf = (float) *((double *) pp) ;
					pp += sizeof (double) ;
# ifdef DEBUG
					printf ("float==(%g)\n", vf) ;
# endif
					sprintf (bp, "%g", vf) ;
					while (*bp)
						++bp ;
				break ;

				case 'F' :
					vd = (double) *((double *) pp) ;
					pp += sizeof (double) ;
# ifdef DEBUG
					printf ("double==(%lf)\n", vd) ;
# endif
					sprintf (bp, "%g", vd) ;
					while (*bp)
						++bp ;
				break ;

# endif /* XFP_FMT */

				case 's' :
					va = (char *) *((char **) pp) ;
					pp += sizeof (char *) ;
# ifdef DEBUG
					printf ("string==[%s]\n", va) ;
# endif
					strcpy (bp, va) ;
					bp += strlen (va) ;
				break ;

			} /* e-o-switch (*++sp) */

		} else /* *sp != '%' */ {

			*bp++ = *sp ;
		}

		sp++ ;

	} /* e-o-while (*sp) */

	*bp = '\0' ;

	return (int) ( bp - buf ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int streq (a, b) char * a , * b ; {

	return strcmp (a, b) == 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * struniq (s, c) char * s ; int c ; {

	register char * old = s , * np , * new = xmalloc (strlen (s)) ;

	if ( new == NULL )
		return NULL ;

	np = new ;

	while ( *old ) {

		if ( *old == c ) {

			for ( *new++ = c ; *old == c ; ++old )
				;

		} else {

			*new++ = *old++ ;
		}
	}

	*new = '\0' ;
	strcpy (s, np) ;
	xmfree (np) ;

	return s ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * trimstr (s, n) char * s ; int n ; {	/* trim s in place at n	*/
	register char * p = s ;
	if ( p == NULL )
		return NULL ;
	while ( *p != '\0' && --n >= 0 )
		++p ;
	if ( *p != '\0' )
		*p = '\0' ;
	return s ;
}

char * strtrim (s, c) char * s ; int c ; {

	register char * old = s , * np , * new = xmalloc (strlen (s)) ;

	if ( new == NULL )
		return NULL ;

	np = new ;

	while ( *old ) {
		if ( *old != c )
			*new++ = *old ;
		++old ;
	}

	*new = '\0' ;
	strcpy (s, np) ;
	xmfree (np) ;

	return s ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

int strclip (tp, ap, dl) char * tp , * * ap ; int dl ; {

	register int sk = 0 ;

	for (EVER) {

		if ( *tp == '\0' )
			break ;

		*ap++ = tp ; ++sk ;

		while ( *tp && *tp != dl )
			++tp ;

		if (*tp)
			*tp++ = '\0' ;
	}

	return sk ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * stripeol (buf) char * buf ; {

# ifdef SLOW

	register char * tp ;

	if ( ( tp = strrchr (buf, '\n') ) != NULL )
		*tp = '\0' ;

	if ( ( tp = strrchr (buf, '\r') ) != NULL )
		*tp = '\0' ;

# else  /* FAST */

	register int len = strlen (buf) ;

	while ( ( buf [ len - 1 ] == CR ) ||
			( buf [ len - 1 ] == LF )    )
		buf [ --len ] = NUL ;

# endif

	return buf ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * strerr (n) int n ; {

# ifdef STRERROR

	return strerror (n) ;

# else

	return sys_errlist [n] ;

# endif

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * strclone (s) char * s ; {

	register char * p = xmalloc (1 + strlen (s)) ;

	if (p == NULL)
		return ("NO MEMORY") ;

	strcpy (p, s) ;
	return p ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef NOSTRSTR

char * strstr (where, what) char * where , * what ; {

	register char * wep = where ;
	register char * wee = wep+(strlen (where)-strlen (what)) ;

	while (wep <= wee) {
		if (strcmp (wep, what) == 0)
			return wep ;
		++wep ;
	}

	return NULL ;
}

# endif /* NOSTRSTR */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

char * stristr (where, what) char * where , * what ; {

	register char * wep = where ;
	register char * wee = wep+(strlen (where)-strlen (what)) ;

	while (wep <= wee) {
		if (stricmp (wep, what) == 0)
			return wep ;
		++wep ;
	}
	return (char *) 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef NOSTRICMP

int stricmp (a, b)
# ifdef CYGWIN
	const
# endif /* CYGWIN */
	char * a , * b ;
{

	register char * pa = (char *) a , * pb = (char *) b ;
	register int x ;

	for ( ; ; ) {

		x = toupper ((int)*pa) - toupper ((int)*pb) ;

		if (x)
			return x ;

		if ( *pa == '\0' )
			return 0 ;

		++pa ; ++pb ;
	}
}

# endif /* NOSTRICMP */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef PADSLIESC

void padbuf (buf, len, byt) char * buf ; int len , byt ; {

	register int    sz = len ;
	register char * bp = buf ;

	while (*bp != NUL && sz > 0) {
		--sz ;
		++bp ;
	}

	while (sz-- > 0)
		*bp++ = byt ;

	*bp = NUL ;
}

int strslic (tp, ap) char * tp , * * ap ; {
	REG int sk = 0 ;

	for (EVER) {
		while (*tp == ' ' || *tp == '\t')
			{ ++tp ; }
		if ( *tp == '\0' /* || *tp == '\n' || *tp == '\r' */ )
			break ;
		*ap++ = tp ; ++sk ;
		while ( *tp && *tp != ' ' && *tp != '\t' /* &~=CR|LF */ )
			{ ++tp ; }
		if (*tp)
			{ *tp++ = '\0' ; }
	}
	return (sk) ;
}

/* stresc by bud a.r.r.w.f. */

# include <ctype.h>

STR stresc (buf) STR buf ; {
	REG STR  mp = buf ;
	REG STR  rp = mp ;
	REG char od ;
	REG char nd ;

	while (*mp) {
		if (*mp == BACKSLASH)
			switch (*++mp) {
				case LC_A : *rp = BELL ; break ;
				case LC_B : *rp = BS   ; break ;
				case LC_E : *rp = ESC  ; break ;
				case LC_F : *rp = FF   ; break ;
				case LC_N : *rp = NL   ; break ;
				case LC_R : *rp = CR   ; break ;
				case LC_S : *rp = SP   ; break ;
				case LC_T : *rp = TAB  ; break ;
				case LC_V : *rp = VT   ; break ;
				case VANE : *rp = VANE ; break ;
				default :
					if (isupper (*mp)) {
						*rp = *mp - AT ;
					} else {
						if (isdigit (*mp)) {
							for ( od = 0 , nd = 1 ; isdigit (*mp) && nd <= 3 ; ++mp , ++nd )
								od = (od << 3) + (*mp - ZERO) ;
							*rp = od ;
							--mp ;
						} else {
							*rp = *mp ;
						}
					}
				break ;
			}
		else
			*rp = *mp ;
		++mp ; ++rp ;
	}
	*rp = NUL ;
	return (buf) ;
}

/* escstr by bud a.r.r.w.f. */

STR escstr (buf) STR buf ; {
	FIX char war [80] ;
	REG STR bp = buf ;
	REG STR wp = war ;

	for ( ; *bp ; ++bp )
		if (*bp >= SP && *bp <= TILDE)
			*wp++ = *bp ;
		else {
			sprintf (wp, "\\%03o", *bp) ;
			wp += 4 ;
		}
	*wp = NUL ;
	return (war) ;
}

# endif /* PADSLIESC */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef XVAFMT

/*
 *								*===========================*
 *								*	strfmt.c				*
 *								*===========================*
 */

# include <stdio.h>

int strfmt (char *, char *, ...) ;

int main () {

	char	xc = '@' ;
	int		xi = 11111 ;
	long	xl = 999999L ;
	char *	xa = "varargs" ;

	char	buf [80] ;

	strfmt (buf, "a=(%s) i=(%d) c=(%c) l=(%D)", xa, xi, xc, xl) ;

	puts (buf) ;
}

/*
 *								*===========================*
 *								*	xva.c					*
 *								*===========================*
 */

# include <stdio.h>

void va (char *, ...) ;

int main () {

# ifdef FULLTEST

	va ("icldsaflcsdia",
		(int) -22222,
		(char) 97,
		(long) -123456789L,
		(double) -123456.7890123E-3,
		(short) -11111,
		(char *) "varargs",
		(float) -1934.5678e-2,
		(long) 987654321L,
		(char) 'X',
		(short) 13333,
		(double) 12.3456789,
		(int) 32222,
		(char *) "enough"
	) ;

# else  /* PLAINTEST */

	char	xc = '@' ;
	int		xi = 11111 ;
	char *	xa = "varargs" ;

	va ("aic", xa, xi, xc) ;

# endif /* FULL x PLAIN */

}

/* va.c */

void va (s) char * s ; {

	register char * sp = s ;
	register char * pp = (char *) &s ;
	char    vc ;
	long	vl ;
	int     vi ;
	short   vs ;
	float   vf ;
	double  vd ;
	char *  va ;

	pp += sizeof (char *) ;

	while (*sp) {

		switch (*sp) {

			case 'c' :
				vc = (char) *((int *) pp) ;
				pp += sizeof (int) ;
printf ("char=='%c'\n", vc) ;
			break ;

			case 'i' :
				vi = (int) *((int *) pp) ;
				pp += sizeof (int) ;
printf ("int==(%d)\n", vi) ;
			break ;

			case 'l' :
				vl = (long) *((long *) pp) ;
				pp += sizeof (long) ;
printf ("int==(%ld)\n", vl) ;
			break ;

                        case 's' :
                                vs = (short) *((int *) pp) ;
                                pp += sizeof (int) ;
printf ("short==(%d)\n", vs) ;
                        break ;

                        case 'f' :
                                vf = (float) *((double *) pp) ;
                                pp += sizeof (double) ;
printf ("float==(%g)\n", vf) ;
                        break ;

                        case 'd' :
                                vd = (double) *((double *) pp) ;
                                pp += sizeof (double) ;
printf ("double==(%lf)\n", vd) ;
                        break ;

                        case 'a' :
                                va = (char *) *((char **) pp) ;
                                pp += sizeof (char *) ;
printf ("address==[%s]\n", va) ;
                        break ;
                }
                sp++ ;
        }
}

# endif /* XVAFMT */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

/*
 * vi:nu tabstop=4
 */
