
/*		 _______________________________________________________________
 *		|																|
 *		|	stdmatch.c						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# define        USE_SYSTYPES
# define	USE_STDIO

# define	USE_STDSTR
# define	USE_STDMATCH
# define	USE_STDLOGIC
# define	USE_STDTYP

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int isaregexp (txt) char * txt ; {

	static		char *	wilds = WILDCHARLIST ;
	register	char *	tp ;
	register	int		found = FALSE ;

	for ( tp = wilds ; *tp ; ++tp )
		if ( strchr ( txt , *tp ) != NULL )
			found = TRUE ;

	return found ;
}

/************************************************************************
*	text pattern matching with minimal wildcard treatment				*
************************************************************************/

# ifdef DOSPATMAT

# define  FASTSCAN
# define  FULLBLOW

int patmat (t, p) char * t , * p ; {

	REG char * x ;

	for ( ; *p ; ++p ) {

		switch (*p) {

			case '*' :

				x = p + 1 ;

# ifdef   FASTSCAN

				starloop:

					if (*t == *x)
						continue ;

					if (*++t)
						goto starloop ;

				if (*x)
					return (FALSE) ;

				return (TRUE) ;

# else    /* FASTSCAN */

				if (*x == NUL)
					return (FALSE) ;

				while (*t) {

					if (*t == *x)
						break ;

					++t ;
				}

				if (*t == NUL)
					return (FALSE) ;
				else
					continue ;

# endif   /* FASTSCAN */

			case '?' :
				if (*t == NUL)
					return (FALSE) ;
			break ;

# ifdef   FULLBLOW

			case '\\' :
				++p ;
				goto it ;

			case '$' :
				if (*t == NUL)
					return (TRUE) ;

				return (FALSE) ;

# endif   /* FULLBLOW */

			default :
it :
				if (*p != *t)
					return (FALSE) ;
			break ;
		}

		++t ;
	}

	if (*t)
		return (FALSE) ;

	return (TRUE) ;
}

# else  /* UNIXPATMAT */

/*		+-------------------------------------------------------+
 *		|	pattern matching (unix style) + full blow ...		|
 *		+-------------------------------------------------------+
 */

#undef	DEBUG

int patmat (sp, pp) REG char * sp, * pp ; {

	REG short	sc,	/* Caracter da Cadeia */
				pc;	/* Caracter do Padrao */

	short		found,	/* Encontrou o Char. na lista */
				not;	/* Foi visto um '~' */

#ifdef	DEBUG
	printf ("DBG: str = '%s', pdr = '%s'\n", sp, pp);
#endif	/* DEBUG */

	/*
	 *	O Padrao pode conter '?', '*', '[....]', '~c', '~[....]'.
	 *	O Caracter '\' desfaz a acao especial dos caracteres
	 *	acima. A Comparacao e' do estilo do "sh", mas
	 *	o caracter '/' e' reconhecido por '?' e '*'.
	 *
	 *	Devolve:
	 *		TRUE  =>	A Cadeia foi Reconhecida.
	 *		FALSE =>	Nao foi Reconhecida, ou
	 *					o Padrao contem um erro de Sintaxe.
	 */

	not = 0;

	/*
	 *	Malha Principal de Comparacao.
	 */

	for ( ; ; sp++, pp++) {

		switch ( pc = pp[0] ) {

		    default:
						/*
						 *	O Padrao contem um caracter Normal ...
						 *	( diferente de '?', '*', '[', '~' e '\0' )
						 */

				if (pc == sp[0])
					continue;
				else
					return FALSE ;

		    case '\0':
						/*
						 *	O Padrao Acabou.
						 *	Atualmente implementa um reconhecimento exato
						 *	(ok se a string tambem acabou). idealmente
						 *	deveria retornar TRUE e deixar o teste de
						 *	fim da string p/ o coringa '$' ...
						 */
/* # define IDEAL */

# ifdef IDEAL

				return TRUE ;

# else  /* EXACT */

				if (sp[0] == '\0')
					return TRUE ;
				else
					return FALSE ;

# endif /* IDEAL */

		    case '?':

				if (sp[0] == '\0')
					return FALSE ;

						/*
						 *	Simula como se o "coringa" '?' fosse
						 *	igual ao caracter da cadeia.
						 */

				continue;

		    case '*':

				if ((++pp)[0] == '\0')
					return TRUE ;

						/*
						 *	Procura Sufixos em comum.
						 */

				while (sp[0] != '\0') {

					if (patmat (sp++, pp))
						return TRUE ;
				}

				return FALSE ;

		    case '\\':

						/*
						 *	Trata o caracter seguinte como normal.
						 */
				pp++;

				if ((pc = pp[0]) == '\0')
					return FALSE ;

				if ((sc = sp[0]) == '\0' || sc != pc)
					return FALSE ;

				continue;

		    case '~':

				pp++;

				if ((pc = pp[0]) == '\0')
					return FALSE ;

				if (pc != '[') {

					/*
					 *	Comparacao inversa.
					 */

					if ((sc = sp[0]) == '\0' || sc == pc)
						return FALSE ;

					continue;
				}

				/*
				 *	pp[0] == '['.
				 *	Prepara para [....] inverso.
				 */

				not = 1;

# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
				/* Cai atraves */

		    case '[':

				found = 0;

				if ((sc = sp[0]) == '\0')
					return FALSE ;

				/*
				 *	Analisa a Sequencia '[....]'.
				 */

				while ((pc = (++pp)[0]) != '\0') {

					switch (pc) {

						default:

							if (pc == sc)
								found = 1;
							continue;

						case '-':

							if (pp[-1] == '[' || pp[1] == ']') {

								if (sc == '-')
									found = 1;

							} else {

								if (pp[-1] <= sc && sc <= pp[1])
									found = 1;
							}

							continue;

						case ']':

							if (found != not)
								goto nextchar;
							else
								return FALSE ;

					}	/* end switch (pc) */

				}	/* end while (...) */

		}	/* end switch */

		/*
		 *	A Sequencia [....] terminou inesperadamente,
		 *	ou em todos os casos.
		 */

		return FALSE ;

nextchar:

		not = 0;

	}	/* end malha principal de comparacao */

}	/* end patmat */

# endif /* PATMAT (DOS x UNIX) */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
