
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_UNISTD

# define	USE_STDLOGIC
# define	USE_STDTIO
# define	USE_STDTERM
# define	USE_STRLIST
# define	USE_STDBOX
# define	USE_STDCAP
# define	USE_STDTYP
# define	USE_STDMISC
# define	USE_STDCOLOR

# include	"abc.h"

int				termisok  = TRUE ;
int				terminal  = FALSE ;
int				colorok   = FALSE ;
int				colortype = CT_ANSI ;

extern int		vfd ;

# ifdef		ANYX

extern TERMIO	origterm ;

# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int terminit () {

# ifdef		ANYX

	int rd ;

	termisok = FALSE ;

	if ( ( rd = initmode () ) != 0 )
		return 10 * rd ;

	if ( ( rd = initcaps () ) != 0 )
		return 20 * rd ;

/*
 *	*********************************************************************
 *	**	ALERT ! initinfo() was ORIGINALLY HERE (in case of crap) ...   **
 *	*********************************************************************
 */

	if ( ( rd = initinfo () ) != 0 )
		return 30 * rd ;

	if ( ( rd = readcaps () ) != 0 )
		return 40 * rd ;

	if ( ( rd = initkeys () ) != 0 )
		return 50 * rd ;

# ifdef NOCRAP
	if ( ( rd = initinfo () ) != 0 )
		return 60 * rd ;
# endif /* NOCRAP */

	if ( ( rd = initbox () ) != 0 )
		return 70 * rd ;

	terminal = TRUE ;

# endif

# ifdef VRAMCOLOR

	_colorbits = _vramcolors ;

# else  /* TERMCOLOR */

	if (terminal)
		_colorbits = _ansicolors ;
	else
		_colorbits = _vramcolors ;

# endif /* VRAMCOLOR */

	initcolor ( _WHITE , _BLUE , _YELLOW , _GREEN ) ;

	termisok = TRUE ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int termend () {

	int rd = 0 ;

# ifdef		ANYX

	endcolor () ;	/* RESET DEFALUT COLORS !!! */
	endcaps () ;

	if (vfd < 0)
		return -1 ;

	rd += endinfo () ;
	rd += resetmode (&origterm) ;
	close (vfd) ;

# endif

	return rd ;
}

# ifdef		ANYX

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	TINAME		"terminfo.ctl"

FILE * tifp = NULL ;

STRLISTCTRL * tinfos = NULL ;

char tiname [1024] ;

int initinfo () {

	register char * tp ;
	register int rd ;

# ifdef OLDORIG
	tinfos = alocstrlist ("tinfos", DFL_MAXSTRLSTSIZ) ;
# else
	tinfos = makestrlist ("tinfos", DFL_MAXSTRLSTSIZ) ;
# endif

	if (tinfos == NULL)
		return -1 ;

	tp = getenv ("HOME") ;

	if (tp == NULL)
		tp = "." ;

	sprintf (tiname, "%s/.xed/%s", tp, TINAME) ;

	if ( ( tifp = fopen (tiname, "r") ) == NULL )
		return -2 ;

	rd = fgetstrlist (tifp, &tinfos) ;

	fclose (tifp) ;
	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void freeinfo () {

	if (tinfos == NULL)
		return ;

	freestrlist (tinfos) ;
	tinfos = NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int endinfo () {

	register int rd ;

	if (tinfos == NULL)
		return -1 ;

	if ( ( tifp = fopen (tiname, "w") ) == NULL )
		return -2 ;

	rd = fputstrlist (tifp, tinfos) ;

	fclose (tifp) ;

	freeinfo () ;

	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int saveinfo (name, sign) char * name , * sign ; {

	register int rd ;
	char mb [256] ;
	char tb [2048] ;

	pickstrlist (tinfos) ;

	sprintf (mb, "%-15s %-15s ", termname() , name ) ;
	sprintf (tb, "%-15s %-15s %s", termname() , name , bintos (sign) ) ;

	if ( ( rd = findstrlist (mb) ) != -1 )
		killstrlist (rd) ;

	feedstrlist (tb) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int loadinfo (name, sign) char * name , * sign ; {

	register int rd ;
	char mb [256] ;
	char tb [2048] ;

	pickstrlist (tinfos) ;

	sprintf (mb, "%-15s %-15s ", termname() , name ) ;

	if ( ( rd = findstrlist (mb) ) == -1 )
		return -1 ;

	peekstrlist (tb, rd) ;
	sscanf (tb, " %s %s %s", mb, mb, sign) ;
	stobin (sign) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* ANYX */

/*
 * vi:nu tabstop=4
 */
