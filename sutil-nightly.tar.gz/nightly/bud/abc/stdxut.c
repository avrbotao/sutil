
/*
 *          |          _                    |~~~~~~~~~~~~~~~~~~~~~~~|
 *          |\       _/ \_                  |    Alexandre Botao    |
 *          | \_    /_    \_                |     www.botao.org     |
 *          \   \__/  \__   \               |   +55-11-98244-UNIX   |
 *           \_    \__/  \_  \              |   +55-11-9933-LINUX   |
 *             \_   _/     \ |              |     botao@linux.sh    |
 *               \_/        \|              |  alexandre@botao.org  |
 *                           |              |_______________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# include	<stdio.h>
# include	<unistd.h>

# include	<sys/stat.h>
# include	<sys/types.h>

# include	"abc.h"
# include	"stdxut.h"

int			currpathmode		=	DFL_CURRPATHMODE ;

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	xut.c						  extra utilities	|
 *		\ \/ /		|	(c) 1995-2020			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

int createdir (name, mode) char * name ; int mode ; {

	int rd = -1 ;

	if ( name == NULL ) {
		return rd ;
	}

# ifdef POSIX_MKDIR
	rd = mkdir (name, mode) ;
# endif /* POSIX_MKDIR */

# ifdef C_MKDIR
	rd = mkdir (name) ;
# endif /* C_MKDIR */

/*
	if ( rd != 0 ) {
		error ("mkdir", name) ;
	}
*/

	return rd ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

char makpthdirnam [MAKEPATHBUFFSIZE] ;

int createpath (name, mode) char * name ; int mode ; {

	register char * np ;
	register char * dp ;

	if ( name == NULL ) {
		return -1 ;
	}

	np = name ;
	dp = makpthdirnam ;

	if ( *np == DIRSEP ) {
		*dp++ = *np++ ;
	}

	for ( ; ; ) {

		while ( *np != '\0' && *np != DIRSEP ) {
			*dp++ = *np++ ;
		}

		*dp = '\0' ;

		if ( access (makpthdirnam, 0) == -1 ) {
			if ( createdir (makpthdirnam, mode) < 0 ) {
				/* error ("mkpath", makpthdirnam) ; */
				return -1 ;
			}
		}

		if ( *np == '\0' ) {
			return 0 ;
		} else {
			*dp++ = *np++ ;
		}
	}
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

/*
 * vi:nu ts=4
 */
