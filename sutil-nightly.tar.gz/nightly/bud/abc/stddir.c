
/*		 _______________________________________________________________
 *		|																|
 *		|	stddir.c						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_SYSTYPES

# define	USE_STDDIR
# define	USE_STDTYP
# define	USE_STDMISC
# define	USE_STDMEM

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

DIRDES * setdirent (name) char * name ; {

	return OpenDir (name) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * getdirsel (dirdesptr, flags) DIRDES * dirdesptr ; int flags ; {

	register DIRENT * dep ;
	register char * np ;

try :

	if ( ( dep = ReadDir (dirdesptr) ) != NULL ) {
		np = dep->d_name ;

		if ( flags & DS_NODOTDIRS )
			if ( dotdir ( np ) )
				goto try ;

		return np ;
	} else
		return NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * getdirent (dirdesptr) DIRDES * dirdesptr ; {

	register DIRENT * dep ;

try :

	if ( ( dep = ReadDir (dirdesptr) ) != NULL ) {

		if ( dotdir ( dep->d_name ) )
			goto try ;

		return dep->d_name ;
	} else
		return NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int enddirent (dirdesptr) DIRDES * dirdesptr ; {

	return CloseDir (dirdesptr) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

DIRDES * OpenDir (name) char * name ; {

# ifdef DOS

	DIRDES * ddp ;
	int rd ;
	char tb [1024] ;

	/* alloc a DIRDES */

	ddp = (DIRDES *) xmalloc ( sizeof (DIRDES) ) ;

	if ( ddp == NULL )
		return ddp ;

	/* name exists ? is a dir ? */

	rd = findfirst (name, &(ddp->ffdat), FA_DIREC) ;

	if (rd != 0) {		/* no */
		xmfree ( (char *) ddp ) ;
		return NULL ;
	}

	sprintf (tb, "%s\\*.*", name) ;

	ddp->dirct = findfirst (tb, &(ddp->ffdat), FA_MASK) ;

	return ddp ;		/* yes */

# endif /* DOS */

# ifdef WIN32

	DIRDES * ddp ;
	long hndl ;
	char tb [1024] ;

	/* alloc a DIRDES */

	ddp = (DIRDES *) xmalloc ( sizeof (DIRDES) ) ;

	if ( ddp == NULL )
		return ddp ;

	/* name exists ? */

	hndl = _findfirsti64 (name, &(ddp->ffdat)) ;

	if ( hndl == -1 ) { /* no */
		xmfree ( (char *) ddp ) ;
		return NULL ;
	}

	/* is a dir ? */

	if ( ddp->ffdat.attrib & _A_SUBDIR ) { /* yes */

		/* prep 4 scan */

		sprintf (tb, "%s\\*.*", name) ;

		ddp->dirct = 0 ;
		ddp->hndl = _findfirsti64 (tb, &(ddp->ffdat)) ;

		return ddp ;

	} else { /* no */

		xmfree ( (char *) ddp ) ;
		return NULL ;

	}

# endif /* WIN32 */

# ifdef	ANYX

#	ifdef V7DIR

#	else  /* SYS V DIR */

	return opendir (name) ;

#	endif /* V7 DIR */

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

DIRENT * ReadDir (dirdesptr) DIRDES * dirdesptr ; {

# ifdef DOS

	int rd ;

	if (dirdesptr->dirct == -1) { /* empty dir */

		return NULL ;

	} else {

		if (dirdesptr->dirct == 0) { /* start 4 non-empty */

			dirdesptr->dirct += 1 ;
			return dirdesptr ;

		} else {

			rd = findnext (&(dirdesptr->ffdat)) ;

			if (rd != 0)
				return NULL ;

			dirdesptr->dirct += 1 ;
			return dirdesptr ;

		}

	}

# endif /* DOS */

# ifdef WIN32

	int rd ;

	if (dirdesptr->hndl == -1) { /* empty dir */

		return NULL ;

	} else {

		if (dirdesptr->dirct == 0) { /* start 4 non-empty */

			dirdesptr->dirct += 1 ;
			return dirdesptr ;

		} else {

			rd = _findnexti64 (dirdesptr->hndl, &(dirdesptr->ffdat)) ;

			if (rd != 0)
				return NULL ;

			dirdesptr->dirct += 1 ;
			return dirdesptr ;

		}

	}

# endif /* WIN32 */

# ifdef ANYX

#	ifdef V7DIR

#	else  /* SYS V DIR */

	return (DIRENT *) readdir (dirdesptr) ;

#	endif /* V7 DIR */

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int CloseDir (dirdesptr) DIRDES * dirdesptr ; {

# ifdef DOS

	xmfree ( (char *) dirdesptr ) ;

	return 0 ;

# endif /* DOS */

# ifdef WIN32

	xmfree ( (char *) dirdesptr ) ;

	return 0 ;

# endif /* WIN32 */

# ifdef ANYX

#	ifdef V7DIR

#	error "version 7 dir deprecated"

#	else  /* SYS V DIR */

	return closedir (dirdesptr) ;

#	endif /* V7 DIR */

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:tabstop=4
 */
