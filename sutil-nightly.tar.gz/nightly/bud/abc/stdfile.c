
/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	stdfile.c						   file stuff	|
 *		\ \/ /		|	(c) 1998				alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_SYSTYPES

# define	USE_ABX
# define	USE_STDAPP
# define	USE_STDCRC
# define	USE_STDTYP
# define	USE_STDSTR
# define	USE_STDMEM
# define	USE_STDSTAT
# define	USE_STDMISC
# define	USE_STDFILE
# define	USE_STDLOGIC

# include	"abc.h"

#ifdef HPUX
# include <unistd.h>
#endif

#ifdef AIX
# include <unistd.h>
#endif

# include <utime.h>

# ifdef WIN32
/* # define DOS */
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	DFL_BINBUFSIZ		 8388608	/* 1048576 15360 */
# define	DFL_ASCBUFSIZ		16777216	/* 2097152 30720 */

FIX		int		binsiz = DFL_BINBUFSIZ ;
FIX		int		ascsiz = DFL_ASCBUFSIZ ;

FIX		char *	binbuf = NULL ;
FIX		char *	ascbuf = NULL ;

ULONG	copycrc = 0L ;

int fcopy (ofp, ifp, usiz, flags) FILE * ofp , * ifp ; ULONG usiz ; int flags ; {

	REG int btt = DFL_BINBUFSIZ ;
	REG int i, j ;
	REG long siz = (long) usiz ;
	FIX int once = TRUE ;
	REG ULONG rescrc = 0 ;
	REG int chkcrc = flags & COPYCRC ;

	if ( once ) {
		once = FALSE ;
		binbuf = xmalloc (binsiz) ;
		ascbuf = xmalloc (ascsiz) ;
	}

	if ( binbuf == NULL || ascbuf == NULL )
		return -1 /* xalert(...) */ ;

	if (chkcrc)
		crcinit () ;

	while (siz > 0) { /* ? >= ? */

		if (siz < DFL_BINBUFSIZ)
			btt = (int) siz ;

		siz -= DFL_BINBUFSIZ ;

# ifdef ZDBG
printf ("usiz %lu siz %ld btt %d\n", usiz, siz, btt) ;
# endif /* ZDBG */

		if (fread (binbuf, btt, 1, ifp) != 1)
			return -2 ;

		if (chkcrc)
			rescrc = crcbuff (binbuf, btt) ;

		if (flags & COPYBIN) {

			if (fwrite (binbuf, btt, 1, ofp) != 1)
				return -3 ;

		} else if (flags & COPYASC) {

			for ( i = j = 0 ; i < btt ; ++i ) {

				if (binbuf[i] == '\r' || binbuf[i] == '\032')
					continue ;
# ifdef DOS
				if (binbuf[i] == '\n')
					ascbuf[j++] = '\r' ;
# endif /* DOS */
				ascbuf[j++] = binbuf[i] ;
			}

			if (fwrite (ascbuf, j, 1, ofp) != 1)
				return -4 ;
		}

	}

	if (chkcrc)
		copycrc = rescrc ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int copyfile (from, to, flags) char * from , * to ; int flags ; {

	FILE * ifp , * ofp ;

	ifp = fopen (from, "r") ;

	if ( flags & 0x0001 /* XF_APPEND */ )
		ofp = fopen (to, "a") ;
	else
		ofp = fopen (to, "w") ;

	/* do the twist ... */

	fclose (ifp) ;
	fclose (ofp) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int renfile (old, new) char * old , * new ; {

# if defined (DOS) || defined (WIN32)

	char tmpold [1024] , tmpnew [1024] ;

	strcpy ( tmpold , old ) ;
	strcpy ( tmpnew , new ) ;

	return rename ( tmpold , tmpnew ) ;

# else  /* ANYX */

	if (link (old, new) < 0)
		return -1 ;

	if (unlink (old) < 0) {
		unlink (new) ;
		return -1 ;
	}

	return 0 ;

# endif /* DOS */

}

/************************************************************************
*	touch file 2 internal time stamp ...								*
*																		*
*	ff_fdate = ((year - 1980) * 512) + (mon * 32) + day					*
*	ff_ftime = (hour * 2048) + (min * 32) + (sec/2)						*
************************************************************************/

# ifdef		DOS
#	include	<stdio.h>
#	include	<io.h>
#	include <dos.h>
# endif

int touchfile (name, ft) char * name ; ULONG ft ; {

# ifdef DOS

	struct date xds ;
	struct time xts ;
	struct ftime xft ;
	int fd ;

	unixtodos (ft, &xds, &xts) ;

	xft.ft_day   = xds.da_day  ;
	xft.ft_month = xds.da_mon  ;
	xft.ft_year  = xds.da_year - 60 ;
	xft.ft_hour  = xts.ti_hour ;
	xft.ft_min   = xts.ti_min  ;
	xft.ft_tsec  = 0 /* xts.ti_sec >> 1 */ ;

/* # define  XDBG */
# ifdef   XDBG
	printf ("%02d/%02d/%04d %02d:%02d:%02d\n",
			xft.ft_day, xft.ft_month, xft.ft_year,
			xft.ft_hour, xft.ft_min, xts.ti_sec ) ;
# endif   /* XDBG */

	if ( ( fd = open ( name , 0 ) ) < 0 )
		return -1 ;

	if (setftime (fd, &xft) == -1) {
		close (fd) ;
		return -1 ;
	}

	close (fd) ;

# endif /* DOS */

# ifdef ANYX

	struct stat x ;
# if defined(HPUX) || defined(SOLARIS) || defined(AIX) || defined(LINUX)
	struct utimbuf y ;
# else
	UTMBUF y ;
# endif

	if (stat (name, &x) < 0)
		y.atime = (time_t) ft ;
	else
		y.atime = x.st_atime ;

	y.mtime = (time_t) ft ;

# ifdef TDBG
printf ("[%s] %s", HDRNAM, ctime (&ft)) ;
# endif /* TDBG */

# if defined(HPUX) || defined(SOLARIS) || defined(AIX) || defined(LINUX)
	if (utime (name, (struct utimbuf *)&y) == -1)
# else
	if (utime (name, (const struct utimbuf *) &y) == -1)
# endif
		return -2 ;

# endif /* ANYX */

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef DOS
# include <mem.h>
# endif

static char * wipebuff = NULL ;

int wipefile (nam, wipelen, wipeval) char * nam ; int wipelen, wipeval ; {

	register int rd ;
	register long wk ;
	register FILE * fp ;

	if ( ( wk = filesize (nam) ) == -1L )
		return xalert (XA_BANAL, "obter o tamanho de", nam, 0) ;

	if (wipebuff == NULL) {
		if ( (wipebuff = (char *) xmalloc (wipelen)) == NULL )
			xalert (XA_FATAL, "alocar", NULL, wipelen) ;
		memset (wipebuff, wipeval, wipelen) ;
	}

	if ((fp = fopen (nam, "r+b")) == (FILE *) 0)
		return xalert (XA_BANAL, "abrir", nam, 0) ;

	fseek (fp, 0L, SEEK_SET) ;

	do {
		if (wk >= wipelen)
			rd = fwrite (wipebuff, wipelen, 1, fp) ;
		else
			rd = fwrite (wipebuff, (int) wk, 1, fp) ;

		if (rd != 1) {
			fclose (fp) ;
			return xalert (XA_BANAL, "limpar", nam, 0) ;
		}

		wk -= wipelen ;
	} while (wk > 0) ;

	fclose (fp) ;
	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

ULONG	crcfile (name, bufsiz) char * name ; int bufsiz ; {

	FILE * fp ;
	char * workbuf ;
	register int bytecount ;
	register ULONG result = 0L ;

	if ( ( fp = fopen (name, "rb") ) == NULL )
		return result ;

	if ( bufsiz <= 0 )
		bufsiz = 16384 ;

	if ( ( workbuf = xmalloc (bufsiz) ) == NULL )
		return result ;

	crcinit () ;

	while ( (bytecount = fread (workbuf, 1, bufsiz, fp)) > 0 )
		result = crcbuff (workbuf, bytecount) ;

	fclose (fp) ;
	xmfree (workbuf) ;
	return result ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/* # define FNVAPI */

# ifdef FNVAPI
# include "fnvx.h"
# define CRC64TYPE Fnv64_t
# endif /* FNVAPI */

# ifdef ORIGAPI
# define CRC64TYPE unsigned long long 
# endif /* ORIGAPI */

ubit64 gcrc64r ;

ubit64 /* CRC64TYPE */	crc64file (name, bufsiz) char * name ; int bufsiz ; {

	FILE * fp ;
	char * workbuf ;
# if ( defined (ORIGAPI) || defined (FNVAPI) )
	register int bytecount ;
# endif
# ifdef ONLYONCEPERSESSION /* ? */
	static once = 0 ;
# endif

	ubit64 /* CRC64TYPE */ result = 0ULL ;

/*	extern unsigned long long fnv1init64a ;	*/

	if ( ( fp = fopen (name, "rb") ) == NULL )
		return result ;

	if ( bufsiz <= 0 )
		bufsiz = 32768 ;

	if ( ( workbuf = xmalloc (bufsiz) ) == NULL )
		return result ;

# ifdef ORIGAPI

	crc64init () ;

	while ( (bytecount = fread (workbuf, 1, bufsiz, fp)) > 0 )
		result = crc64buff (workbuf, bytecount) ;

# endif /* ORIGAPI */

# ifdef FNVAPI

/* # define ONLYONCEPERSESSION */ /* ? */

# ifdef ONLYONCEPERSESSION /* ? */
	if ( once++ == 0 )
# endif
		result = 0xcbf29ce484222325ULL /* fnv1init64a */ ;

	while ( (bytecount = fread (workbuf, 1, bufsiz, fp)) > 0 )
		result = (ubit64) fnv_64a_buf (workbuf, (size_t) bytecount, result) ;

# endif /* FNVAPI */

# ifdef DBG
printf("c6f.r(%016llx)\n",result);
# endif

	fclose (fp) ;
	xmfree (workbuf) ;
	return gcrc64r = result ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history ..............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v rls   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */

