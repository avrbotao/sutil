
/*
 *
 *	  /\		 _______________________________________________
 *	 /  \		|						|
 *	/ OO \		|	stdpam.c		pam stuff ...	|
 *	\ \/ /		|	(c) 1998-2003	alexandre v. r. botao	|
 *	 \  /		|_______________________________________________|
 *	  \/
 *
 */

# ifdef LABIX

#	define	USE_STDIO
#	define	USE_STDPAM

#	include	"abc.h"

# else /* PLAIN */

# include  <stdio.h>

# include  "stdpam.h"

# endif /* LABIX */

/*	--	--	--	--	--	--	--	--	*/
