
/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	USE_SYSTYPES
# define	USE_STDIO

# define	USE_STDASC
# define	USE_STDLOGIC
# define	USE_STDCAP
# define	USE_STDMEM
# define	USE_STDMSG
# define	USE_STDSTR
# define	USE_STDLIB

# include "abc.h"

#ifdef HPUX
# include <unistd.h>
#endif

#ifdef AIX
# include <unistd.h>
#endif

#ifdef CYGWIN
# include <ncurses/term.h>
#else
#if defined (SOLARIS) || defined (AIX)
# include <curses.h>
#endif
# include <term.h>
#endif

char		termid  [16] = "none" ;

# ifdef ANYX

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *		cmbuf ;					/* cursor positioning (ansi)	*/
char *		clbuf ;					/* clear screen 				*/
char *		cebuf ;					/* clear to end-of-line			*/
char *		sobuf ;					/* begin standout (reverse)		*/
char *		sebuf ;					/* end   standout (reverse)		*/
char *		usbuf ;					/* begin underline				*/
char *		uebuf ;					/* end   underline				*/
char *		mdbuf ;					/* begin highlight				*/
char *		mbbuf ;					/* begin blink					*/
char *		mebuf ;					/* end   highlight or blink		*/
char *		blbuf ;					/* audible alarm bell ...		*/
char *		ksbuf ;					/* begin "keypad xmit" mode		*/
char *		kebuf ;					/* end   "keypad xmit" mode		*/
char *		asbuf ;					/* enter alternate char set		*/
char *		aebuf ;					/* leave alternate char set		*/
char *		acbuf ;					/* alternate char set chars		*/
char *		eabuf ;					/* enable alternate char set	*/
char *		tibuf ;					/* init/enter cm/cup mode		*/
char *		tebuf ;					/* end/leave cm/cup mode		*/

CAPINFO	caplist [] = {
	{ "cm", &cmbuf,	 0 	}	,
	{ "cl", &clbuf,	 1	}	,
	{ "ce", &cebuf,	 2	}	,
	{ "so", &sobuf,	 4	}	,
	{ "se", &sebuf,	 5	}	,
	{ "us", &usbuf,	 6	}	,
	{ "ue", &uebuf,	 7	}	,
	{ "md", &mdbuf,	 8	}	,
	{ "mb", &mbbuf,	 9	}	,
	{ "me", &mebuf,	10	}	,
	{ "bl", &blbuf,	11	}	,
	{ "ks", &ksbuf,	12	}	,
	{ "ke", &kebuf,	13	}	,
	{ "as", &asbuf,	14	}	,
	{ "ae", &aebuf,	15	}	,
	{ "ac", &acbuf,	16	}	,
	{ "eA", &eabuf,	17	}	,
	{ "ti", &tibuf,	18	}	,
	{ "te", &tebuf,	19	}	,
	{ NULL, NULL,	-1	}
} ;

char		tgetbuf [1024] ;

int			capsarok ;

extern int	vfd ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char bytebuff [4096] ;
int  bytecount = 0 ;

# ifdef SOLARIS
int byteout (x) char x ; {
# else
int byteout (x) int x ; {
# endif
	bytebuff [ bytecount++ ] = (char) x ;
	return x ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void byteflush () {

	int rd ;

	rd = write (vfd, bytebuff, bytecount) ;
	bytecount -= rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void putcap (buf) char * buf ; {

	if (buf != NULL) {
#ifdef SOLARIS
		tputs (buf, 0, ( int (*)(char) )byteout) ;
#else
		tputs (buf, 0, byteout) ;
#endif
		byteflush () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int initcaps () {

	int		res ;
	char *	tp ;

	capsarok = FALSE ;

	tp = (char *) getenv ("TERM") ;

	if (tp == NULL)
		return XE_TERM_NOT_SET ;
	else if (*tp == NUL)
		return XE_NULL_TERM ;

	strcpy (termid, tp) ;

	res = tgetent (tgetbuf, termid) ;

	if (res == -1)						/* no terminal database */
		return XE_NO_TERM_DB ;

	if (res == 0)						/* undocumented terminal */
		return XE_TERM_UNKNOWN ;

# ifdef TERMDBG
	printf ("TERM=%s \r\n", termid) ;
# endif

	capsarok = TRUE ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int readcaps () {

	register	int			res ;
	register	CAPINFO *	cap ;
				char *		tp ;
				char		tb [2048] ;

	for ( cap = caplist ; cap->cap_id ; ++cap ) {

		*(cap->cap_ptr) = NULL ;
		tp = tb ;
		tp = (char *) tgetstr ( cap->cap_id , &tp ) ;

		if (tp == NULL) { /* undefined capability */
# ifdef KEYDBG
			printf ("*** cap (%s) undocumented \r\n", cap->cap_id) ;
# endif
			continue ;
		} else if (*tp == NUL) { /* empty definition */
# ifdef KEYDBG
			printf ("*** cap (%s) empty \r\n", cap->cap_id) ;
# endif
			continue ;
		}

		res = strlen ( tp ) ;
		*(cap->cap_ptr) = (char *) xmalloc ( res + 1 ) ;

		if ( *(cap->cap_ptr) == NULL )
			return XE_NO_MEMORY ;

		strcpy ( *(cap->cap_ptr) , tp ) ;
		cap->cap_len = res ;
	}

	putcap (tibuf) ;

# ifdef KEYPADXMIT
	putcap (ksbuf) ;
# endif

	putcap (eabuf) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void endcaps () {

# ifdef KEYPADXMIT
	putcap (kebuf) ;
# endif

	putcap (tebuf) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* ANYX */

char * termname () {

	return termid ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

