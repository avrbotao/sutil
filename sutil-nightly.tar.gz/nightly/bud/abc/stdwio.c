

/*
 *                 _             _________________________
 *      |\       _/ \_          |                         |
 *      | \_    /_    \         |     Alexandre Botao     |
 *      \_  \__/  \__  \_       |      www.botao.org      |
 *        \    \__/  \_  \      |   alexandre@botao.org   |
 *         \_   _/     \ |      |     55-11-8244-UNIX     |
 *           \_/        \|      |_________________________|
 *
 */

# include "stdwio.h"

										/*----------------------------------*/
										/*		wordio : word i/o			*/
										/*----------------------------------*/

static	char	wiobuff [WIOBUFFSIZE] ;	/* should malloc()	*/

/*	==	==	==	==	==	==	==	==	==	==	==	==	==	==	==	==	==	==	*/

int fgetword (buf, wfp) char * buf ; FILE * wfp ; {

	int c , s = 0 ;

	if ( buf == NULL )
		buf = wiobuff ;

	/* skip leading spaces or tabs (respecting newlines) */

	while (1==1) {
		c = getc (wfp) ;
		if ( c == '\n' )
			return 0 ;
		if ( c == EOF )
			return -1 ;
		if ( c == '\t' || c == ' ' || c == '\r' )
			continue ;
		ungetc (c, wfp) ;
		break ;
	}

	/* read up to a space, tab, newline or eof */

	while (1==1) {
		c = getc (wfp) ;
		if ( c == '\n' || c == '\r' || c == EOF || c == '\t' || c == ' ' ) {
			ungetc (c, wfp) ;
			break ;
		}
		* ( buf + s++ ) = (char) c ;
	}

	/* append a nul & return length */

	* ( buf + s ) = '\0' ;
	return s ;
}

int fputword (buf, len, wfp) char * buf ; FILE * wfp ; {

	int s ;

	if ( buf == NULL )
		buf = wiobuff ;

	/* honor newlines */

	if ( len == 0 ) {
		fputc ('\n', wfp) ;
		return 0 ;
	}

	/* output a word */

	for ( s = 0 ; s < len ; ++s )
		fputc ( * ( buf + s ) , wfp ) ;

	/* append a blank */

	fputc (' ', wfp) ;

	return len ;
}

/*----------------------------------------------------------------------*/

