
/* # define NOWRAP */

/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	strlist.c		   string list management ...	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1996				alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	USE_SYSTYPES
# define	USE_STDIO
# define	USE_STDLIB

# define	USE_STDSTR
# define	USE_STDLOGIC
# define	USE_STDMATCH
# define	USE_STDASC
# define	USE_STDCMD
# define	USE_STDWIN
# define	USE_STDVIF
# define	USE_STDTYP
# define	USE_STDMISC
# define	USE_STRLIST
# define	USE_STDMEM

# include	"abc.h"

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	STRLISTHDRMARK		'\003'
# define	LINBUFSIZ			512 /* 2048 */

# ifdef NOWRAP

# define	DFL_GRAINSIZE		   256	/*    256    512   1024 */
# define	DFL_GRAINBITS		     8	/*      8      9     10 */
# define	DFL_GRAINMASK		0x00ff	/* 0x00ff 0x01ff 0x03ff */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int				grainsize = DFL_GRAINSIZE ;
int				grainbits = DFL_GRAINBITS ;
int				grainmask = DFL_GRAINMASK ;

# endif /* NOWRAP */

int				totstrlists = 0 ;

STRLISTCTRL *	workstrlist = NULL ;

STRLISTCTRL * *	allstrlists = NULL ;

char			linbuf [LINBUFSIZ] ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int findstrlist (txt) char * txt ; {

	register STRLISTCTRL * slcp = workstrlist ;
	register int j, txtlen ;

	if (slcp == NULL)
		return -1 ;

	if (slcp->slc_tot <= 0)
		return -1 ;

	if (txt == NULL)
		return -1 ;

	txtlen = strlen (txt) ;

	for ( j = 0 ; j < slcp->slc_tot ; ++j )
		if ( strncmp ( (*(slcp->slc_vec + j)).le_ptr , txt , txtlen ) == 0 )
			return j ;

	return -1 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int matchstrlist (txt) char * txt ; {

	register STRLISTCTRL * slcp = workstrlist ;
	register int j ;

	if (slcp == NULL)
		return -1 ;

	if (slcp->slc_tot <= 0)
		return -1 ;

	if (txt == NULL)
		return -1 ;

	for ( j = 0 ; j < slcp->slc_tot ; ++j )
		if ( patmat ( txt , (*(slcp->slc_vec + j)).le_ptr ) )
			return j ;

	return -1 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int sortstrlist () {

	register STRLISTCTRL * slcp = workstrlist ;

	if (slcp == NULL)
		return -1 ;

	if (slcp->slc_tot <= 1)
		return 0 ;

	if (slcp->slc_flg & (LM_SORT | LM_STACK))
		qsort ( (char *) slcp->slc_vec, slcp->slc_tot, LISTELMSIZ, compstrlist ) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int modestrlist (int cmd, int flags) {

	register STRLISTCTRL * slcp = workstrlist ;

	if (slcp == NULL)
		return -1 ;

	switch (cmd) {

		case LM_GET : return slcp->slc_flg ;
		case LM_SET : slcp->slc_flg = flags ;		break ;
		case LM_ON  : slcp->slc_flg |= flags ;		break ;
		case LM_OFF : slcp->slc_flg &= ~(flags) ;	break ;
		default     : return -1 ;
	}

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STRLISTCTRL * currstrlist () {

	return workstrlist ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int	pickstrlist (slcp) STRLISTCTRL * slcp ; {

	if (slcp == NULL)
		return -1 ;

	workstrlist = slcp ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int	compstrlist (a, b) LISTELM * a , * b ; {

	register LISTELM * pa = a , * pb = b ;

	if ( workstrlist->slc_flg & LM_STACK )
		return pb->le_pos - pa->le_pos ;
	else
		return strcmp ( pa->le_ptr , pb->le_ptr ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STRLISTCTRL * alocstrlist (nam, max) char * nam ; int max ; {

	register STRLISTCTRL * slcp ;

# ifdef NOWRAP
	if (max <= 0)
		max = grainsize ;
# endif /* NOWRAP */

# ifdef DEBUG
	printf ("alocstrlist(%s,%d): ", nam, max) ;
# endif /* DEBUG */

	if ( ( slcp = (STRLISTCTRL *) xmalloc (STRLISTCTRLSIZ) ) == NULL ) {
# ifdef DEBUG
	printf ("NO MEM \r\n") ;
# endif /* DEBUG */
		return NULL ;
	}

	slcp->slc_nam = nam ;
	slcp->slc_max = max ;
	slcp->slc_tot = 0 ;
	slcp->slc_cur = 0 ;
	slcp->slc_inx = 0 ;
	slcp->slc_flg = LM_DEFAULT ;
	slcp->slc_vec = NULL ;

# ifdef NOWRAP
	if (max % grainsize)
		slcp->slc_flg |= LM_WRAP ;
# endif /* NOWRAP */

# ifdef DEBUG
	printf ("OK (slcp=0x%lx) \r\n", (long) slcp) ;
# endif /* DEBUG */

	return slcp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STRLISTCTRL * makestrlist (nam, max) char * nam ; int max ; {

	register STRLISTCTRL * * slcpp ;
	register STRLISTCTRL * slcp ;

# ifdef NOWRAP
	if (max <= 0)
		max = grainsize ;
# endif /* NOWRAP */

# ifdef DEBUG
	printf ("makestrlist(%s,%d): ", nam, max) ;
# endif /* DEBUG */

	if (allstrlists == NULL)
		slcpp = (STRLISTCTRL * *) xmalloc (2 * sizeof (STRLISTCTRL *)) ;
	else
		slcpp = (STRLISTCTRL * *) xmrealloc ( (char *) allstrlists,
									(totstrlists+2) * sizeof (STRLISTCTRL *)) ;

	if (slcpp == NULL) {
# ifdef DEBUG
	printf ("NO MEM (ctl) \r\n") ;
# endif /* DEBUG */
		return NULL ;
	}

	slcp = alocstrlist (nam, max) ;

	if (slcp == NULL) {
# ifdef DEBUG
	printf ("NO MEM (str) \r\n") ;
# endif /* DEBUG */
		return NULL ;
	}

	allstrlists = slcpp ;
	*(allstrlists + totstrlists++) = slcp ;
	*(allstrlists + totstrlists)   = NULL ;

# ifdef DEBUG
	printf ("OK (totstrlists = %d) \r\n", totstrlists) ;
# endif /* DEBUG */

	return slcp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void freestrlist (slcp) STRLISTCTRL * slcp ; {

	register int j ;
	register LISTELM * tlep ;

	if (slcp == NULL)
		return ;

	if ( ( tlep = slcp->slc_vec ) != NULL ) {

		for ( j = 0 ; j < slcp->slc_max ; ++j )
			if ( (*(tlep + j)).le_ptr != NULL )
				xmfree ( (char *) (*(tlep + j)).le_ptr ) ; 
		xmfree ( (char *) slcp->slc_vec ) ;
	}

	for ( j = 0 ; *(allstrlists + j) != NULL /* && j < totstrlists */ ; ++j )
		if ( *(allstrlists + j) == slcp )
			break ;

	for ( ; j < totstrlists ; ++j )
		*(allstrlists+j) = *(allstrlists+j+1) ;

	xmfree ( (char *) slcp ) ;
	--totstrlists ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int	feedstrlist (str) char * str ; {

	register STRLISTCTRL * slcp = workstrlist ;
	register char * tcp , * tsp ;
	register LISTELM * tlep ;
	register int j = 0 ;
# ifdef NOWRAP
	register int newsiz ;
# endif /* NOWRAP */

	if (slcp == NULL)
		return -1 ;

# ifdef DEBUG
	printf ("feedstrlist(%s):[%s] ", slcp->slc_nam, str) ;
# endif /* DEBUG */

# ifdef NOWRAP

	/* provide for an empty list & auto-expand on demand ... */

	newsiz = slcp->slc_max ;

	if (slcp->slc_vec == NULL) {

		tlep = (LISTELM *) xmcalloc (newsiz, LISTELMSIZ) ;

	} else {									/********************/
												/*	auto-grow ...	*/
		if ( ! (slcp->slc_flg & LM_WRAP) ) {	/********************/

			if ( slcp->slc_inx && ((slcp->slc_inx & grainmask) == 0x0000) ) {

				newsiz = grainsize * ( ( slcp->slc_inx >> grainbits ) + 1 ) ;
				tlep = (LISTELM *) xmrealloc ( (char *) slcp->slc_vec , newsiz * LISTELMSIZ ) ;
				j = 1 ; /* init new mem */
			}
		}
	}

	if (tlep == NULL) {
# ifdef DEBUG
	printf ("NO MEM (vec %d) \r\n", newsiz) ;
# endif /* DEBUG */
		return -2 ;
	}

	if (j)
		for ( j = slcp->slc_inx ; j < newsiz ; ++j ) {
			(*(tlep+j)).le_ptr = NULL ;
			(*(tlep+j)).le_pos = -1 ;
		}

	slcp->slc_vec = tlep ;
	slcp->slc_max = newsiz ;

# else  /* WRAP */

	/* provide for an empty list */

	if (slcp->slc_vec == NULL) {
		tlep = (LISTELM *) xmcalloc (slcp->slc_max, LISTELMSIZ) ;
		if (tlep == NULL)
			return -2 ;
		slcp->slc_vec = tlep ;
		for ( j = 0 ; j < slcp->slc_max ; ++j ) {
			(*(tlep+j)).le_ptr = NULL ;
			(*(tlep+j)).le_pos = -1 ;
		}
	}

# endif /* NOWRAP */

	/* chk 4 for dupl'd strings (bsearch only if sorted) */

	if (slcp->slc_flg & LM_UNIQ)
		for ( j = 0 ; j < slcp->slc_tot ; ++j )
			if ( strcmp ( (*(slcp->slc_vec + j)).le_ptr , str ) == 0 ) {
				if ( slcp->slc_flg & LM_STACK ) {
					killstrlist (j) ;
				} else {
					slcp->slc_cur = j ;
					return 0 ;
				}
			}

# ifdef NOWRAP

	tsp = str ;

	if (slcp->slc_flg & LM_TAB)
		tsp = exptab (str, 4) ;

	if (slcp->slc_flg & LM_MAP)
		tsp = bintos (str) ;

# else  /* WRAP */

	/* pre-process string if so ... */

/*	if (slcp->slc_flg & LM_RAW)	*/
		tsp = str ;
/*	else	*/
		if (slcp->slc_flg & LM_MAP)
			tsp = bintos (str) ;
		else
			if (slcp->slc_flg & LM_TAB)
				tsp = exptab (str, 4) /* str */ ;

# endif /* NOWRAP */

	/* prepare new string ... */

	j = 1 + strlen (tsp) ;
	tcp = xmalloc (j) ;

	if (tcp == NULL) {
# ifdef DEBUG
	printf ("NO MEM (str %d) \r\n", j) ;
# endif /* DEBUG */
		return -3 ;
	}

	strcpy (tcp, tsp) ;

	/* free previous string (if so) and insert new one ... */

	if ( (*(slcp->slc_vec + slcp->slc_inx)).le_ptr != NULL )
		xmfree ( (*(slcp->slc_vec + slcp->slc_inx)).le_ptr ) ;

	(*(slcp->slc_vec + slcp->slc_inx)).le_ptr = tcp ;
	(*(slcp->slc_vec + slcp->slc_inx)).le_pos = slcp->slc_inx ;

	slcp->slc_inx += 1 ;

	/* check and adjust insertion point and total used */

# ifdef NOWRAP

	if ( slcp->slc_inx >= slcp->slc_max )
		if ( slcp->slc_flg & LM_WRAP )
			slcp->slc_inx = 0 ;

	slcp->slc_tot += 1 ;

	if ( slcp->slc_tot >= slcp->slc_max )
		if ( slcp->slc_flg & LM_WRAP )
			slcp->slc_tot -= 1 ;

# else  /* WRAP */

	if ( slcp->slc_inx >= slcp->slc_max )
		slcp->slc_inx = 0 ;

	if ( slcp->slc_tot < slcp->slc_max )
		slcp->slc_tot += 1 ;

# endif /* NOWRAP */

	sortstrlist () ;

# ifdef DEBUG
	printf ("OK (max=%d,tot=%d,inx=%d) \r\n",
			slcp->slc_max, slcp->slc_tot, slcp->slc_inx) ;
# endif /* DEBUG */

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int	killstrlist (int pos) {

	register STRLISTCTRL * slcp = workstrlist ;
	register int j ;
	register int kp ;

	if (slcp == NULL)
		return -1 ;

	if (slcp->slc_tot <= 1)
		return -1 ;

	if (pos < 0 || pos >= slcp->slc_tot)
		return -1 ;

	xmfree ( (char *) (*(slcp->slc_vec + pos)).le_ptr ) ;
	kp = (*(slcp->slc_vec + pos)).le_pos ;

	for ( j = pos ; j < slcp->slc_tot ; ++j ) {
/*
 *	some systems do not allow struct assign,
 *	so it may be necessary to assign each field individually
 */
		*(slcp->slc_vec + j) = *(slcp->slc_vec + j + 1) ;
	}

	for ( j = 0 ; j < slcp->slc_tot ; ++j ) {
		if ( (*(slcp->slc_vec + j)).le_pos > kp )
			(*(slcp->slc_vec + j)).le_pos -= 1 ;
	}

	if (pos <= slcp->slc_inx)
		slcp->slc_inx -= 1 ;

	slcp->slc_tot -= 1 ;
	slcp->slc_cur = pos ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *	peekstrlist (buf, pos) char * buf ; int pos ; {

	register STRLISTCTRL * slcp = workstrlist ;
	register char * tcp ;

	if (slcp == NULL)
		return NULL ;

	if (slcp->slc_tot == 0)
		return NULL ;

	if (pos < 0 || pos >= slcp->slc_tot)
		return NULL ;

	tcp = (*(slcp->slc_vec + pos)).le_ptr ;
	slcp->slc_cur = pos ;

	if (buf != NULL)
		strcpy (buf, tcp) ;

	return tcp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *	prevstrlist (buf) char * buf ; {

	register STRLISTCTRL * slcp = workstrlist ;
	register char * tcp ;

	if (slcp == NULL)
		return NULL ;

	if (slcp->slc_tot == 0)
		return NULL ;

	if (slcp->slc_cur > 0)
		slcp->slc_cur -= 1 ;
	else
		slcp->slc_cur = slcp->slc_tot - 1 ;

	tcp = (*(slcp->slc_vec + slcp->slc_cur)).le_ptr ;

	if (buf != NULL)
		strcpy (buf, tcp) ;

	return tcp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *	nextstrlist (buf) char * buf ; {

	register STRLISTCTRL * slcp = workstrlist ;
	register char * tcp ;

	if (slcp == NULL)
		return NULL ;

	if (slcp->slc_tot == 0)
		return NULL ;

	slcp->slc_cur += 1 ;

	if (slcp->slc_cur >= slcp->slc_tot)
		slcp->slc_cur = 0 ;

	tcp = (*(slcp->slc_vec + slcp->slc_cur)).le_ptr ;

	if (buf != NULL)
		strcpy (buf, tcp) ;

	return tcp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int	savestrlist (name) char * name ; {

	register STRLISTCTRL * * slcpp = allstrlists ;
	register STRLISTCTRL *   slcp ;
	FILE * fp ;

	if (slcpp == NULL)
		return -1 ;

	fp = fopen (name, "w") ;

	if (fp == NULL)
		return -2 ;

	for ( ; (slcp = *slcpp) != NULL ; ++slcpp )
		fputstrlist (fp, slcp) ;

	fclose (fp) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int fputstrlist (fp, slcp) FILE * fp ; STRLISTCTRL * slcp ; {

	register int j ;

	if (fp == NULL || slcp == NULL)
		return -1 ;

	fprintf (fp, "%c %s %d %d %u \n", STRLISTHDRMARK,
			 slcp->slc_nam, slcp->slc_tot, slcp->slc_max, slcp->slc_flg) ;

	for ( j = 0 ; j < slcp->slc_tot ; ++j )
		fprintf (fp, "%3d %s\n",
			(*(slcp->slc_vec + j)).le_pos ,
			(*(slcp->slc_vec + j)).le_ptr   ) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int fgetstrlist (fp, slcpp) FILE * fp ; STRLISTCTRL * * slcpp ; {

	register STRLISTCTRL * slcp ;
	register int j ;
	register char * tcp ;
	register LISTELM *	tlep ;
	int tmppos , ni = 0 ;
	char tmpnam [80] ;
	int tmptot, tmpmax, tmpflg ;

	if (fp == NULL || slcpp == NULL)
		return -1 ;

	if ( fgets (linbuf, LINBUFSIZ, fp) == NULL )
		return -6 ;

	if ( linbuf[0] != STRLISTHDRMARK )
		return -2 ;

	sscanf (&linbuf[2], "%s %d %d %u", tmpnam, &tmptot, &tmpmax, &tmpflg) ;

	if ( *slcpp == NULL )
		if ( ( *slcpp = (STRLISTCTRL *) xmalloc (STRLISTCTRLSIZ) ) == NULL )
			return -3 ;

	slcp = *slcpp ;

	slcp->slc_tot = tmptot ;
	slcp->slc_max = tmpmax ;
	slcp->slc_flg = tmpflg ;

	/* provide for an empty list */

	if (slcp->slc_vec == NULL) {
		tlep = (LISTELM *) xmcalloc (slcp->slc_max, LISTELMSIZ) ;
		if (tlep == NULL)
			return -4 ;
		slcp->slc_vec = tlep ;
		for ( j = 0 ; j < slcp->slc_max ; ++j ) {
			(*(tlep+j)).le_ptr = NULL ;
			(*(tlep+j)).le_pos = -1 ;
		}
	}

	/* load string vector */

	for ( j = 0 ; j < slcp->slc_tot ; ++j ) {

		ni = fscanf (fp, "%3d ", &tmppos) ;
		if ( ni != 1 )
			return -5 ;
		if ( fgets (linbuf, LINBUFSIZ, fp) == NULL )
			return -6 ;
		stripeol (linbuf) ;
		if ( ( tcp = xmalloc ( 1 + strlen (linbuf) ) ) == NULL )
			return -5 ;

		strcpy (tcp, linbuf) ;

		(*(slcp->slc_vec + slcp->slc_inx)).le_ptr = tcp ;
		(*(slcp->slc_vec + slcp->slc_inx)).le_pos = tmppos ;
		slcp->slc_inx += 1 ;
	}

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int	loadstrlist (name) char * name ; {

	register STRLISTCTRL * slcp ;
	register STRLISTCTRL * * slcpp = allstrlists ;
	register int j ;
	register char * tcp ;
	register LISTELM *	tlep ;
	int tmppos , ni = 0 ;
	register int found ;
	char tmpnam [80] ;
	FILE * fp ;
	int tmptot, tmpmax, tmpflg ;

	if (slcpp == NULL)
		return -1 ;

	if ( ( fp = fopen (name, "r") ) == NULL )
		return -2 ;

	while ( fgets (linbuf, LINBUFSIZ, fp) ) {

		if ( linbuf[0] == STRLISTHDRMARK ) {

			sscanf (&linbuf[2], "%s %d %d %u", tmpnam, &tmptot, &tmpmax, &tmpflg) ;

			/* search for proper entry (bsearch ?!) */

			for ( found = FALSE ; (slcp = *slcpp) != NULL ; ++slcpp )
				if ( strcmp (tmpnam, slcp->slc_nam) == 0 ) {
					found = TRUE ;
					break ;
				}

			if ( ! found )
				return -5 ;

			slcp->slc_tot = tmptot ;
			slcp->slc_max = tmpmax ;
			slcp->slc_flg = tmpflg ;

			/* provide for an empty list */

			if (slcp->slc_vec == NULL) {
				tlep = (LISTELM *) xmcalloc (slcp->slc_max, LISTELMSIZ) ;
				if (tlep == NULL)
					return -3 ;
				slcp->slc_vec = tlep ;
				for ( j = 0 ; j < slcp->slc_max ; ++j ) {
					(*(tlep+j)).le_ptr = NULL ;
					(*(tlep+j)).le_pos = -1 ;
				}
			}

			/* load string vector */

			for ( j = 0 ; j < slcp->slc_tot ; ++j ) {
				ni = fscanf (fp, "%3d ", &tmppos) ;
				if ( ni != 1 )
					return -5 ;
				if ( fgets (linbuf, LINBUFSIZ, fp) == NULL )
					return -6 ;
				stripeol (linbuf) ;
				tcp = xmalloc ( 1 + strlen (linbuf) ) ;

				if (tcp == NULL) {
					return -4 ;
				}

				strcpy (tcp, linbuf) ;

				(*(slcp->slc_vec + slcp->slc_inx)).le_ptr = tcp ;
				(*(slcp->slc_vec + slcp->slc_inx)).le_pos = tmppos ;
				slcp->slc_inx += 1 ;

			}

		} /* endof (if) */

	} /* endof (while) */

	fclose (fp) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * viewstrvect (cpp, tit) char * * cpp ; char * tit ; {

	register STRLISTCTRL * slcp , * tslcp ;
	register char * tp ;

	if ( cpp == NULL )
		return NULL ;

	if ( ( slcp = makestrlist ("vsv", DFL_MAXSTRLSTSIZ) ) == NULL )
		return NULL ;

	tslcp = currstrlist () ;
	pickstrlist (slcp) ;

	modestrlist ( LM_OFF , LM_SORT | LM_UNIQ ) ;
	modestrlist ( LM_ON  , LM_VONLY ) ;

	while ( *cpp != NULL )
		feedstrlist (*cpp++) ;

	tp = viewstrlist (tit) ;

	freestrlist (slcp) ;
	pickstrlist (tslcp) ;
	return tp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * viewstrfile (nam, tit) char * nam , * tit ; {

	register STRLISTCTRL * slcp , * tslcp ;
	register char * tp ;
	register FILE * tfp ;

	if ( nam == NULL )
		return NULL ;

	tfp = fopen (nam, "r") ;

	if (tfp == NULL)
		return NULL ;

	if ( ( slcp = makestrlist ("vsf", DFL_MAXSTRLSTSIZ) ) == NULL )
		return NULL ;

	tslcp = currstrlist () ;
	pickstrlist (slcp) ;

	modestrlist ( LM_OFF , LM_SORT | LM_UNIQ ) ;
	modestrlist ( LM_ON  , /* LM_VONLY | */ LM_TAB ) ;

	while ( fgets (linbuf, LINBUFSIZ, tfp) /* != NULL */ ) {
		stripeol (linbuf) ;
# ifdef DEBUG
		printf ("viewstrfile(%s): lin=[%s] \r\n", nam, linbuf) ;
# endif
		feedstrlist ( linbuf ) ;
	}

	if (tit == NULL)
		tit = lastname (nam) ;

	tp = viewstrlist (tit) ;

	freestrlist (slcp) ;
	pickstrlist (tslcp) ;
	fclose (tfp) ;
	return tp ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char pfmt [20] ;
char ufmt [20] ;

char * viewstrlist (tit) char * tit ; {

	register int inilin = 3 ;
	register int inicol ;
	register int lines = ( wlines() - 8 ) ;
	register int columns = wcols() ;
	register int j, k, len, showpage ;
	register char * tp = NULL ;
	register int total, index, page, maxlen ;
	register int height, width, boxlin, offset = 0 ;
	register STRLISTCTRL * slcp = workstrlist ;
	register WINDES * wp ;
	register int tablen = 8 ;
	register int krstate ;
	register int titlen = 0 ;
	extern int kbdreflect ;

	if (slcp == NULL)
		return NULL ;

	if (slcp->slc_tot == 0)
		return NULL ;

/*	if (lines < 0) */
		lines = videolines () - 8 ;

	if (tit != NULL)
		titlen = strlen (tit) ;

	total = maxlen = 0 ;

	for ( k = 0 ; ( tp = peekstrlist (NULL, k) ) != NULL ; ++k ) {
		if ( ( len = strlen (tp) ) > maxlen)
			maxlen = len ;
		++total ;
	}

/*	if (columns < maxlen + 5) */
		columns = videocols () ;

	if ( slcp->slc_tot < lines )
		lines = slcp->slc_tot ;

	if ( titlen + 4 > maxlen )
		maxlen = titlen + 4 ;

	if ( (width = maxlen + 5) > (j = columns - 10) )
		maxlen = (width = j) - 5 ;

# ifdef COMMENT
				width = maxlen + 5 ;
# endif

	height = lines + 2 ;
	inicol = ( columns - width ) / 2 ;

	sprintf (pfmt, "<%%-%d.%ds>", maxlen, maxlen) ;
	sprintf (ufmt, " %%-%d.%ds ", maxlen, maxlen) ;

	index = page = boxlin = 0 ;

# ifdef DEBUG
	printf ("vsl(%s,%d,%d,%d,%d)\n", tit, inilin, inicol, height, width) ;
# endif

	wp = wopen (inilin, inicol, height, width) ;
	wclear () ;
/*	wrev () ;	*/
	wbox (tit) ;
/*	wnorm () ;	*/

	krstate = kbdreflect ;
	kbdreflect = FALSE ;

	showpage = TRUE ;

	for ( ; ; ) {

		if (showpage) {
			for ( j = 0 ; j < lines ; ++j ) {
				wgoto (j+1, 1) ;

				if (page+j < total)
# ifdef NOWRAP
					len = strlen ( tp = /*prepout ( slcp->slc_flg,*/
											peekstrlist (NULL, page + j) /*)*/ ) ;
# else  /* WRAP */
					len = strlen ( tp = peekstrlist (NULL, page + j) ) ;
# endif /* NOWRAP */
				else
					len = 1 ;

				if ( offset < len )
					tp += offset ;
				else
					tp = " " ;

				if (page+j < total)
					dispnorm ( tp ) ;
				else
					dispnorm (" ") ;
			}
			showpage = FALSE ;
		}

		if ( slcp->slc_flg & LM_VONLY ) {

			k = readcmd () ;

		} else {

# ifdef NOWRAP
			len = strlen ( tp = /*prepout ( slcp->slc_flg,*/
									peekstrlist (NULL, index) /*)*/ ) ;
# else  /* WRAP */
			len = strlen ( tp = peekstrlist (NULL, index) ) ;
# endif /* NOWRAP */

			if ( offset < len )
				tp += offset ;
			else
				tp = " " ;

			wgoto (boxlin+1, 1) ;
			disprev ( tp ) ;

			k = readcmd () ;

			wgoto (boxlin+1, 1) ;
			dispnorm ( tp ) ;
			tp = peekstrlist (NULL, index) ;
		}

		switch (k) {

			case XC_NEXTWORD :
				offset += tablen ;
				showpage = TRUE ;
			break ;

			case XC_PREVWORD :
				if ( offset >= tablen ) {
					offset -= tablen ;
					showpage = TRUE ;
				}
			break ;

			case '6' :
			case XC_MOVERIGHT :
				++offset ;
				showpage = TRUE ;
			break ;

			case '4' :
			case XC_MOVELEFT :
				if ( offset > 0 ) {
					--offset ;
					showpage = TRUE ;
				}
			break ;

			case '3' :
			case XC_PAGEDOWN :
				if (page + lines >= total) { /* end */
					index  = total - 1 ;
					if (total <= lines) {
						boxlin = index ;
					} else {
						boxlin = lines - 1 ;
						page = total - lines ;
					}
				} else {
					page += lines ;
					index = page ;
					boxlin = 0 ;
				}
				showpage = TRUE ;
			break ;

			case '9' :
			case XC_PAGEUP :
				if (page - lines < 0) {
					index = page = boxlin = 0 ; /* home */
				} else {
					page -= lines ;
					index = page ;
					boxlin = 0 ;
				}
				showpage = TRUE ;
			break ;

			case '7' :
			case XC_HOMELINE :
			case XC_FIRSTPAGE :
				index = page = boxlin = 0 ;
				showpage = TRUE ;
			break ;

			case '1' :
			case XC_ENDOFLINE :
			case XC_LASTPAGE :
				index  = total - 1 ;
				if (total <= lines) {
					boxlin = index ;
				} else {
					boxlin = lines - 1 ;
					page = total - lines ;
				}
				showpage = TRUE ;
			break ;

			case '2' :
			case XC_MOVEDOWN :
				if (index < total-1) {
					++index ;
					if (boxlin < lines-1) {
						++boxlin ;
					} else {
						++page ;
						showpage = TRUE ;
					}
				}
			break ;

			case '8' :
			case XC_MOVEUP :
				if (index > 0) {
					--index ;
					if (boxlin > 0) {
						--boxlin ;
					} else {
						--page ;
						showpage = TRUE ;
					}
				}
			break ;

			case XC_DELLINE :
				if ( index < total - 1 ) {
					if ( killstrlist ( index ) == 0 ) {
						--total ;
						showpage = TRUE ;
					}
				}
			break ;

			case XC_ESC :		tp = NULL ;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif

			case XC_NEWLINE :	wclose (wp) ;
								kbdreflect = krstate ;
								return tp ;

			default :			honk () ; break ;
		}
	}
}

void disprev (txt) char * txt ; {

	char tmpbuf [256] ;

	sprintf (tmpbuf, pfmt, txt) ;
	wrev () ;
	wputs (tmpbuf) ;
	wnorm () ;
}

void dispnorm (txt) char * txt ; {

	char tmpbuf [256] ;

	sprintf (tmpbuf, ufmt, txt) ;
	wputs (tmpbuf) ;
}

# ifdef NOWRAP

# ifdef PREPOUT

char * prepout (flg, str) char * str ; {

	char * tsp = str ;

# ifdef COMMENT
	if (flg & LM_RAWTXT)
		tsp = str ;
# endif

	if (flg & LM_TAB)
		tsp = exptab (str, 4) ;

	if (flg & LM_MAP)
		tsp = bintos (str) ;

	return tsp ;
}

# endif /* PREPOUT */

# endif /* NOWRAP */

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history ..............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v rls   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
