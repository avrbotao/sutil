
/*		 _______________________________________________________________
 *		|																|
 *		|	stdstat.c					(c) 1998-2006 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO
# define	USE_SYSTYPES
# define	USE_STDTIME
# define	USE_STDSTAT

# include	"abc.h"

# ifdef WIN32
/* #	define DOS */
# endif

STABUF _xstb_ ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STABUF * laststat () {

	return &_xstb_ ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

STABUF * statof (name) char * name ; {

	register int rd ;

# ifdef DOS
	rd = stat (name, &_xstb_) ;
# else
	rd = lstat (name, &_xstb_) ;
# endif

	if (rd == 0)
		return &_xstb_ ;
	else
		return NULL ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int typeof (stap) STABUF * stap ; {

	register int rd ;

	if (stap == NULL)
		return T_NONE ;

	switch ( stap->st_mode & S_IFMT ) {
		case S_IFREG  :	rd = T_FILE ;	break ;
		case S_IFDIR  :	rd = T_DIR  ;	break ;
# ifdef S_IFBLK
		case S_IFBLK  :	rd = T_BLK  ;	break ;
# endif /* S_IFBLK */
		case S_IFCHR  :	rd = T_CHR  ;	break ;
# ifdef S_IFIFO
		case S_IFIFO  :	rd = T_FIFO ;	break ;
# endif /* S_IFIFO */
# ifdef S_IFLNK
		case S_IFLNK  :	rd = T_LINK ;	break ;
# endif /* S_IFLNK */
# ifdef S_IFSOCK
		case S_IFSOCK :	rd = T_SOCK ;	break ;
# endif /* S_IFSOCK */
		default :		rd = T_NONE ;	break ;
	}

	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long bytesof (stap) STABUF * stap ; {

	if (stap == NULL)
		return -1L ;

	return stap->st_size ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long mtimeof (stap) STABUF * stap ; {

	if (stap == NULL)
		return -1L ;

	return stap->st_mtime ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long atimeof (stap) STABUF * stap ; {

	if (stap == NULL)
		return -1L ;

	return stap->st_atime ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

TIMESPEC * timesof (stap) STABUF * stap ; {

	static struct timespec tsbuf ;

	if (stap == NULL)
		return (TIMESPEC *) NULL ;

	tsbuf.tv_sec = 0 ;
	tsbuf.tv_nsec = 0 ;

	return &tsbuf ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long filesize (name) char * name ; {

	return bytesof ( statof (name) ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long filemtime (name) char * name ; {

	return mtimeof ( statof (name) ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

long fileatime (name) char * name ; {

	return atimeof ( statof (name) ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

TIMESPEC * filetimes (name) char * name ; {

	return timesof ( statof (name) ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int filetype (name) char * name ; {

	return typeof ( statof (name) ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * strmodes (mode) long /* mode_t */ mode ; {

	static		char	prot [16] ;
	register	int		i ;
	register	char *	pp		= prot ;
	static		char *	bitv	= " rwxrwxrwx " ;
	static		char *	bitx	= " sst " ;
	static		char *	bitX	= " SST " ;
	register	int		objtyp ;

	switch ( (int) mode & S_IFMT ) {

		case S_IFREG  :	objtyp = '-' ; break ;
		case S_IFDIR  :	objtyp = 'd' ; break ;

# ifdef S_IFBLK
		case S_IFBLK  :	objtyp = 'b' ; break ;
# endif /* S_IFBLK */

		case S_IFCHR  :	objtyp = 'c' ; break ;

# ifdef S_IFIFO
		case S_IFIFO  :	objtyp = 'p' ; break ;
# endif /* S_IFIFO */

# ifdef S_IFLNK
		case S_IFLNK  :	objtyp = 'l' ; break ;
# endif /* S_IFLNK */

# ifdef S_IFSOCK
		case S_IFSOCK :	objtyp = 's' ; break ;
# endif /* S_IFSOCK */

		default :		objtyp = '?' ; break ;
	}

	*pp++ = objtyp ;

#	define    MBIT    (001000)
#	define    XBIT    (010000)

	for ( i = 1 ; i < 10 ; i++ )
		*pp++ = ((mode & (MBIT >> i)) ? (*(bitv + i)) : '-') ;

	for ( pp = prot + 3 , i = 1 ; i < 4 ; i++ , pp += 3 )
		*pp = ((mode & (XBIT >> i)) ? ( *pp == 'x' ? (*(bitx + i)) : (*(bitX + i)) ) : *pp) ;

	prot[10] = '\0' ;

	return prot ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

/*
 * vi:nu tabstop=4
 */
