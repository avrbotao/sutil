
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   ooak                   there can be only ONE   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'ooak' ("one of a kind") as released by         |
 | Alexandre Botao <botao.org> ;                                        |
 |                                                                      |
 | 'ooak' is Free and Open Source software (FOSS).  This means you can  |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'ooak' is distributed in the hope that it will be useful,            |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'ooak'. If not, see <http://www.gnu.org/licenses/>, or    |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# define	SWNAME			"ooak"
# define	SWVERS			"0.0.33"
# define	SWFORG			"$"						/*	"$" = stable	*/
# define	SWDATE			"2015/01/13"
# define	SWDESC			"deduplication assistant"
# define	SWTAGS			"ooak,deduplication,dedup,scan,analyze,search,report"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	_XOPEN_SOURCE	500

#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

# include "configure.h"
# include "astdint.h"

#include <unistd.h>

#include <sys/time.h>
#include <sys/resource.h>

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	TEMPBUFFSIZE	1048576

# define	DED_DUPLNAME	0x00000001
# define	DED_DUPLSIZE	0x00000002

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	FPCT(P,T)		(((float)P/(float)T)*(float)100.0)

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

struct ded_info {
	char *	ded_full ;		/*	full pathname				*/
	int		ded_flen ;		/*	full pathname length		*/
	int		ded_base ;		/*	base name offset			*/
	char *	ded_name ;		/*	base name					*/
	off_t	ded_size ;		/*	stat size					*/
	time_t	ded_time ;		/*	stat time					*/
	int		ded_flag ;		/*	nftw flags					*/
	int		ded_prop ;		/*	internal flags				*/
	int		ded_code ;		/*	unique reference			*/
} ;

typedef	struct ded_info		DED_INFO ;

# define	DED_INFO_SIZE	sizeof(DED_INFO)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct dup_name {
	char *	dn_name ;
	int		dn_count ;
} ;

typedef	struct dup_name		DUP_NAME ;

# define	DUP_NAME_SIZE	sizeof(DUP_NAME)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct dup_size {
	off_t	ds_size ;
	int		ds_count ;
} ;

typedef		struct dup_size		DUP_SIZE ;

# define	DUP_SIZE_SIZE	sizeof(DUP_SIZE)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

typedef		struct rlimit		RLIMITBUF ;

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

int				contentflag		= 0 ;
int				dumpflag		= 0 ;
int				errorflag		= 0 ;
int				nameflag		= 0 ;
int				reportflag		= 0 ;
int				sizeflag		= 0 ;
int				verboseflag		= 0 ;

int				extraparms		= 0 ;

int				dedinftabsiz	= 0 ;
int				dupnamtabsiz	= 0 ;
int				dupsiztabsiz	= 0 ;

int				dedinftabused	= 0 ;
int				dupnamtabused	= 0 ;
int				dupsiztabused	= 0 ;

int				totdupnam		= 0 ;
int				totdupsiz		= 0 ;

int				totunqnam		= 0 ;
int				totunqsiz		= 0 ;

int				maxdepth		= 32 ;

char *			topdir			= NULL ;
char *			inputfile		= NULL ;
char *			outputfile		= NULL ;

char			tempbuff [TEMPBUFFSIZE] ;

RLIMITBUF		rlimbuf ;

DED_INFO * *	dedinftab		= NULL ;

DUP_NAME * *	dupnamtab		= NULL ;

DUP_SIZE * *	dupsiztab		= NULL ;

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

int			bunchsize	= 1024 ;

void growtab (
				char * * *		tableptr	,
				int *			tablesiz	,
				int				elemsize
) {
	register	int				i			;
	register	int				tmpsiz		;
	register	char * *		tmptab		;
	register	char *			tmprec		;

	tmptab = *tableptr ;
	tmpsiz = *tablesiz + bunchsize ;

	if ( tmptab == NULL ) {
		tmptab = (char * *) malloc ( tmpsiz * sizeof(char *) ) ;
	} else {
		tmptab = (char * *) realloc ( tmptab , tmpsiz * sizeof(char *) ) ;
	} 

	if ( tmptab == NULL ) {
		fprintf (stderr, "** no memory for table **\n");
		exit (EXIT_FAILURE) ;
	}

	*tableptr = tmptab ;

	for ( i = 0 , tmptab = (*tableptr) + *tablesiz ; i < bunchsize ; ++i ) {
		tmprec = (char *) malloc ( elemsize ) ;

		if ( tmprec == NULL ) {
			fprintf (stderr, "** no memory for entry **\n");
			exit (EXIT_FAILURE) ;
		}

		*(tmptab+i) = tmprec ;
	}

	*tablesiz = tmpsiz ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

DED_INFO * newdip () {

	if ( ( dedinftabused % bunchsize ) == 0 ) {
		if ( verboseflag >= 2 ) {
			printf ("%d\r", dedinftabused) ;
			fflush (stdout) ;
		}
		growtab ( (char * * *) &dedinftab , &dedinftabsiz , DED_INFO_SIZE ) ;
	}

	return dedinftab[dedinftabused++] ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

DUP_NAME * newdnp () {

	if ( ( dupnamtabused % bunchsize ) == 0 ) {
		if ( verboseflag >= 2 ) {
			printf ("%d\r", dupnamtabused) ;
			fflush (stdout) ;
		}
		growtab ( (char * * *) &dupnamtab , &dupnamtabsiz , DUP_NAME_SIZE ) ;
	}

	return dupnamtab[dupnamtabused++] ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

DUP_SIZE * newdsp () {

	if ( ( dupsiztabused % bunchsize ) == 0 ) {
		if ( verboseflag >= 2 ) {
			printf ("%d\r", dupsiztabused) ;
			fflush (stdout) ;
		}
		growtab ( (char * * *) &dupsiztab , &dupsiztabsiz , DUP_SIZE_SIZE ) ;
	}

	return dupsiztab[dupsiztabused++] ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void storearg (
	char *	arg
) {
	register	int				i			;

	if ( arg != NULL )
		i = strlen (arg) ;
	if ( i < 0 )
		return ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int dednamcmp (
	const		void *			p1			,
	const		void *			p2
) {
	return
		strcmp (
			(*(DED_INFO * *)p1)->ded_name	,
			(*(DED_INFO * *)p2)->ded_name
		) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int dedsizcmp (
	const		void *			p1			,
	const		void *			p2
) {
	return (*(DED_INFO * *)p1)->ded_size - (*(DED_INFO * *)p2)->ded_size ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|	...															|
 *		|_______________________________________________________________|
 */

void dump_info () {
	register	int				i			;
	register	int				tflag		;
	register	DED_INFO *		dip			;

	for ( i = 0 ; i < dedinftabused ; ++i ) {
		dip = dedinftab[i] ;
		if ( nameflag )
			if ( ! ( dip->ded_prop & DED_DUPLNAME ) )
				continue ;
		if ( sizeflag )
			if ( ! ( dip->ded_prop & DED_DUPLSIZE ) )
				continue ;
		tflag = dip->ded_flag ;
		printf ( "\"%s\";\"%s\";%jd;\"%s\"\n",
			(tflag == FTW_D)	? "d"	:
			(tflag == FTW_DNR)	? "dnr"	:
			(tflag == FTW_DP)	? "dp"	:
			(tflag == FTW_F)	? "f"	:
			(tflag == FTW_NS)	? "ns"	:
			(tflag == FTW_SL)	? "sl"	:
			(tflag == FTW_SLN)	? "sln"	:
			"???",
			dip->ded_name,
			(intmax_t) dip->ded_size,
			dip->ded_full
		) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void dump_name () {
	register	int				i			;
	register	DUP_NAME *		dnp			;

	for ( i = 0 ; i < dupnamtabused ; ++i ) {
		dnp = dupnamtab[i] ;
		printf ( "%d;\"%s\"\n", dnp->dn_count, dnp->dn_name ) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void dump_size () {
	register	int				i			;
	register	DUP_SIZE *		dsp			;

	for ( i = 0 ; i < dupsiztabused ; ++i ) {
		dsp = dupsiztab[i] ;
		printf ( "%d;%jd\n", dsp->ds_count, (intmax_t) dsp->ds_size ) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void count_name () {
	register	int				i			;
	register	DUP_NAME *		dnp			;

	for ( i = 0 ; i < dedinftabused ; ) {
		dnp = newdnp () ;
		dnp->dn_name = strdup ( dedinftab[i++]->ded_name ) ;
		dnp->dn_count = 1 ;
		while ( ( i < dedinftabused ) && ( 0 == strcmp ( dedinftab[i]->ded_name , dnp->dn_name ) ) ) {
			dedinftab[i]->ded_prop |= DED_DUPLNAME ;
			dnp->dn_count += 1 ;
			++i ;
		}
		if ( dnp->dn_count == 1 )
			++totunqnam ;
		else
			++totdupnam ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void count_size () {
	register	int				i			;
	register	DUP_SIZE *		dsp			;

	for ( i = 0 ; i < dedinftabused ; ) {
		dsp = newdsp () ;
		dsp->ds_size = dedinftab[i++]->ded_size ;
		dsp->ds_count = 1 ;
		while ( i < dedinftabused && dedinftab[i]->ded_size == dsp->ds_size ) {
			dedinftab[i]->ded_prop |= DED_DUPLSIZE ;
			dsp->ds_count += 1 ;
			++i ;
		}
		if ( dsp->ds_count == 1 )
			++totunqsiz ;
		else
			++totdupsiz ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int load_info (
	char *	name
) {
	register	int				i			;
	register	int				error = 0	;
	register	DED_INFO *		dip			;
				FILE *			fp			;

	if ( name == NULL )
		return -1 ;

	fp = fopen (name, "r") ;

	if ( fp == NULL ) {
		fprintf (stderr, "* fopen(%s,r) failed\n", name) ;
		return -1 ;
	}

	for ( dedinftabused = 0 ; error == 0 ; ) {

		if ( NULL == fgets (tempbuff, TEMPBUFFSIZE, fp) ) {
			break ;
		} else {
			dip = newdip () ;
			sscanf (tempbuff, "%d", &dip->ded_code) ;
		}

		if ( NULL == fgets (tempbuff, TEMPBUFFSIZE, fp) )
			++error ;
		else
			sscanf (tempbuff, "%d", &dip->ded_prop) ;

		if ( NULL == fgets (tempbuff, TEMPBUFFSIZE, fp) )
			++error ;
		else
			sscanf (tempbuff, "%d", &dip->ded_flag) ;

		if ( NULL == fgets (tempbuff, TEMPBUFFSIZE, fp) )
			++error ;
		else
			sscanf (tempbuff, "%d", &dip->ded_base) ;

		if ( NULL == fgets (tempbuff, TEMPBUFFSIZE, fp) )
			++error ;
		else
			sscanf (tempbuff, "%jd", (intmax_t *) &dip->ded_size) ;

		if ( NULL == fgets (tempbuff, TEMPBUFFSIZE, fp) ) {
			++error ;
		} else {
			i = strlen (tempbuff) ;
			for ( --i ; tempbuff[i] == '\n' || tempbuff[i] == '\r' ; tempbuff[i--] = '\0' ) ;
			dip->ded_full = strdup (tempbuff) ;
			dip->ded_flen = i + 1 ;
			dip->ded_name = dip->ded_full + dip->ded_base ;
		}
	}

	fclose (fp) ;

	if ( error == 0 )
		return 0 ;
	else
		return -1 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int save_info (
	char *	name
) {
	register	int				i			;
	register	DED_INFO *		dip			;
				FILE *			fp			;

	if ( name == NULL )
		return -1 ;

	fp = fopen (name, "w") ;

	if ( fp == NULL ) {
		fprintf (stderr, "* fopen(%s,w) failed\n", name) ;
		return -1 ;
	}

	for ( i = 0 ; i < dedinftabused ; ++i ) {
		dip = dedinftab[i] ;
		fprintf (fp, "%d\n%d\n%d\n%d\n%jd\n%s\n",
			dip->ded_code,
			dip->ded_prop,
			dip->ded_flag,
			dip->ded_base,
			(intmax_t) dip->ded_size,
			dip->ded_full
		) ;
	}

	fclose (fp) ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

static int collect_info (
	const		char *			fpath		,
	const		struct stat *	sb			,
				int				tflag		,
				struct FTW *	ftwbuf
) {
				DED_INFO *		dip			;

	dip = newdip () ;

	dip->ded_full = strdup (fpath) ;
	dip->ded_flen = strlen (fpath) ;
	dip->ded_base = ftwbuf->base ;
	dip->ded_name = dip->ded_full + dip->ded_base ;
	dip->ded_flag = tflag ;
	dip->ded_prop = 0x00 ;
	dip->ded_size = sb->st_size ;
	dip->ded_time = sb->st_mtime ;
	dip->ded_code = dedinftabused ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void report_stats () {

	printf ("+ info table size ................ %d\n", dedinftabsiz) ;
	printf ("+ info table used ................ %d\n", dedinftabused) ;

	if (nameflag) {
		printf ("+ dupl name table size ........... %d\n", dupnamtabsiz) ;
		printf ("+ dupl name table used ........... %d\n", dupnamtabused) ;
		printf ("+ dupl names ..................... %d (%4.1f %%)\n", totdupnam, FPCT(totdupnam,dupnamtabused)) ;
		printf ("+ uniq names ..................... %d (%4.1f %%)\n", totunqnam, FPCT(totunqnam,dupnamtabused)) ;
	}

	if (sizeflag) {
		printf ("+ dupl size table size ........... %d\n", dupsiztabsiz) ;
		printf ("+ dupl size table used ........... %d\n", dupsiztabused) ;
		printf ("+ dupl sizes ..................... %d (%4.1f %%)\n", totdupsiz, FPCT(totdupsiz,dupsiztabused)) ;
		printf ("+ uniq sizes ..................... %d (%4.1f %%)\n", totunqsiz, FPCT(totunqsiz,dupsiztabused)) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void usage (
	char *	name
) {
	fprintf (stderr, "Usage: %s [-cDhnrsv] [-d dir] [-i file] [-o file]\n", name) ; 
	fprintf (stderr, "  -c       sort by content(hash)\n") ;
	fprintf (stderr, "  -D       dump tables\n") ;
	fprintf (stderr, "  -d dir   scan <dir>\n") ;
	fprintf (stderr, "  -h       show help\n") ;
	fprintf (stderr, "  -i file  input from <file>\n") ;
	fprintf (stderr, "  -n       sort by name\n") ;
	fprintf (stderr, "  -o file  output to <file>\n") ;
	fprintf (stderr, "  -r       report stats\n") ;
	fprintf (stderr, "  -s       sort by size\n") ;
	fprintf (stderr, "  -v       verbose\n") ;
	exit (EXIT_FAILURE) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int main (
	int argc,
	char *argv[]
) {
	register	int		i ;
				int		ntwflags = 0 ;
/*
	extern		int		optind ;
	extern		char *	optarg ;
*/
	/* parse args */

	while ( EOF != ( i = getopt (argc, argv, "cDd:hi:no:rsv") ) )
		switch (i) {
			case 'c' : ++contentflag ;				break ;
			case 'D' : ++dumpflag ;					break ;
			case 'd' : topdir = optarg ;			break ;
			case 'h' : ++errorflag ;				break ;
			case 'i' : inputfile = optarg ;			break ;
			case 'n' : ++nameflag ;					break ;
			case 'o' : outputfile = optarg ;		break ;
			case 'r' : ++reportflag ;				break ;
			case 's' : ++sizeflag ;					break ;
			case 'v' : ++verboseflag ;				break ;
			case '?' : ++errorflag ;				break ;
			default  : ++errorflag ;				break ;
		}

	/* check args */

	if ( extraparms	) {

		if (optind == argc) {
			fprintf (stderr, "* missing args\n") ;
			++errorflag ;
		} else {
			while ( optind < argc )
				storearg ( argv[optind++] ) ;
		}

	} else {

		if ( optind < argc ) {
			fprintf (stderr, "* unexpected args: ") ;
			while (optind < argc)
				fprintf (stderr, "{%s} ", argv[optind++]) ;
			fprintf (stderr, "\n") ;
			++errorflag ;
		}

	}

	if ( inputfile == NULL && topdir == NULL ) {
		fprintf (stderr, "* choose {-d} or {-i}\n") ;
		++errorflag ;
	}

	if ( inputfile != NULL && topdir != NULL ) {
		fprintf (stderr, "* options {-d} and {-i} are mutually exclusive\n") ;
		++errorflag ;
	}

	if ( errorflag ) {
		usage ( argv[0] ) ;
	}

	/* prep stuff */

	if ( getrlimit(RLIMIT_NOFILE, &rlimbuf) == -1 ) {
		perror("getrlimit") ;
		exit(EXIT_FAILURE) ;
	}

	maxdepth = rlimbuf.rlim_cur / 2 ;

	/* fill info table */

	if ( topdir != NULL ) {
		if ( verboseflag >= 1 )
			printf ("# scan (%s)\n", topdir) ;
		if ( nftw ( (argc < 2) ? "." : topdir, collect_info, maxdepth, ntwflags ) == -1 ) {
			perror("nftw") ;
			exit(EXIT_FAILURE) ;
		}
	}

	if ( inputfile != NULL ) {
		if ( verboseflag >= 1 )
			printf ("# load (%s)\n", inputfile) ;
		if ( load_info ( inputfile ) == -1 ) {
			exit(EXIT_FAILURE) ;
		}
	}

	if ( verboseflag >= 2 && dedinftabused >= bunchsize )
		printf ("\n") ;

	/* save info table */

	if ( outputfile != NULL ) {
		if ( verboseflag >= 1 )
			printf ("# save (%s)\n", outputfile) ;
		if ( save_info ( outputfile ) == -1 ) {
			exit(EXIT_FAILURE) ;
		}
	}

	/* by name */

	if (nameflag) {
		/* sort */
		if ( verboseflag >= 1 )
			printf ("# sort (%s)\n", "name") ;

		qsort (dedinftab, (size_t)dedinftabused, sizeof(DED_INFO *), dednamcmp) ;

		/* fill name table */
		if ( verboseflag >= 1 )
			printf ("# count (%s)\n", "name") ;

		count_name () ;
	}

	if (sizeflag) {
		/* sort */
		if ( verboseflag >= 1 )
			printf ("# sort (%s)\n", "size") ;

		qsort (dedinftab, (size_t)dedinftabused, sizeof(DED_INFO *), dedsizcmp) ;

		/* fill size table */
		if ( verboseflag >= 1 )
			printf ("# count (%s)\n", "size") ;

		count_size () ;
	}

	/* dump info table */

	if (dumpflag) {
		if (nameflag) {
			dump_name () ;
		}
		if (sizeflag) {
			dump_size () ;
		}
		if (verboseflag) {
			dump_info () ;
		}
	}

	/* report stats ? */

	if (reportflag) {
		if ( verboseflag >= 1 )
			printf ("# report stats\n") ;

		report_stats () ;
	}

	/* do the twist ? */

	exit(EXIT_SUCCESS) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

/*
 * vi:nu ts=4
 */
