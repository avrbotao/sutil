
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'BRASH' (the basic remote administration shell) |
 | as released by Alexandre Botao <botao.org> ;                         |
 |                                                                      |
 | 'BRASH' is Free and Open Source software (FOSS). This means you can  |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'BRASH' is distributed in the hope that it will be useful,           |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'BRASH'.  If not, see <http://www.gnu.org/licenses/>, or  |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# include	"brash.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char *		swname ;
char *		versno ;
char *		forgid ;

int			cflag = 0 ;
int			sflag = 0 ;
int			tflag = 0 ;

int			errorflag = 0 ;
int			interactiveflag = 0 ;
int			cleanflag = 0 ;
int			verboseflag = 0 ;
int			versionflag = 0 ;

FILE *		top = NULL ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

/*	TCP UDP Unassigned Official 4 8 10 12 14 16 26 40	*/

int			portlist [] = { 4, 8, 10, 12, 14, 16, 26, 40, -1 } ;

int			maxports = 8 ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char *		thisuser = "thisuser" ;
char *		thishost = "thishost" ;
char *		thisexec = "thisexec" ;

char *		logtag ;
char *		brashvar = BRASHVAR ;

int			locpid ;

FILE *		logfp ;

mode_t		currmask = DFL_CURRMASK ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int			maxhostnamelen = MAXHOSTNAMELEN ;

int			maxfilsiz = DFL_MAXFILSIZ ;
int			maxfilent = DFL_MAXFILENT ;
int			maxlinsiz = DFL_MAXLINSIZ ;

int			clabufsiz = DFL_CLABUFSIZ ;
int			cllbufsiz = DFL_CLABUFSIZ ;

int			locuid ;
int			locgid ;

int			loceuid ;
int			locegid ;

int			temphostflag ;
int			tempadrcount ;
int			tempalicount ;

int			brashmode		=	0755 ;

char		localusername [MAXUSERNAMELEN] = { '\0' } ;

char		localhostname [MAXHOSTNAMELEN] = { '\0' } ;
char		localhostaddr [64] ;

char		temphostname [MAXHOSTNAMELEN] ;
char		temphostdoma [MAXHOSTNAMELEN] ;
char		temphostfqdn [MAXHOSTNAMELEN] ;
char		temphostaddr [MAXIPV4ADDRLEN] ;

char		tempbuff     [TEMPBUFFSIZE] ;
char		homepath     [PATHBUFFSIZE] ;
char		shellpath    [PATHBUFFSIZE] ;
char		brashdir     [PATHBUFFSIZE] ;
char		currworkpath [PATHBUFFSIZE] ;
char		bratopdir    [PATHBUFFSIZE] ;
char		bralogpath   [PATHBUFFSIZE] ;
char		brahistpath  [PATHBUFFSIZE] ;
char		nodtabpath   [PATHBUFFSIZE] ;
char		listabpath   [PATHBUFFSIZE] ;
char		aliastabpath [PATHBUFFSIZE] ;
char		ipv4tabpath  [PATHBUFFSIZE] ;
char		execpathname [EXECPATHNAMESIZE] ;

char *		locuser = NULL ;

#ifdef L8R
char *		clabuf = NULL ;
char *		cllbuf = NULL ;
#else
char		clabuf [DFL_CLABUFSIZ] ;
char		cllbuf [DFL_CLABUFSIZ] ;
#endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int			bramaxnod = BRA_MAXNOD ;
int			brahostot = 0 ;
int			brahosact = 0 ;

BRACTL * *	branodtab = NULL ;

int			bramaxlis = BRA_MAXLIS ;	/* table size		*/
int			bralistot = 0 ;				/* used slots		*/
int			bralisact = 0 ;				/* active slots		*/

BRALIS * *	bralistab = NULL ;

int			maxlisent = MAXLISENT ;

struct stat	tsb ;

# ifndef _HAS_READLINE_
int		history_base = 0 ;
# endif

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int			maxparachop = 0 ;
int			maxchopslic = 0 ;

char		chopbuff [CHOPBUFFSIZE] ;
char *		chopvect [MAXCHOP] /* = { NULL } */ ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	REXLSTNAM		"match"

# define	MAXREXERRMSGLEN	0x1000

# define	MAXREXMAT		16
# define	MAXREXLEN		128

regex_t		rexbuf ;

regmatch_t	rexmat[MAXREXMAT] ;

int			currexmat = 8 ;
int			totrexmat = 0 ;

char		rexerrmsg[MAXREXERRMSGLEN] ;

char		rexpat[MAXREXLEN] = { '\0' } ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	gnash : general networked administration shell				|
 *		|_______________________________________________________________|
 */

void brashend (rc) int rc ; {

	bralog (BL_INFO, "%s %s (%d) %s\n", versno, "E_N_D", rc, execpathname) ;

	exit (rc) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashexit () {
	extern int grd ;

	lastsockck () ;

	if (interactiveflag) {
		bra_save () ;
	}
/*
	if ( inatty (NULL) ) {
		fprintf (top,"\n<<bye>>\n") ;
	}
*/
	brashend (grd) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void sighand (signo) int signo ; {
	extern int secstoshut ;

	switch ( signo ) {

		case SIGTERM :
			bralog (BL_FATAL, "got SIGTERM ... terminating in %d seconds", secstoshut) ;
			sleep (secstoshut) ;
			bralog (BL_FATAL, "time to die") ;
		break ;

		case SIGINT :
			bralog (BL_FATAL, "interrupted") ;
		break ;

		case SIGSEGV :
			bralog (BL_FATAL, "bad segment") ;
		break ;

		default :
			bralog (BL_FATAL, "unpredicted signal (%d) ...", signo) ;
		break ;
	}

	brashexit () ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	chop ...													|
 *		|_______________________________________________________________|
 */

int strchop (tp, ap) char * tp , * * ap ; {

	register int sk = 0 ;

	for ( ; ; ) {

		while ( *tp == ' ' || *tp == '\t' )
			++tp ;

		if ( *tp == '\0' )
			break ;

		*ap++ = tp ;

		while ( *tp && *tp != ' ' && *tp != '\t' )
			++tp ;

		if (*tp)
			*tp++ = '\0' ;

		++sk ;
	}

	return sk ;
}

int bra_chop (buff) char * buff ; {

	if ( buff == NULL )
		return -1 ;

	strncpy ( chopbuff , buff , CHOPBUFFSIZE ) ;
	chopbuff [ TEMPBUFFSIZE - 1 ] = '\0' ;

	return strchop ( chopbuff , chopvect ) ;
}

int setchopopt (nam, val) char * nam ; int val ; {
	int rd = SYSBAD ;

	if ( 0 == strcmp ( nam , "parachop" ) ) {
		maxparachop = val ;
		rd = SYSGOOD ;
	} else if ( 0 == strcmp ( nam , "maxchops" ) ) {
		maxchopslic = val ;
		rd = SYSGOOD ;
	}

	return rd ;
}

int setchopent (buff) char * buff ; {
	int inx = 0 ;

	if ( buff == NULL ) {
		return -1 ;
	}

	return inx ;
}

char * getchopent (inx) int inx ; {
	char * tep = NULL ;

	if ( inx < 0 ) {
		return NULL ;
	}

	return tep ;
}

void endchopent (inx) int inx ; {

	if ( inx < 0 ) {
		return ;
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	time ...													|
 *		|_______________________________________________________________|
 */

char * timestamp (tloc, tflg) time_t tloc ; int tflg ; {

	static char buf [64] ;
	register char * fmt = NULL ;
	register char * bp ;
	register struct tm * tp ;
	int ex  = 0 ;

	tp = localtime ( &tloc ) ;
	bp = buf ;

	if ( tflg & RAWSTAMP ) {
		fmt = "%4d%02d%02d%02d%02d%02d" ;
		if ( tflg & DATSTAMP ) {
			ex = 8 ;
		}
		if ( tflg & TIMSTAMP ) {
			bp += 8 ;
		}
	}

	if ( tflg & PLUSTAMP ) {
		fmt = "%4d/%02d/%02d+%02d:%02d:%02d" ;
		if ( tflg & DATSTAMP ) {
			ex = 10 ;
		}
		if ( tflg & TIMSTAMP ) {
			bp += 11 ;
		}
	}

	sprintf ( buf , fmt ,

				tp->tm_year + 1900 , tp->tm_mon + 1 , tp->tm_mday ,
				tp->tm_hour , tp->tm_min , tp->tm_sec				) ;

	if ( ex != 0 ) {
		buf[ex] = '\0' ;
	}

	return bp ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	hist ...													|
 *		|_______________________________________________________________|
 */

void bra_hist (ofp) FILE * ofp ; {
	register HIST_ENTRY * * tmp_list ;
	register int i ;

	tmp_list = history_list () ;

	if (tmp_list)
		for ( i = 0 ; tmp_list[i] ; i++ )
			fprintf ( ofp, "%5d :\t%s\n", i + history_base, tmp_list[i]->line ) ;
}

void brahistory (char * histbuf) {
	FILE * histfp ;

	/* FIXME: lock hist file */
	histfp = fopen (brahistpath, "a") ;
	if ( histfp == NULL ) {
		/* FIXME: ? unlock ? hist file */
		return ;
	}
	fprintf (histfp, "%s %s@%s %s[%d] = ",
			timestamp ( time (NULL) , PLUSTAMP ),
			thisuser, thishost,
			thisexec, locpid) ;
	fprintf (histfp, "%s", histbuf) ;
	fclose (histfp) ;
	/* FIXME: unlock hist file */
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bralog (int t, char *s, ...) {
    va_list p;

    va_start(p, s);
    fflush(stdout);
	logfp = fopen (bralogpath, "a") ;
	if ( logfp == NULL ) {
		logfp = stderr ;
	}
	switch (t) {
		case		BL_DEBUG	:	logtag = LP_DEBUG ;			break ;
		default :					logtag = "?????" ;			break ;
	}
	fprintf (logfp, "%s %s %s@%s %s[%d] : ",
			logtag,
			timestamp ( time (NULL) , PLUSTAMP ),
			thisuser, thishost,
			thisexec, locpid) ;
    vfprintf(logfp, s, p);
	fprintf (logfp, "%s", "\n") ;
	if ( logfp != stderr ) {
		fclose (logfp) ;
	}
    va_end(p);
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void braerr (action, object) char * action , * object ; {

	char * sep = "undefined" ;

	if ( errno > 0 ) {
		sep = strerror (errno) ;
	}
	bralog (BL_ERR, "%s(%s) = \"%s\"(%d)", action, object, sep, errno) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bratrace (what) char * what ; {

	bralog (BL_TRACE, "%s", what) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int inatty (fp) FILE * fp ; {
	if ( fp == NULL ) {
		fp = stdin ;
	}
	if ( isatty ( fileno (fp) ) ) {
		return TRUE ;
	}
	return FALSE ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	help ...													|
 *		|_______________________________________________________________|
 */

void bra_help (ofp) FILE * ofp ; {
	/* FIXME: cat helpfile */
	fprintf ( ofp, "%s\n", "bye\tterminate"									) ;
	fprintf ( ofp, "%s\n", "cd"												) ;
	fprintf ( ofp, "%s\n", "date"											) ;
	fprintf ( ofp, "%s\n", "drop"											) ;
	fprintf ( ofp, "%s\n", "exit\tterminate"								) ;
	fprintf ( ofp, "%s\n", "help"											) ;
	fprintf ( ofp, "%s\n", "info"											) ;
	fprintf ( ofp, "%s\n", "list"											) ;
	fprintf ( ofp, "%s\n", "ll"												) ;
	fprintf ( ofp, "%s\n", "ls"												) ;
	fprintf ( ofp, "%s\n", "match"											) ;
	fprintf ( ofp, "%s\n", "node"											) ;
	fprintf ( ofp, "%s\n", "pwd"											) ;
	fprintf ( ofp, "%s\n", "quit\tterminate"								) ;
	fprintf ( ofp, "%s\n", "status"											) ;
	fprintf ( ofp, "%s\n", "time"											) ;
	fprintf ( ofp, "%s\n", "try"											) ;
	fprintf ( ofp, "%s\n", "uname"											) ;
	fprintf ( ofp, "%s\n", "version"										) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_bang (ofp, what) FILE * ofp ; char * what ; {
	char * cmd = shellpath ;

	if ( ofp == NULL )
		return ;

	if ( what != NULL )
		if ( *what != '\0' )
			cmd = what ;

	system (cmd) ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void bra_getwd () {
	if ( getcwd ( currworkpath , PATHBUFFSIZE ) == NULL ) {
		braerr ("get", "cwd") ;
	}
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

char * getlnuid (uid) uid_t uid ; {

	struct passwd * pp ;
	char * tp ;

	pp = getpwuid (uid) ;

	if ( pp == NULL )
		tp = "*unknown*" ;
	else
		tp = pp->pw_name ;

	return tp ;
}

/*\	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
\*/

void getids () {

	locpid  = getpid  () ;
	locuid  = getuid  () ;
	locgid  = getgid  () ;
	loceuid = geteuid () ;
	locegid = getegid () ;

	locuser = getlnuid ( locuid ) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	 	|															|
 *	 	|	brash tree												|
 *	 	|															|
 *	 	|	.brash/													|
 *	 	|		acl													|
 *	 	|			obj;user;group;perms							|
 *	 	|		niche/												|
 *	 	|			default/										|
 *	 	|				datatree(as below)							|
 *	 	|			nichename/										|
 *	 	|				log											|
 *	 	|				history										|
 *	 	|															|
 *		|___________________________________________________________|
 */

char *		nichedir			=	BRA_NICHEDIR ;
char *		currnichname		=	DFL_NICHNAME ;

void bra_preptree () {

}

void bra_prepfile () {

}

void bra_env (nam, ver, frg) char * nam , * ver , * frg ; {
	register char * tp ;
/*
	FILE * tfp ;
	logtag = execname ;
*/
	swname = nam ;
	versno = ver ;
	forgid = frg ;

	getids () ;

	tp = getenv ("HOME") ;

	if ( tp == NULL ) {
		tp = "." ;
	}

	strcpy ( homepath , tp ) ;

	tp = getenv ("SHELL") ;

	if ( tp == NULL ) {
		tp = "/bin/sh" ;
	}

	strcpy ( shellpath , tp ) ;

	tp = getenv (brashvar) ;

	if ( tp == NULL ) {
		sprintf (brashdir, "%s/%s", homepath, DOTBRASHNAME) ;
	} else {
		if ( *tp == '-' ) {
/*
			brargc = strclip ( tp , brargv , ' ' ) ;
			bra_parse ( brargc , brargv ) ;
*/
			sprintf (brashdir, "%s/%s", ".", DOTBRASHNAME) ;
		} else {
			strcpy (brashdir, tp) ;
		}
	}

	sprintf (bralogpath , "%s", DFL_LOGSFILE) ;

	bra_preptree () ;

	if ( stat ( brashdir , &tsb ) == 0 ) {
		if ( ! ( S_ISDIR(tsb.st_mode) ) ) {
			bralog (BL_ERR, "'%s' is not a directory", brashdir) ;
			/* rename ( brashdir , whatever ) ; */
			strcpy (brashdir, ".") ;
		}
	} else {
		bralog (BL_ERR, "'%s' not found", brashdir) ;
		if ( createdir (brashdir, brashmode) != 0 ) {
			strcpy (brashdir, ".") ;
		}
	}

	bra_prepfile () ;

	sprintf (bralogpath   , "%s/%s", brashdir, DFL_LOGSFILE) ;
	sprintf (brahistpath  , "%s/%s", brashdir, BRA_HISTFILE) ;
	sprintf (nodtabpath   , "%s/%s", brashdir, BRA_NODEFILE) ;
	sprintf (listabpath   , "%s/%s", brashdir, BRA_LISTFILE) ;
	sprintf (aliastabpath , "%s/%s", brashdir, BRA_LIASFILE) ;
	sprintf (ipv4tabpath  , "%s/%s", brashdir, BRA_IPV4FILE) ;

#ifdef L8R
	sprintf (areatabpath  , "%s/%s", brashdir, BRAREASFILE) ;
	sprintf (arealogpath  , "%s/%s", brashdir, AREA_LOGSFILE) ;

	if ( cleanflag ) {
		if ( ( tfp = fopen (bralogpath, "w") ) != NULL ) {
			fclose (tfp) ;
			cleanflag = 0 ;
			/* FIXME: now must restart ... */
		}
	}
#endif
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	*xfr ...													|
 *		|_______________________________________________________________|
 */

void bra_get (ofp, names, origs) FILE * ofp ; char * names , * origs ; {
	fprintf ( ofp, "bra_get" ) ;
	if ( names != NULL ) {
		fprintf ( ofp, "<%s>", names ) ;
	}
	if ( origs != NULL ) {
		fprintf ( ofp, "[%s]", origs ) ;
	}
	fprintf ( ofp, "%s", "\n" ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_put (ofp, names, dests) FILE * ofp ; char * names , * dests ; {
	fprintf ( ofp, "bra_put" ) ;
	if ( names != NULL ) {
		fprintf ( ofp, "<%s>", names ) ;
	}
	if ( dests != NULL ) {
		fprintf ( ofp, "[%s]", dests ) ;
	}
	fprintf ( ofp, "%s", "\n" ) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	misc ...													|
 *		|_______________________________________________________________|
 */

void bra_cd (ofp) FILE * ofp ; {
	fprintf ( ofp, "%s\n", "cd" ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_ll (ofp) FILE * ofp ; {
	fprintf ( ofp, "%s\n", "ll" ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_ls (ofp, what) FILE * ofp ; char * what ; {
	fprintf ( ofp, "bra_ls" ) ;
	if ( what != NULL ) {
		fprintf ( ofp, "<%s>", what ) ;
	}
	fprintf ( ofp, "%s", "\n" ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int badipv4 (s) char * s ; {
	int oct [4] ;
	int ns ;

	ns = sscanf ( s, "%d.%d.%d.%d", &oct[0], &oct[1], &oct[2], &oct[3] ) ;

	if ( ns != 4 ) {
		bralog (BL_ERR, "malformed ipv4 (%s)", s) ;
		return TRUE ;
	}

	for ( ns = 0 ; ns < 4 ; ++ns ) {
		if ( oct[ns] < 0 || oct[ns] > 255 ) {
			bralog (BL_ERR, "invalid octet #%d (%d)", 1+ns, oct[ns]) ;
			return TRUE ;
		}
	}

	return FALSE ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int bra_goodfile (name) char * name ; {
	int i ;

	i = stat ( name , &tsb ) ;

	if ( i == SYSGOOD ) {
		if ( S_ISREG (tsb.st_mode) ) {
			if ( access (name, R_OK) == 0 ) {
				if ( tsb.st_size <= maxfilsiz ) {	/* good size */
/*
						#lines < maxfilelines ?
						len(line) < maxlinesize ?
*/
					return SYSGOOD ;
				} else {
					return SYSBAD ;
				}
			} else {
				return SYSBAD ;
			}
		} else {
			return SYSBAD ;
		}
	} else {
		return SYSBAD ;
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	node ...													|
 *		|_______________________________________________________________|
 */

void bra_nodeinit () {
	BRACTL * * bpp ;

	if ( branodtab == NULL ) {
		bpp = (BRACTL * *) calloc ( bramaxnod , sizeof (BRACTL *) ) ;
		if ( bpp == NULL ) {
			braerr ("malloc", "controltable") ;
			brashexit () ;
		} else {
			branodtab = bpp ;
		}
	}
}

BRACTL * bra_nodealloc () {
	BRACTL * bp ;

	if ( branodtab == NULL ) {
		bra_nodeinit () ;
	}

	if ( brahostot > brahosact ) {
		/* FIXME: shrink/compact slack space */
		/* scan branodtab[] for NULL entries */
	}

	if ( brahostot >= bramaxnod ) {
		bralog (BL_ALERT, "node table FULL") ;
		return NULL ;
	}

	bp = (BRACTL *) malloc ( BRACTLSIZ ) ;

	if ( bp == NULL ) {
		braerr ("malloc", "node data") ;
		brashexit () ;
	}

	return bp ;
}

int bra_nodefind (what) char * what ; {
	BRACTL * bp ;
	int i ;

	if ( branodtab == NULL )
		return -1 ;

	for ( i = 0 ; i < brahostot ; ++i ) {
		bp = branodtab[i] ;
		if ( bp == NULL ) {
			continue ;
		}
		if ( 0 == strcmp ( what , bp->bra_name ) ) {
			return i ;
		}
		if ( 0 == strcmp ( what , bp->bra_ipv4 ) ) {
			return i ;
		}
		if ( 0 == strcmp ( what , bp->bra_fqdn ) ) {
			return i ;
		}
	}

	return -1 ;
}

void bra_nodeshow (ofp, pos) FILE * ofp ; int pos ; {
	BRACTL * bp ;

	bp = branodtab[pos] ;
	if ( bp == NULL ) {
		return ;
	}
	fprintf ( ofp, "%s %s %s %s %d %d %d\n" , bp->bra_name , bp->bra_doma , bp->bra_fqdn , bp->bra_ipv4 , bp->bra_flag , bp->bra_adrcnt  , bp->bra_alicnt ) ;
}

void bra_nodedump (ofp) FILE * ofp ; {
	int i ;

	for ( i = 0 ; i < brahostot ; ++i ) {
		bra_nodeshow (ofp, i) ;
	}
}

void bra_nodeadd (ofp, what) FILE * ofp ; char * what ; {
	BRACTL * bp ;
	int  rd ;

	rd = bra_nodefind (what) ;

	if ( rd >= 0 ) {
		bra_nodeshow (ofp, rd) ;
		return ;
	}

	if ( ( bp = bra_nodealloc () ) == NULL ) {
		return ;
	}

	bp->bra_flag	= 0x00000000	;
	bp->bra_name	= "-"			;
	bp->bra_doma	= "-"			;
	bp->bra_fqdn	= "-"			;
	bp->bra_ipv4	= "-"			;
	bp->bra_adrcnt	= 0x00			;
	bp->bra_alicnt	= 0x00			;

	if ( strchr ( what , ' ' ) != NULL ) {

		rd = sscanf ( what, "%s %s %s %s %d %d %d" , temphostname , temphostdoma , temphostfqdn , temphostaddr , &temphostflag , &tempadrcount , &tempalicount ) ;

		if ( rd == 7 ) {
			bp->bra_name = strdup (temphostname) ;
			bp->bra_doma = strdup (temphostdoma) ;
			bp->bra_fqdn = strdup (temphostfqdn) ;
			bp->bra_ipv4 = strdup (temphostaddr) ;
			bp->bra_flag = temphostflag ;
			bp->bra_flag = tempadrcount ;
			bp->bra_flag = tempalicount ;
		} else {
			bralog (BL_ALERT, "inclomplete node data (%s)", what) ;
		}

	} else {

		if ( isdigit ( (int) (*what) ) ) {
			bp->bra_ipv4 = strdup (what) ;
			if ( badipv4 (what) ) {
				bp->bra_flag |= BRA_BADIPV4 ;
			} else {
				bp->bra_flag |= BRA_GOODIPV4 ;
			}
			bp->bra_name = strdup ("-") ;
		} else {
			bp->bra_name = strdup (what) ;
			bp->bra_flag |= BRA_GOODNAME ;
			bp->bra_ipv4 = strdup ("-") ;
		}

	}

	branodtab[brahostot++] = bp ;
	branodtab[brahostot]   = NULL ;

	++brahosact ;
}

void bra_nodewipe (pos) int pos ; {
	BRACTL * bp ;

	bp = *(branodtab + pos) ;

	if ( bp == NULL ) {
		bralog (BL_ALERT, "*** bug: rewipe node (%d)", pos) ;
		return ;
	}

	free ( bp ) ;
	branodtab[pos] = NULL ;

	--brahosact ;
}

void bra_nodechg (ofp, what) FILE * ofp ; char * what ; {
	int i ;
	char * tp ;
	char tempwhat [MAXHOSTNAMELEN] ;

	if ( ( tp = strchr ( what , ' ' ) ) != NULL ) {
		strncpy ( tempwhat , what , tp - what ) ;
		/* tempwhat [ tp - what ] = '\0' ; */
	} else {
		strcpy ( tempwhat , what ) ;
	}

	i = bra_nodefind (tempwhat) ;

	if ( i >= 0 ) {
		bra_nodewipe (i) ; /* FIXME: check for side-effects and 'propagate' .. */
	}

	bra_nodeadd (ofp, what) ;
}

void bra_nodeload (ifp, ofp) FILE * ifp , * ofp ; {
	char * ep ;

	while ( NULL != fgets (tempbuff, MAXHOSTNAMELEN, ifp) ) {
		if ( *tempbuff == '#' ) {
			continue ;
		}

		ep = tempbuff + strlen (tempbuff) ;
		for ( --ep ; *ep == '\r' || *ep == '\n' ; *ep-- = '\0' )
			;

		bra_nodeadd (ofp, tempbuff) ;
	}
}

void bra_nodefrom (ofp, name) FILE * ofp ; char * name ; {
	FILE * ifp ;

	if ( bra_goodfile (name) != 0 ) {
		bralog (BL_ERR, "improper file (%s)", name) ;
		return ;
	}

	ifp = fopen (name, "r") ;

	if ( ifp == NULL ) {
		braerr ("fopen", name) ;
		return ;
	}

	bra_nodeload (ifp, ofp) ;

	fclose (ifp) ;
}

void bra_nodeswell (ofp, what) FILE * ofp ; char * what ; {
	int i ;

	/* FIXME: split (what,' ') and iterate */
/*
        nchops = strchop (what, chopvect) ;
*/
		i = stat ( what , &tsb ) ;

		if ( i == 0 ) {								/*	maybe		*/
			if ( S_ISREG (tsb.st_mode) ) {				/*	file		*/
				if ( access (what, R_OK) == 0 ) {			/*	readable	*/
					bra_nodefrom (ofp, what) ;
				} else {
					bra_nodeadd (ofp, what) ;
				}
			} else {
				bra_nodeadd (ofp, what) ;
			}
		} else {
			bra_nodeadd (ofp, what) ;
		}

	/* FIXME: split (what,' ') and iterate */
}

void bra_node (ofp, what) FILE * ofp ; char * what ; {
	if ( what == NULL ) {
		if ( brahosact <= 0 ) {
			fprintf ( ofp, "%s\n", "zilch" ) ;
		} else {
			bra_nodedump (ofp) ;
		}
	} else {
		bra_nodeswell (ofp, what) ;
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	list ...													|
 *		|_______________________________________________________________|
 */

void bra_listmold () {
	BRALIS * * lpp ;

	if ( bralistab == NULL ) {
		lpp = (BRALIS * *) calloc ( bramaxlis , sizeof (BRALIS *) ) ;
		if ( lpp == NULL ) {
			braerr ("malloc", "list-table") ;
			brashexit () ;
		} else {
			bralistab = lpp ;
		}
	}
}

BRALIS * bra_listalloc () {
	BRALIS * lp ;
	char * * cpp ;

	lp = (BRALIS *) malloc ( BRALISSIZ ) ;

	if ( lp == NULL ) {
		braerr ("malloc", "list-data") ;
		brashexit () ;
	}

	cpp = (char * *) malloc ( maxlisent * sizeof (char *) ) ;

	if ( cpp == NULL ) {
		braerr ("malloc", "list-entry") ;
		brashexit () ;
	} else {
		lp->lis_data = cpp ;
	}

	return lp ;
}

void bra_listshow (ofp, what) FILE * ofp ; char * what ; {
	BRALIS * lp ;
	int i, j, found = FALSE ;

	if ( bralistab == NULL ) {
		fprintf ( ofp, "%s\n" , "no lists" ) ;
		return ;
	}

	for ( j = 0 ; j < bralistot ; ++j ) {
		lp = bralistab[j] ;
		if ( lp == NULL ) {
			continue ;
		}
		if ( 0 == strcmp ( what , lp->lis_name ) ) {
			found = TRUE ;
			if ( lp->lis_size <= 0 ) {
				fprintf ( ofp, "%s %s\n" , lp->lis_name , "empty" ) ;
			} else {
				for ( i = 0 ; i < lp->lis_size ; ++i ) {
					fprintf ( ofp, "%s %s\n" , lp->lis_name , lp->lis_data[i] ) ;
				}
			}
			break ;
		}
	}

	if ( ! found ) {
		fprintf (ofp, "list '%s' not found\n", what) ;
	}
}

int bra_listfind (what) char * what ; {
	BRALIS * lp ;
	int j = -1 ;

	if ( bralistab == NULL )
		return j ;

	for ( j = 0 ; j < bralistot ; ++j ) {
		lp = bralistab[j] ;
		if ( lp == NULL ) {
			continue ;
		}
		if ( 0 == strcmp ( what , lp->lis_name ) ) {
			return j ;
		}
	}

	return -1 ;
}

void bra_listdump (ofp) FILE * ofp ; {
	BRALIS * lp ;
	int j = -1 ;

	if ( bralistab == NULL )
		return ;

	for ( j = 0 ; j < bralistot ; ++j ) {
		lp = bralistab[j] ;
		if ( lp == NULL ) {
			continue ;
		}
		if ( 0 != strcmp ( REXLSTNAM , lp->lis_name ) ) {
			bra_listshow (ofp, lp->lis_name) ;
		}
	}
}

void bra_listmake (what) char * what ; {
	BRALIS * lp ;

	if ( bralistab == NULL ) {
		bra_listmold () ;
	}

	if ( bralistot > bralisact ) {
		/* FIXME: shrink/compact slack space */
		/* scan bralistab[] for NULL entries */
	}

	if ( bralistot < bramaxlis ) {
		lp = bra_listalloc () ;
	} else {
		bralog (BL_ALERT, "list-table FULL") ;
		return ;
	}

	lp->lis_flag = 0x00000000 ;
	lp->lis_size = 0 ;
	lp->lis_name = strdup (what) ;

	bralistab[bralistot++] = lp ;
	bralistab[bralistot]   = NULL ;

	++bralisact ;
}

void bra_listhang (what, elem) char * what , * elem ; {
	BRALIS * lp ;
	char * * cpp ;
	char * cp ;
	int i ;

	i = bra_listfind (what) ;

	if ( i < 0 ) {
		bra_listmake (what) ;
		i = bra_listfind (what) ;
	}

	lp = *(bralistab + i) ;

	if ( lp->lis_size >= maxlisent ) {
		bralog (BL_ALERT, "entry-table FULL") ;
		return ;
	}

	cpp = lp->lis_data ;
	cpp += lp->lis_size ;

	cp = strdup (elem) ;

	if ( cp == NULL ) {
		braerr ("malloc", "list entry") ;
		return ;
	}

	*cpp = cp ;
	lp->lis_size += 1 ;
}

void bra_listfrom (what, name) char * what , * name ; {
	FILE * ifp ;
	char * ep ;

	if ( bra_goodfile (name) != 0 ) {
		bralog (BL_ERR, "improper file (%s)", name) ;
		return ;
	}

	ifp = fopen (name, "r") ;

	if ( ifp == NULL ) {
		bra_listhang (what, "void") ;
		return ;
	}

	while ( NULL != fgets (tempbuff, MAXHOSTNAMELEN, ifp) ) {
		if ( *tempbuff == '#' ) {
			continue ;
		}

		ep = tempbuff + strlen (tempbuff) ;
		for ( --ep ; *ep == '\r' || *ep == '\n' ; *ep-- = '\0' )
			;

		bra_listhang (what, tempbuff) ;
	}

	fclose (ifp) ;
}

void bra_listwipe (pos) int pos ; {
	BRALIS * lp ;
	int i ;

	lp = *(bralistab + pos) ;

	if ( lp->lis_size > 0 ) {
		for ( i = 0 ; i < lp->lis_size ; ++i ) {
			if ( lp->lis_data[i] != NULL ) {
				free ( lp->lis_data[i] ) ;
			}
		}
	}

	lp->lis_size = -1 ;
	lp->lis_flag = 0x00000000 ;
	free ( lp->lis_name ) ;
	lp->lis_name = NULL ;

	--bralisact ;
}

void bra_listgrow (ofp, what, elem) FILE * ofp ; char * what , * elem ; {
	int i ;

	if ( ofp == NULL )
		return ;

	i = bra_listfind (what) ;

	if ( i < 0 ) {
		bra_listmake (what) ;
	}

	/* FIXME: split (elem,' ') and iterate */
/*
        nchops = strchop (elem, chopvect) ;
*/
		i = stat ( elem , &tsb ) ;

		if ( i == 0 ) {								/*	maybe		*/
			if ( S_ISREG (tsb.st_mode) ) {				/*	file		*/
				if ( access (elem, R_OK) == 0 ) {			/*	readable	*/
					bra_listfrom (what, elem) ;
				} else {
					bra_listhang (what, elem) ;
				}
			} else {
				bra_listhang (what, elem) ;
			}
		} else {
			bra_listhang (what, elem) ;
		}

	/* FIXME: split (elem,' ') and iterate */
}

void bra_listinit (ofp, what, elem) FILE * ofp ; char * what , * elem ; {
	int i ;

	i = bra_listfind (what) ;

	if ( i >= 0 ) {
		bra_listwipe (i) ;
	} else {
		bra_listmake (what) ;
	}

	if ( 0 != strcmp ( what , REXLSTNAM ) ) {
		bra_listgrow (ofp, what, elem) ;
	}
}

void bra_listdrop (ofp, what, elem) FILE * ofp ; char * what , * elem ; {
	fprintf ( ofp, "- list (%s) drop (%s)\n", what , elem ) ;
}

void bra_listproc (ofp, what, oper, elem) FILE * ofp ; char * what , * oper , * elem ; {
	switch (*oper) {
		case '=' : bra_listinit (ofp, what, elem) ;      break ;
		case '+' : bra_listgrow (ofp, what, elem) ;      break ;
		case '-' : bra_listdrop (ofp, what, elem) ;      break ;
		default : bralog (BL_ERR, "bad list oper (%c)", oper) ; break ;
	}
}

void bra_listload (ifp, ofp) FILE * ifp , * ofp ; {
	char templist [MAXLISTNAMELEN] ;
	char tempname [MAXHOSTNAMELEN] ;
	char * ep ;
	int rd ;

	if ( ofp == NULL )
		return ;

	/* FIXME: must bra_goodfile (name) */

	while ( NULL != fgets (tempbuff, MAXHOSTNAMELEN, ifp) ) {
		if ( *tempbuff == '#' ) {
			continue ;
		}

		ep = tempbuff + strlen (tempbuff) ;
		for ( --ep ; *ep == '\r' || *ep == '\n' ; *ep-- = '\0' )
			;

		rd = sscanf ( tempbuff, "%s %s" , templist , tempname ) ;

		if ( rd != 2 ) {
			bralog (BL_ERR, "inclomplete list data (%s)", tempbuff) ;
		}

		/* FIXME: skip 'empty' */

		bra_listhang (templist, tempname) ;
		/* bra_listgrow (ofp, templist, tempname) ; */
	}
}

void bra_list (ofp, what) FILE * ofp ; char * what ; {
	if ( what == NULL ) {
		if ( bralisact <= 0 ) {
			fprintf ( ofp, "%s\n", "zippo" ) ;
		} else {
			bra_listdump (ofp) ;
		}
	} else {
		bra_listshow (ofp, what) ;
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	learn ...													|
 *		|_______________________________________________________________|
 */

void bra_learn (ofp, what) FILE * ofp ; char * what ; {
	if ( what == NULL ) {
		fprintf ( ofp, "%s\n", "skynet self aware" ) ;
	} else {
		fprintf ( ofp, "learn(%s)\n", what ) ;
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	alias ...													|
 *		|_______________________________________________________________|
 */

void bra_aliadd (ofp, hname, alias) FILE * ofp ; char * hname , * alias ; {
	fprintf ( ofp, "- hname (%s) alias (%s)\n", hname , alias ) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	address ...													|
 *		|_______________________________________________________________|
 */

void bra_addradd (ofp, hname, iaddr) FILE * ofp ; char * hname , * iaddr ; {
	fprintf ( ofp, "- hname (%s) iaddr (%s)\n", hname , iaddr ) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	match ...													|
 *		|_______________________________________________________________|
 */

void bra_rex (ofp, what) FILE * ofp ; char * what ; {
	BRACTL * bp ;
    int status ;
	int i ;

	strcpy ( tempbuff , what ) ;

	status = regcomp ( &rexbuf, tempbuff, REG_EXTENDED ) ;

    if (status != 0) {
		regerror (status, &rexbuf, rexerrmsg, MAXREXERRMSGLEN) ;
		fprintf (ofp, "pattern <%s> rejected : (%s)\n", tempbuff, rexerrmsg) ;
		return ;
	}

	if ( brahostot <= 0 ) {
		fprintf (ofp, "node table is empty\n") ;
		return ;
	}

	strcpy ( rexpat , tempbuff ) ;

	bra_listinit (ofp, REXLSTNAM, NULL) ;

	for ( i = totrexmat = 0 ; i < brahostot ; ++i ) {
		bp = branodtab[i] ;
		if ( bp == NULL ) {
			continue ;
		}
		if ( ( regexec ( &rexbuf , bp->bra_name , 0 , (regmatch_t *)NULL , 0 ) ) == 0 ) {
			/* bra_listgrow (ofp, REXLSTNAM, bp->bra_name) ; */
			bra_listhang (REXLSTNAM, bp->bra_name) ;
			++totrexmat ;
		}
	}

	if ( totrexmat > 0 ) {
		bra_listshow (ofp, REXLSTNAM) ;
	} else {
		fprintf (ofp, "no matches\n") ;
	}
}

void bra_match (ofp, what) FILE * ofp ; char * what ; {

	if ( what == NULL ) {
		if ( *rexpat == '\0' ) {
			fprintf ( ofp, "%s\n", "pattern not defined" ) ;
		} else {
			fprintf ( ofp, "<%s>\n", rexpat ) ;
		}
	} else {
		bra_rex (ofp, what) ;
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	persistence ...												|
 *		|_______________________________________________________________|
 */

void bra_save () {
	FILE * fp ;

	bratrace ("start save") ;

	fp = fopen (nodtabpath, "w") ;

	if ( fp != NULL ) {
		bra_nodedump (fp) ;
		fclose (fp) ;
	} else {
		braerr ("fopen", nodtabpath) ;
	}

	fp = fopen (listabpath, "w") ;

	if ( fp != NULL ) {
		bra_listdump (fp) ;
		fclose (fp) ;
	} else {
		braerr ("fopen", listabpath) ;
	}

	bratrace ("end save") ;
}

void bra_load () {
	FILE * fp ;
	static int nomore = FALSE ;

	if ( nomore ) {
		return ;
	}

	bratrace ("start load") ;

	fp = fopen (nodtabpath, "r") ;

	if ( fp != NULL ) {
		bra_nodeload (fp, stdout) ;
		fclose (fp) ;
	} else {
		braerr ("fopen", nodtabpath) ;
	}

	fp = fopen (listabpath, "r") ;

	if ( fp != NULL ) {
		bra_listload (fp, stdout) ;
		fclose (fp) ;
	} else {
		braerr ("fopen", listabpath) ;
	}

	nomore = TRUE ;
	bratrace ("end load") ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	drop ...													|
 *		|_______________________________________________________________|
 */

void bra_dropnode (ofp, what) FILE * ofp ; char * what ; {
	int i = -1 ;

	i = bra_nodefind (what) ;

	if ( i >= 0 ) {
		bra_nodewipe (i) ;
	} else {
		fprintf ( ofp, "node {%s} unknown\n", what ) ;
	}
}

void bra_droplist (ofp, what) FILE * ofp ; char * what ; {
	int i = -1 ;

	i = bra_listfind (what) ;

	if ( i >= 0 ) {
		bra_listwipe (i) ;
	} else {
		fprintf ( ofp, "list {%s} unknown\n", what ) ;
	}
}

void bra_dropany (ofp, what) FILE * ofp ; char * what ; {
	int islist = -1 , isnode = -1 ;

	isnode = bra_nodefind (what) ;
	islist = bra_listfind (what) ;

	if ( isnode >= 0 && islist >= 0 ) {
		fprintf ( ofp, "ambiguous {%s} : selector required\n", what ) ;
		return ;
	}

	if ( isnode < 0 && islist < 0 ) {
		fprintf ( ofp, "unrecognized {%s}\n", what ) ;
		return ;
	}

	if ( isnode >= 0 ) {
		bra_nodewipe ( isnode ) ;
	}

	if ( islist >= 0 ) {
		bra_listwipe ( islist ) ;
	}
}

void bra_drop (ofp, what) FILE * ofp ; char * what ; {
	int i , n ;

	fprintf ( ofp, "%s ", "drop" ) ;
	if ( what == NULL ) {
		fprintf ( ofp, "%s\n", "?null?" ) ;
		return ;
	}
	if ( *what == '\0' ) {
		fprintf ( ofp, "%s\n", "?nothing?" ) ;
		return ;
	}
	fprintf ( ofp, "(%s)\n", what ) ;

	if ( ( n = bra_chop (what) ) > 0 ) {
		for ( i = 0 ; i < n ; ++i ) {
			fprintf ( ofp, "{%s}\n", chopvect[i] ) ;
			bra_dropany ( ofp , chopvect[i] ) ;
		}
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_info (ofp, what) FILE * ofp ; char * what ; {
	int i ;
#ifdef COWBOY
	int n ;
#else
	char * tp ;
#endif

	fprintf ( ofp, "%s ", "info" ) ;
	if ( what == NULL ) {
		fprintf ( ofp, "%s\n", "?null?" ) ;
		return ;
	}
	if ( *what == '\0' ) {
		fprintf ( ofp, "%s\n", "?empty?" ) ;
		return ;
	}
	fprintf ( ofp, "(%s)\n", what ) ;

#ifdef COWBOY
	if ( ( n = bra_chop (what) ) > 0 ) {
		for ( i = 0 ; i < n ; ++i ) {
			fprintf ( ofp, "{%s}\n", chopvect[i] ) ;
			/* bra_infoany ( ofp , chopvect[i] ) ; */
		}
	}
#else
	i = setchopent (what) ;
	while ( ( tp = getchopent (i) ) != NULL ) {
		fprintf ( ofp, "{%s}\n", tp ) ;
	}
	endchopent (i) ;
#endif
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_pwd (ofp) FILE * ofp ; {
	if ( getcwd ( currworkpath , PATHBUFFSIZE ) == NULL ) {
		braerr ("get", "cwd") ;
		strcpy ( currworkpath , "* failed *" ) ;
	}
	fprintf ( ofp, "%s\n", currworkpath ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_try (ofp, what) FILE * ofp ; char * what ; {
	int i, n ;

	fprintf ( ofp, "%s ", "try" ) ;
	if ( what == NULL ) {
		fprintf ( ofp, "%s\n", "?null?" ) ;
		return ;
	}
	if ( *what == '\0' ) {
		fprintf ( ofp, "%s\n", "?empty?" ) ;
		return ;
	}
	fprintf ( ofp, "(%s)\n", what ) ;

	if ( ( n = bra_chop (what) ) > 0 ) {
		for ( i = 0 ; i < n ; ++i ) {
			fprintf ( ofp, "{%s}\n", chopvect[i] ) ;
			/* bra_tryany ( ofp , chopvect[i] ) ; */
		}
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	dns / dig ...												|
 *		|_______________________________________________________________|
 */

void bra_dnsany (ofp, what) FILE * ofp ; char * what ; {
	struct hostent *	hepn = NULL , * hepa = NULL ;
	struct in_addr		iab ;
	char * *			hal ;
	char *				tp ;
	int					adrcnt , alicnt ;
	int					tempflag = 0x00 ;

	if ( badipv4 ( what ) ) {
		if ( ( hepn = gethostbyname (what) ) == NULL ) {
			fprintf ( ofp, "* unknown (%s)\n", what ) ;
			braerr ("gethostbyname", what) ;
			return ;
		}
		memcpy ( &iab.s_addr, *(hepn->h_addr_list), sizeof (iab.s_addr) ) ;
		strcpy (temphostaddr, inet_ntoa (iab)) ;
		tempflag |= BRA_GOODIPV4 ;
		strcpy (temphostname, what) ;
		tempflag |= BRA_GOODNAME ;
		for ( hal = hepn->h_aliases , alicnt = 0 ; *hal != NULL ; ++hal , ++alicnt ) {
			bra_aliadd ( ofp , hepn->h_name , *hal ) ;
		}
		if ( ( tempalicount = alicnt ) > 0 ) {
			tempflag |= BRA_HALIASES ;
		}
		for ( hal = hepn->h_addr_list , adrcnt = 0 ; *hal != NULL ; ++hal , ++adrcnt ) {
			memcpy ( &iab.s_addr, *hal, sizeof (iab.s_addr) );
			bra_addradd ( ofp , hepn->h_name , inet_ntoa (iab) ) ;
		}
		if ( ( tempadrcount = adrcnt ) > 1 ) {
			tempflag |= BRA_MADDRESS ;
		}
	} else {
		if ( inet_pton (AF_INET, what, &iab) > 0 ) {
			strcpy (temphostaddr, what) ;
			tempflag |= BRA_GOODIPV4 ;
		} else {
			fprintf ( ofp, "* invalid (%s)\n", what ) ;
			braerr ("inet_pton", what) ;
			return ;
		}
	}

	if ( ( hepa = gethostbyaddr ( (void *) &iab, sizeof iab, AF_INET ) ) == NULL ) {
		fprintf ( ofp, "* unknown (%s)\n", temphostaddr ) ;
		braerr ("gethostbyaddr", temphostaddr) ;
		return ;
	}

	strcpy (temphostfqdn, hepa->h_name) ;
	tempflag |= BRA_GOODFQDN ;

	if ( ( tp = strchr ( temphostfqdn , '.'  ) ) != NULL )  {
		strcpy ( temphostdoma ,  tp + 1 ) ;
		tempflag |= BRA_GOODOMAIN ;
	} else {
		strcpy ( temphostdoma ,  "-" ) ;
	}
/*
	for ( hal = hepa->h_aliases , alicnt = 0 ; *hal != NULL ; ++hal , ++alicnt ) {
		bra_aliadd ( ofp , hepa->h_name , *hal ) ;
	}

	if ( ( tempalicount = alicnt ) > 0 ) {
		tempflag |= BRA_HALIASES ;
	}

	for ( hal = hepn->h_addr_list , adrcnt = 0 ; *hal != NULL ; ++hal , ++adrcnt ) {
		memcpy ( &iab.s_addr, *hal, sizeof (iab.s_addr) );
		bra_addradd ( ofp , hepa->h_name , inet_ntoa (iab) ) ;
	}

	if ( ( tempadrcount = adrcnt ) > 1 ) {
		tempflag |= BRA_MADDRESS ;
	}
*/
	temphostflag = tempflag ;

	sprintf (
		tempbuff , "%s %s %s %s %d %d %d" ,
		temphostname , temphostdoma , temphostfqdn , temphostaddr ,
		temphostflag , tempadrcount , tempalicount
	) ;

	bra_nodechg (ofp, tempbuff) ;
}

void bra_dns (ofp, what) FILE * ofp ; char * what ; {
	int i, n ;

	fprintf ( ofp, "%s ", "dns" ) ;
	if ( what == NULL ) {
		fprintf ( ofp, "%s\n", "?null?" ) ;
		return ;
	}
	if ( *what == '\0' ) {
		fprintf ( ofp, "%s\n", "?empty?" ) ;
		return ;
	}
	fprintf ( ofp, "(%s)\n", what ) ;

	if ( ( n = bra_chop (what) ) > 0 ) {
		for ( i = 0 ; i < n ; ++i ) {
			bra_dnsany ( ofp , chopvect[i] ) ;
		}
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	date / time ...												|
 *		|_______________________________________________________________|
 */

void bra_date (ofp) FILE * ofp ; {
	fprintf ( ofp, "%s\n", timestamp ( time(NULL) , DATSTAMP|PLUSTAMP ) ) ;
}

void bra_ctime (ofp) FILE * ofp ; {
	time_t tloc ;
	struct tm * tmp ;
	static char tbuf [128] ;
	int rd ;

	time (&tloc) ;
	tmp = localtime (&tloc) ;
#ifdef ORIG
	fprintf ( ofp, "%s ", tzname[tmp->tm_isdst] ) ;
	fprintf ( ofp, "%s", ascctime ( tmp ) ) ;
#else
	rd = strftime ( tbuf , 128 , "%a %b %2d %T %Z %Y" , tmp ) ;
	if ( rd == 0 ) {
		braerr ("strftime", "buffer") ;
	} else {
		fprintf ( ofp, "%s\n", tbuf ) ;
	}
#endif
}

void bra_time (ofp) FILE * ofp ; {
	fprintf ( ofp, "%s\n", timestamp ( time(NULL) , TIMSTAMP|PLUSTAMP ) ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_vers (ofp) FILE * ofp ; {
	showversion (ofp, swname, versno, forgid, verboseflag) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_uname (ofp) FILE * ofp ; {
	fprintf ( ofp , "%s %s %s %s\n" ,
		getnodename () ,
		getosname () ,
		getosvers () ,
		getcpuinf ("model") 
	) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_with (ofp, list, cmds) FILE * ofp ; char * list , * cmds ; {
	fprintf ( ofp, "with list (%s) cmds (%s)\n", list , cmds ) ;
/*
	FIXME: chop (list) ; iterate ;
*/
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void bra_status (ofp) FILE * ofp ; {
	fprintf ( ofp, "local host = %s\n", localhostname ) ;
	fprintf ( ofp, "local addr = %s\n", localhostaddr ) ;
	fprintf ( ofp, "local user = %s\n", locuser ) ;
	fprintf ( ofp, "local uid  = %d\n", locuid ) ;
	fprintf ( ofp, "local gid  = %d\n", locgid ) ;
	fprintf ( ofp, "exec name  = %s\n", execpathname ) ;
	fprintf ( ofp, "work dir   = %s\n", currworkpath ) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# ifndef _HAS_READLINE_

HIST_ENTRY **history_list PARAMS((void)) {

	HIST_ENTRY **	histentp	=	NULL ;

	return histentp ;
}

# endif

/*
 * vi:nu ts=4
 */

