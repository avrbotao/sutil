
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'BRASH' (the basic remote administration shell) |
 | as released by Alexandre Botao <botao.org> ;                         |
 |                                                                      |
 | 'BRASH' is Free and Open Source software (FOSS). This means you can  |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'BRASH' is distributed in the hope that it will be useful,           |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'BRASH'.  If not, see <http://www.gnu.org/licenses/>, or  |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# ifndef _BRASH_H_

# define _BRASH_H_

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# include <stdio.h>
# include <ctype.h>
# include <stdarg.h>
# include <stdlib.h>
# include <string.h>
# include <errno.h>
# include <fcntl.h>
# include <time.h>
# include <unistd.h>
# include <strings.h>
# include <regex.h>

# ifdef USE_IO_H
# include <io.h>
# endif /* USE_IO_H */

# include <sys/types.h>
# include <sys/stat.h>
# include <sys/socket.h>
# include <sys/wait.h>
# include <netinet/in.h>
# include <arpa/inet.h>

# include <netdb.h>
# include <signal.h>

# include <pwd.h>

# ifdef BRASHLY
int yyparse () ;
# endif /* BRASHLY */

# include	"configure.h"
# include	"params.h"

# ifdef	_HAS_READLINE_

# include <readline/readline.h>
# include <readline/history.h>

# else  /*	_HAS_READLINE_	*/

#ifdef __STDC__
typedef void *histdata_t;
#else
typedef char *histdata_t;
#endif

/* The structure used to store a history entry. */
typedef struct _hist_entry {
  char *line;
  char *timestamp;              /* char * rather than time_t for read/write */
  histdata_t data;
} HIST_ENTRY;

HIST_ENTRY **history_list PARAMS((void));

# endif /*	_HAS_READLINE_	*/

# include	"zest.h"
# include	"stdxut.h"

# include	"librash.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# ifndef	TRUE
# define	TRUE		(-1)
# endif  /* TRUE */
# ifndef	FALSE
# define	FALSE		(0)
# endif  /* FALSE */

# define	SYSGOOD		0
# define	SYSBAD		-1

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct	bractl	{
	char *	bra_name ;
	char *	bra_doma ;
	char *	bra_fqdn ;
	char *	bra_ipv4 ;
	char *	bra_ipv6 ;
	int *	bra_ports ;
	int		bra_sock ;
	int		bra_adrcnt ;
	int		bra_alicnt ;
	int		bra_flag ;
} ;

typedef		struct bractl		BRACTL ;

# define	BRACTLSIZ			sizeof(BRACTL)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct	bralis	{
	char *		lis_name ;
	char * *	lis_data ;
	int			lis_size ;
	int			lis_flag ;
} ;

typedef		struct bralis		BRALIS ;

# define	BRALISSIZ			sizeof(BRALIS)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct	braddr	{
	char *		adr_name ;
	char *		adr_data ;
} ;

typedef		struct braddr		BRADDR ;

# define	BRADDRSIZ			sizeof(BRADDR)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

struct	bralias	{
	char *		ali_name ;
	char *		ali_data ;
} ;

typedef		struct bralias		BRALIAS ;

# define	BRALIASIZ			sizeof(BRALIAS)

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

typedef		struct hostent			HOSTENT ;
typedef		struct sockaddr			SOCKADDR ;
typedef		struct sockaddr_in		SOCKADDRIN ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	BL_EMERG      0x0001
# define	BL_ALERT      0x0002
# define	BL_CRIT       0x0004
# define	BL_ERR        0x0008
# define	BL_WARN       0x0010
# define	BL_NOTIC      0x0020
# define	BL_INFO       0x0040
# define	BL_DEBUG      0x0080
# define	BL_FATAL      0x0100
# define	BL_AUTH       0x0200
# define	BL_TRACE      0x0400

# define	LP_EMERG      "emerg"
# define	LP_ALERT      "alert"
# define	LP_CRIT       "_crit"
# define	LP_ERR        "error"
# define	LP_WARN       "_warn"
# define	LP_NOTIC      "notic"
# define	LP_INFO       "_info"
# define	LP_DEBUG      "debug"
# define	LP_FATAL      "fatal"
# define	LP_AUTH       "_auth"
# define	LP_TRACE      "trace"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	BRA_MAXNOD	32768
# define	BRA_MAXLIS	 1024

# define	MAXLISENT	 2048

# define	MAXCHOP		 2048

# define	BRA_GOODNAME		0x00000001
# define	BRA_GOODIPV4		0x00000002
# define	BRA_GOODOMAIN		0x00000004
# define	BRA_GOODFQDN		0x00000008
# define	BRA_MADDRESS		0x00000010	/* host has multiple addresses	*/
# define	BRA_HALIASES		0x00000020	/* hostname has aliases			*/
# define	BRA_BADIPV4			0x01000000

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	BRA_IDCODE	0x1618033988749894
# define	SAD_IDCODE	0x1054571725336289

# define	BRA_HANDSHAK	0x3141592653589793
# define	BRA_SHAKHAND	0x2718281828459045
# define	BRA_HOOKEDOK	0x1414213562373095
# define	BRA_OKHOOKED	0x1732050807568877

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	DAEMONTAG				"sadmind"
# define	SERVERTAG				"brash_server"
# define	CLIENTTAG				"brash_client"
# define	TESTERTAG				"brash_tester"
# define	INTERPTAG				"brash_cmdlin"

# define	VRUNDIRNAME				"/var/run/brash.d"
# define	VRUNPATHNAME			"/var/run/brash.d/brash"

# define	DFL_PROMPT				"brash> "

# define	DFL_AREANAME			"world"

# define	DOTBRASHNAME			".brash"

# define	BRA_NICHEDIR			"niche"						/*	dir.	*/
# define	DFL_NICHNAME			"default"					/*	dir.	*/

# define	DFL_LOGSFILE			"log"						/*	file	*/

# define	BRA_IPV4FILE			"ipv4s"						/*	file	*/
# define	BRA_LISTFILE			"list"						/*	file	*/
# define	BRA_TAGSFILE			"tags"						/*	file	*/
# define	BRA_NODEFILE			"nodes"						/*	file	*/
# define	BRA_NICKPATH			"nicks"						/*	dir.	*/
# define	BRA_CACHPATH			"cache"						/*	dir.	*/
# define	BRA_TRACFILE			"trace"						/*	file	*/
# define	BRA_HISTFILE			"history"					/*	file	*/

# define	BRA_LIASFILE			"alias"						/*	file	*/
# define	BRA_AREAFILE			"areas"						/*	file	*/

# define	BRASHVAR				"BRASH"

# define	SERVER					0x01
# define	CLIENT					0x02
# define	TESTER					0x04
# define	INTERP					0x08

# define	HEAR					0x01
# define	SPEAK					0x02

# define	SOCKADDRSIZE			(sizeof(SOCKADDR))
# define	SOCKADDRINSIZE			(sizeof(SOCKADDRIN))

# define	DFL_CURRMASK			 0022

# define	DFL_SECSTOSHUT			    3
# define	DFL_PORT				54321
# define	BACKLOG					   10

# define	MEGASIZE			  1048576

# define	MAXUSERNAMELEN			  256
# define	MAXHOSTNAMELEN			  256
# define	MAXLISTNAMELEN			   64
# define	MAXIPV4ADDRLEN			   24	/*	15 + /mask	*/
# define	MAXIPV6ADDRLEN			   80	/*	63 + /mask	*/
# define	MAXMSGLEN				 1024

# define	UNDEFIPADDR				"???.???.???.???"

# define	ERRMSGBUFSIZ			 4096
# define	PROMPTBUFSIZ			   64
# define	CMDLINBUFSIZ			16384
# define	PATHBUFFSIZE			 8192
# define	TEMPBUFFSIZE			65536
# define	CHOPBUFFSIZE		 MEGASIZE
# define	EXECPATHNAMESIZE		 2048

# define	DFL_CURRPATHMODE		 0755

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	DFL_CLABUFSIZ		 MEGASIZE

# define	DFL_MAXFILSIZ		 134217728
# define	DFL_MAXFILENT		 BRA_MAXNOD
# define	DFL_MAXLINSIZ		 MAXHOSTNAMELEN

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	BRA_NIL					'#'
# define	BRA_BAD					'~'
# define	BRA_BYE					'B'
# define	BRA_DAT					'd'
# define	BRA_TIM					't'

# define	BRA_HEL					'?'
# define	BRA_VER					'V'
# define	BRA_STA					'S'
# define	BRA_UNA					'U'

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# endif /* _BRASH_H_ */

/*
 * vi:nu ts=4
 */
