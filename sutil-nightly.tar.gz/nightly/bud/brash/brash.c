
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   brash      basic remote administration shell   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'BRASH' (the basic remote administration shell) |
 | as released by Alexandre Botao <botao.org> ;                         |
 |                                                                      |
 | 'BRASH' is Free and Open Source software (FOSS). This means you can  |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'BRASH' is distributed in the hope that it will be useful,           |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'BRASH'.  If not, see <http://www.gnu.org/licenses/>, or  |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# define	SWNAME			"brash"
# define	SWVERS			"2.5.93"
# define	SWFORG			"$"						/*	"$" = stable	*/
# define	SWDATE			"2015/01/25"
# define	SWDESC			"basic remote administration shell"
# define	SWTAGS			"brash,remote,system,administration,shell"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

# include "brash.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int			grd = 0 ;		/* global result descriptor		*/

int			myerrno ;
int			cmdcod ;

int			ttyflag = 0 ;
int			forkflag = 0 ;

char		errmsgbuf [ERRMSGBUFSIZ] ;
char		cmdlinbuf [CMDLINBUFSIZ] ;
char		promptbuf [PROMPTBUFSIZ] ;

char *		vrundirname = VRUNDIRNAME ;
char *		vrunpathname = VRUNPATHNAME ;

char		readbuff [MEGASIZE] ;
char		compbuff [MEGASIZE] ;

FILE *		tip = NULL ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void usage () {

	fprintf (stderr, "use : %s [-flags] [args] \n", SWNAME) ;
	brashend (1) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	smash : system management / administration shell			|
 *		|_______________________________________________________________|
 */

void brashprompt () {
# ifndef		_HAS_READLINE_
	if ( inatty (NULL) ) {
		fprintf (top, "%s", promptbuf) ;
	}
# endif
	cmdlinbuf[0] = '\0' ;
}

# ifdef		_HAS_READLINE_
# define	GAMREADLINE		readline
# else
# define	GAMREADLINE		breadline
# endif

# ifdef		BRAPROMPT
# define	GAMPROMPT		promptbuf
# else
# define	GAMPROMPT		DFL_PROMPT /* ">>> " */
# endif

# define	TMPLINSIZ		32768

# define	YY_NULL			0

extern FILE * yyin , * yyout ;

char * breadline (prompt) char * prompt ; {
	static	char *	tp ;

	fprintf (yyout, "%s", prompt) ;

	tp = malloc (TMPLINSIZ) ;

	if ( tp == NULL )
		return tp ;
	else
		return fgets (tp, TMPLINSIZ, yyin) ;
}

/* static */ int gambytes (char * gambuf, size_t gamost) {
        char *	line ;

        if ( feof (yyin) ) {
                fprintf (stderr, "%s\n", "{eof}") ;
                return YY_NULL ;
        }

        line = GAMREADLINE (GAMPROMPT) ;

        if ( ! line ) {
                fprintf (stderr, "%s\n", "{bye}") ;
                return YY_NULL ;
        }

        if ( strlen(line) > gamost - 2 ) {
                fprintf (stderr, "%s\n", "input line too long") ;
                return YY_NULL ;
        }

        strcpy (gambuf, line) ;
# ifdef		_HAS_READLINE_
        add_history (gambuf) ;
        strcat (gambuf, "\n") ;
# endif
        brahistory (gambuf) ;
        free (line) ;

        return strlen (gambuf) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashdo (cod) int cod ; {

	switch (cod) {

		case BRA_NIL : break ;

		case BRA_DAT : bra_date ( top ) ; break ;

		case BRA_TIM : bra_time ( top ) ; break ;

		case BRA_STA : bra_status ( top ) ; break ;

		case BRA_BAD :
		default : fprintf ( top, "?? (%s) ??\n", cmdlinbuf) ; break ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int brashparse ( buf ) char * buf ; {
	char * ep ;

	if ( *buf == '#' )
		return BRA_NIL ;

	ep = buf + strlen (buf) ;
	for ( --ep ; *ep == '\r' || *ep == '\n' ; *ep-- = '\0' )
		;

	if ( *buf == '\0' )
		return BRA_NIL ;

	if ( 0 == strncmp (buf, "bye",  3) ||
		 0 == strncmp (buf, "exit", 3) ||
		 0 == strncmp (buf, "quit", 3)    ) {
		return	BRA_BYE ;
	} else if ( 0 == strncmp (buf, "help", 3) ) {
		return	BRA_HEL ;
	} else if ( 0 == strncmp (buf, "date", 3) ) {
		return	BRA_DAT ;
	} else if ( 0 == strncmp (buf, "time", 3) ) {
		return	BRA_TIM ;
	} else if ( 0 == strncmp (buf, "version", 3) ) {
		return	BRA_VER ;
	} else if ( 0 == strncmp (buf, "status", 3) ) {
		return	BRA_STA ;
	} else if ( 0 == strncmp (buf, "uname", 3) ) {
		return	BRA_UNA ;
	} else {
		return	BRA_BAD ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashell () {

	for ( ; ; ) {
		brashprompt () ;
		if ( NULL == fgets (cmdlinbuf, CMDLINBUFSIZ, tip) ) {
			fprintf (top, "%s", "\n") ;
			bralog (BL_INFO, "eof") ;
			break ;
		}
		if ( ( cmdcod = brashparse (cmdlinbuf) ) == BRA_BYE ) {
			bralog (BL_INFO, "bye") ;
			break ;
		}
		brashdo (cmdcod) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int brashcmp (file1, file2) char * file1 , * file2 ; {
	struct stat sb1, sb2 ;
	int fd1 = 0 , fd2 = 0 ;
	ssize_t rd1 , rd2 ;
	time_t dift ;
	off_t difs ;

	if ( stat ( file1 , &sb1 ) != 0 ) {
		braerr ("stat", file1) ;
		return -1 ;
	}

	if ( stat ( file2 , &sb2 ) != 0 ) {
		braerr ("stat", file2) ;
		return -1 ;
	}

	if ( ( dift = ( sb1.st_mtime - sb2.st_mtime ) ) > 0 ) {
		return (int) dift ;
	}

	if ( dift < 0 ) {
		return 0 ;
	}

	if ( ( difs = ( sb1.st_size - sb2.st_size ) ) ) {
		return (int) difs ;
	}

	fd1 = open (file1, O_RDONLY) ;

	if ( fd1 < 0 ) {
		braerr ("open", file1) ;
		return -1 ;
	}

	fd2 = open (file2, O_RDONLY) ;

	if ( fd2 < 0 ) {
		braerr ("open", file2) ;
		close (fd1) ;
		return -1 ;
	}

	for ( ; ; ) {
		rd1 = read ( fd1 , readbuff , (size_t) MEGASIZE ) ;

		if ( rd1 < 0 ) {
			braerr ("read", file1) ;
			break ;
		}

		rd2 = read ( fd2 , compbuff , (size_t) MEGASIZE ) ;

		if ( rd2 < 0 ) {
			braerr ("read", file2) ;
			rd1 = -1 ;
			break ;
		}

		if ( rd1 != rd2 ) {
			rd1 = -1 ;
			break ;
		}

		if ( rd1 == 0 ) {
			break ;
		}

		if ( 0 != memcmp ( readbuff , compbuff , rd1 ) ) {
			rd1 = -1 ;
			break ;
		}
	}

	if ( fd1 > 0 )
		close (fd1) ;

	if ( fd2 > 0 )
		close (fd2) ;

	return (int) rd1 ;
}

int brashclone (dest, orig) char * dest , * orig ; {
	int rfd = 0 , wfd = 0 ;
	int rd = SYSBAD ;
	ssize_t rd1 , rd2 ;

	bralog (BL_INFO, "%s(%s) %s(%s)", "<bin", orig, ">run", dest) ;

	rfd = open (orig, O_RDONLY) ;

	if ( rfd < 0 ) {
		braerr ("open", orig) ;
		return rd ;
	}

	wfd = open (dest, O_CREAT|O_WRONLY|O_TRUNC, S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH) ;

	if ( wfd < 0 ) {
		braerr ("open", dest) ;
		close (rfd) ;
		return rd ;
	}

	for ( ; ; ) {
		rd1 = read ( rfd , readbuff , (size_t) MEGASIZE ) ;

		if ( rd1 < 0 ) {
			braerr ("read", orig) ;
			break ;
		}

		if ( rd1 == 0 ) {
			rd = SYSGOOD ;
			break ;
		}

		rd2 = write ( wfd , readbuff , (size_t) rd1 ) ;

		if ( rd2 < 0 ) {
			braerr ("write", dest) ;
			break ;
		}

		if ( rd1 != rd2 ) {
			braerr ("sync", dest) ;
			break ;
		}
	}

	if (rfd > 0)
		close (rfd) ;

	if (wfd > 0)
		close (wfd) ;

	return rd ;
}

void brashuffle (argv, envp) char * * argv , * * envp ; {
	pid_t kid ;
	int rd = SYSGOOD ;

	if ( 0 == strcmp (execpathname, vrunpathname) ) { /* is this runfile ? */
		bralog (BL_INFO, "%s %s", "exec", "run") ;
		return ; /* yes.. carry on */
	}

	bralog (BL_INFO, "%s %s", "exec", "bin") ; /* no.. it's binfile */

	if ( access(vrunpathname, F_OK) == 0 ) { /* runfile exists ? */
		if ( brashcmp (execpathname, vrunpathname) ) { /* is it older ? */
			rd = brashclone (vrunpathname, execpathname) ; /* yes.. self-copy */
		}
	} else { /* no.. self-copy */
		rd = brashclone (vrunpathname, execpathname) ;
	}

	if ( rd == SYSGOOD ) { /* ok to run runfile ? */
		if ( forkflag ) {
			if ( ( kid = fork () ) == 0 ) { /* child */
				argv[0] = vrunpathname ;
				logtag = "child" ;
				locpid = getpid () ;
				execve (vrunpathname, argv, envp) ;
				braerr ("execve", vrunpathname) ;
				brashend (2) ;
			} else {
				if ( kid < 0 ) {
					braerr ("fork", "parent") ;
				}
				brashend (0) ;
			}
		} else {
			argv[0] = vrunpathname ;
			execve (vrunpathname, argv, envp) ;
			braerr ("execve", vrunpathname) ;
			brashend (2) ;
		}
	} else { /* no.. exec anyway */
		bralog (BL_INFO, "%s %s", "uninstalled", "bin") ;
	}
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	brash : bud's remote administration (former network) shell	|
 *		|_______________________________________________________________|
 */

void brashwork () {

	if (versionflag) {
		showversion (stdout, swname, versno, forgid, verboseflag) ;
		return ;
	}

	if (cflag) {
		logtag = CLIENTTAG ;
		brashclient () ;
	}

	if (sflag) {
		logtag = SERVERTAG ;
		brashserver () ;
	}

	if (tflag) {
		logtag = TESTERTAG ;
		brashtester () ;
	}

	if (interactiveflag) {
		strcpy (promptbuf, DFL_PROMPT) ;
		bra_nodeinit () ;
		bra_load () ;
# ifdef BRASHLY
# ifdef		_HAS_READLINE_
		using_history () ;
# else
		brashprompt () ;
# endif
		yyparse () ;
# else /* ! BRASHLY */
		logtag = INTERPTAG ;
		brashell () ;
# endif /* BRASHLY */
		bra_save () ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void validargs () {
	if ( cflag && sflag )
		++errorflag ;

	if ( ! ( cflag || sflag ) )
		if ( ! versionflag )
			++interactiveflag ;

	if ( execpathname[EXECPATHNAMESIZE - 1] != '\0' )
		braerr ("name too long", "execpathname") ;

	if ( errorflag )
		usage () ;
}

void brashinit (argc, argv, envp) int argc ; char * * argv , * * envp ; {

	signal (SIGINT,  sighand) ;
	signal (SIGTERM, sighand) ;

	signal (SIGSEGV, sighand) ;

	if (ttyflag) {
		tip = fopen ("/dev/tty", "r+") ;
		top = fopen ("/dev/tty", "w+") ;
	} else {
		tip = stdin  ;
		top = stdout ;
	}

	bra_env (SWNAME, SWVERS, SWFORG) ;

	bralog (BL_INFO, "%s %s %s", versno, "START", *argv) ;

	memset  (execpathname,  '\0', EXECPATHNAMESIZE) ;
	strncpy (execpathname, *argv, EXECPATHNAMESIZE) ;

	brashuffle (argv, envp) ;

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch (*((*argv)+1)) {
					case 'c' : ++cflag ; break ;
					case 'h' : setremotehostname (*++argv) ; break ;
					case 'L' : ++cleanflag ; break ;
					case 'm' : setremotecommand (*++argv) ; break ;
					case 'p' : setremoteport (*++argv) ; break ;
					case 's' : ++sflag ; break ;
					case 't' : ++tflag ; break ;
					case 'v' : ++verboseflag ; break ;
					case 'V' : ++versionflag ; break ;
					case 'x' : setcommandinfo (*++argv) ; break ;
					case '?' : usage () ; break ;
				}
			} else { /* free parm */
				fprintf (stderr, "* unused arg (%s)\n", *argv) ;
			}
		}
	} else { /* no parms */
		++interactiveflag ;
	}

	validargs () ;

	bra_getwd () ;

	getlocalhostinfo () ;
}

/*
 *
 *		  /\
 *		 /  \		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		/ OO \		|	(originally) smash		 sys mgmt / adm shell	|
 *		\ \/ /		|	(c) 1999-2013			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

int main (argc, argv, envp) int argc ; char * * argv , * * envp ; {
	brashinit (argc, argv, envp) ;
	brashwork () ;
	brashexit () ;
	return grd ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   description ..........................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v rls   ......................................	|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu ts=4
 */

