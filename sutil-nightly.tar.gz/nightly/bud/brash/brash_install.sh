BAC=brash
SAD=sadmind
BINMOD=0755
PUBMOD=1777
ULB=/usr/local/bin
ULS=/usr/local/sbin
VRB=/var/run/brash.d
set -x
umask ${BINMOD}
mkdir -p ${ULB} ${ULS} ${VRB}
chmod ${PUBMOD} ${VRB}
cp -p ${BAC} ${ULB}
cp -p ${SAD} ${ULS}
chmod ${BINMOD} ${ULB}/${BAC}
chmod ${BINMOD} ${ULS}/${SAD}
