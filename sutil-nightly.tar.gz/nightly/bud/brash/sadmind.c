
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   sadmind         system administration daemon   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'BRASH' (the basic remote administration shell) |
 | as released by Alexandre Botao <botao.org> ;                         |
 |                                                                      |
 | 'BRASH' is Free and Open Source software (FOSS). This means you can  |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'BRASH' is distributed in the hope that it will be useful,           |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'BRASH'.  If not, see <http://www.gnu.org/licenses/>, or  |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# define	SWNAME			"sadmind"
# define	SWVERS			"1.2.09"
# define	SWFORG			"$"						/*	"$" = stable	*/
# define	SWDATE			"2013/10/02"
# define	SWDESC			"system administration daemon"
# define	SWTAGS			"sadmind,system,administration,daemon"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

# include "brash.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int			grd = 0 ;		/* global result descriptor		*/

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void sadshuffle (argv, envp) char * * argv , * * envp ; {

	if ( argv == NULL || envp == NULL )
		return ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int sadaemit () {
    pid_t   pid ;
    int     fd ;

    if ( ( pid = fork () ) == (pid_t) SYSBAD ) {
		braerr ("fork", SWNAME) ;
        return SYSBAD ;
    } else if ( pid != 0 ) {
		bralog (BL_NOTIC, "bailing out for kid (%d)", pid) ;
		brashexit () ;
    }

	locpid = getpid () ;

	bralog (BL_NOTIC, "%s", "detaching...") ;		/* homage to pdp-11/70's rsts/e */
	bralog (BL_NOTIC, "...from (%d)", getppid()) ;

    setsid ( ) ;
    chdir ( "/" ) ;
    umask ( currmask ) ;

    if ( ( fd = open ( "/dev/null", O_WRONLY, 0 ) ) == SYSBAD )
        return SYSBAD ;

    dup2 ( fd, STDIN_FILENO ) ;
    dup2 ( fd, STDOUT_FILENO ) ;
    dup2 ( fd, STDERR_FILENO ) ;
    
    close ( fd ) ;

    return SYSGOOD ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void sadwork () {

	if (versionflag) {
		bra_vers (stdout) ;
	}

	if (cflag) {
		logtag = CLIENTTAG ;
		brashclient () ;
	}

	if (sflag) {
		logtag = SWNAME ;
        if( sadaemit () != SYSGOOD ) {
			fprintf (stderr, "%s : unable to daemonize \n", SWNAME) ;
			brashend (1) ;
        }
		brashserver () ;
	}

	if (tflag) {
		logtag = TESTERTAG ;
		brashtester () ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void usage () {

	fprintf (stderr, "%s : invalid flag(s) / arg(s) \n", SWNAME) ;
	fprintf (stderr, "use : %s [-flags] [args] \n", SWNAME) ;
	brashend (1) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void validargs () {
	if ( cflag && sflag )
		++errorflag ;

	if ( ! ( cflag || sflag ) )
		if ( ! versionflag )
			++errorflag ;

	if ( execpathname[EXECPATHNAMESIZE - 1] != '\0' )
		braerr ("name too long", "execpathname") ;

	if ( errorflag )
		usage () ;
}

void sadinit (argc, argv, envp) int argc ; char * * argv , * * envp ; {

	signal (SIGINT,  sighand) ;
	signal (SIGTERM, sighand) ;

	signal (SIGSEGV, sighand) ;

	bra_env (SWNAME, SWVERS, SWFORG) ;

	bralog (BL_INFO, "%s %s %s", SWVERS, "START", *argv) ;

	memset  (execpathname,  '\0', EXECPATHNAMESIZE) ;
	strncpy (execpathname, *argv, EXECPATHNAMESIZE) ;

	sadshuffle (argv, envp) ;

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch (*((*argv)+1)) {
					case 'c' : ++cflag ; break ;
					case 'h' : setremotehostname (*++argv) ; break ;
					case 'm' : setremotecommand (*++argv) ; break ;
					case 'p' : setremoteport (*++argv) ; break ;
					case 's' : ++sflag ; break ;
					case 't' : ++tflag ; break ;
					case 'v' : ++verboseflag ; break ;
					case 'V' : ++versionflag ; break ;
					case 'x' : setcommandinfo (*++argv) ; break ;
					case '?' : usage () ; break ;
				}
			} else { /* free parm */
				fprintf (stderr, "* unused arg (%s)\n", *argv) ;
			}
		}
	} else { /* no parms */
		++sflag ;
	}

	validargs () ;

	bra_getwd () ;

	getlocalhostinfo () ;
}

void sadexit () {
	brashexit () ;
}

/*
 *
 *		  /\
 *		 /  \		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		/ OO \		|	(originally) smash		 sys mgmt / adm shell	|
 *		\ \/ /		|	(c) 1999-2013			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

int main (argc, argv, envp) int argc ; char * * argv , * * envp ; {
	sadinit (argc, argv, envp) ;
	sadwork () ;
	sadexit () ;
	return grd ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   description ..........................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v rls   ......................................	|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu ts=4
 */
