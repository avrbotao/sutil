
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'BRASH' (the basic remote administration shell) |
 | as released by Alexandre Botao <botao.org> ;                         |
 |                                                                      |
 | 'BRASH' is Free and Open Source software (FOSS). This means you can  |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'BRASH' is distributed in the hope that it will be useful,           |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'BRASH'.  If not, see <http://www.gnu.org/licenses/>, or  |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# ifndef _LIBRASH_H_

# define _LIBRASH_H_

# include <sys/types.h>

# include       "params.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	RAWSTAMP	0x0001
# define	PLUSTAMP	0x0002
# define	DATSTAMP	0x0004
# define	TIMSTAMP	0x0008

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char * timestamp () ;

void bralog (int, char *, ...) ;
void braerr () ;
void bratrace () ;
void brahistory () ;

void sighand () ;

int inatty () ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashend () ;
void brashexit () ;
void brashprompt () ;

void bra_bang () ;
void bra_cd () ;
void bra_date () ;
void bra_dns () ;
void bra_drop () ;
void bra_droplist () ;
void bra_dropnode () ;
void bra_env () ;
void bra_get () ;
void bra_getwd () ;
void bra_help () ;
void bra_hist () ;
void bra_info () ;
void bra_learn () ;
void bra_list () ;
void bra_listdrop () ;
void bra_listgrow () ;
void bra_listinit () ;
void bra_listproc () ;
void bra_ll () ;
void bra_load () ;
void bra_ls () ;
void bra_match () ;
void bra_mkdir () ;
void bra_node () ;
void bra_nodeinit () ;
void bra_pwd () ;
void bra_put () ;
void bra_save () ;
void bra_status () ;
void bra_ctime () ;
void bra_time () ;
void bra_try () ;
void bra_uname () ;
void bra_vers () ;
void bra_with () ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashclient () ;
void brashserver () ;
void brashtester () ;

void setremotehostname () ;
void setremotecommand () ;
void setremoteport () ;
void setcommandinfo () ;
void getlocalhostinfo () ;

void lastsockck () ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

extern	int			cflag ;
extern	int			sflag ;
extern	int			tflag ;

extern	int			errorflag ;
extern	int			interactiveflag ;
extern	int			cleanflag ;
extern	int			verboseflag ;
extern	int			versionflag ;

extern	FILE *		top ;

extern char * swname ;
extern char * versno ;
extern char * forgid ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

extern	char *		logtag ;
extern	char *		versno ;

extern	int			locpid ;
extern	int			maxports ;

extern	int			portlist [] ;

extern	int			locuid ;
extern	int			locgid ;

extern	char		localhostname [] ;
extern	char		localhostaddr [] ;

extern	char		execpathname[] ;

extern	mode_t		currmask ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# define	SKYNETMSG	"skynet begins to learn at a geometric rate"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

# endif /* _LIBRASH_H_ */

/*
 * vi:nu ts=4
 */

