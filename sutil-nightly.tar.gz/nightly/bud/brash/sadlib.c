
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                    __________________________________________________
 *                   |                                                  |
 *                   |   sadlib      system administration daemon lib   |
 *                   |__________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 | This file is part of 'BRASH' (the basic remote administration shell) |
 | as released by Alexandre Botao <botao.org> ;                         |
 |                                                                      |
 | 'BRASH' is Free and Open Source software (FOSS). This means you can  |
 | redistribute it and/or modify it under the terms of the GNU General  |
 | Public License as published by the Free Software Foundation, either  |
 | version 3 of the License, or (at your option) any later version.     |
 |                                                                      |
 | 'BRASH' is distributed in the hope that it will be useful,           |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 |
 | See the GNU General Public License for more details.                 |
 |                                                                      |
 | You should have received a copy of the GNU General Public License    |
 | along with 'BRASH'.  If not, see <http://www.gnu.org/licenses/>, or  |
 | write to the Free Software Foundation, Inc.,                         |
 | 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.             |
 |______________________________________________________________________|
 */

# include "brash.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int			port = DFL_PORT ;

int			secstoshut = DFL_SECSTOSHUT ;

int			locsok = 0 ;
int			remsok = 0 ;

int			sin_size ;

int			sndmsglen ;
int			rcvmsglen ;

SOCKADDRIN	locaddr ;
SOCKADDRIN	remaddr ;

HOSTENT *	lochep ;
HOSTENT *	remhep ;

char		remotehostname [MAXHOSTNAMELEN] = { '\0' } ;
char		remotehostaddr [64] ;

char		sndmsgbuf [MAXMSGLEN] ;
char		rcvmsgbuf [MAXMSGLEN] ;
char		remcmdbuf [MAXMSGLEN] ;
char		remargbuf [MAXMSGLEN] ;

pid_t		parpid ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void getlocalhostinfo () {

	struct in_addr iab ;

	if ( gethostname ( localhostname, MAXHOSTNAMELEN ) == -1 )
		braerr ("gethostname", "localhost") ;

	if ( ( lochep = gethostbyname ( localhostname ) ) == NULL ) {
		braerr ("gethostbyname", localhostname) ;
		strcpy (localhostaddr, UNDEFIPADDR) ;
	} else {
		memcpy ( &iab.s_addr, *(lochep->h_addr_list), sizeof (iab.s_addr) ) ;
		strcpy (localhostaddr, inet_ntoa (iab)) ;
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void setremotehostname (nam) char * nam ; {

	if (nam == NULL) {
		braerr ("null", "remotehostname") ;
		brashend (1) ;
	}

	strcpy (remotehostname, nam) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void setremotecommand (txt) char * txt ; {

	if (txt == NULL) {
		braerr ("null", "remotecommand") ;
		brashend (1) ;
	}

	strcpy (remcmdbuf, txt) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void setremoteport (txt) char * txt ; {

	if (txt == NULL) {
		braerr ("null", "remoteport") ;
		brashend (1) ;
	}

	port = atoi (txt) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void setcommandinfo (txt) char * txt ; {

	if (txt == NULL) {
		braerr ("null", "remotearg") ;
		brashend (1) ;
	}

	strcpy (remargbuf, txt) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

void greetings () {

	sprintf (sndmsgbuf, "this is %s on %s addr %s !", logtag, localhostname, localhostaddr) ;
	sndmsglen = strlen (sndmsgbuf) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashtalk (op, rs) int op , rs ; {

	int rc = 0 ;
	int rd = 0 ;
	FILE * frs ;

	if ( op == HEAR ) {		/* server */

		frs = fdopen ( rs , "a" ) ;

		if ( frs == NULL ) {
			braerr ("fdopen", "client") ;
			++rc ;
		}

		for ( ; ; ) {

			if ( ( rcvmsglen = recv (rs, rcvmsgbuf, MAXMSGLEN, 0) ) == -1 ) {
				braerr ("recv", "client") ;
				++rc ;
				break ;
			}

			if ( rcvmsglen > 0 ) {
				rcvmsgbuf[rcvmsglen] = '\0' ;
				bralog (BL_DEBUG, "req = {%s}", rcvmsgbuf) ;
			} else {
				bralog (BL_DEBUG, "%s", "recv(0) from client") ;
			}

			if ( strcmp (rcvmsgbuf, "RQID") == 0 ) {

				greetings () ;

				if ( send (rs, sndmsgbuf, sndmsglen, 0) == -1 ) {
					braerr ("send", "client") ;
					++rc ;
				}

				break ;

			} else if ( strcmp (rcvmsgbuf, "UNAM") == 0 ) {

				if ( frs != NULL ) {
					bra_uname ( frs ) ;
					fflush ( frs ) ;
				}

				break ;

			} else if ( strcmp (rcvmsgbuf, "SHUT") == 0 ) {

				bralog (BL_DEBUG, "got {%s} for boss (%d)", rcvmsgbuf, parpid) ;
				kill (parpid, SIGTERM) ;

				/* FIXME: ? await parent death + ? send shut confirmation */

				break ;

			} else {

				bralog (BL_ERR, "invalid request: (%s)", rcvmsgbuf) ;
				++rc ;
				break ;
			}
		}

	} else if ( op == SPEAK ) {		/* client */

		strcpy (sndmsgbuf, remcmdbuf) ;
		sndmsglen = strlen (sndmsgbuf) ;

		if ( ( rd = send (rs, sndmsgbuf, sndmsglen, 0) ) == -1 ) {
			braerr ("send", "server") ;
			++rc ;
		}

		if ( rd != sndmsglen ) {
			braerr ("send", "size mismatch") ;
			++rc ;
		}

		if ( strcmp (sndmsgbuf, "RQID") == 0 ) {

			if ( ( rcvmsglen = recv (rs, rcvmsgbuf, MAXMSGLEN, 0) ) == -1 ) {
				braerr ("recv", "server") ;
				++rc ;
			} else {
				rcvmsgbuf[rcvmsglen] = '\0' ;
				bralog (BL_DEBUG, "rsp = %s", rcvmsgbuf) ;
			}

		} else if ( strcmp (sndmsgbuf, "UNAM") == 0 ) {

			if ( ( rcvmsglen = recv (rs, rcvmsgbuf, MAXMSGLEN, 0) ) == -1 ) {
				braerr ("recv", "server") ;
				++rc ;
			} else {
				rcvmsgbuf[rcvmsglen] = '\0' ;
				if ( rcvmsgbuf[rcvmsglen-1] == '\n' ) {
					rcvmsgbuf[rcvmsglen-1] = '\0' ;
				}
				printf ("uname = (%s)\n", rcvmsgbuf) ;
			}

		} else if ( strcmp (sndmsgbuf, "SHUT") == 0 ) {

				/* rcv shut confirmation */

		} else {

			bralog (BL_ERR, "invalid command (%s)", rcvmsgbuf) ;
			++rc ;
		}
	}

	close (rs) ;
	brashend (rc) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashtester () {

}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashclient () {

	if ( remotehostname[0] == '\0' ) {
		braerr ("empty", "remotehostname") ;
		brashend (1) ;
	}

	/* FIXME: test and check for raw ip addr instead of hostname */

	if ( ( remhep = gethostbyname (remotehostname) ) == NULL ) {
		braerr ("gethostbyname", remotehostname) ;
		brashend (1) ;
	}

	if ( ( remsok = socket (AF_INET, SOCK_STREAM, 0) ) == -1 ) {
		braerr ("socket", "client") ;
		brashend (1) ;
	}

	remaddr.sin_family = AF_INET ;
	remaddr.sin_port = htons (port) ;
	remaddr.sin_addr = *( (struct in_addr *) remhep->h_addr ) ;

	bzero ( &(remaddr.sin_zero), 8 ) ;

	if ( connect ( remsok, (SOCKADDR *) &remaddr, SOCKADDRSIZE) == -1 ) {
		braerr ("connect", "server") ;
		brashend (1) ;
	}

	brashtalk (SPEAK, remsok) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void brashserver () {

	if ( ( locsok = socket ( AF_INET, SOCK_STREAM, 0) ) == -1 ) {
		braerr ("socket", "server") ;
		brashend (1) ;
	}

	locaddr.sin_family = AF_INET ;
	locaddr.sin_port = htons (port) ;
	locaddr.sin_addr.s_addr = INADDR_ANY ; /* auto/y fill w/ loc ip */

	bzero ( &(locaddr.sin_zero), 8 ) ;

	if ( bind ( locsok, (SOCKADDR *) &locaddr, SOCKADDRSIZE ) == -1 ) {
		braerr ("bind", "server") ;
		brashend (1) ;
	}

	if ( listen (locsok, BACKLOG) == -1 ) {
		braerr ("listen", "server") ;
		brashend (1) ;
	}

	for ( ; ; ) {

		/* FIXME: check for messages to server/parent(self) (eg. restart,shutdown,...) */

		sin_size = SOCKADDRINSIZE ;

		if ( ( remsok = accept ( locsok, (SOCKADDR *) &remaddr, (socklen_t *) &sin_size ) ) == -1 ) {
			braerr ("accept", "server") ;
			continue ;
		}

		bralog (BL_INFO, "inbound (%s)",inet_ntoa (remaddr.sin_addr)) ;

		if ( ! fork () ) { /* child */
			locpid = getpid () ;
			parpid = getppid () ;
			brashtalk (HEAR, remsok) ;
		}

		close(remsok) ;  /* parent */

		while ( waitpid (-1, NULL, WNOHANG ) > 0 ) { /* clean up children */
			sleep (2) ;
		}
	}
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void lastsockck () {
	if (locsok != 0)
			close (locsok) ;
}

/*
 * vi:nu ts=4
 */
