
# define	VERNAME			"tv"
# define	VERSION			"1.2"
# define	VERCODE			"239"
# define	VERDATE			"2000.03.20"
# define	VERSIGN			"Alexandre Botao"

/*
 *	tv (tree view) : based on tl
 */

# define BAN "\n\ttv 1.237 @ 2000.03.11 (c) bud \n"

/* includes ... */

# include	<signal.h>

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_SYSTYPES

# define	USE_STDSTR
# define	USE_STDLOGIC
# define	USE_STDSTAT
# define	USE_STDPARM
# define	USE_STDTYP
# define	USE_STDDIR
# define	USE_STDMISC
# define	USE_STDMEM

# include	"abc.h"

# include	"stdinfo.h"

/*________________________________________________________________________
*/

/* defines ... */

#	define	NAMESIZE	4096

/* globals ... */

int aflag = FALSE ;
int dflag = FALSE ;
int sflag = TRUE ;
int depth = 0 ;
int lastone = TRUE ;

char tbuf [NAMESIZE] ;

# ifdef DOS
/* extern */ unsigned _stklen = 16384 ;
# endif

/* function prototypes */

void showname (char *) ;
void tv (char *) ;

# ifdef MSVC

int listcmp (const void *, const void *) ;

# else

/* int listcmp (char* *, char * *) ; */
int listcmp () ;

# endif

void /* int */ prosig (int) ;

int main (argc, argv) int argc ; char * * argv ; {

	int parmcount = 0 ;

# ifdef PROSIG
/*	signal (SIGBUS,  prosig) ; */
	signal (SIGSEGV, prosig) ;
# endif

	puts (BAN) ;

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch ( *((*argv)+1) ) {
					case 'a' : aflag = TRUE  ; break ;
					case 'd' : dflag = TRUE  ; break ;
					case 'u' : sflag = FALSE ; break ;
					case '?' :
					default  :
						printf ("tv [-?a]\n") ;
						return 0 ;
				}
			} else { /* free parm ... pick or proc ? */
				++parmcount ;
				tv (*argv) ;
			}
		}
	} else {
		++parmcount ;
		tv (".") ;
	}
	if (parmcount == 0)
		tv (".") ;
	if (dflag)
		xmdump ("tv") ;

	return 0 ;
}

void tv (name) char * name ; {

	register char * np ;

	register DIRDES * ddp ;
	register DIRENT * dep ;

	char nbuf [NAMESIZE] ;

	if ( filetype (name) == T_DIR ) {

		register char * * lst = NULL ;
		register int cnt = 0 ;

		showname (name) ;

		ddp = OpenDir (name) ;

		if ( ddp == NULL ) {
			printf ("erro ao abrir diretorio %s\n", name) ;
			return ;
		}

		while ( (dep = ReadDir (ddp)) != NULL ) {

			np = dep->d_name ;

			if ( dotdir (np) )
				continue ;

			if ( ! aflag ) {
				sprintf (tbuf, "%s%c%s", name, DIRSEP, np) ;
				if ( filetype (tbuf) != T_DIR ) {
					continue ;
				}
			}

			if (lst == NULL) {
				lst = (char * *) xmalloc ( 2 * PTRSIZ ) ;
			} else {
				lst = (char * *) xmrealloc ( (char *) lst, (2+cnt) * PTRSIZ ) ;
			}

			if ( lst == NULL ) {
				printf ("tv: sem memoria para lista !\n") ;
				return ;
			}

			np = xmalloc ( strlen (np) + 1 ) ;

			if ( np == NULL ) {
				printf ("tv: sem memoria para nome !\n") ;
				return ;
			}

			strcpy (np, dep->d_name) ;
			*(lst+cnt) = np ; ++cnt ;
			*(lst+cnt) = NULL ;
		}

		CloseDir (ddp) ;

		if (sflag) {
			qsort ( (char *) lst, cnt, PTRSIZ, listcmp) ;
		}

		if (cnt > 0) {
			while (*lst) {
				if (*(lst+1)==NULL)
					lastone = TRUE ;
				else
					lastone = FALSE ;
				sprintf (nbuf, "%s%c%s", name, DIRSEP, *lst) ;
				++depth ;
				tv (nbuf) ;
				--depth ;
				++lst ;
			}
		}

	} else {

		if (aflag)
			showname (name) ;
	}
}

int listcmp (a, b) char * * a , * * b ; {

	return strcmp (*a, *b) ;
}

void showname (name) char * name ; {

# define	VSIZ	5 /* 4 ? */
# define	VLEN	3
/* # define	DRAW */

# ifdef DRAW
#	ifdef DANSI
	FIX char vlast [VSIZ] = { 192, 196, 196, 0 } ;
	FIX char veach [VSIZ] = { 195, 196, 196, 0 } ;
	FIX char vstik [VSIZ] = { 179,  32,  32, 0 } ;
	FIX char vspac [VSIZ] = {  32,  32,  32, 0 } /* "   " */ ;
#	else	/*	xterm	*/
	FIX char vlast [VSIZ] = "mqq" ;
	FIX char veach [VSIZ] = "tqq" ;
	FIX char vstik [VSIZ] = "x  " ;
	FIX char vspac [VSIZ] = "   " ;
#	endif
# else
	FIX char vlast [VSIZ] = "\\--" ;
	FIX char veach [VSIZ] = "+--" ;
	FIX char vstik [VSIZ] = "|  " ;
	FIX char vspac [VSIZ] = "   " ;
# endif
	FIX char vbuf  [ 256] = { '\0' } ;

	char * vpref ;

	*(vbuf+(depth*VLEN)) = '\0' ;

	if (*vbuf)
		printf ("%s", vbuf) ;

	if ( lastone ) {
		strcat (vbuf, vspac) ;
		vpref = vlast ;
	} else {
		strcat (vbuf, vstik) ;
		vpref = veach ;
	}

	if (depth)
		printf ("%s", vpref) ;
	else
		printf ("%s", vspac) ;

	printf ("%s\n", lastname (name)) ;
}

# ifdef PROSIG

void /* int */ prosig (signo) {

	printf ("\r\nsignal(%d)\r\n", signo) ;

	if (dflag)
		xmdump ("tv/sig") ;

	exit (1) ;
/*	return 1 ; */
}

# endif

void epilogue () {

}

