
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	vap 				virtual archive processor	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 2000				alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"vap"
# define	VERSION			"0.1"
# define	VERCODE			"172"
# define	VERDATE			"2000.09.22"
# define	VERSIGN			"Alexandre Botao"

/*		 _______________________________________________________________
 *		|																|
 *		|	includes & operational definitions ...						|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO

# define	USE_STDASC
# define	USE_STDAPP
# define	USE_STDLIC
# define	USE_STDLIB
# define	USE_STDSTR
# define	USE_STDPARM
# define	USE_STDMISC

# define	USE_STDLOGIC
# define	USE_STDTYP
# define	USE_STDXAR

# define	USE_STRLIST
# define	USE_STDMATCH

# include	"abc.h"

/*		 _______________________________________________________________
 *		|																|
 *		|	application-specific definitions & data prototypes ...		|
 *		|_______________________________________________________________|
 */

# define	NAMLEN			  128

/*		 _______________________________________________________________
 *		|																|
 *		|	global variables ...										|
 *		|_______________________________________________________________|
 */

int		addflag			= FALSE ;
int		balanceflag		= FALSE ;
int		deleteflag		= FALSE ;
int		dontflag		= FALSE ;
int		extractflag		= FALSE ;
int		filterflag		= FALSE ;
int		forceflag		= FALSE ;
int		listflag		= FALSE ;
int		mkpathflag		= FALSE ;
int		overflag		= FALSE ;
int		quietflag		= FALSE ;
int		recurseflag		= FALSE ;
int		refreshflag		= FALSE ;
int		testflag		= FALSE ;
int		updateflag		= FALSE ;
int		verboseflag		= FALSE ;

char	archname [NAMLEN] ;

STRLISTCTRL * arglist = NULL ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include "stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-abcdfilnopqrtuvxELV?] archive [filespec ...] \n",
	"\n",

	"  -a : adicionar arquivos \n",
	"  -b : balancear arquivos \n",
	"  -c : criar diretorios ao extrair arquivos \n",
	"  -d : deletar arquivos \n",
	"  -f : atualizar arquivos \n",
	"  -i : atualizar arquivos incondicionalmente \n",
	"  -l : listar status dos arquivos \n",
	"  -n : nao executar (apenas informar) \n",
	"  -o : sobrepor arquivos existentes ao extrair \n",
	"  -p : pesquisar diretorios recursivamente \n",
	"  -q : operar silenciosamente \n",
	"  -r : filtrar CR ao extrair arquivos \n",
	"  -t : testar integridade dos arquivos \n",
	"  -u : atualizar e adicionar arquivos \n",
	"  -v : listar status dos arquivos (detalhado) \n",
	"  -x : extrair arquivos \n",

# include "stdflag.h"

	NULL

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

PARMINFO	parminfo [] = {

	{ 'a',	&addflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'b',	&balanceflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'c',	&mkpathflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'd',	&deleteflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'f',	&refreshflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'i',	&forceflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'l',	&listflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'n',	&dontflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'o',	&overflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'p',	&recurseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'q',	&quietflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'r',	&filterflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 't',	&testflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'u',	&updateflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'v',	&verboseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'x',	&extractflag,	NULL,		PI_SETVAL,		TRUE			} ,

# include "deflbits.h"

} ;

/*		 _______________________________________________________________
 *		|																|
 *		|	function prototypes ...										|
 *		|_______________________________________________________________|
 */

void		vap				OF ( (void)									) ;
void		vap_args		OF ( (void)									) ;
void		vap_list		OF ( (void)									) ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	main, prologue, epilogue, parms	...							|
 *		|_______________________________________________________________|
 */

MAINTYPE main (argc, argv) int argc ;  char * * argv ; {

	setargent (argc, argv) ;

	parseargs () ;

	prologue () ;

	drudgery () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	parsebits () ;

	sortargsflag = FALSE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	endargent () ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	SETBIT (flagbits, PI_SYNTAXBIT) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	the application itself ...									|
 *		|_______________________________________________________________|
 */

void drudgery () {

	strcpy ( archname , getargent () ) ;

	vap_args () ;

	vap () ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	general|multipurpose|virtual|crossplatform					|
 *		|	object|archive|directory|tree|hierarquical					|
 *		|	tool|processor|peruser|explorer|browser|viewer|manager		|
 *		|_______________________________________________________________|
 */

# ifdef COMMENT
					default = add
					check archive type
					process archive & parms
# endif

void vap () {

	if (listflag)
		vap_list () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void vap_args () {

	register char * nxtarg ;

	if ( ( arglist = makestrlist ("arg", DFL_MAXSTRLSTSIZ) ) == NULL )
		return ;

	pickstrlist ( arglist ) ;
	modestrlist ( LM_OFF , LM_SORT | LM_UNIQ ) ;

	if (totparms > 1)
		while ( ( nxtarg = getargent () ) != NULL )
			feedstrlist ( nxtarg ) ;
	else
		feedstrlist ( MATCHALL ) ;

	xarpatterns (arglist) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void vap_list () {

	if (verboseflag)
		setxaropt ("v") ;

	setxaropt ("eo") ;
	xarlist (archname) ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history...............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v bid   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
