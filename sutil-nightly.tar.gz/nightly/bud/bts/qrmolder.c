#include <time.h>
#include <stdio.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#define SECSPERDAY 86400
#define DAYSTOWIPE 90
#define SECSTOWIPE DAYSTOWIPE * SECSPERDAY
main(){
	DIR *dirp;
	int n=0,rd;
	char * np , * what;
	time_t today;
	struct dirent *dp;
	struct stat sb;
	struct tm * tp;
	printf ("secstowipe=%d\n",SECSTOWIPE);
	time(&today);
	dirp = opendir(".");
	while ((dp = readdir(dirp)) != NULL) {
		np=dp->d_name;
		rd=stat(np, &sb);
		if (rd != 0) { continue; }
		tp = localtime (&sb.st_mtime);
		if (tp == NULL) { continue; }
		if (today-sb.st_mtime > SECSTOWIPE)
			what = "RM";
		else
			what = "OK";
		printf ("%s %04d/%02d/%02d %02d:%02d:%02d %s\n", what,
			tp->tm_year+1900,
			tp->tm_mon+1,
			tp->tm_mday,
			tp->tm_hour,
			tp->tm_min,
			tp->tm_sec,
			np);
	}
	(void) closedir(dirp);
}
