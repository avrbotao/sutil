#define _XOPEN_SOURCE 500
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

# include "configure.h"
# include "astdint.h"

int vflag = 0 ;

int64_t totbytes = 0 ;

static int display_info(const char *fpath, const struct stat64 *sb, int tflag, struct FTW *ftwbuf) {
	if ( sb->st_size > 0 ) {
		totbytes += sb->st_size ;
	}
	if ( vflag ) {
           printf("%-3s %3d %15lld %s\n",
               (tflag == FTW_D) ?   "d"   : (tflag == FTW_DNR) ? "dnr" :
               (tflag == FTW_DP) ?  "dp"  : (tflag == FTW_F) ?   "f" :
               (tflag == FTW_NS) ?  "ns"  : (tflag == FTW_SL) ?  "sl" :
               (tflag == FTW_SLN) ? "sln" : "???",
               ftwbuf->level,
		(long long) sb->st_size,
               fpath);
	}
	return 0;
}

       int main(int argc, char *argv[]) {
           int flags = 0;

           if (argc > 2 && strchr(argv[2], 'd') != NULL)
               flags |= FTW_DEPTH;
           if (argc > 2 && strchr(argv[2], 'p') != NULL)
               flags |= FTW_PHYS;
           if (argc > 2 && strchr(argv[2], 'v') != NULL)
               ++vflag;

           if (nftw64((argc < 2) ? "." : argv[1], display_info, 256, flags) == -1) {
               perror("nftw");
               exit(EXIT_FAILURE);
           }
	printf ("%15lld\n", totbytes) ;
           exit(EXIT_SUCCESS);
       }
/*	HP-UX	:	gcc -D_FILE_OFFSET_BITS=64 -DXBS5_LP64_OFF64_CFLAGS -D_LARGEFILE64_SOURCE -o xu xu.c	*/
