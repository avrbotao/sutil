
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	crc			 32-bit cyclic redundancy checker	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1991-1997			alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"crc"
# define	VERSION			"1.5"
# define	VERCODE			"537"
# define	VERDATE			"2000.11.19"
# define	VERSIGN			"Alexandre Botao"

/*		 _______________________________________________________________
 *		|																|
 *		|	includes & operational definitions ...						|
 *		|_______________________________________________________________|
 */

# ifdef DOS
# include	<io.h>
# endif

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_SYSTYPES
# define	USE_UNISTD

# define	USE_STDASC
# define	USE_STDAPP
# define	USE_STDPARM
# define	USE_STDLOGIC
# define	USE_STDTIME
# define	USE_STDSTR
# define	USE_STDTYP
# define	USE_STDDIR
# define	USE_STDCRC
# define	USE_STDMISC
# define	USE_STDSTAT
# define	USE_STDFILE

# include	"abc.h"

/*________________________________________________________________________
*/
#ifdef OpenBSD
#	define	strcat(D,S)		strlcat(D,S,sizeof(D))
#	define	strcpy(D,S)		strlcpy(D,S,sizeof(D))
# endif
/*________________________________________________________________________
*/

/*		 _______________________________________________________________
 *		|																|
 *		|	application-specific definitions & data prototypes ...		|
 *		|_______________________________________________________________|
 */

# define	DFL_BUFSIZ			 32768

/*		 _______________________________________________________________
 *		|																|
 *		|	global variables ...										|
 *		|_______________________________________________________________|
 */

ULONG		xcrc ;

char		crclist [80] ;
char		namlist [80] ;

int			bunchflag = FALSE ;
int			checkflag = FALSE ;
int			ignoreflag = FALSE ;
int			recurseflag = FALSE ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include "stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-irELV?] [-f arqlst] [-x arqcrc] [filespec ...] \n",
	"\n",

	"  -i : ignora CR \n",
	"  -f : processa arquivos listados em 'arqlst' \n",
	"  -r : pesquisa diretorios recursivamente \n",
	"  -x : confere crc com a lista em 'arqcrc' \n",

# include "stdflag.h"

	NULL

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

PARMINFO	parminfo [] = {

	{ 'i',	&ignoreflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'f',	&bunchflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'f',	NULL,			namlist,	PI_SETBUF,		0				} ,
	{ 'r',	&recurseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'x',	&checkflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'x',	NULL,			crclist,	PI_SETBUF,		0				} ,

# include "deflbits.h"

} ;

/*		 _______________________________________________________________
 *		|																|
 *		|	function prototypes ...										|
 *		|_______________________________________________________________|
 */

int			crc			OF ( ( char * )					) ;
void		crcheck		OF ( ( void )					) ;

int			proclst			OF ( (char *)							) ;
int			procany			OF ( (char *)							) ;
int			procdir			OF ( (char *)							) ;
int			procfile		OF ( (char *)							) ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	main, prologue, epilogue, parms	...							|
 *		|_______________________________________________________________|
 */

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	setargent (argc, argv) ;

	parseargs () ;

	prologue () ;

	drudgery () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	parsebits () ;

	if (ignoreflag)
		crcsetflag (CRC_IGNORECR) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	endargent () ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	if ( ! ( checkflag || bunchflag ) )
		SETBIT (flagbits, PI_SYNTAXBIT) ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	the application itself ...									|
 *		|_______________________________________________________________|
 */

void drudgery () {

	register char * nxtarg ;

	if ( (totparms > 0) || bunchflag )
		printf ("Data______ Hora____ Tamanho_ CRC_____ Nome____________\n") ;

	while ( ( nxtarg = getargent () ) != NULL )
		procany ( nxtarg ) ;

	if (bunchflag)
		proclst (namlist) ;

	if (checkflag)
		crcheck () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int proclst (nl) char * nl ; {

	char line [128] ;
	FILE * lfp = fopen (nl, "r") ;

	if ( lfp == NULL ) {
		fprintf (stderr, "crc: erro ao abrir lista %s\n", namlist) ;
		return -1 ;
	}

	while (fgets (line, 128, lfp)) {
		stripeol (line) ;
		procany (line) ;
	}

	fclose (lfp) ;
	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procany (name) char * name ; {

	int		tof ;

	if ( ( tof = filetype (name) ) == T_NONE )
		return xalert (XA_BANAL, "acessar", name, 0) ;

	if ( tof == T_DIR && recurseflag )
		return procdir (name) ;
	else
		return procfile (name) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procdir (name) char * name ; {

	register char * np ;
	register DIRDES * ddp ;
	char nb [256] ;

	if ( ( ddp = setdirent (name) ) == NULL )
		return xalert (XA_BANAL, "acessar diretorio", name, 0) ;

	while ( ( np = getdirent (ddp) ) != NULL ) {
		sprintf (nb, "%s%c%s", name, DIRSEP, np) ;
		procany (nb) ;
	}

	return enddirent (ddp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procfile (name) char * name ; {

	return crc (name) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void crcheck () {

	FILE * fp ;
	char line [1024] , name [100] ;
	char * tp ;
	int j ;

	fp = fopen (crclist, "r") ;

	if (fp == NULL) {
		fprintf (stderr, "crc: erro ao abrir lista %s\n", crclist) ;
		return ;
	}

	for ( j = 0 ; j < 5 ; ++j )
		tp = fgets (line, 1024, fp) ;

	if ( tp == NULL ) {
		fclose (fp) ;
		return ;
	}

	while (fgets (line, 1024, fp)) {
		line [ strlen (line) - 1 ] = '\0' ; /* strip '\n' */
		sscanf (&line[29], "%lx", &xcrc) ;
		strcpy (name, &line[38]) ;
		crc (name) ;
	}

	fclose (fp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int crc (nam) char * nam ; {

	unsigned long xc ;
	struct stat stabuf ;
	struct tm * tp ;

# ifdef MUSTLOW
	lowstr (nam) ;
# endif

	if ( access (nam, 0) != 0 ) { /* SHOULD TEST READ PERMISSION !!! */
		fprintf (stderr, "crc: erro ao acessar %s\n", nam) ;
		return -1 ;
	}

	if ( stat ( nam , &stabuf ) < 0 ) {
		printf ("%s/%s/%s ??:??:?? ???????? ", "????", "??", "??") ; /* just to avoid trigraphs warning */
	} else {
		tp = localtime (&stabuf.st_mtime) ;
		printf ("%04d/%02d/%02d %02d:%02d:%02d %8lld ",
				1900+tp->tm_year, tp->tm_mon+1, tp->tm_mday,
				tp->tm_hour, tp->tm_min,   tp->tm_sec,
				(long long)stabuf.st_size) ;
	}

	fflush (stdout) ;

	xc = crcfile (nam, 0) ;

	printf ("%08lx %s", xc, nam) ;

	if (checkflag) {
		if (xc == xcrc)
			printf (" (OK)\n") ;
		else
			printf (" (FAIL)\n") ;
	} else {
		printf ("\n") ;
	}

	return 0 ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history...............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v bid   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + set read buffer size (-b #) ...							|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
