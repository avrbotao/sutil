
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	vrd						versatile record dump	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1998				alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"vrd"
# define	VERSION			"1.3"
# define	VERCODE			"326"
# define	VERDATE			"2000.03.21"
# define	VERSIGN			"Alexandre Botao"

/*		 _______________________________________________________________
 *		|																|
 *		|	includes & operational definitions ...						|
 *		|_______________________________________________________________|
 */

# define	USE_STDIO
# define	USE_STDLIB
# define	USE_SYSTYPES

# define	USE_STDASC
# define	USE_STDAPP
# define	USE_STDPARM
# define	USE_STDLOGIC

# define	USE_STDTYP
# define	USE_STDDIR
# define	USE_STDMISC
# define	USE_STDMEM
# define	USE_STDSTR
# define	USE_STDSTAT

# include	"abc.h"

/*________________________________________________________________________
*/

/*		 _______________________________________________________________
 *		|																|
 *		|	application-specific definitions & data prototypes ...		|
 *		|_______________________________________________________________|
 */

# define	HORIZGRP			'h'
# define	VERTIGRP			'v'

# define	ASCIIFMT			'a'
# define	HEXADFMT			'x'
# define	OCTALFMT			'o'
# define	RAWTXFMT			'r'

# ifdef DOS
#	define	DFL_MAXBUFMEM	 48 KBYTES
# else  /* ANYX */
#	define	DFL_MAXBUFMEM	128 KBYTES
# endif /* DOS */

# define	DFL_OCTOUTSIZ	 16
# define	DFL_HEXOUTSIZ	 16
# define	DFL_ASCOUTSIZ	 16
# define	DFL_RECOUTSIZ	 64

# define	DFL_FMTGRP		HORIZGRP
# define	DFL_FMTLST		"xa"
# define	DFL_OFFSETFMT	"%08ld"

# define	VB(_X)			( ( _X > 31 && _X < 127 ) ? _X : DOT )

/*		 _______________________________________________________________
 *		|																|
 *		|	global variables ...										|
 *		|_______________________________________________________________|
 */

unsigned	maxbufmem		= DFL_MAXBUFMEM ;

int			blkfactor		= 0 ;
int			bufblksiz		= 0 ;
int			varoutsiz		= 0 ;

int			outsiz			= DFL_HEXOUTSIZ ;
int			fmtgrp			= DFL_FMTGRP ;
int			fmtcnt			= 0 ;

char		fmtlst [16]		= { NUL } /* DFL_FMTLST */ ;

char *		offsetfmt		= DFL_OFFSETFMT ;
char *		binbuf			= NULL ;

int			asciiflag		= FALSE ;
int			hexadflag		= FALSE ;
int			octalflag		= FALSE ;
int			rawtxflag		= FALSE ;
int			offsetflag		= TRUE ;

int			recurseflag		= FALSE ;
int			stdinflag		= FALSE ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# include "stdinfo.h"

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-anorvxELV?] [-b N] [filespec ...] \n",
	"\n",

	"  -a : dump ascii \n",
	"  -b : dump N bytes por linha \n",
	"  -n : nao mostra o offset \n",
	"  -o : dump octal \n",
	"  -r : pesquisa recursiva \n",
	"  -v : alihamento vertical \n",
	"  -x : dump hexadecimal \n",

# include "stdflag.h"

	NULL

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

PARMINFO	parminfo [] = {

	{ 'a',	&asciiflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'b',	&varoutsiz,		NULL,		PI_SETNUM,		0				} ,
	{ 'n',	&offsetflag,	NULL,		PI_SETVAL,		FALSE			} ,
	{ 'o',	&octalflag,		NULL,		PI_SETVAL,		TRUE			} ,
	{ 'r',	&recurseflag,	NULL,		PI_SETVAL,		TRUE			} ,
	{ 'v',	&fmtgrp,		NULL,		PI_SETVAL,		VERTIGRP		} ,
	{ 'x',	&hexadflag,		NULL,		PI_SETVAL,		TRUE			} ,

# include "deflbits.h"

} ;

/*		 _______________________________________________________________
 *		|																|
 *		|	function prototypes ...										|
 *		|_______________________________________________________________|
 */

int			procany			OF ( (char *)							) ;
int			procdir			OF ( (char *)							) ;
int			procfile		OF ( (char *)							) ;

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	main, prologue, epilogue, parms	...							|
 *		|_______________________________________________________________|
 */

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	setargent (argc, argv) ;

	parseargs () ;

	prologue () ;

	drudgery () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	parsebits () ;

	if ( ! ( asciiflag || octalflag || hexadflag ) )
		hexadflag = asciiflag = TRUE ;

	if (hexadflag)
		strcat (fmtlst, "x") ;

	if (octalflag)
		strcat (fmtlst, "o") ;

	if (asciiflag) {
		strcat (fmtlst, "a") ;
		if (fmtlst[0] == 'a')
			outsiz = DFL_RECOUTSIZ ;
	}

	if ( varoutsiz > 0 )
		outsiz = varoutsiz ;

	blkfactor = maxbufmem / outsiz ;
	bufblksiz = outsiz * blkfactor ;

	if ( (binbuf = xmalloc (maxbufmem)) == NULL )
		xalert (XA_FATAL, "alocar", NULL, maxbufmem) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	endargent () ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

	stdinflag = TRUE ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	the application itself ...									|
 *		|_______________________________________________________________|
 */

void drudgery () {

	register char * nxtarg ;

	if (stdinflag)
		procfile (NULL) ;
	else
		while ( ( nxtarg = getargent () ) != NULL )
			procany ( nxtarg ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procany (name) char * name ; {

	int		tof ;

	if ( ( tof = filetype (name) ) == T_NONE )
		return xalert (XA_BANAL, "acessar", name, 0) ;

	if ( tof == T_DIR && recurseflag )
		return procdir (name) ;
	else
		return procfile (name) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procdir (name) char * name ; {

	register char * np ;
	register DIRDES * ddp ;
	char nb [256] ;

	/* procfile (name) ; */			/* must be able to dump a dir */

	if ( ( ddp = setdirent (name) ) == NULL )
		return xalert (XA_BANAL, "acessar diretorio", name, 0) ;

	while ( ( np = getdirent (ddp) ) != NULL ) {
		sprintf (nb, "%s%c%s", name, DIRSEP, np) ;
		procany (nb) ;
	}

	return enddirent (ddp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int procfile (name) char * name ; {

	register	int			bytesread , bytecnt , outcnt , byte ;
	register	long		offset = 0L ;
	register	char *		bufptr ;
	register	char *		fmtptr ;

	FILE * fp = stdin ;

	if (stdinflag)
		name = "stdin" ;
	else
		if ( (fp = fopen (name, "rb")) == NULL )
			return xalert (XA_BANAL, "acessar", name, 0) ;

	for ( ; ; ) {

		/* read a blockfull of bytes ... */

		bytesread = fread (bufptr = binbuf, 1, bufblksiz, fp) ;

		if (bytesread <= 0)
			break ;

		/* walk through dumping those bytes ... */

		for ( bytecnt = 0 ; bytecnt < bytesread ; bytecnt += outsiz ) {

			if (offsetflag)
				printf (offsetfmt, offset) ;

			/* for all the selected views ... */

			for ( fmtptr = fmtlst ; *fmtptr ; ++fmtptr ) {

				printf ("  ") ;

				/* ... dump outsiz bytes at a time ... */

				for ( outcnt = 0 ; outcnt < outsiz ; ++outcnt ) {

					if (fmtgrp == VERTIGRP) {

						switch ( *fmtptr ) {

							case HEXADFMT : printf (" ") ; break ;
							case ASCIIFMT : printf ("  ") ; break ;
						}
					}

					if ( bytecnt + outcnt < bytesread ) {

						byte = *(bufptr+outcnt) & 0x00ff ;

						switch ( *fmtptr ) {

							case HEXADFMT : printf ("%2.2x", byte) ; break ;
							case OCTALFMT : printf ("%3.3o", byte) ; break ;
							case ASCIIFMT : printf ("%c", VB(byte)) ; break ;
						}

					} else {

						switch ( *fmtptr ) {

							case HEXADFMT : printf ("%s", "  ") ; break ;
							case OCTALFMT : printf ("%s", "   "/*, byte*/) ; break ;
							case ASCIIFMT : printf ("%s", " "/*, VB(byte)*/) ; break ;
						}

					}

					if ( ( *fmtptr != ASCIIFMT && outcnt < outsiz - 1 )
					  || ( *fmtptr == ASCIIFMT && fmtgrp == VERTIGRP  ) )
						printf (" ") ;

				} /* endof for (outsiz) */

				if (fmtgrp == VERTIGRP)
					printf ("\n        ") ;

			} /* endof for (fmtlst) */

			printf ("\n") ;
			bufptr += outsiz ;
			offset += outsiz ;

		} /* endof for (bytesread) */

	} /* endof for (bytesinfile) */

	if (fp != stdin)
		fclose (fp) ;

	return 0 ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|  date....   version   history...............................	|
 *		|			 		   											|
 *		|  yy mm dd   v.v bid   ......................................	|
 *		|_______________________________________________________________|
 *		|																|
 *		|  + ...														|
 *		|_______________________________________________________________|
 */

/*
 * vi:tabstop=4
 */
