/*
 *                   _______________________________________________
 *		  /\        |												|
 *		 /  \       |	 psk	 preety stupid (or smart) cypher	|
 *		/ OO \      |_______________________________________________|
 *		\ \/ /      |												|
 *		 \  /       |	 (c) 1994		   alexandre v. r. botao	|
 *		  \/        |_______________________________________________|
 *
 */

# define	VERNAME			"psk"
# define	VERSION			"1.1"
# define	VERCODE			"132"
# define	VERDATE			"2000.03.08"
# define	VERSIGN			"Alexandre Botao"

# define	USE_TIME
# define	USE_STDIO
# define	USE_STDMEM
# define	USE_STDMISC
# define	USE_STDTYP

# include	"abc.h"

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		DOS

# define	LOPSYS			"DOS"

# endif		/* DOS */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		SCOXENIX

# define	LOPSYS			"SCO_XENIX"

# define	ANYX

# endif		/* SCOXENIX */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		IUX

# define	LOPSYS			"INTERACTIVE"

# define	ANYX

# endif		/* IUX */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		SOLARIS

# define	LOPSYS			"SOLARIS"

# define	ANYX

# endif		/* SOLARIS */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		SUNOS

# define	LOPSYS			"SUNOS"

# define	ANYX

# endif		/* SUNOS */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		HPUX

# define	LOPSYS			"HPUX"

# define	ANYX

# endif		/* HPUX */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		AIX

# define	LOPSYS			"AIX"

# define	ANYX

# endif		/* AIX */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		LINUX

# define	LOPSYS			"LINUX"

# define	ANYX

# endif		/* LINUX */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifdef		ANSI
# define				OF(X)	X
# else		/* OLD */
# define				OF(X)	()
# endif		/* ANSI */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# include	<string.h>

# ifdef		NOSTD

void		exit		OF ( (int) ) ;
void *		malloc		OF ( (int) ) ;

# else		/* STDLIB */

# include	<stdlib.h>

# endif		/* NOSTD */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# include	<sys/types.h>
# include	<sys/stat.h>

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	dos' peculiarities ...	|
 *  |___________________________|
 */

# ifdef		DOS

# include	<dir.h>
# include	<dos.h>

typedef		struct ffblk		FFBLK ;

# define	FA_MASK				(FA_ARCH|FA_RDONLY|FA_SYSTEM|FA_HIDDEN)

# endif		/* DOS */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

# ifndef	TRUE
# define	TRUE	1
# endif		/* ndef TRUE */

# ifndef	FALSE
# define	FALSE	0
# endif		/* ndef FALSE */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	data prototypes ...		|
 *  |___________________________|
 */

# ifdef ORIG
typedef		unsigned long		ULONG ;
typedef		char *				STR ;
# endif

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	definitions ...		|
 *  |_______________________|
 */

# define	OPTSIZ				8192	/*	4096	*/

/*
 *	|~~~~~~~~~~~~~~~~~~~|
 *	|	globals ...		|
 *  |___________________|
 */

# include "stdinfo.h"

int			argk ;
int			igncr = FALSE ;

char *		workbuf ;
char		keybuff [40] = { '\0' } ;
char		inpname [80] = { '\0' } ;
char		outname [80] = { '\0' } ;

char * *	argp = (char * *) 0 ;

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	function prototypes ...		|
 *  |_______________________________|
 */

void		usag		OF ( ( void )					) ;
void		preparm		OF ( ( int , char * * )			) ;
int			parmcmp		OF ( ( char * * , char * * )	) ;
void		blowild		OF ( ( char * )					) ;
void		argrow		OF ( ( char * )					) ;

ULONG		updcrc		OF ( ( char * , int )			) ;
int			psk			OF ( ( char * )					) ;

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	entry point + (flags & parms) parsing ...					|
 *	|_______________________________________________________________|
 */

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	/* prologue processing */

	verban () ;

	if ( ( workbuf = (char *) xmalloc (OPTSIZ) ) == NULL ) {
		printf ("psk : memoria insuficiente\n\n") ;
		exit (1) ;
	}

	preparm (argc, argv) ;

	/* command line scanning & parsing */

	if (--argk) {
		while (*++argp) {
			if (**argp == '-') {
				switch ( *((*argp)+1) ) {

					case '-' : /* stdin ... ; */ break ;

					case 'i' : strcpy ( inpname , (*++argp) ) ; break ;

					case 'o' : strcpy ( outname , (*++argp) ) ; break ;

					case 's' : strcpy ( keybuff , (*++argp) ) ; break ;

					case '?' :
					default  : usag () ; return 1 ;
				}
			} else {
				/*	psk (*argp) ;	*/
				fprintf (stderr, "psk: parametro (%s) inexperado ...\n", *argp) ;
			}
		}
	} else {
		/* no-parms @ all ... */
	}

	/* epilogue processing */

	return psk ( /* NULL */ ) ;
}

/*
 *													|~~~~~~~~~~~~~~~|
 *													|	syntax ...	|
 *													|_______________|
 */

void usag () {

	printf ("\nuse: psk [-i pathname] [-o pathname] [-s key] \n\n") ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	parms preprocessing ...		|
 *									|_______________________________|
 */

void preparm (argc, argv) int argc ; char * * argv ; {

# ifdef	DOS

	argk = 0 ;

	while (argc--)
		blowild (*argv++) ;

# ifdef COMMENT
	qsort (argp+1, argk-1, sizeof (char *), parmcmp) ;
# endif

# else	/* ANYX */

	argk = argc ; argp = argv ;

# endif	/* DOS */

}

/*
 *										|~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *										|	parms sorting ...		|
 *										|___________________________|
 */

int parmcmp (a, b) char * * a , * * b ; {

	return strcmp (*a, *b) ;
}

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	wildcards (dos-style regular expressions) explosion ...		|
 *	|_______________________________________________________________|
 */

# ifdef		DOS

void blowild (nam) char * nam ; {
	struct ffblk ffbuf ;
	char fnbuf [ 80 ] ;
	char * fnptr = ffbuf.ff_name ;
	int slasti ;								/* last slash inx	*/
	extern void (*whop) (char *, FFBLK *) ;

	if (findfirst (nam, &ffbuf, FA_MASK) < 0) {
		argrow (nam) ;
		return ;
	}

	if ((slasti = lastoc (nam, '\\')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;
	else if ((slasti = lastoc (nam, ':')) >= 0)
		strcpy (fnptr = fnbuf, nam) ;

	do {

		if (fnptr == fnbuf)
			strcpy (fnptr + slasti + 1, ffbuf.ff_name) ;

		argrow ( fnptr ) ; /* , & ffbuf */

	} while (findnext (&ffbuf) >= 0) ;
}

/*
 *						|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *						|	grow up argument (parameter) list ...	|
 *						|___________________________________________|
 */

void argrow (str) char * str ; {
	register char * * tpp ;
	register char *   tp ;

	tp = (char *) xmalloc (1 + strlen (str)) ;

	if (tp == (char *) 0) {
nm:		fprintf (stderr, "%s: no memory ...\n", swid) ;
		exit (1) ;
	}

	if (argp == (char * *) 0)
		tpp = (char * *) xmalloc (2 * sizeof (char *)) ;
	else
		tpp = (char * *) xmrealloc (argp, (2+argk) * sizeof (char *)) ;

	if (tpp == (char * *) 0)
		goto nm ;

	strcpy (tp, str) ;
	argp = tpp ;
	*(argp+argk) = tp ;
	++argk ;
	*(argp+argk) = (char *) 0 ;
}

# endif		/* DOS */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

void getpasswords () {

	char passbuf [40] , confbuf [40] ;

	for ( ; ; ) {
		strcpy ( (STR) passbuf, (STR) getpass ("key: ")) ;
		strcpy ( (STR) confbuf, (STR) getpass ("chk: ")) ;

		if ( strcmp (passbuf, confbuf) == 0 )
			break ;
		else
			printf ("psk: password mismatch !\n") ;
	}

	strcpy (keybuff, passbuf) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int psk ( /* char * nam */ ) {
	register char * bp , * kp , * ep ;
	register int  bk ;
	FILE * ifp , * ofp ;

	if ( keybuff[0] == '\0' )
		getpasswords () ;

	if ( inpname[0] == '\0' )
		ifp = stdin ;
	else
		if ( (ifp = fopen (inpname, "rb")) == (FILE *) 0 ) {
			fprintf (stderr, "psk: ERRO ao abrir %s\n", inpname) ;
			return -1 ;
		}

	if ( outname[0] == '\0' )
		ofp = stdout ;
	else
		if ( (ofp = fopen (outname, "wb")) == (FILE *) 0 ) {
			fprintf (stderr, "psk: ERRO ao criar %s\n", outname) ;
			return -1 ;
		}

	kp = keybuff ;

	while ( (bk = fread (workbuf, 1, OPTSIZ, ifp)) > 0 ) {

		for ( bp = workbuf , ep = bp + bk ; bp < ep ; ++bp ) {
			if (*kp == '\0')
				kp = keybuff ;
			*bp ^= ~ *kp ; ++kp ;
		}

		fwrite (workbuf, 1, bk, ofp) ;
	}

	fclose (ofp) ;
	fclose (ifp) ;
	return 0 ;
}

/*		 ___________________________________________________________
 *		|															|
 *		|  date....   version   history...........................	|
 *		|			 		   										|
 *		|  yy mm dd   v.v rls   ..................................	|
 *		|___________________________________________________________|
 *		|															|
 *		|  + set work buffer size (-b #) ...						|
 *		|___________________________________________________________|
 */

/*
 * vi:nu ts=4
 */
