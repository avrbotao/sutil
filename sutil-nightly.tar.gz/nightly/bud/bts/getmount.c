
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |   +55-11-98244-UNIX   |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*	 _______________________________________________________________
 *	|								|
 *	|	getmount				 (point)	|
 *	|_______________________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# include "configure.h"
# include "absd.h"

# include <time.h>
# include <stdio.h>
# include <string.h>
# include <signal.h>
# include <unistd.h>
# include <sys/utsname.h>

# include "abcs.h"

/*____________________________________________________________________________
*/

# ifdef CYGWIN
# define	USE_STATFS
# define	ulong_t		unsigned long
# endif /* CYGWIN */

# ifdef LINUX
# define	USE_STATVFS
# define	HASFRSIZE
# include <stdint.h>
# define ulong_t	ulong
# endif /* LINUX */

# ifdef HPUX
# define	USE_STATVFS
# endif /* HPUX */

# ifdef USE_STATFS
# ifndef ANYBSD
# include <sys/vfs.h>
# endif
struct statfs	sfsbuf ;
int32_t	x_bavail;  /* free blocks available to non-superuser */
int32_t	x_bfree;   /* free blocks */
int32_t	x_blocks;  /* total blocks in file system */
int32_t	x_bsize;   /* fundamental file system block size in bytes */
int32_t x_bused;
# endif /* USE_STATFS */

# ifdef USE_STATVFS
# include <sys/types.h>
# include <sys/statvfs.h>
struct statvfs	svfsbuf ;
# ifdef NETBSD
typedef unsigned long ulong_t ;
# endif
ulong_t x_bsize;              /* preferred file system block size */
ulong_t x_frsize;             /* fundamental file system block size */
ulong_t x_blocks;             /* total blocks of f_frsize on file system */
ulong_t x_size;               /* size of file system in f_frsize unit */
ulong_t x_bfree;              /* free blocks */
ulong_t x_bavail;             /* blocks available to non-superuser */
ulong_t x_bused;
# endif /* USE_STATVFS */

# ifdef AIX
# include <mntent.h>
# define X_FILESYSLIST	MNTTAB		/* "/etc/filesystems"	*/
# define X_MOUNTEDLIST	MOUNTED		/* "/etc/mtab"		*/
# define XDF_IGNLST "procfs"
# define XDF_SYSLST "/","/home","/opt","/proc","/usr","/var","/tmp","/var/adm/ras/livedump"
# endif /* AIX */

# ifdef HPUX
# include <mntent.h>
# define X_FILESYSLIST	MNT_CHECKLIST	/* "/etc/fstab"		*/
#   ifdef HPUX1111
#	define X_MOUNTEDLIST	"/etc/fstab"	/* avoid hangs */
#   else
#	define X_MOUNTEDLIST	MNT_MNTTAB	/* "/etc/mnttab"	*/
#   endif
# define XDF_IGNLST "swap"
# define XDF_SYSLST "/","/home","/opt","/stand","/usr","/var","/tmp"
# endif /* HPUX */

# ifdef LINUX
# include <mntent.h>
# define X_FILESYSLIST	MNTTAB		/* "/etc/fstab"		*/
# define X_MOUNTEDLIST	MOUNTED		/* "/etc/mtab"		*/
# define XDF_IGNLST "proc","udev","none","devtmpfs","tmpfs","sysfs","devpts","fusectl","nfsd","securityfs","binfmt_misc","fuse.gvfs-fuse-daemon"
# define XDF_SYSLST "/","/boot","/dev","/home","/opt","/usr","/var","/tmp"
# endif /* LINUX */

# ifdef CYGWIN
# include <mntent.h>
# define X_FILESYSLIST	MNTTAB		/* "/etc/fstab"		*/
# define X_MOUNTEDLIST	MOUNTED		/* "/etc/mtab"		*/
# define XDF_IGNLST "proc","C:/cygwin","C:/cygwin/bin","C:/cygwin/lib"
# define XDF_SYSLST "/","/usr/bin","/usr/lib"
# endif /* CYGWIN */

# ifdef SUNX
# include <sys/mnttab.h>
# define X_FILESYSLIST	"/etc/vfstab"
# define X_MOUNTEDLIST	MNTTAB		/* "/etc/mnttab"	*/
# define setmntent(N,M)	fopen(N,M)
# define endmntent(P)	fclose(P)
# define XDF_IGNLST "ctfs","proc","mnttab","tmpfs","objfs","sharefs","fd"
# define XDF_SYSLST "/","/devices","/opt","/usr","/var","/tmp","/etc/svc/volatile","/var/run"
# endif /* SUNX */

#ifdef FREEBSD
# include <sys/param.h>
# include <sys/ucred.h>
# include <sys/mount.h>
typedef		struct statfs		FSSBUF ;
typedef		long			fsstabsiz_t ;
# define	F_BLOCKSIZE		f_bsize
# define	FSSFILL			getfsstat
# define XDF_IGNLST "devfs","procfs","linprocfs"
# define XDF_SYSLST "/","/var","/usr","/tmp"
#endif

#ifdef OPENBSD
# include <sys/param.h>
# include <sys/mount.h>
typedef		struct statfs		FSSBUF ;
typedef		long			fsstabsiz_t ;
# define	F_BLOCKSIZE		f_bsize
# define	FSSFILL			getfsstat
# define XDF_IGNLST "swap"
# define XDF_SYSLST "/","/home","/usr"
#endif

#ifdef NETBSD
# include <sys/types.h>
# include <sys/statvfs.h>
typedef		struct statvfs		FSSBUF ;
typedef		size_t			fsstabsiz_t ;
# define	F_BLOCKSIZE		f_frsize
# define	FSSFILL			getvfsstat
# define XDF_IGNLST "kernfs","ptyfs","procfs"
# define XDF_SYSLST "/"
#endif

/*____________________________________________________________________________
*/

# define	MAXDIRLST	1024
# define	DFLTIMOUT	2

# ifdef		ANYBSD
# define	MAXFSS		1024
# endif		/* ANYBSD */

/*	__	__	__	__	__	__	__	__	__
*/

#ifdef BUG2
static int	helpflag = 0 ;
#endif

long long	xfs_blksiz ;
long long	xfs_totbyt ;
long long	xfs_usebyt ;
long long	xfs_avabyt ;

int		xfs_caperc ;
int		xfs_tmperc ;	/* temporary '%free' ( 100 - caperc ) */

int		sumcaperc = 0LL ;
int		sumtmperc = 0LL ;

long long	sumtotbyt = 0LL ;
long long	sumusebyt = 0LL ;
long long	sumavabyt = 0LL ;

long long	unit = 1 ;

int	sectorflag = 0 ;
int	identflag = 0 ;
int	fstabflag = 0 ;
int	verbflag = 0 ;
int	echoflag = 0 ;
int	hostflag = 0 ;
int	kiloflag = 0 ;
int	megaflag = 0 ;
int	gigaflag = 0 ;
int	teraflag = 0 ;
int	listflag = 0 ;
int	freeflag = 0 ;
int	sumflag = 0 ;
int	volflag = 0 ;
int	sizflag = 0 ;
int	useflag = 0 ;
int	avaflag = 0 ;
int	capflag = 0 ;
int	legflag = 0 ;
int	optflag = 0 ;
int	hdrflag = 0 ;
int	sysflag = 0 ;
int	regflag = 0 ;
int	nfsflag = 0 ;

int	volcount = 0 ;
int	timedout = 0 ;
int	xtimeout = DFLTIMOUT ;

int	hostwid = 12 ;
int	volwid = 24 ;
int	dirwid = 24 ;
int	bigwid = 15 ;

char *	lotime = "localtime" ;
char *	osname = "Unix" ;
char *	osvers = "5" ;
char *	osrels = "4" ;
char *	noname = "NodeName" ;
char *	hostname = "hostname" ;
char *	unitname = "bytes" ;

char	versno [16] ;
char	banner [80] ;
char	hident [128] ;

char * ignlst [] = { XDF_IGNLST , NULL } ;
char * syslst [] = { XDF_SYSLST , NULL } ;

char * dirlst [MAXDIRLST] ;

struct utsname	utsbuf ;

# ifdef		ANYBSD

int fsscount ;
int fsno ;
int fssflags = 0 ;

fsstabsiz_t fsstabsiz ;

FSSBUF fsstab [ MAXFSS ] ;

FSSBUF * fssp ;

# endif		/* ANYBSD */

/*	__	__	__	__	__	__	__	__	__
*/

void wakeup (signo) int signo ; {
	if ( signo != SIGALRM ) {
		fprintf (stderr, "** unexpected signal (%d)\n", signo) ;
		return ;
	}
	alarm (0) ;
	signal (SIGALRM, wakeup) ;
	alarm (0) ;
	++timedout ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void ydf (vol, name, opts) char * vol , * name , * opts ; { /* o.s.-independent stuff */

	if ( vol == NULL )
		vol = "unknown" ;

	if ( name == NULL )
		name = "unknown" ;

	if ( opts == NULL )
		opts = "defaults" ;

	x_bused  = x_blocks - x_bfree ;

	xfs_totbyt = ( xfs_blksiz * x_blocks ) / unit ;
	xfs_usebyt = ( xfs_blksiz * x_bused ) / unit ;
	xfs_avabyt = ( xfs_blksiz * x_bavail ) / unit ;

	xfs_caperc = xfs_totbyt ? ( xfs_usebyt * 100 ) / xfs_totbyt : 0 ;
	xfs_tmperc = 100 - xfs_caperc ;

	++volcount ;

	if ( sumflag ) {
		sumtotbyt += xfs_totbyt ;
		sumusebyt += xfs_usebyt ;
		sumavabyt += xfs_avabyt ;
		sumcaperc += xfs_caperc ;
		sumtmperc += xfs_tmperc ;
	}
}

/*	__	__	__	__	__	__	__	__	__
*/

void xdf (vol, name, opts) char * vol , * name , * opts ; {

	int	rd = -1 ;

# ifdef	ANYBSD
	if ( vol == NULL /* || listflag */ ) {
# endif	/* ANYBSD */

		signal (SIGALRM, wakeup) ; timedout = 0 ; alarm (xtimeout) ;

# ifdef USE_STATFS
		rd = statfs (name, &sfsbuf) ;
# endif /* USE_STATFS */

# ifdef USE_STATVFS
		rd = statvfs (name, &svfsbuf) ;
# endif /* USE_STATVFS */

		alarm (0) ;

		if ( timedout ) {
			fprintf (stderr, "** timeout on %s\n", name != NULL ? name : vol != NULL ? vol : "unknown") ;
			return ;
		}

		if ( rd != 0 ) {
			perror (name) ;
			return ;
		}

# ifdef	ANYBSD
	} else {
		x_bavail = fssp->f_bavail ;
		x_bfree  = fssp->f_bfree ;
		x_blocks = fssp->f_blocks ;
		x_bsize  = fssp->F_BLOCKSIZE ;
		xfs_blksiz = x_bsize ;
		goto osis ;
	}
# endif	/* ANYBSD */

# ifdef USE_STATFS
	x_bavail = sfsbuf.f_bavail ;
	x_bfree  = sfsbuf.f_bfree ;
	x_blocks = sfsbuf.f_blocks ;
	x_bsize  = sfsbuf.f_bsize ;
	xfs_blksiz = x_bsize ;
# endif /* USE_STATFS */

# ifdef USE_STATVFS
	x_bavail = svfsbuf.f_bavail ;
	x_bfree  = svfsbuf.f_bfree ;
	x_blocks = svfsbuf.f_blocks ;
	x_bsize  = svfsbuf.f_bsize ;
# ifdef HAS_VFS_F_SIZE
	x_size   = svfsbuf.f_size ;
# endif /* HAS_VFS_F_SIZE */
	x_frsize = svfsbuf.f_frsize ;
	xfs_blksiz = x_frsize ;
# endif /* USE_STATVFS */

# ifdef	ANYBSD
osis:
# endif	/* ANYBSD */
	if ( x_blocks == 0 )
		return ;

	ydf ( vol , name , opts ) ; /* o.s.-independent stuff */
}

/*	__	__	__	__	__	__	__	__	__
*/

int chkign (name) char * name ; {

	char * * pp ;

	if ( name == NULL )
		return 1 ;

	for ( pp = ignlst ; *pp != NULL ; ++pp )
		if ( strcmp ( name , *pp ) == 0 )
			return 3 ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int chksys (name) char * name ; {

	char * * pp ;

	if ( name == NULL )
		return 1 ;

	for ( pp = syslst ; *pp != NULL ; ++pp )
		if ( strcmp ( name , *pp ) == 0 )
			return 3 ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void getuname () {
	int rd ;

	rd = uname (&utsbuf) ;

	if ( rd == -1 )
		perror ("uname") ;

	osname = utsbuf.sysname ;
	noname = utsbuf.nodename ;
	osvers = utsbuf.version ;
	osrels = utsbuf.release ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int ldf () {

	FILE * mfp ;
# ifdef SUNX
	struct mnttab mntbuf ;
# else
	struct mntent * mtp ;
# endif /* SUNX */
	char *	x_fsname; /* file system name */ 
	char *	x_dir;    /* file system path prefix */ 
	char *	x_type;
	char *	x_opts;
	char *	tp ;
	time_t	tloc ;
	int j ;

# ifdef		CYGWIN
	if ( ! sysflag)
		++regflag ;
# endif		/* CYGWIN */

	getuname () ;

# ifdef		ANYBSD
	fsstabsiz = MAXFSS * sizeof ( FSSBUF ) ;
# endif		/* ANYBSD */

	if ( hostflag ) {
		/* gethostname () ; */
		hostname = noname ;
	}

	if ( identflag ) {
		time ( &tloc ) ;
		lotime = ctime ( &tloc ) ;
		tp = lotime + strlen (lotime) ;
		if ( *--tp == '\n' )
			*tp = '\0' ;
		sprintf (hident, "%s %s v%s r%s %s", noname, osname, osvers, osrels, lotime) ;
	}

	if ( legflag ) {
		++volflag ;
		++sizflag ;
		++useflag ;
		++avaflag ;
		++capflag ;
		++hdrflag ;
		++kiloflag ;
	}

	if ( capflag ) {
		freeflag = 0 ; /* capflag prevails if both are inadvertently set */
	} else {
		if ( freeflag ) {
			capflag = 0 ; /* there can be only one ! */
		}
	}

	if ( sectorflag ) {
		unit = 512LL ;
		bigwid = 15 ;
		unitname = "Sec" ;
	}

	if ( kiloflag ) {
		unit = 1024LL ;
		bigwid = 12 ;
		unitname = "KiB" ;
	}

	if ( megaflag ) {
		unit = 1048576LL ;
		bigwid = 9 ;
		unitname = "MiB" ;
	}

	if ( gigaflag ) {
		unit = 1073741824LL ;
		bigwid = 6 ;
		unitname = "GiB" ;
	}

	if ( listflag ) {
		for ( j = 0 ; j < listflag ; ++j ) {
			xdf (NULL, dirlst[j], NULL) ;
		}
	} else {
# ifdef	ANYBSD
		fsscount = FSSFILL ( fsstab , fsstabsiz , fssflags ) ;
		for ( fsno = 0 , fssp = fsstab ; fsno < fsscount ; ++fsno , ++fssp ) {
			x_type   = fssp->f_fstypename ;
			x_fsname = fssp->f_mntfromname ; 
			x_dir    = fssp->f_mntonname ;
# else	/* ANYBSD */
			if ( fstabflag ) {
				mfp = setmntent ( X_FILESYSLIST , "r" ) ;
			} else {
				mfp = setmntent ( X_MOUNTEDLIST , "r" ) ;
			}
			if ( mfp == NULL ) {
				perror ( X_MOUNTEDLIST ) ;
				return 2 ;
			}
#	ifdef	SUNX
			while ( getmntent ( mfp , &mntbuf ) == 0 ) {
				x_fsname = mntbuf.mnt_special ;
				x_dir    = mntbuf.mnt_mountp ;
				x_type   = mntbuf.mnt_fstype ;
				x_opts   = mntbuf.mnt_mntopts ;
#	else	/* SUNX */
			while ( ( mtp = getmntent ( mfp ) ) != NULL ) {
				x_fsname = mtp->mnt_fsname ;
				x_dir    = mtp->mnt_dir ;
				x_type   = mtp->mnt_type ;
				x_opts   = mtp->mnt_opts ;
#	endif	/* SUNX */
# endif	/* ANYBSD */
				if ( chkign ( x_type ) ) {
					continue ;
				}
				if ( 0 == strcmp ( x_type , "nfs" ) ) {
					if ( ! nfsflag ) {
						continue ;
					}
				}
				if ( sysflag ) {
					if ( ! chksys ( x_dir ) ) {
						continue ;
					}
				}
				if ( regflag ) {
					if ( chksys ( x_dir ) ) {
						continue ;
					}
				}
				if ( echoflag ) {
					if ( chkign ( x_fsname ) ) {
						continue ;
					}
				}
# ifdef BUG3
				fprintf (stderr, "typ(%s) fsn(%s) dir(%s) opt(%s)\n", x_type, x_fsname, x_dir, x_opts) ;
# endif /* BUG3 */
				xdf (x_fsname, x_dir, x_opts) ;
# ifndef ANYBSD
			} /* eowhile ( getmntent ) */
			endmntent ( mfp ) ;
# else   /* ! ANYBSD */
		} /* eofor ( fsstab ) */
# endif  /* ! ANYBSD */
	} /* endif ( listflag ) */	

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int sdf (name) char * name ; {
	if ( name == NULL )
		return -1 ;
	if ( listflag == MAXDIRLST )
		return -1 ;
	dirlst[listflag++] = strdup (name) ;
	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

char * getmount ( path ) char * path ; {

	register	char *		point = path ;

	return point ;
}

/*____________________________________________________________________________
*/

#ifdef BUG2

int main (argc, argv) int argc ; char * * argv ; {

	if (--argc) {
		while (*++argv) {
			if ( strcmp ( *argv , "--help" ) == 0 )
				++helpflag ;
			else if ( strcmp ( *argv , "-V" ) == 0 )
				++verbflag ;
			else if ( strcmp ( *argv , "-?" ) == 0 )
				++helpflag ;
			else
				fprintf (stderr, "%s: bad arg (%s)\n", "getmount", *argv) ;
		}
	}

	return ldf () ;
}

#endif

/*____________________________________________________________________________
*/

#ifdef XBSD

main () {
	for ( fsno = 0 , fssp = fsstab ; fsno < fsscount ; ++fsno , ++fssp ) {
		printf ( "%s %s %lld %lld %s \n" , 
			fssp->f_fstypename ,
			fssp->f_mntfromname , 
			(long long) fssp->F_BLOCKSIZE , 
			(long long) fssp->f_blocks , 
			fssp->f_mntonname
		) ;
	}
}

#endif

/*____________________________________________________________________________
 * vi:nu ts=8
 */
