
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*
 *
 *		  /\		 ___________________________________________________
 *		 /  \		|													|
 *		/ OO \		|	argent			handle free command line args	|
 *		\ \/ /		|	(c) 1999-2015			alexandre v. r. botao	|
 *		 \  /		|___________________________________________________|
 *		  \/
 *
 */

# include <stdio.h>
# include <string.h>

# include "argent.h"

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int		noteused = 0 ;
int		argindex = 0 ;

char *	notelist [MAXARGENT] ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void setargent ( void ) {
	argindex = 0 ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void endargent ( void ) {
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

int totargent ( void ) {
	return noteused ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

char * getargent ( void ) {
	if ( argindex >= noteused )
		return NULL ;
	else
		return notelist [ argindex++ ] ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

void addargent (
				char * name
) {
	if ( noteused < MAXARGENT )
		notelist [ noteused++ ] = strdup (name) ;
}

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__
*/

/*
 * vi:nu tabstop=4
 */

