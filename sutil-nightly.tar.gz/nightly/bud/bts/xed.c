
/*
 *                   ___________________________________________________
 *		  /\        |													|
 *		 /  \       |	xed				  portable sk/ws-style editor	|
 *		/ OO \      |___________________________________________________|
 *		\ \/ /      |													|
 *		 \  /       |	(c) 1993-2001			alexandre v. r. botao	|
 *		  \/        |___________________________________________________|
 *
 */

# define	VERNAME			"xed"
# define	VERSION			"2.4"
# define	VERCODE			"482"
# define	VERDATE			"2001.05.01"
# define	VERSIGN			"Alexandre Botao"

# define	USE_STDIO
# define	USE_CTYPE
# define	USE_STDLIB
# define	USE_SYSTYPES

# define	USE_STDTIME
# define	USE_STDSTAT
# define	USE_STDTERM
# define	USE_STDCAP
# define	USE_STDKEY
# define	USE_STDVIF
# define	USE_STDCMD
# define	USE_STDCOLOR
# define	USE_STDLOGIC
# define	USE_STDMATCH
# define	USE_STDASC
# define	USE_STDTYP
# define	USE_STDTIO
# define	USE_STDWIN
# define	USE_STDMISC
# define	USE_STDPARM
# define	USE_STDMEM
# define	USE_STDBOX
# define	USE_STDSTR
# define	USE_STDFILE
# define	USE_STRLIST

# include	"abc.h"

# include	<signal.h>
# include	<unistd.h>

/*________________________________________________________________________
*/
#ifdef OpenBSD
#	define	strcat(D,S)		strlcat(D,S,sizeof(D))
#	define	strcpy(D,S)		strlcpy(D,S,sizeof(D))
# endif
/*________________________________________________________________________
*/

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	includes & pre-defines : dos ...			|
 *					|_______________________________________________|
 */

# ifdef DOS

#	include <stdlib.h>
#	include <conio.h>
#	include <io.h>
#	include <alloc.h>
#	include <dos.h>
#	include <dir.h>

#	define	OPSYS			"DOS"
#	define	SHELLVAR		"COMSPEC"
#	define	SHELLCMD		"command"
#	define	XEDPAGESIZE		25
#	define	EOLSIZE		     2

# endif /* DOS */

/*
 *					|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *					|	includes & pre-defines : any unix ...		|
 *					|_______________________________________________|
 */

# ifdef ANYX

#	define	USE_SHELLVAR

#	define	SHELLVAR		"SHELL"
#	define	SHELLCMD		"sh"
#	define	XEDPAGESIZE		24
#	define	EOLSIZE		     1

# endif /* ANYX */

# if defined ( AIX ) || defined ( BSD )
# define        TLOC        time_t
# else
# define        TLOC        long
# endif

/*
 *			#########################################################
 *			#	defines ...											#
 *			#########################################################
 */

# define	DFL_TMPLINBUFSIZ  2048

# define	FILENAMESIZE	   128

# define	LINESIZE		   512
# define	MAXFILES		   256

# define	LINEGRAIN		    16
# define	BUFFGRAIN		  1024 /*    256 */
# define	GRAINBITS		    10 /*      8 */
# define	GRAINMASK		0x03ff /* 0x00ff */

# define	MINTABSIZ		     2
# define	MAXTABSIZ		    16

# define	MINPAGSIZ		     8
# define	MAXPAGSIZ		   160

# define	MINPAGWID		    20
# define	MAXPAGWID		   512

# define	BAKSUFFIX		".bak"
# define	NONAME			"<< novo >>"

# define	MESGLINE		(pagesize + 1)
# define	HELPPAGE		(pagesize - 2)
# define	SIDESHIFT		(tabsize << 1)

# define	LINEBLOCK		  0x01
# define	WORDBLOCK		  0x02
# define	TRUEBLOCK		  0x04

# define	YES				'y'
# define	NO				'n'

# define	POS_INS			35
# define	POS_EXACT		39
# define	POS_CRAP		43

# define	SAVEFILE		'f'
# define	SAVEBLOCK		'b'
# define	SAVEPASTE		'p'
# define	SAVEAS			'a'

/*
 *			#########################################################
 *			#	globals ...											#
 *			#########################################################
 */

# include "stdinfo.h"

PARMINFO	parminfo [] = {

# include "deflbits.h"

} ;

char * syntxt [] = {

	"\n",
	" use : ", VERNAME, " [-abmELV?] [-p #] [-t #] arq ... \n",
	"\n",

	"  -a : monitor monocromatico (video reverso) \n",
	"  -b : nao faz backup \n",
	"  -m : monitor monocromatico \n",
	"  -p <linhas-por-pagina> \n",
	"  -t <tabsize> \n",

# include "stdflag.h"

	NULL

} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int			loadlines = -1 ;
int			readlines ;

int			totlines ;
long		totbytes ;

int			pageline ;
int			buffline ;
int			buffcol ;

int			videoline ;
int			videocol ;

int			tabsize = 4 ;
int			leftoff = 0 ;
int			pageparm = 0 ;

int			textline ;
int			textcol ;
int			textsize ;
int			swapsize ;

int			setcursor	= FALSE ;
int			linechanged	= FALSE ;
int			crapchanged	= FALSE ;
int			colchanged	= FALSE ;
int			realcol		= FALSE ;
int			hardscroll	= FALSE ;

int			debugflag	= FALSE ;

int			insert = TRUE ;
int			indent = FALSE ;
int			mexact = TRUE ;
int			craped = FALSE ;
int			backitup = TRUE ;

int			blockfirst = -1 ;
int			blocklast  = -1 ;
int			blockleft  = -1 ;
int			blockright = -1 ;
int			blockwidth = 0 ;
int			blocktype  = LINEBLOCK ;
int			showblock  = TRUE ;

int			optimio    = FALSE ;

TLOC		iostart	= 0L ;
TLOC		ioend	= 0L ;
long		iotime	= 0L ;
ULONG		iobytes	= 0L ;
ULONG		iorate	= 0L ;

ULONG		maxmem ;
ULONG		tmpmem ;
ULONG		availmem ;
ULONG		reqmem = 0L ;

int			totfiles = 0 ;
int			fileindex = 0 ;

int			linbufsiz = DFL_TMPLINBUFSIZ ;

char *		tmplinbuf = NULL ;

char *		textfiles [MAXFILES] ;

char *		currfile  = NULL ;

char * *	editbuff  = NULL ;

char		cwdname	   [128] = { NUL } ;
char		shellbuff  [40] ;
char		cmdbuff    [256] ;

char		wordbuff   [256] = { NUL } ;
char		textbuff   [256] = { NUL } ;
char		swapbuff   [256] = { NUL } ;

char		namebuff   [FILENAMESIZE] = { NUL } ;
char		blockname  [FILENAMESIZE] = { NUL } ;
char		pastename  [FILENAMESIZE] = { NUL } ;
char		saveasname [FILENAMESIZE] = { NUL } ;
char		bakname    [FILENAMESIZE] = { NUL } ;
char		prevname   [FILENAMESIZE] = NONAME ;
char		mkstemplate[FILENAMESIZE] = "/tmp/.xed_XXXXXX" ;

char		baksuffix  [ 8] = BAKSUFFIX ;

int *		lenbuff  = NULL ;

STABUF		stabuf ;

WINDES *	wp ;

extern int	kbdreflect ;

extern int	monochrome ;
extern int	monopaper ;
extern int	linesize ;
extern int	pagesize ;

# ifdef DOS

unsigned	_stklen  = 16384 /* 8192 */ ;

# endif /* DOS */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * xedmesg [] = {
	"erro ao abrir",
	"memoria insuficiente",
	"F1=help F2=save F3=edit F4=find F5=next F6=linB F7=iniB F8=fimB F9=exec F10=fim*",
	"      lin %-5d col %-3d tab %-2d %3s %3s %3s %c %-39.39s",
	"\n \"%s\" %s * %s @ %s / %s (C) %s \n\n",
	"erro ao renomear",
	"fazendo BACK UP ...",
	"GRAVANDO o arquivo ...",
	"erro ao criar",
	"erro ao remover",
	"AVISO ! arquivo modificado : SALVA ? (s/n) ",
	"Nome do arquivo",
	"erro ao inicializar o terminal ...",
	"informe o tamanho do TAB : ",
	"LENDO o arquivo ...",
	"informe o numero da linha : ",
	"procurar : ",
	"texto nao encontrado ...",
	"PESQUISANDO o texto ...",
	"Substituir : ",
	"Por : ",
	"Substitui ? (s/n) ",
	"AVISO ! arquivo ja' existe : DESTROI ? (s/n) ",
	"informe a altura da pagina : ",
	"informe a largura da linha : ",
	"ERRO INTERNO -->",
	"caracteristica de terminal nao encontrada -->",
	"caracteristica de terminal nao definida -->",
	"erro ao gravar em",
	"erro ao obter status",
	"erro ao setar status",
	"salvar como : ",
	"@ ",
	"problema com o log --> ",
	"liberando memoria",
	NULL
} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	XM_CANTOPEN		     0
# define	XM_NOMEM		     1
# define	XM_PFMENU		     2
# define	XM_STATUS		     3
# define	XM_BANNER		     4
# define	XM_CANTRENAME	     5
# define	XM_WAITBACKUP	     6
# define	XM_WAITSAVE		     7
# define	XM_CANTCREATE	     8
# define	XM_CANTREMOVE	     9
# define	XM_SAVECHANGES	    10
# define	XM_FILENAME		    11
# define	XM_TERMERR		    12
# define	XM_TABSIZE		    13
# define	XM_WAITLOAD		    14
# define	XM_LINENUMB		    15
# define	XM_LOOKFOR		    16
# define	XM_NOTEXT		    17
# define	XM_WAITSEARCH	    18
# define	XM_REPLACE		    19
# define	XM_BY			    20
# define	XM_CHANGEIT		    21
# define	XM_OVERWRITE	    22
# define	XM_PAGSIZE		    23
# define	XM_PAGWID		    24
# define	XM_CTRLERR		    25
# define	XM_NOCAP		    26
# define	XM_NULCAP		    27
# define	XM_CANTWRITE	    28
# define	XM_STATERR		    29
# define	XM_CHMODERR		    30
# define	XM_SAVEAS		    31
# define	XM_PROMPT		    32
# define	XM_LOGERR		    33
# define	XM_WAITMEM		    34

# define	XM_FATAL		0x25600

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char * helptext [] = {

	 " ",
	 " proxima pagina ....................... ^C     PgDn    ",
	 " pagina anterior ...................... ^R     PgUp    ",
	 " primeira pagina ...................... ^Q^R   ^PgUp   ",
	 " ultima pagina ........................ ^Q^C   ^PgDn   ",
	 " ",
	 " cursor acima ......................... ^E     Up      ",
	 " cursor abaixo ........................ ^X     Down    ",
	 " cursor a direita ..................... ^D     Right   ",
	 " cursor a esquerda .................... ^S     Left    ",
	 " ",
	 " proxima palavra ...................... ^F     ^Right  ",
	 " palavra anterior ..................... ^A     ^Left   ",
	 " ",
	 " inicio da linha ...................... ^Q^S   Home    ",
	 " fim da linha ......................... ^Q^D   End     ",
	 " alto da pagina ....................... ^Q^E   ^Home   ",
	 " base da pagina ....................... ^Q^X   ^End    ",
	 " ",
	 " rola tela p/ cima .................... ^Z     ^Up     ",
	 " rola tela p/ baixo ................... ^W     ^Down   ",
	 " ",
	 " salva e termina ...................... ^K^X           ",
	 " salva e continua ..................... ^K^S   F2      ",
	 " salva e edita ........................ ^K^D           ",
	 " salva como ........................... ^K^A           ",
	 " ",
	 " proximo arquivo ...................... ^K^N           ",
	 " alterna arq. atual e anterior ........ ^K^Z           ",
	 " edita outro .......................... ^K^E   F3      ",
	 " termina .............................. ^K^Q   F10     ",
	 " ",
	 " inicio de bloco ...................... ^K^B   F7      ",
	 " fim de bloco ......................... ^K^K   F8      ",
	 " marca palavra ........................ ^K^T           ",
	 " marca linha .......................... ^K^L   F6      ",
	 " copia bloco .......................... ^K^C           ",
	 " move  bloco .......................... ^K^V           ",
	 " deleta bloco ......................... ^K^Y           ",
	 " le bloco ............................. ^K^R           ",
	 " grava bloco .......................... ^K^W           ",
	 " desmarca bloco ....................... ^K^H           ",
	 " salva bloco .......................... ^K^O           ",
	 " cola  bloco .......................... ^K^I           ",
	 " ",
	 " pesquisa texto ....................... ^Q^F   F4      ",
	 " repete pesquisa ...................... ^L     F5      ",
	 " substitui texto ...................... ^Q^A           ",
	 " pesquisa exata ....................... ^Q^P           ",
	 " ",
	 " insercao (on/off) .................... ^V     Ins     ",
	 " ",
	 " deleta caractere ..................... ^G     Del     ",
	 " deleta linha ......................... ^Y             ",
	 " deleta palavra ....................... ^T             ",
	 " deleta `a direita .................... ^Q^Y           ",
	 " ",
	 " abre um shell ........................ ^O^S   F11     ",
	 " executa comando ...................... ^O^X   F9      ",
	 " tamanho do tab ....................... ^O^T           ",
	 " refaz a tela ......................... ^O^P           ",
	 " informacoes .......................... ^O^I   F12     ",
	 " help geral ........................... ^O^H   F1      ",
	 " ",
	 " linhas por pagina .................... ^O^G           ",
	 " colunas por linha .................... ^O^W           ",
	 " coluna real (on/off) ................. ^O^C           ",
	 " otimiza i/o (on/off) ................. ^O^O           ",
	 " recarrega arquivo .................... ^O^L           ",
	 " duplica linha ........................ ^O^D           ",
	 " ",
	 " concatena linhas ..................... ^Q^G           ",
	 " acha linha ........................... ^Q^L           ",
	 " acha inicio de bloco ................. ^Q^B           ",
	 " acha fim de bloco .................... ^Q^K           ",
	 " ",
	 " converte maiusculas/minusculas ....... ^Q^U           ",
	 " ",

	 NULL
} ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *	__swid__ = VERNAME ;
char *	__vers__ = VERSION ;
char *	__relz__ = VERCODE ;
char *	__date__ = VERDATE ;
char *	__avrb__ = VERSIGN ;

/*
 *		#############################################################
 *		#	function prototypes ...									#
 *		#############################################################
 */

void	xed				OF ( (void)				) ;
void	banner  		OF ( (void)				) ;
void	syntax  		OF ( (void)				) ;
void	credits  		OF ( (void)				) ;

void	loadctrl		OF ( (void)				) ;
void	savectrl		OF ( (void)				) ;
void	washctrl		OF ( (void)				) ;

void	mesgerr  		OF ( (int, char *)		) ;
void	mesgwait		OF ( (int)				) ;
int		mesginput  		OF ( (int, char *)		) ;
int		yesorno			OF ( (int)				) ;
int		waitcont		OF ( (void)				) ;

void	prologue 		OF ( (void)				) ;
void	epilogue 		OF ( (void)				) ;

void	initbuff		OF ( (void)				) ;
void	freebuff 		OF ( (void)				) ;

void	loadfile		OF ( (void)				) ;
int		editfile		OF ( (void)				) ;
int		reloadit		OF ( (void)				) ;

void	savefile		OF ( (void)				) ;
void	savecont		OF ( (void)				) ;
int		saveedit		OF ( (void)				) ;
void	saveexit		OF ( (void)				) ;
void	saveas			OF ( (void)				) ;

void	resolbak		OF ( (void)				) ;

int		quitnext		OF ( (void)				) ;
int		quitedit 		OF ( (void)				) ;
void	quitexit 		OF ( (void)				) ;
int		quitsure		OF ( (void)				) ;

void	showpage		OF ( (void)				) ;
void	showtext		OF ( (char *, int)		) ;
void	showline		OF ( (int, int)			) ;

void	dispstatus		OF ( (void)				) ;
void	disptext		OF ( (int)				) ;
void	dispfunbar		OF ( (void)				) ;
void	dispcol			OF ( (void)				) ;
void	displine		OF ( (void)				) ;
void	dispcrap		OF ( (void)				) ;

void	pagedown		OF ( (void)				) ;
void	pageup  		OF ( (void)				) ;
void	firstpage  		OF ( (void)				) ;
void	lastpage  		OF ( (void)				) ;

void	moveright  		OF ( (void)				) ;
void	moveleft   		OF ( (void)				) ;
void	movedown   		OF ( (void)				) ;
void	moveup    		OF ( (void)				) ;

void	homeline		OF ( (void)				) ;
void	endofline		OF ( (void)				) ;
void	pagetop			OF ( (void)				) ;
void	pagebase		OF ( (void)				) ;

void	rollup  		OF ( (void)				) ;
void	rolldown		OF ( (void)				) ;
void	scrollup  		OF ( (void)				) ;
void	scrolldown		OF ( (void)				) ;

void	nextword		OF ( (void)				) ;
void	prevword		OF ( (void)				) ;
int		copyword		OF ( (void)				) ;

void	setbuffcol		OF ( (void)				) ;
void	setvideocol		OF ( (void)				) ;

void	addtext 		OF ( (int)				) ;
void	backspace		OF ( (void)				) ;
void	crapit			OF ( (void)				) ;

void	openline 		OF ( (int, int)			) ;
void	closeline 		OF ( (int, int)			) ;
void	newline 		OF ( (void)				) ;
void	joinline 		OF ( (void)				) ;
void	gotoline 		OF ( (void)				) ;
void	reachline 		OF ( (int)				) ;

void	proctab 		OF ( (void)				) ;
void	backtab 		OF ( (void)				) ;
void	tabforward		OF ( (void)				) ;

void	blockstart		OF ( (void)				) ;
void	blockend		OF ( (void)				) ;
void	blockhide		OF ( (void)				) ;
void	blockline		OF ( (void)				) ;
void	blockword		OF ( (void)				) ;
void	blockcopy		OF ( (void)				) ;
void	blockmove		OF ( (void)				) ;
void	blockdel		OF ( (void)				) ;
void	blockread		OF ( (void)				) ;
void	blockwrite		OF ( (void)				) ;
void	blocksave		OF ( (void)				) ;
void	blockpaste		OF ( (void)				) ;

void	looktext		OF ( (void)				) ;
void	swapctrl		OF ( (void)				) ;
void	swaptext		OF ( (void)				) ;
int		looknext		OF ( (void)				) ;

void	findstart		OF ( (void)				) ;
void	findend			OF ( (void)				) ;

void	del_char  		OF ( (void)				) ;
void	del_word  		OF ( (void)				) ;
void	del_line  		OF ( (void)				) ;
void	del_right  		OF ( (void)				) ;

void	help			OF ( (void)				) ;
void	info			OF ( (void)				) ;

void	dupline			OF ( (void)				) ;
void	popinsert		OF ( (void)				) ;
void	popexact		OF ( (void)				) ;
void	popcase			OF ( (void)				) ;
void	chgtabsize 		OF ( (void)				) ;
void	chgpagsize 		OF ( (void)				) ;
void	chgpagwid 		OF ( (void)				) ;
void	whichcol		OF ( (void)				) ;

void	syscmd			OF ( (char *)			) ;
void	shell			OF ( (void)				) ;
void	runcmd			OF ( (void)				) ;

void	setiorate		OF ( (ULONG)			) ;
void	resetiorate		OF ( (void)				) ;
void	popoptimio		OF ( (void)				) ;
void	popscroll		OF ( (void)				) ;

void	getmodes			OF ( (void)				) ;
void	setstatus		OF ( (void)				) ;

int		getfilnam		OF ( (char *)			) ;

void	xedlists		OF ( (void)				) ;
void	forecolor		OF ( (void)				) ;
void	backcolor		OF ( (void)				) ;

void	sighand			OF ( (int)				) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

#	define	XEDLOG			"xed.ctl"

#	define	XEDFILES		"files"
#	define	XEDTEXTS		"texts"
#	define	XEDNUMBS		"numbs"
#	define	XEDEXECS		"execs"
#	define	XEDCTRLS		"ctrls"

#	define	MAXLOGFILES		 256 /*  512 */
#	define	MAXLOGTEXTS		 128 /*  512 */
#	define	MAXLOGNUMBS		  64 /*  128 */
#	define	MAXLOGEXECS		 128 /* 1024 */
#	define	MAXLOGCTRLS		 256 /*  512 */

STRLISTCTRL * xedfiles ;
STRLISTCTRL * xedtexts ;
STRLISTCTRL * xednumbs ;
STRLISTCTRL * xedexecs ;
STRLISTCTRL * xedctrls ;

char logpath [128] ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

MAINTYPE main (argc, argv) int argc ; char * * argv ; {

	int j ;

	linesize = LINESIZE ;
	pagesize = XEDPAGESIZE - 2 ;

	signal (SIGTERM, sighand) ;

	banner () ;

	if (--argc) {
		while (*++argv) {
			if (**argv == '-') {
				switch ( * ( (*argv) + 1 ) ) {

					case 'a' : monopaper = TRUE ; break ;

					case 'b' : backitup = FALSE ; break ;

					case 'c' : colorok = TRUE ; break ;

					case 'D' : debugflag = TRUE ; break ;

					case 'l' :
						linbufsiz = atoi (*++argv) ;
						linbufsiz = linbufsiz < DFL_TMPLINBUFSIZ ? DFL_TMPLINBUFSIZ : linbufsiz ;
					break ;

					case 'm' : monochrome = TRUE ; break ;

					case 'p' :
						pageparm = atoi (*++argv) - 2 ;
						pagesize = pageparm < 4 ? XEDPAGESIZE - 2 : pageparm ;
					break ;

					case 't' :
						tabsize = atoi (*++argv) ;
						/*	tabsize = tabsize < 2 ? 2 : tabsize ;	*/
					break ;

					case 'T' : terminal = TRUE ; break ;

					case 'z' : strcpy (prevname, *++argv) ; break ;

					case '?' :
					default :	syntax () ;  return 1 ;
				}
			} else {
				if (totfiles < MAXFILES)
					textfiles[totfiles++] = *argv ;
			}
		}
	}

	prologue () ;

	if (totfiles > 0)
		for ( j = 0 ; j < totfiles ; ++j ) {
			currfile = textfiles[j] ;
			pickstrlist (xedfiles) ;
			feedstrlist (currfile) ;
			xed () ;
		}
	else
		xed () ;

	epilogue () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void noparms () {

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void banner () {

	printf (xedmesg[XM_BANNER],
			 VERNAME, VERSION, VERCODE, VERDATE, OPSYS, VERSIGN) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void syntax () {

	fprintf (stderr, "\n\n") ;
	fprintf (stderr, "use : xed [-abm] [-p #] [-t #] arq ...\n\n") ;
	fprintf (stderr, " -a : monitor monocromatico (video reverso)\n") ;
	fprintf (stderr, " -b : nao faz backup\n") ;
	fprintf (stderr, " -m : monitor monocromatico\n") ;
	fprintf (stderr, " -p <linhas-por-pagina>\n") ;
	fprintf (stderr, " -t <tabsize>\n") ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xed () {

	int res ;

	for ( EVER ) {

		loadfile () ;
		loadctrl () ;
		res = editfile () ;

		if ( res == XC_QUITNEXT )
			return ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void sighand (int signo) {

	if (signo == SIGTERM)
		saveexit () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void washctrl () {

	REG int j ;
	REG STRLISTCTRL * tslcp ;

	char tb [256] ;
	char mb [ 256] ;

	tslcp = currstrlist () ;
/*
 *							|-----------------------------------|
 *							|	1st kill unused ctrls ...		|
 *							|-----------------------------------|
 */
	for ( j = 0 ; ; ++j ) {

		pickstrlist (xedctrls) ;

		if ( peekstrlist ( tb , j ) == NULL )
			break ;

		sscanf ( tb , " %s " , mb ) ;
		pickstrlist (xedfiles) ;

		if ( findstrlist (mb) == -1 ) {
			pickstrlist (xedctrls) ;
			killstrlist (j--) ;
		}
	}
/*
 *							|-----------------------------------|
 *							|	2nd kill files w/o ctrls ...	|
 *							|-----------------------------------|
 */
	for ( j = 0 ; ; ++j ) {

		pickstrlist (xedfiles) ;

		if ( peekstrlist ( tb , j ) == NULL )
			break ;

		sscanf ( tb , " %s " , mb ) ;
		sprintf ( tb , "%s " , mb ) ;
		pickstrlist (xedctrls) ;

		if ( findstrlist (tb) == -1 ) {
			pickstrlist (xedfiles) ;
			killstrlist (j--) ;
		}
	}

	pickstrlist (tslcp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void loadctrl () {

	REG int rd ;
	REG STRLISTCTRL * tslcp ;

	char tb [256] ;
	char mb [ 256] ;

	craped = FALSE ;
	blockfirst = blocklast = blockleft = blockright = -1 ;
	buffline = buffcol = pageline = leftoff = 0 ;
	videoline = 1 ; videocol = 0 ; tabsize = 4 ;
	insert = mexact = showblock = TRUE ;
	blocktype = LINEBLOCK ;

	if (currfile == NULL)
		return ;

	tslcp = currstrlist () ;
	sprintf ( mb , "%s " , currfile ) ;
	pickstrlist (xedctrls) ;

	if ( ( rd = findstrlist (mb) ) != -1 ) {
		peekstrlist (tb, rd) ;
		sscanf ( tb , " %s %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d " ,
			mb , &buffline , &buffcol , &videoline , &videocol , &tabsize ,
			&blockfirst , &blocklast , &blockleft , &blockright , &blocktype ,
			&pageline , &leftoff , &insert , &mexact , &showblock ) ;
	}

	pickstrlist (tslcp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void savectrl () {

	REG int rd ;
	REG STRLISTCTRL * tslcp ;

	char tb [256] ;
	char mb [ 256] ;

	if (currfile == NULL)
		return ;

	sprintf ( mb , "%s " , currfile ) ;

	sprintf ( tb , "%-12s %4d %3d %4d %3d %2d %4d %4d %3d %3d %d %4d %3d %2d %2d %2d " ,
		currfile , buffline , buffcol , videoline , videocol , tabsize ,
		blockfirst , blocklast , blockleft , blockright , blocktype ,
		pageline , leftoff , insert , mexact , showblock ) ;

	tslcp = currstrlist () ;
	pickstrlist (xedctrls) ;

	if ( ( rd = findstrlist (mb) ) != -1 )
		killstrlist (rd) ;

	feedstrlist (tb) ;
	pickstrlist (tslcp) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void mesgerr (msgx, info) int msgx ; char * info ; {

	char tmpbuf [1024] ;
/*	int key ; */

	if (info == NULL)
		info = " " ;

	sprintf (tmpbuf, "%s: %s (%s)", VERNAME, xedmesg[msgx & 0x00ff], info) ;

	if (termisok) {

		wgoto (MESGLINE, 0) ;
		wrev () ;
		wceol () ;
		wputs (tmpbuf) ;

		wgoto (MESGLINE, 72) ;
		wblink () ;
		wputs ("[ESC]") ;
		wgoto (MESGLINE, 78) ;
		wnorm () ;

		while ( ( /* key = */ readkey () ) != ESC )
			honk () ;

		dispfunbar () ;
		setcursor = TRUE ;

	} else {

		fprintf (stderr, "\r\n%s\r\n\r\n", tmpbuf) ;
		fflush (stderr) ;

	}

	if (msgx & XM_FATAL)
		quitexit () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void mesgwait (int msgx) {

	char tmpbuf [100] ;
	int  buflen ;

	sprintf (tmpbuf, " **** AGUARDE : %s ", xedmesg[msgx]) ;

	if (termisok) {

		buflen = strlen (tmpbuf) ;
		wgoto (MESGLINE, linesize - buflen - 1) ;
		wceol () ;
		wblink () ;
		wputb (tmpbuf, buflen) ;
		wnorm () ;

	} else {

		fprintf (stderr, "\n%s\n\n", tmpbuf) ;
		fflush (stderr) ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int getfilnam (buf) char * buf ; {

	int rd ;
	char * tit = xedmesg[XM_FILENAME] ;
	char * tp ;

	pickstrlist (xedfiles) ;

	rd = getbox (tit, 7, 10, buf, FILENAMESIZE, 50) ;

	if (rd == ESC)
		goto rtn ;

	if ( isaregexp (buf) == FALSE )
		goto rtn ;

	tp = dirscan ( NULL , buf ) ;

	if (tp == NULL)
		rd = ESC ;
	else
		strcpy (buf, tp) ;

rtn :

	setcursor = TRUE ;
	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int mesginput (msgx, infobuff) int msgx ; char * infobuff ; {

	int gcol = strlen (xedmesg[msgx]) ;
	int	editsize = linesize - gcol - 1 ;
	int rd ;

	wgoto (MESGLINE, 0) ;
	wceol () ;
	wrev () ;
	wputb ( xedmesg [msgx] , gcol ) ;
	wnorm () ;

	rd = gled (MESGLINE, gcol, infobuff, editsize, editsize) ;

	dispfunbar () ;
	setcursor = TRUE ;

	return rd ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int yesorno (int msgx) {

	int gcol = strlen (xedmesg[msgx]) ;
	int key ;
	int ok = FALSE ;

	wgoto (MESGLINE, 0) ;
	wrev () ;
	wceol () ;
	wputs ( xedmesg [msgx] ) ;
	wgoto (MESGLINE, gcol) ;

	while ( ! ok ) {

		key = readkey () ;

		switch (key) {

			case 'y' :
			case 'Y' :
			case 's' :
			case 'S' :	key = YES ; ok = TRUE ; break ;

			case 'n' :
			case 'N' :	key = NO ; ok = TRUE ; break ;

			case ESC :  ok = TRUE ; break ;

			default  :	honk () ; break ;
		}

	}

	dispfunbar () ;
	setcursor = TRUE ;
	return key ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void loadfile () {

	REG	int			editcnt = 0 ;
	REG	int			newsize ;
	REG	int			linelen ;
	REG	char *		filename = currfile ;
	REG	char *		test ;
	REG	char *		loadptr ;
	REG	char ** 	loadbuff ;
	REG	FILE *		fp ;

	if (currfile == NULL)
		return ;
	else
		if (access (currfile, 0) != 0)
			return ;

	if ((fp = fopen (filename, "rb")) == NULL) {
		mesgerr (XM_CANTOPEN, filename) ;
		return ;
	}

	mesgwait (XM_WAITLOAD) ;

	resetiorate () ;

	while (fgets (tmplinbuf, linbufsiz, fp) != NULL) {
/*
 *		|===========================================|
 *		|	pre-process the line just read ...		|
 *		|===========================================|
 */
		linelen = strlen (tmplinbuf) ;
		totbytes += linelen ;
		test = tmplinbuf + linelen ;

		if (*(test-1) == CTRL_Z) {
			*--test = NUL ;
			if (--linelen < 1)
				continue ;
		}

		if (*(test-1) == NL) {
			*--test = NUL ;
			--linelen ;
		}

		if (*(test-1) == CR) {
			*--test = NUL ;
			--linelen ;
		}
/*
 *		|===========================================|
 *		|	create or expand edit buffer ...		|
 *		|===========================================|
 */
		if (editbuff == NULL) {

			newsize   = (loadlines == -1) ? BUFFGRAIN : loadlines ;
			newsize  *= sizeof (char *) ;
			editbuff  = (char * *) xmalloc (newsize) ;

			if (editbuff == NULL)
				mesgerr (XM_NOMEM | XM_FATAL, "02") ;

			editcnt  = 0 ;
			reqmem  += newsize ;

		} else {

			++editcnt ;

			if ((loadlines == -1) && ((editcnt & GRAINMASK) == 0x00)) {

				newsize = ( ( editcnt >> GRAINBITS ) + 1 ) * BUFFGRAIN ;
				newsize *= sizeof (char *) ;
				loadbuff = (char * *) xmrealloc ((char *) editbuff, newsize) ;

				if (loadbuff == NULL)
					mesgerr (XM_NOMEM | XM_FATAL, "03") ;

				editbuff  = loadbuff ;
				reqmem   += (BUFFGRAIN * sizeof (char *)) ;
			}
		}
/*
 *		|===========================================|
 *		|	create or expand length buffer ...		|
 *		|===========================================|
 */
		if ( lenbuff == NULL ) {

			newsize  = (loadlines == -1) ? BUFFGRAIN : loadlines ;
			newsize *= sizeof (int) ;
			lenbuff  = (int *) xmalloc (newsize) ;

			if (lenbuff == NULL)
				mesgerr (XM_NOMEM | XM_FATAL, "04") ;

			reqmem += newsize ;

		} else {

			if ((loadlines == -1) && ((editcnt & GRAINMASK) == 0x00)) {

				newsize  = ( ( editcnt >> GRAINBITS ) + 1 ) * BUFFGRAIN ;
				newsize *= sizeof (int) ;
				loadptr  = (char *) xmrealloc ( (char *) lenbuff, newsize) ;

				if (loadptr == NULL)
					mesgerr (XM_NOMEM | XM_FATAL, "05") ;

				lenbuff  = (int *) loadptr ;
				reqmem  += (BUFFGRAIN * sizeof (int)) ;
			}
		}
/*
 *		|=======================================|
 *		|	store this line & continue ...		|
 *		|=======================================|
 */
		*(lenbuff+editcnt) = linelen ;

		if (linelen < 0)
			linelen = *(lenbuff+editcnt) = 0 ;

		if (optimio)
			newsize = (((linelen + 1) >> 2) + 1) << 2 ; /* 4-byte pad ? */
		else
			newsize = linelen + 1 ;

		loadptr = (char *) xmalloc (newsize) ;

		if (loadptr == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "06") ;

		if (linelen > 0)
			strcpy (loadptr, tmplinbuf) ;
		else
			*loadptr = NUL ;

		* ( editbuff + editcnt ) = loadptr ;
		reqmem += (newsize) ;
	}
/*
 *	|===================================|
 *	|	clean-ups & close-ups ...		|
 *	|===================================|
 */
	setiorate (totbytes) ;

	fclose (fp) ;
	getmodes () ;
	readlines = totlines = editcnt + 1 ;

	if (loadlines == -1) {

		newsize  = totlines * sizeof (char *) ;
		loadbuff = (char * *) xmrealloc ((char *) editbuff, newsize) ;
		newsize  = totlines * sizeof (int) ;
		loadptr  = (char *)   xmrealloc ((char *) lenbuff,  newsize) ;

		if (loadbuff == NULL || loadptr == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "07") ;

		editbuff = loadbuff ;
		lenbuff  = (int *) loadptr ;

	} else

		loadlines = -1 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef POLYSAVE

int savebuff (filename, int firstline, int lastline, int savetype) char * name ; {

	REG int x ;
	char tmpbuf  [FILENAMESIZE] ;
	char * tp ;
	FILE * fp ;
	int ok_backup ;

	if (savetype == SAVEFILE) {
		if ( ! craped )
			return ;
		firstline = 0 ;
		lastline = totlines ;
	}

	if (filename == NULL) {

		tmpbuf[0] = NUL ;

		if ( getfilnam (tmpbuf) == ESC )
			return ;

		ok_backup = FALSE ;

		if (savetype == SAVEFILE)
			strcpy (currfile = namebuff, tmpbuf) ;

	} else

		if (access (filename, 2) == 0)
			ok_backup = TRUE ;
		else
			ok_backup = FALSE ;

	if (backitup && ok_backup) {

		mesgwait (XM_WAITBACKUP) ;

		resolbak () ;

		if (access (bakname, 0) == 0) {
			if (unlink (bakname) != 0) {
				mesgerr (XM_CANTREMOVE, bakname) ;
				return ;
			}
		}

		if (renfile (filename, bakname) != 0) {
			sprintf (tmpbuf, "%s to %s", filename, bakname) ;
			mesgerr (XM_CANTRENAME, tmpbuf) ;
			return ;
		}
	}

	mesgwait (XM_WAITSAVE) ;

	fp = fopen (filename, "w") ;

	if (fp == NULL) {
		mesgerr (XM_CANTCREATE, filename) ;

		if (backitup && ok_backup)
			if (renfile (bakname, filename) != 0) {
				sprintf (tmpbuf, "%s to %s", bakname, filename) ;
				mesgerr (XM_CANTRENAME, tmpbuf) ;
			}

		return ;
	}

	resetiorate () ;

	for ( x = firstline ; x < lastline ; ++x ) {
		if ( *(lenbuff+x) )
			if ( fputs ( *(editbuff+x) , fp ) == EOF ) {
				mesgerr (XM_CANTWRITE, filename) ;
				break ;
			}
		putc ( NL, fp ) ;
	}

	setiorate (totbytes) ;
	fclose (fp) ;
	setstatus () ;
	dispfunbar () ;

	if (savetype == SAVEFILE) {
		craped = FALSE ;
		crapchanged = TRUE ;
	}

	savectrl () ;
}

# else /* CURRENTSAVE */

void savefile () {

	REG int x ;
	char tmpbuf  [FILENAMESIZE] ;
	/* char * tp ; */
	FILE * fp ;
	int ok_backup ;

	if (craped == FALSE)
		return ;

	if (currfile == NULL) {

		tmpbuf[0] = NUL ;

		if ( getfilnam (tmpbuf) == ESC )
			return ;

		strcpy (namebuff, tmpbuf) ;
		currfile = namebuff ;
		ok_backup = FALSE ;

	} else {

		if (access (currfile, 2) == 0)
			ok_backup = TRUE ;
		else
			ok_backup = FALSE ;
	}

	if (backitup && ok_backup) {

		mesgwait (XM_WAITBACKUP) ;

		resolbak () ;

		if (access (bakname, 0) == 0) {
			if (unlink (bakname) != 0) {
				mesgerr (XM_CANTREMOVE, bakname) ;
				return ;
			}
		}

		if ( renfile ( currfile , bakname ) != 0 ) {
			sprintf (tmpbuf, "\"%s\" para \"%s\"", currfile, bakname) ;
			mesgerr (XM_CANTRENAME, tmpbuf) ;
			return ;
		}
	}

	mesgwait (XM_WAITSAVE) ;

	fp = fopen (currfile, "w") ;

	if (fp == NULL) {
		mesgerr (XM_CANTCREATE, currfile) ;

		if (backitup && ok_backup)
			if (renfile (bakname, currfile) != 0) {
				sprintf (tmpbuf, "%s para %s", bakname, currfile) ;
				mesgerr (XM_CANTRENAME, tmpbuf) ;
			}

		return ;
	}

	resetiorate () ;

	for ( x = 0 ; x < totlines ; ++x ) {
		if ( *(lenbuff+x) )
			if ( fputs ( *(editbuff+x) , fp ) == EOF ) {
				mesgerr (XM_CANTWRITE, currfile) ;
				break ;
			}
		putc ( NL, fp ) ;
	}

	setiorate (totbytes) ;

	fclose (fp) ;
	setstatus () ;
	craped = FALSE ;
	crapchanged = TRUE ;
	dispfunbar () ;
	savectrl () ;
}

# endif /* POLYSAVE */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void resolbak () {

	char * tp ;

	if (currfile == NULL) {
		strcpy (bakname, "n/a") ;
		return ;
	}

	strcpy (bakname, currfile) ;
	tp = /* (char *) */ strrchr (bakname, DOT) ;

	if ( tp == NULL )
		strcat (bakname, baksuffix) ;
	else
		if ( tp == bakname )
			strcat (bakname, baksuffix) ;
		else
			strcpy (tp, baksuffix) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void saveas () {

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void savecont () {

	savefile () ;
	setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int saveedit () {

	savefile () ;

	return quitedit () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void saveexit () {

	savefile () ;
	quitexit () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void quitexit () {

	if ( quitnext () == ESC )
		return ;

	epilogue () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int quitnext () {

	int resp ;

	resp = quitsure () ;

	if (resp == ESC)
		return ESC ;

	if (resp == TRUE)
		savefile () ;
	else
		savectrl () ;

	freebuff () ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int quitedit () {

	char tmpbuf [FILENAMESIZE] ;

	tmpbuf[0] = NUL ;

	if ( getfilnam (tmpbuf) == ESC )
		return ESC ;

	if ( strlen (tmpbuf) == 0 )
		return ESC ;

	if ( quitnext () == ESC )
		return ESC ;

	if ( currfile != NULL )
		strcpy (prevname, currfile) ;
	else
		strcpy (prevname, NONAME) ;

	strcpy (currfile = namebuff, tmpbuf) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int quitswap () {

	char tmpbuf [FILENAMESIZE] ;

	setcursor = TRUE ;

	if ( strcmp (prevname, NONAME) == 0 )
		return ESC ;

	if ( quitnext () == ESC )
		return ESC ;

	strcpy (tmpbuf, prevname) ;
	strcpy (prevname, currfile) ;
	strcpy (currfile = namebuff, tmpbuf) ;

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int quitsure () {

	int resp ;

	if (craped) {
		resp = yesorno (XM_SAVECHANGES) ;

		if (resp == YES)
			return TRUE ;

		if (resp == ESC)
			return ESC ;

		return FALSE ;
	} else
		return FALSE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int reloadit () {

	loadlines = /* 1 + */ ( (readlines > totlines) ? readlines : totlines ) ;

	if ( quitnext () == ESC ) {
		loadlines = -1 ;
		return ESC ;
	}

	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prologue () {

	REG char * tp ;
	REG int rd ;
	char tb [256] ;

	maxmem = xmlimit ( -1L ) ;

# ifdef USE_SHELLVAR

	tp = getenv (SHELLVAR) ;

	if (tp == NULL)

# endif /* USE_SHELLVAR */

		tp = SHELLCMD ;

	strcpy (shellbuff, tp) ;

	rd = terminit () ;

	if (rd) {
		sprintf (tb, "<codigo %d>", rd) ;
		mesgerr (XM_TERMERR, tb) ;
	}

# ifdef ANYX

	fixkeys (KF_FORCE) ;

	stabuf.st_mode = 0600 ; /* ( ~ umask () ) & 0666 */

# endif /* ANYX */

	initcolor ( _BLUE , _LIGHTGRAY , _YELLOW , _BLUE );

	if ( ! pageparm ) {
		getscrsiz ( &pagesize, &linesize ) ;
		pagesize -= 2 ;
	}

# ifdef OLD
	wwinit (pagesize+2, linesize) ;
# else
	winit () ;
# endif

# ifdef ANYX
	freeinfo () ;			/* forget about tinfos ... */
# endif /* ANYX */

	xedlists () ;

	kbdreflect = TRUE ;

	tmplinbuf = xmalloc (linbufsiz) ;

	if (tmplinbuf == NULL)
		mesgerr (XM_NOMEM | XM_FATAL, "27") ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void xedlists () {

	xedfiles = makestrlist (XEDFILES, MAXLOGFILES) ;
	xedtexts = makestrlist (XEDTEXTS, MAXLOGTEXTS) ;
	xednumbs = makestrlist (XEDNUMBS, MAXLOGNUMBS) ;
	xedexecs = makestrlist (XEDEXECS, MAXLOGEXECS) ;
	xedctrls = makestrlist (XEDCTRLS, MAXLOGCTRLS) ;

	sprintf (logpath, "%s%c%s%c%s", getenv ("HOME"), DIRSEP, ".xed", DIRSEP, XEDLOG) ;

	loadstrlist (logpath) ;

	pickstrlist (xedfiles) ;
	modestrlist (LM_ON, LM_STACK) ;

	pickstrlist (xedtexts) ;
	modestrlist (LM_ON, LM_STACK) ;

	pickstrlist (xedexecs) ;
	modestrlist (LM_ON, LM_STACK) ;

	pickstrlist (xednumbs) ;
	modestrlist (LM_ON, LM_STACK) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void epilogue () {

	if (pastename[0] != NUL)
		unlink (pastename) ;

	washctrl () ;

	if ( savestrlist (logpath) )
		mesgerr (XM_LOGERR, "save") ;

	wclear () ;

	wend () ;

	termend () ;

	banner () ;

	exit (0) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void initbuff () {

	REG	char *	tmpline ;

	editbuff = (char * *) xmalloc (sizeof (char *)) ;

	if (editbuff == NULL)
		mesgerr (XM_NOMEM | XM_FATAL, "08") ;

	tmpline = (char *) xmalloc (1) ;

	if (tmpline == NULL)
		mesgerr (XM_NOMEM | XM_FATAL, "09") ;

	*tmpline = NUL ;
	*editbuff = tmpline ;

	lenbuff = (int *) xmalloc (sizeof (int)) ;

	if (lenbuff == NULL)
		mesgerr (XM_NOMEM | XM_FATAL, "10") ;

	*lenbuff  = 0 ;
	totlines  = 1 ;
	totbytes  = 0L ;
	reqmem   += (sizeof (char *) + sizeof (int) + 1) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void freebuff () {

	int x ;

	mesgwait (XM_WAITMEM) ;

	if (editbuff != NULL) {
		for ( x = 0 ; x < totlines ; ++x )
			if ( * ( editbuff + x ) != NULL ) {
				xmfree ( * ( editbuff + x ) ) ;
				reqmem -= * ( lenbuff + x ) ;
			}
		xmfree ( (char *) editbuff ) ;
		editbuff = NULL ;
		reqmem -= totlines * sizeof (char *) ;
	}

	if (lenbuff != NULL) {
		xmfree ( (char *) lenbuff ) ;
		reqmem -= totlines * sizeof (int) ;
		lenbuff  = NULL ;
	}

	totlines = 0 ;
	totbytes = 0L ;

	if ( (long) reqmem < 0L )
		reqmem = 0L ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void resetiorate () {

	ioend   = iotime = 0L ;
	iobytes = iorate = 0L ;
	time ( &iostart ) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void setiorate (count) ULONG count ; {

	time ( &ioend ) ;
	iotime = ioend - iostart ;

	if (iotime == 0)
		iotime = 1 ;

	iorate = count / iotime ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int editfile () {

	int what ;

	if (editbuff == NULL)
		initbuff () ;

	showpage () ;

	for ( EVER ) {

		if (linechanged) {
			displine () ;
			linechanged = FALSE ;
			setcursor   = TRUE ;
		}

		if (colchanged) {
			dispcol () ;
			colchanged = FALSE ;
			setcursor  = TRUE ;
		}

		if (crapchanged) {
			dispcrap () ;
			crapchanged = FALSE ;
			setcursor  = TRUE ;
		}

		if (setcursor) {
			wgoto (videoline, videocol) ;
			setcursor = FALSE ;
		}

		what = readcmd () ;

		switch (what) {

			case XC_QUITNEXT	:	if ( quitnext () != ESC )
										return what ;
			break ;

			case XC_QUITEDIT	:	if ( quitedit () == 0 )
										return 0 ;
			break ;

			case XC_QUITSWAP	:	if ( quitswap () == 0 )
										return 0 ;
			break ;

			case XC_SAVEEDIT	:	if ( saveedit () == 0 )
										return 0 ;
			break ;

			case XC_RELOADIT	:	if ( reloadit () == 0 )
										return 0 ;
			break ;

			case XC_SAVECONT	:	savecont () ;	break ;
			case XC_SAVEEXIT	:	saveexit () ;	break ;
			case XC_SAVEAS		:	saveas () ;		break ;
			case XC_QUITEXIT	:	quitexit () ;	break ;

			case XC_MOVERIGHT	:	moveright () ;	break ;
			case XC_MOVELEFT	:	moveleft () ;	break ;
			case XC_MOVEDOWN	:	movedown () ;	break ;
			case XC_MOVEUP		:	moveup () ;		break ;

			case XC_HOMELINE	:	homeline () ;	break ;
			case XC_ENDOFLINE	:	endofline () ;	break ;
			case XC_PAGETOP		:	pagetop () ;	break ;
			case XC_PAGEBASE	:	pagebase () ;	break ;

			case XC_PAGEDOWN	:	pagedown () ;	break ;
			case XC_PAGEUP		:	pageup () ;		break ;
			case XC_FIRSTPAGE	:	firstpage () ;	break ;
			case XC_LASTPAGE	:	lastpage () ;	break ;

			case XC_NEXTWORD	:	nextword () ;	break ;
			case XC_PREVWORD	:	prevword () ;	break ;

			case XC_ROLLDOWN	:	rolldown () ;	break ;
			case XC_ROLLUP		:	rollup () ;		break ;

			case XC_BLOCKSTART	:	blockstart () ;	break ;
			case XC_BLOCKEND	:	blockend () ;	break ;
			case XC_BLOCKHIDE	:	blockhide () ;	break ;
			case XC_BLOCKLINE	:	blockline () ;	break ;
			case XC_BLOCKWORD	:	blockword () ;	break ;
			case XC_BLOCKCOPY	:	blockcopy () ;	break ;
			case XC_BLOCKMOVE	:	blockmove () ;	break ;
			case XC_BLOCKDEL	:	blockdel () ;	break ;
			case XC_BLOCKREAD	:	blockread () ;	break ;
			case XC_BLOCKWRITE	:	blockwrite () ;	break ;
			case XC_BLOCKSAVE	:	blocksave () ;	break ;
			case XC_BLOCKPASTE	:	blockpaste () ;	break ;

			case XC_FINDTEXT	:	looktext () ;	break ;
			case XC_FINDNEXT	:	looknext () ;	break ;
			case XC_CHANGETEXT	:	swapctrl () ;	break ;

			case XC_FINDSTART	:	findstart () ;	break ;
			case XC_FINDEND		:	findend () ;	break ;

			case XC_HELP		:	help () ;		break ;
			case XC_INFO		:	info () ;		break ;

			case XC_SHELL		:	shell () ;		break ;
			case XC_RUNCMD		:	runcmd () ;		break ;

			case XC_TABSIZE		:	chgtabsize () ;	break ;
			case XC_PAGSIZE		:	chgpagsize () ;	break ;
			case XC_PAGWID		:	chgpagwid () ;	break ;
			case XC_REFRESH		:	showpage () ;	break ;
			case XC_WHICHCOL	:	whichcol () ;	break ;
			case XC_DUPLINE		:	dupline () ;	break ;
			case XC_POPOPTIMIO	:	popoptimio () ;	break ;
			case XC_POPSCROLL	:	popscroll () ;	break ;

			case XC_DELCHAR		:	del_char () ;	break ;
			case XC_DELWORD		:	del_word () ;	break ;
			case XC_DELLINE		:	del_line () ;	break ;
			case XC_DELRIGHT	:	del_right () ;	break ;

			case XC_NEWLINE		:	newline () ;	break ;
			case XC_JOINLINE	:	joinline () ;	break ;
			case XC_GOTOLINE	:	gotoline () ;	break ;

			case XC_TAB			:	proctab () ;	break ;
			case XC_BACKTAB		:	backtab () ;	break ;
			case XC_BACKSPACE	:	backspace () ;	break ;

			case XC_POPINSERT	:	popinsert () ;	break ;
			case XC_POPEXACT	:	popexact () ;	break ;
			case XC_POPCASE		:	popcase () ;	break ;

			case XC_FORECOLOR	:	forecolor () ;	break ;
			case XC_BACKCOLOR	:	backcolor () ;	break ;

			case XC_ESC			:
			case XC_BAD			:	setcursor = TRUE ;
									honk () ;		break ;

			default				:	addtext (what) ; break ;
		}
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void help () {

	viewstrvect (helptext, "Help") ;
	setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void info () {

	char tmpbuf [256] ;
	char ts1 [40] , ts2 [40] ;
	register STRLISTCTRL * slcp , * tslcp ;

	if ( ( slcp = makestrlist ("inf", DFL_MAXSTRLSTSIZ) ) == NULL )
		return ;

	tslcp = currstrlist () ;
	pickstrlist (slcp) ;
	modestrlist ( LM_OFF , LM_SORT | LM_UNIQ ) ;
	modestrlist ( LM_ON  , LM_VONLY ) ;
	feedstrlist (" ") ;

	if ( getcwd (cwdname, 128) == NULL )
		return ;

	sprintf (tmpbuf, "Diretorio atual ...... : \"%s\"", cwdname) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	sprintf (tmpbuf, "Arquivo .............. : \"%s\"",
			 (currfile == NULL ? NONAME : currfile) ) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	sprintf (tmpbuf, "Tamanho .............. : %ld bytes (%ld K) em %d linhas",
			 totbytes, totbytes >> 10, totlines) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	sprintf (tmpbuf, "Estado ............... : %s",
			 (craped ? "MODIFICADO" : "INTACTO") ) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	resolbak () ;
	sprintf (tmpbuf, "Backup ............... : \"%s\"",
			 (backitup ? bakname /*"ATIVADO"*/ : "DESATIVADO") ) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	sprintf (tmpbuf, "Posicao atual ........ : coluna %d , linha %d (%d bytes)",
			 buffcol+1, buffline+1, *(lenbuff+buffline)) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	sprintf (tmpbuf, "Cursor na tela ....... : coluna %d , linha %d",
			 videocol+1, videoline) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	sprintf (tmpbuf, "Tamanho da tela ...... : %d linhas , %d colunas",
			 pagesize+2, linesize) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	if (terminal) {
		sprintf (tmpbuf, "Terminal ............. : %s", termname ()) ;
		feedstrlist (tmpbuf) ;
		feedstrlist (" ") ;
	}

	if (blocktype == LINEBLOCK) {

		if (blocklast > blockfirst) {

			if ( blocklast - blockfirst == 1 )
				sprintf (tmpbuf, "Bloco ................ : linha %d", blockfirst+1) ;
			else
				sprintf (tmpbuf, "Bloco ................ : linhas %d a %d (%d linhas)",
						 blockfirst+1, blocklast, blocklast - blockfirst) ;

			feedstrlist (tmpbuf) ;
			feedstrlist (" ") ;
		}

	} else if (blocktype == WORDBLOCK) {

		if (blockright > blockleft) {

			if ( blockright - blockleft == 1 )
				sprintf (tmpbuf, "Bloco ................ : linha %d, coluna %d",
						 blockfirst+1, blockleft+1) ;
			else
				sprintf (tmpbuf, "Bloco ................ : linha %d, colunas %d a %d (%d bytes)",
						 blockfirst+1, blockleft+1, blockright, blockright - blockleft) ;

			feedstrlist (tmpbuf) ;
			feedstrlist (" ") ;
		}
	}

	if ( colorok /* (monochrome || monopaper) */ ) {
		sprintf (tmpbuf, "Cores do texto ....... : %s sobre %s (%d/%d)",
				_COLORNAME ( forenorm ) , _COLORNAME ( backnorm ) ,
				forenorm & 0x0f, backnorm & 0x0f ) ;
		feedstrlist (tmpbuf) ;
		feedstrlist (" ") ;

		sprintf (tmpbuf, "Cores do bloco ....... : %s sobre %s (%d/%d)",
				_COLORNAME ( forerev ) , _COLORNAME ( backrev ) ,
				forerev & 0x0f, backrev & 0x0f ) ;
		feedstrlist (tmpbuf) ;
		feedstrlist (" ") ;
	}

	sprintf (tmpbuf, "Shell ................ : \"%s\"", shellbuff) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	sprintf (tmpbuf, "Log .................. : \"%s\"", logpath) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	/********************************************************************/

	tmpmem = maxmem ;
	strcpy ( ts1 , xltoa (tmpmem, 15, 0x08) ) ;
	strcpy ( ts2 , xltoa (tmpmem>>10, 11, 0x08) ) ;
	sprintf (tmpbuf, "Memoria total ........ : %15s bytes (%11s K) ", ts1, ts2) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	tmpmem = xmavail () ;
	strcpy ( ts1 , xltoa (tmpmem, 15, 0x08) ) ;
	strcpy ( ts2 , xltoa (tmpmem>>10, 11, 0x08) ) ;
	sprintf (tmpbuf, "Memoria livre ........ : %15s bytes (%11s K) ", ts1, ts2) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	tmpmem = xmused () ;
	strcpy ( ts1 , xltoa (tmpmem, 15, 0x08) ) ;
	strcpy ( ts2 , xltoa (tmpmem>>10, 11, 0x08) ) ;
	sprintf (tmpbuf, "Memoria usada ........ : %15s bytes (%11s K) ", ts1, ts2) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	if ( debugflag ) {
		tmpmem = xmctrl () ;
		strcpy ( ts1 , xltoa (tmpmem, 15, 0x08) ) ;
		strcpy ( ts2 , xltoa (tmpmem>>10, 11, 0x08) ) ;
		sprintf (tmpbuf, "Memoria controle ..... : %15s bytes (%11s K) ", ts1, ts2) ;

		feedstrlist (tmpbuf) ;
		feedstrlist (" ") ;

		tmpmem = xmlimit ( -2L ) ;
		strcpy ( ts1 , xltoa (tmpmem, 15, 0x08) ) ;
		strcpy ( ts2 , xltoa (tmpmem>>10, 11, 0x08) ) ;
		sprintf (tmpbuf, "Memoria sistema ...... : %15s bytes (%11s K) ", ts1, ts2) ;

		feedstrlist (tmpbuf) ;
		feedstrlist (" ") ;

# ifdef MEMLEFTOK
		tmpmem = memleft () ;
		strcpy ( ts1 , xltoa (tmpmem, 15, 0x08) ) ;
		strcpy ( ts2 , xltoa (tmpmem>>10, 11, 0x08) ) ;
		sprintf (tmpbuf, "Memoria testada ...... : %15s bytes (%11s K) ", ts1, ts2) ;

		feedstrlist (tmpbuf) ;
		feedstrlist (" ") ;
# endif /* MEMLEFTOK */

# ifdef MEMDBG
		xmdump ( "xed.f12" ) ;
# endif /* MEMDBG */

		if (iorate > 0L) {
			sprintf (tmpbuf, "Taxa de i/o .......... : %lu bytes (%lu K) por segundo",
					 iorate, iorate >> 10) ;
			feedstrlist (tmpbuf) ;
			feedstrlist (" ") ;
		}
	}

	sprintf (tmpbuf, "\"%s\" versao ......... : %s * %s @ %s / %s",
			 VERNAME, VERSION, VERCODE, VERDATE, OPSYS) ;

	feedstrlist (tmpbuf) ;
	feedstrlist (" ") ;

	viewstrlist ("Status") ;
	freestrlist (slcp) ;
	pickstrlist (tslcp) ;
	setcursor = TRUE ;

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void credits () {
	char	tmpbuf [100] ;

	wclear () ;
	wgoto (0, 0) ;
	wrev () ;
	sprintf (tmpbuf, "\n \"%s\" %s * %s @ %s / %s ",
			 VERNAME, VERSION, VERCODE, VERDATE, OPSYS) ;
	wputs (tmpbuf) ;
	wnorm () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int waitcont () {

	REG	char *	pak = "Pressione qualquer tecla para continuar ... " ;
	REG	int		len = strlen (pak) ;

	wgoto (MESGLINE, 0) ;
	wceol () ;
	wrev () ;
	wputb (pak, len) ;
	wnorm () ;
	wgoto (MESGLINE, len) ;
	return readkey () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void endofline () {

	REG	char *	bp = *(editbuff+buffline) ;

	for ( buffcol = 0 ; *bp++ != NUL ; ++buffcol )
		;

	colchanged = TRUE ;
	setvideocol () ;

	if (videocol >= linesize) {

		if (leftoff > 0)
			videocol += leftoff ;

		leftoff = (videocol / linesize) * linesize ;

		if (videocol == linesize)
			leftoff -= SIDESHIFT ;

		videocol -= leftoff ;
		showpage () ;

	} else {

		if (videocol < 0) {
			homeline () ;
			endofline () ;
		}
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void homeline () {

	buffcol = videocol = 0 ;
	colchanged = TRUE ;

	if (leftoff > 0) {
		leftoff = 0 ;
		showpage () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void pagetop () {

	buffline = pageline ;
	videoline = 1 ;
	linechanged = TRUE ;
	setbuffcol () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void pagebase () {

	if (totlines <= pagesize) {
		buffline  = totlines - 1 ;
		videoline = totlines ;
	} else {
		if ( totlines - pageline < pagesize ) {
			buffline = totlines - 1 ;
			videoline = totlines - pageline ;
		} else {
			buffline += ( pagesize - videoline ) ;
			videoline = pagesize ;
		}
	}

	linechanged = TRUE ;
	setbuffcol () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void rollup () {

	if (totlines - pageline <= pagesize)
	 	return ;

	scrollup () ;
	setcursor = TRUE ;

	if (--videoline <= 0)
		movedown () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void rolldown () {

	if (pageline == 0)
		return ;

	scrolldown () ;
	setcursor = TRUE ;

	++videoline ;

	if (videoline > pagesize)
		moveup () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void scrollup () {

	if (hardscroll) {
		wgoto (MESGLINE, 0) ;
		wceol () ;
		wputs ("\n") ;
		wgoto (MESGLINE - 1, 0) ;
		showline (pageline+pagesize, 0) ;
		dispfunbar () ;
		dispstatus () ;
		++pageline ;
	} else {
		++pageline ;
		setbuffcol () ;
		showpage () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void scrolldown () {

	if (pageline == 0)
		return ;

	--pageline ;
	setbuffcol () ;
	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void setbuffcol () {

	REG char * bp = *(editbuff+buffline) ;
	REG int tsp = tabsize ;
	REG int tvc = 0 ;
	REG int tbc = 0 ;
	REG int sbc = buffcol ;

	for ( ; tvc < videocol + leftoff ; ++bp , ++tbc ) {
		if (*bp == TAB) {
			while (tsp--)
				++tvc ;
			tsp = tabsize ;
		} else {
			++tvc ;
			if (--tsp == 0)
				tsp = tabsize ;
		}
	}

	if (sbc != tbc)
		colchanged = TRUE ;

	buffcol  = tbc ;
	videocol = tvc - leftoff ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void setvideocol () {

	REG char * bp = *(editbuff+buffline) ;
	REG int   tsp = tabsize ;
	REG int   tvc = 0 ;
	REG int   tbc = 0 ;

	for ( ; tbc < buffcol ; ++bp , ++tbc ) {
		if (*bp == TAB) {
			while (tsp--)
				++tvc ;
			tsp = tabsize ;
		} else {
			++tvc ;
			if (--tsp == 0)
				tsp = tabsize ;
		}
	}
	videocol = tvc - leftoff ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void moveright () {

	REG	char *	bp = *(editbuff+buffline) + buffcol ;
	REG	int		linelen = *(lenbuff + buffline) ;

	if ( buffcol == linelen ) {
		homeline () ;
		movedown () ;
		return ;
	}

	if ( *bp == TAB && buffcol < linelen ) {
		REG int ts ; /* inline tabfwd() 4 speed ... */

		for ( ts = videocol % tabsize ; ts++ < tabsize ; ++videocol )
			;
	} else {
		++videocol ;
	}

	if (videocol >= linesize) {
		leftoff  += SIDESHIFT ;
		videocol -= SIDESHIFT ;
		showpage () ;
	}

	++buffcol ;
	colchanged = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void movedown () {

	if (buffline + 1 >= totlines)
	 	return ;

	++buffline ;
	linechanged = TRUE ;

	if (videoline < pagesize)
		++videoline ;
	else
		scrollup () ;

	setbuffcol () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void moveleft () {

	REG char * bp = *(editbuff+buffline) ;

	if (videocol == 0) {

		if (leftoff == 0) {

			if (buffline == 0)
				return ;

			moveup () ;
			endofline () ;

		} else {

			leftoff  -= SIDESHIFT ;
			videocol += SIDESHIFT ;

			if (leftoff < 0) {
				leftoff = videocol = 0 ;
			}

			if ( *(bp + --buffcol) == TAB )
				setvideocol () ;
			else
				--videocol ;

			showpage () ;
		}

	} else if ( *(bp + --buffcol) == TAB )
		setvideocol () ;
	else
		--videocol ;

	colchanged = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void moveup () {

	if (buffline == 0)
		return ;

	--buffline ;
	linechanged = TRUE ;

	if (videoline == 1)
		scrolldown () ;
	else
		--videoline ;

	setbuffcol () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void popcase () {

	if ( copyword () == -1 ) {
		setcursor = TRUE ;
		return ;
	}

	if ( ! isalpha ( (int) wordbuff[0] ) ) {
		setcursor = TRUE ;
		return ;
	}

	if ( isupper ( (int) wordbuff[0] ) )
		strcpy ( swapbuff , strlwr ( wordbuff ) ) ;
	else
		strcpy ( swapbuff , strupr ( wordbuff ) ) ;

	strcpy ( textbuff , wordbuff ) ;
	textsize = swapsize = strlen ( wordbuff ) ;
	buffcol += textsize ;
	setvideocol () ;
	swaptext () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int copyword () {

	REG	int		linelen ;
	REG	char *	linptr ;
	REG	char *	wp = wordbuff ;

	linelen = *(lenbuff + buffline) ;

	if (buffcol >= linelen)
		return -1 ;

	linptr  = *(editbuff + buffline) ;
	linptr += buffcol ;

	if ( *linptr == SPC || *linptr == TAB )
		return -1 ;

	while ( *linptr != SPC && *linptr != TAB && *linptr != NUL )
		*wp++ = *linptr++ ;

	*wp = NUL ;
	return 0 ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void nextword () {

	REG	char *		lp ;
	REG	int			linlen ;

	linlen = * (lenbuff + buffline) ;

	if (buffcol >= linlen) {
		if (buffline + 1 == totlines)
			return ;
		movedown () ;
		homeline () ;
		return ;
	}

	lp  = * (editbuff + buffline) ;
	lp += buffcol ;

	if ( *lp != TAB && *lp != SPC )
		while ( *lp != TAB && *lp != SPC && *lp != NUL ) {
			++lp ;
			moveright () ;
		}

	while ( *lp == TAB || *lp == SPC ) {
		++lp ;
		moveright () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void prevword () {

	REG	char *		lp ;
	REG	int			linlen ;

	linlen = * (lenbuff + buffline) ;

	if (buffcol == 0)
		moveleft () ;
	else if (buffcol > linlen)
		endofline () ;

	lp  = * (editbuff + buffline) ;
	lp += buffcol ;

	if (   buffcol > 0 &&
		   *lp != TAB  && *lp != SPC && 
		 ( *(lp-1) == TAB || *(lp-1) == SPC ) ) {
		--lp ;
		moveleft () ;
	}

	while ( *lp == TAB || *lp == SPC ) {
		if (buffcol == 0)
			break ;

		--lp ;
		moveleft () ;
	}

	while ( *lp != TAB && *lp != SPC ) {
		if (buffcol == 0)
			break ;

		--lp ;

		if ( *lp == TAB || *lp == SPC )
			break ;

		moveleft () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void showpage () {

	dispstatus () ;
	disptext (0) ;
	dispfunbar () ;
	setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void disptext (int vidlin) {

	int k ;

	for ( k = vidlin ; k < pagesize ; ++k ) {

		wgoto (k+1, 0) ;
		showline (pageline + k, 0) ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void showline (int lineno, int bufpos) {

	REG	char *	bufptr = tmplinbuf ;
	REG	char *	linptr ;
	REG	int		tabcnt = tabsize ;
	REG	int		outsize = 0 ;
	REG	int		tmpsiz ;
	REG	int		oktoclear = TRUE ;
	REG	int		dispblock = FALSE ;
	REG	int		s_o_block = -1 ;
	REG	int		e_o_block = -1 ;

	if ( blocktype == LINEBLOCK ) {

		if (	blocklast >= 0			&&
				blockfirst >= 0			&&
				lineno >= blockfirst	&&
				lineno < blocklast		&&
				showblock					) {

			wrev () ;

		} else {

			wnorm () ;
		}

	} else if ( blocktype == WORDBLOCK ) {

		if (	blockright >= 0			&&
				blockleft  >= 0			&&
				blockright >  blockleft	&&
				lineno == blockfirst	&&
				showblock					) {

			dispblock = TRUE ;

		} else {

			dispblock = FALSE ;
		}

		wnorm () ;
	}

	if (lineno >= totlines) {
		wceol () ;
		return ;
	}

	linptr = * (editbuff+lineno) ;

	if (bufpos > 0) {
		linptr += bufpos ;
		tabcnt -= (videocol % tabsize) ;

		if (dispblock)
			if (bufpos >= blockright)
				dispblock = FALSE ;
	}

	for ( tmpsiz = bufpos ; *linptr ; ++linptr , ++tmpsiz ) {

		if (dispblock) {

			if (tmpsiz == blockleft)
				s_o_block = (int) (bufptr - tmplinbuf) ;

			if (tmpsiz == blockright)
				e_o_block = (int) (bufptr - tmplinbuf) ;
		}

		if (*linptr == TAB) {

			while (tabcnt--)
				*bufptr++ = SPC ;

			tabcnt = tabsize ;

		} else {

			if (--tabcnt == 0)
				tabcnt = tabsize ;

			*bufptr++ = *linptr ;
		}
	}

	outsize = (int) (bufptr - tmplinbuf) ;

	if (dispblock) {

		if (s_o_block == -1)
			s_o_block = 0 ;

		if (e_o_block == -1)
			e_o_block = outsize ;

		if (e_o_block < leftoff)
			dispblock = FALSE ;
	}

	if (bufpos == 0) { /* "normal" (full-line) output */

		if (outsize > leftoff) {

			outsize   -= leftoff ;
			s_o_block -= leftoff ;
			e_o_block -= leftoff ;

			if (outsize >= linesize) {
				outsize = linesize ;
				oktoclear = FALSE ;
			}

			if (dispblock)
				if (s_o_block >= linesize)
					dispblock = FALSE ;

			tmplinbuf [ leftoff + outsize ] = NUL ;

			if (dispblock) {
				if (s_o_block > 0)
					wputb ( tmplinbuf+leftoff, s_o_block ) ;
				wrev () ;
				wputb ( tmplinbuf+leftoff+s_o_block, (int) (e_o_block - s_o_block) ) ;
				wnorm () ;
				tmpsiz = outsize - e_o_block ;
				if (tmpsiz > 0)
					wputb ( tmplinbuf+leftoff+e_o_block, tmpsiz ) ;
			} else
				wputb ( tmplinbuf+leftoff, outsize ) ;
		}

	} else { /* "update" (half-line) output */

		tmpsiz = linesize - videocol ;

		if (outsize >= tmpsiz) {
			outsize = tmpsiz ;
			oktoclear = FALSE ;
		}

		if (dispblock)
			if (s_o_block >= tmpsiz)
				dispblock = FALSE ;

		tmplinbuf [ outsize ] = NUL ;

		if (dispblock) {
			if (s_o_block > 0)
				wputb ( tmplinbuf, s_o_block ) ;
			wrev () ;
			wputb ( tmplinbuf+s_o_block, (int) (e_o_block - s_o_block) ) ;
			wnorm () ;
			tmpsiz = outsize - e_o_block ;
			if (tmpsiz > 0)
				wputb ( tmplinbuf+e_o_block, tmpsiz ) ;
		} else
			wputb ( tmplinbuf , outsize ) ;
	}

	if (oktoclear)
		wceol () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void dispstatus () {

	char tmpbuf [1024] ;

	sprintf (tmpbuf, xedmesg [XM_STATUS],
				buffline+1, (realcol ? buffcol+1 : videocol+1+leftoff), tabsize,
				(indent ? "ind" : "   "),
				(insert ? "ins" : "   "),
				(mexact ? "exa" : "ign"),
				(craped ? '*' : SPC),
				(currfile == NULL ? NONAME : lastname (currfile)) ) ;

	if (linesize > 80)
		padstr (tmpbuf, linesize, ' ') ;

	wgoto (0, 0) ;
	wceol () ;
	wrev () ;
	wputs (tmpbuf) ;
	wnorm () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void dispfunbar () {

	char tmpbuf [1024] ;

	strcpy (tmpbuf, xedmesg[XM_PFMENU]) ;
	padstr (tmpbuf, terminal ? linesize /**/ - 1 /**/ : linesize , ' ') ;
	wgoto (MESGLINE, 0) ;
	wceol () ;
	wrev () ;
	wputs (tmpbuf) ;
	wnorm () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void dispcol () {

	char tmpbuf [8] ;

	wgoto (0, 20) ;
	wrev () ;
	sprintf (tmpbuf, "%-3d", (realcol ? buffcol+1 : videocol+1+leftoff)) ;
	wputs (tmpbuf) ;
	wnorm () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void displine () {

	char tmpbuf [8] ;

	wgoto (0, 10) ;
	wrev () ;
	sprintf (tmpbuf, "%-5d", buffline+1) ;
	wputs (tmpbuf) ;
	wnorm () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void dispcrap () {

	wgoto (0, POS_CRAP) ;
	wrev () ;
	wputs ( craped ? "*" : " " ) ;
	wnorm () ;
}

/*
 *		#############################################################
 *		#	page stuff ...											#
 *		#	+ cursor should remain in mid-page if possible ...		#
 *		#############################################################
 */

void pagedown () {

	pageline += pagesize ;

	if (pageline > totlines - 1) {
		pageline -= pagesize ;
		return ;
	}

	buffline = pageline ; buffcol = leftoff = 0 ;
	videoline = 1 ; videocol = 0 ;
	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void pageup () {

	if (pageline == 0)
		return ;

	pageline -= pagesize ;

	if (pageline < 0)
		pageline = 0 ;

	buffline = pageline ; buffcol = leftoff = 0 ;
	videoline = 1 ; videocol = 0 ;
	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void firstpage () {

	if (pageline == 0) {
		pagetop () ;
		homeline () ;
		return ;
	}

	buffline = buffcol = pageline = leftoff = 0 ;
	videoline = 1 ; videocol = 0 ;
	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void lastpage () {

	if (totlines > pagesize) {
		buffline = pageline = totlines - pagesize ;
		videoline = 1 ; videocol = buffcol = leftoff = 0 ;
		showpage () ;
	}

	pagebase () ;
	endofline () ;
}

/*
 *		#############################################################
 *		#	block : mark, hide, copy, move, del, i/o, ...			#
 *		#############################################################
 */

void blockhide () {

	if (blockfirst == -1 || blocklast == -1) {
		setcursor = TRUE ;
		return ;
	}

	if (showblock)
		showblock = FALSE ;
	else
		showblock = TRUE ;

	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockstart () {

	blockfirst = buffline ;
	blockleft  = buffcol ;
	showblock  = TRUE ;

	if (blocklast == -1)

		setcursor = TRUE ;

	else {

		if (blocklast == blockfirst)
			blocktype = WORDBLOCK ;
		else
			blocktype = LINEBLOCK ;

		showpage () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockend () {

	blocklast  = buffline ;
	blockright = buffcol ;
	showblock  = TRUE ;

	if (blockfirst == -1)

		setcursor = TRUE ;

	else {

		if (blocklast == blockfirst)
			blocktype = WORDBLOCK ;
		else
			blocktype = LINEBLOCK ;

		showpage () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockline () {

	blockfirst = buffline ;
	blocklast  = buffline + 1 ;
	blocktype  = LINEBLOCK ;
	showblock  = TRUE ;
	blockleft  = blockright = 0 ;
	showpage () ;
	homeline () ;
	movedown () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockword () {

	REG	int		linelen ;
	REG	char *	linptr ;

	linelen = *(lenbuff + buffline) ;

	if (buffcol >= linelen) {
		setcursor = TRUE ;
		return ;
	}

	linptr  = *(editbuff + buffline) ;
	linptr += buffcol ;

	if ( *linptr == SPC || *linptr == TAB ) {
		setcursor = TRUE ;
		return ;
	}

	blockleft = buffcol ;

	while ( *linptr != SPC && *linptr != TAB && *linptr != NUL ) {
		++linptr ;
		moveright () ;
	}

	blockright = buffcol ;
	blockfirst = blocklast = buffline ;
	blocktype  = WORDBLOCK ;
	showblock  = TRUE ;
	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockcopy () {

	REG	int		blocksize ;
	REG	int		tmp ;
	REG	int		linelen ;
	REG	char *	blklin ;
	REG	char *	tmplin ;
	REG	char *	tmpbuf ;
		char		tempbuff [256] ;

	if (blocktype == LINEBLOCK) {

		if ( blocklast <= blockfirst || showblock == FALSE ) {
			setcursor = TRUE ;
			return ;
		}

		if ( buffline > blockfirst && buffline < blocklast ) {
			setcursor = TRUE ;
			return ;
		}

		blocksize = blocklast - blockfirst ;
		openline (buffline, blocksize) ;

		if (buffline <= blockfirst) {
			blockfirst += blocksize ;
			blocklast  += blocksize ;
		}

		for ( tmp = 0 ; tmp < blocksize ; ++tmp ) {

			linelen = * ( lenbuff + ( blockfirst + tmp ) ) ;

			if (linelen) {

				tmplin  = * ( editbuff + ( buffline   + tmp ) ) ;
				blklin  = * ( editbuff + ( blockfirst + tmp ) ) ;
				tmpbuf = xmrealloc ( tmplin , linelen + 1 ) ;

				if (tmpbuf == NULL)
					mesgerr (XM_NOMEM | XM_FATAL, "11") ;

				reqmem   += linelen ;
				totbytes += linelen ;
				strcpy ( tmpbuf , blklin ) ;
				* ( editbuff + ( buffline + tmp ) ) = tmpbuf ;
				* ( lenbuff  + ( buffline + tmp ) ) = linelen ;
			}
		}

		blockfirst = buffline ;
		blocklast  = buffline + blocksize ;

		homeline () ;
		crapit () ;

	} else if (blocktype == WORDBLOCK) {

		if ( blockright <= blockleft || showblock == FALSE ) {
			setcursor = TRUE ;
			return ;
		}

		if ( buffline == blockfirst && 
			 buffcol > blockleft && buffcol < blockright ) {
			setcursor = TRUE ;
			return ;
		}

		tmplin = * ( editbuff + blockfirst ) ;
		tmplin += blockleft ;
		blocksize = blockright - blockleft ;
		strncpy (tempbuff, tmplin, blocksize) ;

		for ( tmp = 0 ; tmp < blocksize ; ++tmp ) {
			wgoto (videoline, videocol) ;
			addtext (tempbuff[tmp]) ;
		}

		blockfirst = blocklast = buffline ;
		blockright = buffcol ;
		blockleft = buffcol - blocksize ;

	}

	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockmove () {

	REG	int			blocksize ;
	REG	int			tmp ;
	REG	char * *	blkptr ;
	REG	char *		tmplin ;
	REG	int *		lenptr ;
	REG	int			tmplen ;
		char		tempbuff [256] ;

	if (blocktype == LINEBLOCK) {

		if ( blocklast <= blockfirst || showblock == FALSE ) {
			setcursor = TRUE ;
			return ;
		}

		if ( buffline >= blockfirst && buffline <= blocklast ) {
			setcursor = TRUE ;
			return ;
		}

		blocksize = blocklast - blockfirst ;

		if (buffline < blockfirst) {

			while ( blockfirst > buffline ) {

				blkptr = editbuff + blockfirst ;
				lenptr = lenbuff  + blockfirst ;

				for ( tmp = 0 ; tmp < blocksize ; ++tmp ) {

					tmplin      = *(blkptr-1) ;
					*(blkptr-1) = *blkptr ;
					*blkptr     = tmplin ;
					++blkptr ;

					tmplen      = *(lenptr-1) ;
					*(lenptr-1) = *lenptr ;
					*lenptr     = tmplen ;
					++lenptr ;
				}

				--blockfirst ;
				--blocklast ;
			}

		} else /* if (buffline > blocklast) */ {

			while ( blocklast < buffline ) {

				blkptr = editbuff + ( blocklast - 1 ) ;
				lenptr = lenbuff  + ( blocklast - 1 ) ;

				for ( tmp = 0 ; tmp < blocksize ; ++tmp ) {

					tmplin      = *(blkptr+1) ;
					*(blkptr+1) = *blkptr ;
					*blkptr     = tmplin ;
					--blkptr ;

					tmplen      = *(lenptr+1) ;
					*(lenptr+1) = *lenptr ;
					*lenptr     = tmplen ;
					--lenptr ;
				}

				++blockfirst ;
				++blocklast ;
			}

		}

		homeline () ;
		crapit () ;

	} else if (blocktype == WORDBLOCK) {

		if ( blockright <= blockleft || showblock == FALSE ) {
			setcursor = TRUE ;
			return ;
		}

		if ( buffline == blockfirst && 
			 buffcol > blockleft && buffcol < blockright ) {
			setcursor = TRUE ;
			return ;
		}

		blocksize = blockright - blockleft ;
		tmplin = * ( editbuff + blockfirst ) ;
		tmplin += blockleft ;
		strncpy (tempbuff, tmplin, blocksize) ;

		for ( tmp = 0 ; tmp < blocksize ; ++tmp ) {
			wgoto (videoline, videocol) ;
			addtext (tempbuff[tmp]) ;
		}

		tmplin = * ( editbuff + blockfirst ) ;
		tmplin += blockleft ;
		strcpy ( tmplin , tmplin + blocksize ) ;
		* ( lenbuff + blockfirst ) -= blocksize ;

		if ( buffline == blockfirst && buffcol > blockright ) {
			buffcol -= blocksize ;
			setvideocol () ;
		}

		blockright = buffcol ;
		blockleft = blockright - blocksize ;
		blockfirst = blocklast = buffline ;

	}

	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockdel () {

	REG	int		blocksize ;

	if (blocktype == LINEBLOCK) {

		if ( blocklast <= blockfirst || showblock == FALSE ) {
			setcursor = TRUE ;
			return ;
		}

		blocksize = blocklast - blockfirst ;
		closeline (blockfirst, blocksize) ;
		blocklast = blockfirst ;
		crapit () ;
		reachline (blockfirst) ;

	} else if (blocktype == WORDBLOCK) {

		if ( blockright <= blockleft || showblock == FALSE ) {
			setcursor = TRUE ;
			return ;
		}

		if ( buffline == blockfirst && 
			 buffcol > blockleft && buffcol < blockright ) {
			setcursor = TRUE ;
			return ;
		}

		blocksize = blockright - blockleft ;

		findstart () ;
		wgoto (videoline, videocol) ;

		while (blocksize--) {
			del_char () ;
			wgoto (videoline, videocol) ;
		}
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockwrite () {

	REG	int		tmp ;
	REG	int		blocksize ;
	REG	ULONG	outbytes = 0L ;
				FILE *	fp ;

	if ( blocklast <= blockfirst || showblock == FALSE ) {
		setcursor = TRUE ;
		return ;
	}

	if ( getfilnam (blockname) == ESC )
		return ;

	if (access (blockname, 0) == 0) {

		tmp = yesorno (XM_OVERWRITE) ;

		if ( tmp == ESC || tmp == NO )
			return ;
	}

	if ( ( fp = fopen (blockname, "w") ) == NULL ) {
		mesgerr (XM_CANTCREATE, blockname) ;
		return ;
	}

	mesgwait (XM_WAITSAVE) ;
	blocksize = blocklast - blockfirst ;

	resetiorate () ;

	for ( tmp = 0 ; tmp < blocksize ; ++tmp ) {
		if ( *(lenbuff + (blockfirst + tmp)) )
			if ( fputs ( *(editbuff + (blockfirst + tmp)) , fp ) == EOF ) {
				mesgerr (XM_CANTWRITE, blockname) ;
				break ;
			}
		putc ( NL, fp ) ;
		outbytes += ( *(lenbuff + (blockfirst + tmp)) ) ;
	}

	setiorate (outbytes) ;
	fclose (fp) ;
	dispfunbar () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blocksave () {

	REG	int		tmp ;
	REG	int		blocksize ;
		FILE *	fp ;
		int		fd = 0 ;

	if ( blocklast <= blockfirst || showblock == FALSE ) {
		setcursor = TRUE ;
		return ;
	}

# ifdef ORIG
	if (pastename[0] == NUL)
		strcpy (pastename, tmpnam (NULL)) ;

	if ( ( fp = fopen (pastename, "w") ) == NULL ) {
		mesgerr (XM_CANTCREATE, pastename) ;
		return ;
	}
# else
	if (pastename[0] == NUL)
		fd = mkstemp (mkstemplate) ;

	if ( ( fp = fdopen ( fd , "w" ) ) == NULL ) {
		mesgerr (XM_CANTCREATE, mkstemplate) ;
		return ;
	}
	strcpy (pastename, mkstemplate) ;
# endif

	blocksize = blocklast - blockfirst ;

	for ( tmp = 0 ; tmp < blocksize ; ++tmp ) {
		fputs ( *(editbuff + (blockfirst + tmp)) , fp ) ;
		putc ( NL, fp ) ;
	}

	fclose (fp) ;
	setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockread () {

	REG	int		blocksize = 0 ;
	REG	int		linelen ;
	REG	char *	test ;
	REG	ULONG	readbytes = 0L ;
				FILE *	fp ;

	if ( getfilnam (blockname) == ESC )
		return ;

	if ( ( fp = fopen (blockname, "r") ) == NULL ) {
		mesgerr (XM_CANTOPEN, blockname) ;
		return ;
	}

	mesgwait (XM_WAITLOAD) ;

	resetiorate () ;

	while (fgets (tmplinbuf, linbufsiz, fp) != NULL) {

		linelen = strlen (tmplinbuf) ;
		readbytes += linelen ;
		test = tmplinbuf + linelen ;

		if (*(test-1) == CTRL_Z) {
			*--test = NUL ;
			if (--linelen < 1)
				continue ;
		}

		if (*(test-1) == NL) {
			*--test = NUL ;
			--linelen ;
		}

		if (*(test-1) == CR) {
			*--test = NUL ;
			--linelen ;
		}

		openline (buffline+blocksize, 1) ;

		if (linelen < 0)
			linelen = 0 ;

		reqmem -= *(lenbuff+(buffline+blocksize)) ;
		*(lenbuff+(buffline+blocksize)) = linelen ;
		xmfree ( *(editbuff+(buffline+blocksize)) ) ;
		test = (char *) xmalloc (linelen + 1) ;

		if (test == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "13") ;

		if (linelen > 0)
			strcpy (test, tmplinbuf) ;
		else
			*test = NUL ;

		*(editbuff+(buffline+blocksize)) = test ;
		reqmem += (linelen + 1) ;
		++blocksize ;
	}

	setiorate (readbytes) ;

	fclose (fp) ;
	blockfirst = buffline ;
	blocklast  = buffline + blocksize ;
	totbytes  += readbytes ;
	showblock  = TRUE ;
	crapit () ;
	showpage () ;
	homeline () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void blockpaste () {

	REG	int		blocksize = 0 ;
	REG	int		linelen ;
	REG	char *	test ;
	REG	ULONG	readbytes = 0L ;
				FILE *	fp ;

	if (pastename[0] == NUL) {
		setcursor = TRUE ;
		return ;
	}

	if ( ( fp = fopen (pastename, "r") ) == NULL ) {
		mesgerr (XM_CANTOPEN, pastename) ;
		return ;
	}

	while (fgets (tmplinbuf, linbufsiz, fp) != NULL) {

		linelen = strlen (tmplinbuf) ;
		readbytes += linelen ;
		test = tmplinbuf + linelen ;

		if (*(test-1) == CTRL_Z) {
			*--test = NUL ;
			if (--linelen < 1)
				continue ;
		}

		if (*(test-1) == NL) {
			*--test = NUL ;
			--linelen ;
		}

		if (*(test-1) == CR) {
			*--test = NUL ;
			--linelen ;
		}

		openline (buffline+blocksize, 1) ;

		if (linelen < 0)
			linelen = 0 ;

		reqmem -= *(lenbuff+(buffline+blocksize)) ;
		*(lenbuff+(buffline+blocksize)) = linelen ;
		xmfree ( *(editbuff+(buffline+blocksize)) ) ;
		test = (char *) xmalloc (linelen + 1) ;

		if (test == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "15") ;

		if (linelen > 0)
			strcpy (test, tmplinbuf) ;
		else
			*test = NUL ;

		*(editbuff+(buffline+blocksize)) = test ;
		reqmem += (linelen + 1) ;
		++blocksize ;
	}

	fclose (fp) ;
	totbytes  += readbytes ;
	crapit () ;
	showpage () ;
	homeline () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void dupline () {

	blockline () ;
	blockcopy () ;
	blockhide () ;
}

/*
 *		#############################################################
 *		#	findtext, findnext, replace, ...						#
 *		#############################################################
 */

void looktext () {

	pickstrlist (xedtexts) ;

	if ( mesginput (XM_LOOKFOR, textbuff) == ESC )
		return ;

	textsize = strlen (textbuff) ;

	if (textsize <= 0)
		return ;

	looknext () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void swapctrl () {

	int		resp ;

	pickstrlist (xedtexts) ;

	if ( mesginput (XM_REPLACE, textbuff) == ESC )
		return ;

	textsize = strlen (textbuff) ;

	if (textsize <= 0)
		return ;

	if ( mesginput (XM_BY, swapbuff) == ESC )
		return ;

	swapsize = strlen (swapbuff) ;

	if (swapsize <= 0)
		swapsize = 0 ;

	while ( looknext () ) {

		resp = yesorno (XM_CHANGEIT) ;

		if (resp == ESC)
			return ;

		if (resp == NO)
			continue ;

		swaptext () ;

	} /* end of text search ... */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void swaptext () {

	REG	int		linelen = 0 ;
	REG	int		diffsize ;
	REG	int		j ;
	REG	char *	oldp = NULL ;
	REG	char *	newp ;
	REG	char *	tmpbuf = NULL ;

/*
 *		|=======================================|
 *		|	expand or contract the line ...		|
 *		|=======================================|
 */
		diffsize = swapsize - textsize ;

		if (diffsize != 0) {

			linelen = *(lenbuff + buffline) + diffsize ;
			tmpbuf  = xmalloc (linelen + 1) ;

			if (tmpbuf == NULL)
				mesgerr (XM_NOMEM | XM_FATAL, "16") ;
		}
/*
 *		|=======================================|
 *		|	copy 1st half ...					|
 *		|=======================================|
 */
		if (diffsize != 0) {

			oldp = *(editbuff + buffline) ;
			newp = tmpbuf ;

			for ( j = 0 ; j < (buffcol - textsize) ; ++j )
				*newp++ = *oldp++ ;
		}
/*
 *		|=======================================|
 *		|	copy new text ...					|
 *		|=======================================|
 */
		if (diffsize == 0)
			newp = ( *(editbuff + buffline) ) + (buffcol - textsize) ;

		for ( j = 0 ; j < swapsize ; ++j )
			*newp++ = swapbuff[j] ;
/*
 *		|=======================================|
 *		|	copy 2nd half ...					|
 *		|=======================================|
 */
		if (diffsize != 0) {

			for ( oldp += textsize ; *oldp ; ++oldp )
				*newp++ = *oldp ;

			*newp = NUL ;
		}
/*
 *		|=======================================|
 *		|	commit the substitution ...			|
 *		|=======================================|
 */
		buffcol -= textsize ;
		setvideocol () ;

		if (diffsize != 0) {
			xmfree ( *(editbuff + buffline) ) ;
			*(editbuff + buffline) = tmpbuf ;
			*(lenbuff  + buffline) = linelen ;
			reqmem   += diffsize ;
			totbytes += diffsize ;
		/*	if (swapsize == 0)	*/
				wgoto (videoline, videocol) ;
			showtext (swapbuff, swapsize) ;
			showline (buffline, buffcol) ;
		} else {
			wgoto (videoline, videocol) ;
			showtext (swapbuff, swapsize) ;
		}

		crapit () ;

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

int looknext () {

	REG	int		tmplin = buffline ;
	REG	char *	lp ;
	REG	char *	txtptr ;
	REG	char *	linptr ;
	REG	int		linelen , result ;

	linelen = * ( lenbuff  + tmplin ) ;
	linptr  = * ( editbuff + tmplin ) ;

	if (buffcol < linelen)

		lp = linptr + buffcol ;

	else {

		if (++tmplin >= totlines) {
			mesgerr (XM_NOTEXT, textbuff) ;
			return FALSE ;
		}

		lp = linptr = * ( editbuff + tmplin ) ;
	}

	mesgwait (XM_WAITSEARCH) ;

	for ( EVER ) {

		txtptr = NULL ;

		for ( ; *lp ; ++lp ) {

			if (mexact)
				result = memcmp ( lp, textbuff, textsize ) ;
			else
				result = memicmp ( lp, textbuff, textsize ) ;

			if (result == 0) {
				txtptr = lp ;
				break ;
			}
		}

		if ( txtptr != NULL ) {
			buffline  = tmplin ;
			pageline  = ( tmplin   / pagesize ) * pagesize ;
			videoline = ( buffline % pagesize ) + 1 ;
			buffcol = (int) ( txtptr - linptr ) /* + textsize */ ;

			if (buffcol <= leftoff)
				leftoff = 0 ;

			setvideocol () ;

			if (videocol >= linesize) {

				if (leftoff > 0)
					videocol += leftoff ;

				leftoff = (videocol / linesize) * linesize ;

				if (videocol == linesize)
					leftoff -= SIDESHIFT ;

				videocol -= leftoff ;
			}

			showpage () ;
			wgoto (videoline, videocol) ;
			showtext ( txtptr /* textbuff */ , textsize ) ;
			return TRUE ;
		}

		if (++tmplin >= totlines) {
			mesgerr (XM_NOTEXT, textbuff) ;
			return FALSE ;
		}

		lp = linptr = * ( editbuff + tmplin ) ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void showtext (buff, size) char * buff ; int size ; {

	REG	int		j ;

	if (size <= 0)
		return ;

	wrev () ;

	for ( j = 0 ; j < size ; ++j ) {
		wputb (buff+j, 1) ; /* & TAB EXP/N ?!? */
		moveright () ;
		wgoto (videoline, videocol) ;
	}

	wnorm () ;

}

/*
 *		#############################################################
 *		#	delete char, line, word, rest, ...						#
 *		#############################################################
 */

void del_char () {

	REG	char *	moveptr ;
	REG	char *	baseptr ;
	REG	char *	lineptr ;
	REG	int		linelen ;
	REG	int		x ;

	lineptr = * ( editbuff + buffline ) ;
	linelen = * ( lenbuff  + buffline ) ;
	baseptr = lineptr + buffcol ;

	if (buffcol >= linelen) {
		if (buffcol > linelen) {
			moveptr = (char *) xmrealloc ( lineptr , buffcol + 1 ) ;

			if (moveptr == NULL)
				mesgerr (XM_NOMEM | XM_FATAL, "17") ;

			lineptr = *(editbuff+buffline) = moveptr ;

			for ( x = linelen ; x < buffcol ; ++x )
				* ( lineptr + x ) = SPC ;

			* ( lineptr + buffcol  ) = NUL ;
			* ( lenbuff + buffline ) = buffcol ;
		}
		joinline () ;
		return ;
	}

	for ( moveptr = baseptr ; *moveptr ; ++moveptr )
		*moveptr = *(moveptr + 1) ;

	*moveptr = NUL ;

	if ( blocktype == WORDBLOCK && buffline == blockfirst ) {

		if ( buffcol < blockleft )
			--blockleft ;

		if ( buffcol < blockright )
			--blockright ;
	}

	showline ( buffline , buffcol ) ;
	* ( lenbuff  + buffline ) = --linelen ;
	--reqmem ;
	--totbytes ;
	setcursor = TRUE ;
	crapit () ;

# ifdef COMMENT		/********* this realloc miserably craps !?! *****/
	if ( ( moveptr = realloc ( lineptr , linelen ) ) == NULL )
		mesgerr (XM_NOMEM | XM_FATAL, "18") ;
	* ( editbuff + buffline ) = moveptr ;
# endif /* COMMENT */
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void del_word () {

	REG	char *	baseptr ;
	REG	char *	lineptr ;
	REG	int		linelen ;

	linelen = * ( lenbuff + buffline ) ;

	if (buffcol >= linelen) {
		joinline () ;
		return ;
	}

	lineptr = * ( editbuff + buffline ) ;
	baseptr = lineptr + buffcol ;

	if ( *baseptr != SPC && *baseptr != TAB ) {
		while ( *baseptr != SPC && *baseptr != TAB && *baseptr != NUL ) {
			del_char () ;
			wgoto (videoline, videocol) ;
			lineptr = * ( editbuff + buffline ) ;
			baseptr = lineptr + buffcol ;
		}
	}

	while ( *baseptr == SPC || *baseptr == TAB ) {
		del_char () ;
		wgoto (videoline, videocol) ;
		lineptr = * ( editbuff + buffline ) ;
		baseptr = lineptr + buffcol ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void del_line () {

	if (totlines == 1)
		return ;

	closeline (buffline, 1) ;

	if ( buffline < blockfirst )
		--blockfirst ;

	if ( buffline < blocklast )
		--blocklast ;

	disptext (videoline - 1) ;
	crapit () ;

	if (buffline == totlines)
		moveup () ;

	homeline () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void del_right () {

	REG int linelen = * ( lenbuff + buffline ) ;

	if (buffcol >= linelen) {
		joinline () ;
		return ;
	}

	while (buffcol < linelen) {
		wgoto (videoline, videocol) ;
		del_char () ; /* THIS WILL CRAP WHEN JOINLINE GETS DONE !!! */
		linelen = * ( lenbuff + buffline ) ;
	}

	setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void backspace () {

	if (buffline == 0 && buffcol == 0)
		return ;

	moveleft () ;

	if (insert) {
		wgoto (videoline, videocol) ;
		del_char () ;
	}
}

/*
 *		#############################################################
 *		#	newline, openline, closeline, joinline					#
 *		#############################################################
 */

void newline () {

	REG	char *		tmpx ;
	REG	char *		tmplin ;
	REG	int			linelen = *(lenbuff + buffline) ;
	REG	int			tmplen ;

	if (insert) {

		openline (buffline, 1) ;

		if (buffcol > 0) {

			if (buffcol < linelen) {
/*
 *				|~~~~~~~~~~~~~~~~~~~~~~~|
 *				|	process 1st half	|
 *				|_______________________|
 */
				tmplin = * (editbuff + (buffline + 1)) ;
				tmpx = xmrealloc ( *(editbuff+buffline) , buffcol + 1 ) ;

				if (tmpx == NULL)
					mesgerr (XM_NOMEM | XM_FATAL, "19") ;

				memcpy (tmpx, tmplin, buffcol) ;
				*(tmpx+buffcol) = NUL ;
				*(editbuff + buffline) = tmpx ;
				*(lenbuff  + buffline) = buffcol ;

				/*************************
				**	process 2nd half	**
				*************************/

				tmpx = tmplin ;
				tmplin += buffcol ;
				*(lenbuff + (buffline+1)) = strlen (tmplin) ;

				while (*tmpx)
					*tmpx++ = *tmplin++ ;

			} else {

				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~**
				**	just swap line pointers & lengths ...	**
				**__________________________________________*/

				tmpx = *(editbuff + buffline) ;
				*(editbuff + buffline) = *(editbuff + (buffline+1)) ;
				*(editbuff + (buffline+1)) = tmpx ;

				tmplen = *(lenbuff + buffline) ;
				*(lenbuff + buffline) = *(lenbuff + (buffline+1)) ;
				*(lenbuff + (buffline+1)) = tmplen ;
			}

		}

		if ( buffline < blockfirst )
			++blockfirst ;

		if ( buffline < blocklast )
			++blocklast ;

		disptext (videoline - 1) ;
		crapit () ;
	}

	movedown () ;
	homeline () ;
}

/*
 *		|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *		|	insert blank lines before current one ...	|
 *		|												|
 *		|	(1) expand edit buffer						|
 *		|	(2) shift line pointers						|
 *		|_______________________________________________|
 */

void openline (int lineno, int linecount) {

	REG	char *		tmpbuf ;
	REG	int  *		tmplen ;
	REG	char * *	tmpx ;
	REG	int			tmpval ;

	/* ==================== (1) ==================== */

	totlines += linecount ;
	tmpval = totlines * sizeof (char *) ;
	tmpx   = (char * *) xmrealloc ( (char *) editbuff, tmpval) ;

	if (tmpx == NULL)
		mesgerr (XM_NOMEM | XM_FATAL, "20") ;

	editbuff  = tmpx ;
	reqmem   += (linecount * sizeof (char *)) ;

	/* ==================== (2) ==================== */

	tmpx   = editbuff + (totlines - 1) ;
	tmpval = totlines ;

	while ( tmpval >= (lineno + linecount) ) {
		*tmpx = *(tmpx-linecount) ;
		--tmpx ;
		--tmpval ;
	}

	/*************************
	**	expand lenbuff		**
	*************************/

	tmpbuf = (char *) xmrealloc ( (char *) lenbuff, totlines * sizeof (int)) ;

	if (tmpbuf == NULL)
		mesgerr (XM_NOMEM | XM_FATAL, "21") ;

	lenbuff   = (int *) tmpbuf ;
	reqmem   += (linecount * sizeof (int)) ;
	totbytes += (linecount * EOLSIZE) ;

	/*======================**
	**	shift line lengths	**
	**======================*/

	tmplen = lenbuff + (totlines - 1) ;
	tmpval = totlines ;

	while ( tmpval >= (lineno + linecount) ) {
		*tmplen = *(tmplen-linecount) ;
		--tmplen ;
		--tmpval ;
	}

	/*==============================================**
	**	alloc an empty line 4 each line opened ...	**
	**==============================================*/

	for ( tmpval = 0 ; tmpval < linecount ; ++tmpval ) {

		tmpbuf = (char *) xmalloc (1) ;

		if (tmpbuf == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "22") ;

		*tmpbuf = NUL ;
		*(editbuff + (lineno+tmpval)) = tmpbuf ;
		*(lenbuff  + (lineno+tmpval)) = 0 ;
		reqmem += 1 ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void closeline (int lineno, int linecount) {

	REG	char * *	tmpx ;
	REG	int *		tmplen ;
	REG	int			tmpval ;
	REG	int			linelen ;

	for ( tmpval = 0 ; tmpval < linecount ; ++tmpval ) {
		linelen = * ( lenbuff + (lineno + tmpval) ) ;
		xmfree ( * ( editbuff + (lineno + tmpval) ) ) ;
		reqmem   -= ( 1 + linelen + sizeof (char *) + sizeof (int) ) ;
		totbytes -= (linelen + EOLSIZE) ;
	}

	tmpval = lineno ;
    tmpx   = editbuff + lineno ;
	tmplen = lenbuff  + lineno ;

	while ( tmpval < (totlines - linecount) ) {
		*tmplen = *(tmplen + linecount) ;
		*tmpx   = *(tmpx   + linecount) ;
		++tmpx ;
		++tmplen ;
		++tmpval ;
	}

	totlines -= linecount ;
	tmpval = totlines * sizeof (char *) ;
	tmpx   = (char * *) xmrealloc ( (char *) editbuff, tmpval) ;
	tmpval = totlines * sizeof (int) ;
	tmplen = (int *) xmrealloc ( (char *) lenbuff, tmpval ) ;

	if (tmpx == NULL || tmplen == NULL)
		mesgerr (XM_NOMEM | XM_FATAL, "23") ;

	editbuff = tmpx ;
	lenbuff  = tmplen ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void joinline () {

	REG	int			nextlen ;
	REG	char *		tmplin ;
	REG	char *		currline ;
	REG	char *		nextline ;
	REG	int			currlen ;

	if (buffline >= (totlines-2))
		return ;
/*
 *	|---------------------------------------------------|
 *	|	concatenate (append) next line @ current ...	|
 *	|---------------------------------------------------|
 */
	nextlen = *(lenbuff + (buffline+1)) ;

	if (nextlen > 0) {
		currline = *(editbuff +  buffline   ) ;
		nextline = *(editbuff + (buffline+1)) ;
		currlen  = *(lenbuff  +  buffline   ) ;

		tmplin = xmrealloc (currline, currlen + nextlen + 1) ;

		if (tmplin == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "24") ;

		strcat (tmplin, nextline) ;
		*(editbuff + buffline)  = tmplin ;
		*(lenbuff  + buffline) += nextlen ;
	}
/*
 *	|---------------------------------------|
 *	|	delete next line & u/d screen ...	|
 *	|---------------------------------------|
 */
	closeline (buffline+1, 1) ;

	if ( (buffline+1) < blockfirst )
		--blockfirst ;

	if ( (buffline+1) < blocklast )
		--blocklast ;

	crapit () ;
	setcursor = TRUE ;
	disptext (videoline - 1) ;
}

/*
 *		#############################################################
 *		#	tab stuff (forward, backward, size)						#
 *		#############################################################
 */

void proctab () {

	if (insert)
		addtext (TAB) ;
	else {
		tabforward () ;
		setbuffcol () ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void backtab () {

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void chgtabsize () {

	char tmpbuf [256] ;
	int  tmptab ;

	tmpbuf[0] = NUL ;

	pickstrlist (xednumbs) ;

	if ( mesginput (XM_TABSIZE, tmpbuf) == ESC )
		return ;

	tmptab = atoi (tmpbuf) ;

	if (tmptab >= MINTABSIZ && tmptab <= MAXTABSIZ) {
		tabsize = tmptab ;
		homeline () ;
		showpage () ;
	} else
		setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void chgpagsize () {

	char tmpbuf [256] ;
	int  tmppag ;

	tmpbuf[0] = NUL ;

	pickstrlist (xednumbs) ;

	if ( mesginput (XM_PAGSIZE, tmpbuf) == ESC )
		return ;

	tmppag = atoi (tmpbuf) ;

	if (tmppag >= MINPAGSIZ && tmppag <= MAXPAGSIZ) {
		wgrow ( tmppag - (pagesize + 2) , 0 ) ;
		pagesize = tmppag - 2 ;
		showpage () ;
	} else
		setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void chgpagwid () {

	char tmpbuf [256] ;
	int  tmpwid ;

	tmpbuf[0] = NUL ;

	pickstrlist (xednumbs) ;

	if ( mesginput (XM_PAGWID, tmpbuf) == ESC )
		return ;

	tmpwid = atoi (tmpbuf) ;

	if (tmpwid >= MINPAGWID && tmpwid <= MAXPAGWID) {
		linesize = tmpwid ;
		showpage () ;
	} else
		setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void tabforward () {

	REG int ts ;

	for ( ts = videocol % tabsize ; ts++ < tabsize ; ++videocol )
		;
}

/*		 ___________________________________________________________
 *		|															|
 *		|	+ line resize should be done in GRAIN increments, 		|
 *		|	  GRAIN defaults to 16 or 8 and may be parm'ed ...		|
 *		|	  but this requires a physlen[] buff analog to lenbuff	|
 *		|___________________________________________________________|
 */

void addtext (int byte) {

	FIX	char	tmpbyte [ 4] = { NUL, NUL, NUL, NUL } ;
	FIX	char	tmpbuf  [512] ;
	REG	char *	lineptr ;
	REG	char *	tmpline ;

	REG	char *	baseptr ;
	REG	char *	moveptr ;

	REG	int		ts ;
	REG	int		x ;
	REG	int		redisp = FALSE ;
	REG	int		linelen ;
	REG	int		inshift ;

	lineptr = *(editbuff + buffline) ;
	linelen = *(lenbuff  + buffline) ;

	if (buffcol > linelen) {
		tmpline = (char *) xmrealloc ( lineptr , buffcol + 2 ) ;

		if (tmpline == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "25") ;

		lineptr = *(editbuff+buffline) = tmpline ;

		for ( x = linelen ; x < buffcol ; ++x )
			* ( lineptr + x ) = SPC ;

		* ( lineptr + (buffcol+1) ) = NUL ;
		* ( lenbuff +  buffline   ) = linelen = buffcol + 1 ;
		inshift   = FALSE ;
		reqmem   += (buffcol - linelen) ;
		totbytes += (buffcol - linelen) ;
	} else
		if ( insert || (buffcol == linelen) )
			inshift = TRUE ;
		else
			inshift = FALSE ;

	baseptr = lineptr + buffcol ;
	tmpbyte[0] = byte ;

	if (inshift) {
		tmpline = (char *) xmrealloc ( lineptr , linelen + 2 ) ;

		if (tmpline == NULL)
			mesgerr (XM_NOMEM | XM_FATAL, "26") ;

		baseptr = tmpline + buffcol ;
		moveptr = tmpline + (linelen + 1);

		for ( ; moveptr > baseptr ; --moveptr )
			*moveptr = *(moveptr-1) ;

		*baseptr = byte ;
		*(editbuff+buffline) = lineptr = tmpline ;
		*(lenbuff +buffline) += 1 ;
		redisp    = TRUE ;
		reqmem   += 1 ;
		totbytes += 1 ;
	} else {
		if ( *baseptr == TAB )
			if ( byte == TAB )
				redisp = FALSE ;
			else
				redisp = TRUE ;
		else
			if ( byte == TAB )
				redisp = TRUE ;
			else
				redisp = FALSE ;

		*baseptr = byte ;
	}

	if ( blocktype == WORDBLOCK && buffline == blockfirst ) {

		if ( buffcol <= blockleft )
			++blockleft ;

		if ( buffcol <= blockright )
			++blockright ;
	}

	++buffcol ;
	colchanged = TRUE ;

	if ( byte == TAB ) {

		x = 0 ; /* tabforward () ; speedy inline ... */

		for ( ts = videocol % tabsize ; ts++ < tabsize ; ++videocol ) {
			tmpbuf[x++] = SPC ;
		}

		tmpbuf[x] = NUL ;
		wputb (tmpbuf, x) ;
		redisp = TRUE ;

	} else {

		++videocol ;
		wputb (tmpbyte, 1) ;
	}

	if (videocol >= linesize) {
		leftoff  += SIDESHIFT ;
		videocol -= SIDESHIFT ;
		showpage () ;
		wgoto (videoline, videocol) ;
	}

	if (redisp)
		showline ( buffline , buffcol ) ;

	crapit () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void crapit () {

	if (craped == FALSE) {
		craped = TRUE ;
		crapchanged = TRUE ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void popinsert () {

	if (insert)
		insert = FALSE ;
	else
		insert = TRUE ;

	wgoto (0, POS_INS) ;
	wrev () ;
	wputs ( insert ? "ins" : "   " ) ;
	wnorm () ;
	setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void popexact () {

	if (mexact)
		mexact = FALSE ;
	else
		mexact = TRUE ;

	wgoto (0, POS_EXACT) ;
	wrev () ;
	wputs ( mexact ? "exa" : "ign" ) ;
	wnorm () ;
	setcursor = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void popindent () {

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void popoptimio () {

	if (optimio)
		optimio = FALSE ;
	else
		optimio = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void popscroll () {

	if (hardscroll)
		hardscroll = FALSE ;
	else
		hardscroll = TRUE ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void whichcol () {

	if (realcol)
		realcol = FALSE ;
	else
		realcol = TRUE ;

	colchanged = TRUE ;
}

/*
 *		#############################################################
 *		#	gotoline, reachline, findstart, findend, ...			#
 *		#############################################################
 */

void gotoline () {

	char tmpbuf [256] ;
	int  tmplin ;

	tmpbuf[0] = NUL ;

	pickstrlist (xednumbs) ;

	if ( mesginput (XM_LINENUMB, tmpbuf) == ESC )
		return ;

	tmplin = atoi (tmpbuf) - 1 ;

	if (tmplin < 0 || tmplin >= totlines) {
		setcursor = TRUE ;
		return ;
	}

	reachline (tmplin) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void reachline (int linenumb) {

	buffline  = linenumb ;
	pageline  = ( linenumb / pagesize ) * pagesize ;
	videoline = (buffline % pagesize) + 1 ;
	showpage () ;
	homeline () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void findstart () {

	if (blockfirst == -1) {
		setcursor = TRUE ;
		return ;
	}

	reachline (blockfirst) ;

	if ( blocktype == WORDBLOCK ) {
		buffcol = blockleft ;
		setvideocol () ;
		setcursor = TRUE ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void findend () {

	if (blocklast == -1) {
		setcursor = TRUE ;
		return ;
	}

	reachline (blocklast) ;

	if ( blocktype == WORDBLOCK ) {
		buffcol = blockright ;
		setvideocol () ;
		setcursor = TRUE ;
	}
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void syscmd (cmdptr) char * cmdptr ; {

	int rd ;

					credits () ;
					wgoto (2,0) ;
					wputs (cmdptr) ;
					wgoto (4,0) ;
# ifdef ANYX
					origmode () ;
# endif /* ANYX */
					rd = system (cmdptr) ;
					if ( rd < 0 ) {
						fprintf (stderr, "system('%s') = %d\r\n", cmdptr, rd) ;
					}
# ifdef ANYX
					workmode () ;
# endif /* ANYX */
					waitcont () ;
					showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void shell () {

	syscmd (shellbuff) ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void runcmd () {

	char tmpbuf [256] ;

	if (cmdbuff[0])
		strcpy (tmpbuf, cmdbuff) ;
	else
		tmpbuf[0] = NUL ;

	pickstrlist (xedexecs) ;

	if ( mesginput (XM_PROMPT, tmpbuf) == ESC )
		return ;

	if (strlen (tmpbuf) <= 0)
		return ;

	strcpy (cmdbuff, tmpbuf) ;
	syscmd (cmdbuff) ;
}

/*
 *		#############################################################
 *		#	END of XED ( miscellany boundary ) ...					#
 *		#############################################################
 */

void getmodes () {

# ifdef ANYX

	if ( stat ( currfile , &stabuf ) != 0 )
		mesgerr (XM_STATERR, currfile) ;

# endif /* ANYX */

}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void setstatus () {

# ifdef ANYX

	if ( chmod ( currfile , stabuf.st_mode ) != 0 )
		mesgerr (XM_CHMODERR, currfile) ;

	if ( bakname[0] != NUL )
		if ( chmod ( bakname , stabuf.st_mode ) != 0 )
			mesgerr (XM_CHMODERR, bakname) ;

# endif /* ANYX */

}

/*
 *		#############################################################
 *		#	operating system - dependent stuff ...					#
 *		#############################################################
 */

void forecolor () {

	if (monochrome || monopaper)
		return ;

	colorvideo ( ++forenorm, backnorm ) ;
	showpage () ;
}

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

void backcolor () {

	if (monochrome || monopaper)
		return ;

	colorvideo ( forenorm, ++backnorm ) ;
	showpage () ;
}

/*		 _______________________________________________________________
 *		|																|
 *		|	   date		ver bid		history								|
 *		|																|
 *		|	1998.06.23	2.3 328		stdmem								|
 *		|																|
 *		|	97 05 19   1.6  683		stdcolor; block bug fix				|
 *		|	94 03 10   1.2  262		dyn. chg page size					|
 *		|	94 01 18   1.2  219		find-and-replace					|
 *		|	94 01 08   1.1  143		write block							|
 *		|	93 11 16   1.0    0		load, save, page's, move's, ...		|
 *		|																|
 *		|	+ AIX/LNX BUG (BIG LINE = CORE DUMP !!!) ...				|
 *		|																|
 *		|	+ showpage should intercept commands for slow terms !		|
 *		|	+ disp on info() a list of undef'ed caps (or cap : status)	|
 *		|	+ findtext options: u=ign.case, g=fromline0, l=local2block	|
 *		|	+ add "sf" & "sr" (scroll fwd & bwd) to caps list & USE !!!	|
 *		|																|
 *		|==========   do   until   here   and   FREEZE   !!   ==========|
 *		|																|
 *		|	+ proprietary load/save FAST! & (big-)buffered i/o engines	|
 *		|	+ block read: try count lines b4 read (1 openline only)		|
 *		|	+ flexible pf menu (multi-rules, split-rules, "more", ...)	|
 *		|	+ "true" blocks : only after selling a whole lot ...		|
 *		|_______________________________________________________________|
 */

/*
 * vi:nu tabstop=4
 */
