	{ 'D',	&flagbits,		NULL,		PI_SETBIT,		PI_DEBUGBIT		} ,
	{ 'E',	&flagbits,		NULL,		PI_SETBIT,		PI_ENVIRONBIT	} ,
	{ 'L',	&flagbits,		NULL,		PI_SETBIT,		PI_LICENSEBIT	} ,
	{ 'V',	&flagbits,		NULL,		PI_SETBIT,		PI_VERSIONBIT 	} ,
	{ '?',	&flagbits,		NULL,		PI_SETBIT,		PI_SYNTAXBIT 	} ,

	{ NUL,	NULL,			NULL,		0x0000,			0x0000			}
