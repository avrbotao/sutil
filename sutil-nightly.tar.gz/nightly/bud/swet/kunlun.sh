# 1x
date ; ./swet -Z -W -I -N -h -D -A -T -H -L -v -d 32 -t 44 -O d32t44Z
date ; ./swet -Z -W -R 10 -I -N -h -D -A -T -H -L -v -d 32 -t 44 -O d32t44ZR10
# 2x t
date ; ./swet -Z -W -I -N -h -D -A -T -H -L -v -d 32 -t 88 -O d32t88Z
date ; ./swet -Z -W -R 10 -I -N -h -D -A -T -H -L -v -d 32 -t 88 -O d32t88ZR10
# 2x p
date ; ./swet -Z -W -I -N -h -D -A -T -H -L -v -d 64 -t 44 -O d64t44Z
date ; ./swet -Z -W -R 10 -I -N -h -D -A -T -H -L -v -d 64 -t 44 -O d64t44ZR10
# 4x
date ; ./swet -Z -W -I -N -h -D -A -T -H -L -v -d 64 -t 88 -O d64t88Z
date ; ./swet -Z -W -R 10 -I -N -h -D -A -T -H -L -v -d 64 -t 88 -O d64t88ZR10
