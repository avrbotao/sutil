#__________________________________________________________________
#
#       climbtest :   increasing workload dispatcher for swet(1)
#
#       v1.8               2017-07-06            Alexandre Botao
#__________________________________________________________________
#
NAM=climbtest
TST=`date +%Y%m%d%H%M%S`
LOG=${NAM}.${TST}.log
INC=1
EOT=/tmp/.stopclimbing.
msg () {
	T=`date +%Y%m%d%H%M%S`
	echo "${T} | $*"
	echo "${T} | $*" >> $LOG
}
valck () {
	if test -n "$1" && expr "$1" + 0 >/dev/null 2>&1
	then
		return `true`
	else
		msg "BAD value (\"$1\")"
		return `false`
	fi
}
endin () {
	msg "endin"
	exit $1
}
stopck () {
	if test -f ${EOT}
	then
		rm -f ${EOT}
		msg "stopped"
		endin 0
	fi
}
waitem () {
	while pgrep -l swet
	do
		date ; sleep 10
	done
}
msg "begin"
if test $# -eq 0
then
	msg "use : $0 [ [ -i <increment> ] <limit> [...] ]"
	endin 1
fi
if test "$1" = "-i"
then
	shift
	INC=$1
	shift
	valck "${INC}" || endin 1
fi
for i in $*
do
	valck "${i}" || continue
	n=${INC}
	while test $n -le $i
	do
		msg "+> climb $n of $i steps by $INC"
		msg "./swet -Z -I -N -h -W -d $n -O \"d${n}\""
		./swet -Z -I -N -h -W -d $n -O "d${n}"
		# waitem
		msg "./swet -Z -I -N -h -t $n -O \"t${n}\""
		./swet -Z -I -N -h -t $n -O "t${n}"
		((n+=${INC}))
		stopck
	done
done
endin 0
