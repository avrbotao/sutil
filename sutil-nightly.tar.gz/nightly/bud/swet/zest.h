
#ifndef _ZEST_H_

#define _ZEST_H_

char * getdistro () ;
char * getosname () ;
char * getosvers () ;
char * getcpuinf () ;
char * zest () ;

long long getcpufhz () ;

#endif  /* _ZEST_H_ */

