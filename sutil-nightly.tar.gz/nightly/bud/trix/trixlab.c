
# include <stdio.h>
# include <string.h>

# define	C_GSPC		   ' '			/* graphic white space			*/
# define	C_ABOX		   223			/* "above" box (or whole box)	*/

# define	C_G25P		   176			/* ...                          */
# define	C_G50P		   177			/* ...                          */
# define	C_G75P		   178			/* ...                          */
# define	C_G99P		   219			/* ...                          */

# define	C_SHBX		   220			/* ...                          */
# define	C_WHBX		   221			/* ...                          */
# define	C_EHBX		   222			/* ...                          */
# define	C_NHBX		   223			/* ...                          */

# define	DFL_BANLINS	12

# define	REG		register

# define	VZRO(X)		(X)0

int _banlins = DFL_BANLINS ;

char * banopt [ DFL_BANLINS+1 ] = {

"                                               ",	/*  1 */
"                              222 222   222 222",	/*  2 */
"                               555 552 255 555 ",	/*  3 */
"                                777 55255 777  ",	/*  4 */
" 999999999999    99999999s     99999 757 99999 ",	/*  5 */
" 999999999999    9999999999     n9999 7 9999n  ",	/*  6 */
" nnnn9999nnnn    9999 99999       n999 999n    ",	/*  7 */
"     9999        99999999n          99999      ",	/*  8 */
"     9999        9999999s         s9999999s    ",	/*  9 */
"     9999        9999 9999s     s99999n99999s  ",	/* 10 */
"     9999        9999  9999    99999n   n99999 ",	/* 11 */
"                                               ",	/* 12 */

 VZRO (char *)

} ;

char * bantxt [ DFL_BANLINS+1 ] ;

void initban () {
	REG char * tp ;
	REG int tl ;

	for ( tl = 0 ; tl < _banlins ; ++tl ) {
		bantxt[tl] = strdup (banopt[tl]) ;
	}

	for ( tl = 0 ; tl < _banlins ; ++tl ) {
		for ( tp = bantxt[tl] ; *tp ; ++tp ) {
            switch (*tp) {
                case ' ' : *tp = (char) ( C_GSPC & 0x00ff ) ; break ; /* ' ' */
                case '2' : *tp = (char) ( C_G25P & 0x00ff ) ; break ;
                case '5' : *tp = (char) ( C_G50P & 0x00ff ) ; break ;
                case '7' : *tp = (char) ( C_G75P & 0x00ff ) ; break ;
                case '9' : *tp = (char) ( C_G99P & 0x00ff ) ; break ;
                case 's' : *tp = (char) ( C_SHBX & 0x00ff ) ; break ;
                case 'w' : *tp = (char) ( C_WHBX & 0x00ff ) ; break ;
                case 'e' : *tp = (char) ( C_EHBX & 0x00ff ) ; break ;
                case 'n' : *tp = (char) ( C_NHBX & 0x00ff ) ; break ;
				default  : *tp = '?' ; break ; 
            }
		}
	}
}

main () {

	puts ("begin") ;
	puts ("initban") ;
	initban () ;
	puts ("end") ;
}

/*
 * vi:tabstop=4
 */
