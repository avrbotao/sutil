/*                	 _______________________________________________
 *  ______________	|												|
 * /\  ___________\	|	TRIX + file system administration utility	|
 * \ \ \________  /	|_______________________________________________|
 *  \ \ \    / / /	|                                               |
 *   \ \ \  / / /	|	trixmove.c : motion strategy ...			|
 *    \ \ \/ / /	|_______________________________________________|
 *     \ \/ / /		|												|
 *		\  / /		|	TRIX & its logo are registered trademarks	|
 *		 \/_/		|	of Alexandre Victor Rodrigues Botao (1991)	|
 *					|_______________________________________________|
 */

#	include	<stdio.h>
#	include	<string.h>

#	ifdef	DOS

#		include	<conio.h>
#		include <io.h>
#		include	<sys/types.h>
#		include	<sys/stat.h>

#		define	F_OK		0

#	else	/* ANYX	*/

#		include <unistd.h>

#	endif	/* DOS		*/

#	include	"trix.h"
#	include	"trixstd.h"
#	include	"trixaloc.h"
#	include	"trixblue.h"
#	include	"trixkeys.h"
#	include	"trixfunc.h"
#	include	"trixext.h"
#	include	"trixtext.h"
#	include	"trixasci.h"
#	include	"trixcmd.h"
#	include	"trixwig.h"
# include	"trixterm.h"

EXT	int		( * filcmp ) () ;
EXT char *	currwd , * cebuf , * ghelpt , * ghyid , * xwhy ;
EXT	char	origwd [ ] ;

/*
 *	+---------------------------------------------------------------+
 *	|	move, copy, link file destination directory preprocessing	|
 *	|	sets logedest properly 4 further processing if destination	|
 *	|	directory is currently loged (calls isdestin() 4 this ...)	|
 *	+---------------------------------------------------------------+
 */
int trixdest (fp, pdestdir, cmd) FILDAT * fp ; char * pdestdir ; int cmd ; {
	REG int grd ;
		STABLK stabuf ;
	REG char * np ;
	REG char * htopic = NULL ;						/* help topic			*/
		char destmp [100] ;

# ifdef ANYX

    REG char * pp ;

    pp = fp->fd_dir->dd_path ;

    if ( access (pp, W_OK) < 0 ) {
		grd = trixerr (T_ENWDIR, pp, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
	}

# endif /* ANYX */

	switch (cmd) {

		case 'm' :
			sprintf (tmpbuf, T_MOVFIL, fp->fd_path) ;
			htopic = T_HMOVFIL ;
		break ;

		case CTRL_O :
			sprintf (tmpbuf, "%s", T_MOVSEL) ;
			htopic = T_MOVSEL ;
		break ;

		case 'c' :
			sprintf (tmpbuf, T_COPFIL, fp->fd_path) ;
			htopic = T_HCOPFIL ;
		break ;

		case CTRL_C :
			sprintf (tmpbuf, "%s", T_COPSEL) ;
			htopic = T_COPSEL ;
		break ;
	}

	/*  get dest path   */

	ghelpt = htopic ;
	ghyid  = "dir" ;
	grd = asktxt (tmpbuf, T_TODEST, destmp, 65, KEEPMNUS) ;
	ghyid  = NOSTR ;
	ghelpt = NOSTR ;

	if (grd != ENTER)
		return ESC ;

	grd = *destmp ;

	if (grd == '\r' || grd == '\n' || grd == '\0')
		return ESC ;

	/*  validate dest path (exists & writable) ...  */

	if ((np = isdir (destmp, &stabuf)) == NOSTR) {
# ifdef COMMENT
		grd = trixerr (T_EACDIR, destmp, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;	 /* should ask 4 create ! */
		}
# else  /* OK */
		return -1 ;
# endif /* COMMENT */
	}

	strcpy (pdestdir, np) ;

# ifdef COMMENT
	/* dest shouldn't be cwd ... */

	if (strcmp (np, ...fp->fd_dir->fd_path) == 0) {
		grd = trixerr (T_EDESTCUR, np, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;	 /* should ask 4 create ! */
		}
	}
# endif /* COMMENT */

# ifdef ANYX
	if ((grd = access (np, W_OK)) < 0) {
		grd = trixerr (T_ENWDIR, np, errno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;	 /* should ask 4 create ! */
		}
	}
# endif /* ANYX */

	dispat (_msglin+1, strlen (T_TODEST), np, strlen (np), VEHILT) ;
	isdestin (np) ; /* chk if dest is loged ... */
	return 0 ;
}

/*
 *	+---------------------------------------------------------------+
 *	|	move file ...												|
 *	+---------------------------------------------------------------+
 */
EXT int overmove ;

int movfil (fp, pdestdir, flgs) FILDAT * fp ; char * pdestdir ; int flgs ; {

	REG int grd ;
		char * xp ;
	REG char * np = pdestdir ;
		char origup [140] , destup [140] ;
/*
 *	@ build dest (path)name
 */
	strcpy (tmpbuf, np) ;
	xp = tmpbuf + strlen (np) ;
	*xp++ = DIRSEP ; *xp++ = '\0' ;
	strcat (tmpbuf, fp->fd_nam) ;
	strcpy (destup, tmpbuf) ;
	strcpy (origup, fp->fd_path) ;
# ifdef DOS
	strupr (origup) ;
	strupr (destup) ;
# endif /* DOS */
/*
 *	@ tell we're moving ...
 */
	locat (_lcmb1, 0) ; CLRTOEOL ;
	locat (_lcmb2, 0) ; CLRTOEOL ;
	locat (_lfmb1, 0) ; CLRTOEOL ;
	sprintf (tmpbuf, T_MOVFIL, origup) ;
	dispat (_lcmb1, 0, tmpbuf, 80, VEHILT) ;
	sprintf (tmpbuf, "%s\"%s\"", T_TODEST, destup) ;
	dispat (_lcmb2, 0, tmpbuf, 80, VEHILT) ;
/*
 *	@ chk 4 self destructive move ...
 */
	if (strcmp (origup, destup) == 0) {
		grd = vaskyn (T_EMOVSELF, T_VOKFMB) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;	 /* should ask 4 create ! */
		}
	}
/*
 *	||=============================================================||
 *	||	+ confirm & destroy dest (path)name                        ||
 *  ||                                                             ||
 *	||	+ should link dest to $TRIXWASTEBASKET,                    ||
 *	||	  not only to be able to revert things out if the link	   ||
 *	||	  doesn't succeed, but also to honor trix's r.f.           ||
 *	||	+ trix should keep a wastebasket on all mounted			   ||
 *	||	  filesystems (in 'lost+found' style) so we could save &   ||
 *	||	  unerase on every dir ...								   ||
 *	||=============================================================||
 */
	if ((grd = access (destup, F_OK)) == 0) {
		overmove = FALSE ;
		if (flgs & CONFLG) {	/* confirm deletion if dest exists */
cit :		grd = vaskyn (T_RMXFIL, T_VYNFMB) ;
			switch (grd) {
				case ENTER :
				case NOPE  : return -1 ;
				case CTRL_Q :
				case ESC   : return ESC ;
				case YEAH  : overmove = TRUE ; break ;
				case '?'   :
				case KF1   : hyxhelp (T_RMXFIL) ; goto cit ;
			}
		} else {
			overmove = TRUE ;
		}
		if ( unlink ( destup ) < 0 ) {
			overmove = FALSE ;
			grd = trixerr (T_CANTRM, destup, errno, BANAL) ;
			switch (grd) {
				case CTRL_Q :
				case ESC   : return ESC ;
				default    : return -1 ;
			}
		}
		chkover (fp) ;
	} else
		overmove = FALSE ;

	/*
	 *	move it ! ...
	 *
	 *	trixerr must be window-(dialog box)-oriented ...
	 */
	grd = xmovfil ( origup , destup ) ;

	if ( grd != 0 ) {
		overmove = FALSE ;
		grd = trixerr (T_EMOVFIL, origup, xerrno, BANAL) ;
		switch (grd) {
			case CTRL_Q :
			case ESC   : return ESC ;
			default    : return -1 ;
		}
	}
	return 0 ;
}
/*	+---------------------------------------------------------------+
 *	|	physically (& portably) move file ...						|
 *	+---------------------------------------------------------------+
 */
int xmovfil (old, new) char * old, * new ; {

# ifdef DOS

	int dosret ;
	union REGS iregs, oregs ;
	struct SREGS sregs ;

	iregs.h.ah = 0x56 ;

# ifdef TINYTRIX						/* small model ... */

	iregs.x.dx = (unsigned int) old ;
	iregs.x.di = (unsigned int) new ;

	dosret = intdos (&iregs, &oregs) ;

# else  /* LARGTRIX */					/* compact model */

	iregs.x.dx = (unsigned int) (FP_OFF (old)) ;
	iregs.x.di = (unsigned int) (FP_OFF (new)) ;

	segread (&sregs) ;
	sregs.ds = FP_SEG (old) ;
	sregs.es = FP_SEG (new) ;

	dosret = intdosx (&iregs, &oregs, &sregs) ;

# endif /* TINYTRIX */

	if (dosret == 0x12)
		dosret = 0 ;

	xerrno = errno ;
	return (dosret) ;

# else  /* ANYX */

	int grd ;

	if ((grd = link (old, new)) < 0) {
		xerrno = errno ;
		return grd ;
	}

	if ((grd = unlink (old)) < 0) {
		xerrno = errno ;
		unlink (new) ;
		return grd ;
	}

	return 0 ;

# endif /* DOS */

}
/*
 *	+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+
 *	| + checks if destination directory is loged, and reflects		|
 *	|	logedest accordingly ...									|
 *	| + presently, 4 d sak of simplicity & hurry, only d curr 		|
 *	|	TOPDAT is scanned. fut/y, there should be made an all-TOP	|
 *	|	search & built a list-of-dest-dirdats (& the list would 	|
 *	|	then b fully u/d'ed upon processing) ...					|
 *	+_______________________________________________________________+
 */
EXT	DIRDAT * *	wablst ;
EXT DIRDAT *    destdd ;
EXT FILDAT *    destfilv ;
EXT FILDAT *    destmflv ;
EXT int			logedest ;

void isdestin (dirnam) char * dirnam ; {
	REG DIRDAT * *	wabp = wablst ;
	REG DIRDAT * *	wabe = wabp + (int) (TOTDIRS) ;
	REG DIRDAT *	dp ;

	logedest = FALSE ; destdd = VZRO (DIRDAT *) ;

	for ( ; wabp < wabe ; ++wabp ) {
		dp = *wabp ;

		if (strcmp (dp->dd_path, dirnam) == 0) {
			logedest = TRUE ; destdd = dp ;
			xerrno = (int) (wabp - wablst) ;
			return ;
		}
	}
}
/*	+---------------------------------------------------------------+
 *	| + u/d nu parent dirdat due to a move, copy, or link command	|
 *	+---------------------------------------------------------------+
 */
void udirdat (ddp, ffp, ucmd) DIRDAT * ddp ; FILDAT * ffp ; int ucmd ; {
	REG char * xp ;
	REG int namofs ;
	REG FILDAT * * tfpp ;
	REG long tmix ;
	REG long xsiz = ffp->fd_stabuf.STASIZ ;
	char nupn [MAXPNL] ;

	if ( ucmd == CMD_MOVFIL || ucmd == CMD_MOVTAG ) {
/*
 *		|===========================================================|
 *		|	+ save old parent's dirdat								|
 *		|	+ give the file a new parent (backlink) ...				|
 *		|	+ build the file's new pathname ...						|
 *		|===========================================================|
 */
		ffp->fd_dir = ddp ;

		strcpy (nupn, ddp->dd_path) ;
		xp = nupn ; xp += strlen (nupn) ;
		*xp++ = DIRSEP ; namofs = (int) (xp - nupn) ;
		strcpy (xp, ffp->fd_nam) ;
/*
 *		|===========================================================|
 *		|	reset file's pathname & name 2 d nu 1s ...				|
 *		|===========================================================|
 */
		free (ffp->fd_path) ;
		xp = malloc (1 + strlen (nupn)) ;
		if (xp == (char *) 0)
nmm :		trixerr (T_FEWMEM, NOSTR, NOWHY, FATAL) ;
		strcpy (xp, nupn) ;
		ffp->fd_path = xp ; ffp->fd_nam = xp + namofs ;
/*
 *		|-----------------------------------------------------------|
 *		|	+ overmove adjustments ...								|
 *		|-----------------------------------------------------------|
 */
		if (overmove) {
			tfpp = ddp->dd_fil ; tmix = 0L ;

			while ( tmix < ddp->dd_fik ) {
				if ( strcmp ( (*tfpp)->fd_nam, ffp->fd_nam ) == 0 )
					break ;
				++tfpp ; ++tmix ;
			}
			if (tmix >= ddp->dd_fik) {
				trixerr ("* ERRO INTERNO # 6 !", NOSTR, NOWHY, FATAL) ;
			}
			ffp->fd_lix = (*tfpp)->fd_lix ;
			ffp->fd_mix = (*tfpp)->fd_mix ;
			tmix = (*tfpp)->fd_stabuf.STASIZ ;
			ddp->dd_fib -= tmix ; ddp->dd_mfb -= tmix ;
			ddp->dd_fib += xsiz ; ddp->dd_mfb += xsiz ;
			TOTFILS -= 1    ; MATFILS -= 1    ;
			TOTBYTS -= tmix ; MATBYTS -= tmix ;

			if (TAGGED (*tfpp)) {
				ddp->dd_tfb -= tmix ; ddp->dd_tfk -= 1 ;
				SELBYTS -= tmix ; SELFILS -= 1 ;
			}
			destfilv = *tfpp ;
			*tfpp = ffp ;
			tfpp = ddp->dd_mfl ; tmix = 0L ;

			while (tmix < ddp->dd_mfk) {
				if ( strcmp ( (*tfpp)->fd_nam, ffp->fd_nam ) == 0 )
					break ;
				++tfpp ; ++tmix ;
			}
			if (tmix >= ddp->dd_mfk) {
				trixerr ("* ERRO INTERNO # 7 !", NOSTR, NOWHY, FATAL) ;
			}
			destmflv = *tfpp ;
			free ((*tfpp)->fd_path) ; free ((char *) (*tfpp)) ;
			*tfpp = ffp ;
			goto eoud ;
		}
# ifdef COMMENT
/*
 *		@ u/d tagged counts ...
 */
		if (TAGGED (ffp)) {
			ddp->dd_tfk += 1 ; ddp->dd_tfb += xsiz ;
		}
# endif /* COMMENT */
/*
 *		|===========================================================|
 *		|	+ adjust nu parent's maxlen ...							|
 *		|	+ enlarge parent's total file list & add ffp 2 it ...	|
 *		|===========================================================|
 */
		namofs = strlen (ffp->fd_nam) ;

		if (ddp->dd_maxlen < namofs)
			ddp->dd_maxlen = namofs ;

		if ((tfpp = ddp->dd_fil) != VZRO (FILDAT * *)) {
			namofs = ((int)(ddp->dd_fik) + 1) * sizeof (FILDAT *) ;
			tfpp = (FILDAT * *) REALLOC ((char *) tfpp, namofs) ;
			if (tfpp == (FILDAT * *) 0) {
rrm :			trixerr (T_REALOC, NOSTR, NOWHY, FATAL) ;
			}
		} else {
			if (FALLOP (tfpp, FILDAT *))
				goto nmm ;
		}
		ddp->dd_fil = tfpp ;
		tfpp += (int)(ddp->dd_fik) ;
		ffp->fd_lix = ddp->dd_fik ;
		ddp->dd_fik += 1 ;
		ddp->dd_fib += xsiz ;
		*tfpp = ffp ;
/*
 *		|===========================================================|
 *		|	+ enlarge parent's matching file list & add ffp 2 it.	|
 *		|	+ sort parent's mfl ...									|
 *		|===========================================================|
 */
		if ((tfpp = ddp->dd_mfl) != VZRO (FILDAT * *)) {
			namofs = ((int) (ddp->dd_mfk) + 1) * sizeof (FILDAT *) ;
			tfpp = (FILDAT * *) REALLOC ((char *) tfpp, namofs) ;
			if (tfpp == (FILDAT * *) 0) {
				goto rrm ;
			}
		} else {
			if (FALLOP (tfpp, FILDAT *))
				goto nmm ;
		}
		ddp->dd_mfl = tfpp ;
		tfpp += (int)(ddp->dd_mfk) ;
		ffp->fd_mix = ddp->dd_mfk ;
		ddp->dd_mfk += 1 ;
		ddp->dd_mfb += xsiz ;
		*tfpp = ffp ;
eoud :
		qsort ( (char *)(ddp->dd_mfl), (int)(ddp->dd_mfk),
				sizeof (FILDAT *), filcmp) ;
	}
}

/*
 *								|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *								|	over (move, copy) validation	|
 *								|___________________________________|
 */

void chkover (ffp) FILDAT * ffp ; {

	REG DIRDAT *	ddp ;
	REG FILDAT * *	tfpp ;
	REG long		tmix ;

	if (overmove == FALSE)
		return ;

	if (logedest == FALSE) {
nov :	overmove = FALSE ;
		return ;
	}

	ddp = destdd ;

	if (ddp->dd_fik == 0)
		goto nov ;

	tfpp = ddp->dd_fil ; tmix = 0L ;

	while (tmix < ddp->dd_fik) {
		if ( strcmp ( (*tfpp)->fd_nam, ffp->fd_nam ) == 0 )
			break ;
		++tfpp ; ++tmix ;
	}

	if (tmix >= ddp->dd_fik)
		goto nov ;
}

/*====================================================================*/

/*
 * vi:nu ts=4
 */
