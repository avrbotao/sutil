/*
 *	rind -- another shell
 *
 *	peel, coat, crust, bark, husk, hull, shuck,
 *	hoof, scalp, cask, conch, ladle, scurf, scab.
 */

# include "trix_abc.h"
# include "ascii.h"
# include <sys/signal.h>

# define    MAXR                  80
# define    LINLEN               128
# define    MAXLOG               100
# define    LOGEDG                  (MAXLOG-1)

int	pl ;
int	nr ;
int	rb[MAXR] ;
char	pb[20] ;
char *	homedir ;
char *	tp ;
char *	cwd ;
char *	hb[MAXLOG] ;
char *	malloc () ;
char *	getenv () ;
char *	getcwd () ;

main (argc, argv)
char ** argv ;
{
	if (--argc)
		while (*++argv) {
			rind (*argv) ;
		}
	else
		rind ((char *) 0) ;
}

int	rind (name)
char *	name ;
{
	register int i ;
	register int tno ;
	register int cno = 0 ;

	rindinit () ;

	while (TRUE) {
prompt:
		if (lined (pb, pl, hb[cno], 0))
			goto prompt ;

		if (hb[cno][0] == NUL)
			goto prompt ;
parse:
		if (hb[cno][0] == 'r') {

			if (hb[cno][1] == NUL) {

				if (cno == 0) {
					if (hb[LOGEDG][0])
						tno = LOGEDG ;
					else
						goto prompt ;
				} else
					tno = cno - 1 ;

				strcpy (hb[cno], hb[tno]) ;
				nr = 1 ;

			} else if (hb[cno][1] == SP) {

			    nr = setrange (&hb[cno][2], rb, MAXR, 2, 0, 99) ;

				if (nr < 0) {
					nr = 0 ;
					continue ;
				}

				for ( i = 0 , tno = cno ; i < nr ; i++ ) {

					if (rb[i] >= cno) {
						nr = 0 ;
						goto prompt ;
					}

					strcpy (hb[tno], hb[rb[i]]) ;

					if (++tno == MAXLOG)
						tno = 0 ;
				}
			}

		} else if ((hb[cno][0] == 'l') && (hb[cno][1] == NUL)) {

			if (cno == 0) {
				if (hb[LOGEDG][0])
					tno = MAXLOG ;
				else
					goto prompt ;
			} else
				tno = cno ;

			for ( i = 0 ; i < tno ; i++ ) {
				printf ("%2d %s\n", i, hb[i]) ;
			}

			goto prompt ;

		} else if (hb[cno][0] == 'q' && hb[cno][1] == NUL) {
			return ;
		} else if (hb[cno][0] == 'd' && hb[cno][1] == NUL) {
			putline (cwd) ;
			goto prompt ;
		}

		if (nr) {
			nr-- ;

			if (lined (pb, pl, hb[cno], LINLEN))
				goto plus ;
		}

		if (hb[cno][0] == 'c' && hb[cno][1] == 'd') {

			if (hb[cno][2] == NUL)
				tp = homedir ;
			else if (hb[cno][2] == SP)
				tp = &hb[cno][3] ;
			else
				goto process ;

			if (chdir (tp)) {
				write (2, "rind: mad directory\n", 20) ;
			} else if (*tp == SLASH) {
				strcpy (cwd, tp) ;
			} else {
				cwd = getcwd ((char *) 0, 80) ;
			}

			goto plus ;
		}
process:
		system (hb[cno]) ;
plus:
		if (++cno == MAXLOG)
			cno = 0 ;

		if (nr)
			goto parse ;
	}
}

rindinit ()
{
	register int tno ;
	static int twice = 0 ;
	int sigint () ;

	if (twice++)
		return ;

	for ( tno = 0 ; tno < MAXLOG ; tno++ )
		if ((hb[tno] = malloc (LINLEN)) == (char *) 0) {
			write (2, "rind: no memory\n", 15) ;
			exit (2) ;
		}

	strcpy (pb, (tp = getenv ("PS1")) ? tp : "[] ") ;
	pl = strlen (pb) ;
	strcpy ((homedir = malloc (60)), getenv ("HOME")) ;
	cwd = getcwd ((char *) 0, 80) ;
	signal (SIGINT, sigint) ;
}

sigint ()
{
	signal (SIGINT, sigint) ;
}
