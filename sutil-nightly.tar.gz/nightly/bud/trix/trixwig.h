
/************************************************************************
*	window-graphy ...													*
************************************************************************/

# define	DFL_VDOLINS			24
# define	DFL_VDOCOLS			80

# define	DFL_HLBORD			12			/* tree/ctrl wdw horiz. border	*/
# define	DFL_VCBORD			62			/* tree/file wdw vert. border	*/

# define	DFL_MSGLIN			21			/* tree/file wdw horiz. border	*/
# define	DFL_FWLEN	    	14			/* small file wdw useful length	*/

# define	DFL_TWLINS			10			/* tree window height in lines	*/
# define	DFL_TWLINW	(DFL_VCBORD - 4)	/* line width of tree window	*/
# define	DFL_TWCOFS			 2			/* tree window home col offset	*/
# define	DFL_TWLOFS			 2			/* tree window home lin offset	*/

# define	DFL_BWCOFS	DFL_TWCOFS
# define	DFL_BWLOFS	DFL_TWLOFS			/* big window home lin offset	*/
# define	DFL_BWLINS		    10			/* big window height in lines	*/
# define	DFL_BWLINW		    76			/* big window line width		*/

# define	DFL_FWLINS			10			/* small fil wdw height (lins)	*/
# define	DFL_FWLINW		    14			/* small fil wdw lin width		*/
# define	DFL_FWCOFS	(DFL_VCBORD+2)		/* small fil wdw hom col offset	*/
# define	DFL_FWLOFS	DFL_TWLOFS			/* small fil wdw hom lin offset	*/

# define	DFL_LFILNAM			19			/* file name lin (y)			*/
# define	DFL_CFILNAM		     2			/* file name col (x)			*/
# define	DFL_WFILNAM			23			/* file name dispat() pad width	*/
# define	DFL_LFILSIZ			18			/* file size lin (y)			*/
# define	DFL_CFILSIZ		     1			/* file size col (x)			*/

# define	DFL_LCURFIB		DFL_LFILSIZ
# define	DFL_CCURFIB		DFL_CFILSIZ
# define	DFL_LCURFIK		DFL_LFILNAM
# define	DFL_CCURFIK			 1

# define	DFL_LTOTFIL			15
# define	DFL_CTOTFIL		     1
# define	DFL_LTOTBYT			14
# define	DFL_CTOTBYT		     1

# define	DFL_LMATFIL			15
# define	DFL_CMATFIL		    28
# define	DFL_LMATBYT			14
# define	DFL_CMATBYT			28

# define	DFL_LSELFIL			15
# define	DFL_CSELFIL			54
# define	DFL_LSELBYT			14
# define	DFL_CSELBYT			54

# define	DFL_LHTOTBYT		14
# define	DFL_CHTOTBYT        21 /* 17 */
# define	DFL_LHTOTFIL        15
# define	DFL_CHTOTFIL        21 /* 17 */
# define	DFL_LHMATBYT        14
# define	DFL_CHMATBYT        48 /* 44 */
# define	DFL_LHMATFIL        15
# define	DFL_CHMATFIL        44
# define	DFL_LHSELBYT        14
# define	DFL_CHSELBYT        74 /* 70 */
# define	DFL_LHSELFIL        15
# define	DFL_CHSELFIL        70

# define	DFL_LHDIRBYT        18
# define	DFL_CHDIRBYT        21 /* 17 */
# define	DFL_LHDIRFIL        19
# define	DFL_CHDIRFIL        17

# define	DFL_LTOTHDR			13
# define	DFL_CTOTHDR			 2
# define	DFL_LFAMHDR			13
# define	DFL_CFAMHDR			28
# define	DFL_LRGXPAT			13
# define	DFL_CRGXPAT			37
# define	DFL_WRGXPAT			15

# define	DFL_LSELHDR			13
# define	DFL_CSELHDR			55

# define	DFL_LCURHDR			17
# define	DFL_CCURHDR			 2

# define	DFL_LPROHDR			17
# define	DFL_CPROHDR			28
# define	DFL_CPROTXT			38
# define	DFL_WPROTXT			14

# define	DFL_LWRTHDR			18
# define	DFL_CWRTHDR			28
# define	DFL_CWRTIME			38

# define	DFL_LRDTHDR			19
# define	DFL_CRDTHDR			28
# define	DFL_CRDTIME			38

# define	DFL_LOWNHDR			17
# define	DFL_COWNHDR			55
# define	DFL_COWNRID			62
# define	DFL_WOWNRID			16

# define	DFL_LGRPHDR			18
# define	DFL_CGRPHDR			55
# define	DFL_CGRPNAM			62
# define	DFL_WGRPNAM			16

# define	DFL_LLNKHDR			19
# define	DFL_CLNKHDR			55
# define	DFL_CLNKCNT			65
# define	DFL_WLNKCNT			 6

# define	DFL_CTLOFS			17			/* dir / fil lin ofs			*/
# define	DFL_CTCOFS		     2			/* dir / fil col ofs			*/

# define	DFL_LPATH		     0			/* path name lin (y)			*/
# define	DFL_CPATH		    20			/* path name col (x)			*/
# define	DFL_WPATH			60			/* [full] path name pad width	*/

# define	DFL_BANLOFS			 1          /* banner lin					*/
# define	DFL_BANLINS			12

# define	DFL_LCMB1			21			/* command menu bar	(1st line)	*/
# define	DFL_CCMB1			 0
# define	DFL_LCMB2			22			/* command menu bar	(2nd line)	*/
# define	DFL_CCMB2			 0

# define	DFL_LFMB1			23			/* PFKEYS menu bar	(1st half)	*/
# define	DFL_CFMB1			 0
# define	DFL_LFMB2			23			/* PFKEYS menu bar	(2nd half)	*/
# define	DFL_CFMB2			40

# define	DFL_LVRSN			21
# define	DFL_CVRSN			 2
# define	DFL_LSRNO			21

# define	DFL_CRNLOFS			22			/* copyright notice lin			*/
# define	DFL_CRNCOFS			 2			/* copyright notice col			*/
# define	DFL_SNILOFS			23			/* serial # id lin				*/
# define	DFL_SNICOFS			 2			/* serial # id col				*/

# define	DFL_L_HLPBOX	     3
# define	DFL_C_HLPBOX	     5
# define	DFL_HLPWLEN			70
# define	DFL_HLPWHEI			16

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

extern int	fwcofs	;
extern int	vlinwid	;

extern int _vdolins	;
extern int _vdocols	;

extern int _hlbord	;
extern int _vcbord	;

extern int _msglin	;
extern int _fwlen	;

extern int _twlins	;
extern int _twlinw	;
extern int _twcofs	;
extern int _twlofs	;

extern int _bwcofs	;
extern int _bwlofs	;
extern int _bwlins	;
extern int _bwlinw	;

extern int _fwlins	;
extern int _fwlinw	;
extern int _fwcofs	;
extern int _fwlofs	;

extern int _lfilnam	;
extern int _cfilnam	;
extern int _wfilnam	;
extern int _lfilsiz	;
extern int _cfilsiz	;

extern int _lcurfib	;
extern int _ccurfib	;
extern int _lcurfik	;
extern int _ccurfik	;

extern int _ltotfil	;
extern int _ctotfil	;
extern int _ltotbyt	;
extern int _ctotbyt	;

extern int _lmatfil	;
extern int _cmatfil	;
extern int _lmatbyt	;
extern int _cmatbyt	;

extern int _lselfil	;
extern int _cselfil	;
extern int _lselbyt	;
extern int _cselbyt	;

extern int _lhtotbyt	;
extern int _chtotbyt	;
extern int _lhtotfil	;
extern int _chtotfil	;
extern int _lhmatbyt	;
extern int _chmatbyt	;
extern int _lhmatfil	;
extern int _chmatfil	;
extern int _lhselbyt	;
extern int _chselbyt	;
extern int _lhselfil	;
extern int _chselfil	;
extern int _lhdirbyt	;
extern int _chdirbyt	;
extern int _lhdirfil	;
extern int _chdirfil	;

extern int _ltothdr	;
extern int _ctothdr	;

extern int _lfamhdr	;
extern int _cfamhdr	;
extern int _lrgxpat	;
extern int _crgxpat	;
extern int _wrgxpat	;

extern int _lselhdr	;
extern int _cselhdr	;

extern int _lcurhdr	;
extern int _ccurhdr	;

extern int _lprohdr	;
extern int _cprohdr	;
extern int _cprotxt	;
extern int _wprotxt	;

extern int _lwrthdr	;
extern int _cwrthdr	;
extern int _cwrtime	;

extern int _lrdthdr	;
extern int _crdthdr	;
extern int _crdtime	;

extern int _lownhdr	;
extern int _cownhdr	;
extern int _cownrid	;
extern int _wownrid	;

extern int _lgrphdr	;
extern int _cgrphdr	;
extern int _cgrpnam	;
extern int _wgrpnam	;

extern int _llnkhdr	;
extern int _clnkhdr	;
extern int _clnkcnt	;
extern int _wlnkcnt	;

extern int _ctlofs	;
extern int _ctcofs	;

extern int _lpath	;
extern int _cpath	;
extern int _wpath	;

extern int _banlofs	;
extern int _banlins	;

extern int _lcmb1	;
extern int _ccmb1	;
extern int _lcmb2	;
extern int _ccmb2	;

extern int _lfmb1	;
extern int _cfmb1	;
extern int _lfmb2	;
extern int _cfmb2	;

extern int _lvrsn	;
extern int _cvrsn	;
extern int _lsrno	;

extern int _crnlofs	;
extern int _crncofs	;
extern int _snilofs	;
extern int _snicofs	;

extern int _l_hlpbox	;
extern int _c_hlpbox	;
extern int _hlpwlen	;
extern int _hlpwhei	;

# ifdef BIGTRX
extern int _botfilnamlin ;
# endif /* BIGTRX */

void mapwig (void) ;

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/*
 * vi:tabstop=4
 */
