int tputs(const char *str, int affcnt, int (*putc)(int));
