# include <stdio.h>

# ifdef DOS
#	include	<conio.h>
# endif /* DOS */

# include "trix.h"
# include "trixext.h"
# include "trixchrs.h"
# include "trixblue.h"
# include "trixfunc.h"
# include "trixwind.h"

EXT char *      clbuf ;

/*
 *  |---------------------------------------------------------------|
 *  |   draw boxes anywhere (no wwindowws involved) ...             |
 *  |---------------------------------------------------------------|
 */

EXT	BYT xfram [ ] ;

void putbox (l, c, w, h) int l, c, w, h ; {
	REG int i ;
	REG int k ;

# ifdef DOS

# define    gotoxy(x,y)     locat (y-1, x-1)
# define	putch(x)		write (TFD, &x, 1) ;

	++c ; ++l ;
	gotoxy (c, l) ; putch (UPRLEFT) ;
	for ( i = 0 , k = w - 2 ; i < k ; ++i )
		putch (HORZBAR) ;
	putch (UPRIGHT) ;

	for ( i = 1 , k = h - 1 ; i < k ; ++i ) {
		gotoxy (c, l+i) ;  putch (VERTBAR) ;
		gotoxy (c+w-1, l+i) ; putch (VERTBAR) ;
	}

	gotoxy (c, l+h-1) ; putch (LWRLEFT) ;
	for ( i = 0 , k = w - 2 ; i < k ; ++i )
		putch (HORZBAR) ;
	putch (LWRIGHT) ;

# undef gotoxy
# undef putch

# else  /* ANYX */

    BYT xb [512] ;
    EXT BYT xfram [] ;

/* # define BOXTRC */

# ifdef BOXTRC
	fprintf (trcfp, "+putbox(%d,%d,%d,%d)\r\n", l, c, w, h) ;
# endif

    xb[0] = UPRLEFT ;
	for ( i = 0 , k = w - 2 ; i < k ; ++i )
		xb[i+1] = HORZBAR ;
	xb[i+1] = UPRIGHT ; xb[i+2] = '\0' ;
    dispat (l,     c, xb, w, VEAGCS) ;

    xb[0] = LWRLEFT ; xb[i+1] = LWRIGHT ;
    dispat (l+h-1, c, xb, w, VEAGCS) ;

    xb[0] = VERTBAR ; xb[1] = '\0' ;
	for ( i = 1 , k = h - 1 ; i < k ; ++i ) {
        dispat (l+i, c,     xb, 1, VEAGCS) ;
        dispat (l+i, c+w-1, xb, 1, VEAGCS) ;
	}

# endif /* DOS */

}

/*              	                 _______________________________
 *	    	    		            |								|
 *		    						|	flex fram interpreter ...	|
 *	            			        |_______________________________|
 */

# ifdef		ANSI
int stodec ( char * , int * ) ;
# else		/* OLD STYLE */
int stodec ( ) ;
# endif		/* ANSI */

void flexfram (fdb) char * * fdb ; {

	REG char * * fdp = fdb ;
	REG char * xp ;
	REG int rk = 0 ;
	REG int xc = 0 ;

# ifdef ANYX

    REG int x1 = FALSE ;
    REG int fx = 0 ;
	/* REG int gon = FALSE ; */
    char fb [512] ;
	int frameffs = VENORM ;

# endif /* ANYX */

	int xv, tlin = 0, tcol = 0 ;

# ifdef XTRC
	fprintf (trcfp, "flexfram()\r\n") ;
# endif

	while ((xp = *fdp++) != (char *) 0) {

		while (*xp) {

			switch (*xp) {

				case '\'' :

					++xp ;

					switch (*xp) {

						case '*' :
							CLRSCR ; ++xp ;
						break ;

						case '=' :
							rk = stodec (++xp, &xv) ; xp += xv ;
						break ;

						case '-' :
# ifdef ANYX
							x1 = TRUE ;
# endif /* ANYX */
							++xp ;
						break ;

						case 's' :
							++xp ;
							switch (*xp) {
								case '7' : xc = UPRLEFT ; break ;
								case '8' : xc = UPRTEE	; break ;
								case '9' : xc = UPRIGHT	; break ;
								case '4' : xc = LEFTEE	; break ;
								case '+' : xc = PLUSTEE	; break ;
								case '6' : xc = RIGHTEE	; break ;
								case '1' : xc = LWRLEFT	; break ;
								case '2' : xc = LWRTEE	; break ;
								case '3' : xc = LWRIGHT	; break ;
								case '-' : xc = HORZBAR	; break ;
								case '|' : xc = VERTBAR	; break ;
							}

							goto rpt ;

						/* break ; */

						case 'g' : /* agcs on ... */
# ifdef ANYX
                            if (fx > 0) { /* flush flex buf */
                                fb [fx] = '\0' ;
                                dispat (tlin, tcol, fb, fx, frameffs) ;
                                fx = 0 ;
                            }

							frameffs = VEAGCS ;
							++xp ;
# endif /* ANYX */
						break ;

						case 'n' : /* agcs on ... */
# ifdef ANYX
                            if (fx > 0) { /* flush flex buf */
                                fb [fx] = '\0' ;
                                dispat (tlin, tcol, fb, fx, frameffs) ;
                                fx = 0 ;
                            }

							frameffs = VENORM ;
							++xp ;
# endif /* ANYX */
						break ;

						case 'p' :
# ifdef ANYX
                            if (fx > 0) { /* flush flex buf */
                                fb [fx] = '\0' ;
                                dispat (tlin, tcol, fb, fx, frameffs) ;
                                fx = 0 ;
                            }
# endif /* ANYX */
							tlin = stodec (++xp, &xv) ; xp += xv ;
							tcol = stodec (++xp, &xv) ; xp += xv ;
# ifdef ANYX
                            if (x1) {
                                --tlin ; --tcol ;
                            }
# endif /* ANYX */

# ifdef DOS
							gotoxy (tcol, tlin) ;
# endif /* DOS */
						break ;
					}
				break ;

				default :

					if (xc == 0)
						xc = *xp ;

rpt:				do {

# ifdef DOS
						putch (xc) ;
# else  /* ANYX */
                        fb [fx++] = xc ;
# endif /* DOS */
					} while (--rk > 0) ;

					rk = xc = 0 ; ++xp ;

				break ;

			} /* endof switch (*xp) */

		} /* endof while (*xp) */

	} /* endof while (fdp) */

# ifdef ANYX

    if (fx > 0) { /* flush flex buf */
        fb [fx] = '\0' ;
        dispat (tlin, tcol, fb, fx, VENORM) ;
        fx = 0 ;
    }

# endif /* ANYX */

} /* endof flexfram () */

int stodec (tp, vp) char * tp ; int * vp ; {
	REG int xv = 0 , ck = 0 ;

	while (*tp >= '0' && *tp <= '9') {
		xv = (xv * 10) + (*tp - '0') ;
		++tp ; ++ck ;
	}
	*vp = ck ; return xv ;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/*
 * vi:nu tabstop=4
 */
