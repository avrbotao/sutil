extern int gwrd ;
extern int scaleflag ;
extern	int		termrows ;
extern	int		termcols ;
