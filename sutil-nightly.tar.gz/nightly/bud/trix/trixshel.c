/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixshel.c + some command processor ...				|
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include	<stdio.h>
# include	<string.h>

# ifdef		DOS

# include	<conio.h>
# include	<stdlib.h>

# else		/* ANYX */

# include   <signal.h>

# endif		/* DOS */

# include	"trixasci.h"
# include	"trix.h"
# include	"trixblue.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixkeys.h"
# include	"trixwind.h"

# ifdef		CYGWIN
# include	<sys/wait.h>
# endif		/* CYGWIN */

# ifdef		LINUX
# include	<sys/wait.h>
# endif		/* LINUX */

# ifdef		SUNX
# include	<sys/types.h>
# include	<sys/wait.h>
# endif		/* SUNX */

# ifdef		ANYX
EXT char * clbuf ;
# endif		/* ANYX */

# define    PUTNL       putchar ('\n') ;

EXT     char *          ghyid ;
EXT		char *			currwd ;
EXT		char			origwd [ ] ;
/*======================================================================**
**	+ Shell ...															**
**	  + on dos should test 4 curr disk vs. logged disk & chdisk ...		**
**======================================================================*/
int trixshel () {

	if (trixcd (currwd) == -1)
		if (trixerr (T_XWDERR, currwd, errno, BANAL) == ESC)
			return -1 ;
	CLRSCR ; dispat (0, 0, T_SHEND, 79, VEREVS) ; locat (1, 0) ;
	chtermod ('s') ;
	trixrun (SYSHELL) ;
	chtermod ('w') ;
    trixcd (origwd) ;
	return 0 ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	+ app on all atgged 1s ...	|
 *									|_______________________________|
 */

char * exetag () {
	int grd ;
	char tb [512] ;
    FIX char cmdbuf [512] ;

	sprintf (tb, T_RUNANY, OPSYS) ;
	memset (cmdbuf, '\0', 80) ;

	ghyid = "cmd" ;
	grd = asktxt (tb, "$ ", cmdbuf, 70, USEBUF) ;
	ghyid = NOSTR ;

	if (grd != ENTER)
        return NOSTR ;

	return cmdbuf ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	+ x-pand & run app ...		|
 *									|_______________________________|
 */

int runtag (fdp, task) FILDAT * fdp ; char * task ; {
	char cmd [ 512 ] ;
	register char * tp ;
	register char * np ;
	register char * cp ;
	int grd ;

	for ( cp = cmd , tp = task ; *tp ; ++tp ) {
		if (*tp == '=') {
			for ( np = fdp->fd_path ; *np ; ++np )
				*cp++ = *np ;
		} else {
			*cp++ = *tp ;
		}
	}

	*cp++ = '\0' ;
	fprintf (stderr, "+ %s\n", cmd) ;
	grd = trixrun (cmd) ;
	return grd ;
}

/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	+ eXec : run a file ...		|
 *									|_______________________________|
 */

int trixexec (fdp) FILDAT * fdp ; {
	int grd ;
	char tb [512] ;
    char cmdbuf [512] ;

	if (fdp == NOFID) {
		sprintf (tb, T_RUNANY, OPSYS) ;
		memset (cmdbuf, '\0', 80) ;
	} else {
		sprintf (tb, T_RUNCMD, fdp->fd_path, OPSYS) ;
		strcpy (cmdbuf, fdp->fd_nam) ;
	}

	ghyid = "cmd" ;
	grd = asktxt (tb, "$ ", cmdbuf, 70, USEBUF) ;
	ghyid = NOSTR ;

	if (grd != ENTER)
        return -1 ;

	if (trixcd (currwd) == -1) {
		trixerr (T_XWDERR, currwd, errno, BANAL) ; return FALSE ;
	}

	CLRSCR ; sprintf (tb, T_RUNING, cmdbuf) ;
	dispat (0, 0, tb, 79, VEREVS) ; locat (1, 0) ;
	chtermod ('s') ;
    grd = trixrun (cmdbuf) ; PUTNL ;
    chtermod ('w') ;
	trixcd (origwd) ; /* should err if couldn't get (chd) back ! */
	dispat (23, 0, T_SHKRTN, 79, VEREVS) ; getkey () ;
	return 0 ;
}
/*
 *  |-----------------------------------------------------------|
 *  |   + print (spool) a file ...                              |
 *  |-----------------------------------------------------------|
 */
int trixprint (fdp) FILDAT * fdp ; {
	int grd ;
	char tb [512] ;
    char cmdbuf [512] ;
    EXT char * printcmd ;

    sprintf (tb, "* Imprimir %s ...", fdp->fd_path) ;
    sprintf (cmdbuf, "%s %s", printcmd, fdp->fd_path) ;
    grd = asktxt (tb, "$ ", cmdbuf, 70, USEBUF) ;

	if (grd != ENTER)
        return -1 ;

	CLRSCR ; locat (1, 0) ;
	chtermod ('s') ;
    grd = trixrun (cmdbuf) ; PUTNL ;
    chtermod ('w') ;
	dispat (23, 0, T_SHKRTN, 79, VEREVS) ; getkey () ;
	return 0 ;
}
/*
 *  |-----------------------------------------------------------|
 *  |   + edit a file with your favorite text processor ...     |
 *  |-----------------------------------------------------------|
 */
int trixedit (fdp) FILDAT * fdp ; {
	int grd ;
	char tb [512] ;
    char cmdbuf [512] ;
    EXT char * editcmd ;

    sprintf (tb, "* Editar %s ...", fdp->fd_path) ;
    sprintf (cmdbuf, "%s %s", editcmd, fdp->fd_path) ;
    grd = asktxt (tb, "$ ", cmdbuf, 70, USEBUF) ;

	if (grd != ENTER)
        return -1 ;

	if (trixcd (currwd) == -1)
		if (trixerr (T_XWDERR, currwd, errno, BANAL) == ESC)
			return -1 ;
	CLRSCR ; locat (1, 0) ;
	chtermod ('s') ;
    grd = trixrun (cmdbuf) ; PUTNL ;
    chtermod ('w') ;
	dispat (23, 0, T_SHKRTN, 79, VEREVS) ; getkey () ;
    trixcd (origwd) ;
	return 0 ;
}

/*                                       ___________________________
 *							            |							|
 *							            |	safely run a cmd ...    |
 *							            |___________________________|
 */

int trixrun (s) char * s ; {

# ifdef DOS

    return system (s) ;

# else  /* ANYX */

	REG SIGHANTYP	(*istat) (), (*qstat) ();
	    int			status, pid, w;

	if ((pid = fork ()) == 0) {
        if ( setuid (realuid) != 0 )
			return errno ;
		if ( setgid (realgid) != 0 )
			return errno ;
		execl ("/bin/sh", "sh", "-c", s, (char *)NULL);
		return (-1);
	}
 
	istat = signal (SIGINT,  SIG_IGN);
	qstat = signal (SIGQUIT, SIG_IGN);

	while ((w = wait (&status)) != pid && w != -1)
		;

	if (w == -1)
		status = -1;

	signal (SIGINT,  istat);
	signal (SIGQUIT, qstat);

	return (status);

# endif /* DOS */
}

/*******************************************************************/

/*
 * vi:nu ts=4
 */
