L=$1
C=$2
T=$3
[ -n "$L" ] || L=24
[ -n "$C" ] || L=80
[ -n "$T" ] || T=putty-xterm 
LINES=$L COLUMNS=$C TERM=$T ./trx $4 $5 $6 $7 $8 $9
