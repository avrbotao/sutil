
/*                 _________________________________________________
 *  ____________  |													|
 * /\  _________\ |	TRIX + directory & file administration utility	|
 * \ \ \______  / |_________________________________________________|
 *  \ \ \  / / /  |													|
 *   \ \ \/ / /	  | file window commands interface ...				|
 *    \ \/ / /	  |_________________________________________________|
 *     \  / /	  |													|
 *		\/_/	  |	TRIX & the TRIX logo are registered trademarks	|
 *                |	of Alexandre Victor Rodrigues Botao (1991)		|
 *				  |_________________________________________________|
 */

# include	<stdio.h>
# include	<string.h>

# ifdef		DOS
# include	<conio.h>
# endif		/* DOS */

# include	"trixasci.h"
# include	"trix.h"
# include	"trixstd.h"
# include	"trixblue.h"
# include	"trixkeys.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixmenu.h"
# include	"trixcmd.h"
# include	"trixwig.h"
# include	"trixwind.h"

# define	FWTNAM		( tfp -> fd_nam )
# define	MUSTAY		( ( pglok == FALSE ) && ( key == KDOWN ) )

EXT		UNS			gprot ;
EXT		int			nflg ;
EXT		int			( * filcmp ) () ;
EXT		int			fwlins ;		/* file window height in lines			*/
EXT		int			fwlinwid ;		/* line width of file window			*/
EXT		int			fwcofs ;		/* column offset of file window home	*/
EXT		int			fwlofs ;		/* line offset of file window home		*/
EXT		int			pglok ;			/* wrap around / scroll					*/
EXT		int			xfmb ;
EXT		int			finfmt ;		/* fil info fmt							*/
EXT		int			framtyp, mmval ;
EXT		int			trixtate, bedvue ;
EXT		int			ascord ;
EXT		int			wpathdr ;
EXT		int			wpathnam ;
EXT		int			logedest ;
EXT		int			bignamjus ;
EXT		int			overmove, overcopy ;
EXT		char		xdestdir	[ ] ;
EXT		char *		ghelpt , * xwhy ;
EXT		MENUCTL		auxmenu, bfwmenu ;
EXT		DIRDAT *	destdd ;
EXT		FILDAT *	destfilv ;
EXT		FILDAT *	destmflv ;

int filwut (dp, fwflgs) DIRDAT * dp ; int fwflgs ; {
	REG int tmx					;	/* tmp match fil lst inx			*/
	REG int a_tmx				;	/* aux. tmp match fil lst inx		*/
	REG char * curnam			;	/* current fil nam					*/
	REG FILDAT * tfp			;	/* tmp match fil lst ptr			*/
	REG FILDAT * * emlp 		;	/* extra match fil lst ptr			*/
	REG FILDAT * a_tfp			;	/* aux. tmp match fil lst ptr		*/
	REG FILDAT * * a_emlp 		;	/* aux. extra match fil lst ptr		*/
	REG int vlin = 0			;	/* video line						*/
	REG int vcol = 0			;	/* video col						*/
	REG FILDAT * * tmlp = NULL	;	/* tmp match fil lst ptr			*/
	REG FILDAT * * xmfl			;	/* extra match fil lst				*/
	REG int emx					;	/* extra match fil lst inx			*/
	REG int xmfk				;	/* extra match fil cnt				*/
	REG int tlin = 0			;	/* tmp cell line					*/
	REG int tcol = 0			;	/* cell col							*/
	REG int topx				;	/* top-of-pag index					*/
	REG DIRDAT * xdp			;	/* xtra dp 4 pan's backlink ...		*/
	REG int a_tlin				;	/* aux. tmp cell line				*/
	REG int a_tcol				;	/* aux. cell col					*/
# ifdef COMMENT
	REG int a_topx				;	/* aux. top-of-pag index			*/
# endif /* COMMENT */
	REG int curwid				;
	REG int dcolwid				;
	REG int key = 0				;
	REG int maxlin				;	/* phys max lin #					*/
	REG int ficols				;	/* # of file info cols				*/
	REG int elmspg				;	/* elements per pag					*/
	REG int tatr				;
	REG int bigfw = 0			;	/* it's a big file window ...		*/
	REG int clrfw = TRUE		;	/* clear file window b4 display		*/
	REG int recawc = TRUE		;	/* recalc window coordinates		*/
	REG int retot = TRUE		;	/* u/d tots on ctrl wdw				*/
	REG int mustay = FALSE		;	/* must stay still (don't home) ...	*/
	REG int upyego = FALSE		;	/* climb up if del last on pg ...	*/
	REG int grd = 0				;	/* generic result descriptor ...	*/
	REG long xmfb				;	/* extra match file bytes ...		*/
	REG int noscrup = FALSE		;	/* "no-scroll-up" wraps around ok	*/
	REG int tmpflg = 0			;
	REG int pgon				;
	REG int tmplix				;
	REG long tmpgix = 0L		;
/*		char tb [80]			;	*/
	REG	char * xp ;

# ifdef XTRC
	if ( dp == VZRO(DIRDAT *) )
		fprintf (trcfp, "filwut(NULL,%d)\r\n", fwflgs) ;
	else
		fprintf (trcfp, "filwut(%s,%d)\r\n", dp->dd_path, fwflgs) ;
# endif

	fwlins = _fwlins ;

	xmfl = dp->dd_mfl ;
	xmfk = (int)(dp->dd_mfk) ;
	/*___________________________________________________________________
	 *	+ I : dyn re-init / pg
	 *
	 *	+ dcolwid may chg via alt-f
	 *	+ maxlen idem when del or ren or cp .
	 */
refmtpag :
# ifdef BIGTRX
	if ( ! nflg ) {
		flipath ('f') ;
	}
	frescrn (UPATHDR, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	curwid = NAMSIZ ;
# else	/* OLDTRX */
	curwid = dp->dd_maxlen ;
# endif /* BIGTRX */
	dcolwid = curwid ;
    if (fwlinwid > dcolwid) {
        ++dcolwid ;
	}
	maxlin = fwlofs + fwlins ;
	ficols = fwlinwid / dcolwid ;
	elmspg = fwlins * ficols ;
	topx = 0 ;

	if (fwflgs & FWPAN) {
		goto retopg ;
	}
	if (fwflgs & FWPLAY) {
		if (key == 0) {
			goto play ;
		}
	}
	/*___________________________________________________________________
	 *	+ clean & fill up file window ...
	 *
	 *	+ file window should only be cleared b4 print when fwview ...
	 *
	 *	+ tlin, tcol must be set to the appropriate coordinates based on
	 *	  ofs_within_pag ...
	 */
retopg :	/* redraw from top-of-page ...	*/
	if (clrfw) {
		for ( vlin = fwlofs ; vlin < maxlin ; ++vlin ) {
			dispat (vlin, fwcofs, NOSTR, fwlinwid, VENORM) ;
		}
	}
	clrfw = TRUE ;
	vlin = fwlofs ;
	vcol = fwcofs ;
	tmx = topx ;
rexypg :	/* redraw from tmp x,y (mid page) ... */
	emx = topx + elmspg ;
	emlp = xmfl + tmx ;

	for ( ; tmx < emx ; ++tmx , ++emlp ) {
		if (tmx < xmfk) {
			tfp = *emlp ;
			tatr = VENORM ;
			if (TAGGED (tfp))
				tatr = VEHILT ;
			dispat (vlin, vcol, FWTNAM, curwid, tatr) ;
		} else {
			/*===========================================================
			 * + perhaps if in del d cur pg has < elmspp,
			 *   d last entry onpg should b cleared since
			 *   --fik (just once b4 brk) ...
			 */
			dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
			break ;
		}
		if (++vlin == maxlin) {
			vlin = fwlofs ;
			vcol += dcolwid ;
		}
	}
	if (fwflgs & FWVIEW) {
		return (grd) ;
	}
play :
	if (key == 0) {
		if (! (fwflgs & FWPAN))
			fliptot ('d') ;
		flipcur ('f') ; flipcmb ('f') ; flipfmb ('f') ;
		frescrn (DYNHDRS|CMNUBAR|FMNUBAR, NODID, NOFID) ;
	}
	if (retot) {
		/*_______________________________________________________________
		 *	retot should only b set 2 true by cmds lik ^D, ^M ...
		 */
		frescrn (UDTOTS, dp, NOFID) ;
		retot = FALSE ;
	}
	/*===================================================================
	 *	+ d if blow 'll bcom much simpler (in fact it'll turn out 2 b
	 *	  just " if ( cmd != SCROLL_1_DOWN ) { " when d above directive
	 *	  about " no pglok " bcoms effective ...
	 */
	if ( MUSTAY )
		mustay = TRUE ;
	if ( ! (  mustay ) ) {
		tmlp = xmfl + topx ;
		tlin = tcol = 0 ;
		vlin = fwlofs ;
		vcol = fwcofs ;
		if (mustay)
			mustay = FALSE ;
	}
	for (EVER) {
		/****************************************************************
		 *	+ recalc complex windowgraphy if necessary ...
		 *
		 *	+ it may be necessary to if ( x = f ( l , c ) )
		 *	  or ( ( l , c ) = f ( x ) ) ...
		 */
		if (recawc) {
			vcol = tcol * dcolwid + fwcofs ;
			vlin = tlin + fwlofs ;
			recawc = FALSE ;
		}
		tfp = *tmlp ;
		curnam = FWTNAM ;
        /*
         *  + u/d status info on screen ...
         */
		frescrn (UDCURF|UDSTATUS, NODID, tfp) ;

		if (fwflgs & FWPAN)
			dispat(_lpath,wpathdr,tfp->fd_dir->dd_path,wpathnam,VEHILT) ;
		/****************************************************************
		**	display its mode, date, owner, etc ... only if toggled
		*/
		if (finfmt == NAMONLY) {
			/*___________________________________________________________
			 *	+ refresh file window cursor ...
			 *
			 *	+ here should sprintf & keep along ... 2 speed up i/o
			 *	  mainly in the else ...
			 */
			dispat (vlin, vcol, curnam, curwid, VEREVS) ;
		}
		if (key == 0) {
			if (fwflgs & FWPAN) {
				key = KF4 ;
				goto kyt ;
			}
		}
        if (mmval != -1) {
            key = mmval ; mmval = -1 ;
        } else {
    		key = getkey () ;
		}
		tatr = VENORM ;
		if (TAGGED (tfp)) {
			tatr = VEHILT ;
		}
		dispat (vlin, vcol, curnam, curwid, tatr) ;
kyt :
		switch (key) {
			/*___________________________________________________________
			 *	up (north) arrow ...
			 */
			case '\b' :
			case '8' :
			case KUP :
up:
				if (vlin > fwlofs) { /* often ...	*/
					--tmlp ;
					--tlin ;
					--vlin ;
				} else { /* wrap back ... */
					if (vcol > fwcofs) { /* southwest wrap */
						--tmlp ;
						--tcol ;
						vcol -= dcolwid ;
						tlin = fwlins - 1 ;
						vlin = maxlin - 1 ;
					} else { /* wrap-end (southeast) or scroll up ...	*/
						if (pglok || noscrup) { /* wrap to end-of page	*/
							noscrup = FALSE ;
							if (upyego) {
								upyego = FALSE ;
								goto pup ;
							}
							tmx = xmfk - topx ;
							recawc = TRUE ;
							if ( tmx > elmspg ) { /* full page wrap ...	*/
								tlin = fwlins - 1 ;
								tcol = ficols - 1 ;
								tmx = topx + ( elmspg - 1 ) ;
								tmlp = xmfl + tmx ;
							} else { /* fractal wrap-eopg ... */
								--tmx ;
								tlin = tmx % fwlins ;
								tcol = tmx / fwlins ;
								tmlp += tmx ;
							} /* endif full or fractal wrap-end */
						} else { /* scroll up ... */
							if ( (int) (tmlp - xmfl) > 0 ) { /* able 2 scroll	*/
								--tmlp ;
								--topx ;
								clrfw = FALSE ;
								recawc = TRUE ;
								goto retopg ;
							} /* endif scrollable */
						} /* endif scroll or wrap  */
					} /* endif wrapend or line up */
				} /* endif wrap or no */
			break ;
			/*___________________________________________________________
			 *	down (south) arrow ...
			 */
			case '\r' :
			case '\n' :
			case '2' :
			case KDOWN :
				key = KDOWN ;
down:
				if ( tmlp - xmfl >= xmfk - 1 ) { /* no way down */
					if (pglok) { /* wrap home */
						tlin = tcol = 0 ;
						vlin = fwlofs ;
						vcol = fwcofs ;
						tmlp = xmfl + topx ;
					}
					break ;
				} /* endif way down */
				if ( vlin + 1 < maxlin ) { /* often */
					++tmlp ;
					++tlin ;
					++vlin ;
				} else { /* wrap or scroll ... */
					if ( tcol + 1 < ficols ) { /* northeast wrap */
						++tmlp ;
						++tcol ;
						vcol += dcolwid ;
						tlin = 0 ;
						vlin = fwlofs ;
					} else { /* home-wrap or scroll-down ... */
						if (pglok) { /* home wrap */
							tlin = tcol = 0 ;
							vlin = fwlofs ;
							vcol = fwcofs ;
							tmlp = xmfl + topx ;
						} else { /* scroll down */
							++tmlp ;
							++topx ;
							recawc = TRUE ;
							clrfw = FALSE ;
							goto retopg ;
						} /* endif scroll or home */
					} /* endif wrap home or / */
				} /* endif often */
			break ;
			/*___________________________________________________________
			 *	right (east) arrow ...
			 */
			case '6' :
			case KRIGHT :
				tmx = (int) (tmlp - xmfl) ;

				if ( tcol + 1 < ficols ) { /* often sam lin */
					++tcol ;
					vcol += dcolwid ;
					tmx += fwlins ;
				} else { /* southwest wrap */
swrap :
					tmx -= ( tcol * fwlins ) ;
					tcol = 0 ;
					vcol = fwcofs ;

					if ( tlin + 1 < fwlins ) { /* "may" go down */
						++tlin ;
						++vlin ;
						++tmx ;
					} else { /* northwest "home" wrap */
						tlin = 0 ;
						vlin = fwlofs ;
						tmx = topx ;
					} /* endif down or wrap */
				} /* endif often or wrap */
				if ( tmx >= xmfk ) { /* past edge-of-world ... */
					goto swrap ;
				} else { /* within d world ... */
					tmlp = xmfl + tmx ;
				} /* endif in this world */
			break ;
			/*___________________________________________________________
			 *	left (west) arrow ...
			 */
			case '4' :
			case KLEFT :
/* west : */
				tmx = (int) (tmlp - xmfl) ;
wleft :
				if ( tcol > 0 ) { /* often "may" go west ... */
					--tcol ;
					vcol -= dcolwid ;
					tmx -= fwlins ;
				} else { /* once per line we wrap ... */
					recawc = TRUE ;
					tcol = ficols - 1 ;
					tmx += ( tcol * fwlins ) ;
					if ( tlin > 0 ) { /* "may" wrap up */
						--tlin ;
						--tmx ;
					} else { /* wrap to eopg */
						tlin = fwlins - 1 ;
						tmx = topx + ( elmspg - 1 ) ;
					} /* endif up or eopg */
				} /* endif often or wrap */
				if ( tmx >= xmfk ) { /* past edge-of-world ... */
					goto wleft ;
				} else { /* within d world ... */
					tmlp = xmfl + tmx ;
				} /* endif in this world */
			break ;
			/************************************************************
			 *	[ Tab ] : flip back 2 tree wdw ...
			 *
			 *	+ leaving bigfw must redraw tree wdw ...
			 */
			case CMD_TREWIN :
			case TAB :
bye :
				if (bigfw == 'b') {
					framtyp = 'f' ; flipfram () ;
					fwcofs = _fwcofs ; fwlofs = _fwlofs ;
					fwlins = _fwlins ; fwlinwid = _fwlinw ;
				}
				goto eofw ;
			/************************************************************
			 *	[ F4 ] : flip screen design ...
			 */
			case CMD_BIGWIN :
			case ' ' : key = KF4 ;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			case KF4 :
				if (bigfw == 'b') {
					framtyp = 'f' ; flipfram () ; bigfw = 0 ;
					fwcofs = _fwcofs ; fwlofs = _fwlofs ;
					fwlins = _fwlins ; fwlinwid = _fwlinw ;
					trixtate = 'f' ;
					frescrn (UDTREE, NODID, NOFID) ;
				} else {
					framtyp = 'b' ; flipfram () ; bigfw = 'b' ;
					fwcofs = _bwcofs ; fwlofs = _bwlofs ;
					fwlins = _bwlins ; fwlinwid = _bwlinw ;
					trixtate = 'b' ;
				}
				mustay = FALSE ; recawc = TRUE ;
				goto refmtpag ;

			/*==========================================================*
			*	+ enough is enough ...									*
			*==========================================================*/

			case CMD_QUITOS :
			case CTRL_Q :
			case ESC :	/* quit ...	*/
			case 'Q' :
			case 'q' :	byechk () ; break ;

			/*==========================================================*
			*	+ Page Lock (should be activated by Scroll Lock) ...	*
			*	+ should status-out on-screen as well ...				*
			*==========================================================*/

			case CTRL_W :
				pglok = ! pglok ;
			break ;

			/*___________________________________________________________
			 *	PgUp ...
			 */
			case '9' :
			case KPGUP :
pup :
				if (topx >= elmspg) {
					topx -= elmspg ;
					tlin = tcol = 0 ;
					vlin = fwlofs ;
					vcol = fwcofs ;
					tmlp = xmfl + topx ;
					mustay = FALSE ;
					clrfw = TRUE ;
					goto retopg ;
				} else {
					goto cpu /* ? or home ? */ ;
				}
			/*___________________________________________________________
			 *	...
			 */
			case '3' :
			case KPGDN :
				if (topx + elmspg <= xmfk - 1) {
					topx += elmspg ;
					tlin = tcol = 0 ;
					vlin = fwlofs ;
					vcol = fwcofs ;
					tmlp = xmfl + topx ;
					mustay = FALSE ;
					clrfw = TRUE ;
					goto retopg ;
				} else {
					goto eopg ;
				}
			/*___________________________________________________________
			 *	move to 1st entry (on 1st page) ...
			 */
			case '7' :
			case KHOME :
cpu :
				tlin = tcol = 0 ;
				vlin = fwlofs ;
				vcol = fwcofs ;
				tmlp = xmfl ;
				topx = 0 ;
				mustay = FALSE ;
				goto retopg ;
			/*__________________________________________________________*
			 *	last entry (on last page) or ...						*
			 *__________________________________________________________*/
			case '1' :
			case KEND :
/* cpd : */
				if (xmfk > elmspg) {
					if (topx + elmspg > xmfk - 1)
						goto eopg ;
					topx = xmfk - elmspg ;
					tmlp = xmfl + topx + (elmspg-1) ;
					tlin = fwlins - 1 ;
					tcol = ficols - 1 ;
					mustay = recawc = TRUE ;
					goto retopg ;
				}
				goto eopg ;
			/*==========================================================*
			 *	home (northwest, start-og-page) ...						*
			 *==========================================================*/
			case '[' :
			case CPGUP :
/* home: */
				tlin = tcol = 0 ;
				vlin = fwlofs ;
				vcol = fwcofs ;
				tmlp = xmfl + topx ;
			break ;
			/*===========================================================
			 *	move to end-of-page ...
			 */
			case ']' :
			case CPGDN :
eopg :
				tlin = tcol = 0 ;
				vlin = fwlofs ;
				vcol = fwcofs ;
				tmlp = xmfl + topx ;
				noscrup = TRUE ;
				goto up ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ Ordenar (change sort criterion) diretorio atual ...	|
 *			|___________________________________________________________|
 */
			case CMD_ORDCUR :
			case 'o' :
ocd :					if (trixord ('o') == ESC)
							break ;
						qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
								sizeof (FILDAT *), filcmp) ;
						goto cpu ;
/*			 ___________________________________________________________
 *			|															|
 *			|	+ Ordenar (change sort criterion) todos os diretorios	|
 *			|___________________________________________________________|
 */
			case CMD_ORDALL :
			case 'O' :
						if (fwflgs & FWPAN)
							goto ocd ;
						if (trixord ('O') == ESC)
							break ;
						trixsort () ; goto cpu ;
/*
 *			|-------------------------------------------------------|
 *			|	binary edit a file ...                              |
 *			|-------------------------------------------------------|
 */
			case CMD_BEDFIL :
            case 'b' :
				if (trixebit (tfp) == -1)
                    break ;
				flipcmb ('f') ; flipfmb ('f') ;
				rescreen (dp, tfp) ;
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
/*
 *			|-------------------------------------------------------|
 *			|	edit a file ...                                     |
 *			|-------------------------------------------------------|
 */
			case CMD_TEDFIL :
            case 'e' :
				if (trixedit (tfp) == -1)
                    break ;
				flipcmb ('f') ; flipfmb ('f') ;
				rescreen (dp, tfp) ; /* full screen refresh ... */
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
/*
 *			:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 *			::	print a file ...                                   ::
 *			:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 */
			case CMD_PRTFIL :
            case 'i' :
				if (trixprint (tfp) == -1)
                    break ;
				flipcmb ('f') ; flipfmb ('f') ;
				rescreen (dp, tfp) ; /* full screen refresh ... */
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
			/*	 ___________________________________________________
			 *	|													|
			 *	|	+ family of files : FileName Specification ...	|
			 *	|___________________________________________________|
			 */
			case CMD_FAMRXP :
			case 'f' :
			case 'F' :
				trixfam () ;

				if (fwflgs & FWPAN) {
					trixpan (PANMFL) ;
				}
				if (dp->dd_mfk > 0) {
					xmfk = (int)(dp->dd_mfk) ;
					frescrn (UDMATS|UDRGXP, dp, NOFID) ;
# ifdef BIGTRX
					curwid = NAMSIZ ;
# else	/* OLDTRX */
					curwid = dp->dd_maxlen ;
# endif /* BIGTRX */
    	            dcolwid = curwid ;
                    if (fwlinwid > dcolwid)
                        ++dcolwid ;
					ficols = fwlinwid / dcolwid ;
					elmspg = fwlins * ficols ;
					goto cpu ;
				} else {
					goto bye ;
				}
/*
 *			:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 *			::													   ::
 *			::	+ copy current file somewhere ...				   ::
 *			::													   ::
 *			:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 */
			/*
			 *		+ "still won't do" list ... (just 4 fenasoft)
			 *
			 *		+ u/d dest dir tots ...
			 *		+ use proprietary routines
			 *		+ disp %, bars, & bytes
			 */

			case CMD_CPYFIL :
			case 'C' :			key = 'c' ;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			case 'c' :

				dispat (vlin, vcol, curnam, curwid, VEBLNK) ;

				destfilv = destmflv = (FILDAT *) 0 ;
				logedest = overcopy = FALSE ;
				destdd = VZRO (DIRDAT *) ;

				if (trixdest ( tfp , xdestdir , key ) != 0) {
					frescrn (UDMNUS, NODID, NOFID) ;
					logedest = overcopy = FALSE ;
					destdd = VZRO (DIRDAT *) ;
					break ;
				}

				grd = copfil ( tfp , xdestdir , CONFLG ) ;

				frescrn (UDMNUS, NODID, NOFID) ;

				if (grd == ESC || grd == -1) {
					logedest = overcopy = FALSE ;
					destdd = VZRO (DIRDAT *) ;
					break ;
				}

				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;

			/* break ;	*/
/*
 *			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *			%	+ delete the current file , or ...					%
 *			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *
 *			O-------------------------------------------------------O
 *			|	+	move it someplace else ...						|
 *          |   +   if (xdestdir is logged) ** 4 trixdest() 2 chk!	|
 *			|          nu dirdat parent point 2 fildat (GROW LISTS) |
 *			|          ++(nu dirdat parent's)->files & bytes        |
 *			|          recalc nu dd par's maxlen                    |
 *			|          u/d fildat's dir par backlink & ff_path      |
 *			|          --(old dd par) files&byts (as delfil does)   |
 *			|          don't free() fildat                          |
 *			|          shrink old dd par lists (as delfil does)     |
 *			|			don't forget "overmove" side effects ...	|
 *			|       else                                            |
 *			|          behave as with deleted files                 |
 *			|	+	b4 start moving we must 						|
 *			|			trixcd (tfp->fd_dir->dd_path) ;				|
 *			|		but this involves dyn/y chg currwd & then set	|
 *			|		it back 2 its orig val ... (so think)			|
 *			O-------------------------------------------------------O
 */
			case CMD_DELFIL :
			case 'd' :								/* del it ...	*/
			case 'D' :	key = 'd' ; goto pdm ;
			case CMD_MOVFIL :
			case 'm' :								/* mov it ...	*/
			case 'M' :	key = 'm' ;
pdm :			dispat (vlin, vcol, curnam, curwid, VEBLNK) ;
				/*
				 *	+ disintegration or movimentation ...
				 */

				xdp = tfp->fd_dir ;
				tmplix = (int) (tfp->fd_lix) ;

				destfilv = destmflv = (FILDAT *) 0 ;
				logedest = overmove = FALSE ;
				destdd = VZRO (DIRDAT *) ;

				if (key == 'd') {
					honk () ;
					logedest = overmove = FALSE ;
					destdd = VZRO (DIRDAT *) ;
					grd = delfil ( tfp , CONFLG ) ;
				} else {
					if (trixdest ( tfp , xdestdir , key ) != 0) {
						frescrn (UDMNUS, NODID, NOFID) ;
						logedest = overmove = FALSE ;
						destdd = VZRO (DIRDAT *) ;
						break ;
					}
					grd = movfil ( tfp , xdestdir , CONFLG ) ;
					frescrn (UDMNUS, NODID, NOFID) ;
				}
				if (grd == ESC || grd == -1) {
					logedest = overmove = FALSE ;
					destdd = VZRO (DIRDAT *) ;
					break ;
				}
/*
 *				+ = = = = = = = = = = = = = = = = = = = = = = = = = +
 *              | retot or not retot ...							|
 *              | in case of loged dest, work things out ...		|
 *				+ = = = = = = = = = = = = = = = = = = = = = = = = = +
 */
				if (key == 'd')
					retot = TRUE ;
				else
					if (logedest)
						if (fwflgs & FWPAN)
							if (overmove)
								retot = TRUE ;
							else
								retot = FALSE ;
						else
							retot = TRUE ;
					else
						retot = TRUE ;

				if (logedest)
					udirdat (destdd, tfp, CMD_MOVFIL) ;
				else
					overmove = FALSE ;
/*
 *				+ - - - - - - - - - - - - - - - - - - - - - - - - - +
 *              | u/d counts (files & bytes) ...					|
 *				+ - - - - - - - - - - - - - - - - - - - - - - - - - +
 */
				xmfb = tfp->fd_stabuf.STASIZ ;

				if ( retot ) {
					--xmfk ;
					dp->dd_fik -= 1    ; dp->dd_mfk -= 1    ;
					dp->dd_fib -= xmfb ; dp->dd_mfb -= xmfb ;
				}
				if (fwflgs & FWPAN) {
					xdp->dd_fik -= 1    ; xdp->dd_mfk -= 1    ;
					xdp->dd_fib -= xmfb ; xdp->dd_mfb -= xmfb ;
				} else {
					if (logedest == FALSE) {
						TOTFILS    -= 1    ; MATFILS    -= 1    ;
						TOTBYTS    -= xmfb ; MATBYTS    -= xmfb ;
					}
				}
/*
 *				+ - - - - - - - - - - - - - - - - - - - - - +
 * 	   		    |	tagged stats adjustments ...			|
 *				+ - - - - - - - - - - - - - - - - - - - - - +
 */
				if (TAGGED (tfp)) {
					dp->dd_tfk -= 1 ; dp->dd_tfb -= xmfb ;

					if (fwflgs & FWPAN) {
						xdp->dd_tfk -= 1 ; xdp->dd_tfb -= xmfb ;
					} else {
						SELFILS -= 1 ; SELBYTS -= xmfb ;
					}

					UNTAGT (tfp) ;
				}
/*
 *				+===================================================+
 *				|	+ free info , adjust lists (if so) ...			|
 *				|	+ should we care 4 free() errors ?				|
 *				+===================================================+
 */
				if (fwflgs & FWPAN) {
					/*
					 *	+ u/d parent's (backlink _dir's) fil by lix .
					 */
					emx = tmplix /* (int)(tfp->fd_lix) */ ;
					emlp = xdp->dd_fil ; emlp += emx ;
					while (emx++ < xdp->dd_fik) {
						*emlp = *(emlp+1) ; (*emlp)->fd_lix -= 1 ;
						++emlp ;
					}
					/*
					 *	+ idem 4 mfl by mix or by seq lin srch ...
					 *
					 *		this is a bit tricky & embarassing :
					 *		fd_mix ins't solid until it can
					 *		survive a qsort() ... so d seq lin srch
					 *		is safer & regretably slower !
					 */
# ifdef OLDTRIX
					emx = (int)(tfp->fd_mix) ;
					emlp = xdp->dd_mfl ; emlp += emx ;
					while (emx++ < xdp->dd_mfk) {
						*emlp = *(emlp+1) ; (*emlp)->fd_mix -= 1 ;
						++emlp ;
					}
# else  /* GUARANTEED */
					emx = 0 ; emlp = xdp->dd_mfl ;
					while (emx < xdp->dd_mfk) {
						if (*emlp == tfp)
							break ;
						++emlp ; ++emx ;
					}
					if (*emlp != tfp) {
						trixerr ("* ERRO INTERNO # 4 !", NOSTR, NOWHY, FATAL) ;
					}
					while (emx < xdp->dd_mfk) {
						*emlp = *(emlp+1) ;
						++emlp ; ++emx ;
					}
# endif /* OLDTRIX */
					if (logedest) {
						if (overmove) {
							/*
							 *	@ substitute fildat on gpan's
							 *	(dp's) twin (dest) entries ...
							 */
							emx = 0 ; emlp = dp->dd_fil ;
							while ( emx < (1+(dp->dd_fik)) ) {
								if (*emlp == destfilv)
									break ;
								++emx ; ++emlp ;
							}
							if (*emlp != destfilv) {
								trixerr ("* ERRO INTERNO # 8 !", NOSTR, NOWHY, FATAL) ;
							}
							emx = (int) ((*emlp)->fd_gix) ;
							*emlp = tfp ;
							tmpgix = tfp->fd_gix ;
							tfp->fd_gix = emx ;

							emx = 0 ; emlp = dp->dd_mfl ;
							while (emx < xmfk) {
								if (*emlp == destmflv)
									break ;
								++emx ; ++emlp ;
							}
							if (*emlp != destmflv) {
								xwhy = "**** ERRO INTERNO # 9 ****" ;
								epilog () ;
							}
							*emlp = tfp ;
							dp->dd_fik += 1    ; dp->dd_mfk += 1    ;
							dp->dd_fib += xmfb ; dp->dd_mfb += xmfb ;
						} else {
							tmx = (int) (tmlp - xmfl) ;
							goto eodm ;
						} /* endif (overmove) */
					} /* endif (logedest) */
					/*
					 *	+ u/d gpan's (dp's) fil by gix .
					 */
					if (! overmove)
						emx = (int) (tfp->fd_gix) ;
					else
						emx = (int) tmpgix ;
					if (logedest == FALSE) {
						free ( (char *) (tfp->fd_path) ) ;
						free ( (char *) tfp ) ;
					}
					emlp = dp->dd_fil ; emlp += emx ;
					while (emx++ < dp->dd_fik) {
						*emlp = *(emlp+1) ; (*emlp)->fd_gix -= 1 ;
						++emlp ;
					}
					/*
					 *	+ idem 4 mfl by tmlp .
					 */
					if ( (tmx = emx = (int)(tmlp - xmfl)) < xmfk ) {
						emlp = tmlp ; upyego = FALSE ;
						while (emx++ < xmfk)
							{ *emlp = *(emlp+1) ; ++emlp ; }
					} else {
						dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
						upyego = TRUE ;
					}
				} else {
					emx = tmplix /*   (int)(tfp->fd_lix) */ ;
					if (logedest == FALSE) {
						free ( (char *) (tfp->fd_path) ) ;
						free ( (char *) tfp ) ;
					}
					emlp = dp->dd_fil ; emlp += emx ;
					while (emx++ < dp->dd_fik) {
						*emlp = *(emlp+1) ; (*emlp)->fd_lix -= 1 ;
						++emlp ;
					}
					if ( (tmx = emx = (int)(tmlp - xmfl)) < xmfk ) {
						emlp = tmlp ; upyego = FALSE ;
						while (emx++ < xmfk)
							{ *emlp = *(emlp+1) ; ++emlp ; }
					} else {
						dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
						upyego = TRUE ;
					}
				}
eodm :
				if ( xmfk == 0 ) /* return if last file ... */
					goto bye ;
				/*
				 *	+ video adjust & u/d ...
				 *
				 *	+ if it's the last entry on page, must go up (but
				 *	  care must be taken w/ scroll) . otherwise  just
				 *	  relist from here [ to e.o.pg ] (& go back to
				 *	  the current screen coordinates) ...
				 */
				if (upyego) {
					frescrn (UDTOTS, dp, NOFID) ;
					goto up ;
				}
				recawc = TRUE ; /* ? depends ? ... */
				mustay = TRUE ; /* ? depends ? ... */
				goto rexypg ;
/*
 *			|-------------------------------------------------------|
 *			|	protect current file ...                            |
 *			|-------------------------------------------------------|
 */
			case CMD_SECFIL :
            case 'p' :
				proted (tfp, NODID, 'f') ;
				rescreen (dp, tfp) ;
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
/*			 _______________________________________________________
 *          |                                                       |
 *			|	+ rename :	b4 sort we should match the nu nam      |
 *			|				against d curr pattern ...              |
 *			|_______________________________________________________|
 */
			case 'r' :
			case 'R' :
			case CMD_RENFIL :

				dispat (vlin, vcol, curnam, curwid, VEBLNK) ;
				grd = trixren ( tfp ) ;

				if (grd == ESC || grd == -1) {
					break ;
				}

				grd = strlen (tfp->fd_nam) ;

				if (grd > dp->dd_maxlen) {
					dp->dd_maxlen = grd ;
# ifdef BIGTRX
					curwid = NAMSIZ ;
# else	/* OLDTRX */
					curwid = dp->dd_maxlen ;
# endif /* BIGTRX */
	                dcolwid = curwid ;
                    if (fwlinwid > dcolwid)
                        ++dcolwid ;
					ficols = fwlinwid / dcolwid ;
					elmspg = fwlins * ficols ;
				}

				qsort ( (char *)(dp->dd_mfl), (int)(dp->dd_mfk),
						sizeof (FILDAT *), filcmp) ;

				if (fwflgs & FWPAN) {
					xdp = tfp->fd_dir ;
					if (grd > xdp->dd_maxlen)
						xdp->dd_maxlen = grd ;
					qsort ( (char *)(xdp->dd_mfl), (int)(xdp->dd_mfk),
							sizeof (FILDAT *), filcmp) ;
				}

			mustay = recawc = TRUE ; goto retopg ;

			/*___________________________________________________________
			 *	...
			 */
			case CMD_SELFIL :
			case 's' :	/* select it ...	*/
			case 'S' :	/* select it ...	*/

				if (TAGGED (tfp)) {
					goto unsel ;
				}
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			/*___________________________________________________________
			 *	tag current file ...
			 */
			case CMD_TAGFIL :
			case 't' :
			case 'T' :
				if (TAGGED (tfp))
					goto down ;
				TAGGIT (tfp) ; xmfb = tfp->fd_stabuf.STASIZ ;
				dp->dd_tfk += 1 ; dp->dd_tfb += xmfb ;
				if (fwflgs & FWPAN) {
					xdp = tfp->fd_dir ;
					xdp->dd_tfk += 1 ; xdp->dd_tfb += xmfb ;
				} else
					{ SELFILS += 1 ; SELBYTS += xmfb ; }
				dispat (vlin, vcol,	curnam, curwid, VEHILT) ;
udt :			frescrn (UDSELS, dp, NOFID) ;
				key = KDOWN ; goto down ;
			/*___________________________________________________________
			 *	untag current file ...
			 */
			case CMD_UNTFIL :
			case 'u' :
			case 'U' :
				if (TAGGED (tfp) == FALSE)
					goto down ;
unsel :			UNTAGT (tfp) ; xmfb = tfp->fd_stabuf.STASIZ ;
				dp->dd_tfk -= 1 ; dp->dd_tfb -= xmfb ;
				if (fwflgs & FWPAN) {
					xdp = tfp->fd_dir ;
					xdp->dd_tfk -= 1 ; xdp->dd_tfb -= xmfb ;
				} else
					{ SELFILS -= 1 ; SELBYTS -= xmfb ; }
				dispat (vlin, vcol,	curnam, curwid, VENORM) ;
				goto udt ;
/*
 *												|~~~~~~~~~~~~~~~~~~~|
 *												|	ascii vur ...	|
 *												|___________________|
 */
			case 'v' :
			case 'V' :
			case CMD_ASCVUE :
av :
				grd = trixvue (tfp) ;

				if (grd == -1)
					break ;

				if (grd == 'h')
					goto hv ;

				flipcmb ('f') ; flipfmb ('f') ;
				rescreen (dp, tfp) ;
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
/*
 *												|~~~~~~~~~~~~~~~~~~~|
 *												|	hex vur ...		|
 *												|___________________|
 */
			case 'h' :
			case CMD_BEDVUE :
hv :
				bedvue = TRUE ;
				grd = trixebit (tfp) ;
				bedvue = FALSE ;

				if (grd == -1)
					break ;

				if (grd == 'a')
					goto av ;

				flipcmb ('f') ; flipfmb ('f') ;
				rescreen (dp, tfp) ;
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
/*
 *									|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *									|	flippy ^tag / ^untag ...	|
 *									|_______________________________|
 */
			case CMD_SELALL :
			case CTRL_S :	/* select (or unselect) 'em all ... */
				if (dp->dd_tfk > 0) {
					tmx = xmfk ;
					emlp = xmfl ;

					while (tmx--) {
						tfp = *emlp++ ;

						if (TAGGED (tfp))
							goto unsal ;
					}
					goto sal ;
				} else {
					goto sal ;
				}
/*			 _______________________________________________________
 *			|														|
 *			|	+ tag (select) all files on the current dir ...		|
 *			|_______________________________________________________|
 */
			case CMD_TAGTAG :
			case CTRL_T :				/* tag 'em all ...				*/
sal :									/* select'em all ...			*/
				tmx = xmfk ; emlp = xmfl ;
				while (tmx--) {
					tfp = *emlp++ ;
					if (TAGGED (tfp))
						continue ;
					TAGGIT (tfp) ; xmfb = tfp->fd_stabuf.STASIZ ;
					dp->dd_tfk += 1 ; dp->dd_tfb += xmfb ;
					if (fwflgs & FWPAN) {
						xdp = tfp->fd_dir ;
						xdp->dd_tfk += 1 ; xdp->dd_tfb += xmfb ;
					} else
						{ SELFILS += 1 ; SELBYTS += xmfb ; }
				}
uds :			frescrn (UDSELS, dp, NOFID) ;
				recawc = mustay = TRUE ; goto retopg ;
/*			 _______________________________________________________
 *			|														|
 *			|	+ untag (unselect) all files on the current dir ...	|
 *			|_______________________________________________________|
 */
			case CMD_UNTTAG :
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			case CTRL_U :						/* untag 'em all ...	*/
unsal : 										/* unselect  all ...	*/
				tmx = xmfk ; emlp = xmfl ;
				while (tmx--) {
					tfp = *emlp++ ;
					if (TAGGED (tfp) == FALSE)
						continue ;
					UNTAGT (tfp) ; xmfb = tfp->fd_stabuf.STASIZ ;
					dp->dd_tfk -= 1 ; dp->dd_tfb -= xmfb ;
					if (fwflgs & FWPAN) {
						xdp = tfp->fd_dir ;
						xdp->dd_tfk -= 1 ; xdp->dd_tfb -= xmfb ;
					} else
						{ SELFILS -= 1 ; SELBYTS -= xmfb ; }
				}
				goto uds ;
/*           _______________________________________________________
 *			:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 *			::													   ::
 *			::	+ copy all tagged files							   ::
 *			::_____________________________________________________::
 *			:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 */
			case CMD_CPYTAG :	key = CTRL_C ;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			case CTRL_C :

				if (dp->dd_tfk < 1) {
					break ;
                }
/*
 *				O-------------------O
 *				|	...				|
 *				O-------------------O
 */
				honk () ;

				destfilv = destmflv = (FILDAT *) 0 ;
				logedest = overcopy = FALSE ;
				destdd = VZRO (DIRDAT *) ;

    			dispat (vlin, vcol, curnam, curwid, VEREVS) ;
/*
 *				O-------------------O
 *				|	...				|
 *				O-------------------O
 */
				grd = trixdest ( tfp , xdestdir , key ) ;

				if (grd != 0) {
					frescrn (UDMNUS, NODID, NOFID) ;
					logedest = overcopy = FALSE ;
					destdd = VZRO (DIRDAT *) ;
					goto notd ;
				}

				ghelpt = T_ARMXFIL ;
				grd = vaskyn (T_ARMXFIL, T_VYNFMB) ;
				ghelpt = NOSTR ;
				switch (grd) {
					case CTRL_Q :
					case ESC   : goto udm ;
					case ENTER :
					case NOPE  : tmpflg = CONFLG ; break ;
					case YEAH  : tmpflg = 0 ; break ;
				}
/*
 *				O-------------------------------O
 *				|	+ some inits & b/ups ...	|
 *				O-------------------------------O
 */
				pgon = FALSE ;

				if (topx == 0)
					pgon = TRUE ;

				a_tmx = 0 ;
				a_emlp = xmfl ;
				topx = tlin = tcol = 0 ;
				/*------------------------------------------------------*
				 *	+ loop scanning & processing tagged files ...		*
				 *------------------------------------------------------*/
				for ( ; ; ) {
					if (xmfk == 0) /* no more files 2 del ! */
						break ;
					if (a_tmx >= xmfk) /* don't go beyond e-o-lst ! */
						break ;
					a_tfp = *a_emlp ;

					if (TAGGED (a_tfp)) {
						if (pgon == FALSE) {	/* disp curr pag */
							for (vlin = fwlofs ; vlin < maxlin ; ++vlin)
								dispat (vlin, fwcofs,
										NOSTR, fwlinwid, VENORM) ;
							vlin = fwlofs ; vcol = fwcofs ; tmx = topx ;
							emx = topx + elmspg ; emlp = xmfl + tmx ;
							for ( ; tmx < emx ; ++tmx , ++emlp ) {
								if (tmx < xmfk) {
									tfp = *emlp ; tatr = VENORM ;
									if (TAGGED (tfp))
										tatr = VEHILT ;
									dispat (vlin, vcol, FWTNAM, curwid, tatr) ;
								} else {
									dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
									break ;
								}
								if (++vlin == maxlin)
									{ vlin = fwlofs ; vcol += dcolwid ; }
							}
							pgon = TRUE ;
						}
						vcol = tcol * dcolwid + fwcofs ;
						vlin = tlin + fwlofs ; curnam = a_tfp->fd_nam ;
						dispat (vlin, vcol,	curnam, curwid, VEBLNK) ;
						frescrn (UDCURF|UDSTATUS, NODID, a_tfp) ;
						if (fwflgs & FWPAN)
							dispat (_lpath, wpathdr,
									a_tfp->fd_dir->dd_path,
									wpathnam, VEHILT) ;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
						grd = copfil ( a_tfp , xdestdir , tmpflg ) ;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
						tatr = VENORM ;
						if (TAGGED (a_tfp))
							tatr = VEHILT ;
						dispat (vlin, vcol,	curnam, curwid, tatr) ;
						if (grd == ESC)
							goto cpu ;	/* PROVISORY ! MUST STAY ! */
					}

					if (++tlin == fwlins) {
						tlin = 0 ;
						if (++tcol == ficols) {
							tcol = 0 ; pgon = FALSE ;
							topx += elmspg ;
						}
					}

					++a_emlp ; ++a_tmx ;

				} /* endof for (anytagged) */

				frescrn (UDMNUS, NODID, NOFID) ;
				goto cpu ;	/* PROVISORY ! MUST STAY ! */

		/*	break ;	*/	/* endof ^Copy all tagged 1s ... */

/*			 _______________________________________________________
 *			|														|
 *			|	+ delete or move all tagged files ...				|
 *			|_______________________________________________________|
 *			|														|
 *			|	+ @ e-o-work we home() but this is some provisory	|
 *			|	  behavioral solution ! the correct one is to stay	|
 *			|	  wherever the work ends or gets suspended (this	|
 *			|	  can b done with a precise and complete restore	|
 *			|	  of all ctl vars)									|
 *			|														|
 *			|	+ ^M is much like CR (regretably)					|
 *			|_______________________________________________________|
 */
			case CMD_DELTAG : key = CTRL_D ;
			case CTRL_D : goto p_d_m ;
			case CMD_MOVTAG : key = CTRL_O ;
# if defined (__GNUC__) 
					__attribute__ ((fallthrough));
# endif
			case CTRL_O :
p_d_m :			if (dp->dd_tfk < 1) {
notd :									/* nothing 2 do ! ...			*/
					break ;
				}
				honk () ;

				destfilv = destmflv = (FILDAT *) 0 ;
				logedest = overmove = FALSE ;
				destdd = VZRO (DIRDAT *) ;

    			dispat (vlin, vcol, curnam, curwid, VEREVS) ;

				if (key == CTRL_D) {
					logedest = overmove = FALSE ;
					destdd = VZRO (DIRDAT *) ;
					ghelpt = T_DELSEL ;
					grd = askyn (T_DELSEL, T_CHK4DEL) ;
					ghelpt = NOSTR ;
					switch (grd) {
						case CTRL_Q :
						case ESC   : goto notd ;
						case NOPE  : tmpflg = 0 ; break ;
						case ENTER :
						case YEAH  : tmpflg = CONFLG ; break ;
					}
				} else if (key == CTRL_O) {
					grd = trixdest ( tfp , xdestdir , key ) ;

					if (grd != 0) {
udm :					frescrn (UDMNUS, NODID, NOFID) ;
						logedest = overmove = FALSE ;
						destdd = VZRO (DIRDAT *) ;
						goto notd ;
					}

					ghelpt = T_ARMXFIL ;
					grd = vaskyn (T_ARMXFIL, T_VYNFMB) ;
					ghelpt = NOSTR ;
					switch (grd) {
						case CTRL_Q :
						case ESC   : goto udm ;
						case ENTER :
						case NOPE  : tmpflg = CONFLG ; break ;
						case YEAH  : tmpflg = 0 ; break ;
					}
				}
				/*------------------------------------------------------*
				 *	+ some initializations & backups ...				*
				 *------------------------------------------------------*/
				pgon = FALSE ;
				if (topx == 0)
					pgon = TRUE ;
# ifdef COMMENT
				a_tlin = tlin ;
				a_tcol = tcol ;
				a_topx = topx ;
# endif /* COMMENT */
				a_tmx = 0 ;
				a_emlp = xmfl ;
				topx = tlin = tcol = 0 ;
				/*------------------------------------------------------*
				 *	+ loop scanning & processing tagged files ...		*
				 *------------------------------------------------------*/
				for ( ; ; ) {
					if (xmfk == 0) /* no more files 2 del ! */
						break ;
					if (a_tmx >= xmfk) /* don't go beyond e-o-lst ! */
						break ;
					a_tfp = *a_emlp ;

					if (TAGGED (a_tfp)) {
						if (pgon == FALSE) {	/* disp curr pag */
							for (vlin = fwlofs ; vlin < maxlin ; ++vlin)
								dispat (vlin, fwcofs,
										NOSTR, fwlinwid, VENORM) ;
							vlin = fwlofs ; vcol = fwcofs ; tmx = topx ;
							emx = topx + elmspg ; emlp = xmfl + tmx ;
							for ( ; tmx < emx ; ++tmx , ++emlp ) {
								if (tmx < xmfk) {
									tfp = *emlp ; tatr = VENORM ;
									if (TAGGED (tfp))
										tatr = VEHILT ;
									dispat (vlin, vcol, FWTNAM, curwid, tatr) ;
								} else {
									dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
									break ;
								}
								if (++vlin == maxlin)
									{ vlin = fwlofs ; vcol += dcolwid ; }
							}
							pgon = TRUE ;
						}
						vcol = tcol * dcolwid + fwcofs ;
						vlin = tlin + fwlofs ;
						curnam = a_tfp->fd_nam ;
						dispat (vlin, vcol,	curnam, curwid, VEBLNK) ;
						frescrn (UDCURF|UDSTATUS, NODID, a_tfp) ;
						if (fwflgs & FWPAN)
							dispat (_lpath, wpathdr,
									a_tfp->fd_dir->dd_path,
									wpathnam, VEHILT) ;

						xdp = a_tfp->fd_dir ;
						tmplix = (int) (a_tfp->fd_lix) ;
						destfilv = destmflv = (FILDAT *) 0 ;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
						if (key == CTRL_D) {
							grd = delfil ( a_tfp , tmpflg ) ;
						} else if (key == CTRL_O) {
							grd = movfil ( a_tfp , xdestdir , tmpflg ) ;
						}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
						tatr = VENORM ;
						if (TAGGED (a_tfp))
							tatr = VEHILT ;
						dispat (vlin, vcol,	curnam, curwid, tatr) ;

						if (grd == ESC) {
# ifndef VRSN0 /* should be really ifdef ! (perhaps in v2.0) */
							logedest = overmove = FALSE ;
							destdd = VZRO (DIRDAT *) ;
							frescrn (UDMNUS, NODID, NOFID) ;
							goto cpu ;	/* PROVISORY ! MUST STAY ! */
# else  /* NU */
							logedest = overmove = FALSE ;
							destdd = VZRO (DIRDAT *) ;
							tlin = a_tlin ;
							tcol = a_tcol ;
							topx = a_topx ;
							tmlp = a_emlp ;
							mustay = recawc = TRUE ;
							goto notd ; /* NEEDS ADJUSTMENTS ! ! ! */
# endif /* V0 */
						}
						if (grd == -1)
							goto pgdny ;
/*
 *						+ = = = = = = = = = = = = = = = = = = = = = +
 *						| retot or not retot ...					|
 *						| in case of loged dest, work things out.	|
 *						+ = = = = = = = = = = = = = = = = = = = = = +
 */
						if (key == CTRL_D)
							retot = TRUE ;
						else
							if (logedest)
								if (fwflgs & FWPAN)
									if (overmove)
										retot = TRUE ;
									else
										retot = FALSE ;
								else
									retot = TRUE ;
							else
								retot = TRUE ;

						if (logedest)
							udirdat (destdd, a_tfp, CMD_MOVTAG) ;
						else
							overmove = FALSE ;
/*
 *						+ - - - - - - - - - - - - - - - - - - - - - +
 * 	        		    | u/d counts (files & bytes) ...			|
 *						+ - - - - - - - - - - - - - - - - - - - - - +
 */
						xmfb = a_tfp->fd_stabuf.STASIZ ;

						if ( retot ) {
							--xmfk ;
							dp->dd_fik -= 1    ; dp->dd_mfk -= 1    ;
							dp->dd_fib -= xmfb ; dp->dd_mfb -= xmfb ;
						}
						if (fwflgs & FWPAN) {
							xdp->dd_fik -= 1    ; xdp->dd_mfk -= 1    ;
							xdp->dd_fib -= xmfb ; xdp->dd_mfb -= xmfb ;
						} else {
							if (logedest == FALSE) {
								TOTFILS    -= 1    ; MATFILS    -= 1    ;
								TOTBYTS    -= xmfb ; MATBYTS    -= xmfb ;
							}
						}
/*
 *						+ - - - - - - - - - - - - - - - - - - - - - +
 * 	        		    |	tagged stats adjustments ...			|
 *						+ - - - - - - - - - - - - - - - - - - - - - +
 */
						dp->dd_tfk -= 1 ; dp->dd_tfb -= xmfb ;

						if (fwflgs & FWPAN) {
							xdp->dd_tfk -= 1 ; xdp->dd_tfb -= xmfb ;
						} else {
							SELFILS -= 1 ; SELBYTS -= xmfb ;
						}

						UNTAGT (a_tfp) ;
						dispat (vlin, vcol,	a_tfp->fd_nam, curwid, VENORM) ;

						if (retot)
							frescrn (UDTOTS, dp, NOFID) ;
/*
 *						:::::::::::::::::::::::::::::::::::::::::::::
 *						::	+ free info , adjust lists (if so)	   ::
 *						:::::::::::::::::::::::::::::::::::::::::::::
 */
						if (fwflgs & FWPAN) {
							/*
							 *	+ u/d parent's (backlink _dir's) fil by lix .
							 */
							emx = tmplix /* (int)(a_tfp->fd_lix) */ ;
							emlp = xdp->dd_fil ; emlp += emx ;
							while (emx++ < xdp->dd_fik) {
								*emlp = *(emlp+1) ; (*emlp)->fd_lix -= 1 ;
								++emlp ;
							}
							/*
							 *	+ idem 4 mfl by mix or by seq lin srch .
							 */
# ifdef OLDTRIX
							emx = (int)(a_tfp->fd_mix) ;
							emlp = xdp->dd_mfl ; emlp += emx ;
							while (emx++ < xdp->dd_mfk) {
								*emlp = *(emlp+1) ; (*emlp)->fd_mix -= 1 ;
								++emlp ;
							}
# else  /* GUARANTEED */
							emx = 0 ; emlp = xdp->dd_mfl ;
							while (emx < xdp->dd_mfk) {
								if (*emlp == a_tfp)
									break ;
								++emlp ; ++emx ;
							}
							if (*emlp != a_tfp) {
								trixerr ("* ERRO INTERNO # 5 !", NOSTR, NOWHY, FATAL) ;
							}
							while (emx < xdp->dd_mfk) {
								*emlp = *(emlp+1) ;
								++emlp ; ++emx ;
							}
# endif /* OLDTRIX */
/*
 *							:::::::::::::::::::::::::::::::::::::::::::::
 *							::	+ loged dest & overmove care		   ::
 *							:::::::::::::::::::::::::::::::::::::::::::::
 */
							if (logedest) {
								if (overmove) {
									/*
									 *	@ substitute fildat on gpan's
									 *	(dp's) twin (dest) entries ...
									 */
									emx = 0 ; emlp = dp->dd_fil ;
									while ( emx < (1+(dp->dd_fik)) ) {
										if (*emlp == destfilv)
											break ;
										++emx ; ++emlp ;
									}
									if (*emlp != destfilv) {
										trixerr ("* ERRO INTERNO # 18 !", NOSTR, NOWHY, FATAL) ;
									}
									emx = (int) ((*emlp)->fd_gix) ;
									*emlp = a_tfp ;
									tmpgix = a_tfp->fd_gix ;
									a_tfp->fd_gix = emx ;

									emx = 0 ; emlp = dp->dd_mfl ;
									while (emx < xmfk) {
										if (*emlp == destmflv)
											break ;
										++emx ; ++emlp ;
									}
									if (*emlp != destmflv) {
										xwhy = "**** ERRO INTERNO # 19 ****" ;
										epilog () ;
									}
									*emlp = a_tfp ;
									dp->dd_fik += 1    ; dp->dd_mfk += 1    ;
									dp->dd_fib += xmfb ; dp->dd_mfb += xmfb ;
									/* tmx = (int) (tmlp - xmfl) ; */
								} else {
									tmx = (int) (tmlp - xmfl) ;
									goto eodms ;
								} /* endif (overmove) */
							} /* endif (logedest) */
/*
 *							:::::::::::::::::::::::::::::::::::::::::::::
 *							::	+ u/d gpan's (dp's) fil by gix		   ::
 *							:::::::::::::::::::::::::::::::::::::::::::::
 */
							if (! overmove)
								emx = (int) (a_tfp->fd_gix) ;
							else
								emx = (int) tmpgix ;

							if (logedest == FALSE) {
								free ( (char *) (a_tfp->fd_path) ) ;
								free ( (char *) a_tfp ) ;
							}

							emlp = dp->dd_fil ; emlp += emx ;
							while (emx++ < dp->dd_fik) {
								*emlp = *(emlp+1) ; (*emlp)->fd_gix -= 1 ;
								++emlp ;
							}
							/*
							 *	+ idem 4 mfl by tmlp .
							 */
							tmlp = a_emlp ;
							if ( (tmx = emx = (int)(tmlp - xmfl)) < xmfk ) {
								emlp = tmlp ; upyego = FALSE ;
								while (emx++ < xmfk)
									{ *emlp = *(emlp+1) ; ++emlp ; }
							} else {
								dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
								upyego = TRUE ;
							}
						} else {
							emx = tmplix /* (int)(a_tfp->fd_lix) */ ;

							if (! logedest) {
								free ( (char *) (a_tfp->fd_path) ) ;
								free ( (char *) a_tfp ) ;
							}

							emlp = dp->dd_fil ; emlp += emx ;
							while (emx++ < dp->dd_fik) {
								*emlp = *(emlp+1) ; (*emlp)->fd_lix -= 1 ;
								++emlp ;
							}
							tmlp = a_emlp ;
							if ( (tmx = emx = (int)(tmlp - xmfl)) < xmfk ) {
								emlp = tmlp ; upyego = FALSE ;
								while (emx++ < xmfk)
									{ *emlp = *(emlp+1) ; ++emlp ; }
							} else {
								dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
								upyego = TRUE ;
							}
						}
eodms :
						if ( xmfk == 0 ) /* return if last file ... */
							goto bye ;

						if (upyego)
							goto cpu ;	/* PROVISORY ! (MUSTAY) */

						if (key == CTRL_O && fwflgs & FWPAN)
							if (logedest)
								if (overmove == FALSE)
									goto pgdny ;
/*
 *						|===========================|
 *						|	re-list to e-o-page...	|
 *						|===========================|
 */
						emx = topx + elmspg ; emlp = xmfl + tmx ;
						for ( ; tmx < emx ; ++tmx , ++emlp ) {
							if (tmx < xmfk) {
								tfp = *emlp ; tatr = VENORM ;
								if (TAGGED (tfp))
									tatr = VEHILT ;
								dispat (vlin, vcol, FWTNAM, curwid, tatr) ;
							} else {
								dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
								break ;
							}
							if (++vlin == maxlin)
								{ vlin = fwlofs ; vcol += dcolwid ; }
						}
					} else { /* skip untaged files */
pgdny :	/* advc pg ctrl carefully */
						if (++tlin == fwlins) {
							tlin = 0 ;
							if (++tcol == ficols) {
								tcol = 0 ; pgon = FALSE ;
								topx += elmspg ;
							}
						}
						++a_emlp ; ++a_tmx ;
					} /* endif (tagged or not) */
				} /* endof for (anytagged) */
				/*------------------------------------------------------*
				 *	+ some restores & updates ...						*
				 *------------------------------------------------------*/
				frescrn (UDMNUS, NODID, NOFID) ;
				goto cpu ;	/* PROVISORY ! MUST STAY ! */
# ifdef COMMENT
				tlin = a_tlin ;
				tcol = a_tcol ;
				topx = a_topx ;
				tmlp = a_emlp ;
				mustay = recawc = TRUE ;
			break ; /* endof ^Del all tagged 1s ... */
# endif /* COMMENT */
/*			 _______________________________________________________
 *			|														|
 *			|	+ protect all tagged files ...						|
 *			|_______________________________________________________|
 */
			case CMD_SECTAG :
			case CTRL_P :

				if (dp->dd_tfk < 1) {
ntp :				break ;
                }
				grd = proted (NOFID, NODID, 'f') ;

				rescreen (dp, tfp) ;
				recawc = mustay = TRUE ;
				clrfw = FALSE ;

				if (grd != 0)
					goto retopg ;
/*
 *              |===========================================|
 *              |   redraw curr page ...                    |
 *              |===========================================|
 */
                a_tlin = vlin ; a_tcol = vcol ; a_tfp = tfp ;
				vlin = fwlofs ; vcol = fwcofs ; tmx = topx ;
				emx = topx + elmspg ; emlp = xmfl + tmx ;
				for ( ; tmx < emx ; ++tmx , ++emlp ) {
					if (tmx < xmfk) {
						tfp = *emlp ; tatr = VENORM ;
						if (TAGGED (tfp))
							tatr = VEHILT ;
						dispat (vlin, vcol, FWTNAM, curwid, tatr) ;
					} else {
						dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
						break ;
					}
					if (++vlin == maxlin)
						{ vlin = fwlofs ; vcol += dcolwid ; }
				}
    			dispat (a_tlin, a_tcol, curnam, curwid, VEREVS) ;
                vlin = a_tlin ; vcol = a_tcol ; tfp = a_tfp ;
/*
 *              |===========================================|
 *              |   chk 4 confirms ...                      |
 *              |===========================================|
 */
				ghelpt = T_PROTSEL ;
				grd = askyn (T_PROTSEL, T_CHKB4PROT) ;
				ghelpt = NOSTR ;

				switch (grd) {
					case CTRL_Q :
					case ESC   : goto ntp ;
					case NOPE  : tmpflg = 0 ; break ;
					case ENTER :
					case YEAH  : tmpflg = CONFLG ; break ;
				}
				/*------------------------------------------------------*
				 *	+ some initializations & backups ...				*
				 *------------------------------------------------------*/
				pgon = FALSE ;

				if (topx == 0)
					pgon = TRUE ;

				a_tmx = 0 ;
				a_emlp = xmfl ;
				topx = tlin = tcol = 0 ;
				/*------------------------------------------------------*
				 *	+ loop scanning & processing tagged files ...		*
				 *------------------------------------------------------*/
				for ( ; ; ) {
					if (xmfk == 0) /* no more files 2 del ! */
						break ;
					if (a_tmx >= xmfk) /* don't go beyond e-o-lst ! */
						break ;
					a_tfp = *a_emlp ;

					if (TAGGED (a_tfp)) {
						if (pgon == FALSE) {	/* disp curr pag */
							for (vlin = fwlofs ; vlin < maxlin ; ++vlin)
								dispat (vlin, fwcofs,
										NOSTR, fwlinwid, VENORM) ;
							vlin = fwlofs ; vcol = fwcofs ; tmx = topx ;
							emx = topx + elmspg ; emlp = xmfl + tmx ;
							for ( ; tmx < emx ; ++tmx , ++emlp ) {
								if (tmx < xmfk) {
									tfp = *emlp ; tatr = VENORM ;
									if (TAGGED (tfp))
										tatr = VEHILT ;
									dispat (vlin, vcol, FWTNAM, curwid, tatr) ;
								} else {
									dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
									break ;
								}
								if (++vlin == maxlin)
									{ vlin = fwlofs ; vcol += dcolwid ; }
							}
							pgon = TRUE ;
						}
						vcol = tcol * dcolwid + fwcofs ;
						vlin = tlin + fwlofs ; curnam = a_tfp->fd_nam ;
						dispat (vlin, vcol,	curnam, curwid, VEBLNK) ;
						frescrn (UDCURF|UDSTATUS, NODID, a_tfp) ;
						if (fwflgs & FWPAN)
							dispat (_lpath, wpathdr,
									a_tfp->fd_dir->dd_path,
									wpathnam, VEHILT) ;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
						grd = protfil ( a_tfp , gprot , tmpflg ,
										NODID , 'f' ) ;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
						tatr = VENORM ;
						if (TAGGED (a_tfp))
							tatr = VEHILT ;
						dispat (vlin, vcol,	curnam, curwid, tatr) ;
						if (grd == ESC)
							goto cpu ;	/* PROVISORY ! MUST STAY ! */
					}

					if (++tlin == fwlins) {
						tlin = 0 ;
						if (++tcol == ficols) {
							tcol = 0 ; pgon = FALSE ;
							topx += elmspg ;
						}
					}

					++a_emlp ; ++a_tmx ;

				} /* endof for (anytagged) */

				gprot = 0 ;
				goto cpu ;	/* PROVISORY ! MUST STAY ! */

		/*	break ;	*/	/* endof ^Protect all tagged 1s ... */
/*			 ___________________________________________________________
 *			|															|
 *			|	+ ctrl-cmd submenu bars ...								|
 *			|___________________________________________________________|
 */
			case '^' :
			case KF9 :
				if (dp->dd_tfk < 1)
					break ;
				xfmb = 'a' ;
				frescrn (CLRMNUS, NODID, NOFID) ;
				dispat (_msglin, 0, T_CTLCMDS, 80, VEHILT) ;
				dispat (_msglin+1, 0, T_CTLMNU, 80, VEHILT) ;
gcc :			grd = getkey () ;
				switch (grd) {
					case 'd'  :
					case 'D'  : key = CTRL_D ; goto kyt ;
					case 'm'  :
					case 'M'  : key = CTRL_O ; goto kyt ;
					case CTRL_Q :
					case ESC  : frescrn (UDMNUS, NODID, NOFID) ;
						break ;
					case '?'  :
					case KF1  : hyxhelp ("ctlcmds") ; goto gcc ;
					default   : honk () ; goto gcc ;
				}
			break ;
/*
 *			|-------------------------------------------------------|
 *			|	HELP !												|
 *			|-------------------------------------------------------|
 */
			case '?' :
			case KF1 :
				hyxhelp ("filcmd") ;
			break ;
			/*----------------------------------------------------------*
			 *	host operating system shell (with trix shell tricks !)	*
			 *----------------------------------------------------------*/
			case CMD_XSHELL :
			case '!' :
			case KF2 :
				if (trixshel () == -1)
					break ;
				rescreen (dp, tfp) ; /* full screen refresh ... */
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
/*
 *			|-------------------------------------------------------|
 *			|	switch frame style ...								|
 *			|-------------------------------------------------------|
 */
			case CMD_SWFRAM :
			case '+' :
				switfram () ;
rff :			frescrn (REFRAME, NODID, NOFID) ;
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
# ifdef BIGTRX
/*
 *			|-------------------------------------------------------|
 *			|	flip big name justification ...						|
 *			|-------------------------------------------------------|
 */
			case CMD_FLPBNJ :
			case ':' :
				bignamjus = ! bignamjus ;
				frescrn (UDCURF/*|UDSTATUS*/, NODID, tfp) ;
/* really?
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
*/
			break ;
# endif /* BIGTRX */
/*			 ___________________________________________________________
 *			|															|
 *			|	+ trix menus ...										|
 *			|___________________________________________________________|
 */
			case '#' :
			case KF10 :

				dispat (vlin, vcol, curnam, curwid, VEREVS) ;

				mmval = -1 ;

				if (bigfw == 'b')
					grd = runmenu ( & bfwmenu , -1 , -1 ) ;
				else
					grd = runmenu ( & auxmenu , -1 , -1 ) ;

				dispat (vlin, vcol, curnam, curwid, VENORM) ;

                goto rff ;
/*										 ___________________________
 *										|							|
 *										|	+ run current file ...	|
 *										|___________________________|
 */
			case CMD_EXEFIL :
			case 'x' :
			case 'X' :
				if (trixexec (tfp) == -1)
                    break ;
				rescreen (dp, tfp) ; /* full screen refresh ... */
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
/*
 *			|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *			|	+ run application passing tagged files as parm ...	|
 *			|_______________________________________________________|
 */
			case CMD_EXETAG :
			case CTRL_X :
				xp = exetag () ;

				if (xp == NOSTR)
					break ;

				CLRSCR ;
				chtermod ('s') ;
				/*------------------------------------------------------*
				 *	+ some initializations & backups ...				*
				 *------------------------------------------------------*/
				pgon = FALSE ;

				if (topx == 0)
					pgon = TRUE ;

				a_tmx = 0 ;
				a_emlp = xmfl ;
				topx = tlin = tcol = 0 ;
				/*------------------------------------------------------*
				 *	+ loop scanning & processing tagged files ...		*
				 *------------------------------------------------------*/
				for ( ; ; ) {
					if (xmfk == 0) /* no more files 2 del ! */
						break ;
					if (a_tmx >= xmfk) /* don't go beyond e-o-lst ! */
						break ;
					a_tfp = *a_emlp ;

					if (TAGGED (a_tfp)) {
# ifdef COMMENT
						if (pgon == FALSE) {	/* disp curr pag */
							for (vlin = fwlofs ; vlin < maxlin ; ++vlin)
								dispat (vlin, fwcofs,
										NOSTR, fwlinwid, VENORM) ;
							vlin = fwlofs ; vcol = fwcofs ; tmx = topx ;
							emx = topx + elmspg ; emlp = xmfl + tmx ;
							for ( ; tmx < emx ; ++tmx , ++emlp ) {
								if (tmx < xmfk) {
									tfp = *emlp ; tatr = VENORM ;
									if (TAGGED (tfp))
										tatr = VEHILT ;
									dispat (vlin, vcol, FWTNAM, curwid, tatr) ;
								} else {
									dispat (vlin, vcol, NOSTR, curwid, VENORM) ;
									break ;
								}
								if (++vlin == maxlin)
									{ vlin = fwlofs ; vcol += dcolwid ; }
							}
							pgon = TRUE ;
						}
						vcol = tcol * dcolwid + fwcofs ;
						vlin = tlin + fwlofs ; curnam = a_tfp->fd_nam ;
						dispat (vlin, vcol,	curnam, curwid, VEBLNK) ;
						frescrn (UDCURF|UDSTATUS, NODID, a_tfp) ;
						if (fwflgs & FWPAN)
							dispat (_lpath, wpathdr,
									a_tfp->fd_dir->dd_path,
									wpathnam, VEHILT) ;
# endif /* COMMENT */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
						grd = runtag ( a_tfp , xp ) ;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
# ifdef COMMENT
						tatr = VENORM ;
						if (TAGGED (a_tfp))
							tatr = VEHILT ;
						dispat (vlin, vcol,	curnam, curwid, tatr) ;
# endif /* COMMENT */
						if (grd == ESC)
							goto cpu ;	/* PROVISORY ! MUST STAY ! */
					} /* endif (tagged) */
/*
					if (++tlin == fwlins) {
						tlin = 0 ;
						if (++tcol == ficols) {
							tcol = 0 ; pgon = FALSE ;
							topx += elmspg ;
						}
					}
*/
					++a_emlp ; ++a_tmx ;

				} /* endof for (anytagged) */

				chtermod ('w') ;
				dispat (23, 0, T_SHKRTN, 79, VEREVS) ; getkey () ;

				rescreen (dp, tfp) ; /* full screen refresh ... */
# ifdef FIXLATER
				recawc = mustay = TRUE ;
				clrfw = FALSE ;
				goto retopg ;
# else  /* SOLVENOW */
				goto cpu ;
# endif /* FIXLATER */
			/*______________________________________________________
			 *	...
			 */
			default :
/* badky : */
				honk () ;
			break ;
		} /* endof switch key */
	} /* endof 4 evr */
eofw :
	dispat (_lfilnam, _cfilnam, NOSTR, _wfilnam, VENORM) ;
	fliptot ('g') ;
	flipcur ('d') ;
	flipcmb ('d') ;
	flipfmb ('d') ;
	frescrn (DYNHDRS|CMNUBAR|FMNUBAR, NODID, NOFID) ;
	return bigfw ;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/*
 * vi:nu tabstop=4
 */
