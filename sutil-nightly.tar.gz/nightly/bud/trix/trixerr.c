/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|-------------------------------------------------------|
 *		|	trixerr.c + crap treatment & evasive maneuvers ...	|
 *		|-------------------------------------------------------|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre Victor Rodrigues Botao (1991)				|
 *		|_______________________________________________________|
 */

# include	<stdio.h>
# include	<string.h>

# include	"trix.h"
# include	"trixstd.h"
# include	"trixblue.h"
# include	"trixkeys.h"
# include	"trixfunc.h"
# include	"trixext.h"
# include	"trixtext.h"
# include	"trixasci.h"
# include	"trixwig.h"

EXT int    xfmb ;
EXT char * ghelpt ;
EXT ERRINF errdat [] ;

/*
 *	|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
 *	|	trixerr : someone always do ...								|
 *	|																|
 *	|	+ should use bsearch() instead of seq lin srch ...			|
 *	|	+ the list should go in a sep file ("trixerrs.dat") ...		|
 *	|_______________________________________________________________|
 */

int trixerr (msgtxt, optxt, errcod, flgs) char * msgtxt, * optxt ; int errcod, flgs ; {
	char tb [100] ;
	char * hp = NULL ;
	REG char * mp = msgtxt ;
	REG ERRINF * ep ;
	REG int found ;
	int whatever ;

	if (optxt != NOSTR)
		sprintf (tb, mp, optxt) ;
	else
		strcpy (tb, mp) ;

	if (flgs & FATAL)
		xfmb = 'e' ;
	else
		xfmb = 'o' ;

	frescrn (CLRMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;
	honk () ; dispat (_lcmb1, 0, tb, strlen (tb), VEHILT) ;

	if (errcod >= 0) {
		found = FALSE ; /* MUST USE BSEARCH ! ! ! ! */
		for ( ep = errdat ; ep->ei_why != VZRO (char *) ; ++ep )
			if (ep->ei_cod == errcod) {
				found = TRUE ;
				break ;
			}
		if (found) {
			sprintf (tb, "* (%s)", ep->ei_why) ;
			hp = ep->ei_why ;
		} else {
# ifdef ORIG
			sprintf (tb, T_SYSERR, OPSYS, xerrno, sys_errlist[xerrno]) ;
			hp = (char *) sys_errlist[xerrno] ;
# else
			sprintf (tb, T_SYSERR, OPSYS, xerrno, strerror(xerrno)) ;
			hp = (char *) strerror(xerrno) ;
# endif
		}
		dispat (_lcmb2, 0, tb, strlen (tb), VEHILT) ;
	}
	honk () ;
it :
	whatever = getkey () ;

	switch (whatever) {
		case '\r' :
		case '\n' : whatever = ENTER ;
		case CTRL_Q :
		case ESC  :	break ;
		case '?'  :
		case KF1  : ghelpt = NOSTR ; hyxhelp (hp) ; goto it ;
		default   : honk () ; goto it ;
	}

	frescrn (UDMNUS, VZRO (DIRDAT *), VZRO (FILDAT *)) ;

	if (flgs & FATAL)
		epilog () ;

	return whatever ;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/*
 * vi:nu ts=4
 */
