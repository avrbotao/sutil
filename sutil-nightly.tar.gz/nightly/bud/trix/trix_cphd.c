/* dup high-density diskette ... */

# include <stdlib.h>
# include <string.h>
# include <stdio.h>
# include <ctype.h>
# include <fcntl.h>
# include <conio.h>
# include <dos.h>
# include <io.h>

void main (argc, argv) char * * argv ; {
	char * buf , * cmp ;
	char * nam ;
	int drvno ;				/* driver letter / number	*/
	int bysect = 512 ;		/* bytes per sector			*/
	int sectrk ;			/* sectors per track		*/
	int totrk ;				/* total number of tracks	*/
	int totsec ;			/* total number of sectors	*/
	int sectno ;			/* logical sector number	*/
	int trkno ;
	int trksiz ;
	int verify ;
	FILE * fp ;

	printf ("\ncphd 1.0 (c) 1992 alexandre v. r. botao (021) 230-2873\n") ;
	if (argc != 6) {
		printf ("\nuse: cphd <drive> <sectors/track> ") ;
		printf ("<cylinders> <tempfile> <v|n>\n") ;
		return ;
	}
	drvno = toupper (*(*(argv+1))) - 'A' ;
	sectrk = 2 * (atoi (*(argv+2))) ;
	totrk = atoi (*(argv+3)) ;
	nam = *(argv+4) ;
	verify = tolower (*(*(argv+5))) ;
	trksiz = sectrk * bysect ;
	if ((buf = malloc (trksiz)) == NULL) {
		printf ("\ncphd: no memory 4 transfer buffer\n") ;
		return ;
	}
	totsec = sectrk * totrk ;
	if ((fp = fopen (nam, "wb")) == NULL) {
		printf ("\ncphd: can't create %s\n", nam) ;
		return ;
	}
	printf ("\ninsert source disk on drive %c and press [Enter] ", drvno+'a') ;
	while (getch () != '\r')
		;
	printf ("\n\n") ;
	trkno = 0 ;
	for ( sectno = 0 ; sectno < totsec ; ++trkno , sectno += sectrk ) {
		printf ("track # %2d (sector # %4d) ... ",
				trkno, sectno) ;
		if (absread (drvno, sectrk, sectno, buf) < 0)
			printf ("READ ERROR\n") ;
		else
			printf ("READ OK\r") ;
		fwrite (buf, trksiz, 1, fp) ;
	}
	fclose (fp) ;
	if ((cmp = malloc (trksiz)) == NULL) {
		printf ("\ncphd: no memory 4 verify buffer\n") ;
		return ;
	}
	if ((fp = fopen (nam, "rb")) == NULL) {
		printf ("\ncphd: can't read %s\n", nam) ;
		return ;
	}
	printf ("insert target disk on drive %c and press [Enter] ", drvno+'a') ;
	while (getch () != '\r')
		;
	printf ("\n\n") ;
	trkno = 0 ;
	for ( sectno = 0 ; sectno < totsec ; ++trkno , sectno += sectrk ) {
		printf ("track # %2d (sector # %4d) ... ",
				trkno, sectno) ;
		if (fread (buf, trksiz, 1, fp) != 1) {
			printf ("COPY ERROR on %s\n", nam) ;
			continue ;
		}
		if (abswrite (drvno, sectrk, sectno, buf) < 0) {
			printf ("WRITE ERROR\n") ;
			continue ;
		}
		if (verify == 'v') {
			if (absread (drvno, sectrk, sectno, cmp) < 0) {
				printf ("READ ERROR on VERIFY\n") ;
				continue ;
			}
			if (memcmp (buf, cmp, trksiz) != 0) {
				printf ("VERIFY ERROR\n") ;
				continue ;
			}
		}
		printf ("WRITTEN OK\r") ;
	}
	printf ("cphd 1.0 (c) 1992 alexandre v. r. botao (021) 230-2873\n") ;
	fclose (fp) ;
}
