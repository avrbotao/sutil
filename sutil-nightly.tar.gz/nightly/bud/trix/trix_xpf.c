
/*
 *	keyboard (keypad) sense test
 */

# include <stdio.h>
# include <signal.h>
# include <fcntl.h>
# include <errno.h>
# include <sys/termio.h>

struct termio orig , work ;
char * swid = "xpf" ;
int tfd ;
int fc_ant = -4 ;
int ndelay = 0 ;

# ifdef ANSI
char * keynam (char *) ;
# else  /* OLD */
char * keynam ( ) ;
# endif /* ANSI */

# ifdef HPUX
# define FIORDCHK FIONREAD
# endif /* HPUX */

# define RETRYCOUNT	10

main (argc, argv) char * * argv ; {
	int x ;
	int y ;
	int i ;
	int g ;
	int r ;
	int rd ;
	int en ;
	int retrycount = RETRYCOUNT ;
	char b [ 40 ] ;
	char * p = b ;
	char * kid ;

	printf ("\nxpf 1.0 (c) 1993 Alexandre V. R. Botao\n\n") ;

	signal (SIGINT, SIG_IGN) ;
	signal (SIGQUIT, SIG_IGN) ;

	if ( ( tfd = open ("/dev/tty", 2) ) < 0 ) {
		perror ("xpf/opntty") ;
		exit (1) ;
	}
	if ( ioctl (tfd, TCGETA, &orig) < 0 ) {
		perror ("xpf/tcgeta") ;
		exit (1) ;
	}

	work = orig ;
	work.c_cc [ VMIN  ] = 1 /*0*/ ;
	work.c_cc [ VINTR ] = '\0' ;
	work.c_cc [ VQUIT ] = '\0' ;
# ifdef ORIGCODE
	work.c_lflag &= ~ ( ICANON | ECHO  ) ;
	work.c_iflag &= ~ ( IGNCR  | ICRNL | IXON | IXANY | IXOFF ) ;
# else  /* FULLCODE */
	work.c_cc [ VTIME ] = 0 /*1*/ ;
    work.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|INLCR|IGNCR|ICRNL|IXON/*|IXANY|IXOFF*/) ;
    work.c_oflag &= ~(OPOST/*|OXTABS*/) ;
    work.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN) ;
	work.c_iflag &= ~ISTRIP ;
	work.c_cflag &= ~(CSIZE|PARENB) ;
	work.c_cflag |= CS8 ;
# endif /* ORIGCODE */

	if ( ioctl (tfd, TCSETA, &work) < 0 ) {
		perror ("xpf/tcseta") ;
		goto rok ;
	}
	for ( ; ; ) {
		i = 0 ;
		r = read (tfd, p+i, 1) ;

		if (r <= 0) {
			if (ndelay == 0) {
				perror ("xpf/r<=0&nd==0") ;
				goto rok ;
			}
		}
		y = *(p+i) ;

		if (y == 27) {

# ifdef NOFIORK

			/* 1st : unblock reads */

			if (fc_ant == -4) {
				rd = fc_ant = fcntl (tfd, F_GETFL, 0) ;
				if ( rd < 0 )
					perror ("xpf/fct.gfl") ;
				rd = fcntl (tfd, F_SETFL, fc_ant | O_NDELAY | O_NONBLOCK) ;
				if ( rd < 0 )
					perror ("xpf/fct.sfl.ndl") ;
				ndelay = 1 ;
			}

			/* 2nd : try and read anything */
gmc :
			++i ;
			r = read (tfd, p+i, 1) ; en = errno ;

			if (r == 0) {

				/* 3rd : reblock reads */

				if (fc_ant != -4) {
					fcntl (tfd, F_SETFL, fc_ant) ;
					fc_ant = -4 ;
					ndelay = 0 ;
				}

				--i ;

				if ( i > 0 )
					goto pem ;

				goto poc ;
			}

			if (r < 0) {
					perror ("xpf/r<0") ;
					/* fprintf (stderr, "errno=(%d)\n", en) ; */
					if ( en == EAGAIN ) {
						if (--retrycount > 0)
							goto gmc ;
					}
					retrycount = RETRYCOUNT ;
					goto rok ;
			}

			goto gmc ;

# else  /* FIORK */

gmc :		/* get more chars ... */

# ifdef HPUX
			g = ioctl (tfd, FIORDCHK, &g) ;
# else  /* ! HPUX */
#	ifdef CYGWIN
			rd = ioctl (tfd, TIOCINQ, &g) ;
			if ( rd < 0)
				g = 0 ;
#	else  /* ! CYGWIN */
			g = ioctl (tfd, FIORDCHK, NULL) ;
#	endif /* CYGWIN */
# endif /* HPUX */
			if (g < 0) {
				perror ("xpf/g<0") ;
				goto rok ;
			}
			if (g == 0) {
				if ( i > 0 )
					goto pem ;
				goto poc ;
			}
			++i ;
			r = read (tfd, p+i, 1) ;

			if (r <= 0) {
				if (ndelay == 0) {
					perror ("xpf/r<=0&nd==0") ;
					goto rok ;
				}
			}

			goto gmc ;		/* go get more chars ... */

# endif /* NOFIORK */

pem :		/* print'em ... */

			printf ("\n") ;

			b[i+1] = '\0' ;
			kid = keynam (b) ;

			if (kid != (char *) 0)
				printf ("\t+ %s\n\n", kid) ;
			for ( r = 0 ; r <= i ; ++r ) {
				x = b[r] ;
				printf ("\t+ %02x %03o %3d '%c'\n", x, x, x,
						x >= 32 && x <= 126 ? x : '?') ;
			}
			printf ("\n") ;
			continue ;
		}
poc :
		x = y ;
		printf (". %02x %03o %3d '%c'\n", x, x, x,
			x >= 32 && x <= 126 ? x : '?') ;
		if (x == '~')
			break ;
		if (x == '&') { /* liga no-delay ... */
			if (fc_ant == -4)
				fc_ant = fcntl (tfd, F_GETFL, 0) ;
			fcntl (tfd, F_SETFL, fc_ant | O_NDELAY) ;
			ndelay = 1 ;
		}
		if (x == '#') { /* desliga no-delay ... */
			if (fc_ant != -4)
				fcntl (tfd, F_SETFL, fc_ant) ;
			fc_ant = -4 ;
			ndelay = 0 ;
		}
	}
rok :
	if ( ioctl (tfd, TCSETA, &orig) < 0 ) {
		perror ("xpf/tcseta") ;
		exit (1) ;
	}
}

struct keyinfo {
	char * ki_nam ;		/* identification	*/
	char * ki_sig ;		/* signature	*/
} ;
typedef  struct keyinfo  KEYINFO ;

KEYINFO trixkeys [] = {
	{ "F1",		"\033[M"	} ,
	{ "F2",		"\033[N"	} ,
	{ "F3",		"\033[O"	} ,
	{ "F4",		"\033[P"	} ,
	{ "F5",		"\033[Q"	} ,
	{ "F6",		"\033[R"	} ,
	{ "F7",		"\033[S"	} ,
	{ "F8",		"\033[T"	} ,
	{ "F9",		"\033[U"	} ,
	{ "F10",	"\033[V"	} ,
	{ "F11",	"\033[W"	} ,
	{ "F12",	"\033[X"	} ,
	{ "Home",	"\033[H"	} ,
	{ "End",	"\033[F"	} ,
	{ "PgUp",	"\033[I"	} ,
	{ "PgDn",	"\033[G"	} ,
	{ "Up",		"\033[A"	} ,
	{ "Down",	"\033[B"	} ,
	{ "Left",	"\033[D"	} ,
	{ "Right",	"\033[C"	} ,
	{ "Esc",	"\033"		} ,
	{ (char *) 0,	(char *) 0	}
} ;

char * keynam (s) char * s ; {
# ifdef BSRCH
	/*	+---------------------------+
	 *	|	fast binary search ...	|
	 *	+---------------------------+
	 */

	...

# else  /* SEQ SEARCH */
	register KEYINFO * kip = trixkeys ;
	register int found = 0 ;

	for ( ; kip->ki_nam ; ++kip )
		if (strcmp (kip->ki_sig, s) == 0) {
			found = 1 ;
			break ;
		}
	if (found)
		return kip->ki_nam ;
	return (char *) 0 ;
# endif /* BSRCH */
}
# ifdef COMMENT
/*
 *	teste de bsearch() ...
 */

# include <stdio.h>
# include <stdlib.h>

double quem ;

struct categ {
	int			cat_cod ;
	char *	cat_tit ;
} ;
typedef		struct categ		CATEG ;

CATEG	* ptabcat ;

CATEG		tabbas [] = {			/* a propria tabela de categorias ...					*/
	{    1, "Masculino" } ,
	{    2, "Feminino" } ,
	{    1, "Janeiro" } ,
	{    2, "Fevereiro" } ,
	{    3, "Marco" } ,
	{    4, "Abril" } ,
	{    5, "Maio" } ,
	{    6, "Junho" } ,
	{    7, "Julho" } ,
	{    8, "Agosto" } ,
	{    9, "Setembro" } ,
	{   10, "Outubro" } ,
	{   11, "Novembro" } ,
	{   12, "Dezembro" } ,
	{    1, "Solteira" } ,
	{    2, "Casada" } ,
	{    3, "Viuva" } ,
	{    4, "Tico-Tico-no-Fuba" } ,
	{ 9999, "sei la ..." } ,
	{	  -1, NULL } /* reservado para "fim-da-lista" ... */
} ;

int catcmp (void *, void *) ;

void main () {
	CATEG * res ;
	CATEG tst ;

	printf ("quem ? ") ;
	scanf ("%lf", &quem) ;
	tst.cat_cod = (int) quem ;

	ptabcat = tabbas ;
	res = (CATEG *) bsearch ( (void *) &tst , (void *) (ptabcat + 2) ,
									(size_t) 12 , (size_t) sizeof (CATEG) , catcmp ) ;
	if (res == (CATEG *) 0)
		printf ("categoria (%d) nao encontrada !\n", tst.cat_cod) ;
	else
		printf ("categoria (%d) = [%s] !\n", res->cat_cod, res->cat_tit) ;
}

int catcmp (a, b) void * a , * b ; {
	register CATEG * pa = (CATEG *) a ;
	register CATEG * pb = (CATEG *) b ;

	return pa->cat_cod - pb->cat_cod ;
}
# endif /* COMMENT */
/*
 * vi:tabstop=4
 */
