
# define	BACVERSION		"1.6.98"

# define	SWVRSNO     	BACVERSION		/*	trix version	*/

# define	VRSNTIM			"2015.08.14"

/*
 * vi:nu tabstop=4
 */
