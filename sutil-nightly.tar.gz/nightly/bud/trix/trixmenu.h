/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixmenu.h + stuff 4 well-tempered menus ...		|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre V.R. Botao                       (1991)	|
 *		|_______________________________________________________|
 */
# define	MM_BAR		0x0001
# define	MM_BOX		0x0002

# define	MI_MNU		0x0001

typedef		struct menuctl	MENUCTL		;
typedef		struct menuit	MENUIT		;
typedef		int				(*FUNP) ()	;

# define    NOCMD       ( (char *)		0 )
# define    NOFUN       ( (FUNP)		0 )
# define    NOMNU       ( (MENUCTL *)	0 )

struct menuit {
	int			mi_flg	;
	int			mi_lin	;
	int			mi_col	;
	int			mi_key	;
	int			mi_val	;
	char *		mi_name	;
	char *		ma_cmd	;
	FUNP		ma_funp	;
	MENUCTL *	ma_menu ;
	char *		mi_help ;
} ;

struct menuctl {
	int			mm_flg	;
	int			mm_lin	;
	int			mm_col	;
	int			mm_wid	;
	int			mm_hei	;
	int			mm_nit	;
	int			mm_lit	;
	MENUIT *	mm_item ;
} ;

# ifdef ANSI

int	runmenu (MENUCTL *, int, int) ;
int	barmenu (MENUCTL *, int, int) ;
int	boxmenu (MENUCTL *, int, int) ;

# else  /* OLD */

int	runmenu ( ) ;
int	barmenu ( ) ;
int	boxmenu ( ) ;

# endif /* ANSI */
