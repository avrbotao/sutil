/*				                     _______________________________
 *									|								|
 *									|	path name dismantler ...	|
 *				                    |_______________________________|
 */

char *	pnd (pn) char *	pn ; {

	static char * pnp = (char *) 0 ;
	static char   buf[512] ;
	static char * bp = buf ;

	if (pnp == (char *) 0)
		pnp = pn ;

	if (*pnp == '\0') {
		pnp = (char *) 0 ;
		bp = buf ;
		return (pnp) ;
	}

	if ((pnp == pn) && (*pnp == '/')) {
		*bp++ = *pnp++ ;
	} else {
		if (*pnp == '/')
			*bp++ = *pnp++ ;
		while (*pnp && *pnp != '/')
			*bp++ = *pnp++ ;
	}

	*bp = '\0' ;
	return (buf) ;
}

