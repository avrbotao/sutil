
/*		 _______________________________________________________
 *		|														|
 *		|	T R I X + directory & file administration utility	|
 *		|_______________________________________________________|
 *		|														|
 *		|	trixwind.h + blessings window package include file	|
 *		|_______________________________________________________|
 *		|														|
 *		|	TRIX & the TRIX logo are registered trademarks of	|
 *		|	Alexandre V.R. Botao                       (1991)	|
 *		|_______________________________________________________|
 */

# ifdef   DOS

#	include <dos.h>
#	include <stdlib.h>
#	include <string.h>

# else    /* ANYX */

# include <fcntl.h>

# ifdef COMMENT /* vstat already done */
# include <sys/machdep.h>
# endif /* COMMENT */

# define  far

# endif   /* DOS */

struct screlm {
	unsigned char se_byte ;
	unsigned char se_attr ;
} ;

typedef  struct screlm  SCRELM ;

# define	MAXSCRELM		524288 /* 262144 131072 */ /* 65536 */ /* 32768 */ /* 16384 */

struct wwinfo {
	int ww_lin ;
	int ww_col ;
	int ww_wid ;
	int ww_hei ;
	int ww_cy ;
	int ww_cx ;
	int ww_atr ;
    int ww_siz ;        /* # of screlms in ww_sav ...           */
	SCRELM * ww_sav ;
} ;

typedef  struct wwinfo  WWINFO ;

extern WWINFO     * stdww  ;
extern SCRELM far * stdweb ;

# ifdef		BIGEFF

# define	WW_NORMAL		0x0000
# define	WW_BLINK		0x0100
# define	WW_REVERSE      0x0200
# define	WW_HIGHLIGHT    0x0400
# define	WW_UNDERLINE    0x0800
# define	WW_ALTCHRSET	0x1000

# else		/* DOSEFF */

# define	WW_NORMAL		VENORM      /* 0x0007 */
# define	WW_BLINK		VEBLNK      /* 0x0087 */
# define	WW_REVERSE      VEREVS      /* 0x0070 */
# define	WW_HIGHLIGHT    VEHILT      /* 0x000f */
# define	WW_UNDERLINE    VEULIN      /* 0x0004 */
# define	WW_ALTCHRSET	VEAGCS      /* 0x0007 */
# define	WW_REVBLINK 	VERVBL      /* 0x00f0 */

# endif		/* BIGEFF */

# define	NOWWP			( VZRO (WWINFO *) )

# ifdef		ANSI

void		wwinit	(void)								;
void		wwend	(void)								;
WWINFO *	wwopen	(int, int, int, int)				;
void		wwfill	(WWINFO *, int, int)				;
void		wwputs	(WWINFO *, char *)					;
void		wwgoyx	(WWINFO *, int, int)				;
void		wwsatr	(WWINFO *, int)						;
void		wwcatr	(WWINFO *, int)						;
void		wwfram	(WWINFO *, int)						;
void		wwputc	(WWINFO *, int)						;
void		wwputq	(WWINFO *, int)						;
void		wwputw	(int, int, SCRELM *)				;
void		wwdisp	(WWINFO *, int, int, char *, int)	;
void		wwupdt	(WWINFO *)							;
void		wweras	(void)								;
void		wwclos	(WWINFO *)							;

# else		/* OLD STYLE */

void		wwinit	( )									;
void		wwend	( )									;
WWINFO *	wwopen	( )									;
void		wwfill	( )									;
void		wwputs	( )									;
void		wwgoyx	( )									;
void		wwsatr	( )									;
void		wwcatr	( )									;
void		wwfram	( )									;
void		wwputc	( )									;
void		wwputq	( )									;
void		wwputw	( )									;
void		wwdisp	( )									;
void		wwupdt	( )									;
void		wweras	( )									;
void		wwclos	( )									;

# endif		/* ANSI */

/*
 * vi:tabstop=4
 */
