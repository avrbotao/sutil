
# include "trix.h"
# include "trixwig.h"

EXT		int			nflg ;

/************************************************************************
*	window-graphy ...													*
*	(1) initialize defaults properly ...								*
*	(2) remapwig() to re-adjust all numbers to new window limits ...	*
************************************************************************/

int _vdolins	= DFL_VDOLINS	;
int _vdocols	= DFL_VDOCOLS	;

int _hlbord		= DFL_HLBORD	;
int _vcbord		= DFL_VCBORD	;

/*
int _cwcofs		= DFL_CWCOFS	;
int _cicofs		= DFL_CICOFS	;
*/

int _msglin		= DFL_MSGLIN	;
int _fwlen		= DFL_FWLEN		;

int _twlins		= DFL_TWLINS	;
int _twlinw		= DFL_TWLINW	;
int _twcofs		= DFL_TWCOFS	;
int _twlofs		= DFL_TWLOFS	;

int _bwcofs		= DFL_BWCOFS	;
int _bwlofs		= DFL_BWLOFS	;
int _bwlins		= DFL_BWLINS	;
int _bwlinw		= DFL_BWLINW	;

int _fwlins		= DFL_FWLINS	;
int _fwlinw		= DFL_FWLINW	;
int _fwcofs		= DFL_FWCOFS	;
int _fwlofs		= DFL_FWLOFS	;

int _lfilnam	= DFL_LFILNAM	;
int _cfilnam	= DFL_CFILNAM	;
int _wfilnam	= DFL_WFILNAM	;
int _lfilsiz	= DFL_LFILSIZ	;
int _cfilsiz	= DFL_CFILSIZ	;

int _lcurfib	= DFL_LCURFIB	;
int _ccurfib	= DFL_CCURFIB	;
int _lcurfik	= DFL_LCURFIK	;
int _ccurfik	= DFL_CCURFIK	;

int _ltotfil	= DFL_LTOTFIL	;
int _ctotfil	= DFL_CTOTFIL	;
int _ltotbyt	= DFL_LTOTBYT	;
int _ctotbyt	= DFL_CTOTBYT	;

int _lmatfil	= DFL_LMATFIL	;
int _cmatfil	= DFL_CMATFIL	;
int _lmatbyt	= DFL_LMATBYT	;
int _cmatbyt	= DFL_CMATBYT	;

int _lselfil	= DFL_LSELFIL	;
int _cselfil	= DFL_CSELFIL	;
int _lselbyt	= DFL_LSELBYT	;
int _cselbyt	= DFL_CSELBYT	;

int _lhtotbyt	= DFL_LHTOTBYT	;
int _chtotbyt	= DFL_CHTOTBYT	;
int _lhtotfil	= DFL_LHTOTFIL	;
int _chtotfil	= DFL_CHTOTFIL	;
int _lhmatbyt	= DFL_LHMATBYT	;
int _chmatbyt	= DFL_CHMATBYT	;
int _lhmatfil	= DFL_LHMATFIL	;
int _chmatfil	= DFL_CHMATFIL	;
int _lhselbyt	= DFL_LHSELBYT	;
int _chselbyt	= DFL_CHSELBYT	;
int _lhselfil	= DFL_LHSELFIL	;
int _chselfil	= DFL_CHSELFIL	;
int _lhdirbyt	= DFL_LHDIRBYT	;
int _chdirbyt	= DFL_CHDIRBYT	;
int _lhdirfil	= DFL_LHDIRFIL	;
int _chdirfil	= DFL_CHDIRFIL	;

int _ltothdr	= DFL_LTOTHDR	;
int _ctothdr	= DFL_CTOTHDR	;

int _lfamhdr	= DFL_LFAMHDR	;
int _cfamhdr	= DFL_CFAMHDR	;
int _lrgxpat	= DFL_LRGXPAT	;
int _crgxpat	= DFL_CRGXPAT	;
int _wrgxpat	= DFL_WRGXPAT	;

int _lselhdr	= DFL_LSELHDR	;
int _cselhdr	= DFL_CSELHDR	;

int _lcurhdr	= DFL_LCURHDR	;
int _ccurhdr	= DFL_CCURHDR	;

int _lprohdr	= DFL_LPROHDR	;
int _cprohdr	= DFL_CPROHDR	;
int _cprotxt	= DFL_CPROTXT	;
int _wprotxt	= DFL_WPROTXT	;

int _lwrthdr	= DFL_LWRTHDR	;
int _cwrthdr	= DFL_CWRTHDR	;
int _cwrtime	= DFL_CWRTIME	;

int _lrdthdr	= DFL_LRDTHDR	;
int _crdthdr	= DFL_CRDTHDR	;
int _crdtime	= DFL_CRDTIME	;

int _lownhdr	= DFL_LOWNHDR	;
int _cownhdr	= DFL_COWNHDR	;
int _cownrid	= DFL_COWNRID	;
int _wownrid	= DFL_WOWNRID	;

int _lgrphdr	= DFL_LGRPHDR	;
int _cgrphdr	= DFL_CGRPHDR	;
int _cgrpnam	= DFL_CGRPNAM	;
int _wgrpnam	= DFL_WGRPNAM	;

int _llnkhdr	= DFL_LLNKHDR	;
int _clnkhdr	= DFL_CLNKHDR	;
int _clnkcnt	= DFL_CLNKCNT	;
int _wlnkcnt	= DFL_WLNKCNT	;

int _ctlofs		= DFL_CTLOFS	;
int _ctcofs		= DFL_CTCOFS	;

int _lpath		= DFL_LPATH		;
int _cpath		= DFL_CPATH		;
int _wpath		= DFL_WPATH		;

int _banlofs	= DFL_BANLOFS	;
int _banlins	= DFL_BANLINS	;

int _lcmb1		= DFL_LCMB1		;
int _ccmb1		= DFL_CCMB1		;
int _lcmb2		= DFL_LCMB2		;
int _ccmb2		= DFL_CCMB2		;

int _lfmb1		= DFL_LFMB1		;
int _cfmb1		= DFL_CFMB1		;
int _lfmb2		= DFL_LFMB2		;
int _cfmb2		= DFL_CFMB2		;

int _lvrsn		= DFL_LVRSN		;
int _cvrsn		= DFL_CVRSN		;
int _lsrno		= DFL_LSRNO		;

int _crnlofs	= DFL_CRNLOFS	;
int _crncofs	= DFL_CRNCOFS	;
int _snilofs	= DFL_SNILOFS	;
int _snicofs	= DFL_SNICOFS	;

int _l_hlpbox	= DFL_L_HLPBOX	;
int _c_hlpbox	= DFL_C_HLPBOX	;
int _hlpwlen	= DFL_HLPWLEN	;
int _hlpwhei	= DFL_HLPWHEI	;

# ifdef BIGTRX
int _botfilnamlin ;					/* bottom file name line		*/
# endif /* BIGTRX */

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

void mapwig () {

	vlinwid		= _vdocols		;

# ifdef BIGTRX
	if ( nflg ) {
		_botfilnamlin = --_vdolins ;
	}
# endif /* BIGTRX */

	_hlbord		= _vdolins - 12 ;
	_vcbord		= _vdocols - 18	;
/*
	_cwcofs		= DFL_CWCOFS	;
	_cicofs		= DFL_CICOFS	;
*/
	_msglin		= _vdolins  - 3 ;
	_fwlen		= DFL_FWLEN		;

	_twlins		= _vdolins - 14 ;
	_twlinw		= _vcbord   - 4 ;
	_twcofs		= DFL_TWCOFS	;
	_twlofs		= DFL_TWLOFS	;

	_bwcofs		= _twcofs		;
	_bwlofs		= _twlofs		;
	_bwlins		= _twlins		;
	_bwlinw		= _vdocols  - 4 ;

	_fwlins		= _twlins		;
	_fwlinw		= DFL_FWLINW	;
	_fwcofs		= _vcbord   + 2 ;
	_fwlofs		= _twlofs		;

	fwcofs		= _fwcofs		;

	_lfilnam	= _vdolins  - 5 ;
	_cfilnam	= DFL_CFILNAM	;
	_wfilnam	= DFL_WFILNAM	;
	_lfilsiz	= _vdolins  - 6 ;
	_cfilsiz	= DFL_CFILSIZ	;

	_lcurfib	= _lfilsiz		;
	_ccurfib	= _cfilsiz		;
	_lcurfik	= _lfilnam		;
	_ccurfik	= DFL_CCURFIK	;

	_ltotfil	= _vdolins  - 9 ;
	_ctotfil	= DFL_CTOTFIL	;
	_ltotbyt	= _vdolins - 10 ;
	_ctotbyt	= DFL_CTOTBYT	;

	_lmatfil	= _ltotfil		;
	_cmatfil	= DFL_CMATFIL	;
	_lmatbyt	= _ltotbyt		;
	_cmatbyt	= DFL_CMATBYT	;

	_lselfil	= _ltotfil		;
	_cselfil	= DFL_CSELFIL	;
	_lselbyt	= _ltotbyt		;
	_cselbyt	= DFL_CSELBYT	;

	_lhtotbyt	= _vdolins - 10 ;
	_chtotbyt	= DFL_CHTOTBYT	;
	_lhtotfil	= _vdolins  - 9 ;
	_chtotfil	= DFL_CHTOTFIL	;
	_lhmatbyt	= _lhtotbyt		;
	_chmatbyt	= DFL_CHMATBYT	;
	_lhmatfil	= _lhtotfil		;
	_chmatfil	= DFL_CHMATFIL	;
	_lhselbyt	= _lhtotbyt		;
	_chselbyt	= DFL_CHSELBYT	;
	_lhselfil	= _lhtotfil		;
	_chselfil	= DFL_CHSELFIL	;

	_lhdirbyt	= _vdolins  - 6 ;
	_chdirbyt	= DFL_CHDIRBYT	;
	_lhdirfil	= _vdolins  - 5 ;
	_chdirfil	= DFL_CHDIRFIL	;

	_ltothdr	= _vdolins - 11 ;
	_ctothdr	= DFL_CTOTHDR	;
	_lfamhdr	= _ltothdr		;
	_cfamhdr	= DFL_CFAMHDR	;
	_lrgxpat	= _ltothdr		;
	_crgxpat	= DFL_CRGXPAT	;
	_wrgxpat	= DFL_WRGXPAT	;

	_lselhdr	= _ltothdr		;
	_cselhdr	= DFL_CSELHDR	;

	_lcurhdr	= _vdolins  - 7 ;
	_ccurhdr	= DFL_CCURHDR	;

	_lprohdr	= _lcurhdr		;
	_cprohdr	= DFL_CPROHDR	;
	_cprotxt	= DFL_CPROTXT	;
	_wprotxt	= DFL_WPROTXT	;

	_lwrthdr	= _vdolins  - 6 ;
	_cwrthdr	= DFL_CWRTHDR	;
	_cwrtime	= DFL_CWRTIME	;

	_lrdthdr	= _vdolins  - 5 ;
	_crdthdr	= DFL_CRDTHDR	;
	_crdtime	= DFL_CRDTIME	;

	_lownhdr	= _vdolins  - 7 ;
	_cownhdr	= DFL_COWNHDR	;
	_cownrid	= DFL_COWNRID	;
	_wownrid	= DFL_WOWNRID	;

	_lgrphdr	= _vdolins  - 6 ;
	_cgrphdr	= DFL_CGRPHDR	;
	_cgrpnam	= DFL_CGRPNAM	;
	_wgrpnam	= DFL_WGRPNAM	;

	_llnkhdr	= _vdolins  - 5 ;
	_clnkhdr	= DFL_CLNKHDR	;
	_clnkcnt	= DFL_CLNKCNT	;
	_wlnkcnt	= DFL_WLNKCNT	;

	_ctlofs		= _vdolins  - 7 ;
	_ctcofs		= DFL_CTCOFS	;

	_lpath		= DFL_LPATH		;
	_cpath		= DFL_CPATH		;
	_wpath		= DFL_WPATH		;

	_banlins	= DFL_BANLINS	;
	_banlofs	= _vdolins <= 25 ? DFL_BANLOFS : ((_vdolins-_banlins)/2) ;

	_lcmb1		= _vdolins  - 3 ;
	_ccmb1		= DFL_CCMB1		;
	_lcmb2		= _vdolins  - 2 ;
	_ccmb2		= DFL_CCMB2		;

	_lfmb1		= _vdolins  - 1 ;
	_cfmb1		= DFL_CFMB1		;
	_lfmb2		= _lfmb1		;
	_cfmb2		= DFL_CFMB2		;

	_lvrsn		= _vdolins  - 6 ;
	_cvrsn		= DFL_CVRSN		;
	_lsrno		= _vdolins  - 5 ;

	_crnlofs	= _vdolins  - 6 ;
	_crncofs	= DFL_CRNCOFS	;
	_snilofs	= _vdolins  - 5 ;
	_snicofs	= DFL_SNICOFS	;

	_l_hlpbox	= DFL_L_HLPBOX	;
	_c_hlpbox	= DFL_C_HLPBOX	;
	_hlpwlen	= _vdocols - 10 ;
	_hlpwhei	= _vdolins  - 8 ;

}

/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

/*
 * vi:tabstop=4
 */
