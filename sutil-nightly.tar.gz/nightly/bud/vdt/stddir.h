
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stddir.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDDIR_H

# define _STDDIR_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	DS_DOT			0x0001
# define	DS_RECURSE		0x0002
# define	DS_NODOTDIRS	0x0004

# define	DS_REG			0x0010
# define	DS_DIR			0x0020
# define	DS_BLK			0x0040
# define	DS_CHR			0x0080

# define	DS_FIFO			0x0100
# define	DS_LINK			0x0200
# define	DS_SOCK			0x0400

# define	DS_FILES		(DS_REG|DS_BLK|DS_CHR|DS_FIFO|DS_LINK|DS_SOCK)

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef TC2

#	include	<dir.h>
#	include	<dos.h>

	struct dosdirdes {
		struct	ffblk	ffdat ;
		int				dirct ;
	} ;

	typedef		struct dosdirdes		DIRDES ;
	typedef		struct dosdirdes		DIRENT ;

#	define	d_name		ffdat.ff_name

#	define	FA_MASK		(FA_ARCH|FA_DIREC|FA_RDONLY|FA_SYSTEM|FA_HIDDEN)

# endif /* TC2 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef MSVC

# ifdef MSVCADVDIF
# include <windows.h>
# include <winerror.h>
# endif /* MSVCADVDIF */

# include <io.h>

	struct windirdes {
		struct _finddatai64_t	ffdat ;
		int						dirct ;
		long					hndl ;
	} ;

	typedef		struct windirdes		DIRDES ;
	typedef		struct windirdes		DIRENT ;

#	define	d_name		ffdat.name

/* #	define	FA_MASK		(_A_NORMAL|_A_RDONLY|_A_HIDDEN|_A_SYSTEM|_A_SUBDIR|_A_ARCH) */

# endif /* MSVC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef	ANYX

#	ifdef OLDIR

		struct v7dir {
			ushort	d_ino ;
			char	d_name[14] ;
		} ;

		typedef		FILE			DIRDES ;
		typedef		struct v7dir	DIRENT ;

#	else  /* SYS V DIR */

#		include <dirent.h>

		typedef		DIR				DIRDES ;

#		ifdef SYSVDIRBUG
			struct xdirent {
				ino_t	d_ino ;
				off_t	f_off ;
				char	d_name[1] ;
			} ;
			typedef		struct xdirent	DIRENT ;
#		else
			typedef		struct dirent	DIRENT ;
#		endif

#	endif /* OLD DIR */

# endif /* ANYX */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

#if !defined(MAXNAMLEN)
#define MAXNAMLEN 512 /* 1024 */
#endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

DIRDES *	OpenDir			OF ( (char *)							) ;
DIRENT *	ReadDir			OF ( (DIRDES *)							) ;
int			CloseDir		OF ( (DIRDES *)							) ;

DIRDES *	setdirent		OF ( (char *)							) ;
char *		getdirent		OF ( (DIRDES *)							) ;
char *		getdirsel		OF ( (DIRDES *, int)					) ;
int			enddirent		OF ( (DIRDES *)							) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDDIR_H */

/*
 * vi:nu ts=4
 */
