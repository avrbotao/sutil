
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This file is part of 'VDT' (the Visual Disk Test) by <botao.org> ;  |
 |                                                                      |
 |  'VDT' is free software: you can redistribute it and/or modify it    |
 |  under the terms of the GNU General Public License as published by   |
 |  the Free Software Foundation, either version 3 of the License, or   |
 |  (at your option) any later version.                                 |
 |                                                                      |
 |  'VDT' is distributed in the hope that it will be useful,            |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with 'VDT'.  If not, see <http://www.gnu.org/licenses/>, or   |
 |  write to the Free Software Foundation, Inc.,                        |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# ifndef _VDT_H_

# define _VDT_H_

# include	"configure.h"

#if defined (__HP_cc)
# if __HP_cc == 111108
#  define	NOCONST
# endif
#endif

#ifdef	NOCONST
# define	const
#endif

# include	<sys/time.h>
# include	<sys/types.h>
# include	<sys/stat.h>
# include	<sys/utsname.h>

# ifdef AIX71
typedef uint_t          rid_t;          /* role ID */
# endif /* AIX71 */

# include	<fcntl.h>
# include	<math.h>
# include	<time.h>
# include	<ctype.h>
# include	<errno.h>
# include	<stdio.h>
# include	<stdlib.h>
# include	<unistd.h>
# include	<signal.h>
# include	<string.h>
# include	<limits.h>

# include	"bud.h"

# ifdef USE_NCURSES
#	include	<ncurses/curses.h>
# else
#	ifdef USE_CURSES
#		include	<curses.h>
#	else
#		error	"missing curses"
#	endif
# endif

/*	__	__	__	__	__	__	__	__	*/

# if ! ( defined (SYSIO) || defined (SIMIO) || defined (BUFIO) )
#	error	"must define {SYS|BUF|SIM}IO"
# endif

/*	__	__	__	__	__	__	__	__	*/

/*
# define	BANNER			SWNAME
*/
# define	VDTLOG			"vdt.log"
# define	VDTERR			"vdt.err"
# define	VDTOPT			"vdt.opt"
# define	VDTSEC			"vdt.sec"
# define	VDTBOS			"vdt.bos"

# define	DFLVDTDIR		"."
# define	DOTVDTDIR		".vdt"

# define	MAXPATHNAMELEN		   1024

# define	MAXVDTARG			   1024

# define	MINVDTMSG			   1000
# define	MAXVDTMSG			   1040

# define	DFLSECSIZ			    512

# define	TMPBUFSIZ			   8192

# define	MINVISBLKSIZ		    512
# define	STDVISBLKSIZ		   1024
# define	MAXVISBLKSIZ		1048576		/* 16 MiB */

# define	MINSTRIPECNT		      3
# define	MAXSTRIPECNT		      8

# define	VBF_READOK		0x00000001
# define	VBF_SEEKOK		0x00000002
# define	VBF_WRITOK		0x00000004
# define	VBF_TESTOK		0x00000010
# define	VBF_JUMPOK		0x00000020
# define	VBF_PEEKOK		0x00000040
/*
# define	VBF_COMPOK		0x00000100
*/
# define	VBF_RIFFOK		0x00000200
# define	VBF_ENDING		0x00001000
# define	VBF_SCRAPS		0x00002000
# define	VBF_USEFUL		0x00004000

# define	DFLAVROWS				16
# define	DFLAVCOLS				64

# define	BW_LIN		1
# define	BW_COL		1
# define	PW_LIN		1
# define	PW_WID		12
# define	SW_COL		1
# define	SW_HEI		4
# define	XW_HEI		(sectflag?4:6)
# define	XW_WID		PW_WID /* 12 */
# define	IW_HEI		SW_HEI /* 4 */
# define	IW_WID		PW_WID /* 12 */

# define	BW_HEI		2+avrows
# define	BW_WID		2+avcols
# define	PW_COL		wscols-13
# define	PW_HEI		12 /* 2+avrows */
# define	SW_LIN		wsrows-5
# define	SW_WID		BW_WID /* wscols-2 */
# define	XW_LIN		((BW_HEI)-(sectflag?3:5)) /* 1+(PW_HEI) */
# define	XW_COL		PW_COL
# define	IW_LIN		SW_LIN
# define	IW_COL		PW_COL

# define	NEXTDECRADDR(X,T)		( (T-1) - X )
# define	NEXTSCATADDR(X,T)		( (T&1) ? ( (X&1) ? (T/2)+(X/2)+1 : (T/2)-(X/2) ) : ( (X&1) ? (T/2)+(X/2) : (T/2)-(X/2)-1 ) )
# define	NEXTCONVADDR(X,T)		( (X&1) ? (X/2) : (T-1)-(X/2) )
# define	NEXTSPOTADDR(X,T)		( (X&1) ? ( T&1 ? X : X-1 ) : (T-1)-X )
# define	NEXTGOLDADDR(X,T)		( ( X < T/2 ) ? ( ( T & 1 ) ? ( (X&1) ? (T/2)+X+1 : (T/2)-X ) : ( (X&1) ? (T/2)+X : (T/2)-X-1 ) ) : ( (X&1) ? (T/2)+(T-X)-1 : X-(T/2)-(T&1) ) )
# define	NEXTRANDADDR(X,T)		( vdtrand () % T )

#ifdef SLICADDR
# define	NEXTSERISLICADDR(X,T)	( nextserislicaddr (X,T) )
# define	NEXTDISTSLICADDR(X,T)	( nextdistslicaddr (X,T) )
#endif

# define	VDT_INCR	'I'
# define	VDT_DECR	'D'
# define	VDT_SCAT	'S'
# define	VDT_CONV	'C'
# define	VDT_SPOT	'X'
# define	VDT_GOLD	'G'
# define	VDT_RAND	'R'

/*	__	__	__	__	__	__	__	__	*/

struct visblkdat {
	long	vbd_size ;
	off_t	vbd_addr ;
	int		vbd_lin ;
	int		vbd_col ;
	int		vbd_hits ;
	long	vbd_flags ;
} ;

typedef		struct visblkdat	VISBLKDAT ;

struct vdtperf {
	double		vdp_min ;		/* min throughput (bytes/usec)	*/
	double		vdp_max ;		/* max throughput (bytes/usec)	*/
	double		vdp_avg ;		/* avg throughput (bytes/usec)	*/
	double		vdp_sum ;
	double		vdp_siz ;		/* total size accounted for		*/
} ;

typedef		struct vdtperf		VDTPERF ;

struct vdtmark {
	char *		vdm_nam ;
	long long	vdm_min ;		/* min i/o time (usecs)			*/
	long long	vdm_max ;		/* max i/o time (usecs)			*/
	long long	vdm_avg ;		/* avg i/o time (usecs)			*/
	long long	vdm_sum ;
	long		vdm_cnt ;
	VDTPERF		vdm_prf ;
} ;

typedef		struct vdtmark		VDTMARK ;

# define	VISBLKDATSIZ		( sizeof (VISBLKDAT) )

struct vdtypeinfo {
	int *	vty_flag ;
	char *	vty_name ;
} ;

typedef		struct vdtypeinfo		VDTYPEINFO ;

/*	__	__	__	__	__	__	__	__	*/

# define			SPECTABXOPEN	 0
# define			SPECTABXCLOS	 1
# define			SPECTABXREAD	 2	/* read from 1st file			*/
# define			SPECTABXSEEK	 3	/* seek to read from 1st file	*/
# define			SPECTABXSTAT	 4
# define			SPECTABXWRIT	 5	/* write on second file			*/
# define			SPECTABXBLOT	 6
# define			SPECTABXCOOL	 7
# define			SPECTABXCOPY	 8
/*
# define			SPECTABXMESS	 9
*/
# define			SPECTABXAVER	10
# define			SPECTABXCOMP	11
# define			SPECTABXJUMP	12	/* seek to write on 2nd file	*/
# define			SPECTABXMAKE	13
# define			SPECTABXRIFF	14	/* read from 2nd file			*/
# define			SPECTABXPEEK	15	/* seek to read from 2nd file	*/
# define			SPECTABXSTIR	16	/* read, write someplace else	*/
# define			SPECTABXPOKE	17	/* write single sector			*/
# define			SPECTABXMIME	18	/* differing sector copy		*/

/*______________________________________________________________________*/

# define	VER_NOPENTTY		1001
# define	VER_NOWINSIZ		1002
# define	VER_NOIONAME		1003
# define	VER_MESSREQS		1004
# define	VER_BADBUFSZ		1005
# define	VER_INVALIFE		1006
# define	VER_BADEADLN		1007
# define	VER_NVDEADLN		1008
# define	VER_PASTDDLN		1009
# define	VER_NOCPYNAM		1010

# define	VER_NOCMPNAM		1011
# define	VER_BADMXFER		1012
# define	VER_BADMXPAS		1013
# define	VER_NOCOKNAM		1014
# define	VER_NOBURNAM		1015
# define	VER_NOMESNAM		1016
# define	VER_NOINPNAM		1017
# define	VER_NOACTION		1018
# define	VER_STRIPREQ		1019
# define	VER_STRPRANG		1020

# define	VER_STRPOREG		1021
# define	VER_PERCRANG		1022
# define	VER_PCTOEVEN		1023
# define	VER_MAKEREQZ		1024
# define	VER_TIMOUNIQ		1025
# define	VER_RCONFLCT		1026
# define	VER_ISCRFAIL		1027
# define	VER_BADSIGQT		1028
# define	VER_BADSIGWC		1029
# define	VER_NOWRITEX		1030

# define	VER_RESERVED		1031
# define	VER_BADTSTSZ		1032
# define	VER_BADMXOPS		1033
# define	VER_TIMODEAD		1034
# define	VER_CACHEXCL		1035
# define	VER_BADKILSZ		1036
# define	VER_BOILREQS		1037
# define	VER_BREWREQS		1038

# define	VER_INVBUFSZ		1055
# define	VER_REQBUFSZ		1056
# define	VER_TILOFINE		1057

/*	__	__	__	__	__	__	__	__	*/

# ifdef ANSI
void vdtrepinf (int, int) ;
void vdtreport (char *) ;
# else
void vdtrepinf () ;
void vdtreport () ;
# endif

void vdtinit () ;
void vdt () ;

#ifdef PROTOIOCTL
# ifdef ANSI
int ioctl(int d, int request, ...);
# else
int ioctl();
# endif
#endif

/*	__	__	__	__	__	__	__	__	*/

# endif /* ! _VDT_H_ */

/*34567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890*/
/*       1         2         3         4         5         6         7         8         9          */

/*       1         2         3         4         5         6         7        */
/*3456789012345678901234567890123456789012345678901234567890123456789012345678*/

/*
 * vi:nu ts=4
 */
