
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                                       _______________________________
 *                                      |                               |
 *                                      |   vdt      visual disk test   |
 *                                      |_______________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This file is part of 'VDT' (the Visual Disk Test) by <botao.org> ;  |
 |                                                                      |
 |  'VDT' is Free and Open Source software (FOSS). This means you can   |
 |  redistribute it and/or modify it under the terms of the GNU General |
 |  Public License as published by the Free Software Foundation, either |
 |  version 3 of the License, or (at your option) any later version.    |
 |                                                                      |
 |  'VDT' is distributed in the hope that it will be useful,            |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License	|
 |  along with 'VDT'.  If not, see <http://www.gnu.org/licenses/>, or	|
 |  write to the Free Software Foundation, Inc.,                        |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# define	SWNAME			"vdt"
# define	SWVERS			"5.4.88"
# define	SWFORG			"a"						/*	"$" = stable	*/
# define	SWDATE			"2013/12/30"
# define	SWCOPY			"GPLv3"
# define	SWAUTH			"alexandre@botao.org"

# include	"vdt.h"

/*______________________________________________________________________*/

char *		swid = SWNAME ;
char *		swvn = SWVERS ;
char *		swfn = SWFORG ;
char *		swrd = SWDATE ;
char *		swlc = SWCOPY ;
char *		swan = SWAUTH ;

char *		vdtev = "VDT" ;
char *		vdtdir = ".vdt" ;

/*______________________________________________________________________*/

int		incrflag = 0 ;
int		decrflag = 0 ;
int		convflag = 0 ;
int		scatflag = 0 ;
int		goldflag = 0 ;
int		spotflag = 0 ;
int		randflag = 0 ;

VDTYPEINFO	vdaddrlist [] = {
	{ &incrflag , "incr" } ,
	{ &decrflag , "decr" } ,
	{ &convflag , "conv" } ,
	{ &scatflag , "scat" } ,
	{ &goldflag , "gold" } ,
	{ &spotflag , "spot" } ,
	{ &randflag , "rand" } ,
	{ NULL,		NULL }
} ;

int		headflag = 0 ;
int		coreflag = 0 ;
int		tailflag = 0 ;
int		edgeflag = 0 ;	/* edge or curb						*/
int		slabflag = 0 ;	/* edge + core						*/

VDTYPEINFO	vdagrplist [] = {
	{ &edgeflag , "edge" } ,
	{ &slabflag , "slab" } ,
	{ NULL,		NULL }
} ;

VDTYPEINFO	vdarealist [] = {
	{ &headflag , "head" } ,
	{ &coreflag , "core" } ,
	{ &tailflag , "tail" } ,
	{ NULL,		NULL }
} ;

int		averflag = 0 ;
int		blotflag = 0 ;
int		compflag = 0 ;
int		coolflag = 0 ;
int		copyflag = 0 ;
int		makeflag = 0 ;
int		mimeflag = 0 ;
int		pokeflag = 0 ;	/* poke								*/
int		readflag = 0 ;
int		seekflag = 0 ;	/* seek								*/
int		stirflag = 0 ;	/* read+rand+writ					*/
int		writflag = 0 ;

VDTYPEINFO	vdtbaslist [] = {	/* basic tests			*/
	{ &makeflag , "make" } ,
	{ &pokeflag , "poke" } ,
	{ &readflag , "read" } ,
	{ &seekflag , "seek" } ,
	{ &writflag , "writ" } ,
	{ NULL,		NULL }
} ;

VDTYPEINFO	vdtcomlist [] = {	/* compound tests		*/
	{ &averflag , "aver" } ,
	{ &blotflag , "blot" } ,
	{ &compflag , "comp" } ,
	{ &coolflag , "cool" } ,
	{ &copyflag , "copy" } ,
	{ &mimeflag , "mime" } ,
	{ &stirflag , "stir" } ,
	{ NULL,		NULL }
} ;

int		boilflag = 0 ;	/* comp			*/
int		brewflag = 0 ;	/* copy			*/
int		burnflag = 0 ;
int		cookflag = 0 ;
int		messflag = 0 ;	/* aver+blot+cool+stir(*)			*/
int		toilflag = 0 ;	/* try various buffer sizes			*/

VDTYPEINFO	vdtmixlist [] = {	/* stress tests			*/
	{ &boilflag , "boil" } ,
	{ &brewflag , "brew" } ,
	{ &burnflag , "burn" } ,
	{ &cookflag , "cook" } ,
	{ &messflag , "mess" } ,
	{ &toilflag , "toil" } ,
	{ NULL,		NULL }
} ;

int		fastflag = 0 ;
int		fateflag = 0 ;
int		firmflag = 0 ;
int		sameflag = 0 ;
int		whimflag = 0 ;

VDTYPEINFO	vdrandlist [] = {
	{ &fastflag , "fast" } ,
	{ &fateflag , "fate" } ,
	{ &firmflag , "firm" } ,
	{ &sameflag , "same" } ,
	{ &whimflag , "whim" } ,
} ;

int		biasflag = 0 ;	/* skip cached b.o.s.		*/
int		boonflag = 0 ;		/* allow last test to finish neatly			*/
int		cloyflag = 0 ;	/* dull after max_rnd_hit		*/
int		dazeflag = 0 ;	/* full buffer/file random pattern fill		*/
int		deadflag = 0 ;
int		dualflag = 0 ;
int		evenflag = 0 ;
int		fillflag = 0 ;	/* undoc/d : reserved...	*/
int		fineflag = 0 ;	/* fine-grained comparison/copy and report */
int		flipflag = 0 ;
int		forcflag = 0 ;	/* force write existing files etc...	*/
int		fullflag = 0 ;	/* if sect rand within b.o.s. else uniq	*/
int		glibflag = 0 ;	/* smooth transition			*/
int		infoflag = 0 ;	/* show host system configuration info			*/
int		noteflag = 0 ;	/* short note on screen and logs		*/
int		partflag = 0 ;	/* compute partial performance of altbufsiz		*/
int		razeflag = 0 ;
int		sectflag = 0 ;	/* single sector i/o				*/
int		snagflag = 0 ;	/* cloggy transition			*/
int		stewflag = 0 ;	/* applies '-P Rand' to each b.o.s.		*/
int		syncflag = 0 ;
int		tileflag = 0 ;
int		timeflag = 0 ;
int		uniqflag = 0 ;
int		verbflag = 0 ;	/* verbose log info + stuff...	*/
int		versflag = 0 ;	/* undoc/d version/bin-name			*/
int		waitflag = 0 ;	/* "hit [Enter]" to finish			*/
int		wrapflag = 0 ;	/* wrap around eof until timeout	*/
int		siflag   = 0 ;	/* use powers of 1000 not 1024		*/

int		stampathflag = 0 ;	/* timestamped names for log&err	*/

VDTYPEINFO	vdflaglist [] = {
	{ &biasflag , "bias" } ,
	{ &boonflag , "boon" } ,
	{ &cloyflag , "cloy" } ,
	{ &dazeflag , "daze" } ,
	{ &deadflag , "dead" } ,
	{ &dualflag , "dual" } ,
/*	{ &edgeflag , "edge" } ,	*/
	{ &evenflag , "even" } ,
/*	{ &fastflag , "fast" } ,	*/
	{ &fillflag , "fill" } ,
	{ &fineflag , "fine" } ,
	{ &flipflag , "flip" } ,
	{ &forcflag , "forc" } ,
	{ &fullflag , "full" } ,
	{ &glibflag , "glib" } ,
	{ &infoflag , "info" } ,
	{ &noteflag , "note" } ,
	{ &partflag , "part" } ,
	{ &razeflag , "raze" } ,
	{ &sectflag , "sect" } ,
/*	{ &slabflag , "slab" } ,	*/
	{ &snagflag , "snag" } ,
	{ &stewflag , "stew" } ,
	{ &syncflag , "sync" } ,
	{ &tileflag , "tile" } ,
	{ &timeflag , "time" } ,
	{ &uniqflag , "uniq" } ,
	{ &verbflag , "verb" } ,
	{ &waitflag , "wait" } ,
	{ &wrapflag , "wrap" } ,
	{ NULL,		NULL }
} ;

int		authflag = 0 ;
int		erroflag = 0 ;
int		goneflag = 0 ;		/* time to die...							*/
int		helpflag = 0 ;
int		keepflag = 0 ;		/* append to log/err file(s)				*/
int		lifeflag = 0 ;		/* deadline across stress-tests				*/
int		motiflag = 0 ;		/* pattern filler							*/
int		percflag = 0 ;
int		redoflag = 0 ;
int		soonflag = 0 ;		/* deadline before midnight					*/
int		strpflag = 0 ;		/* striped test area						*/
int		termflag = 0 ;		/* terminated by SIGTERM					*/

/*	{ &keepflag , "keep" } ,	*/
/*	{ &motiflag , "moti" } ,	*/

/*______________________________________________________________________*/

int		errcnt = 0 ;
int		passno = 0 ;
int		maxpass = 0 ;
int		skipcnt = 0 ;
int		stripcnt = 0 ;
int		stripinx = 0 ;
int		randhitp = 0 ;
int		randextr = 0 ;
int		timedout = 0 ;
int		testedok = 0 ;
int		comperrs = 0 ;
int		compsects = 0 ;

int		curraddrmode = 0 ;

# ifdef SLICADDR
int		serislicflag = 0 ;
int		distslicflag = 0 ;
# endif

int		delay = 2 ;
int		passev = 0 ;
int		chkpnt = 0 ;

int		wsrows = 0 ;
int		wscols = 0 ;

int		avrows = 0 ;
int		avcols = 0 ;

int		linsizloc = 0 ;
int		linelapst = 0 ;
int		linmixnam = 0 ;
int		lintstnam = 0 ;
int		coltstnam = 0 ;
int		hittablen = 0 ;

int		brow ;
int		bcol ;

int		warea = 0 ;
int		wdens = 0 ;

time_t	declsecs = 0 ;			/* time to live (-t)				*/
time_t	vitality = 0 ;			/* time to live (-D)				*/

int		declperc = 0 ;			/* user-given %						*/
int		justperc = 0 ;			/* adjusted %						*/
int		rgonperc = 0 ;			/* region share %					*/
int		usedperc = 100 ;		/* effectively considereded %		*/
int		motifsiz = 0 ;
int		percok, lastpercok ;
int		percy, lastpercy ;
int		pwprev ;

int		vdtseed = 132947 ;
int		vdtargc = -1 ;

size_t	altbufsiz = 0 ;

off_t	visblkcnt = 0 ;			/* total clumps(bos)				*/
off_t	visblkuse = 0 ;			/* useful clumps(bos)				*/
off_t	visblkpct = 0 ;			/* % total clumps(bos)				*/
off_t	visblkrnd ;				/* clumps(bos) entropy				*/
off_t	visblklim = 0 ;			/* max iterations(bos)				*/

unsigned char		motif8  = 0x00 ;

unsigned short		motif16 = 0x0000 ;

unsigned long		motif32 = 0x00000000 ;

unsigned long long	motif64 = 0x0000000000000000 ;

long		visblksiz = 0 ;
long		visblksects = 0 ;
long		totvisblk = 0 ;
long		lastsize ;
long		sectsize = DFLSECSIZ ;

off_t		filesize = 0 ;
off_t		testsize = 0 ;
off_t		declsize = 0 ;
off_t		killsize = 0 ;
off_t		percsize = 0 ;
off_t		worksize = 0 ;
off_t		headsize = 0 ;		/* head length						*/
off_t		tailsize = 0 ;		/* tail start						*/
off_t		corehead = 0 ;
off_t		coretail = 0 ;
off_t		moresize = 0 ; /* ? better name !? */
off_t		strparea = 0 ;
off_t		strpsize = 0 ;
off_t		skiparea = 0 ;
off_t		skipsize = 0 ;
off_t		strpbase [MAXSTRIPECNT] ;

char *		vdtpath = NULL ;
char *		vdtreptyp = NULL ;

char		logfilename [MAXNAMLEN] ;
char		errfilename [MAXNAMLEN] ;
char		optfilename [MAXNAMLEN] ;

char *		readfilename = NULL ;
char *		compfilename = NULL ;
char *		rwiofilename = NULL ;
char *		writfilename = NULL ;

char *		readbuff = NULL ;
char *		compbuff = NULL ;
char *		writbuff = NULL ;

char *		motifbuf = NULL ;
char *		deadbuff = NULL ;
char *		notebuff = NULL ;

char *		cpufam = NULL ;
char *		osname = NULL ;
char *		osver = NULL ;

char *		vdtargv [MAXVDTARG] ;

off_t *		finelist = NULL ;
off_t *		groslist = NULL ;

char		pwpbuf [64] ;
char		errmsg [TMPBUFSIZ] ;

char		skipchar = '_' ;
char		bondchar = ' ' ;

			/*		 "123456789-123456789-123456789-123456789-123456789-123456789-123456789-123456789-123456789-"		*/
char *		hittab = "123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&*+,-./:;=?@^_|[]{}()<>~0" ;		/* 90 */

FILE *		efp = NULL ;
FILE *		lfp = NULL ;
FILE *		ofp = NULL ;

WINDOW *	mwp = NULL ;	/* main			*/
WINDOW *	bwp = NULL ;	/* visblk		*/
WINDOW *	swp = NULL ;	/* status		*/
WINDOW *	pwp = NULL ;	/* progress		*/
WINDOW *	xwp = NULL ;	/* extra		*/
WINDOW *	iwp = NULL ;	/* info			*/

VISBLKDAT *			lbp = NULL ;
VISBLKDAT *			visblklst = NULL ;

VFD			rfd = -1 ;		/* read		file descriptor		*/
VFD			cfd = -1 ;		/* compare	file descriptor		*/
VFD			wfd = -1 ;		/* write	file descriptor		*/

time_t		initloc ;
time_t		partloc ;
time_t		diftloc ;
time_t		lastloc ;
time_t		quitloc ;
time_t		riptloc ;		/* deadline						*/

struct tm *			nowtmptr = NULL ;
struct tm *			riptmptr = NULL ;

struct stat			sb ;
struct timeval		tod1 , tod2 ;
struct timeval		tod5 , tod6 ;
struct timeval		tod11 , tod12 ;
struct timeval		tod15 , tod16 ;
struct timeval		initod , quitod ;
struct timezone		tzb ;

#ifdef AIX
struct devinfo devinfbuf ;
struct lv_info lv_infbuf ;
#endif

#if defined ( OPENBSD ) || defined ( NETBSD )
struct disklabel dsklabbuf;
#endif

#ifdef HPUX
struct capacity capinfbuf ;
disk_describe_type dskdesbuf ;
capacity_type dskcapbuf ;
#endif

#ifdef SUNX
#	ifdef USE_MEDINF
struct dk_minfo medinfbuf ;
#	endif
#	ifdef USE_DSKGEO
struct dk_geom  dskgeobuf ;
#	endif
#endif

#ifdef APPLE
uint32_t aplblksiz ;
uint64_t aplblkcnt ;
#endif

long long			diftim  = 0 ;	/* usecs */
long long			netelap = 0 ;	/* usecs */

int					specindx = -1 ;

VDTMARK				vdtspec [] = {
	{ "open"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "close" , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "read"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "seek"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "stat"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "write" , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "blot"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "cool"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "copy"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "mess"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } , /* FIXME: reuse 4 meld */
	{ "aver"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "comp"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "jump"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "make"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "riff"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "peek"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "stir"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "poke"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ "mime"  , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
	{ NULL    , LLONG_MAX , LLONG_MIN , 0 , 0 , 0 , { DOUBLE_MAX , DOUBLE_MIN , 0.0 , 0.0 , 0.0 } } ,
} ;

/*______________________________________________________________________*/

char *		vdtmesgs [ ] = {

/*1000*/ "no problemo."													,

/*1001*/ "can't open tty."												,
/*1002*/ "can't get window size."										,
/*1003*/ "missing i/o filename."										,
/*1004*/ "--mess requires --{aver|blot|cool|stir}."						,
/*1005*/ "alternate buffer size is not a multiple of sector size."		,
/*1006*/ "invalid lifespan."											,
/*1007*/ "incorrectly formatted deadline."								,
/*1008*/ "invalid deadline."											,
/*1009*/ "deadline is in the past."										,
/*1010*/ "missing input or output filename for copy."					,

/*1011*/ "missing source or target filename for comparison."			,
/*1012*/ "max. transfers must be greater than 0."						,
/*1013*/ "max. passes must be greater than 0."							,
/*1014*/ "missing input filename for cook."								,
/*1015*/ "missing output filename for burn."							,
/*1016*/ "missing i/o filename for mess."								,
/*1017*/ "missing input filename..."									,
/*1018*/ "no action specified..."										,
/*1019*/ "'-s #' requires '-p %%' or --even"							,
/*1020*/ "given stripe count is out of range."							,

/*1021*/ "stripes and region(s) are mutually exclusive."				,
/*1022*/ "given percent is out of range."								,
/*1023*/ "--even and -p %% are mutually exclusive."						,
/*1024*/ "--make requires -z <size>."									,
/*1025*/ "--uniq and -t are mutually exclusive."						,
/*1026*/ "--whim and ( --same or --firm ) are incompatible."			,
/*1027*/ "screen initialization failed."								,
/*1028*/ "quit trap failed."											,
/*1029*/ "window resize trap failed."									,
/*1030*/ "to write on existing file requires '-F'."						,

/*1031*/ "reserved"														,
/*1032*/ "incompatible test size."										,
/*1033*/ "too many iterations."											,
/*1034*/ "-D and -t are incompatible (except on stress tests)."			,
/*1035*/ "--cloy , --glib , and --snag are mutually exclusive."			,
/*1036*/ "invalid bulksize"												,

/*1037*/ "--boil requires --comp"										,
/*1038*/ "--brew requires --copy"										,
/*1039*/ "reserved"														,
/*1040*/ "reserved"														,

/*1055*/ "alternate buffer size is not a multiple of bunch size."		,
/*1056*/ "--tile requires alternate buffer size."						,
/*1057*/ "--tile and --fine are mutually exclusive."					,

		NULL
} ;

/*______________________________________________________________________
*/

char * dfltoiltrysiz [] = {
	"512",
	  "1k",
	  "2k",
	  "4k",
	  "8k",
	 "16k",
	 "32k",
	 "64k",
	"128k",
	"256k",
	"512k",
	  "1m",
	  "2m",
	  "4m",
	  "8m",
	 "16m",
	 "32m",
	 "64m",
	"128m",
	NULL
} ;

char * * tmptoiltrysiz = NULL ;

size_t * * usetoiltrysiz = NULL ;

/*______________________________________________________________________
*/

long lceilp2 (x) long x ; {

	long c ;

	if (x < 0)
		return -1 ;

	for ( c = 1 ; c < x ; c <<= 1 )
		;

	return c ;
}

/*	__	__	__	__	__	__	__	__	*/

char * vdtkmgtpe (n) sbit64 n ; {

	if ( siflag )
		return lltosikmgtpe (n) ;
	else
		return lltokmgtpe (n) ;
}

char * skipspac (s) char * s ; {
	register char * p = s ;
	while ( *p == ' ' )
		++p ;
	return p ;
}

/*	__	__	__	__	__	__	__	__	*/

char * vdtmsg (n) int n ; {

	if ( n < MINVDTMSG || n >= MAXVDTMSG )
		return "unknown" ;
	else
		return vdtmesgs [ n - MINVDTMSG ] ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdterr (txt) char * txt ; {
	FILE * tfp = lfp ;
	char * tp = txt ;
	if ( erroflag )
		tfp = efp ;
	++errcnt ;
	if (tfp == NULL)
		tfp = stderr ;
	if (tp == NULL)
		tp = errmsg ;
	fprintf (tfp, "\n%s *** %s\n", timestamp (time (NULL), PLUSTAMP), tp) ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtend (sig) int sig ; {

	signal (SIGINT, SIG_IGN) ;
	signal (SIGQUIT, SIG_IGN) ;
	signal (SIGTERM, SIG_IGN) ;
	signal (SIGSEGV, SIG_IGN) ;
	signal (SIGWINCH, SIG_IGN) ;
	if ( sig != 0 ) {
		if ( sig > 0 ) {
			if ( sig == SIGTERM ) {
				if ( lifeflag )
					{ lifeflag = 0 ; ++goneflag ; }
				standout () ; mvaddstr (0, 20, "TERMINATED") ; standend () ; refresh () ;
				++termflag ; sleep (1) ; return ;
			} else {
				if ( sig > 1000 ) {
					sprintf (errmsg, "error(%d):%s", sig, vdtmsg (sig)) ;
				} else {
					vdtreport ("bad") ; sprintf (errmsg, "caught %s (signal %d)", signame (sig), sig) ;
				}
			}
		} else {
			sprintf (errmsg, "errno(%d):%s", -sig, strerror (-sig)) ;
		}
		vdterr (NULL) ;
	}
	if ( mwp != NULL )
		endwin () ;
	if (lfp != NULL)
		fclose (lfp) ;
	if (efp != NULL)
		fclose (efp) ;
	if (errcnt > 0)		/* FIXME: show proper file name */
		fprintf (stderr, "\n*** problems found -- see '%s' for details.\n\n", erroflag ? VDTERR : VDTLOG) ;
	exit (sig) ;
}

/*	__	__	__	__	__	__	__	__	*/

#ifdef TOUTALRM
void vdtwake (sig) int sig ; {
	if ( sig != SIGALRM )
		vdtend (sig) ;
	signal (SIGALRM, vdtwake) ;
	timedout = 1 ;
}
#endif

/*	__	__	__	__	__	__	__	__	*/

void getwinsiz () {

	int rd , fd = 1 ;
	struct winsize wsb ;

	fd = open ("/dev/tty", O_RDWR /*2*/) ;

	if (fd < 0) {
		vdtend (VER_NOPENTTY) ;
	}

	rd = ioctl (fd, TIOCGWINSZ, &wsb) ;

	if (rd < 0) {
		vdtend (VER_NOWINSIZ) ;
	}

	wsrows = wsb.ws_row ;
	wscols = wsb.ws_col ;

	close (fd) ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtidy () {

	/* release ram */

	if ( readbuff != NULL ) {
		free (readbuff) ;
		readbuff = NULL ;
	}

	if ( compbuff != NULL ) {
		free (compbuff) ;
		compbuff = NULL ;
	}

	if ( writbuff != NULL ) {
		if ( ! ( copyflag || mimeflag ) ) {
			free (writbuff) ;
		}
		writbuff = NULL ; /* ?leak? */
	}

	if ( visblklst != NULL ) {
		free (visblklst) ;
		visblklst = NULL ;
	}

	/* close open files */

	if ( rfd != -1 ) {
		VCLOSE ( rfd ) ;
		rfd = -1 ;
	}

	if ( wfd != -1 ) {
		VCLOSE ( wfd ) ;
		wfd = -1 ;
	}

	/* reset values */

	avrows = avcols = 0 ;
	wsrows = wscols = 0 ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtreset () {

	endwin () ;
	vdtidy () ;
	redoflag = 1 ;
}

/*	__	__	__	__	__	__	__	__	*/

void sigwinch (sig) int sig ; {

	int i ;
	static int swk = 0 ;

	signal (SIGINT, SIG_IGN) ;
	signal (SIGQUIT, SIG_IGN) ;
	signal (SIGTERM, SIG_IGN) ;
	signal (SIGSEGV, SIG_IGN) ;
	signal (SIGWINCH, SIG_IGN) ;

	wstandout (iwp) ; /* wattron  (iwp, A_BLINK) ;	*/
	mvwaddstr (iwp, 1, 1, "restarting") ;
	wstandend (iwp) ; /* wattroff (iwp, A_BLINK) ;	*/
	wrefresh (iwp) ;

	sprintf (errmsg, "sigwinch(%d)#(%d)", sig, ++swk) ;
	vdterr (NULL) ;

	curs_set (0) ;
	for ( i = 0 ; i < 5 ; ++i ) {
		mvwaddnstr (iwp, 2, 1, "          ", 2*i) ;
		wrefresh (iwp) ;
		wstandout (iwp) ;
		wprintw (iwp, "%d", 5-i) ;
		wstandend (iwp) ;
		wrefresh (iwp) ;
		sleep (1) ;
	}
	curs_set (1) ;

	vdtreset () ;
}

/*	__	__	__	__	__	__	__	__	*/

void setaltsecsiz ( altsiz ) int altsiz ; {

	if ( altsiz != sectsize )
		sectsize = altsiz ;
}

/*	__	__	__	__	__	__	__	__	*/

void usage () {

	fprintf (stderr, "Usage : %s <options> <parameters>\n", swid) ;
	fprintf (stderr, "Perform i/o tests.\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " basic parameters:\n") ;
    fprintf (stderr, "\n") ;
	fprintf (stderr, " -b size       alternate i/o buffer size\n") ;
	fprintf (stderr, " -c filename   target file for comparison tests\n") ;
	fprintf (stderr, " -D deadline   run until [[[CC]YY]MMDD]hhmm.ss\n") ;
	fprintf (stderr, " -e seed       random number generator seed\n") ;
	fprintf (stderr, " -f filename   use this file for read/write (compound) tests\n") ;
	fprintf (stderr, " -I 'comment'  (short) information to appear on screen and logs\n") ;
	fprintf (stderr, " -m number     maximum number of operations per test\n") ;
	fprintf (stderr, " -M number     maximum number of passes per test\n") ;
	fprintf (stderr, " -p percent    test area = given %% of testsize\n") ;
	fprintf (stderr, " -P pattern    filler for output buffer (0oct|Xhex|Bbin|dec|Rand|Zero)\n") ;
	fprintf (stderr, " -r filename   input(source) file for read-only(comparison) tests\n") ;
	fprintf (stderr, " -s stripes    split test area in given # of stripes\n") ;
	fprintf (stderr, " -t lifespan   [[hh:]mm:]ss = maximum elapsed time per test\n") ;
	fprintf (stderr, " -w filename   use this output file for write-only tests\n") ;
	fprintf (stderr, " -z testsize   test area = just this much\n") ;
	fprintf (stderr, " -Z bulksize   terminate after transfer this much\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " basic tests:\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --make        create & fill test (Bunch_of_Sectors at a time)\n") ;
    fprintf (stderr, " --poke        poke test (same as '--writ --sect')\n") ;
    fprintf (stderr, " --read        read test (B.o.S. at a time)\n") ;
    fprintf (stderr, " --seek        seek test (same as '--read --sect')\n") ;
    fprintf (stderr, " --writ        write test (B.o.S. at a time)\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " compound tests:\n") ;
    fprintf (stderr, "\n") ;
	fprintf (stderr, " --aver        ratification test (write, read back, compare)\n") ;
    fprintf (stderr, " --blot        update test (read, stain, write back)\n") ;
    fprintf (stderr, " --comp        comparison test (B.o.S. at a time)\n") ;
	fprintf (stderr, " --cool        freshen test (read, write back)\n") ;
    fprintf (stderr, " --copy        copy test (B.o.S. at a time)\n") ;
    fprintf (stderr, " --mime        differing copy test (B.o.S. at a time)\n") ;
	fprintf (stderr, " --stir        shuffle test (read, write somewhere else)\n") ;
/*
					   --meld		 <1>2 , <2>1 , ...
    fprintf (stderr, " --echo        write to 2 files (mirror)\n") ;
*/
    fprintf (stderr, "\n") ;
    fprintf (stderr, " stress tests:\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --boil        read-only  test (2 files, all addressing modes)\n") ;
    fprintf (stderr, " --brew        read+write test (2 files, all addressing modes)\n") ;
    fprintf (stderr, " --burn        write-only test (1 file,  all addressing modes)\n") ;
    fprintf (stderr, " --cook        read-only  test (1 file,  all addressing modes)\n") ;
    fprintf (stderr, " --mess        read+write test (1 file,  all addressing modes)\n") ;
    fprintf (stderr, " --toil        try various buffer sizes\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " addressing patterns:\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --incr        incrementing addresses (start to end)\n") ;
    fprintf (stderr, " --decr        decrementing addresses (end to start)\n") ;
    fprintf (stderr, " --conv        converging addresses (edges to middle)\n") ;
    fprintf (stderr, " --scat        scattering addresses (middle to edges)\n") ;
    fprintf (stderr, " --gold        'diamond'-pattern (middle to edges and back)\n") ;
    fprintf (stderr, " --spot        'X'-pattern (edges to middle and back)\n") ;
    fprintf (stderr, " --rand        random addresses\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " region selection:\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --edge        --head and --tail combined\n") ;
    fprintf (stderr, " --head        select initial portion of test area (default)\n") ;
    fprintf (stderr, " --core        select central portion of test area\n") ;
    fprintf (stderr, " --tail        select  final  portion of test area\n") ;
    fprintf (stderr, " --slab        --edge and --core combined\n") ;
    fprintf (stderr, " --even        divide test area proportionally\n") ;
    fprintf (stderr, " --flip        invert selection of test area\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " entropy control:\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --same        yields same random numbers across tests\n") ;
    fprintf (stderr, " --firm        yields same random numbers across platforms\n") ;
    fprintf (stderr, " --fate        same as '--same --firm'\n") ;
    fprintf (stderr, " --whim        extra entropy for unpredictable randomness\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " cache illustration:\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --cloy        stops after (default 90) hit limit\n") ;
    fprintf (stderr, " --glib        smooth transition to next round\n") ;
    fprintf (stderr, " --snag        cloggy transition to next round\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " operation flags:\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " -A            append to log file\n") ;
    fprintf (stderr, " -E            separate error messages into 'vdt.err'\n") ;
    fprintf (stderr, " -F            force overwrite existing files\n") ;
    fprintf (stderr, " -T            timestamped names for log and error files\n") ;
    fprintf (stderr, " -V            show version info and exit\n") ;
    fprintf (stderr, " -v            verbose and additional details\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --si          use powers of 1000 not 1024\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " --bias        skip (possibly) cached B.o.S.\n") ;
    fprintf (stderr, " --bang        same as -F above\n") ;
    fprintf (stderr, " --boon        allow last test to end cleanly past deadline\n") ;
    fprintf (stderr, " --daze        full buffer random pattern fill (implies --stew)\n") ;
    fprintf (stderr, " --fast        apply faster algorithms\n") ;
    fprintf (stderr, " --fine        fine-grained (sectorwise) comparison and report\n") ;
    fprintf (stderr, " --full        random seek within B.o.S.\n") ;
    fprintf (stderr, " --help        show this usage help\n") ;
    fprintf (stderr, " --info        show host system configuration and exit\n") ;
    fprintf (stderr, " --once        same as --uniq\n") ;
    fprintf (stderr, " --part        compute performance using alt. buffer size\n") ;
    fprintf (stderr, " --raze        flatten (truncate) output file\n") ;
    fprintf (stderr, " --sect        i/o just a single (512-Byte) sector at a time\n") ;
    fprintf (stderr, " --stew        applies '-P Rand' for each B.o.S.\n") ;
    fprintf (stderr, " --sync        synchronous (blocking) output\n") ;
    fprintf (stderr, " --tile        split B.o.S. i/o into alternate-buffer-size parts\n") ;
    fprintf (stderr, " --uniq        test each and every random address just once\n") ;
    fprintf (stderr, " --wait        request user interaction to finish\n") ;
    fprintf (stderr, " --wrap        wrap around EOF until timeout\n") ;
    fprintf (stderr, "\n") ;
    fprintf (stderr, " extra parameters:\n") ;
    fprintf (stderr, "\n") ;
	fprintf (stderr, " -L lines      override screen's # of lines\n") ;
	fprintf (stderr, " -C columns    ditto for columns\n") ;
    fprintf (stderr, "\n") ;

	vdtend (0) ;
}

/*	__	__	__	__	__	__	__	__	*/

# define	VDTRNDMAX		0x7fffffff

static int ovum = 0x5f3759df ;

int vdtmlcrng () {	/* Multiplicative Linear Congruential Random Number Generator */
	register int hi, lo ;

	hi = ovum / 127773 ; lo = ovum % 127773 ;
	ovum = 16807 * lo - 2836 * hi ;
	if (ovum <= 0)
		ovum += VDTRNDMAX ;
	return ovum ;
}

int vdtbsdrng () {	/* BSD randz... */
	ovum = ovum * 1103515245 + 12345 ;
	return ovum % ((unsigned int)VDTRNDMAX + 1) ;
}

int vdtrand () {
	if ( firmflag )
		if ( fastflag )
			return vdtbsdrng () ;
		else
			return vdtmlcrng () ;
	else
		return rand () ;
}

void vdtsow (germ) int germ ; {
	if ( firmflag )
		ovum = germ ;
	else
		srand (germ) ;
}

/*	__	__	__	__	__	__	__	__	*/

int vdtluck () {

	return (int) time (NULL) ;
}

/*	__	__	__	__	__	__	__	__	*/

void setmotif () {

	int np ;
	unsigned char tmp8 ;
	unsigned long long tmp64 ;
#ifndef COWBOY
	static unsigned short tmp16 [4] = { 0 , 0 , 0 , 0 } ;
	static unsigned int tmp32 [2] = { 0 , 0 } ;
#endif

	if ( motifbuf == NULL )
		return ;

	if ( *motifbuf == 'r' || *motifbuf == 'R' ) /* strcasecmp ( motifbuf , "rand" ) */
		motif64 = (unsigned long long) vdtrand () * (unsigned long long) vdtrand () ; 
	else if ( *motifbuf == 'z' || *motifbuf == 'Z' )
		motif64 = 0ULL ;
	else if ( *motifbuf == 'b' || *motifbuf == 'B' )
		motif64 = bits2ull ( motifbuf+1 ) ;
	else if ( *motifbuf == 'x' || *motifbuf == 'X' )
		sscanf ( motifbuf+1 , "%llx" , &motif64 ) ;
	else if ( *motifbuf == '0' || *motifbuf == 'o' || *motifbuf == 'O' )
		sscanf ( motifbuf+1 , "%llo" , &motif64 ) ;
	else
		sscanf ( motifbuf , "%lld" , &motif64 ) ;

	if ( motif64 != 0ULL ) {
		if ( motif64 < 256 ) {
			tmp8 = (unsigned char)motif64 ;
			memset ( &motif64 , tmp8 , 8 ) ;
			motifsiz = 8 ;
		} else if ( motif64 < 65536 ) {
			for ( np = 0 , tmp64 = motif64 ; np < 4 ; ++np )
#ifdef COWBOY
				*((unsigned short *)&motif64 + np) = (unsigned short)tmp64 ;
#else
				tmp16[np] = (unsigned short)tmp64 ;
			memcpy ( &motif64 , tmp16 , 8 ) ;
#endif
			motifsiz = 16 ;
		} else if ( motif64 < 4294967296ULL ) {
			for ( np = 0 , tmp64 = motif64 ; np < 2 ; ++np )
#ifdef COWBOY
				*((unsigned int *)&motif64 + np) = (unsigned int)tmp64 ;
#else
				tmp32[np] = (unsigned int)tmp64 ;
			memcpy ( &motif64 , tmp32 , 8 ) ;
#endif
			motifsiz = 32 ;
		} else {
			motifsiz = 64 ;
		}
	}

	motif32 = motif64 & 0xffffffff ;
	motif16 = motif64 & 0xffff ;
	motif8  = motif64 & 0xff ;
}

void motifill ( buf , siz ) char * buf ; size_t siz ; {

	unsigned long long * qp = (unsigned long long *) buf ;
	int nq = siz / sizeof(unsigned long long) ;

	if ( buf == NULL || siz <= 0 )
		return ;

	while ( nq > 0 ) {
		if ( dazeflag )
			setmotif () ;
		*qp++ = motif64 ;
		--nq ;
	}
}

/*	__	__	__	__	__	__	__	__	*/

void blotbuff ( buf ) char * buf ; {

	if ( buf == NULL )
		return ;
	/*	FIXME: must reflect stew/fill	*/
	memcpy ( buf , "blot" , 4 ) ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtparse (argc, argv) int argc ; char * * argv ; {

	if (argc == 0)
		return ;
	if (argv == NULL)
		return ;
	if ( **argv == '-' ) {
		--argv ;
		++argc ;
	}
	if (--argc) {
		while (*++argv) {
			trimstr ( *argv , MAXNAMLEN ) ;
			if ( strcmp (*argv, "-?"           ) == 0 ) {
				++helpflag ;
			} else if ( strcmp (*argv, "--help") == 0 ) {
				++helpflag ;
			} else if ( strcmp (*argv, "--decr") == 0 ) {
				++decrflag ;
			} else if ( strcmp (*argv, "--conv") == 0 ) {
				++convflag ;
			} else if ( strcmp (*argv, "--gold") == 0 ) {
				++goldflag ;
			} else if ( strcmp (*argv, "--read") == 0 ) {
				++readflag ;
			} else if ( strcmp (*argv, "--once") == 0 ) {
				++uniqflag ;
			} else if ( strcmp (*argv, "--uniq") == 0 ) {
				++uniqflag ;
			} else if ( strcmp (*argv, "--tile") == 0 ) {
				++tileflag ;
			} else if ( strcmp (*argv, "--fine") == 0 ) {
				++fineflag ;
			} else if ( strcmp (*argv, "--full") == 0 ) {
				++fullflag ;
			} else if ( strcmp (*argv, "--rand") == 0 ) {
				++randflag ;
			} else if ( strcmp (*argv, "--scat") == 0 ) {
				++scatflag ;
			} else if ( strcmp (*argv, "--incr") == 0 ) {
				++incrflag ;
			} else if ( strcmp (*argv, "--spot") == 0 ) {
				++spotflag ;
			} else if ( strcmp (*argv, "--head") == 0 ) {
				++headflag ;
			} else if ( strcmp (*argv, "--core") == 0 ) {
				++coreflag ;
			} else if ( strcmp (*argv, "--edge") == 0 ) {
				++edgeflag ;
			} else if ( strcmp (*argv, "--tail") == 0 ) {
				++tailflag ;
			} else if ( strcmp (*argv, "--slab") == 0 ) {
				++slabflag ;
			} else if ( strcmp (*argv, "--even") == 0 ) {
				++evenflag ;
			} else if ( strcmp (*argv, "--flip") == 0 ) {
				++flipflag ;
			} else if ( strcmp (*argv, "--sect") == 0 ) {
				++sectflag ;
			} else if ( strcmp (*argv, "--seek") == 0 ) {
				++seekflag ;
			} else if ( strcmp (*argv, "--wait") == 0 ) {
				++waitflag ;
			} else if ( strcmp (*argv, "--fill") == 0 ) {
				++fillflag ;
			} else if ( strcmp (*argv, "--burn") == 0 ) {
				++burnflag ;
			} else if ( strcmp (*argv, "--cook") == 0 ) {
				++cookflag ;
			} else if ( strcmp (*argv, "--writ") == 0 ) {
				++writflag ;
			} else if ( strcmp (*argv, "--copy") == 0 ) {
				++copyflag ;
			} else if ( strcmp (*argv, "--mime") == 0 ) {
				++mimeflag ;
			} else if ( strcmp (*argv, "--blot") == 0 ) {
				++blotflag ;
			} else if ( strcmp (*argv, "--mess") == 0 ) {
				++messflag ;
			} else if ( strcmp (*argv, "--cool") == 0 ) {
				++coolflag ;
			} else if ( strcmp (*argv, "--aver") == 0 ) {
				++averflag ;
			} else if ( strcmp (*argv, "--comp") == 0 ) {
				++compflag ;
			} else if ( strcmp (*argv, "--sync") == 0 ) {
				++syncflag ;
			} else if ( strcmp (*argv, "--dual") == 0 ) {
				++dualflag ;
			} else if ( strcmp (*argv, "--same") == 0 ) {
				++sameflag ;
			} else if ( strcmp (*argv, "--firm") == 0 ) {
				++firmflag ;
			} else if ( strcmp (*argv, "--fate") == 0 ) {
				++fateflag ;
			} else if ( strcmp (*argv, "--whim") == 0 ) {
				++whimflag ;
			} else if ( strcmp (*argv, "--fast") == 0 ) {
				++fastflag ;
			} else if ( strcmp (*argv, "--make") == 0 ) {
				++makeflag ;
			} else if ( strcmp (*argv, "--bang") == 0 ) {
				++forcflag ;
			} else if ( strcmp (*argv, "--stir") == 0 ) {
				++stirflag ;
			} else if ( strcmp (*argv, "--raze") == 0 ) {
				++razeflag ;
			} else if ( strcmp (*argv, "--poke") == 0 ) {
				++pokeflag ;
			} else if ( strcmp (*argv, "--wrap") == 0 ) {
				++wrapflag ;
			} else if ( strcmp (*argv, "--boon") == 0 ) {
				++boonflag ;
			} else if ( strcmp (*argv, "--bias") == 0 ) {
				++biasflag ;
			} else if ( strcmp (*argv, "--cloy") == 0 ) {
				cloyflag = 1 ;
			} else if ( strcmp (*argv, "--glib") == 0 ) {
				glibflag = 1 ;
			} else if ( strcmp (*argv, "--snag") == 0 ) {
				snagflag = 1 ;
			} else if ( strcmp (*argv, "--stew") == 0 ) {
				++stewflag ;
			} else if ( strcmp (*argv, "--part") == 0 ) {
				++partflag ;
			} else if ( strcmp (*argv, "--daze") == 0 ) {
				++dazeflag ;
			} else if ( strcmp (*argv, "--boil") == 0 ) {
				++boilflag ;
			} else if ( strcmp (*argv, "--toil") == 0 ) {
				++toilflag ;
			} else if ( strcmp (*argv, "--brew") == 0 ) {
				++brewflag ;
			} else if ( strcmp (*argv, "--info") == 0 ) {
				++infoflag ;
			} else if ( strcmp (*argv, "--si"  ) == 0 ) {
				++siflag ;
			} else if ( strcmp (*argv, "-a"    ) == 0 ) {
				++authflag ;
			} else if ( strcmp (*argv, "-F"    ) == 0 ) {
				++forcflag ;
			} else if ( strcmp (*argv, "-A"    ) == 0 ) {
				++keepflag ;
			} else if ( strcmp (*argv, "-E"    ) == 0 ) {
				++erroflag ;
			} else if ( strcmp (*argv, "-V"    ) == 0 ) {
				++versflag ;
			} else if ( strcmp (*argv, "-T"    ) == 0 ) {
				++stampathflag ;
			} else if ( strcmp (*argv, "-t"    ) == 0 ) {
				++timeflag ;
				declsecs = (time_t) hms2sec ( *++argv ) ;
			} else if ( strcmp (*argv, "-M"    ) == 0 ) {
				maxpass = (int) bunitz ( *++argv ) ;
			} else if ( strcmp (*argv, "-z"    ) == 0 ) {
				declsize = bunitz ( *++argv ) ;
			} else if ( strcmp (*argv, "-Z"    ) == 0 ) {
				killsize = (off_t) bunitz ( *++argv ) ;
			} else if ( strcmp (*argv, "-b"    ) == 0 ) {
				altbufsiz = (size_t) bunitz ( *++argv ) ;
			} else if ( strcmp (*argv, "-m"    ) == 0 ) {
				visblklim =  (off_t) bunitz ( *++argv ) ;
			} else if ( strcmp (*argv, "-e"    ) == 0 ) {
				vdtseed = (unsigned int) bunitz ( *++argv ) ;
			} else if ( strcmp (*argv, "-I"    ) == 0 ) {
				++noteflag ;
				notebuff = strdup ( *++argv ) ;
			} else if ( strcmp (*argv, "-r"    ) == 0 ) {
				++readflag ;
				readfilename = strdup ( *++argv ) ;
			} else if ( strcmp (*argv, "-D"    ) == 0 ) {
				++deadflag ;
				deadbuff = strdup ( *++argv ) ;
			} else if ( strcmp (*argv, "-P"    ) == 0 ) {
				++motiflag ;
				motifbuf = strdup ( *++argv ) ;
			} else if ( strcmp (*argv, "-c"    ) == 0 ) {
				compfilename = strdup ( *++argv ) ;
			} else if ( strcmp (*argv, "-w"    ) == 0 ) {
				++writflag ;
				writfilename = strdup ( *++argv ) ;
			} else if ( strcmp (*argv, "-f"    ) == 0 ) {
				rwiofilename = strdup ( *++argv ) ;
			} else if ( strcmp (*argv, "-L"    ) == 0 ) {
				sscanf ( *++argv , "%d" , &avrows ) ;
			} else if ( strcmp (*argv, "-C"    ) == 0 ) {
				sscanf ( *++argv , "%d" , &avcols ) ;
			} else if ( strcmp (*argv, "-p"    ) == 0 ) {
				++percflag ;
				sscanf ( *++argv , "%d" , &declperc ) ;
			} else if ( strcmp (*argv, "-s"    ) == 0 ) {
				++strpflag ;
				sscanf ( *++argv , "%d" , &stripcnt ) ;
			} else if ( strcmp (*argv, "-v"    ) == 0 ) {
				++verbflag ;
			} else if ( strcmp (*argv, "-B"    ) == 0 ) {
				skipchar = ' ' ;
			} else {
				++helpflag ;
			}
		}
	}
}

/*	__	__	__	__	__	__	__	__	*/

void vdtobey (fp) FILE * fp ; {

	if (fp == NULL)
		return ;

	while ( fgets ( errmsg , TMPBUFSIZ , fp ) != NULL ) {
		stripeol ( errmsg ) ;
		vdtargc = strclip ( errmsg , vdtargv , ' ' ) ;
		vdtparse ( vdtargc , vdtargv ) ;
	}

	fclose (fp) ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtenv () {
	register char * tp ;

	tp = getenv (vdtev) ;

	if ( tp == NULL ) {
		tp = getenv ("HOME") ;
		if ( tp == NULL ) {
			vdtpath = strdup (".") ;
		} else {
			sprintf (errmsg, "%s/%s", tp, DOTVDTDIR) ;
			vdtpath = strdup (errmsg) ;
		}
	} else {
		if ( *tp == '-' ) {
			vdtargc = strclip ( tp , vdtargv , ' ' ) ;
			vdtparse ( vdtargc , vdtargv ) ;
			vdtpath = strdup (".") ;
		} else {
			vdtpath = strdup (tp) ;
		}
	}
	if ( stat ( vdtpath , &sb ) == 0 ) {
		if ( ! ( S_ISDIR(sb.st_mode) ) ) {
#ifdef VDTWARN
			sprintf (errmsg, "warning: '%s' is not a directory.", vdtpath) ;
			passev = -1 ;
#endif
			free ( vdtpath ) ;
			vdtpath = strdup (".") ;
		}
	} else {
#ifdef VDTWARN
		sprintf (errmsg, "warning: '%s' not found.", vdtpath) ;
		passev = -1 ;
#endif
		free ( vdtpath ) ;
		vdtpath = strdup (".") ;
	}
}

/*	__	__	__	__	__	__	__	__	*/

void vdtinit () {

	int	rd = -1 ;
	char * tsp = NULL ;
	struct utsname utsbuf ;

	if ( osname == NULL ) {
		vdtenv () ;

		sprintf (optfilename, "%s/%s", vdtpath, VDTOPT) ;

		if ( ofp == NULL )
			ofp = fopen ( optfilename, "r" ) ;

		if ( ofp != NULL )
			vdtobey ( ofp ) ;

		rd = uname ( &utsbuf ) ;

		osname = strdup ( ( rd == -1 ) ? "unknown" : utsbuf.sysname ) ;
		osver = strdup ( getosver ( &utsbuf ) ) ;
		hittablen = strlen ( hittab ) ;

		if ( verbflag ) {
			bondchar = '\n' ;
		} else {
			bondchar = ' ' ;
		}

		if ( infoflag ) {
			lfp = stdout ;
			vdtrepinf (-1, -1) ;
			vdtend (0) ;
		}

		if ( versflag ) {
			printf ("%s_", swid) ;
			printf ("%s", SWVERS) ;
			if ( verbflag > 1 && *swfn != '$' )
				printf ("%s", swfn) ;
			printf ("_") ;
			printf ("%s_%s_%s", cpufam, osname, osver) ;
#ifdef LINUX
			if ( verbflag )
				printf ("_%s", getdistro()) ;
#endif
			printf ("\n") ;
			vdtend (0) ;
		}

		printf ("\n%s=%s", swid, SWVERS) ;
		if ( verbflag > 1 && *swfn != '$' )
			printf ("%s", swfn) ;
		printf (" %s=%s ", osname, osver) ;
#ifdef LINUX
		if ( verbflag )
			printf ("%s ", getdistro()) ;
#endif
		printf ("%s=%s ", cpufam, SWDATE) ;
		if ( authflag ) {
			printf ("%s=%s ", "(C)" /* SWCOPY */, SWAUTH) ;
		}
		printf ("\n\n") ;

		if ( stampathflag ) {
			tsp = timestamp ( time (NULL) , RAWSTAMP ) ;
			sprintf (logfilename, "%s/vdt%s.log", vdtpath, tsp) ;
			sprintf (errfilename, "%s/vdt%s.err", vdtpath, tsp) ;
		} else {
			sprintf (logfilename, "%s/%s", vdtpath, VDTLOG) ;
			sprintf (errfilename, "%s/%s", vdtpath, VDTERR) ;
		}

		if ( lfp == NULL )
			lfp = fopen ( logfilename, keepflag ? "a" : "w" ) ;

		if ( lfp == NULL )
			fprintf (stderr, "\n*** can't open log file '%s'.\n\n", logfilename) ;

		if ( erroflag ) {
			if ( efp == NULL )
				efp = fopen ( errfilename, keepflag ? "a" : "w" ) ;
			if ( efp == NULL )
				fprintf (stderr, "\n*** can't open error file '%s'.\n\n", errfilename) ;
		}
#ifdef VDTWARN
		if ( passev == -1 )
			vdterr (NULL) ;
#endif
		if ( helpflag ) {
			usage () ;
		}

		if ( averflag /* || meldflag */ ) {
			vdterr ("feature not implemented (yet).") ;
			vdtend (0) ;
		}

		if ( readfilename == NULL && writfilename == NULL && rwiofilename == NULL ) {
			fprintf (stderr, "*** no filename informed.\n\n") ;
			fprintf (stderr, "==> try `vdt --help' for details.\n\n") ;
			vdtend (0) ;
		}

		if ( coolflag || blotflag || stirflag ) {
			if ( rwiofilename == NULL ) {
				vdtend (VER_NOIONAME) ;
			}
			++readflag ;
		}

		if ( messflag ) {
			if ( ! ( averflag || blotflag || coolflag || stirflag ) ) {
				vdtend (VER_MESSREQS) ;
			}
		}

		if ( tileflag && fineflag ) {
			vdtend (VER_TILOFINE) ;
		}

		if ( altbufsiz != 0 ) {
			if ( altbufsiz % sectsize ) {
				vdtend (VER_BADBUFSZ) ;
			}
		} else {
			if ( tileflag ) {
				vdtend (VER_REQBUFSZ) ;
			}
		}

		if ( seekflag ) {
			++readflag ;
			++sectflag ;
		}

		if ( pokeflag ) {
			++writflag ;
			++sectflag ;
		}

		if ( timeflag && deadflag ) {
			if ( ! ( cookflag || burnflag || messflag || boilflag || brewflag ) ) {
				vdtend (VER_TIMODEAD) ;
			}
		}

		if ( timeflag ) {
			if ( declsecs <= (time_t) 0 ) {
				vdtend (VER_INVALIFE) ;
			}
		}

		if ( deadflag ) {

			strcpy ( errmsg , deadbuff ) ; riptmptr = dtparse ( errmsg , DTP_MARK ) ;

			if ( riptmptr == NULL ) {
				vdtend (VER_BADEADLN) ;
			}

			time ( &partloc ) ; nowtmptr = localtime ( &partloc ) ;

			if ( riptmptr->tm_year == -1 )
				riptmptr->tm_year = nowtmptr->tm_year ;

			if ( riptmptr->tm_mon == -1 )
				riptmptr->tm_mon = nowtmptr->tm_mon ;

			if ( riptmptr->tm_mday == -1 )
				riptmptr->tm_mday = nowtmptr->tm_mday ;

			riptloc = mktime ( riptmptr ) ;

			if ( riptloc == (time_t) -1 ) {
				vdtend (VER_NVDEADLN) ;
			}

			diftloc = (time_t) difftime ( riptloc , partloc ) ;

			if ( diftloc <= (time_t) 0 ) {
				sprintf (errmsg, "deadline missed (by %lld seconds).", (long long) diftloc) ;
				vdterr (NULL) ;
				vdtend (VER_PASTDDLN) ;
			}

			if ( cookflag || burnflag || messflag || boilflag || brewflag ) {
				++lifeflag ; vitality = diftloc ;
			} else {
				++timeflag ; declsecs = diftloc ;
			}

			if (	riptmptr->tm_year == nowtmptr->tm_year	&&
					riptmptr->tm_mon  == nowtmptr->tm_mon	&&
					riptmptr->tm_mday == nowtmptr->tm_mday		)
				++soonflag ;
		}

		if ( copyflag || mimeflag ) {
			if ( readfilename == NULL || writfilename == NULL ) {
				vdtend (VER_NOCPYNAM) ;
			}
			++readflag ;
			++writflag ;
		}

		if ( compflag ) {
			if ( readfilename == NULL || compfilename == NULL ) {
				vdtend (VER_NOCMPNAM) ;
			}
			++readflag ;
		}

		if ( visblklim != (off_t) 0 ) {
			if ( (long long)visblklim < 0LL ) {
				vdtend (VER_BADMXFER) ;
			}
		}

		if ( killsize != (off_t) 0 ) {
			if ( (long long)killsize < 0LL ) {
				vdtend (VER_BADKILSZ) ;
			}
		}

		if ( maxpass != 0 ) {
			if ( maxpass < 0 ) {
				vdtend (VER_BADMXPAS) ;
			}
		}

		if ( cookflag ) {
			if ( readfilename == NULL ) {
				vdtend (VER_NOCOKNAM) ;
			}
			readflag = 1 ;
			incrflag = decrflag = convflag = scatflag = spotflag = goldflag = randflag = 1 ;
		}

		if ( burnflag ) {
			if ( writfilename == NULL ) {
				vdtend (VER_NOBURNAM) ;
			}
			writflag = 1 ;
			incrflag = decrflag = convflag = scatflag = spotflag = goldflag = randflag = 1 ;
		}

		if ( messflag ) {
			if ( rwiofilename == NULL ) {
				vdtend (VER_NOMESNAM) ;
			}
			incrflag = decrflag = convflag = scatflag = spotflag = goldflag = randflag = 1 ;
		}

		if ( boilflag ) {
			if ( ! ( compflag ) ) {
				vdtend (VER_BOILREQS) ;
			}
			incrflag = decrflag = convflag = scatflag = spotflag = goldflag = randflag = 1 ;
		}

		if ( brewflag ) {
			if ( ! ( copyflag ) ) {
				vdtend (VER_BREWREQS) ;
			}
			incrflag = decrflag = convflag = scatflag = spotflag = goldflag = randflag = 1 ;
		}

		if ( readflag || writflag || copyflag || compflag || coolflag || mimeflag || stirflag || blotflag ) {
			if ( ! ( incrflag || decrflag || convflag || scatflag || spotflag || goldflag || randflag ) ) {
				++incrflag ;
			}
		}

		if ( readflag && ! ( coolflag || blotflag || stirflag ) ) {
			if ( readfilename == NULL ) {
				vdtend (VER_NOINPNAM) ;
			}
		}

		if ( ! ( readflag || writflag ) ) {
			vdtend (VER_NOACTION) ;
		}

		if ( strpflag ) {
			if ( ! ( percflag || evenflag ) ) {
				vdtend (VER_STRIPREQ) ;
			}
			if ( stripcnt < MINSTRIPECNT || stripcnt > MAXSTRIPECNT ) {
				sprintf (errmsg, "stripe count %d outside (%d..%d)", stripcnt, MINSTRIPECNT, MAXSTRIPECNT) ;
				vdterr (NULL) ;
				vdtend (VER_STRPRANG) ;
			}
			if ( headflag || tailflag || coreflag || edgeflag || slabflag ) {
				vdtend (VER_STRPOREG) ;
			}
		}

		if ( slabflag ) {
			++edgeflag ;
			++coreflag ;
		}

		if ( edgeflag ) {
			++headflag ;
			++tailflag ;
		}

		if ( percflag ) {
			if ( declperc < 1 || declperc > 100 ) {
				sprintf (errmsg, "percent '%d' outside (%d..%d)", declperc, 1, 100) ;
				vdterr (NULL) ;
				vdtend (VER_PERCRANG) ;
			} else {
				if ( evenflag ) {
					vdtend (VER_PCTOEVEN) ;
				}
				usedperc = declperc ;
			}
			if ( ! ( headflag || tailflag || coreflag || edgeflag || slabflag || strpflag ) ) {
				++headflag ;
			}
		}

		if ( makeflag ) {
			if ( declsize == 0 ) {
				vdtend (VER_MAKEREQZ) ;
			}
			++incrflag ;
			++fillflag ;
			++writflag ;
		}

		if ( sectflag ) {
			linmixnam = 3 ;
			if ( readflag ) {
				specindx = SPECTABXSEEK ;
			}
			if ( writflag ) {
				specindx = SPECTABXJUMP ;
			}
		} else {
			linmixnam = 5 ;
			if ( readflag ) {
				specindx = SPECTABXREAD ;
			}
			if ( /* makeflag || */ writflag ) {
				specindx = SPECTABXWRIT ;
			}
		}

		if ( fineflag || mimeflag ) {
			fullflag = 0 ;
		}

		if ( fullflag ) {
			if ( ! sectflag ) {
				++uniqflag ;
				fullflag = 0 ;
			}
		}
#ifdef NOTSURE
		if ( timeflag && uniqflag ) {
			vdtend (VER_TIMOUNIQ) ;
		}
#endif
		if ( uniqflag || fullflag ) {
			++randflag ;
		}

		if ( fateflag ) {
			++sameflag ;
			++firmflag ;
		}

		if ( randflag ) {
			if ( ( rd = cloyflag + glibflag + snagflag ) ) {
				if ( rd > 1 ) {
					vdtend (VER_CACHEXCL) ;
				}
			} else {
				++glibflag ;
			}
		}

		if ( dazeflag ) {
			++stewflag ;
		}

		if ( stewflag ) {
			++motiflag ;
			motifbuf = strdup ( "Rand" ) ;
		}

		if ( motiflag ) {
			setmotif () ;
		}

		if ( whimflag && ( sameflag || firmflag ) ) {
			vdtend (VER_RCONFLCT) ;
		}
	}

	if ( randflag ) {
		if ( sameflag ) {
			vdtsow ( vdtseed ) ;
		} else {
			if ( whimflag ) {
				vdtseed *= vdtluck () ;
			}
			vdtseed *= (unsigned int) time (NULL) ;
			vdtsow ( vdtseed ) ;
		}
	}

	getwinsiz () ;

	mwp = initscr () ;

	if (mwp == NULL) {
		vdtend (VER_ISCRFAIL) ;
	}

	if ( avrows == 0 ) {
		if ( wsrows > 0 ) {
			avrows = (int) pow((double)2,floor(log2((double)(wsrows-8)))) ;
		} else {
			avrows = DFLAVROWS ;
		}
	}

	if ( avcols == 0 ) {
		if ( wscols > 0 ) {
			avcols = (int) pow((double)2,floor(log2((double)(wscols-16)))) ;
		} else {
			avcols = DFLAVCOLS ;
		}
	}

	signal (SIGINT, vdtend) ;
	signal (SIGTERM, vdtend) ;
	signal (SIGSEGV, vdtend) ;

	if ( SIG_ERR == signal (SIGQUIT, sigwinch) )
		vdtend (VER_BADSIGQT) ;

	if ( SIG_ERR == signal (SIGWINCH, sigwinch) )
		vdtend (VER_BADSIGWC) ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtreperf (inx, lfp) int inx ; FILE * lfp ; {

	VDTMARK * tip ;
	char * nam ;
	double netperf = 0.0 ;

	tip = vdtspec + inx ;
	nam = tip->vdm_nam ;

	fprintf (lfp, "%s_count=%ld%c",  nam, tip->vdm_cnt, bondchar) ;
	fprintf (lfp, "tot_%s_time=%lld.%06llds%c",  nam, tip->vdm_sum / 1000000, tip->vdm_sum % 1000000 , bondchar) ;
	fprintf (lfp, "min_%s_time=%fs%c",  nam, (double) (tip->vdm_min / 1000000.0)	, bondchar) ;
	fprintf (lfp, "avg_%s_time=%fs%c",  nam, (double) (tip->vdm_avg / 1000000.0)	, bondchar) ;
	fprintf (lfp, "max_%s_time=%fs%c",  nam, (double) (tip->vdm_max / 1000000.0)	, bondchar) ;
	if ( ( ! sectflag ) && ( ( altbufsiz == 0 ) || partflag ) ) {
		if ( inx != SPECTABXSEEK && inx != SPECTABXPEEK && inx != SPECTABXJUMP ) {
			fprintf (lfp, "tot_%s_size=%s%c",   nam, skipspac ( vdtkmgtpe ( (long long) tip->vdm_prf.vdp_siz ) ) , bondchar) ;
# ifdef RAWSPEED
			fprintf (lfp, "min_%s_perf=%f/s%c", nam, (double) (1000000.0 * tip->vdm_prf.vdp_min)	, bondchar) ;
			fprintf (lfp, "avg_%s_perf=%f/s%c", nam, (double) (1000000.0 * tip->vdm_prf.vdp_avg)	, bondchar) ;
			fprintf (lfp, "max_%s_perf=%f/s%c", nam, (double) (1000000.0 * tip->vdm_prf.vdp_max)	, bondchar) ;
# else
			fprintf (lfp, "min_%s_perf=%s/s%c", nam, skipspac ( vdtkmgtpe ( (long long) (1000000.0 * tip->vdm_prf.vdp_min)	) ) , bondchar) ;
			fprintf (lfp, "avg_%s_perf=%s/s%c", nam, skipspac ( vdtkmgtpe ( (long long) (1000000.0 * tip->vdm_prf.vdp_avg)	) ) , bondchar) ;
			fprintf (lfp, "max_%s_perf=%s/s%c", nam, skipspac ( vdtkmgtpe ( (long long) (1000000.0 * tip->vdm_prf.vdp_max)	) ) , bondchar) ;
# endif
			if ( netelap > 0 ) {
				netperf = tip->vdm_prf.vdp_siz / (double)netelap ; /* (total) bytes / (elapsed) usec */
				fprintf (lfp, "net_%s_perf=%s/s%c", nam, skipspac ( vdtkmgtpe ( (long long) (1000000.0 * netperf) ) ) , bondchar) ;
			} else {
				fprintf (lfp, "net_%s_perf=n/a%c", nam, bondchar) ;
			}
		}
	}
	tip->vdm_min = LLONG_MAX ;
	tip->vdm_max = LLONG_MIN ;
	tip->vdm_avg = tip->vdm_sum = tip->vdm_cnt = 0 ;
	tip->vdm_prf.vdp_min = DOUBLE_MAX ;
	tip->vdm_prf.vdp_max = DOUBLE_MIN ;
	tip->vdm_prf.vdp_avg = tip->vdm_prf.vdp_sum = tip->vdm_prf.vdp_siz = 0.0 ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtacct (inx, tv1, tv2, siz) int inx ; struct timeval * tv1 , * tv2 ; long siz ; {

	VDTMARK *	tip ;
	double		dbltim , dblsiz , dbltpt ;

	diftim = diftod ( tv1 , tv2 ) ;

	if ( diftim == 0 )
		diftim = 1 ;

	tip = vdtspec + inx ;

	tip->vdm_sum += diftim ;
	tip->vdm_cnt += 1 ;
	tip->vdm_avg = tip->vdm_sum / tip->vdm_cnt ;

	if ( diftim < tip->vdm_min )
		tip->vdm_min = diftim ;

	if ( diftim > tip->vdm_max )
		tip->vdm_max = diftim ;

	if ( siz == -1L )
		return ;

	if ( ( ( siz == visblksiz ) || dualflag ) || ( ( (size_t)siz == altbufsiz ) && partflag ) ) {
		dbltim = diftim ;
		dblsiz = siz ;
		dbltpt = dblsiz / dbltim ;		/* bytes / usec */
		tip->vdm_prf.vdp_siz += dblsiz ;
		tip->vdm_prf.vdp_sum += dbltpt ;
		tip->vdm_prf.vdp_avg = tip->vdm_prf.vdp_sum / tip->vdm_cnt ;
		if ( dbltpt < tip->vdm_prf.vdp_min )
			tip->vdm_prf.vdp_min = dbltpt ;
		if ( dbltpt > tip->vdm_prf.vdp_max )
			tip->vdm_prf.vdp_max = dbltpt ;
	}
}

# ifdef SLICADDR

/*	__	__	__	__	__	__	__	__	*/

off_t nextserislicaddr (cur, tot) int cur , tot ; {

	return (off_t) cur + tot ;
}

off_t nextdistslicaddr (cur, tot) int cur , tot ; {

	return (off_t) cur + tot ;
}

# endif

/*	__	__	__	__	__	__	__	__	*/

char * getvdaddr (adr) int adr ; {
	static char * ap ;
	switch ( adr ) {
		case VDT_INCR : ap = "incr" ; break ;
		case VDT_DECR : ap = "decr" ; break ;
		case VDT_SCAT : ap = "scat" ; break ;
		case VDT_CONV : ap = "conv" ; break ;
		case VDT_SPOT : ap = "spot" ; break ;
		case VDT_GOLD : ap = "gold" ; break ;
		case VDT_RAND : ap = "rand" ; break ;
		default : ap = "none" ; break ;
	}
	return ap ;
}

/*	__	__	__	__	__	__	__	__	*/

char * getvdarea () {
	int i ;
	static char abuf [80] ;
	if ( verbflag || ! ( slabflag || edgeflag ) ) {
		for ( abuf[0] = i = 0 ; vdarealist[i].vty_name != NULL ; ++i ) {
			if ( *(vdarealist[i].vty_flag) ) {
				strcat ( abuf , vdarealist[i].vty_name ) ;
				strcat ( abuf , "," ) ;
			}
		}
	} else {
		for ( abuf[0] = i = 0 ; vdagrplist[i].vty_name != NULL ; ++i ) {
			if ( *(vdagrplist[i].vty_flag) ) {
				strcat ( abuf , vdagrplist[i].vty_name ) ;
				strcat ( abuf , "," ) ;
			}
		}
	}
	abuf[strlen(abuf)-1] = '\0' ;
	return abuf ;
}

/*	__	__	__	__	__	__	__	__	*/

char * getvdbasic () {
	int i ;
	static char tbuf [80] ;
	for ( tbuf[0] = i = 0 ; vdtbaslist[i].vty_name != NULL ; ++i )
		if ( *(vdtbaslist[i].vty_flag) ) {
			strcat ( tbuf , vdtbaslist[i].vty_name ) ;
			strcat ( tbuf , "," ) ;
		}
	if ( tbuf[0] == '\0' )
		strcpy (tbuf, "none") ;
	else
		tbuf[strlen(tbuf)-1] = '\0' ;
	return tbuf ;
}

/*	__	__	__	__	__	__	__	__	*/

char * getvdstress () {
	int i ;
	static char tbuf [80] ;
	for ( tbuf[0] = i = 0 ; vdtmixlist[i].vty_name != NULL ; ++i )
		if ( *(vdtmixlist[i].vty_flag) ) {
			strcat ( tbuf , vdtmixlist[i].vty_name ) ;
			strcat ( tbuf , "," ) ;
		}
	if ( tbuf[0] == '\0' )
		strcpy (tbuf, "none") ;
	else
		tbuf[strlen(tbuf)-1] = '\0' ;
	return tbuf ;
}

/*	__	__	__	__	__	__	__	__	*/

char * getvdcompo () {
	int i ;
	static char tbuf [80] ;
	for ( tbuf[0] = i = 0 ; vdtcomlist[i].vty_name != NULL ; ++i )
		if ( *(vdtcomlist[i].vty_flag) ) {
			strcat ( tbuf , vdtcomlist[i].vty_name ) ;
			strcat ( tbuf , "," ) ;
		}
	if ( tbuf[0] == '\0' )
		strcpy (tbuf, "none") ;
	else
		tbuf[strlen(tbuf)-1] = '\0' ;
	return tbuf ;
}

/*	__	__	__	__	__	__	__	__	*/

char * getvdflag () {
	int i ;
	static char fbuf [80] ;
	for ( fbuf[0] = i = 0 ; vdflaglist[i].vty_name != NULL ; ++i )
		if ( *(vdflaglist[i].vty_flag) ) {
			strcat ( fbuf , vdflaglist[i].vty_name ) ;
			strcat ( fbuf , "," ) ;
		}
	if ( fbuf[0] == '\0' )
		strcpy (fbuf, "none") ;
	else
		fbuf[strlen(fbuf)-1] = '\0' ;
	return fbuf ;
}

/*	__	__	__	__	__	__	__	__	*/

char * getvdrand () {
	int i ;
	static char rbuf [80] ;
	for ( rbuf[0] = i = 0 ; vdrandlist[i].vty_name != NULL ; ++i )
		if ( *(vdrandlist[i].vty_flag) ) {
			strcat ( rbuf , vdrandlist[i].vty_name ) ;
			strcat ( rbuf , "," ) ;
		}
	rbuf[strlen(rbuf)-1] = '\0' ;
	return rbuf ;
}

/*	__	__	__	__	__	__	__	__	*/

void finedump () { /* dump finelist[] to <vdt.sec> */
	register int i ;
	FILE * dfp ;
	off_t * tp = finelist ;
	dfp = fopen (VDTSEC, "w") ;
	if ( dfp == NULL ) {
		vdterr ("unable to create comparison sector offset dump file") ;
		return ;
	}
	for ( i = 0 ; i < comperrs ; ++i ) {
		fprintf ( dfp , "%lld\n" , (long long) *(tp+i) ) ;
	}
	fclose (dfp) ;
}

/*	__	__	__	__	__	__	__	__	*/

void grosdump () { /* dump groslist[] to <vdt.bos> */
	register int i ;
	FILE * dfp ;
	off_t * tp = groslist ;
	dfp = fopen (VDTBOS, "w") ;
	if ( dfp == NULL ) {
		vdterr ("unable to create comparison B.o.S. offset dump file") ;
		return ;
	}
	for ( i = 0 ; i < comperrs ; ++i ) {
		fprintf ( dfp , "%lld\n" , (long long) *(tp+i) ) ;
	}
	fclose (dfp) ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtrepinf (inx, adr) int inx , adr ; {

	register char * tp = NULL ;

	fprintf (lfp, "%s=%s", swid, SWVERS) ;

	if ( verbflag > 1 && *swfn != '$' ) {
		fprintf (lfp, "%s", swfn) ;
	}

	fprintf (lfp, "%c", bondchar) ;

	if ( verbflag ) {
		fprintf (lfp, "release=%s%c", SWDATE, bondchar) ;
	}

	fprintf (lfp, "os=%s%c", osname, bondchar) ;

# ifdef LINUX
	if ( verbflag ) {
		fprintf (lfp, "distro=%s%c", getdistro (), bondchar) ;
	}
# endif

	fprintf (lfp, "version=%s%c", osver, bondchar) ;
	fprintf (lfp, "cpu=%s%c", cpufam, bondchar) ;

	if ( verbflag ) {
		fprintf (lfp, "count=%s%c", getcpuinf ("count"), bondchar) ;
		fprintf (lfp, "clock=%s%c", getcpuinf ("clock"), bondchar) ;
		fprintf (lfp, "model=%s%c", getcpuinf ("model"), bondchar) ;
	}

	fprintf (lfp, "ram=%lld%c", getsysram (), bondchar) ;

	if ( verbflag ) {
		fprintf (lfp, "endian=%s%c", isbigend () ? "big" : "little", bondchar) ;
	}

	if ( infoflag ) {
		if ( ! verbflag )
			fprintf (lfp, "\n") ;
		return ;
	}

	if ( verbflag ) {
		fprintf (lfp, "start=%s+%s%c", strdate (initloc), strtime (initloc), bondchar) ;
	} else {
		strcpy ( errmsg , ctime ( &initloc ) ) ;
		tp = errmsg + strlen (errmsg) ;
		if ( *--tp == '\n' ) {
			*tp = '\0' ;
		}
		fprintf (lfp, "start=%s%c", errmsg, bondchar) ;
	}

	if ( quitloc == (time_t) 0 ) {
		fprintf (lfp, "end=%s%c", "n/a", bondchar) ;
	} else {
		if ( verbflag ) {
			fprintf (lfp, "end=%s+%s%c", strdate (quitloc), strtime (quitloc), bondchar) ;
		} else {
			strcpy ( errmsg , ctime ( &quitloc ) ) ;
			tp = errmsg + strlen (errmsg) ;
			if ( *--tp == '\n' ) {
				*tp = '\0' ;
			}
			fprintf (lfp, "end=%s%c", errmsg, bondchar) ;
		}
	}

	fprintf (lfp, "elapsed=") ;
	if ( quitloc == (time_t) 0 || netelap <= 0 ) {
		fprintf (lfp, "%s", "n/a") ;
	} else {
		if ( verbflag ) {
			fprintf (lfp, "%lld.%06llds", netelap / 1000000, netelap % 1000000) ;
		} else {
			if ( diftloc > SECPERDAY ) {
				fprintf (lfp, "%lldd+", (long long)(diftloc/SECPERDAY)) ;
				diftloc %= SECPERDAY ;
			}
			fprintf (lfp, "%s", strhms (diftloc)) ;
		}
	}
	fprintf (lfp, "%c", bondchar) ;

	if ( timeflag ) {
		fprintf (lfp, "life=") ;
		if ( declsecs < 60 ) {
			fprintf (lfp, "%llds", (long long) declsecs) ;
		} else {
			if ( declsecs > SECPERDAY ) {
				fprintf (lfp, "%lldd+", (long long)(declsecs/SECPERDAY)) ;
				declsecs %= SECPERDAY ;
			}
			fprintf (lfp, "%s", strhms (declsecs)) ;
		}
		fprintf (lfp, "%c", bondchar) ;
		if ( verbflag ) {
			fprintf (lfp, "timeout=%s%c", timedout ? "yes" : "no", bondchar) ;
		}
	}

	if ( deadflag ) {
		if ( ! timeflag ) {
			fprintf (lfp, "term=") ;
			if ( vitality < 60 ) {
				fprintf (lfp, "%llds", (long long) vitality) ;
			} else {
				if ( vitality > SECPERDAY ) {
					fprintf (lfp, "%lldd+", (long long)(vitality/SECPERDAY)) ;
					vitality %= SECPERDAY ;
				}
				fprintf (lfp, "%s", strhms (vitality)) ;
			}
			fprintf (lfp, "%c", bondchar) ;
		}
		if ( verbflag ) {
			fprintf (lfp, "death=%s+%s%c", strdate (riptloc), strtime (riptloc), bondchar) ;
		} else {
			strcpy ( errmsg , ctime ( &riptloc ) ) ;
			tp = errmsg + strlen (errmsg) ;
			if ( *--tp == '\n' ) {
				*tp = '\0' ;
			}
			fprintf (lfp, "death=%s%c", errmsg, bondchar) ;
		}
	}

	fprintf (lfp, "basic=%s%c", getvdbasic(), bondchar) ;
	fprintf (lfp, "stress=%s%c", getvdstress(), bondchar) ;
	fprintf (lfp, "compound=%s%c", getvdcompo(), bondchar) ;
	fprintf (lfp, "address=%s%c", getvdaddr(adr), bondchar) ;
	fprintf (lfp, "flag=%s%c", getvdflag(), bondchar) ;

	if ( sameflag || firmflag || whimflag || fastflag )
		fprintf (lfp, "rand=%s%c", getvdrand(), bondchar) ;

	if ( readfilename != NULL )
		fprintf (lfp, "input=%s%c", readfilename, bondchar) ;

	if ( rwiofilename != NULL )
		fprintf (lfp, "i/o=%s%c", rwiofilename, bondchar) ;

	if ( compfilename != NULL )
		fprintf (lfp, "compare=%s%c", compfilename, bondchar) ;

	if ( writfilename != NULL )
		fprintf (lfp, "output=%s%c", writfilename, bondchar) ;

	if ( filesize > 0 ) {
		fprintf (lfp, "size=%lld%c", (long long) filesize, bondchar) ;
		if ( fineflag ) {
			fprintf (lfp, "sectors=%lld%c", (long long) compsects, bondchar) ;
		}
	} else {
		fprintf (lfp, "size=%s%c", "n/a", bondchar) ;
	}

	if (verbflag) {
#ifdef SUNX
#	ifdef USE_MEDINF
		fprintf (lfp, "capac=%lld lbsize=%lld%c", (long long)medinfbuf.dki_capacity, (long long)medinfbuf.dki_lbsize, bondchar);
#	endif
#	ifdef USE_DSKGEO
		fprintf (lfp, "cyls=%lld heads=%lld sects=%lld%c", (long long)dskgeobuf.dkg_ncyl, (long long)dskgeobuf.dkg_nhead, (long long)dskgeobuf.dkg_nsect, bondchar);
#	endif
#endif
	}

	if ( filesize != testsize )
		fprintf (lfp, "used=%lld%c", (long long) testsize, bondchar) ;

	if ( killsize > (off_t) 0 )
		fprintf (lfp, "bulk=%lld%c", (long long) killsize, bondchar) ;

	if ( visblklim > (off_t) 0 )
		fprintf (lfp, "operations=%lld%c", (long long) visblklim, bondchar) ;

	if ( percflag ) {
		fprintf (lfp, flipflag ? "%s=~%lld%%%c" : "%s=%lld%%%c", evenflag ? "even" : "percent", (long long) ( flipflag ? 100 - usedperc : usedperc ) , bondchar) ;
		if ( verbflag ) {
			fprintf (lfp, "adjusted%s%d%%%c", flipflag ? "=~" : "=", justperc, bondchar) ;
			fprintf (lfp, "slice=%lld%c", (long long) percsize, bondchar) ;
		}
	}

	if ( strpflag ) {
		if ( flipflag )
			fprintf (lfp, "stripes=]%lldx%lld[%c", (long long) skipcnt , (long long) skipsize, bondchar) ;
		else
			fprintf (lfp, "stripes=[%lldx%lld]%c", (long long) stripcnt , (long long) strpsize, bondchar) ;
	}

	if ( headflag || tailflag || coreflag || edgeflag || slabflag ) {
		fprintf (lfp, flipflag ? "region=)%s(%c" : "region=(%s)%c", getvdarea(), bondchar) ;
		if ( verbflag ) {
			fprintf (lfp, "share=%d%%%c", rgonperc, bondchar) ;
		}
	}

	fprintf (lfp, "blocks=%lldx%lld", (long long) totvisblk, (long long) visblksiz) ;

	if ( lastsize > 0 )
		fprintf (lfp, "+%lld", (long long) lastsize) ;

	fprintf (lfp, "%c", bondchar) ;

	if (verbflag) {
		if ( percflag )
			fprintf (lfp, "selected%s%lld%c", flipflag ? "=~" : "=", (long long)visblkpct, bondchar) ;
		fprintf (lfp, "marked=%lld%c", (long long) visblkuse, bondchar) ;
		fprintf (lfp, "tested=%lld%c", (long long) (biasflag ? testedok : visblkuse), bondchar) ;
	}

	if ( timeflag && wrapflag ) {
		fprintf (lfp, "passes=%d", passno ? passno : 1+passno) ;
		if ( maxpass > 0 )
			fprintf (lfp, "/%d", maxpass) ;
		fprintf (lfp, "%c", bondchar) ;
	}

	if ( altbufsiz != 0 )
		fprintf (lfp, "buffer=%ld%c", (long)altbufsiz, bondchar) ;

	if ( motiflag ) {
		if ( verbflag )
			fprintf (lfp, "pattern=%s/x%llx/0%llo/%llu%c", ull2bits (motif64), (unsigned long long)motif64, (unsigned long long)motif64, (unsigned long long)motif64, bondchar) ;
		else
			fprintf (lfp, "pattern=%s%c", motifbuf, bondchar) ;
	}

	vdtreperf (inx, lfp) ;

	if ( verbflag ) {
		fprintf (lfp, "screen=%dx%d%c", wsrows, wscols, bondchar) ;
		fprintf (lfp, "window=%dx%d%c", avrows, avcols, bondchar) ;
		fprintf (lfp, "area=%d%c", warea, bondchar) ;
		fprintf (lfp, "density=%d%c", wdens, bondchar) ;
	}

	if ( copyflag || coolflag || mimeflag || stirflag || blotflag ) {
		switch ( inx ) {
			case SPECTABXREAD : vdtreperf (SPECTABXSEEK, lfp) ; break ;
			case SPECTABXWRIT : vdtreperf (SPECTABXJUMP, lfp) ; break ;
		}
	} else if ( compflag || mimeflag ) {
		switch ( inx ) {
			case SPECTABXREAD : vdtreperf (SPECTABXSEEK, lfp) ; break ;
			case SPECTABXRIFF : vdtreperf (SPECTABXPEEK, lfp) ; break ;
		}
		if ( comperrs == 0 ) {
			fprintf (lfp, "mismatches=none%c", bondchar) ;
		} else {
			fprintf (lfp, "mismatches=%d%c", comperrs, bondchar) ;	/*	FIXME: show %	*/
			if ( fineflag ) {
				finedump () ; /* dump finelist[] to <vdt.sec> */
			} else {
				grosdump () ; /* dump groslist[] to <vdt.bos> */
			}
		}
	} else {
		if ( ! sectflag ) {
			if ( ! ( writflag /* || makeflag */ ) ) {
				vdtreperf (SPECTABXSEEK, lfp) ;
			}
			if ( ! readflag ) {
				vdtreperf (SPECTABXJUMP, lfp) ;
			}
		}
	}

	if ( randflag && verbflag ) {
		if ( ! timeflag ) {
			if ( randhitp ) {
				fprintf (lfp, "(%d %% rand cache hit)%c", randhitp, bondchar) ;
			}
			if ( uniqflag ) {
				fprintf (lfp, "(%d rand extra)%c", randextr, bondchar) ;
			}
		}
	}

	if ( authflag ) {
		fprintf (lfp, "license=%s%c", SWCOPY, bondchar) ;
		fprintf (lfp, "author=%s%c", SWAUTH, bondchar) ;
	}

	if (verbflag) {
		fprintf (lfp, "checkpoint=%d%c", chkpnt, bondchar) ;
	}

	if (noteflag) {
		fprintf (lfp, "comment='%s'%c", notebuff, bondchar) ;
	}

	fprintf (lfp, "status=") ;
	if ( termflag )
		fprintf (lfp, "%s", "terminated") ;
	else
		fprintf (lfp, "%s", vdtreptyp == NULL ? "good" : vdtreptyp) ;
	fprintf (lfp, "%c", bondchar) ;

	/* if ( ! verbflag ) */
		fprintf (lfp, "\n") ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdtreport (reptyp) char * reptyp ; {

	vdtreptyp = reptyp ;

	if ( copyflag ) {
		vdtrepinf ( SPECTABXREAD , curraddrmode ) ;
		vdtrepinf ( SPECTABXWRIT , curraddrmode ) ;
		vdtrepinf ( SPECTABXCOPY , curraddrmode ) ;
	} else if ( blotflag ) {
		vdtrepinf ( SPECTABXREAD , curraddrmode ) ;
		vdtrepinf ( SPECTABXWRIT , curraddrmode ) ;
		vdtrepinf ( SPECTABXBLOT , curraddrmode ) ;
	} else if ( coolflag ) {
		vdtrepinf ( SPECTABXREAD , curraddrmode ) ;
		vdtrepinf ( SPECTABXWRIT , curraddrmode ) ;
		vdtrepinf ( SPECTABXCOOL , curraddrmode ) ;
	} else if ( mimeflag ) {
		vdtrepinf ( SPECTABXREAD , curraddrmode ) ;
		vdtrepinf ( SPECTABXWRIT , curraddrmode ) ;
		vdtrepinf ( SPECTABXMIME , curraddrmode ) ;
	} else if ( stirflag ) {
		vdtrepinf ( SPECTABXREAD , curraddrmode ) ;
		vdtrepinf ( SPECTABXWRIT , curraddrmode ) ;
		vdtrepinf ( SPECTABXSTIR , curraddrmode ) ;
	} else if ( compflag ) {
		vdtrepinf ( SPECTABXREAD , curraddrmode ) ;
		vdtrepinf ( SPECTABXRIFF , curraddrmode ) ;
		vdtrepinf ( SPECTABXCOMP , curraddrmode ) ;
	} else {
		vdtrepinf ( specindx , curraddrmode ) ; /* FIXME: no need 4 2nd parm */
	}
}

/*	__	__	__	__	__	__	__	__	*/

void vdtest (addrmode) int addrmode ; {

	VDTMARK * tip = vdtspec + specindx ;
	int i , j , rd , xtroutbit = 0 , hitz = 0 , /* hytp , */ hito = 0 ;
	int compsize , readsects ;
	register int olin = 0 , ocol = 0 ;
	register int hitcount = 0 , hitround = 0 ;
	register int cmpres = 0 , ci = 0 ;
	register int tilebufs = 0 ;
	register int badtiles = 0 ;
	register char * readsptr ;
	register char * compsptr ;
	off_t ofs ;
	size_t readsize = 0 , readspan = 0 ;
	size_t writsize = 0 , writspan = 0 ;

	curraddrmode = addrmode ;

	if (readflag) {
		if ( altbufsiz == 0 ) {
			if ( sectflag ) {
				readspan = (size_t)sectsize ;
			} else {
				readspan = visblksiz ;
			}
		} else {
			readspan = tileflag ? (size_t)visblksiz : altbufsiz ;
		}

		readbuff = malloc ( tileflag ? (size_t)visblksiz : readspan ) ;

		if (readbuff == NULL) {
			vdterr ("no memory for input buffer") ;
			vdtend (-errno) ;
		}

		if ( coolflag || stirflag || blotflag )
			rfd = VOPEN (rwiofilename, MODEIO, 0) ;
		else
			rfd = VOPEN (readfilename, MODEIN, 0) ;

		if ( rfd < 0 ) {
			rfd = errno ;
			sprintf (errmsg, "can't open %s file '%s'.", 
				( coolflag || stirflag || blotflag ) ? "i/o" : "input", 
				( coolflag || stirflag || blotflag ) ? rwiofilename : readfilename) ;
			vdterr (NULL) ;
			vdtend (-rfd) ;
		}
	}

	if (compflag || mimeflag) {
		compbuff = malloc ( tileflag ? (size_t)visblksiz : readspan ) ;

		if (compbuff == NULL) {
			vdterr ("no memory for comparison buffer") ;
			vdtend (-errno) ;
		}

		if ( mimeflag ) {
			cfd = VOPEN (writfilename, MODEIN, 0) ;
		} else {
			cfd = VOPEN (compfilename, MODEIN, 0) ;
		}

		if ( cfd < 0 ) {
			sprintf (errmsg, "can't open comparison file '%s'.", mimeflag ? writfilename : compfilename) ;
			vdterr (NULL) ;
			vdtend (-errno) ;
		}

		comperrs = 0 ;

		if ( fineflag ) {
			compsects = testsize / sectsize ;
			if ( testsize % sectsize ) {
				++compsects ;
			}
			if ( finelist == NULL ) {
				finelist = (off_t *) calloc ( (size_t) compsects , (size_t) sizeof (off_t) ) ;
				if (finelist == NULL) {
					vdterr ("no memory for matching sector list") ;
					vdtend (-errno) ;
				}
			}
			/*	memset ( finelist , 0x00 , compsects * sizeof (off_t) ) ;	*/
		} else {
			if ( groslist == NULL ) {
				groslist = (off_t *) calloc ( (size_t) visblkcnt , (size_t) sizeof (off_t) ) ;
				if (groslist == NULL) {
					vdterr ("no memory for matching B.o.S. list") ;
					vdtend (-errno) ;
				}
			}
			/*	memset ( groslist , 0x00 , visblkcnt * sizeof (off_t) ) ;	*/
		}
	}

	if (writflag) {
		if ( altbufsiz == 0 ) {
			if ( sectflag ) {
				writspan = sectsize ;
			} else {
				writspan = visblksiz ;
			}
		} else {
			writspan = altbufsiz ;
		}

		if (copyflag || mimeflag)
			writbuff = readbuff ;
		else
			writbuff = malloc ( tileflag ? (size_t)visblksiz : writspan ) ;

		if (writbuff == NULL) {
			vdterr ("no memory for output buffer") ;
			vdtend (-errno) ;
		}

		if ( syncflag )
			xtroutbit = O_SYNC ;

		if ( motiflag && ! stewflag ) {
			motifill ( writbuff , writspan ) ;
		}

		if ( access ( writfilename , F_OK ) == 0 ) {
			if ( makeflag ) {
				if ( forcflag ) {
					if ( razeflag )
						xtroutbit = O_TRUNC ;
					wfd = VOPEN (writfilename, MODEOUT|xtroutbit, 0) ;
				} else {
					sprintf (errmsg, "file '%s' exists!", writfilename) ;
					vdterr (NULL) ;
					vdtend (VER_NOWRITEX) ;
				}
			} else {
				if ( mimeflag ) {
					wfd = VOPEN (writfilename, MODEIO, 0) ;
				} else {
					wfd = VOPEN (writfilename, MODEOUT|xtroutbit, 0) ;
				}
			}
		} else {
			if ( mimeflag ) {
				sprintf (errmsg, "file '%s' does not exist!", writfilename) ;
				vdterr (NULL) ;
				vdtend (VER_NOIONAME) ;
			}
			wfd = VOPEN (writfilename, MODEZAP|xtroutbit, S_IRWXU) ;
		}

		if ( wfd < 0 ) {
			sprintf (errmsg, "can't open output file '%s'.", writfilename) ;
			vdterr (NULL) ;
			vdtend (-errno) ;
		}
	}

	if ( waitflag ) {
		linelapst = 3 ;
		lintstnam = 0 ;
		coltstnam = 1 ;
	} else {
		linelapst = 0 ;
		lintstnam = 1 ;
		coltstnam = 1 ;
	}

	if (blotflag)
		mvwaddstr (iwp, lintstnam, coltstnam, "blot") ;
	else if (coolflag)
		mvwaddstr (iwp, lintstnam, coltstnam, "cool") ;
	else if (stirflag)
		mvwaddstr (iwp, lintstnam, coltstnam, "stir") ;
	else if (makeflag)
		mvwaddstr (iwp, lintstnam, coltstnam, "make") ;
	else if (mimeflag)
		mvwaddstr (iwp, lintstnam, coltstnam, "mime") ;
	else if (copyflag)
		mvwaddstr (iwp, lintstnam, coltstnam, "copy") ;
	else if (compflag)
		mvwaddstr (iwp, lintstnam, coltstnam, "comp") ;
	else if (writflag)
		mvwaddstr (iwp, lintstnam, coltstnam, sectflag ? "poke" : "writ") ;
	else if (readflag)
		mvwaddstr (iwp, lintstnam, coltstnam, sectflag ? "seek" : "read") ;
	else
		mvwaddstr (iwp, lintstnam, coltstnam, "????") ;

	mvwaddstr (iwp, lintstnam, 7, getvdaddr(addrmode)) ;
	mvwaddstr (iwp, 2, 1, "         ") ;

	if ( syncflag )
		mvwaddstr (iwp, 2, 1, "sync") ;

	if ( randflag ) {
/*
		if ( fullflag )
			mvwaddstr (iwp, 2, 1, "full") ;
*/
		if ( uniqflag )
			mvwaddstr (iwp, 2, 7, "uniq") ;
	}

	if ( fineflag )
		mvwaddstr (iwp, 2, 1, "fine") ;

	if ( tileflag )
		mvwaddstr (iwp, 2, 1, "tile") ;

	if ( cookflag || burnflag || messflag || boilflag || brewflag ) {
		mvwaddstr (xwp, linmixnam, 4, getvdstress ()) ;
		wrefresh (xwp) ;
	}

	lastpercok = -1 ; quitloc = (time_t) 0 ; time ( &initloc ) ; gettimeofday (&initod, &tzb) ; lastloc = initloc ;

	if ( percflag ) {
		visblkpct = ( visblkcnt * ( flipflag ? 100 - usedperc : usedperc ) ) / 100 ;
		if ( visblkpct > visblkuse )
			visblkpct = visblkuse ;
	} else
		visblkpct = visblkcnt ;

	if ( timeflag ) {
		if ( wrapflag ) {
			passno = 0 ;
			if ( maxpass > 0 ) {
				mvwprintw ( xwp, 0, 1, "pass%d/%d", 1+passno , maxpass ) ;
			} else {
				mvwprintw ( xwp, 0, 2, "pass%d", 1+passno ) ;
			}
			wrefresh (xwp) ;
		}
		timedout = 0 ;
		if ( verbflag )
			mvwaddstr (iwp, linelapst, 2, "00:00:00") ;
#ifdef TOUTALRM
		signal (SIGALRM, vdtwake) ; alarm (declsecs) ;
#endif
	}

	wrefresh (iwp) ;

	for ( i = 0 ; (i < visblkcnt) || ( uniqflag && (hitz < visblkcnt) ) || ( timeflag && (! timedout) ) ; ++i ) {

		if ( redoflag )
			return ;

		if ( percflag )
			if ( hito >= visblkpct )
				if ( ! ( timeflag && wrapflag ) )
					break ;

		if ( timeflag ) {
			time ( &partloc ) ;
			if ( partloc - lastloc >= 1 ) {
				diftloc = partloc - initloc ;
				if ( verbflag && diftloc < SECPERDAY ) {
					mvwaddstr (iwp, linelapst, 2, strhms (diftloc)) ;
					wrefresh (iwp) ;
				}
				lastloc = partloc ;
				if ( diftloc >= declsecs )
					timedout = 1 ;
				if ( timedout )
					break ;
			}
		}

		if ( lifeflag ) {
			time ( &partloc ) ;
			if ( partloc - lastloc >= 1 ) {
				diftloc = riptloc - partloc ;
				if ( verbflag && diftloc < SECPERDAY ) {
					mvwaddstr (iwp, linelapst, 2, strhms (diftloc)) ;
					wrefresh (iwp) ;
				}
				lastloc = partloc ;
				if ( diftloc <= 0 ) {
					lifeflag = 0 ; ++goneflag ;
					if ( ! boonflag ) {
						break ;
					}
				}
			}
		}

		if ( termflag )
			break ;

		if ( hito >= visblkpct ) {
			if ( timeflag ) {
				if ( wrapflag ) {
					++passno ;
					if ( maxpass > 0 && passno >= maxpass )
						break ;
					hito = hitz = 0 ; i = lastpercok = -1 ;
					if ( verbflag ) {
						moresize = testsize ;
					}
					for ( j = 0 ; j < visblkcnt ; ++j ) {
						percok = ( moresize * 100 ) / testsize ;
						if ( percok != lastpercok ) {
							percy = ( 10 * percok ) / 100 ;
							if ( percy ) {
								mvwprintw (pwp, 11-percy, 1, "%3d %% %s", percok, (char *) vdtkmgtpe (moresize?moresize:1)) ;
								wrefresh (pwp) ; lastpercok = percok ;
							}
						}
						if ( moresize >= visblksiz ) {
							moresize -= visblksiz ;
						}
						if ( (visblklst+j)->vbd_flags & VBF_USEFUL ) {
							(visblklst+j)->vbd_hits = 0 ;	/* toggles passno vs. hittab */
							(visblklst+j)->vbd_flags &= ~(VBF_READOK | VBF_WRITOK | VBF_JUMPOK | VBF_SEEKOK | VBF_PEEKOK | VBF_RIFFOK) ;
						}
					}
					if ( maxpass > 0 ) {
						mvwprintw ( xwp, 0, 1, "pass%d/%d", 1+passno , maxpass ) ;
					} else {
						mvwprintw ( xwp, 0, 2, "pass%d", 1+passno ) ;
					}
					wrefresh (xwp) ;
					continue ;
				} else {
					if ( ! randflag )
						break ;
				}
			} else {
				break ;
			}
		}

		if ( visblklim )
			if ( (off_t)i >= visblklim )
				break ;

		if ( killsize )
			if ( (off_t) ( i * ( readflag ? readspan : writspan ) /* visblksiz */ ) >= killsize )
				break ;

		switch ( addrmode ) {
			case VDT_INCR : lbp = visblklst + i ;	/* NEXTINCRADDR */		break ;
			case VDT_DECR : lbp = visblklst + NEXTDECRADDR (i, visblkcnt) ; break ;
			case VDT_SCAT : lbp = visblklst + NEXTSCATADDR (i, visblkcnt) ; break ;
			case VDT_CONV : lbp = visblklst + NEXTCONVADDR (i, visblkcnt) ; break ;
			case VDT_SPOT : lbp = visblklst + NEXTSPOTADDR (i, visblkcnt) ; break ;
			case VDT_GOLD : lbp = visblklst + NEXTGOLDADDR (i, visblkcnt) ; break ;
			case VDT_RAND : lbp = visblklst + NEXTRANDADDR (i, visblkcnt) ; break ;
# ifdef SLICADDR
			else if ( serislicflag ) lbp = visblklst + NEXTSERISLICADDR (i, visblkcnt) ;
			else if ( distslicflag ) lbp = visblklst + NEXTDISTSLICADDR (i, visblkcnt) ;
# endif
			default : lbp = visblklst + i ; /* NEXTINCRADDR */ break ;
		}

		if ( lbp < visblklst )
			lbp = visblklst /* continue */ ;

		if ( ! ( lbp->vbd_flags & VBF_USEFUL ) )
			goto updpct ;

		if ( uniqflag && ( lbp->vbd_flags & ( VBF_READOK | VBF_RIFFOK | VBF_WRITOK ) ) ) {
			goto updpct ;
		}

		if ( timeflag && wrapflag && passno & 0x01 )
			wstandout (bwp) ;

		if ( randflag && ( lbp->vbd_flags & ( VBF_READOK | VBF_RIFFOK | VBF_WRITOK ) ) ) {
			if ( uniqflag && (lbp->vbd_hits == 1) ) {
				goto updpct ;
			}
			++hitz ;
			lbp->vbd_hits += 1 ;
			if ( cloyflag ) {
				if ( lbp->vbd_hits <= hittablen ) {
					mvwaddch ( bwp, lbp->vbd_lin, lbp->vbd_col, hittab [ lbp->vbd_hits - 1 ] ) ;
				}
			}
			if ( glibflag ) {
				if ( ( lbp->vbd_hits / hittablen ) & 0x01 ) {
					wstandout (bwp) ; mvwaddch ( bwp, lbp->vbd_lin, lbp->vbd_col, hittab [ lbp->vbd_hits % hittablen ] ) ; wstandend (bwp) ;
				} else {
					mvwaddch ( bwp, lbp->vbd_lin, lbp->vbd_col, hittab [ lbp->vbd_hits % hittablen ] ) ;
				}
			}
			if ( snagflag ) {
				if ( ( mvwinch ( bwp , lbp->vbd_lin , lbp->vbd_col ) & A_CHARTEXT ) != '0' ) {
					if ( hitround & 0x01 ) {
						wstandout (bwp) ; mvwaddch ( bwp, lbp->vbd_lin, lbp->vbd_col, hittab [ lbp->vbd_hits % hittablen ] ) ; wstandend (bwp) ;
					} else {
						mvwaddch ( bwp, lbp->vbd_lin, lbp->vbd_col, hittab [ lbp->vbd_hits % hittablen ] ) ;
					}
				} else {
					if ( ( lbp->vbd_hits % hittablen ) == 0 )
						++hitcount ;
					if ( hitcount >= visblkpct ) {
						++hitround ; hitcount = 0 ;
						for ( j = 0 ; j < visblkcnt ; ++j ) {
							if ( (visblklst+j)->vbd_flags & VBF_USEFUL ) {
								mvwaddch ( bwp, (visblklst+j)->vbd_lin, (visblklst+j)->vbd_col, ' ' ) ;
							}
						} wrefresh (bwp) ;
					}
				}
			}
			wrefresh (bwp) ;
			if ( biasflag /* ! timeflag */ )	/*	skip cached clumps	*/
				goto updpct ;
		}

		visblkrnd = 0 ;
		if ( fullflag && visblksects ) {
			visblkrnd = vdtrand() % visblksects ;
		}
/*								 _______________________________________
 *								|_______seek_to_read_from_1st_file______|
 */
		if ( readflag ) {
			if ( sectflag ) {
				ofs = VSEEK (rfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
			} else {
				gettimeofday (&tod5, &tzb) ;
				ofs = VSEEK (rfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
				gettimeofday (&tod6, &tzb) ;
				vdtacct (SPECTABXSEEK, &tod5, &tod6, -1L) ;
			}
			if (ofs == (off_t) -1) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'S') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			lbp->vbd_flags |= VBF_SEEKOK ;
		}
/*								 _______________________________________
 *								|_______seek_to_read_from_2nd_file______|
 */
		if ( compflag || mimeflag ) {
			if ( sectflag ) {
				ofs = VSEEK (cfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
			} else {
				gettimeofday (&tod15, &tzb) ;
				ofs = VSEEK (cfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
				gettimeofday (&tod16, &tzb) ;
				vdtacct (SPECTABXPEEK, &tod15, &tod16, -1L) ;
			}
			if (ofs == (off_t) -1) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'P') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			lbp->vbd_flags |= VBF_PEEKOK ;
		}
								/* seek to write on output file			*/
		if ( writflag ) {
			if ( sectflag ) {
				ofs = VSEEK (wfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
			} else {
				gettimeofday (&tod15, &tzb) ;
				ofs = VSEEK (wfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
				gettimeofday (&tod16, &tzb) ;
				vdtacct (SPECTABXJUMP, &tod15, &tod16, -1L) ;
			}
			if (ofs == (off_t) -1) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'J') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			lbp->vbd_flags |= VBF_JUMPOK ;
		}
/*								 _______________________________________
 *								|__________read_from_1st_file___________|
 */
		if ( readflag ) {
			if ( lbp->vbd_flags & VBF_SCRAPS ) {
				readsize = lbp->vbd_size ;
				if ( readsize > readspan ) {
					readsize = readspan ;
				}
			} else {
				readsize = readspan ;
			}
			if ( tileflag ) {
				tilebufs = readsize / altbufsiz ;
				if ( readsize % altbufsiz )
					++tilebufs ;
				for ( ci = badtiles = 0 , readsptr = readbuff ; ci < tilebufs ; ++ci , readsptr += altbufsiz ) {
					gettimeofday (&tod1, &tzb) ;
					rd = VREAD (readsptr, 1, altbufsiz, rfd) ;
					gettimeofday (&tod2, &tzb) ;
					vdtacct (copyflag || compflag || coolflag || mimeflag || stirflag || blotflag ? SPECTABXREAD : specindx, &tod1, &tod2, (long)altbufsiz) ;
					if (rd < 0) {
						badtiles = 'r' ;
						break ;
					}
					if ((size_t)rd != altbufsiz) {
						if ((size_t)rd != (readsize % altbufsiz)) {
							badtiles = 'z' ;
							break ;
						}
					}
				}
				if ( badtiles ) {
					mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, badtiles) ;
					wrefresh (bwp) ;
					goto updpct ;
				}
			} else {
				gettimeofday (&tod1, &tzb) ;
				rd = VREAD (readbuff, 1, readsize, rfd) ;
				gettimeofday (&tod2, &tzb) ;
				vdtacct (copyflag || compflag || coolflag || mimeflag || stirflag || blotflag ? SPECTABXREAD : specindx, &tod1, &tod2, (long)readsize) ;
				if (rd < 0) {
					mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'R') ;
					wrefresh (bwp) ;
					goto updpct ;
				}
				if ((size_t)rd != readsize) {
					mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'Z') ;
					wrefresh (bwp) ;
					goto updpct ;
				}
			}
			lbp->vbd_flags |= VBF_READOK ;
		}
/*								 _______________________________________
 *								|__________read_from_2nd_file___________|
 */
		if ( compflag || mimeflag ) {
			if ( mimeflag ) {
				compbuff[0] = 0x00 ;
			}
			gettimeofday (&tod11, &tzb) ;
			rd = VREAD (compbuff, 1, readsize, cfd) ;
			gettimeofday (&tod12, &tzb) ;
			vdtacct (SPECTABXRIFF, &tod11, &tod12, (long)readsize) ;
			if (rd < 0) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'I') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			if ((size_t)rd != readsize) {
				if ( ! mimeflag ) {
					mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'Y') ;
					wrefresh (bwp) ;
					goto updpct ;
				}
			}
			lbp->vbd_flags |= VBF_RIFFOK ;
/*							 ___________________________________________
 *							|________compare 1st and 2nd buffers________|
 */
			cmpres = 0 ;
			if ( fineflag ) {
				readsects = readsize / sectsize ;
				compsize = readsize % sectsize ;
				if ( compsize ) {
					++readsects ;
				} else {
					compsize = sectsize ;
				}
				for ( ci = 0 , readsptr = readbuff , compsptr = compbuff ; ci < readsects ; ++ci , readsptr += sectsize , compsptr += sectsize ) {
					if ( 0 != memcmp ( readsptr , compsptr , compsize ) ) {
						cmpres += 1 ;
						finelist [ comperrs++ ] = lbp->vbd_addr + ( ci * sectsize ) ;
						/* FIXME: vec[readsects] = save to write(fine-mime) */
					}
				}
			} else {
				if ( 0 != memcmp ( readbuff , compbuff , readsize ) ) {
					cmpres = 1 ;
					groslist [ comperrs++ ] = lbp->vbd_addr ;
				}
			}
			if ( 0 != cmpres ) {
				vdtacct ( SPECTABXCOMP, &tod1, &tod12, (long) ( readsize + ( dualflag ? readsize : 0 ) ) ) ;
				if ( fineflag /* && verbflag */ ) {
					/* FIXME: calc % dirty , mvwaddch '0'..'9' */
					mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, '%') ;
				} else {
					mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, '#') ;
				}
				wrefresh (bwp) ;
				if ( ! mimeflag ) {
					goto updpct ;
				}
			} else {
				vdtacct ( SPECTABXCOMP, &tod1, &tod12, (long) ( readsize + ( dualflag ? readsize : 0 ) ) ) ;
				goto updone ;
			}
		}
/*							 ___________________________________________
 *							|_______seek_to_write_back_on_1st_file______|
 */
		if ( coolflag || stirflag || blotflag ) {
			if ( stirflag ) {
				olin = lbp->vbd_lin ; ocol = lbp->vbd_col ;
				lbp = visblklst + NEXTRANDADDR (i, visblkcnt) ;
				visblkrnd = 0 ;
				if ( fullflag && visblksects ) {
					visblkrnd = vdtrand() % visblksects ;
				}
			}
			if ( sectflag ) {
				ofs = VSEEK (rfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
			} else {
				gettimeofday (&tod15, &tzb) ;
				ofs = VSEEK (rfd, visblkrnd + lbp->vbd_addr, SEEK_SET) ;
				gettimeofday (&tod16, &tzb) ;
				vdtacct (SPECTABXJUMP, &tod15, &tod16, -1L) ;
			}
			if (ofs == (off_t) -1) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'J') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			lbp->vbd_flags |= VBF_JUMPOK ;
/*									 ___________________________________
 *									|_______write_back_to_1st_file______|
 */
			writbuff = readbuff ;
			writsize = readsize ;
			if ( blotflag )
				blotbuff ( writbuff ) ;
			gettimeofday (&tod11, &tzb) ;
			rd = VWRITE (writbuff, 1, writsize, rfd) ;
			gettimeofday (&tod12, &tzb) ;
			vdtacct (SPECTABXWRIT, &tod11, &tod12, (long)writsize) ;
			if (rd < 0) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'W') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			if ((size_t)rd != writsize) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'Z') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			lbp->vbd_flags |= VBF_WRITOK ;
			vdtacct ( blotflag ? SPECTABXBLOT : stirflag ? SPECTABXSTIR : SPECTABXCOOL, &tod1, &tod12, (long) ( writsize + ( dualflag ? readsize : 0 ) ) ) ;
		}
								/* write to output file					*/
		if ( writflag ) {
			if ( copyflag || mimeflag ) {
				writsize = readsize ;
			} else {
				if ( lbp->vbd_flags & VBF_SCRAPS ) {
					writsize = lbp->vbd_size ;
					if ( writsize > writspan ) {
						writsize = writspan ;
					}
				} else {
					writsize = writspan ;
				}
			}
			if ( stewflag && ! readflag ) {	/*	FIXME: averflag implies readflag..	*/
				setmotif () ;
				motifill ( writbuff , writspan ) ;
			}
			gettimeofday (&tod11, &tzb) ;
				/* FIXME: if ( fine ) { seek(vec[readsects]) ; write(&writbuff[ci*sectsize],sectsize) ; } else ... */
			rd = VWRITE (writbuff, 1, writsize, wfd) ;
			gettimeofday (&tod12, &tzb) ;
			vdtacct (sectflag ? SPECTABXJUMP : SPECTABXWRIT, &tod11, &tod12, (long)writsize) ;
			if (rd < 0) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'W') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			if ((size_t)rd != writsize) {
				mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'Z') ;
				wrefresh (bwp) ;
				goto updpct ;
			}
			lbp->vbd_flags |= VBF_WRITOK ;
			if (copyflag) { /* FIXME: should be compound(acctREAD,acctWRIT) */
				vdtacct ( SPECTABXCOPY, &tod1, &tod12, (long) ( writsize + ( dualflag ? readsize : 0 ) ) ) ;
			} else if (mimeflag) { /* FIXME: should be compound(acctREAD,acctWRIT) */
				vdtacct ( SPECTABXMIME, &tod1, &tod12, (long) ( writsize + ( dualflag ? readsize : 0 ) ) ) ;
			}
		}

		if ( randflag && (! biasflag) /* timeflag */ && lbp->vbd_hits >= 1 )	/*	skip cached clumps	*/
			goto updpct ;
/*												 _______________________
 *												|_______bullseye_!______|
 */
updone:
		if ( stirflag ) {
			mvwaddch (bwp, olin, ocol, 'o') ;
			mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, '+') ;
		} else if ( mimeflag && cmpres ) {
			mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, '=') ;
		} else {
			mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, 'o') ;
		}
		wrefresh (bwp) ;

		++hito ;
updpct:
		if ( timeflag && wrapflag && passno & 0x01 )
			wstandend (bwp) ;
		percok = ( (i+1) * 100 ) / visblkcnt ;
		if ( percok != lastpercok ) {
			percy = percok % 10 ? 1+(percok/10) : (percok/10) ;
			if ( percy ) {
				if ( percok <= 100 ) {
					sprintf ( pwpbuf, "%3d %% %s", percok, (char *) vdtkmgtpe ( (long long) (i+1) * (long long) visblksiz ) ) ;
					pwprev = ( percok % 10 ) ;
					if ( pwprev || ( ! verbflag ) ) {
							wstandout (pwp) ;
							mvwaddnstr (pwp, 11-percy, 1, pwpbuf, pwprev) ;
							wstandend (pwp) ;
							waddstr (pwp, pwpbuf+pwprev) ;
					} else {
							wstandout (pwp) ;
							mvwaddstr (pwp, 11-percy, 1, pwpbuf) ;
							wstandend (pwp) ;
					}
				} else {
					sprintf ( pwpbuf, "%s%% ", (char *) vdtkmgtpe ( (long long) percok ) ) ;
					mvwaddstr (pwp, 1, 1, pwpbuf) ;
					sprintf ( pwpbuf, "%s", (char *) vdtkmgtpe ( (long long) (i+1) * (long long) visblksiz ) ) ;
					mvwaddstr (pwp, 1, 7, pwpbuf) ;
				}
				wrefresh (pwp) ; lastpercok = percok ;
			}
			if (copyflag || compflag || coolflag || mimeflag || stirflag || blotflag) {
				mvwprintw ( xwp, 2, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXREAD].vdm_prf.vdp_avg) ) ) ;
			}
			if (copyflag) {
				mvwprintw ( xwp, 3, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXWRIT].vdm_prf.vdp_avg) ) ) ;
				mvwprintw ( xwp, 4, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXCOPY].vdm_prf.vdp_avg) ) ) ;
			} else if (blotflag) {
				mvwprintw ( xwp, 3, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXWRIT].vdm_prf.vdp_avg) ) ) ;
				mvwprintw ( xwp, 4, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXBLOT].vdm_prf.vdp_avg) ) ) ;
			} else if (coolflag) {
				mvwprintw ( xwp, 3, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXWRIT].vdm_prf.vdp_avg) ) ) ;
				mvwprintw ( xwp, 4, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXCOOL].vdm_prf.vdp_avg) ) ) ;
			} else if (mimeflag) {
				mvwprintw ( xwp, 3, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXWRIT].vdm_prf.vdp_avg) ) ) ;
				mvwprintw ( xwp, 4, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXMIME].vdm_prf.vdp_avg) ) ) ;
			} else if (stirflag) {
				mvwprintw ( xwp, 3, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXWRIT].vdm_prf.vdp_avg) ) ) ;
				mvwprintw ( xwp, 4, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXSTIR].vdm_prf.vdp_avg) ) ) ;
			} else if (compflag) {
				mvwprintw ( xwp, 3, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXRIFF].vdm_prf.vdp_avg) ) ) ;
				mvwprintw ( xwp, 4, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * vdtspec[SPECTABXCOMP].vdm_prf.vdp_avg) ) ) ;
			} else {
				mvwprintw ( xwp, 2, 1, "%10.6f", (double) (tip->vdm_avg / 1000000.0) ) ;
				if ( ! sectflag )
					mvwprintw ( xwp, 4, 5, "%s/s", vdtkmgtpe ( (long long) (1000000.0 * tip->vdm_prf.vdp_avg) ) ) ;
			}
			wrefresh (xwp) ;
		}
		chkpnt = i ; testedok = hito ;
	} /* end of for ( main loop ) */

	time ( &quitloc ) ; gettimeofday (&quitod, &tzb) ;
	netelap = diftod ( &initod , &quitod ) ;
	diftloc = quitloc - initloc ;

	/* random cache hits */

	if ( randflag ) {
		randhitp = /* hytp = */ ( hitz * 100 ) / visblkcnt ;
		if ( uniqflag )
			randextr = (i-visblkcnt) ;
	}

	/* cleanups */

	if ( readflag ) {
		VCLOSE (rfd) ;
		if ( readbuff != NULL ) {
			free (readbuff) ;
			readbuff = NULL ;
		}
	}
	if ( compflag ) {
		VCLOSE (cfd) ;
		if ( compbuff != NULL ) {
			free (compbuff) ;
			compbuff = NULL ;
		}
	}
	if ( writflag ) {
		VCLOSE (wfd) ;
		if ( ! ( copyflag || mimeflag ) ) {
			free (writbuff) ;
			writbuff = NULL ;
		}
	}

	vdtreport (NULL) ;

	if ( waitflag ) {							/* pause */
		mvwaddstr (iwp, 1, 1, " Hit      ") ;
		mvwaddstr (iwp, 2, 1, "[Enter]   ") ;
		wrefresh (iwp) ;
		wmove (iwp, 2, 9) ;
		wgetch (iwp) ;
	}

	/* repaint */

	if ( verbflag ) {
		moresize = testsize ;
		lastpercok = -1 ;
	}
	for ( i = 0 ; i < visblkcnt ; ++i ) {
		percok = ( moresize * 100 ) / testsize ;
		if ( percok != lastpercok ) {
			percy = ( 10 * percok ) / 100 ;
			if ( percy ) {
				mvwprintw (pwp, 11-percy, 1, "%3d %% %s", percok, (char *) vdtkmgtpe (moresize?moresize:1)) ;
				wrefresh (pwp) ;
				lastpercok = percok ;
			}
		}
		if ( moresize >= visblksiz ) {
			moresize -= visblksiz ;
		}
		if ( (visblklst+i)->vbd_flags & VBF_USEFUL ) {
			mvwaddch (bwp, (visblklst+i)->vbd_lin, (visblklst+i)->vbd_col, '.') ;
			(visblklst+i)->vbd_hits = 0 ;
			(visblklst+i)->vbd_flags &= ~(VBF_READOK | VBF_WRITOK | VBF_JUMPOK | VBF_SEEKOK | VBF_PEEKOK | VBF_RIFFOK) ;
		}
	}
	wrefresh (bwp) ;
	wborder (xwp, 0, 0, 0, 0, 0, 0, 0, 0) ;
	wrefresh (xwp) ;
}

/*	__	__	__	__	__	__	__	__	*/

off_t vdtdevsiz (name) char * name ; {

	int rd ;
	off_t devsiz = 0 ;

	if ( ( rd = open (name, O_RDONLY) ) < 0 )
		vdtend (-errno) ;
/*												 _______________________
 *												|_______AIX_____________|
 */
#ifdef AIX
		if ( ioctl (rd, IOCINFO, &devinfbuf) < 0 )
			vdtend (-errno) ;
		switch (devinfbuf.devtype) {
			case DD_DISK:
				devsiz = (off_t)devinfbuf.un.dk.segment_size * devinfbuf.un.dk.segment_count;
			break;
			case DD_SCDISK: /* scsi */
				devsiz = (off_t)devinfbuf.un.scdk.blksize * devinfbuf.un.scdk.numblks;
			break;
			default:
				devsiz = 0;
			break;
		}   
		if ( devsiz == 0 && ( devinfbuf.devsubtype == DS_LV || devinfbuf.devsubtype == DS_LVZ ) ) {
			if ( ioctl (rd, LV_INFO, &lv_infbuf) < 0 )
				vdtend (-errno) ;
			devsiz = (off_t)sectsize * lv_infbuf.num_blocks;
		}
#endif
/*												 _______________________
 *												|_______HPUX____________|
 */
#ifdef HPUX
		if ( ioctl (rd, SIOC_CAPACITY, &capinfbuf) < 0 ) {
			if ( ioctl (rd, DIOC_CAPACITY, &dskcapbuf) < 0 ) {
				vdtend (-errno) ;
			} else {
				if ( ioctl (rd, DIOC_DESCRIBE, &dskdesbuf) < 0 ) {
					vdtend (-errno) ;
				} else {
					devsiz = (off_t)dskdesbuf.lgblksz * (off_t)dskcapbuf.lba ;
					setaltsecsiz ( (int)dskdesbuf.lgblksz ) ;
				}
			}
		} else {
			devsiz = (off_t)capinfbuf.lba * capinfbuf.blksz ;
			setaltsecsiz ( (int)capinfbuf.blksz ) ;
		}
#endif
/*												 _______________________
 *												|_______LINUX___________|
 */
#ifdef LINUX
		if ( ioctl (rd, BLKGETSIZE, &devsiz) < 0 )
			vdtend (-errno) ;
		devsiz *= DFLSECSIZ ;
#endif
/*												 _______________________
 *												|_______FREEBSD_________|
 */
#ifdef FREEBSD
		if ( ioctl (rd, DIOCGMEDIASIZE, &devsiz) < 0 )
			vdtend (-errno) ;
#endif
/*												 _______________________
 *												|_______OPENBSD_________|
 */
/*												 _______________________
 *												|_______NETBSD__________|
 */
#if defined ( OPENBSD ) || defined ( NETBSD )
    	if (ioctl (rd, DIOCGDINFO, &dsklabbuf))
			vdtend (-errno) ;
#	ifdef SPLITSIZ
    	devsiz = (off_t) ( dsklabbuf.d_ncylinders * dsklabbuf.d_ntracks * dsklabbuf.d_nsectors ) * DFLSECSIZ ;
#	else
    	devsiz = (off_t)dsklabbuf.d_secperunit * DFLSECSIZ ;
#	endif
#endif
/*												 _______________________
 *												|_______SUNX____________|
 */
#ifdef SUNX
#	ifdef USE_MEDINF
		if ( ioctl (rd, DKIOCGMEDIAINFO, &medinfbuf) < 0 )
			vdtend (-errno) ;
		devsiz = (off_t)medinfbuf.dki_capacity * medinfbuf.dki_lbsize ;
#	endif
#	ifdef USE_DSKGEO
		if ( ioctl (rd, DKIOCGGEOM, &dskgeobuf) < 0 )
			vdtend (-errno) ;
		devsiz = (off_t)dskgeobuf.dkg_ncyl * dskgeobuf.dkg_nhead * dskgeobuf.dkg_nsect * DFLSECSIZ ;
#	endif
#endif
/*												 _______________________
 *												|_______APPLE___________|
 */
#ifdef APPLE
    	if ( ioctl (fd, DKIOCGETBLOCKSIZE, &aplblksiz) < 0 ) {
			vdtend (-errno) ;
    	if ( ioctl (fd, DKIOCGETBLOCKCOUNT, &aplblkcnt) < 0 ) {
			vdtend (-errno) ;
    	devsiz = (off_t)aplblkcnt * aplblksiz ;
#endif
	close (rd) ;
	return devsiz ;
}

/*	__	__	__	__	__	__	__	__	*/

off_t vdtgetsiz (name) char * name ; {

	int rd ;

	rd = VSTAT (name, &sb) ;

	if ( rd != 0 ) {
		if ( ! makeflag ) {
			rd = errno ;
			sprintf (errmsg, "can't get size of file '%s'", name) ;
			vdterr (NULL) ;
			vdtend (-rd) ;
		}
	}

	if ( S_ISCHR (sb.st_mode) || S_ISBLK (sb.st_mode) ) {
		return vdtdevsiz (name) ;
	} else {
		return (off_t) sb.st_size ;
	}
}

/*	__	__	__	__	__	__	__	__	*/

void vdtmain () {

	int notlen = 0 , coletc = 25 ;

	clear () ; border (0, 0, 0, 0, 0, 0, 0, 0) ; mvaddstr (0, 3, swid) ; mvaddstr (0, 6, SWVERS) ;
	if ( verbflag > 1 && *swfn != '$' )
		addstr (swfn) ;
	if ( noteflag ) {
		notlen = strlen ( notebuff ) ;
		if ( notlen > (wscols / 4) ) {
			notlen = (wscols / 4) ;
		}
		mvaddnstr ( 0 , ( wscols - ( 3 + notlen ) ) , notebuff , notlen ) ;
	}
	refresh () ;

	/* FIXME: store separate sizes (read,comp,writ,rwio) */

	if ( coolflag || stirflag || blotflag ) {
		filesize = vdtgetsiz (rwiofilename) ;
	} else if ( readflag ) {
		filesize = vdtgetsiz (readfilename) ;
	} else if ( writflag ) {
		filesize = vdtgetsiz (writfilename) ;
	} else {
		filesize = 0 ;
	}

	if (declsize == 0)
		testsize = filesize ;
	else
		testsize = declsize ;

	if ( testsize <= 0 || ( ( filesize > 0 && testsize > filesize ) && ! makeflag ) ) {
		sprintf (errmsg, "invalid test size (%lld) for file size (%lld)", (long long)testsize, (long long)filesize) ;
		vdterr (NULL) ;
		vdtend (VER_BADTSTSZ) ;
	}

	/* FIXME: validate sizes for copy & compare */

	if ( strpflag ) {
		skipcnt = stripcnt - 1 ;
	}

	if ( evenflag ) {
		++percflag ;
		if ( strpflag ) {
			declperc = ( 100 / ( stripcnt + skipcnt ) ) * stripcnt ;
		} else {
			if ( slabflag ) {
				declperc = 60 ;
			} else {
				if ( edgeflag ) {
					if ( coreflag ) {
						++slabflag ;
						declperc = 60 ;
					} else {
						declperc = 66 ;
					}
				} else {
					if ( coreflag ) {
						if ( headflag || tailflag ) {
							if ( headflag && tailflag ) {
								++edgeflag ;
								declperc = 60 ;
							} else {
								declperc = 66 ;
							}
						} else {
							declperc = 33 ;
						}
					} else {
						if ( headflag && tailflag ) {
							++edgeflag ;
							declperc = 66 ;
						} else {
							if ( headflag || tailflag ) {
								declperc = 50 ;
							}
						}
					}
				}
			}
		}
		usedperc = justperc = declperc ;
	}

	if ( percflag ) {
		if ( edgeflag ) {
			if ( coreflag ) {
				if ( declperc < 3 )
					{ declperc = 3 ; }
				rgonperc = declperc /= 3 ;
				usedperc = justperc = rgonperc * 3 ;
			} else {
				if ( declperc & 0x01 ) {
					if ( declperc == 1 )
						{ ++declperc ; }
					else
						{ --declperc ; }
				}
				rgonperc = declperc /= 2 ;
				usedperc = justperc = rgonperc * 2 ;
			}
		} else
			{ rgonperc = declperc ; }
		percsize = ( testsize * declperc ) / 100 ;
		if ( headflag ) {
			headsize = percsize ;
		}
		if ( tailflag ) {
			tailsize = testsize - percsize ;
		}
		if ( coreflag ) {
			corehead = ( testsize - percsize ) / 2 ;
			coretail = corehead + percsize ;
		}
	}

	if ( strpflag ) {
		strparea = percsize ;
		skiparea = testsize - strparea ;
		strpsize = strparea / stripcnt ;
		skipsize = skiparea / skipcnt ;
		for ( stripinx = 0 ; stripinx < stripcnt ; ++stripinx ) {
			strpbase[stripinx] = stripinx * ( strpsize + skipsize ) ;
		}
	}

	warea = avrows * avcols ;

	if ( ( testsize % warea ) == 0 )
		wdens = testsize / warea ;
	else
		wdens = testsize / ( warea - 1 ) ;

	visblksiz = wdens ;

	if ( tileflag ) {
		if ( altbufsiz != 0 ) {
			if ( altbufsiz % visblksiz ) {
				vdtend (VER_INVBUFSZ) ;
			}
		}
	}

	if ( visblksiz < MINVISBLKSIZ ) {
		visblksiz = MINVISBLKSIZ ;
		visblksects = 0 ;
	} else {
		visblksiz = lceilp2 (visblksiz) ;
		visblksects = visblksiz / sectsize ;
	}

/*	bwp = newwin (18, 66, 1, 1) ;	*/
	bwp = newwin (BW_HEI, BW_WID, BW_LIN, BW_COL) ;
	wborder (bwp, 0, 0, 0, 0, 0, 0, 0, 0) ;
	wrefresh (bwp) ;

/*	pwp = newwin (12, 12, 1, 67) ;	*/
	pwp = newwin (PW_HEI, PW_WID, PW_LIN, PW_COL) ;
	wborder (pwp, 0, 0, 0, 0, 0, 0, 0, 0) ;
	wrefresh (pwp) ;

	if (copyflag || coolflag || mimeflag || stirflag || blotflag) {
		/* xwp = newwin (6, 12, 13, 67) ; */
		xwp = newwin (6, XW_WID, XW_LIN, XW_COL) ;
		mvwprintw (xwp, 1, 1, "%s %s",  /* "read" */ "avg.", "speed") ;
		mvwprintw (xwp, 2, 1, "%s ", "in ") ;
		mvwprintw (xwp, 3, 1, "%s ", "out") ;
		mvwprintw (xwp, 4, 1, "%s ", "i/o") ;
	} else if (compflag) {
		/* xwp = newwin (6, 12, 13, 67) ; */
		xwp = newwin (6, XW_WID, XW_LIN, XW_COL) ;
		mvwprintw (xwp, 1, 1, "%s %s",  /* "read" */ "avg.", "speed") ;
		mvwprintw (xwp, 2, 1, "%s ", "in1") ;
		mvwprintw (xwp, 3, 1, "%s ", "in2") ;
		mvwprintw (xwp, 4, 1, "%s ", "cmp") ;
	} else {
		if ( sectflag ) {
			/* xwp = newwin (4, 12, 13, 67) ; */
			xwp = newwin (4, XW_WID, XW_LIN, XW_COL) ;
			mvwprintw (xwp, 1, 1, "%s  %s", /* "seek" */ "avg.", "time") ;
		} else {
			/* xwp = newwin (6, 12, 13, 67) ; */
			xwp = newwin (6, XW_WID, XW_LIN, XW_COL) ;
			mvwprintw (xwp, 1, 1, "%s  %s", /* "read" */ "avg.", "time") ;
			mvwprintw (xwp, 3, 1, "%s %s",  /* "read" */ "avg.", "speed") ;
		}
	}
	wborder (xwp, 0, 0, 0, 0, 0, 0, 0, 0) ;
	wrefresh (xwp) ;

/*	swp = newwin (4, 66, 19, 1) ;	*/
	swp = newwin (SW_HEI, SW_WID, SW_LIN, SW_COL) ;
	wborder (swp, 0, 0, 0, 0, 0, 0, 0, 0) ;
	wrefresh (swp) ;

/*	iwp = newwin (4, 12, 19, 67) ;	*/
	iwp = newwin (IW_HEI, IW_WID, IW_LIN, IW_COL) ;
	wborder (iwp, 0, 0, 0, 0, 0, 0, 0, 0) ;
	wrefresh (iwp) ;

	wmove (swp, 1, 1) ;

	if ( copyflag || mimeflag ) {
		waddch (swp, '<') ;
		waddnstr (swp, readfilename, SW_WID-3) ;
		wmove (swp, 2, 1) ;
		waddch (swp, '>') ;
		waddnstr (swp, writfilename, SW_WID-3) ;
	} else if ( compflag ) {
		waddch (swp, '<') ;
		waddnstr (swp, readfilename, SW_WID-3) ;
		wmove (swp, 2, 1) ;
		waddch (swp, '<') ;
		waddnstr (swp, compfilename, SW_WID-3) ;
	} else if ( coolflag || stirflag || blotflag ) {
		waddch (swp, '+') ;
		waddnstr (swp, rwiofilename, SW_WID-3) ;
	} else {
		if ( readflag ) {
			waddch (swp, '<') ;
			waddnstr (swp, readfilename, SW_WID-3) ;
		} else if ( writflag ) {
			waddch (swp, '>') ;
			waddnstr (swp, writfilename, SW_WID-3) ;
		}
	}

	if ( copyflag || compflag || mimeflag )
		linsizloc = 3 ;
	else
		linsizloc = 2 ;

	wmove (swp, linsizloc, 1) ;

	if ( percflag ) {
		wprintw (swp, flipflag ? "~%d%%" : "%d%%", ( flipflag ? 100 - usedperc : usedperc ) ) ;
		if ( strpflag ) {
			if ( flipflag )
				wprintw (swp, "]%dx%s[", skipcnt  , (char *) skipspac ( vdtkmgtpe ( (long long) skipsize ) ) ) ;
			else
				wprintw (swp, "[%dx%s]", stripcnt , (char *) skipspac ( vdtkmgtpe ( (long long) strpsize ) ) ) ;
		}
		if ( headflag || tailflag || coreflag || edgeflag || slabflag ) {
			if ( flipflag )
				wprintw (swp, ")%s(", getvdarea()) ;
			else
				wprintw (swp, "(%s)", getvdarea()) ;
		}
		if ( copyflag || compflag || mimeflag )
			wprintw (swp, "-of-") ;
		else
			wprintw (swp, " of ") ;
	}
	wprintw ( swp, "%s", (char *) skipspac ( vdtkmgtpe ((long long)testsize) ) ) ;
	wrefresh (swp) ;

	/* preset vis.blk entries */

	visblkcnt = visblkuse = 0 ;
	brow = bcol = 1 ;
	moresize = testsize ;
	lastpercok = -1 ;

	while ( moresize > 0 ) {

		if ( visblklst == NULL ) {
			visblklst = (VISBLKDAT *) malloc (VISBLKDATSIZ) ;
		} else {
			visblklst = (VISBLKDAT *) realloc (visblklst, (visblkcnt+1)*VISBLKDATSIZ) ;
		}

		if ( visblklst == NULL )
			vdtend (-errno) ;

		lbp = visblklst + visblkcnt ;
		lbp->vbd_addr = visblkcnt * visblksiz ;
		worksize = testsize - moresize ;

		if ( percflag || strpflag ) {
			lbp->vbd_flags = flipflag ? VBF_USEFUL : 0 ;
			if ( percflag ) {
				if ( headflag && ( worksize < headsize ) )
					{ lbp->vbd_flags = flipflag ? 0 : VBF_USEFUL ; }
				if ( tailflag && ( worksize >= tailsize ) )
					{ lbp->vbd_flags = flipflag ? 0 : VBF_USEFUL ; }
				if ( coreflag && ( worksize >= corehead && worksize < coretail ) )
					{ lbp->vbd_flags = flipflag ? 0 : VBF_USEFUL ; }
			}
			if ( strpflag ) {
				for ( stripinx = 0 ; stripinx < stripcnt ; ++stripinx ) {
					if ( worksize >= strpbase[stripinx] && worksize < ( strpbase[stripinx] + strpsize ) )
						{ lbp->vbd_flags = flipflag ? 0 : VBF_USEFUL ; break ; }
				}
			}
		} else
			{ lbp->vbd_flags = VBF_USEFUL ; }

		percok = ( moresize * 100 ) / testsize ;
		if ( percok != lastpercok ) {
			percy = ( 10 * percok ) / 100 ;
			if ( percy ) {
				mvwprintw (pwp, 11-percy, 1, "%3d %% %s", percok, (char *) vdtkmgtpe (moresize?moresize:1)) ;
				wrefresh (pwp) ;
				lastpercok = percok ;
			}
		}

		if ( moresize >= visblksiz ) {
			lbp->vbd_size = visblksiz ;
			moresize -= visblksiz ;
		} else {
			lbp->vbd_size = moresize ;
			moresize = 0 ;
		}

		if ( bcol > avcols ) {
			bcol = 1 ;
			++brow ;
		}

		lbp->vbd_lin  = brow ;
		lbp->vbd_col  = bcol++ ;
		lbp->vbd_hits = 0 ;

		if ( lbp->vbd_flags & VBF_USEFUL ) {
			mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, '.') ;
			++visblkuse ;
		} else {
			mvwaddch (bwp, lbp->vbd_lin, lbp->vbd_col, skipchar) ;
		}
		wrefresh (bwp) ;

		++visblkcnt ;
	}

	/* lbp->vbd_flags |= VBF_ENDING ; */

	if ( lbp->vbd_size == visblksiz ) {
		wprintw ( swp, "{%ldx%s}", (long) visblkcnt, (char *) skipspac ( vdtkmgtpe ( (long long)visblksiz ) ) ) ;
		totvisblk = visblkcnt ;
		lastsize = 0 ;
	} else {
		wprintw ( swp, "{%ldx%s", (long) (visblkcnt-1), (char *) skipspac ( vdtkmgtpe ( (long long)visblksiz ) ) ) ;
		wprintw ( swp, "+%s}", (char *) skipspac ( vdtkmgtpe ( (long long)lbp->vbd_size ) ) ) ;
		totvisblk = visblkcnt - 1 ;
		lastsize = lbp->vbd_size ;
		lbp->vbd_flags |= VBF_SCRAPS ;
	}

	if ( altbufsiz != 0 ) {
		wprintw ( swp , "%c" , flipflag ? '\\' : '/' ) ;
		if ( altbufsiz > 8192 )
			wprintw ( swp , "%s" , skipspac ( vdtkmgtpe ( (long long) altbufsiz ) ) ) ;
		else
			wprintw ( swp , "%ld" , (long) altbufsiz ) ;
	}

	if ( deadflag ) {
		mvwprintw ( swp, 0, (SW_WID)-10, "%s", strtime (riptloc) ) ;
		if ( soonflag )
			coletc = 14 ;
		else
			mvwprintw ( swp, 0, (SW_WID)-21, "%s", strdate (riptloc) ) ;
		mvwprintw ( swp, 0, (SW_WID)-coletc, "%s", "etc" ) ;
	}

	wrefresh (swp) ;
	redoflag = 0 ;

	if ( visblklim >= visblkcnt ) {
		sprintf (errmsg, "invalid maximum iterations (%lld)", (long long)visblklim) ;
		vdterr (NULL) ;
		vdtend (VER_BADMXOPS) ;
	}

	if ( incrflag && ( ! ( redoflag || goneflag ) ) )
		vdtest ( VDT_INCR ) ;
	if ( decrflag && ( ! ( redoflag || goneflag ) ) )
		vdtest ( VDT_DECR ) ;
	if ( scatflag && ( ! ( redoflag || goneflag ) ) )
		vdtest ( VDT_SCAT ) ;
	if ( convflag && ( ! ( redoflag || goneflag ) ) )
		vdtest ( VDT_CONV ) ;
	if ( spotflag && ( ! ( redoflag || goneflag ) ) )
		vdtest ( VDT_SPOT ) ;
	if ( goldflag && ( ! ( redoflag || goneflag ) ) )
		vdtest ( VDT_GOLD ) ;
	if ( randflag && ( ! ( redoflag || goneflag ) ) )
		vdtest ( VDT_RAND ) ;
}

/*	__	__	__	__	__	__	__	__	*/

void vdt () {

	do {
		vdtinit () ;
		vdtmain () ;
	} while ( redoflag || lifeflag ) ;

	vdtend (0) ;
}

/*	__	__	__	__	__	__	__	__	*/

int main (argc, argv) int argc ; char * * argv ; {

	vdtparse ( argc , argv ) ;

	vdt () ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	*/

/*
 * vi:nu ts=4
 */
