
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdtyp.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# ifndef _STDTYP_H

# define _STDTYP_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	FIX			static
# define	REG			register
# define	EXT			extern
/* # define	NEW			auto */
# define	UNS			unsigned
# define	TYP			typedef

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef _AIX
typedef		int64_t		sbit64 ;
# endif

# ifdef __hpux
typedef		int64_t		sbit64 ;
# endif

# ifdef linux
typedef		/* int64_t */ long long int		sbit64 ;
typedef		unsigned long long int	ubit64 ;
# endif

# ifdef __FreeBSD__
typedef		/* int64_t */ long long int		sbit64 ;
typedef		unsigned long long int	ubit64 ;
# endif

# ifdef __NetBSD__
typedef		/* int64_t */ long long int		sbit64 ;
typedef		unsigned long long int	ubit64 ;
# endif

# ifdef __OpenBSD__
typedef		/* int64_t */ long long int		sbit64 ;
typedef		unsigned long long int	ubit64 ;
# endif

# ifdef __CYGWIN__
typedef		long long int			sbit64 ;
typedef		unsigned long long int	ubit64 ;
# endif

# ifdef sun
typedef		longlong_t	sbit64 ;
# endif

# ifdef MSVC
typedef		__int64		sbit64 ;
typedef		unsigned long	u_long ;
# endif

# ifdef BCC55
typedef		__int64		sbit64 ;
/* typedef		unsigned long	u_long ; */
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

TYP		UNS char		UCHAR ;
TYP		UNS short		USHORT ;
TYP		UNS int			UINT ;
TYP		UNS long		ULONG ;

TYP		UNS				BIT ;
TYP		UCHAR			BYTE ;
TYP		USHORT			WORD ;
TYP		ULONG			DWORD ;

TYP		int				BOOL ;

TYP		char *			STR ;
TYP		char *			PTR ;
TYP		BYTE *			ADDR ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	KBYTE		* 1024
# define	KBYTES		* 1024

# define	MBYTE		* 1048576
# define	MBYTES		* 1048576

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDTYP_H */

/*
 * vi:tabstop=4
 */
