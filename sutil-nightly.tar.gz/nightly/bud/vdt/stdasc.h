
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdasc.h						 (c) 1996 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# ifndef _STDASC_H

# define _STDASC_H

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef REMASC

/*
	dec  hex  oct  chr		dec  hex  oct  chr		dec  hex  oct  chr

	  0  x00  000  NUL		 43  x2b  053  +		 86  x56  126  V
	  1  x01  001  SOH		 44  x2c  054  ,		 87  x57  127  W
	  2  x02  002  STX		 45  x2d  055  -		 88  x58  130  X
	  3  x03  003  ETX		 46  x2e  056  .		 89  x59  131  Y
	  4  x04  004  EOT		 47  x2f  057  /		 90  x5a  132  Z
	  5  x05  005  ENQ		 48  x30  060  0		 91  x5b  133  [
	  6  x06  006  ACK		 49  x31  061  1		 92  x5c  134  \
	  7  x07  007  BEL		 50  x32  062  2		 93  x5d  135  ]
	  8  x08  010  BS 		 51  x33  063  3		 94  x5e  136  ^
	  9  x09  011  HT 		 52  x34  064  4		 95  x5f  137  _
	 10  x0a  012  LF 		 53  x35  065  5		 96  x60  140  `
	 11  x0b  013  ...		 54  x36  066  6		 97  x61  141  a
	 12  x0c  014  ...		 55  x37  067  7		 98  x62  142  b
	 13  x0d  015  CR 		 56  x38  070  8		 99  x63  143  c
	 14  x0e  016  SO 		 57  x39  071  9		100  x64  144  d
	 15  x0f  017  SI 		 58  x3a  072  :		101  x65  145  e
	 16  x10  020  DLE		 59  x3b  073  ;		102  x66  146  f
	 17  x11  021  DC1		 60  x3c  074  <		103  x67  147  g
	 18  x12  022  DC2		 61  x3d  075  =		104  x68  150  h
	 19  x13  023  DC3		 62  x3e  076  >		105  x69  151  i
	 20  x14  024  DC4		 63  x3f  077  ?		106  x6a  152  j
	 21  x15  025  NAK		 64  x40  100  @		107  x6b  153  k
	 22  x16  026  SYN		 65  x41  101  A		108  x6c  154  l
	 23  x17  027  ETB		 66  x42  102  B		109  x6d  155  m
	 24  x18  030  CAN		 67  x43  103  C		110  x6e  156  n
	 25  x19  031  EM 		 68  x44  104  D		111  x6f  157  o
	 26  x1a  032  SUB		 69  x45  105  E		112  x70  160  p
	 27  x1b  033  ESC		 70  x46  106  F		113  x71  161  q
	 28  x1c  034  FS 		 71  x47  107  G		114  x72  162  r
	 29  x1d  035  GS 		 72  x48  110  H		115  x73  163  s
	 30  x1e  036  RS 		 73  x49  111  I		116  x74  164  t
	 31  x1f  037  US 		 74  x4a  112  J		117  x75  165  u
	 32  x20  040  SPC		 75  x4b  113  K		118  x76  166  v
	 33  x21  041  !		 76  x4c  114  L		119  x77  167  w
	 34  x22  042  ""		 77  x4d  115  M		120  x78  170  x
	 35  x23  043  #		 78  x4e  116  N		121  x79  171  y
	 36  x24  044  $		 79  x4f  117  O		122  x7a  172  z
	 37  x25  045  %		 80  x50  120  P		123  x7b  173  {
	 38  x26  046  &		 81  x51  121  Q		124  x7c  174  |
	 39  x27  047  ''		 82  x52  122  R		125  x7d  175  }
	 40  x28  050  (		 83  x53  123  S		126  x7e  176  ~
	 41  x29  051  )		 84  x54  124  T		127  x7f  177  DEL
	 42  x2a  052  *		 85  x55  125  U
*/

/*
	  0='?'   1='?'   2='?'   3='?'   4='?'   5='?'   6='?'   7='?' 
	  8='?'   9='?'  10='?'  11='?'  12='?'  13='?'  14='?'  15='?' 
	 16='?'  17='?'  18='?'  19='?'  20='?'  21='?'  22='?'  23='?' 
	 24='?'  25='?'  26='?'  27='?'  28='?'  29='?'  30='?'  31='?' 
	 32=' '  33='!'  34='"'  35='#'  36='$'  37='%'  38='&'  39='\'' 
	 40='('  41=')'  42='*'  43='+'  44=','  45='-'  46='.'  47='/' 
	 48='0'  49='1'  50='2'  51='3'  52='4'  53='5'  54='6'  55='7' 
	 56='8'  57='9'  58=':'  59=';'  60='<'  61='='  62='>'  63='?' 
	 64='@'  65='A'  66='B'  67='C'  68='D'  69='E'  70='F'  71='G' 
	 72='H'  73='I'  74='J'  75='K'  76='L'  77='M'  78='N'  79='O' 
	 80='P'  81='Q'  82='R'  83='S'  84='T'  85='U'  86='V'  87='W' 
	 88='X'  89='Y'  90='Z'  91='['  92='\\'  93=']'  94='^'  95='_' 
	 96='`'  97='a'  98='b'  99='c' 100='d' 101='e' 102='f' 103='g' 
	104='h' 105='i' 106='j' 107='k' 108='l' 109='m' 110='n' 111='o' 
	112='p' 113='q' 114='r' 115='s' 116='t' 117='u' 118='v' 119='w' 
	120='x' 121='y' 122='z' 123='{' 124='|' 125='}' 126='~' 127='?' 
	128='�' 129='�' 130='�' 131='�' 132='�' 133='�' 134='�' 135='�' 
	136='�' 137='�' 138='�' 139='�' 140='�' 141='�' 142='�' 143='�' 
	144='�' 145='�' 146='�' 147='�' 148='�' 149='�' 150='�' 151='�' 
	152='�' 153='�' 154='�' 155='�' 156='�' 157='�' 158='�' 159='�' 
	160='�' 161='�' 162='�' 163='�' 164='�' 165='�' 166='�' 167='�' 
	168='�' 169='�' 170='�' 171='�' 172='�' 173='�' 174='�' 175='�' 
	176='�' 177='�' 178='�' 179='�' 180='�' 181='�' 182='�' 183='�' 
	184='�' 185='�' 186='�' 187='�' 188='�' 189='�' 190='�' 191='�' 
	192='�' 193='�' 194='�' 195='�' 196='�' 197='�' 198='�' 199='�' 
	200='�' 201='�' 202='�' 203='�' 204='�' 205='�' 206='�' 207='�' 
	208='�' 209='�' 210='�' 211='�' 212='�' 213='�' 214='�' 215='�' 
	216='�' 217='�' 218='�' 219='�' 220='�' 221='�' 222='�' 223='�' 
	224='�' 225='�' 226='�' 227='�' 228='�' 229='�' 230='�' 231='�' 
	232='�' 233='�' 234='�' 235='�' 236='�' 237='�' 238='�' 239='�' 
	240='�' 241='�' 242='�' 243='�' 244='�' 245='�' 246='�' 247='�' 
	248='�' 249='�' 250='�' 251='�' 252='�' 253='�' 254='�' 255='�' 
*/

# endif /* REMASC */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define  CTRL_A	 1
# define  CTRL_B	 2
# define  CTRL_C	 3
# define  CTRL_D	 4
# define  CTRL_E	 5
# define  CTRL_F	 6
# define  CTRL_G	 7
# define  CTRL_H	 8
# define  CTRL_I	 9
# define  CTRL_J	10
# define  CTRL_K	11
# define  CTRL_L	12
# define  CTRL_M	13
# define  CTRL_N	14
# define  CTRL_O	15
# define  CTRL_P	16
# define  CTRL_Q	17
# define  CTRL_R	18
# define  CTRL_S	19
# define  CTRL_T	20
# define  CTRL_U	21
# define  CTRL_V	22
# define  CTRL_W	23
# define  CTRL_X	24
# define  CTRL_Y	25
# define  CTRL_Z	26

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define  BS		'\b'
# define  TAB		'\t'
# define  NL		'\n'
# define  FF		'\f'
# define  VT		'\v'
# define  CR		'\r'

# define  NUL		0x00
# define  SOH		0x01
# define  STX		0x02
# define  ETX		0x03
# define  EOT		0x04
# define  ENQ		0x05
# define  ACK		0x06
# define  BEL		0x07
# define  HT		0x09
# define  LF		0x0a
# define  SO		0x0e
# define  SI		0x0f
# define  DLE		0x10
# define  DC1		0x11
# define  DC2		0x12
# define  DC3		0x13
# define  DC4		0x14
# define  NAK		0x15
# define  SYN		0x16
# define  ETB		0x17
# define  CAN		0x18
# define  EM		0x19
# define  SUB		0x1a
# define  ESC		0x1b
# define  FS		0x1c
# define  GS		0x1d
# define  ASC_RS	0x1e
# define  US		0x1f

# define  DEL		127

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define  SPC			' '
# define  AT			'@'
# define  DOT			'.'
# define  ASTERISK		'*'
# define  COLON			':'
# define  COMMA			','
# define  NUMBERSIGN	'#'
# define  HASHSIGN		'#'
# define  POUNDSIGN		'#'
# define  VANE			'\"'
# define  MINUS			'-'
# define  PLUS			'+'
# define  SLASH			'/'
# define  UNDERSCORE	'_'
# define  BACKSLASH		'\\'
# define  CARET			'^'
# define  PLICK			'\''
# define  PIPE			'|'

# define  COPYRIGHT		'\0251'

/* # define  TILDE			'~' */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDASC_H */

/*
 * vi:nu tabstop=4
 */
