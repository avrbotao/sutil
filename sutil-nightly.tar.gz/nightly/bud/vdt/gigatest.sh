# 'gigabyte' vdt test suite
# Nov'10	<alexandre@botao.org>
[ -x ./vdt ] || exit
siz=1G
first=ggg.lix
secnd=iii.lix
rm -f $first $secnd vdt*.log vdt*.err
./vdt $2 -A --make -w $first -z $siz -P x55ab 
./vdt $2 -A --copy -r $first -w $secnd
./vdt $2 -A --cool -f $secnd --sync --rand
./vdt $2 -A --comp -r $secnd -c $first --gold
./vdt $2 -A --poke -w $first --rand -P rand -v -v
./vdt $2 -A --comp -r $secnd -c $first --scat
./vdt $2 -A --cook -r $secnd --read --si -T -E -t 3 --wrap -v -v -p 60 --slab -M 10 -I 'wrap/slab'
./vdt $2 -A --burn -w $first --writ -t 3 -v -v --wrap -p 50 -s 5 --flip -M 5 --stew -I 'stew/wrap/flip'
ls -l vdt*.log vdt*.err
rm -f $first $secnd
