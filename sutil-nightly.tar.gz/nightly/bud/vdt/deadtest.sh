# 'deadline' vdt feature validation test suite
# Sep'10	<alexandre@botao.org>
# Jul'17	kunlun enhancements
fixnum () {
	n="$1"
	m="$2"
	if test -z "$n"
	then
		echo 0
	else
		case $n in
			[0-9][0-9])
				if test $n -ge 0 -a $n -le $m
				then
					echo $n
				else
					echo 0
				fi
			;;
			*) echo 0 ;;
		esac
	fi
}
sethms () {
	tt="$1"
	if test -z "$tt"
	then
		echo "+++ missing target (hh:mm:ss) duration +++"
		exit 1
	fi
	hh=`date +%H`
	mm=`date +%M`
	ss=`date +%S`
	ts=`echo $tt | awk -F: '{ print $3 }'`
	tm=`echo $tt | awk -F: '{ print $2 }'`
	th=`echo $tt | awk -F: '{ print $1 }'`
	ts=`fixnum "$ts" 59`
	tm=`fixnum "$tm" 59`
	th=`fixnum "$th" 23`
	if test `expr $ts + $tm + $th` -eq 0
	then
		echo "+++ invalid target ($tt) duration +++"
		exit 1
	fi
	ss=`expr $ss + $ts`
	mm=`expr $mm + $tm`
	hh=`expr $hh + $th`
	if [ $ss -gt 59 ]
	then
		ss=`expr $ss - 60`
		mm=`expr $mm + 1`
	fi
	if [ $mm -gt 59 ]
	then
		mm=`expr $mm - 60`
		hh=`expr $hh + 1`
	fi
	if [ $hh -gt 23 ]
	then
		hh=`expr $hh - 24`
		dd=`expr $hh / 24`
	fi
}
[ -x ./vdt ] || exit
siz=128M
first=bbb.lix
secnd=ppp.lix
[ -n "$2" ] && siz=$2
dur="$1"
sethms "$dur"
tgt="$hh$mm.$ss"
rm -f $first $secnd vdt*.log vdt*.err
xop=$3
./vdt $xop -A --make -w $first -z $siz -P x55ab -F
echo "=== duration($dur) adjust($tgt) ==="
./vdt $xop -A --writ -w $first --sync -v -v --rand --daze --wrap -D $tgt -I "try($tgt)/wrap"
sethms "$dur"
./vdt $xop -A --writ -w $first --sync -v -v --rand --daze --wrap --burn -D $tgt -I "last($tgt)/wrap"
ls -l vdt*.log 
rm -f $first $secnd
# vi:nu ts=4
