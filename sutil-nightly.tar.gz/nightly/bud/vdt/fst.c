
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*                               _______________________________________
 *                              |                                       |
 *                              |   fst      file(system) stress test   |
 *                              |_______________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This file is part of 'VDT' (the Visual Disk Test) by <botao.org> ;  |
 |                                                                      |
 |  'VDT' is Free and Open Source software (FOSS). This means you can   |
 |  redistribute it and/or modify it under the terms of the GNU General |
 |  Public License as published by the Free Software Foundation, either |
 |  version 3 of the License, or (at your option) any later version.    |
 |                                                                      |
 |  'VDT' is distributed in the hope that it will be useful,            |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License	|
 |  along with 'VDT'.  If not, see <http://www.gnu.org/licenses/>, or	|
 |  write to the Free Software Foundation, Inc.,                        |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# include <fcntl.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>

# include <unistd.h>

# include <sys/types.h>
# include <sys/stat.h>

# include <sys/resource.h>

typedef		struct stat		STABUF ;

# define	MAXTST		9

# define	MIN(A,B)	( (A) < (B) ? (A) : (B) )

# define FST_STAT1 0x00000001 /* stat	1								*/
# define FST_CREAT 0x00000002 /* create+close							*/
# define FST_STAT2 0x00000004 /* stat	2								*/
# define FST_OPENR 0x00000008 /* open(RDONLY)+close						*/
# define FST_STAT3 0x00000010 /* stat	3								*/
# define FST_OWRIT 0x00000020 /* open(WRONLY)+writ(512)+close			*/
# define FST_STAT4 0x00000040 /* stat	4								*/
# define FST_OREAD 0x00000080 /* open(RDONLY)+read(512)+close			*/
# define FST_STAT5 0x00000100 /* stat	5								*/
# define FST_TRUNC 0x00000200 /* open(WRONLY+TRUNC)+close				*/
# define FST_STAT6 0x00000400 /* stat	6								*/
# define FST_WSYNC 0x00000800 /* open(WRONLY+SYNC)+writ(512)+close		*/
# define FST_STAT7 0x00001000 /* stat	7								*/
# define FST_UPDAT 0x00002000 /* open(RDWR)+read(512)+writ(512)+close	*/
# define FST_STAT8 0x00004000 /* stat	8								*/
# define FST_APPND 0x00008000 /* open(append)+writ(1MiB)+close			*/
# define FST_STAT9 0x00010000 /* stat	9								*/
# define FST_UNLNK 0x00020000 /* unlink									*/

struct fstdat {
	int		ftd_fd ;
	int		ftd_rd [MAXTST] ;
	char *	ftd_buf ;
	char *	ftd_name ;
	STABUF	fst_stab [MAXTST] ;
} ;

typedef		struct fstdat		FSTDAT ;

# define FSTDATSIZ	(sizeof(FSTDAT))

FSTDAT		fstone ;

FSTDAT *	fstbuf = NULL ;

void fst (nft, flg) int nft , flg ; {
	register int i , rd ;
	int	sysnof = 0 , usenof = 0 ;
	long opnmax = 0 ;
	struct rlimit rlmbuf ;

	if ( nft <= 0 )
		return ;

	printf ("files=%d tests=%x\n", nft, flg) ;

	rd = getrlimit ( RLIMIT_NOFILE , &rlmbuf ) ;

	if ( rd == -1 ) {
		perror ("fst/getrlim(NOF)") ;
		return ;
	}

	printf ("sysnof=%d/%d\n", (int)rlmbuf.rlim_cur, (int)rlmbuf.rlim_max) ;

	sysnof = (int)rlmbuf.rlim_cur ;

	opnmax = sysconf ( _SC_OPEN_MAX ) ;

	if ( opnmax == -1L ) {
		perror ("fst/sysconf(OPNMAX)") ;
		return ;
	}

	printf ("opnmax=%ld\n", opnmax) ;

	usenof = MIN ( sysnof , (int)opnmax ) ;

	printf ("usenof=%d\n", usenof) ;

	if ( nft > usenof ) {
		fprintf (stderr, "not enough files\n") ;
		return ;
	}

	/*	N-at-a-time		*/

	/*	prep-N													*/
	if ( fstbuf == NULL ) {
		fstbuf = (FSTDAT *) calloc ( (size_t)nft , (size_t)FSTDATSIZ ) ;
		if ( fstbuf == NULL ) {
			perror ("fst/(calloc)") ;
			return ;
		}
	}
	/*	stat1-N													*/
	if ( flg & FST_STAT1 ) {
		for ( i = 0 ; i < nft ; ++i ) {
		}
	}
	/*	create-N + close-N										*/
	/*	stat2-N													*/
	/*	open-N (RDONLY) + close-N								*/
	/*	stat3-N													*/
	/*	open-N (WRONLY) + write(512) + close-N					*/
	/*	stat4-N													*/
	/*	open-N (RDONLY) + read(512) + close-N					*/
	/*	stat5-N													*/
	/*	open-N (WRONLY+TRUNC) + close-N							*/
	/*	stat6-N													*/
	/*	open-N (WRONLY+SYNC) + write(512) + close-N				*/
	/*	stat7-N													*/
	/*	open-N (RDWR) + read(512) + upd + write(512) + close-N	*/
	/*	stat8-N													*/
	/*	open-N (append) + write(1MiB) + close-N					*/
	/*	stat9-N													*/
	/*	unlink-N												*/

	/*	1-at-a-time , N times	*/

	for ( i = 0 ; i < nft ; ++i ) {
		/*	stat												*/
		/*	create + close										*/
		/*	stat												*/
		/*	open (RDONLY) + close								*/
		/*	stat												*/
		/*	open (WRONLY) + write(512) + close					*/
		/*	stat												*/
		/*	open (RDONLY) + read(512) + close					*/
		/*	stat												*/
		/*	open (WRONLY+TRUNC) + close							*/
		/*	stat												*/
		/*	open (WRONLY+SYNC) + write(512) + close				*/
		/*	stat												*/
		/*	open (RDWR) + read(512) + upd + write(512) + close	*/
		/*	stat												*/
		/*	open (append) + write(1MiB) + close					*/
		/*	stat												*/
		/*	unlink												*/
	}	/*	end of for(main)	*/

	if ( fstbuf != NULL )
		free ( fstbuf ) ;
}

char * swid = "fst" ;

int main (argc, argv) int argc ; char * * argv ; {
	int narq = 0 , tstf = 0 ;

	if (--argc)
		while (*++argv)
			if ( 0 == strcmp (*argv, "-n") )
				narq = atoi (*++argv) ;
			else if ( 0 == strcmp (*argv, "-t") )
				sscanf (*++argv, "%x", &tstf) ;
			else
				fprintf (stderr, "use: %s [-n files] [-t testflags]\n", swid) ;
	fst (narq, tstf) ;
	return 0 ;
}

/*
 * vi:nu ts=4
 */
