# 'big' vdt feature validation test suite
# Sep'10	alexandre <botao.org>
[ -x ./vdt ] || exit
siz=64M
first=aaa.lix
secnd=zzz.lix
[ "$1" != "" ] && siz=$1
rm -f $first $secnd vdt*.log vdt*.err
./vdt $2 -A --make -w $first -z $siz -P x55ab 
./vdt $2 -A --copy -r $first -w $secnd
./vdt $2 -A --read -r $secnd
./vdt $2 -A --read -r $first --conv -b 4K
./vdt $2 -A --read -r $secnd --decr
./vdt $2 -A --read -r $first --rand -b 4K --part
./vdt $2 -A --read -r $secnd --spot
./vdt $2 -A --read -r $first --rand --uniq
./vdt $2 -A --cool -f $secnd --sync --rand 
./vdt $2 -A --comp -r $secnd -c $first --gold -m 400
./vdt $2 -A --poke -w $first --rand -P rand -m 100 -v -v
./vdt $2 -A --comp -r $secnd -c $first --scat -m 400 -v -v
./vdt $2 -A --blot -f $first --conv --sync
./vdt $2 -A --read -r $first -p 50
./vdt $2 -A --writ -w $secnd -p 50 --tail
./vdt $2 -A --writ -w $first -p 50 --core --daze
./vdt $2 -A --read -r $secnd -p 60 --edge --rand -v -v
./vdt $2 -A --writ -w $first -p 40 --slab --rand --flip --uniq
./vdt $2 -A --read -r $secnd -p 40 --slab --rand --uniq -t 3 --wrap -v -v -M 10
./vdt $2 -A --poke -w $secnd --rand -P zero -Z 13m
./vdt $2 -A --read -r $first -s 4 --even --rand --uniq
./vdt $2 -A --read -r $first -s 4 --even --rand --uniq --flip -v -v
./vdt $2 -A --writ -w $secnd --rand -v -v -t 3 -P xa5b5c
./vdt $2 -A --stir -f $first --gold --sync
./vdt $2 -A --read -r $secnd --scat -t 3 -v -v
./vdt $2 -A --writ -w $first --rand -P random
./vdt $2 -A --writ -w $secnd --rand --stew -Z 11M
./vdt $2 -A --writ -w $first --rand -P random --uniq
./vdt $2 -A --seek -r $secnd -p 50 --core --uniq --rand
./vdt $2 -A --poke -w $first --rand --sync -P xb5a -v -v
./vdt $2 -A --poke -w $secnd --spot -P xb5 --wrap -t 6 -v -v --sync
./vdt $2 -A --writ -w $first --rand -v -v -t 3 --sync -P xabc55def
./vdt $2 -A --read -r $secnd -s 6 -p 40 --rand --flip -v -v
./vdt $2 -A --read -r $secnd -s 6 -p 40 --rand 
./vdt $2 -A --writ -w $first --rand -t 3 -v -v -p 69 --slab
./vdt $2 -A --cook -r $secnd --si -T -E -t 3 --wrap -v -v -M 10
./vdt $2 -A --writ -w $first --burn -t 3 -v -v --wrap -M 5
./vdt $2 -A --writ -w $secnd --burn -t 3 -v -v --wrap -M 5 -p 50 --slab --flip -I 'wrap-slab-flip'
./vdt $2 -A --cook -r $first --si -T -E -t 3 --wrap -v -v -M 10 -s 5 --even
./vdt $2 -A --read -r $first --rand --bias -z 4M -t 15 -v --cloy -I 'cloy/bias15secs'
./vdt $2 -A --read -r $first --rand --bias -z 8M -t 15 -v --glib -I '15seconds-glib' -b 2K
./vdt $2 -A --read -r $first --rand --bias -z 8M -t 15 -v --snag -I 'bias-15s-snag' -b 2K --part
ls -l vdt*.log vdt*.err
rm -f $first $secnd
