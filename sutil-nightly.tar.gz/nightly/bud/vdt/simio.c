
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

								/************************************/
								/*	simulated/virtual i/o package	*/
								/************************************/

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# include <sys/types.h>
# include <sys/stat.h>

# include <fcntl.h>
# include <unistd.h>

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef SIMIO

# include "simio.h"

# endif /* SIMIO */

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

# ifdef SIMIO

SIMFILE		simtab [MAXSIMFDS] ;
int			simvfd = 3 ;

unsigned long	sio_open_delay = SIO_DFL_OPEN_TIME_US ;
unsigned long	sio_cret_delay = SIO_DFL_CRET_TIME_US ;
unsigned long	sio_clos_delay = SIO_DFL_CLOS_TIME_US ;
unsigned long	sio_seek_delay = SIO_DFL_SEEK_TIME_US ;
unsigned long	sio_read_delay = SIO_DFL_READ_TIME_US ;
unsigned long	sio_writ_delay = SIO_DFL_WRIT_TIME_US ;

/*	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	__	*/

VFD		simopen (name, flag) char * name ; int flag ; {

	SIMFILE *	sfp = &simtab[simvfd] ;

	sfp->sf_name = name ;
	sfp->sf_flag = flag ;
	sfp->sf_offs = 0 ;

	if (flag & O_CREAT)
		sfp->sf_size = 0 ;
	else
		sfp->sf_size = SIO_DFL_FILESIZE ;

	usleep (sio_open_delay) ;

	return sfp->sf_desc = simvfd++ ;
}

VFD		simcreat (name, flag) char * name ; int flag ; {

	usleep (sio_cret_delay) ;

	return simopen (name, O_CREAT) ;
}

int		simioctl (vfd, cmd, flag) VFD vfd ; int cmd ; int flag ; {

	usleep (sio_seek_delay) ;

	return 0 ;
}

int		simclos (vfd) VFD vfd ; {

	usleep (sio_clos_delay) ;

	return 0 ;
}

int		simstat (name, sbuf) char * name ; struct stat * sbuf ; {

	usleep (sio_seek_delay) ;

	return 0 ;
}

off_t	simseek (fd, offset, whence) VFD fd ; off_t offset ; int whence ; {

	SIMFILE *	sfp = &simtab[fd] ;

	switch (whence) {
		case SEEK_SET : sfp->sf_offs = offset ; break ;
		case SEEK_CUR : sfp->sf_offs += offset ; break ;
		case SEEK_END : sfp->sf_offs = sfp->sf_size + offset ; break ;
		default : return -1 ; break ;
	}

	usleep (sio_seek_delay) ;

	return sfp->sf_offs ;
}

ssize_t	simread (fd, buffer, count) VFD fd ; char * buffer ; size_t count ; {

	SIMFILE *	sfp = &simtab[fd] ;

	sfp->sf_offs += count ;

	usleep ( (count >> 20) * (sio_read_delay >> 1) ) ;

	return count ;
}

ssize_t	simwrit (fd, buffer, count) VFD fd ; char * buffer ; size_t count ; {

	SIMFILE *	sfp = &simtab[fd] ;

	sfp->sf_offs += count ;

	usleep (sio_writ_delay) ;

	return count ;
}

# endif /* SIMIO */

/*
 * vi:nu ts=4
 */
