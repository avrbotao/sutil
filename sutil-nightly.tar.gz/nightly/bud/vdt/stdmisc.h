
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdmisc.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

# ifndef _STDMISC_H

# define _STDMISC_H

/* typedef		unsigned long		ULONG ; */

# ifdef TC2
#		include	<mem.h>
# endif

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# ifdef _LARGEFILE_SOURCE
# define XLFS64
# endif

# ifdef XLFS64

#	define		KMGTPE(X)		lltokmgtpe(X)

# else  /* XSFS32 */

#	define		KMGTPE(X)		ltokmg(X)

# endif /* XLFS64 */

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# define	PTE_DATE	0x00000100
# define	PTE_TIME	0x00000200
# define	PTE_DONE	0x00000400
# define	PTE_PCOK	0x00000400
# define	PTE_TODO	0x00001000
# define	PTE_ELAP	0x00002000
# define	PTE_RATE	0x00004000
# define	PTE_PBAR	0x00010000
# define	PTE_ETTC	0x00020000
# define	PTE_NEWL	0x00040000

/*	__	__	__	__	__	__	__	__	*/

extern char * cpufam ;
extern char * osname ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

#ifdef LINUX

struct distroinf {
	char *	di_sys ;
	char *	di_nam ;
	char *	di_rel ;
} ;

typedef		struct distroinf		DISTROINF ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

char *			getdistro	OF ( (void)									) ;

#endif /* LINUX */

char *			getcpuinf	OF ( (char *)								) ;

int				isbigend	OF ( (void)									) ;
int				islilend	OF ( (void)									) ;

unsigned long long bits2ull	OF ( (char *)								) ;

long long		getsysram	OF ( (void)									) ;

char *			ull2bits	OF ( (unsigned long long)					) ;

long			hms2sec		OF ( (char *)								) ;

char *			getverno	OF ( (char *)								) ;
char *			getosver	OF ( (struct utsname *)						) ;

char *			strhms		OF ( (ULONG)								) ;

char *			abspath		OF ( (char *)								) ;
char *			bintos		OF ( (char *)								) ;
char *			dirpick		OF ( (char *)								) ;
char *			dirscan		OF ( (char *, char *)						) ;
char *			dirview		OF ( (char *)								) ;
char *			dirwalk		OF ( (char *)								) ;
char *			itostr		OF ( (int)									) ;
char *			signame		OF ( (int)									) ;
char *			lastname	OF ( (char *)								) ;
char *			scanview	OF ( (char *, char *)						) ;
char *			stobin		OF ( (char *)								) ;
char *			exptab		OF ( (char *, int)							) ;
char *			xltoa		OF ( (long, int, int)						) ;

char *			ltokmg			OF ( (long)								) ;
char *			lltokmgtpe		OF ( (sbit64)							) ;
char *			lltosikmgtpe	OF ( (sbit64)							) ;

int				ptrel		OF ( (ULONG, ULONG, ULONG)					) ;
int				ptrel64		OF ( (sbit64, sbit64, ULONG)				) ;

int				dotdir		OF ( (char *)								) ;
int				lastoc		OF ( (char *, int)							) ;
int				strcount	OF ( (char *, int)							) ;
int				makedir		OF ( (char *)								) ;
int				makepath	OF ( (char *)								) ;

ULONG			blkstokb	OF ( (ULONG, ULONG)							) ;

void			verban		OF ( ( void )								) ;

void			trimeol		OF ( (char *, int)							) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDMISC_H */

/*
 * vi:nu tabstop=4
 */
