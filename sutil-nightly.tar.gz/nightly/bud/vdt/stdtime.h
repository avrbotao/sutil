
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*______________________________________________________________________
 |                                                                      |
 |  This code is free software: you can redistribute it and/or modify   |
 |  it under the terms of the GNU General Public License as published   |
 |  by the Free Software Foundation, either version 3 of the License,   |
 |  or (at your option) any later version.                              |
 |                                                                      |
 |  This code is distributed in the hope that it will be useful,        |
 |  but WITHOUT ANY WARRANTY; without even the implied warranty of      |
 |  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
 |  See the GNU General Public License for more details.                |
 |                                                                      |
 |  You should have received a copy of the GNU General Public License   |
 |  along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
 |  or write to the Free Software Foundation, Inc.,                     |
 |  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
 |______________________________________________________________________|
 */

/*		 _______________________________________________________________
 *		|																|
 *		|	stdtime.h						 (c) 1998 Alexandre Botao	|
 *		|_______________________________________________________________|
 */

# ifndef _STDTIME_H

# define _STDTIME_H

# include <sys/time.h>

# include <time.h>
# include <utime.h>

# define	CF_TIME		0x0001

# define	RAWSTAMP	0x0001
# define	PLUSTAMP	0x0002

# define	MINPERDAY	 1440	/*		(24*60)		*/
# define	SECPERDAY	86400	/*	  (24*3600)		*/

# define	DTP_MARK	0x0001	/*	missing fields = -1				*/
# define	DTP_COMP	0x0002	/*	missing fields = localtime		*/

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

typedef		struct timespec		TIMESPEC ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

struct tm *		dtparse		OF ( (char *, int)							) ;
long long		diftod		OF ( (struct timeval *, struct timeval *)	) ;
char *			fmtus		OF ( (long long)							) ;

char *			strtime		OF ( (long)									) ;
char *			strhourmin	OF ( (long)									) ;
char *			strdate		OF ( (long)									) ;
char *			strdaymon	OF ( (long)									) ;
char *			timestamp	OF ( (long, int)							) ;

long			maketime	OF ( (int, int, int, int, int, int, int)	) ;

void			timechop	OF ( ( long, int *, int *, int *,
										 int *, int *, int * )			) ;

/*	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	--	*/

# endif /* _STDTIME_H */

/*
 * vi:nu tabstop=4
 */
